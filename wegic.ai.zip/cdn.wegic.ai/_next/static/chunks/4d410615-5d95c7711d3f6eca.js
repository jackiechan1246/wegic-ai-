! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e5174131-62a5-4c90-96fb-e5237d1bff05", e._sentryDebugIdIdentifier = "sentry-dbid-e5174131-62a5-4c90-96fb-e5237d1bff05")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9775], {
        7095: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return Ts
                }
            });
            var s = n(84767),
                r = n(71402),
                o = (n(23896), n(21556)),
                i = n(30386),
                a = n(18446),
                c = n(25579),
                l = n(91290),
                u = n(42934),
                d = n(25450),
                h = n(77345),
                p = n(91273),
                m = n(31563),
                f = (n(50744), n(98394)),
                y = n(79756),
                g = n(78937),
                S = n(1640),
                k = n(21967),
                v = n(89244),
                b = n(32973),
                _ = n(57225),
                w = n(62804),
                I = n(35630),
                C = n(1416),
                E = n(25503),
                T = n(42683),
                M = n(70831),
                x = n(88550);
            const R = p.GLOBAL_OBJ,
                A = "sentryReplaySession",
                D = "Unable to send Replay",
                O = 15e4,
                L = 5e3,
                N = 2e7,
                F = 36e5;

            function B(e, t) {
                return null != e ? e : t()
            }

            function P(e) {
                let t, n = e[0],
                    s = 1;
                for (; s < e.length;) {
                    const r = e[s],
                        o = e[s + 1];
                    if (s += 2, ("optionalAccess" === r || "optionalCall" === r) && null == n) return;
                    "access" === r || "optionalAccess" === r ? (t = n, n = o(n)) : "call" !== r && "optionalCall" !== r || (n = o(((...e) => n.call(t, ...e))), t = void 0)
                }
                return n
            }
            var U;

            function z(e) {
                const t = P([e, "optionalAccess", e => e.host]);
                return Boolean(P([t, "optionalAccess", e => e.shadowRoot]) === e)
            }

            function W(e) {
                return "[object ShadowRoot]" === Object.prototype.toString.call(e)
            }

            function H(e) {
                try {
                    const n = e.rules || e.cssRules;
                    return n ? ((t = Array.from(n, j).join("")).includes(" background-clip: text;") && !t.includes(" -webkit-background-clip: text;") && (t = t.replace(/\sbackground-clip:\s*text;/g, " -webkit-background-clip: text; background-clip: text;")), t) : null
                } catch (e) {
                    return null
                }
                var t
            }

            function j(e) {
                let t;
                if (function(e) {
                        return "styleSheet" in e
                    }(e)) try {
                    t = H(e.styleSheet) || function(e) {
                        const {
                            cssText: t
                        } = e;
                        if (t.split('"').length < 3) return t;
                        const n = ["@import", `url(${JSON.stringify(e.href)})`];
                        return "" === e.layerName ? n.push("layer") : e.layerName && n.push(`layer(${e.layerName})`), e.supportsText && n.push(`supports(${e.supportsText})`), e.media.length && n.push(e.media.mediaText), n.join(" ") + ";"
                    }(e)
                } catch (e) {} else if (function(e) {
                        return "selectorText" in e
                    }(e) && e.selectorText.includes(":")) return function(e) {
                    const t = /(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm;
                    return e.replace(t, "$1\\$2")
                }(e.cssText);
                return t || e.cssText
            }! function(e) {
                e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment"
            }(U || (U = {}));
            class $ {
                constructor() {
                    this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
                }
                getId(e) {
                    if (!e) return -1;
                    return B(P([this, "access", e => e.getMeta, "call", t => t(e), "optionalAccess", e => e.id]), (() => -1))
                }
                getNode(e) {
                    return this.idNodeMap.get(e) || null
                }
                getIds() {
                    return Array.from(this.idNodeMap.keys())
                }
                getMeta(e) {
                    return this.nodeMetaMap.get(e) || null
                }
                removeNodeFromMap(e) {
                    const t = this.getId(e);
                    this.idNodeMap.delete(t), e.childNodes && e.childNodes.forEach((e => this.removeNodeFromMap(e)))
                }
                has(e) {
                    return this.idNodeMap.has(e)
                }
                hasNode(e) {
                    return this.nodeMetaMap.has(e)
                }
                add(e, t) {
                    const n = t.id;
                    this.idNodeMap.set(n, e), this.nodeMetaMap.set(e, t)
                }
                replace(e, t) {
                    const n = this.getNode(e);
                    if (n) {
                        const e = this.nodeMetaMap.get(n);
                        e && this.nodeMetaMap.set(t, e)
                    }
                    this.idNodeMap.set(e, t)
                }
                reset() {
                    this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
                }
            }

            function q({
                maskInputOptions: e,
                tagName: t,
                type: n
            }) {
                return "OPTION" === t && (t = "SELECT"), Boolean(e[t.toLowerCase()] || n && e[n] || "password" === n || "INPUT" === t && !n && e.text)
            }

            function K({
                isMasked: e,
                element: t,
                value: n,
                maskInputFn: s
            }) {
                let r = n || "";
                return e ? (s && (r = s(r, t)), "*".repeat(r.length)) : r
            }

            function V(e) {
                return e.toLowerCase()
            }

            function J(e) {
                return e.toUpperCase()
            }
            const G = "__rrweb_original__";

            function Y(e) {
                const t = e.type;
                return e.hasAttribute("data-rr-is-password") ? "password" : t ? V(t) : null
            }

            function X(e, t, n) {
                return "INPUT" !== t || "radio" !== n && "checkbox" !== n ? e.value : e.getAttribute("value") || ""
            }

            function Q(e, t) {
                let n;
                try {
                    n = new URL(e, B(t, (() => window.location.href)))
                } catch (e) {
                    return null
                }
                return B(P([n.pathname.match(/\.([0-9a-z]+)(?:$)/i), "optionalAccess", e => e[1]]), (() => null))
            }
            const Z = {};

            function ee(e) {
                const t = Z[e];
                if (t) return t;
                const n = window.document;
                let s = window[e];
                if (n && "function" == typeof n.createElement) try {
                    const t = n.createElement("iframe");
                    t.hidden = !0, n.head.appendChild(t);
                    const r = t.contentWindow;
                    r && r[e] && (s = r[e]), n.head.removeChild(t)
                } catch (e) {}
                return Z[e] = s.bind(window)
            }

            function te(...e) {
                return ee("setTimeout")(...e)
            }

            function ne(...e) {
                return ee("clearTimeout")(...e)
            }
            let se = 1;
            const re = new RegExp("[^a-z0-9-_:]");

            function oe() {
                return se++
            }
            let ie, ae;
            const ce = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
                le = /^(?:[a-z+]+:)?\/\//i,
                ue = /^www\..*/i,
                de = /^(data:)([^,]*),(.*)/i;

            function he(e, t) {
                return (e || "").replace(ce, ((e, n, s, r, o, i) => {
                    const a = s || o || i,
                        c = n || r || "";
                    if (!a) return e;
                    if (le.test(a) || ue.test(a)) return `url(${c}${a}${c})`;
                    if (de.test(a)) return `url(${c}${a}${c})`;
                    if ("/" === a[0]) return `url(${c}${function(e){let t="";return t=e.indexOf("//")>-1?e.split("/").slice(0,3).join("/"):e.split("/")[0],t=t.split("?")[0],t}(t)+a}${c})`;
                    const l = t.split("/"),
                        u = a.split("/");
                    l.pop();
                    for (const e of u) "." !== e && (".." === e ? l.pop() : l.push(e));
                    return `url(${c}${l.join("/")}${c})`
                }))
            }
            const pe = /^[^ \t\n\r\u000c]+/,
                me = /^[, \t\n\r\u000c]+/;
            const fe = new WeakMap;

            function ye(e, t) {
                return t && "" !== t.trim() ? Se(e, t) : t
            }

            function ge(e) {
                return Boolean("svg" === e.tagName || e.ownerSVGElement)
            }

            function Se(e, t) {
                let n = fe.get(e);
                if (n || (n = e.createElement("a"), fe.set(e, n)), t) {
                    if (t.startsWith("blob:") || t.startsWith("data:")) return t
                } else t = "";
                return n.setAttribute("href", t), n.href
            }

            function ke(e, t, n, s, r, o) {
                return s ? "src" === n || "href" === n && ("use" !== t || "#" !== s[0]) || "xlink:href" === n && "#" !== s[0] ? ye(e, s) : "background" !== n || "table" !== t && "td" !== t && "th" !== t ? "srcset" === n ? function(e, t) {
                    if ("" === t.trim()) return t;
                    let n = 0;

                    function s(e) {
                        let s;
                        const r = e.exec(t.substring(n));
                        return r ? (s = r[0], n += s.length, s) : ""
                    }
                    const r = [];
                    for (; s(me), !(n >= t.length);) {
                        let o = s(pe);
                        if ("," === o.slice(-1)) o = ye(e, o.substring(0, o.length - 1)), r.push(o);
                        else {
                            let s = "";
                            o = ye(e, o);
                            let i = !1;
                            for (;;) {
                                const e = t.charAt(n);
                                if ("" === e) {
                                    r.push((o + s).trim());
                                    break
                                }
                                if (i) ")" === e && (i = !1);
                                else {
                                    if ("," === e) {
                                        n += 1, r.push((o + s).trim());
                                        break
                                    }
                                    "(" === e && (i = !0)
                                }
                                s += e, n += 1
                            }
                        }
                    }
                    return r.join(", ")
                }(e, s) : "style" === n ? he(s, Se(e)) : "object" === t && "data" === n ? ye(e, s) : "function" == typeof o ? o(n, s, r) : s : ye(e, s) : s
            }

            function ve(e, t, n) {
                return ("video" === e || "audio" === e) && "autoplay" === t
            }

            function be(e, t, n = 1 / 0, s = 0) {
                return e ? e.nodeType !== e.ELEMENT_NODE || s > n ? -1 : t(e) ? s : be(e.parentNode, t, n, s + 1) : -1
            }

            function _e(e, t) {
                return n => {
                    const s = n;
                    if (null === s) return !1;
                    try {
                        if (e)
                            if ("string" == typeof e) {
                                if (s.matches(`.${e}`)) return !0
                            } else if (function(e, t) {
                                for (let n = e.classList.length; n--;) {
                                    const s = e.classList[n];
                                    if (t.test(s)) return !0
                                }
                                return !1
                            }(s, e)) return !0;
                        return !(!t || !s.matches(t))
                    } catch (e) {
                        return !1
                    }
                }
            }

            function we(e, t, n, s, r, o) {
                try {
                    const i = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
                    if (null === i) return !1;
                    if ("INPUT" === i.tagName) {
                        const e = i.getAttribute("autocomplete");
                        if (["current-password", "new-password", "cc-number", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-csc"].includes(e)) return !0
                    }
                    let a = -1,
                        c = -1;
                    if (o) {
                        if (c = be(i, _e(s, r)), c < 0) return !0;
                        a = be(i, _e(t, n), c >= 0 ? c : 1 / 0)
                    } else {
                        if (a = be(i, _e(t, n)), a < 0) return !1;
                        c = be(i, _e(s, r), a >= 0 ? a : 1 / 0)
                    }
                    return a >= 0 ? !(c >= 0) || a <= c : !(c >= 0) && !!o
                } catch (e) {}
                return !!o
            }

            function Ie(e, t) {
                const {
                    doc: n,
                    mirror: s,
                    blockClass: r,
                    blockSelector: o,
                    unblockSelector: i,
                    maskAllText: a,
                    maskAttributeFn: c,
                    maskTextClass: l,
                    unmaskTextClass: u,
                    maskTextSelector: d,
                    unmaskTextSelector: h,
                    inlineStylesheet: p,
                    maskInputOptions: m = {},
                    maskTextFn: f,
                    maskInputFn: y,
                    dataURLOptions: g = {},
                    inlineImages: S,
                    recordCanvas: k,
                    keepIframeSrcFn: v,
                    newlyAddedElement: b = !1
                } = t, _ = function(e, t) {
                    if (!t.hasNode(e)) return;
                    const n = t.getId(e);
                    return 1 === n ? void 0 : n
                }(n, s);
                switch (e.nodeType) {
                    case e.DOCUMENT_NODE:
                        return "CSS1Compat" !== e.compatMode ? {
                            type: U.Document,
                            childNodes: [],
                            compatMode: e.compatMode
                        } : {
                            type: U.Document,
                            childNodes: []
                        };
                    case e.DOCUMENT_TYPE_NODE:
                        return {
                            type: U.DocumentType,
                            name: e.name,
                            publicId: e.publicId,
                            systemId: e.systemId,
                            rootId: _
                        };
                    case e.ELEMENT_NODE:
                        return function(e, t) {
                            const {
                                doc: n,
                                blockClass: s,
                                blockSelector: r,
                                unblockSelector: o,
                                inlineStylesheet: i,
                                maskInputOptions: a = {},
                                maskAttributeFn: c,
                                maskInputFn: l,
                                dataURLOptions: u = {},
                                inlineImages: d,
                                recordCanvas: h,
                                keepIframeSrcFn: p,
                                newlyAddedElement: m = !1,
                                rootId: f,
                                maskAllText: y,
                                maskTextClass: g,
                                unmaskTextClass: S,
                                maskTextSelector: k,
                                unmaskTextSelector: v
                            } = t, b = function(e, t, n, s) {
                                try {
                                    if (s && e.matches(s)) return !1;
                                    if ("string" == typeof t) {
                                        if (e.classList.contains(t)) return !0
                                    } else
                                        for (let n = e.classList.length; n--;) {
                                            const s = e.classList[n];
                                            if (t.test(s)) return !0
                                        }
                                    if (n) return e.matches(n)
                                } catch (e) {}
                                return !1
                            }(e, s, r, o), _ = function(e) {
                                if (e instanceof HTMLFormElement) return "form";
                                const t = V(e.tagName);
                                return re.test(t) ? "div" : t
                            }(e);
                            let w = {};
                            const I = e.attributes.length;
                            for (let t = 0; t < I; t++) {
                                const s = e.attributes[t];
                                s.name && !ve(_, s.name, s.value) && (w[s.name] = ke(n, _, V(s.name), s.value, e, c))
                            }
                            if ("link" === _ && i) {
                                const t = Array.from(n.styleSheets).find((t => t.href === e.href));
                                let s = null;
                                t && (s = H(t)), s && (delete w.rel, delete w.href, w._cssText = he(s, t.href))
                            }
                            if ("style" === _ && e.sheet && !(e.innerText || e.textContent || "").trim().length) {
                                const t = H(e.sheet);
                                t && (w._cssText = he(t, Se(n)))
                            }
                            if ("input" === _ || "textarea" === _ || "select" === _ || "option" === _) {
                                const t = e,
                                    n = Y(t),
                                    s = X(t, J(_), n),
                                    r = t.checked;
                                if ("submit" !== n && "button" !== n && s) {
                                    const e = we(t, g, k, S, v, q({
                                        type: n,
                                        tagName: J(_),
                                        maskInputOptions: a
                                    }));
                                    w.value = K({
                                        isMasked: e,
                                        element: t,
                                        value: s,
                                        maskInputFn: l
                                    })
                                }
                                r && (w.checked = r)
                            }
                            "option" === _ && (e.selected && !a.select ? w.selected = !0 : delete w.selected);
                            if ("canvas" === _ && h)
                                if ("2d" === e.__context)(function(e) {
                                    const t = e.getContext("2d");
                                    if (!t) return !0;
                                    for (let n = 0; n < e.width; n += 50)
                                        for (let s = 0; s < e.height; s += 50) {
                                            const r = t.getImageData,
                                                o = G in r ? r[G] : r;
                                            if (new Uint32Array(o.call(t, n, s, Math.min(50, e.width - n), Math.min(50, e.height - s)).data.buffer).some((e => 0 !== e))) return !1
                                        }
                                    return !0
                                })(e) || (w.rr_dataURL = e.toDataURL(u.type, u.quality));
                                else if (!("__context" in e)) {
                                const t = e.toDataURL(u.type, u.quality),
                                    s = n.createElement("canvas");
                                s.width = e.width, s.height = e.height;
                                t !== s.toDataURL(u.type, u.quality) && (w.rr_dataURL = t)
                            }
                            if ("img" === _ && d) {
                                ie || (ie = n.createElement("canvas"), ae = ie.getContext("2d"));
                                const t = e,
                                    s = (t.currentSrc || t.getAttribute("src"), t.crossOrigin),
                                    r = () => {
                                        t.removeEventListener("load", r);
                                        try {
                                            ie.width = t.naturalWidth, ie.height = t.naturalHeight, ae.drawImage(t, 0, 0), w.rr_dataURL = ie.toDataURL(u.type, u.quality)
                                        } catch (e) {
                                            if ("anonymous" !== t.crossOrigin) return t.crossOrigin = "anonymous", void(t.complete && 0 !== t.naturalWidth ? r() : t.addEventListener("load", r))
                                        }
                                        "anonymous" === t.crossOrigin && (s ? w.crossOrigin = s : t.removeAttribute("crossorigin"))
                                    };
                                t.complete && 0 !== t.naturalWidth ? r() : t.addEventListener("load", r)
                            }
                            "audio" !== _ && "video" !== _ || (w.rr_mediaState = e.paused ? "paused" : "played", w.rr_mediaCurrentTime = e.currentTime);
                            m || (e.scrollLeft && (w.rr_scrollLeft = e.scrollLeft), e.scrollTop && (w.rr_scrollTop = e.scrollTop));
                            if (b) {
                                const {
                                    width: t,
                                    height: n
                                } = e.getBoundingClientRect();
                                w = {
                                    class: w.class,
                                    rr_width: `${t}px`,
                                    rr_height: `${n}px`
                                }
                            }
                            "iframe" !== _ || p(w.src) || (b || e.contentDocument || (w.rr_src = w.src), delete w.src);
                            let C;
                            try {
                                customElements.get(_) && (C = !0)
                            } catch (e) {}
                            return {
                                type: U.Element,
                                tagName: _,
                                attributes: w,
                                childNodes: [],
                                isSVG: ge(e) || void 0,
                                needBlock: b,
                                rootId: f,
                                isCustom: C
                            }
                        }(e, {
                            doc: n,
                            blockClass: r,
                            blockSelector: o,
                            unblockSelector: i,
                            inlineStylesheet: p,
                            maskAttributeFn: c,
                            maskInputOptions: m,
                            maskInputFn: y,
                            dataURLOptions: g,
                            inlineImages: S,
                            recordCanvas: k,
                            keepIframeSrcFn: v,
                            newlyAddedElement: b,
                            rootId: _,
                            maskAllText: a,
                            maskTextClass: l,
                            unmaskTextClass: u,
                            maskTextSelector: d,
                            unmaskTextSelector: h
                        });
                    case e.TEXT_NODE:
                        return function(e, t) {
                            const {
                                maskAllText: n,
                                maskTextClass: s,
                                unmaskTextClass: r,
                                maskTextSelector: o,
                                unmaskTextSelector: i,
                                maskTextFn: a,
                                maskInputOptions: c,
                                maskInputFn: l,
                                rootId: u
                            } = t, d = e.parentNode && e.parentNode.tagName;
                            let h = e.textContent;
                            const p = "STYLE" === d || void 0,
                                m = "SCRIPT" === d || void 0,
                                f = "TEXTAREA" === d || void 0;
                            if (p && h) {
                                try {
                                    e.nextSibling || e.previousSibling || P([e, "access", e => e.parentNode, "access", e => e.sheet, "optionalAccess", e => e.cssRules]) && (h = H(e.parentNode.sheet))
                                } catch (e) {}
                                h = he(h, Se(t.doc))
                            }
                            m && (h = "SCRIPT_PLACEHOLDER");
                            const y = we(e, s, o, r, i, n);
                            p || m || f || !h || !y || (h = a ? a(h, e.parentElement) : h.replace(/[\S]/g, "*"));
                            f && h && (c.textarea || y) && (h = l ? l(h, e.parentNode) : h.replace(/[\S]/g, "*"));
                            if ("OPTION" === d && h) {
                                h = K({
                                    isMasked: we(e, s, o, r, i, q({
                                        type: null,
                                        tagName: d,
                                        maskInputOptions: c
                                    })),
                                    element: e,
                                    value: h,
                                    maskInputFn: l
                                })
                            }
                            return {
                                type: U.Text,
                                textContent: h || "",
                                isStyle: p,
                                rootId: u
                            }
                        }(e, {
                            doc: n,
                            maskAllText: a,
                            maskTextClass: l,
                            unmaskTextClass: u,
                            maskTextSelector: d,
                            unmaskTextSelector: h,
                            maskTextFn: f,
                            maskInputOptions: m,
                            maskInputFn: y,
                            rootId: _
                        });
                    case e.CDATA_SECTION_NODE:
                        return {
                            type: U.CDATA,
                            textContent: "",
                            rootId: _
                        };
                    case e.COMMENT_NODE:
                        return {
                            type: U.Comment,
                            textContent: e.textContent || "",
                            rootId: _
                        };
                    default:
                        return !1
                }
            }

            function Ce(e) {
                return null == e ? "" : e.toLowerCase()
            }

            function Ee(e, t) {
                const {
                    doc: n,
                    mirror: s,
                    blockClass: r,
                    blockSelector: o,
                    unblockSelector: i,
                    maskAllText: a,
                    maskTextClass: c,
                    unmaskTextClass: l,
                    maskTextSelector: u,
                    unmaskTextSelector: d,
                    skipChild: h = !1,
                    inlineStylesheet: p = !0,
                    maskInputOptions: m = {},
                    maskAttributeFn: f,
                    maskTextFn: y,
                    maskInputFn: g,
                    slimDOMOptions: S,
                    dataURLOptions: k = {},
                    inlineImages: v = !1,
                    recordCanvas: b = !1,
                    onSerialize: _,
                    onIframeLoad: w,
                    iframeLoadTimeout: I = 5e3,
                    onStylesheetLoad: C,
                    stylesheetLoadTimeout: E = 5e3,
                    keepIframeSrcFn: T = () => !1,
                    newlyAddedElement: M = !1
                } = t;
                let {
                    preserveWhiteSpace: x = !0
                } = t;
                const R = Ie(e, {
                    doc: n,
                    mirror: s,
                    blockClass: r,
                    blockSelector: o,
                    maskAllText: a,
                    unblockSelector: i,
                    maskTextClass: c,
                    unmaskTextClass: l,
                    maskTextSelector: u,
                    unmaskTextSelector: d,
                    inlineStylesheet: p,
                    maskInputOptions: m,
                    maskAttributeFn: f,
                    maskTextFn: y,
                    maskInputFn: g,
                    dataURLOptions: k,
                    inlineImages: v,
                    recordCanvas: b,
                    keepIframeSrcFn: T,
                    newlyAddedElement: M
                });
                if (!R) return null;
                let A;
                A = s.hasNode(e) ? s.getId(e) : ! function(e, t) {
                    if (t.comment && e.type === U.Comment) return !0;
                    if (e.type === U.Element) {
                        if (t.script && ("script" === e.tagName || "link" === e.tagName && ("preload" === e.attributes.rel || "modulepreload" === e.attributes.rel) && "script" === e.attributes.as || "link" === e.tagName && "prefetch" === e.attributes.rel && "string" == typeof e.attributes.href && "js" === Q(e.attributes.href))) return !0;
                        if (t.headFavicon && ("link" === e.tagName && "shortcut icon" === e.attributes.rel || "meta" === e.tagName && (Ce(e.attributes.name).match(/^msapplication-tile(image|color)$/) || "application-name" === Ce(e.attributes.name) || "icon" === Ce(e.attributes.rel) || "apple-touch-icon" === Ce(e.attributes.rel) || "shortcut icon" === Ce(e.attributes.rel)))) return !0;
                        if ("meta" === e.tagName) {
                            if (t.headMetaDescKeywords && Ce(e.attributes.name).match(/^description|keywords$/)) return !0;
                            if (t.headMetaSocial && (Ce(e.attributes.property).match(/^(og|twitter|fb):/) || Ce(e.attributes.name).match(/^(og|twitter):/) || "pinterest" === Ce(e.attributes.name))) return !0;
                            if (t.headMetaRobots && ("robots" === Ce(e.attributes.name) || "googlebot" === Ce(e.attributes.name) || "bingbot" === Ce(e.attributes.name))) return !0;
                            if (t.headMetaHttpEquiv && void 0 !== e.attributes["http-equiv"]) return !0;
                            if (t.headMetaAuthorship && ("author" === Ce(e.attributes.name) || "generator" === Ce(e.attributes.name) || "framework" === Ce(e.attributes.name) || "publisher" === Ce(e.attributes.name) || "progid" === Ce(e.attributes.name) || Ce(e.attributes.property).match(/^article:/) || Ce(e.attributes.property).match(/^product:/))) return !0;
                            if (t.headMetaVerification && ("google-site-verification" === Ce(e.attributes.name) || "yandex-verification" === Ce(e.attributes.name) || "csrf-token" === Ce(e.attributes.name) || "p:domain_verify" === Ce(e.attributes.name) || "verify-v1" === Ce(e.attributes.name) || "verification" === Ce(e.attributes.name) || "shopify-checkout-api-token" === Ce(e.attributes.name))) return !0
                        }
                    }
                    return !1
                }(R, S) && (x || R.type !== U.Text || R.isStyle || R.textContent.replace(/^\s+|\s+$/gm, "").length) ? oe() : -2;
                const D = Object.assign(R, {
                    id: A
                });
                if (s.add(e, D), -2 === A) return null;
                _ && _(e);
                let O = !h;
                if (D.type === U.Element) {
                    O = O && !D.needBlock, delete D.needBlock;
                    const t = e.shadowRoot;
                    t && W(t) && (D.isShadowHost = !0)
                }
                if ((D.type === U.Document || D.type === U.Element) && O) {
                    S.headWhitespace && D.type === U.Element && "head" === D.tagName && (x = !1);
                    const t = {
                        doc: n,
                        mirror: s,
                        blockClass: r,
                        blockSelector: o,
                        maskAllText: a,
                        unblockSelector: i,
                        maskTextClass: c,
                        unmaskTextClass: l,
                        maskTextSelector: u,
                        unmaskTextSelector: d,
                        skipChild: h,
                        inlineStylesheet: p,
                        maskInputOptions: m,
                        maskAttributeFn: f,
                        maskTextFn: y,
                        maskInputFn: g,
                        slimDOMOptions: S,
                        dataURLOptions: k,
                        inlineImages: v,
                        recordCanvas: b,
                        preserveWhiteSpace: x,
                        onSerialize: _,
                        onIframeLoad: w,
                        iframeLoadTimeout: I,
                        onStylesheetLoad: C,
                        stylesheetLoadTimeout: E,
                        keepIframeSrcFn: T
                    };
                    for (const n of Array.from(e.childNodes)) {
                        const e = Ee(n, t);
                        e && D.childNodes.push(e)
                    }
                    if (function(e) {
                            return e.nodeType === e.ELEMENT_NODE
                        }(e) && e.shadowRoot)
                        for (const n of Array.from(e.shadowRoot.childNodes)) {
                            const s = Ee(n, t);
                            s && (W(e.shadowRoot) && (s.isShadow = !0), D.childNodes.push(s))
                        }
                }
                return e.parentNode && z(e.parentNode) && W(e.parentNode) && (D.isShadow = !0), D.type === U.Element && "iframe" === D.tagName && function(e, t, n) {
                    const s = e.contentWindow;
                    if (!s) return;
                    let r, o = !1;
                    try {
                        r = s.document.readyState
                    } catch (e) {
                        return
                    }
                    if ("complete" !== r) {
                        const s = te((() => {
                            o || (t(), o = !0)
                        }), n);
                        return void e.addEventListener("load", (() => {
                            ne(s), o = !0, t()
                        }))
                    }
                    const i = "about:blank";
                    if (s.location.href !== i || e.src === i || "" === e.src) return te(t, 0), e.addEventListener("load", t);
                    e.addEventListener("load", t)
                }(e, (() => {
                    const t = e.contentDocument;
                    if (t && w) {
                        const n = Ee(t, {
                            doc: t,
                            mirror: s,
                            blockClass: r,
                            blockSelector: o,
                            unblockSelector: i,
                            maskAllText: a,
                            maskTextClass: c,
                            unmaskTextClass: l,
                            maskTextSelector: u,
                            unmaskTextSelector: d,
                            skipChild: !1,
                            inlineStylesheet: p,
                            maskInputOptions: m,
                            maskAttributeFn: f,
                            maskTextFn: y,
                            maskInputFn: g,
                            slimDOMOptions: S,
                            dataURLOptions: k,
                            inlineImages: v,
                            recordCanvas: b,
                            preserveWhiteSpace: x,
                            onSerialize: _,
                            onIframeLoad: w,
                            iframeLoadTimeout: I,
                            onStylesheetLoad: C,
                            stylesheetLoadTimeout: E,
                            keepIframeSrcFn: T
                        });
                        n && w(e, n)
                    }
                }), I), D.type === U.Element && "link" === D.tagName && "string" == typeof D.attributes.rel && ("stylesheet" === D.attributes.rel || "preload" === D.attributes.rel && "string" == typeof D.attributes.href && "css" === Q(D.attributes.href)) && function(e, t, n) {
                    let s, r = !1;
                    try {
                        s = e.sheet
                    } catch (e) {
                        return
                    }
                    if (s) return;
                    const o = te((() => {
                        r || (t(), r = !0)
                    }), n);
                    e.addEventListener("load", (() => {
                        ne(o), r = !0, t()
                    }))
                }(e, (() => {
                    if (C) {
                        const t = Ee(e, {
                            doc: n,
                            mirror: s,
                            blockClass: r,
                            blockSelector: o,
                            unblockSelector: i,
                            maskAllText: a,
                            maskTextClass: c,
                            unmaskTextClass: l,
                            maskTextSelector: u,
                            unmaskTextSelector: d,
                            skipChild: !1,
                            inlineStylesheet: p,
                            maskInputOptions: m,
                            maskAttributeFn: f,
                            maskTextFn: y,
                            maskInputFn: g,
                            slimDOMOptions: S,
                            dataURLOptions: k,
                            inlineImages: v,
                            recordCanvas: b,
                            preserveWhiteSpace: x,
                            onSerialize: _,
                            onIframeLoad: w,
                            iframeLoadTimeout: I,
                            onStylesheetLoad: C,
                            stylesheetLoadTimeout: E,
                            keepIframeSrcFn: T
                        });
                        t && C(e, t)
                    }
                }), E), D
            }

            function Te(e) {
                let t, n = e[0],
                    s = 1;
                for (; s < e.length;) {
                    const r = e[s],
                        o = e[s + 1];
                    if (s += 2, ("optionalAccess" === r || "optionalCall" === r) && null == n) return;
                    "access" === r || "optionalAccess" === r ? (t = n, n = o(n)) : "call" !== r && "optionalCall" !== r || (n = o(((...e) => n.call(t, ...e))), t = void 0)
                }
                return n
            }

            function Me(e, t, n = document) {
                const s = {
                    capture: !0,
                    passive: !0
                };
                return n.addEventListener(e, t, s), () => n.removeEventListener(e, t, s)
            }
            let xe = {
                map: {},
                getId() {
                    return -1
                },
                getNode() {
                    return null
                },
                removeNodeFromMap() {},
                has() {
                    return !1
                },
                reset() {}
            };

            function Re(e, t, n = {}) {
                let s = null,
                    r = 0;
                return function(...o) {
                    const i = Date.now();
                    r || !1 !== n.leading || (r = i);
                    const a = t - (i - r),
                        c = this;
                    a <= 0 || a > t ? (s && (! function(...e) {
                        Ye("clearTimeout")(...e)
                    }(s), s = null), r = i, e.apply(c, o)) : s || !1 === n.trailing || (s = Xe((() => {
                        r = !1 === n.leading ? 0 : Date.now(), s = null, e.apply(c, o)
                    }), a))
                }
            }

            function Ae(e, t, n, s, r = window) {
                const o = r.Object.getOwnPropertyDescriptor(e, t);
                return r.Object.defineProperty(e, t, s ? n : {
                    set(e) {
                        Xe((() => {
                            n.set.call(this, e)
                        }), 0), o && o.set && o.set.call(this, e)
                    }
                }), () => Ae(e, t, o || {}, !0)
            }

            function De(e, t, n) {
                try {
                    if (!(t in e)) return () => {};
                    const s = e[t],
                        r = n(s);
                    return "function" == typeof r && (r.prototype = r.prototype || {}, Object.defineProperties(r, {
                        __rrweb_original__: {
                            enumerable: !1,
                            value: s
                        }
                    })), e[t] = r, () => {
                        e[t] = s
                    }
                } catch (e) {
                    return () => {}
                }
            }
            "undefined" != typeof window && window.Proxy && window.Reflect && (xe = new Proxy(xe, {
                get(e, t, n) {
                    return Reflect.get(e, t, n)
                }
            }));
            let Oe = Date.now;

            function Le(e) {
                const t = e.document;
                return {
                    left: t.scrollingElement ? t.scrollingElement.scrollLeft : void 0 !== e.pageXOffset ? e.pageXOffset : Te([t, "optionalAccess", e => e.documentElement, "access", e => e.scrollLeft]) || Te([t, "optionalAccess", e => e.body, "optionalAccess", e => e.parentElement, "optionalAccess", e => e.scrollLeft]) || Te([t, "optionalAccess", e => e.body, "optionalAccess", e => e.scrollLeft]) || 0,
                    top: t.scrollingElement ? t.scrollingElement.scrollTop : void 0 !== e.pageYOffset ? e.pageYOffset : Te([t, "optionalAccess", e => e.documentElement, "access", e => e.scrollTop]) || Te([t, "optionalAccess", e => e.body, "optionalAccess", e => e.parentElement, "optionalAccess", e => e.scrollTop]) || Te([t, "optionalAccess", e => e.body, "optionalAccess", e => e.scrollTop]) || 0
                }
            }

            function Ne() {
                return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight
            }

            function Fe() {
                return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth
            }

            function Be(e) {
                if (!e) return null;
                return e.nodeType === e.ELEMENT_NODE ? e : e.parentElement
            }

            function Pe(e, t, n, s, r) {
                if (!e) return !1;
                const o = Be(e);
                if (!o) return !1;
                const i = _e(t, n);
                if (!r) {
                    const e = s && o.matches(s);
                    return i(o) && !e
                }
                const a = be(o, i);
                let c = -1;
                return !(a < 0) && (s && (c = be(o, _e(null, s))), a > -1 && c < 0 || a < c)
            }

            function Ue(e, t) {
                return -2 === t.getId(e)
            }

            function ze(e, t) {
                if (z(e)) return !1;
                const n = t.getId(e);
                return !t.has(n) || (!e.parentNode || e.parentNode.nodeType !== e.DOCUMENT_NODE) && (!e.parentNode || ze(e.parentNode, t))
            }

            function We(e) {
                return Boolean(e.changedTouches)
            }

            function He(e, t) {
                return Boolean("IFRAME" === e.nodeName && t.getMeta(e))
            }

            function je(e, t) {
                return Boolean("LINK" === e.nodeName && e.nodeType === e.ELEMENT_NODE && e.getAttribute && "stylesheet" === e.getAttribute("rel") && t.getMeta(e))
            }

            function $e(e) {
                return Boolean(Te([e, "optionalAccess", e => e.shadowRoot]))
            }
            /[1-9][0-9]{12}/.test(Date.now().toString()) || (Oe = () => (new Date).getTime());
            class qe {
                constructor() {
                    this.id = 1, this.styleIDMap = new WeakMap, this.idStyleMap = new Map
                }
                getId(e) {
                    return (0, s.h)(this.styleIDMap.get(e), (() => -1))
                }
                has(e) {
                    return this.styleIDMap.has(e)
                }
                add(e, t) {
                    if (this.has(e)) return this.getId(e);
                    let n;
                    return n = void 0 === t ? this.id++ : t, this.styleIDMap.set(e, n), this.idStyleMap.set(n, e), n
                }
                getStyle(e) {
                    return this.idStyleMap.get(e) || null
                }
                reset() {
                    this.styleIDMap = new WeakMap, this.idStyleMap = new Map, this.id = 1
                }
                generateId() {
                    return this.id++
                }
            }

            function Ke(e) {
                let t = null;
                return Te([e, "access", e => e.getRootNode, "optionalCall", e => e(), "optionalAccess", e => e.nodeType]) === Node.DOCUMENT_FRAGMENT_NODE && e.getRootNode().host && (t = e.getRootNode().host), t
            }

            function Ve(e) {
                const t = e.ownerDocument;
                if (!t) return !1;
                const n = function(e) {
                    let t, n = e;
                    for (; t = Ke(n);) n = t;
                    return n
                }(e);
                return t.contains(n)
            }

            function Je(e) {
                const t = e.ownerDocument;
                return !!t && (t.contains(e) || Ve(e))
            }
            const Ge = {};

            function Ye(e) {
                const t = Ge[e];
                if (t) return t;
                const n = window.document;
                let s = window[e];
                if (n && "function" == typeof n.createElement) try {
                    const t = n.createElement("iframe");
                    t.hidden = !0, n.head.appendChild(t);
                    const r = t.contentWindow;
                    r && r[e] && (s = r[e]), n.head.removeChild(t)
                } catch (e) {}
                return Ge[e] = s.bind(window)
            }

            function Xe(...e) {
                return Ye("setTimeout")(...e)
            }
            var Qe = (e => (e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e))(Qe || {}),
                Ze = (e => (e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e[e.CustomElement = 16] = "CustomElement", e))(Ze || {}),
                et = (e => (e[e.MouseUp = 0] = "MouseUp", e[e.MouseDown = 1] = "MouseDown", e[e.Click = 2] = "Click", e[e.ContextMenu = 3] = "ContextMenu", e[e.DblClick = 4] = "DblClick", e[e.Focus = 5] = "Focus", e[e.Blur = 6] = "Blur", e[e.TouchStart = 7] = "TouchStart", e[e.TouchMove_Departed = 8] = "TouchMove_Departed", e[e.TouchEnd = 9] = "TouchEnd", e[e.TouchCancel = 10] = "TouchCancel", e))(et || {}),
                tt = (e => (e[e.Mouse = 0] = "Mouse", e[e.Pen = 1] = "Pen", e[e.Touch = 2] = "Touch", e))(tt || {});

            function nt(e) {
                let t, n = e[0],
                    s = 1;
                for (; s < e.length;) {
                    const r = e[s],
                        o = e[s + 1];
                    if (s += 2, ("optionalAccess" === r || "optionalCall" === r) && null == n) return;
                    "access" === r || "optionalAccess" === r ? (t = n, n = o(n)) : "call" !== r && "optionalCall" !== r || (n = o(((...e) => n.call(t, ...e))), t = void 0)
                }
                return n
            }

            function st(e) {
                return "__ln" in e
            }
            class rt {
                constructor() {
                    this.length = 0, this.head = null, this.tail = null
                }
                get(e) {
                    if (e >= this.length) throw new Error("Position outside of list range");
                    let t = this.head;
                    for (let n = 0; n < e; n++) t = nt([t, "optionalAccess", e => e.next]) || null;
                    return t
                }
                addNode(e) {
                    const t = {
                        value: e,
                        previous: null,
                        next: null
                    };
                    if (e.__ln = t, e.previousSibling && st(e.previousSibling)) {
                        const n = e.previousSibling.__ln.next;
                        t.next = n, t.previous = e.previousSibling.__ln, e.previousSibling.__ln.next = t, n && (n.previous = t)
                    } else if (e.nextSibling && st(e.nextSibling) && e.nextSibling.__ln.previous) {
                        const n = e.nextSibling.__ln.previous;
                        t.previous = n, t.next = e.nextSibling.__ln, e.nextSibling.__ln.previous = t, n && (n.next = t)
                    } else this.head && (this.head.previous = t), t.next = this.head, this.head = t;
                    null === t.next && (this.tail = t), this.length++
                }
                removeNode(e) {
                    const t = e.__ln;
                    this.head && (t.previous ? (t.previous.next = t.next, t.next ? t.next.previous = t.previous : this.tail = t.previous) : (this.head = t.next, this.head ? this.head.previous = null : this.tail = null), e.__ln && delete e.__ln, this.length--)
                }
            }
            const ot = (e, t) => `${e}@${t}`;
            class it {
                constructor() {
                    this.frozen = !1, this.locked = !1, this.texts = [], this.attributes = [], this.attributeMap = new WeakMap, this.removes = [], this.mapRemoves = [], this.movedMap = {}, this.addedSet = new Set, this.movedSet = new Set, this.droppedSet = new Set, this.processMutations = e => {
                        e.forEach(this.processMutation), this.emit()
                    }, this.emit = () => {
                        if (this.frozen || this.locked) return;
                        const e = [],
                            t = new Set,
                            n = new rt,
                            s = e => {
                                let t = e,
                                    n = -2;
                                for (; - 2 === n;) t = t && t.nextSibling, n = t && this.mirror.getId(t);
                                return n
                            },
                            r = r => {
                                if (!r.parentNode || !Je(r)) return;
                                const o = z(r.parentNode) ? this.mirror.getId(Ke(r)) : this.mirror.getId(r.parentNode),
                                    i = s(r);
                                if (-1 === o || -1 === i) return n.addNode(r);
                                const a = Ee(r, {
                                    doc: this.doc,
                                    mirror: this.mirror,
                                    blockClass: this.blockClass,
                                    blockSelector: this.blockSelector,
                                    maskAllText: this.maskAllText,
                                    unblockSelector: this.unblockSelector,
                                    maskTextClass: this.maskTextClass,
                                    unmaskTextClass: this.unmaskTextClass,
                                    maskTextSelector: this.maskTextSelector,
                                    unmaskTextSelector: this.unmaskTextSelector,
                                    skipChild: !0,
                                    newlyAddedElement: !0,
                                    inlineStylesheet: this.inlineStylesheet,
                                    maskInputOptions: this.maskInputOptions,
                                    maskAttributeFn: this.maskAttributeFn,
                                    maskTextFn: this.maskTextFn,
                                    maskInputFn: this.maskInputFn,
                                    slimDOMOptions: this.slimDOMOptions,
                                    dataURLOptions: this.dataURLOptions,
                                    recordCanvas: this.recordCanvas,
                                    inlineImages: this.inlineImages,
                                    onSerialize: e => {
                                        He(e, this.mirror) && !Pe(e, this.blockClass, this.blockSelector, this.unblockSelector, !1) && this.iframeManager.addIframe(e), je(e, this.mirror) && this.stylesheetManager.trackLinkElement(e), $e(r) && this.shadowDomManager.addShadowRoot(r.shadowRoot, this.doc)
                                    },
                                    onIframeLoad: (e, t) => {
                                        Pe(e, this.blockClass, this.blockSelector, this.unblockSelector, !1) || (this.iframeManager.attachIframe(e, t), e.contentWindow && this.canvasManager.addWindow(e.contentWindow), this.shadowDomManager.observeAttachShadow(e))
                                    },
                                    onStylesheetLoad: (e, t) => {
                                        this.stylesheetManager.attachLinkElement(e, t)
                                    }
                                });
                                a && (e.push({
                                    parentId: o,
                                    nextId: i,
                                    node: a
                                }), t.add(a.id))
                            };
                        for (; this.mapRemoves.length;) this.mirror.removeNodeFromMap(this.mapRemoves.shift());
                        for (const e of this.movedSet) ct(this.removes, e, this.mirror) && !this.movedSet.has(e.parentNode) || r(e);
                        for (const e of this.addedSet) lt(this.droppedSet, e) || ct(this.removes, e, this.mirror) ? lt(this.movedSet, e) ? r(e) : this.droppedSet.add(e) : r(e);
                        let o = null;
                        for (; n.length;) {
                            let e = null;
                            if (o) {
                                const t = this.mirror.getId(o.value.parentNode),
                                    n = s(o.value); - 1 !== t && -1 !== n && (e = o)
                            }
                            if (!e) {
                                let t = n.tail;
                                for (; t;) {
                                    const n = t;
                                    if (t = t.previous, n) {
                                        const t = this.mirror.getId(n.value.parentNode);
                                        if (-1 === s(n.value)) continue;
                                        if (-1 !== t) {
                                            e = n;
                                            break
                                        } {
                                            const t = n.value;
                                            if (t.parentNode && t.parentNode.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                                                const s = t.parentNode.host;
                                                if (-1 !== this.mirror.getId(s)) {
                                                    e = n;
                                                    break
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (!e) {
                                for (; n.head;) n.removeNode(n.head.value);
                                break
                            }
                            o = e.previous, n.removeNode(e.value), r(e.value)
                        }
                        const i = {
                            texts: this.texts.map((e => ({
                                id: this.mirror.getId(e.node),
                                value: e.value
                            }))).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                            attributes: this.attributes.map((e => {
                                const {
                                    attributes: t
                                } = e;
                                if ("string" == typeof t.style) {
                                    const n = JSON.stringify(e.styleDiff),
                                        s = JSON.stringify(e._unchangedStyles);
                                    n.length < t.style.length && (n + s).split("var(").length === t.style.split("var(").length && (t.style = e.styleDiff)
                                }
                                return {
                                    id: this.mirror.getId(e.node),
                                    attributes: t
                                }
                            })).filter((e => !t.has(e.id))).filter((e => this.mirror.has(e.id))),
                            removes: this.removes,
                            adds: e
                        };
                        (i.texts.length || i.attributes.length || i.removes.length || i.adds.length) && (this.texts = [], this.attributes = [], this.attributeMap = new WeakMap, this.removes = [], this.addedSet = new Set, this.movedSet = new Set, this.droppedSet = new Set, this.movedMap = {}, this.mutationCb(i))
                    }, this.processMutation = e => {
                        if (!Ue(e.target, this.mirror)) switch (e.type) {
                            case "characterData":
                                {
                                    const t = e.target.textContent;Pe(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || t === e.oldValue || this.texts.push({
                                        value: we(e.target, this.maskTextClass, this.maskTextSelector, this.unmaskTextClass, this.unmaskTextSelector, this.maskAllText) && t ? this.maskTextFn ? this.maskTextFn(t, Be(e.target)) : t.replace(/[\S]/g, "*") : t,
                                        node: e.target
                                    });
                                    break
                                }
                            case "attributes":
                                {
                                    const t = e.target;
                                    let n = e.attributeName,
                                        s = e.target.getAttribute(n);
                                    if ("value" === n) {
                                        const n = Y(t),
                                            r = t.tagName;
                                        s = X(t, r, n);
                                        const o = q({
                                            maskInputOptions: this.maskInputOptions,
                                            tagName: r,
                                            type: n
                                        });
                                        s = K({
                                            isMasked: we(e.target, this.maskTextClass, this.maskTextSelector, this.unmaskTextClass, this.unmaskTextSelector, o),
                                            element: t,
                                            value: s,
                                            maskInputFn: this.maskInputFn
                                        })
                                    }
                                    if (Pe(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || s === e.oldValue) return;
                                    let r = this.attributeMap.get(e.target);
                                    if ("IFRAME" === t.tagName && "src" === n && !this.keepIframeSrcFn(s)) {
                                        if (t.contentDocument) return;
                                        n = "rr_src"
                                    }
                                    if (r || (r = {
                                            node: e.target,
                                            attributes: {},
                                            styleDiff: {},
                                            _unchangedStyles: {}
                                        }, this.attributes.push(r), this.attributeMap.set(e.target, r)), "type" === n && "INPUT" === t.tagName && "password" === (e.oldValue || "").toLowerCase() && t.setAttribute("data-rr-is-password", "true"), !ve(t.tagName, n) && (r.attributes[n] = ke(this.doc, V(t.tagName), V(n), s, t, this.maskAttributeFn), "style" === n)) {
                                        if (!this.unattachedDoc) try {
                                            this.unattachedDoc = document.implementation.createHTMLDocument()
                                        } catch (e) {
                                            this.unattachedDoc = this.doc
                                        }
                                        const n = this.unattachedDoc.createElement("span");
                                        e.oldValue && n.setAttribute("style", e.oldValue);
                                        for (const e of Array.from(t.style)) {
                                            const s = t.style.getPropertyValue(e),
                                                o = t.style.getPropertyPriority(e);
                                            s !== n.style.getPropertyValue(e) || o !== n.style.getPropertyPriority(e) ? r.styleDiff[e] = "" === o ? s : [s, o] : r._unchangedStyles[e] = [s, o]
                                        }
                                        for (const e of Array.from(n.style)) "" === t.style.getPropertyValue(e) && (r.styleDiff[e] = !1)
                                    }
                                    break
                                }
                            case "childList":
                                if (Pe(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !0)) return;
                                e.addedNodes.forEach((t => this.genAdds(t, e.target))), e.removedNodes.forEach((t => {
                                    const n = this.mirror.getId(t),
                                        s = z(e.target) ? this.mirror.getId(e.target.host) : this.mirror.getId(e.target);
                                    Pe(e.target, this.blockClass, this.blockSelector, this.unblockSelector, !1) || Ue(t, this.mirror) || ! function(e, t) {
                                        return -1 !== t.getId(e)
                                    }(t, this.mirror) || (this.addedSet.has(t) ? (at(this.addedSet, t), this.droppedSet.add(t)) : this.addedSet.has(e.target) && -1 === n || ze(e.target, this.mirror) || (this.movedSet.has(t) && this.movedMap[ot(n, s)] ? at(this.movedSet, t) : this.removes.push({
                                        parentId: s,
                                        id: n,
                                        isShadow: !(!z(e.target) || !W(e.target)) || void 0
                                    })), this.mapRemoves.push(t))
                                }))
                        }
                    }, this.genAdds = (e, t) => {
                        if (!this.processedNodeManager.inOtherBuffer(e, this) && !this.addedSet.has(e) && !this.movedSet.has(e)) {
                            if (this.mirror.hasNode(e)) {
                                if (Ue(e, this.mirror)) return;
                                this.movedSet.add(e);
                                let n = null;
                                t && this.mirror.hasNode(t) && (n = this.mirror.getId(t)), n && -1 !== n && (this.movedMap[ot(this.mirror.getId(e), n)] = !0)
                            } else this.addedSet.add(e), this.droppedSet.delete(e);
                            Pe(e, this.blockClass, this.blockSelector, this.unblockSelector, !1) || (e.childNodes.forEach((e => this.genAdds(e))), $e(e) && e.shadowRoot.childNodes.forEach((t => {
                                this.processedNodeManager.add(t, this), this.genAdds(t, e)
                            })))
                        }
                    }
                }
                init(e) {
                    ["mutationCb", "blockClass", "blockSelector", "unblockSelector", "maskAllText", "maskTextClass", "unmaskTextClass", "maskTextSelector", "unmaskTextSelector", "inlineStylesheet", "maskInputOptions", "maskAttributeFn", "maskTextFn", "maskInputFn", "keepIframeSrcFn", "recordCanvas", "inlineImages", "slimDOMOptions", "dataURLOptions", "doc", "mirror", "iframeManager", "stylesheetManager", "shadowDomManager", "canvasManager", "processedNodeManager"].forEach((t => {
                        this[t] = e[t]
                    }))
                }
                freeze() {
                    this.frozen = !0, this.canvasManager.freeze()
                }
                unfreeze() {
                    this.frozen = !1, this.canvasManager.unfreeze(), this.emit()
                }
                isFrozen() {
                    return this.frozen
                }
                lock() {
                    this.locked = !0, this.canvasManager.lock()
                }
                unlock() {
                    this.locked = !1, this.canvasManager.unlock(), this.emit()
                }
                reset() {
                    this.shadowDomManager.reset(), this.canvasManager.reset()
                }
            }

            function at(e, t) {
                e.delete(t), t.childNodes.forEach((t => at(e, t)))
            }

            function ct(e, t, n) {
                return 0 !== e.length && function(e, t, n) {
                    let s = t.parentNode;
                    for (; s;) {
                        const t = n.getId(s);
                        if (e.some((e => e.id === t))) return !0;
                        s = s.parentNode
                    }
                    return !1
                }(e, t, n)
            }

            function lt(e, t) {
                return 0 !== e.size && ut(e, t)
            }

            function ut(e, t) {
                const {
                    parentNode: n
                } = t;
                return !!n && (!!e.has(n) || ut(e, n))
            }
            let dt;

            function ht(e) {
                dt = e
            }

            function pt() {
                dt = void 0
            }
            const mt = e => {
                if (!dt) return e;
                return (...t) => {
                    try {
                        return e(...t)
                    } catch (e) {
                        if (dt && !0 === dt(e)) return () => {};
                        throw e
                    }
                }
            };

            function ft(e) {
                let t, n = e[0],
                    s = 1;
                for (; s < e.length;) {
                    const r = e[s],
                        o = e[s + 1];
                    if (s += 2, ("optionalAccess" === r || "optionalCall" === r) && null == n) return;
                    "access" === r || "optionalAccess" === r ? (t = n, n = o(n)) : "call" !== r && "optionalCall" !== r || (n = o(((...e) => n.call(t, ...e))), t = void 0)
                }
                return n
            }
            const yt = [];

            function gt(e) {
                try {
                    if ("composedPath" in e) {
                        const t = e.composedPath();
                        if (t.length) return t[0]
                    } else if ("path" in e && e.path.length) return e.path[0]
                } catch (e) {}
                return e && e.target
            }

            function St(e, t) {
                const n = new it;
                yt.push(n), n.init(e);
                let s = window.MutationObserver || window.__rrMutationObserver;
                const r = ft([window, "optionalAccess", e => e.Zone, "optionalAccess", e => e.__symbol__, "optionalCall", e => e("MutationObserver")]);
                r && window[r] && (s = window[r]);
                const o = new s(mt((t => {
                    e.onMutation && !1 === e.onMutation(t) || n.processMutations.bind(n)(t)
                })));
                return o.observe(t, {
                    attributes: !0,
                    attributeOldValue: !0,
                    characterData: !0,
                    characterDataOldValue: !0,
                    childList: !0,
                    subtree: !0
                }), o
            }

            function kt({
                mouseInteractionCb: e,
                doc: t,
                mirror: n,
                blockClass: s,
                blockSelector: r,
                unblockSelector: o,
                sampling: i
            }) {
                if (!1 === i.mouseInteraction) return () => {};
                const a = !0 === i.mouseInteraction || void 0 === i.mouseInteraction ? {} : i.mouseInteraction,
                    c = [];
                let l = null;
                return Object.keys(et).filter((e => Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== a[e])).forEach((i => {
                    let a = V(i);
                    const u = (t => i => {
                        const a = gt(i);
                        if (Pe(a, s, r, o, !0)) return;
                        let c = null,
                            u = t;
                        if ("pointerType" in i) {
                            switch (i.pointerType) {
                                case "mouse":
                                    c = tt.Mouse;
                                    break;
                                case "touch":
                                    c = tt.Touch;
                                    break;
                                case "pen":
                                    c = tt.Pen
                            }
                            c === tt.Touch ? et[t] === et.MouseDown ? u = "TouchStart" : et[t] === et.MouseUp && (u = "TouchEnd") : tt.Pen
                        } else We(i) && (c = tt.Touch);
                        null !== c ? (l = c, (u.startsWith("Touch") && c === tt.Touch || u.startsWith("Mouse") && c === tt.Mouse) && (c = null)) : et[t] === et.Click && (c = l, l = null);
                        const d = We(i) ? i.changedTouches[0] : i;
                        if (!d) return;
                        const h = n.getId(a),
                            {
                                clientX: p,
                                clientY: m
                            } = d;
                        mt(e)({
                            type: et[u],
                            id: h,
                            x: p,
                            y: m,
                            ...null !== c && {
                                pointerType: c
                            }
                        })
                    })(i);
                    if (window.PointerEvent) switch (et[i]) {
                        case et.MouseDown:
                        case et.MouseUp:
                            a = a.replace("mouse", "pointer");
                            break;
                        case et.TouchStart:
                        case et.TouchEnd:
                            return
                    }
                    c.push(Me(a, u, t))
                })), mt((() => {
                    c.forEach((e => e()))
                }))
            }

            function vt({
                scrollCb: e,
                doc: t,
                mirror: n,
                blockClass: s,
                blockSelector: r,
                unblockSelector: o,
                sampling: i
            }) {
                return Me("scroll", mt(Re(mt((i => {
                    const a = gt(i);
                    if (!a || Pe(a, s, r, o, !0)) return;
                    const c = n.getId(a);
                    if (a === t && t.defaultView) {
                        const n = Le(t.defaultView);
                        e({
                            id: c,
                            x: n.left,
                            y: n.top
                        })
                    } else e({
                        id: c,
                        x: a.scrollLeft,
                        y: a.scrollTop
                    })
                })), i.scroll || 100)), t)
            }
            const bt = ["INPUT", "TEXTAREA", "SELECT"],
                _t = new WeakMap;

            function wt({
                inputCb: e,
                doc: t,
                mirror: n,
                blockClass: s,
                blockSelector: r,
                unblockSelector: o,
                ignoreClass: i,
                ignoreSelector: a,
                maskInputOptions: c,
                maskInputFn: l,
                sampling: u,
                userTriggeredOnInput: d,
                maskTextClass: h,
                unmaskTextClass: p,
                maskTextSelector: m,
                unmaskTextSelector: f
            }) {
                function y(e) {
                    let n = gt(e);
                    const u = e.isTrusted,
                        y = n && J(n.tagName);
                    if ("OPTION" === y && (n = n.parentElement), !n || !y || bt.indexOf(y) < 0 || Pe(n, s, r, o, !0)) return;
                    const S = n;
                    if (S.classList.contains(i) || a && S.matches(a)) return;
                    const k = Y(n);
                    let v = X(S, y, k),
                        b = !1;
                    const _ = q({
                            maskInputOptions: c,
                            tagName: y,
                            type: k
                        }),
                        w = we(n, h, m, p, f, _);
                    "radio" !== k && "checkbox" !== k || (b = n.checked), v = K({
                        isMasked: w,
                        element: n,
                        value: v,
                        maskInputFn: l
                    }), g(n, d ? {
                        text: v,
                        isChecked: b,
                        userTriggered: u
                    } : {
                        text: v,
                        isChecked: b
                    });
                    const I = n.name;
                    "radio" === k && I && b && t.querySelectorAll(`input[type="radio"][name="${I}"]`).forEach((e => {
                        if (e !== n) {
                            const t = K({
                                isMasked: w,
                                element: e,
                                value: X(e, y, k),
                                maskInputFn: l
                            });
                            g(e, d ? {
                                text: t,
                                isChecked: !b,
                                userTriggered: !1
                            } : {
                                text: t,
                                isChecked: !b
                            })
                        }
                    }))
                }

                function g(t, s) {
                    const r = _t.get(t);
                    if (!r || r.text !== s.text || r.isChecked !== s.isChecked) {
                        _t.set(t, s);
                        const r = n.getId(t);
                        mt(e)({ ...s,
                            id: r
                        })
                    }
                }
                const S = ("last" === u.input ? ["change"] : ["input", "change"]).map((e => Me(e, mt(y), t))),
                    k = t.defaultView;
                if (!k) return () => {
                    S.forEach((e => e()))
                };
                const v = k.Object.getOwnPropertyDescriptor(k.HTMLInputElement.prototype, "value"),
                    b = [
                        [k.HTMLInputElement.prototype, "value"],
                        [k.HTMLInputElement.prototype, "checked"],
                        [k.HTMLSelectElement.prototype, "value"],
                        [k.HTMLTextAreaElement.prototype, "value"],
                        [k.HTMLSelectElement.prototype, "selectedIndex"],
                        [k.HTMLOptionElement.prototype, "selected"]
                    ];
                return v && v.set && S.push(...b.map((e => Ae(e[0], e[1], {
                    set() {
                        mt(y)({
                            target: this,
                            isTrusted: !1
                        })
                    }
                }, !1, k)))), mt((() => {
                    S.forEach((e => e()))
                }))
            }

            function It(e) {
                return function(e, t) {
                    if (Mt("CSSGroupingRule") && e.parentRule instanceof CSSGroupingRule || Mt("CSSMediaRule") && e.parentRule instanceof CSSMediaRule || Mt("CSSSupportsRule") && e.parentRule instanceof CSSSupportsRule || Mt("CSSConditionRule") && e.parentRule instanceof CSSConditionRule) {
                        const n = Array.from(e.parentRule.cssRules).indexOf(e);
                        t.unshift(n)
                    } else if (e.parentStyleSheet) {
                        const n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
                        t.unshift(n)
                    }
                    return t
                }(e, [])
            }

            function Ct(e, t, n) {
                let s, r;
                return e ? (e.ownerNode ? s = t.getId(e.ownerNode) : r = n.getId(e), {
                    styleId: r,
                    id: s
                }) : {}
            }

            function Et({
                mirror: e,
                stylesheetManager: t
            }, n) {
                let s = null;
                s = "#document" === n.nodeName ? e.getId(n) : e.getId(n.host);
                const r = "#document" === n.nodeName ? ft([n, "access", e => e.defaultView, "optionalAccess", e => e.Document]) : ft([n, "access", e => e.ownerDocument, "optionalAccess", e => e.defaultView, "optionalAccess", e => e.ShadowRoot]),
                    o = ft([r, "optionalAccess", e => e.prototype]) ? Object.getOwnPropertyDescriptor(ft([r, "optionalAccess", e => e.prototype]), "adoptedStyleSheets") : void 0;
                return null !== s && -1 !== s && r && o ? (Object.defineProperty(n, "adoptedStyleSheets", {
                    configurable: o.configurable,
                    enumerable: o.enumerable,
                    get() {
                        return ft([o, "access", e => e.get, "optionalAccess", e => e.call, "call", e => e(this)])
                    },
                    set(e) {
                        const n = ft([o, "access", e => e.set, "optionalAccess", e => e.call, "call", t => t(this, e)]);
                        if (null !== s && -1 !== s) try {
                            t.adoptStyleSheets(e, s)
                        } catch (e) {}
                        return n
                    }
                }), mt((() => {
                    Object.defineProperty(n, "adoptedStyleSheets", {
                        configurable: o.configurable,
                        enumerable: o.enumerable,
                        get: o.get,
                        set: o.set
                    })
                }))) : () => {}
            }

            function Tt(e, t = {}) {
                const n = e.doc.defaultView;
                if (!n) return () => {};
                let s;
                e.recordDOM && (s = St(e, e.doc));
                const r = function({
                        mousemoveCb: e,
                        sampling: t,
                        doc: n,
                        mirror: s
                    }) {
                        if (!1 === t.mousemove) return () => {};
                        const r = "number" == typeof t.mousemove ? t.mousemove : 50,
                            o = "number" == typeof t.mousemoveCallback ? t.mousemoveCallback : 500;
                        let i, a = [];
                        const c = Re(mt((t => {
                                const n = Date.now() - i;
                                e(a.map((e => (e.timeOffset -= n, e))), t), a = [], i = null
                            })), o),
                            l = mt(Re(mt((e => {
                                const t = gt(e),
                                    {
                                        clientX: n,
                                        clientY: r
                                    } = We(e) ? e.changedTouches[0] : e;
                                i || (i = Oe()), a.push({
                                    x: n,
                                    y: r,
                                    id: s.getId(t),
                                    timeOffset: Oe() - i
                                }), c("undefined" != typeof DragEvent && e instanceof DragEvent ? Ze.Drag : e instanceof MouseEvent ? Ze.MouseMove : Ze.TouchMove)
                            })), r, {
                                trailing: !1
                            })),
                            u = [Me("mousemove", l, n), Me("touchmove", l, n), Me("drag", l, n)];
                        return mt((() => {
                            u.forEach((e => e()))
                        }))
                    }(e),
                    o = kt(e),
                    i = vt(e),
                    a = function({
                        viewportResizeCb: e
                    }, {
                        win: t
                    }) {
                        let n = -1,
                            s = -1;
                        return Me("resize", mt(Re(mt((() => {
                            const t = Ne(),
                                r = Fe();
                            n === t && s === r || (e({
                                width: Number(r),
                                height: Number(t)
                            }), n = t, s = r)
                        })), 200)), t)
                    }(e, {
                        win: n
                    }),
                    c = wt(e),
                    l = function({
                        mediaInteractionCb: e,
                        blockClass: t,
                        blockSelector: n,
                        unblockSelector: s,
                        mirror: r,
                        sampling: o,
                        doc: i
                    }) {
                        const a = mt((i => Re(mt((o => {
                                const a = gt(o);
                                if (!a || Pe(a, t, n, s, !0)) return;
                                const {
                                    currentTime: c,
                                    volume: l,
                                    muted: u,
                                    playbackRate: d
                                } = a;
                                e({
                                    type: i,
                                    id: r.getId(a),
                                    currentTime: c,
                                    volume: l,
                                    muted: u,
                                    playbackRate: d
                                })
                            })), o.media || 500))),
                            c = [Me("play", a(0), i), Me("pause", a(1), i), Me("seeked", a(2), i), Me("volumechange", a(3), i), Me("ratechange", a(4), i)];
                        return mt((() => {
                            c.forEach((e => e()))
                        }))
                    }(e);
                let u = () => {},
                    d = () => {},
                    h = () => {},
                    p = () => {};
                e.recordDOM && (u = function({
                    styleSheetRuleCb: e,
                    mirror: t,
                    stylesheetManager: n
                }, {
                    win: s
                }) {
                    if (!s.CSSStyleSheet || !s.CSSStyleSheet.prototype) return () => {};
                    const r = s.CSSStyleSheet.prototype.insertRule;
                    s.CSSStyleSheet.prototype.insertRule = new Proxy(r, {
                        apply: mt(((s, r, o) => {
                            const [i, a] = o, {
                                id: c,
                                styleId: l
                            } = Ct(r, t, n.styleMirror);
                            return (c && -1 !== c || l && -1 !== l) && e({
                                id: c,
                                styleId: l,
                                adds: [{
                                    rule: i,
                                    index: a
                                }]
                            }), s.apply(r, o)
                        }))
                    });
                    const o = s.CSSStyleSheet.prototype.deleteRule;
                    let i, a;
                    s.CSSStyleSheet.prototype.deleteRule = new Proxy(o, {
                        apply: mt(((s, r, o) => {
                            const [i] = o, {
                                id: a,
                                styleId: c
                            } = Ct(r, t, n.styleMirror);
                            return (a && -1 !== a || c && -1 !== c) && e({
                                id: a,
                                styleId: c,
                                removes: [{
                                    index: i
                                }]
                            }), s.apply(r, o)
                        }))
                    }), s.CSSStyleSheet.prototype.replace && (i = s.CSSStyleSheet.prototype.replace, s.CSSStyleSheet.prototype.replace = new Proxy(i, {
                        apply: mt(((s, r, o) => {
                            const [i] = o, {
                                id: a,
                                styleId: c
                            } = Ct(r, t, n.styleMirror);
                            return (a && -1 !== a || c && -1 !== c) && e({
                                id: a,
                                styleId: c,
                                replace: i
                            }), s.apply(r, o)
                        }))
                    })), s.CSSStyleSheet.prototype.replaceSync && (a = s.CSSStyleSheet.prototype.replaceSync, s.CSSStyleSheet.prototype.replaceSync = new Proxy(a, {
                        apply: mt(((s, r, o) => {
                            const [i] = o, {
                                id: a,
                                styleId: c
                            } = Ct(r, t, n.styleMirror);
                            return (a && -1 !== a || c && -1 !== c) && e({
                                id: a,
                                styleId: c,
                                replaceSync: i
                            }), s.apply(r, o)
                        }))
                    }));
                    const c = {};
                    xt("CSSGroupingRule") ? c.CSSGroupingRule = s.CSSGroupingRule : (xt("CSSMediaRule") && (c.CSSMediaRule = s.CSSMediaRule), xt("CSSConditionRule") && (c.CSSConditionRule = s.CSSConditionRule), xt("CSSSupportsRule") && (c.CSSSupportsRule = s.CSSSupportsRule));
                    const l = {};
                    return Object.entries(c).forEach((([s, r]) => {
                        l[s] = {
                            insertRule: r.prototype.insertRule,
                            deleteRule: r.prototype.deleteRule
                        }, r.prototype.insertRule = new Proxy(l[s].insertRule, {
                            apply: mt(((s, r, o) => {
                                const [i, a] = o, {
                                    id: c,
                                    styleId: l
                                } = Ct(r.parentStyleSheet, t, n.styleMirror);
                                return (c && -1 !== c || l && -1 !== l) && e({
                                    id: c,
                                    styleId: l,
                                    adds: [{
                                        rule: i,
                                        index: [...It(r), a || 0]
                                    }]
                                }), s.apply(r, o)
                            }))
                        }), r.prototype.deleteRule = new Proxy(l[s].deleteRule, {
                            apply: mt(((s, r, o) => {
                                const [i] = o, {
                                    id: a,
                                    styleId: c
                                } = Ct(r.parentStyleSheet, t, n.styleMirror);
                                return (a && -1 !== a || c && -1 !== c) && e({
                                    id: a,
                                    styleId: c,
                                    removes: [{
                                        index: [...It(r), i]
                                    }]
                                }), s.apply(r, o)
                            }))
                        })
                    })), mt((() => {
                        s.CSSStyleSheet.prototype.insertRule = r, s.CSSStyleSheet.prototype.deleteRule = o, i && (s.CSSStyleSheet.prototype.replace = i), a && (s.CSSStyleSheet.prototype.replaceSync = a), Object.entries(c).forEach((([e, t]) => {
                            t.prototype.insertRule = l[e].insertRule, t.prototype.deleteRule = l[e].deleteRule
                        }))
                    }))
                }(e, {
                    win: n
                }), d = Et(e, e.doc), h = function({
                    styleDeclarationCb: e,
                    mirror: t,
                    ignoreCSSAttributes: n,
                    stylesheetManager: s
                }, {
                    win: r
                }) {
                    const o = r.CSSStyleDeclaration.prototype.setProperty;
                    r.CSSStyleDeclaration.prototype.setProperty = new Proxy(o, {
                        apply: mt(((r, i, a) => {
                            const [c, l, u] = a;
                            if (n.has(c)) return o.apply(i, [c, l, u]);
                            const {
                                id: d,
                                styleId: h
                            } = Ct(ft([i, "access", e => e.parentRule, "optionalAccess", e => e.parentStyleSheet]), t, s.styleMirror);
                            return (d && -1 !== d || h && -1 !== h) && e({
                                id: d,
                                styleId: h,
                                set: {
                                    property: c,
                                    value: l,
                                    priority: u
                                },
                                index: It(i.parentRule)
                            }), r.apply(i, a)
                        }))
                    });
                    const i = r.CSSStyleDeclaration.prototype.removeProperty;
                    return r.CSSStyleDeclaration.prototype.removeProperty = new Proxy(i, {
                        apply: mt(((r, o, a) => {
                            const [c] = a;
                            if (n.has(c)) return i.apply(o, [c]);
                            const {
                                id: l,
                                styleId: u
                            } = Ct(ft([o, "access", e => e.parentRule, "optionalAccess", e => e.parentStyleSheet]), t, s.styleMirror);
                            return (l && -1 !== l || u && -1 !== u) && e({
                                id: l,
                                styleId: u,
                                remove: {
                                    property: c
                                },
                                index: It(o.parentRule)
                            }), r.apply(o, a)
                        }))
                    }), mt((() => {
                        r.CSSStyleDeclaration.prototype.setProperty = o, r.CSSStyleDeclaration.prototype.removeProperty = i
                    }))
                }(e, {
                    win: n
                }), e.collectFonts && (p = function({
                    fontCb: e,
                    doc: t
                }) {
                    const n = t.defaultView;
                    if (!n) return () => {};
                    const s = [],
                        r = new WeakMap,
                        o = n.FontFace;
                    n.FontFace = function(e, t, n) {
                        const s = new o(e, t, n);
                        return r.set(s, {
                            family: e,
                            buffer: "string" != typeof t,
                            descriptors: n,
                            fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t)))
                        }), s
                    };
                    const i = De(t.fonts, "add", (function(t) {
                        return function(n) {
                            return Xe(mt((() => {
                                const t = r.get(n);
                                t && (e(t), r.delete(n))
                            })), 0), t.apply(this, [n])
                        }
                    }));
                    return s.push((() => {
                        n.FontFace = o
                    })), s.push(i), mt((() => {
                        s.forEach((e => e()))
                    }))
                }(e)));
                const m = function(e) {
                        const {
                            doc: t,
                            mirror: n,
                            blockClass: s,
                            blockSelector: r,
                            unblockSelector: o,
                            selectionCb: i
                        } = e;
                        let a = !0;
                        const c = mt((() => {
                            const e = t.getSelection();
                            if (!e || a && ft([e, "optionalAccess", e => e.isCollapsed])) return;
                            a = e.isCollapsed || !1;
                            const c = [],
                                l = e.rangeCount || 0;
                            for (let t = 0; t < l; t++) {
                                const i = e.getRangeAt(t),
                                    {
                                        startContainer: a,
                                        startOffset: l,
                                        endContainer: u,
                                        endOffset: d
                                    } = i;
                                Pe(a, s, r, o, !0) || Pe(u, s, r, o, !0) || c.push({
                                    start: n.getId(a),
                                    startOffset: l,
                                    end: n.getId(u),
                                    endOffset: d
                                })
                            }
                            i({
                                ranges: c
                            })
                        }));
                        return c(), Me("selectionchange", c)
                    }(e),
                    f = function({
                        doc: e,
                        customElementCb: t
                    }) {
                        const n = e.defaultView;
                        return n && n.customElements ? De(n.customElements, "define", (function(e) {
                            return function(n, s, r) {
                                try {
                                    t({
                                        define: {
                                            name: n
                                        }
                                    })
                                } catch (e) {}
                                return e.apply(this, [n, s, r])
                            }
                        })) : () => {}
                    }(e),
                    y = [];
                for (const t of e.plugins) y.push(t.observer(t.callback, n, t.options));
                return mt((() => {
                    yt.forEach((e => e.reset())), ft([s, "optionalAccess", e => e.disconnect, "call", e => e()]), r(), o(), i(), a(), c(), l(), u(), d(), h(), p(), m(), f(), y.forEach((e => e()))
                }))
            }

            function Mt(e) {
                return void 0 !== window[e]
            }

            function xt(e) {
                return Boolean(void 0 !== window[e] && window[e].prototype && "insertRule" in window[e].prototype && "deleteRule" in window[e].prototype)
            }
            class Rt {
                constructor(e) {
                    this.generateIdFn = e, this.iframeIdToRemoteIdMap = new WeakMap, this.iframeRemoteIdToIdMap = new WeakMap
                }
                getId(e, t, n, s) {
                    const r = n || this.getIdToRemoteIdMap(e),
                        o = s || this.getRemoteIdToIdMap(e);
                    let i = r.get(t);
                    return i || (i = this.generateIdFn(), r.set(t, i), o.set(i, t)), i
                }
                getIds(e, t) {
                    const n = this.getIdToRemoteIdMap(e),
                        s = this.getRemoteIdToIdMap(e);
                    return t.map((t => this.getId(e, t, n, s)))
                }
                getRemoteId(e, t, n) {
                    const s = n || this.getRemoteIdToIdMap(e);
                    if ("number" != typeof t) return t;
                    const r = s.get(t);
                    return r || -1
                }
                getRemoteIds(e, t) {
                    const n = this.getRemoteIdToIdMap(e);
                    return t.map((t => this.getRemoteId(e, t, n)))
                }
                reset(e) {
                    if (!e) return this.iframeIdToRemoteIdMap = new WeakMap, void(this.iframeRemoteIdToIdMap = new WeakMap);
                    this.iframeIdToRemoteIdMap.delete(e), this.iframeRemoteIdToIdMap.delete(e)
                }
                getIdToRemoteIdMap(e) {
                    let t = this.iframeIdToRemoteIdMap.get(e);
                    return t || (t = new Map, this.iframeIdToRemoteIdMap.set(e, t)), t
                }
                getRemoteIdToIdMap(e) {
                    let t = this.iframeRemoteIdToIdMap.get(e);
                    return t || (t = new Map, this.iframeRemoteIdToIdMap.set(e, t)), t
                }
            }

            function At(e) {
                let t, n = e[0],
                    s = 1;
                for (; s < e.length;) {
                    const r = e[s],
                        o = e[s + 1];
                    if (s += 2, ("optionalAccess" === r || "optionalCall" === r) && null == n) return;
                    "access" === r || "optionalAccess" === r ? (t = n, n = o(n)) : "call" !== r && "optionalCall" !== r || (n = o(((...e) => n.call(t, ...e))), t = void 0)
                }
                return n
            }
            class Dt {
                constructor() {
                    this.crossOriginIframeMirror = new Rt(oe), this.crossOriginIframeRootIdMap = new WeakMap
                }
                addIframe() {}
                addLoadListener() {}
                attachIframe() {}
            }
            class Ot {
                constructor(e) {
                    this.iframes = new WeakMap, this.crossOriginIframeMap = new WeakMap, this.crossOriginIframeMirror = new Rt(oe), this.crossOriginIframeRootIdMap = new WeakMap, this.mutationCb = e.mutationCb, this.wrappedEmit = e.wrappedEmit, this.stylesheetManager = e.stylesheetManager, this.recordCrossOriginIframes = e.recordCrossOriginIframes, this.crossOriginIframeStyleMirror = new Rt(this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror)), this.mirror = e.mirror, this.recordCrossOriginIframes && window.addEventListener("message", this.handleMessage.bind(this))
                }
                addIframe(e) {
                    this.iframes.set(e, !0), e.contentWindow && this.crossOriginIframeMap.set(e.contentWindow, e)
                }
                addLoadListener(e) {
                    this.loadListener = e
                }
                attachIframe(e, t) {
                    this.mutationCb({
                        adds: [{
                            parentId: this.mirror.getId(e),
                            nextId: null,
                            node: t
                        }],
                        removes: [],
                        texts: [],
                        attributes: [],
                        isAttachIframe: !0
                    }), At([this, "access", e => e.loadListener, "optionalCall", t => t(e)]), e.contentDocument && e.contentDocument.adoptedStyleSheets && e.contentDocument.adoptedStyleSheets.length > 0 && this.stylesheetManager.adoptStyleSheets(e.contentDocument.adoptedStyleSheets, this.mirror.getId(e.contentDocument))
                }
                handleMessage(e) {
                    const t = e;
                    if ("rrweb" !== t.data.type || t.origin !== t.data.origin) return;
                    if (!e.source) return;
                    const n = this.crossOriginIframeMap.get(e.source);
                    if (!n) return;
                    const s = this.transformCrossOriginEvent(n, t.data.event);
                    s && this.wrappedEmit(s, t.data.isCheckout)
                }
                transformCrossOriginEvent(e, t) {
                    switch (t.type) {
                        case Qe.FullSnapshot:
                            {
                                this.crossOriginIframeMirror.reset(e),
                                this.crossOriginIframeStyleMirror.reset(e),
                                this.replaceIdOnNode(t.data.node, e);
                                const n = t.data.node.id;
                                return this.crossOriginIframeRootIdMap.set(e, n),
                                this.patchRootIdOnNode(t.data.node, n),
                                {
                                    timestamp: t.timestamp,
                                    type: Qe.IncrementalSnapshot,
                                    data: {
                                        source: Ze.Mutation,
                                        adds: [{
                                            parentId: this.mirror.getId(e),
                                            nextId: null,
                                            node: t.data.node
                                        }],
                                        removes: [],
                                        texts: [],
                                        attributes: [],
                                        isAttachIframe: !0
                                    }
                                }
                            }
                        case Qe.Meta:
                        case Qe.Load:
                        case Qe.DomContentLoaded:
                            return !1;
                        case Qe.Plugin:
                            return t;
                        case Qe.Custom:
                            return this.replaceIds(t.data.payload, e, ["id", "parentId", "previousId", "nextId"]), t;
                        case Qe.IncrementalSnapshot:
                            switch (t.data.source) {
                                case Ze.Mutation:
                                    return t.data.adds.forEach((t => {
                                        this.replaceIds(t, e, ["parentId", "nextId", "previousId"]), this.replaceIdOnNode(t.node, e);
                                        const n = this.crossOriginIframeRootIdMap.get(e);
                                        n && this.patchRootIdOnNode(t.node, n)
                                    })), t.data.removes.forEach((t => {
                                        this.replaceIds(t, e, ["parentId", "id"])
                                    })), t.data.attributes.forEach((t => {
                                        this.replaceIds(t, e, ["id"])
                                    })), t.data.texts.forEach((t => {
                                        this.replaceIds(t, e, ["id"])
                                    })), t;
                                case Ze.Drag:
                                case Ze.TouchMove:
                                case Ze.MouseMove:
                                    return t.data.positions.forEach((t => {
                                        this.replaceIds(t, e, ["id"])
                                    })), t;
                                case Ze.ViewportResize:
                                    return !1;
                                case Ze.MediaInteraction:
                                case Ze.MouseInteraction:
                                case Ze.Scroll:
                                case Ze.CanvasMutation:
                                case Ze.Input:
                                    return this.replaceIds(t.data, e, ["id"]), t;
                                case Ze.StyleSheetRule:
                                case Ze.StyleDeclaration:
                                    return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleId"]), t;
                                case Ze.Font:
                                    return t;
                                case Ze.Selection:
                                    return t.data.ranges.forEach((t => {
                                        this.replaceIds(t, e, ["start", "end"])
                                    })), t;
                                case Ze.AdoptedStyleSheet:
                                    return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleIds"]), At([t, "access", e => e.data, "access", e => e.styles, "optionalAccess", e => e.forEach, "call", t => t((t => {
                                        this.replaceStyleIds(t, e, ["styleId"])
                                    }))]), t
                            }
                    }
                    return !1
                }
                replace(e, t, n, s) {
                    for (const r of s)(Array.isArray(t[r]) || "number" == typeof t[r]) && (Array.isArray(t[r]) ? t[r] = e.getIds(n, t[r]) : t[r] = e.getId(n, t[r]));
                    return t
                }
                replaceIds(e, t, n) {
                    return this.replace(this.crossOriginIframeMirror, e, t, n)
                }
                replaceStyleIds(e, t, n) {
                    return this.replace(this.crossOriginIframeStyleMirror, e, t, n)
                }
                replaceIdOnNode(e, t) {
                    this.replaceIds(e, t, ["id", "rootId"]), "childNodes" in e && e.childNodes.forEach((e => {
                        this.replaceIdOnNode(e, t)
                    }))
                }
                patchRootIdOnNode(e, t) {
                    e.type === U.Document || e.rootId || (e.rootId = t), "childNodes" in e && e.childNodes.forEach((e => {
                        this.patchRootIdOnNode(e, t)
                    }))
                }
            }
            class Lt {
                init() {}
                addShadowRoot() {}
                observeAttachShadow() {}
                reset() {}
            }
            class Nt {
                constructor(e) {
                    this.shadowDoms = new WeakSet, this.restoreHandlers = [], this.mutationCb = e.mutationCb, this.scrollCb = e.scrollCb, this.bypassOptions = e.bypassOptions, this.mirror = e.mirror, this.init()
                }
                init() {
                    this.reset(), this.patchAttachShadow(Element, document)
                }
                addShadowRoot(e, t) {
                    if (!W(e)) return;
                    if (this.shadowDoms.has(e)) return;
                    this.shadowDoms.add(e), this.bypassOptions.canvasManager.addShadowRoot(e);
                    const n = St({ ...this.bypassOptions,
                        doc: t,
                        mutationCb: this.mutationCb,
                        mirror: this.mirror,
                        shadowDomManager: this
                    }, e);
                    this.restoreHandlers.push((() => n.disconnect())), this.restoreHandlers.push(vt({ ...this.bypassOptions,
                        scrollCb: this.scrollCb,
                        doc: e,
                        mirror: this.mirror
                    })), Xe((() => {
                        e.adoptedStyleSheets && e.adoptedStyleSheets.length > 0 && this.bypassOptions.stylesheetManager.adoptStyleSheets(e.adoptedStyleSheets, this.mirror.getId(e.host)), this.restoreHandlers.push(Et({
                            mirror: this.mirror,
                            stylesheetManager: this.bypassOptions.stylesheetManager
                        }, e))
                    }), 0)
                }
                observeAttachShadow(e) {
                    e.contentWindow && e.contentDocument && this.patchAttachShadow(e.contentWindow.Element, e.contentDocument)
                }
                patchAttachShadow(e, t) {
                    const n = this;
                    this.restoreHandlers.push(De(e.prototype, "attachShadow", (function(e) {
                        return function(s) {
                            const r = e.call(this, s);
                            return this.shadowRoot && Je(this) && n.addShadowRoot(this.shadowRoot, t), r
                        }
                    })))
                }
                reset() {
                    this.restoreHandlers.forEach((e => {
                        try {
                            e()
                        } catch (e) {}
                    })), this.restoreHandlers = [], this.shadowDoms = new WeakSet, this.bypassOptions.canvasManager.resetShadowRoots()
                }
            }
            class Ft {
                reset() {}
                freeze() {}
                unfreeze() {}
                lock() {}
                unlock() {}
                snapshot() {}
                addWindow() {}
                addShadowRoot() {}
                resetShadowRoots() {}
            }
            class Bt {
                constructor(e) {
                    this.trackedLinkElements = new WeakSet, this.styleMirror = new qe, this.mutationCb = e.mutationCb, this.adoptedStyleSheetCb = e.adoptedStyleSheetCb
                }
                attachLinkElement(e, t) {
                    "_cssText" in t.attributes && this.mutationCb({
                        adds: [],
                        removes: [],
                        texts: [],
                        attributes: [{
                            id: t.id,
                            attributes: t.attributes
                        }]
                    }), this.trackLinkElement(e)
                }
                trackLinkElement(e) {
                    this.trackedLinkElements.has(e) || (this.trackedLinkElements.add(e), this.trackStylesheetInLinkElement(e))
                }
                adoptStyleSheets(e, t) {
                    if (0 === e.length) return;
                    const n = {
                            id: t,
                            styleIds: []
                        },
                        s = [];
                    for (const t of e) {
                        let e;
                        this.styleMirror.has(t) ? e = this.styleMirror.getId(t) : (e = this.styleMirror.add(t), s.push({
                            styleId: e,
                            rules: Array.from(t.rules || CSSRule, ((e, t) => ({
                                rule: j(e),
                                index: t
                            })))
                        })), n.styleIds.push(e)
                    }
                    s.length > 0 && (n.styles = s), this.adoptedStyleSheetCb(n)
                }
                reset() {
                    this.styleMirror.reset(), this.trackedLinkElements = new WeakSet
                }
                trackStylesheetInLinkElement(e) {}
            }
            class Pt {
                constructor() {
                    this.nodeMap = new WeakMap, this.active = !1
                }
                inOtherBuffer(e, t) {
                    const n = this.nodeMap.get(e);
                    return n && Array.from(n).some((e => e !== t))
                }
                add(e, t) {
                    this.active || (this.active = !0, function(...e) {
                        Ye("requestAnimationFrame")(...e)
                    }((() => {
                        this.nodeMap = new WeakMap, this.active = !1
                    }))), this.nodeMap.set(e, (this.nodeMap.get(e) || new Set).add(t))
                }
                destroy() {}
            }
            let Ut, zt;
            try {
                if (2 !== Array.from([1], (e => 2 * e))[0]) {
                    const e = document.createElement("iframe");
                    document.body.appendChild(e), Array.from = (0, r.x)([e, "access", e => e.contentWindow, "optionalAccess", e => e.Array, "access", e => e.from]) || Array.from, document.body.removeChild(e)
                }
            } catch (e) {}
            const Wt = new $;

            function Ht(e = {}) {
                const {
                    emit: t,
                    checkoutEveryNms: n,
                    checkoutEveryNth: s,
                    blockClass: o = "rr-block",
                    blockSelector: i = null,
                    unblockSelector: a = null,
                    ignoreClass: c = "rr-ignore",
                    ignoreSelector: l = null,
                    maskAllText: u = !1,
                    maskTextClass: d = "rr-mask",
                    unmaskTextClass: h = null,
                    maskTextSelector: p = null,
                    unmaskTextSelector: m = null,
                    inlineStylesheet: f = !0,
                    maskAllInputs: y,
                    maskInputOptions: g,
                    slimDOMOptions: S,
                    maskAttributeFn: k,
                    maskInputFn: v,
                    maskTextFn: b,
                    maxCanvasSize: _ = null,
                    packFn: w,
                    sampling: I = {},
                    dataURLOptions: C = {},
                    mousemoveWait: E,
                    recordDOM: T = !0,
                    recordCanvas: M = !1,
                    recordCrossOriginIframes: x = !1,
                    recordAfter: R = ("DOMContentLoaded" === e.recordAfter ? e.recordAfter : "load"),
                    userTriggeredOnInput: A = !1,
                    collectFonts: D = !1,
                    inlineImages: O = !1,
                    plugins: L,
                    keepIframeSrcFn: N = () => !1,
                    ignoreCSSAttributes: F = new Set([]),
                    errorHandler: B,
                    onMutation: P,
                    getCanvasManager: U
                } = e;
                ht(B);
                const z = !x || window.parent === window;
                let W = !1;
                if (!z) try {
                    window.parent.document && (W = !1)
                } catch (e) {
                    W = !0
                }
                if (z && !t) throw new Error("emit function is required");
                if (!z && !W) return () => {};
                void 0 !== E && void 0 === I.mousemove && (I.mousemove = E), Wt.reset();
                const H = !0 === y ? {
                        color: !0,
                        date: !0,
                        "datetime-local": !0,
                        email: !0,
                        month: !0,
                        number: !0,
                        range: !0,
                        search: !0,
                        tel: !0,
                        text: !0,
                        time: !0,
                        url: !0,
                        week: !0,
                        textarea: !0,
                        select: !0,
                        radio: !0,
                        checkbox: !0
                    } : void 0 !== g ? g : {},
                    j = !0 === S || "all" === S ? {
                        script: !0,
                        comment: !0,
                        headFavicon: !0,
                        headWhitespace: !0,
                        headMetaSocial: !0,
                        headMetaRobots: !0,
                        headMetaHttpEquiv: !0,
                        headMetaVerification: !0,
                        headMetaAuthorship: "all" === S,
                        headMetaDescKeywords: "all" === S
                    } : S || {};
                let q;
                ! function(e = window) {
                    "NodeList" in e && !e.NodeList.prototype.forEach && (e.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in e && !e.DOMTokenList.prototype.forEach && (e.DOMTokenList.prototype.forEach = Array.prototype.forEach), Node.prototype.contains || (Node.prototype.contains = (...e) => {
                        let t = e[0];
                        if (!(0 in e)) throw new TypeError("1 argument is required");
                        do {
                            if (this === t) return !0
                        } while (t = t && t.parentNode);
                        return !1
                    })
                }();
                let K = 0;
                const V = e => {
                    for (const t of L || []) t.eventProcessor && (e = t.eventProcessor(e));
                    return w && !W && (e = w(e)), e
                };
                Ut = (e, o) => {
                    const i = e;
                    if (i.timestamp = Oe(), !(0, r.x)([yt, "access", e => e[0], "optionalAccess", e => e.isFrozen, "call", e => e()]) || i.type === Qe.FullSnapshot || i.type === Qe.IncrementalSnapshot && i.data.source === Ze.Mutation || yt.forEach((e => e.unfreeze())), z)(0, r.x)([t, "optionalCall", e => e(V(i), o)]);
                    else if (W) {
                        const e = {
                            type: "rrweb",
                            event: V(i),
                            origin: window.location.origin,
                            isCheckout: o
                        };
                        window.parent.postMessage(e, "*")
                    }
                    if (i.type === Qe.FullSnapshot) q = i, K = 0;
                    else if (i.type === Qe.IncrementalSnapshot) {
                        if (i.data.source === Ze.Mutation && i.data.isAttachIframe) return;
                        K++;
                        const e = s && K >= s,
                            t = n && q && i.timestamp - q.timestamp > n;
                        (e || t) && ne(!0)
                    }
                };
                const J = e => {
                        Ut({
                            type: Qe.IncrementalSnapshot,
                            data: {
                                source: Ze.Mutation,
                                ...e
                            }
                        })
                    },
                    G = e => Ut({
                        type: Qe.IncrementalSnapshot,
                        data: {
                            source: Ze.Scroll,
                            ...e
                        }
                    }),
                    Y = e => Ut({
                        type: Qe.IncrementalSnapshot,
                        data: {
                            source: Ze.CanvasMutation,
                            ...e
                        }
                    }),
                    X = new Bt({
                        mutationCb: J,
                        adoptedStyleSheetCb: e => Ut({
                            type: Qe.IncrementalSnapshot,
                            data: {
                                source: Ze.AdoptedStyleSheet,
                                ...e
                            }
                        })
                    }),
                    Q = "boolean" == typeof __RRWEB_EXCLUDE_IFRAME__ && __RRWEB_EXCLUDE_IFRAME__ ? new Dt : new Ot({
                        mirror: Wt,
                        mutationCb: J,
                        stylesheetManager: X,
                        recordCrossOriginIframes: x,
                        wrappedEmit: Ut
                    });
                for (const e of L || []) e.getMirror && e.getMirror({
                    nodeMirror: Wt,
                    crossOriginIframeMirror: Q.crossOriginIframeMirror,
                    crossOriginIframeStyleMirror: Q.crossOriginIframeStyleMirror
                });
                const Z = new Pt,
                    ee = function(e, t) {
                        try {
                            return e ? e(t) : new Ft
                        } catch (e) {
                            return new Ft
                        }
                    }(U, {
                        mirror: Wt,
                        win: window,
                        mutationCb: e => Ut({
                            type: Qe.IncrementalSnapshot,
                            data: {
                                source: Ze.CanvasMutation,
                                ...e
                            }
                        }),
                        recordCanvas: M,
                        blockClass: o,
                        blockSelector: i,
                        unblockSelector: a,
                        maxCanvasSize: _,
                        sampling: I.canvas,
                        dataURLOptions: C,
                        errorHandler: B
                    }),
                    te = "boolean" == typeof __RRWEB_EXCLUDE_SHADOW_DOM__ && __RRWEB_EXCLUDE_SHADOW_DOM__ ? new Lt : new Nt({
                        mutationCb: J,
                        scrollCb: G,
                        bypassOptions: {
                            onMutation: P,
                            blockClass: o,
                            blockSelector: i,
                            unblockSelector: a,
                            maskAllText: u,
                            maskTextClass: d,
                            unmaskTextClass: h,
                            maskTextSelector: p,
                            unmaskTextSelector: m,
                            inlineStylesheet: f,
                            maskInputOptions: H,
                            dataURLOptions: C,
                            maskAttributeFn: k,
                            maskTextFn: b,
                            maskInputFn: v,
                            recordCanvas: M,
                            inlineImages: O,
                            sampling: I,
                            slimDOMOptions: j,
                            iframeManager: Q,
                            stylesheetManager: X,
                            canvasManager: ee,
                            keepIframeSrcFn: N,
                            processedNodeManager: Z
                        },
                        mirror: Wt
                    }),
                    ne = (e = !1) => {
                        if (!T) return;
                        Ut({
                            type: Qe.Meta,
                            data: {
                                href: window.location.href,
                                width: Fe(),
                                height: Ne()
                            }
                        }, e), X.reset(), te.init(), yt.forEach((e => e.lock()));
                        const t = function(e, t) {
                            const {
                                mirror: n = new $,
                                blockClass: s = "rr-block",
                                blockSelector: r = null,
                                unblockSelector: o = null,
                                maskAllText: i = !1,
                                maskTextClass: a = "rr-mask",
                                unmaskTextClass: c = null,
                                maskTextSelector: l = null,
                                unmaskTextSelector: u = null,
                                inlineStylesheet: d = !0,
                                inlineImages: h = !1,
                                recordCanvas: p = !1,
                                maskAllInputs: m = !1,
                                maskAttributeFn: f,
                                maskTextFn: y,
                                maskInputFn: g,
                                slimDOM: S = !1,
                                dataURLOptions: k,
                                preserveWhiteSpace: v,
                                onSerialize: b,
                                onIframeLoad: _,
                                iframeLoadTimeout: w,
                                onStylesheetLoad: I,
                                stylesheetLoadTimeout: C,
                                keepIframeSrcFn: E = () => !1
                            } = t || {};
                            return Ee(e, {
                                doc: e,
                                mirror: n,
                                blockClass: s,
                                blockSelector: r,
                                unblockSelector: o,
                                maskAllText: i,
                                maskTextClass: a,
                                unmaskTextClass: c,
                                maskTextSelector: l,
                                unmaskTextSelector: u,
                                skipChild: !1,
                                inlineStylesheet: d,
                                maskInputOptions: !0 === m ? {
                                    color: !0,
                                    date: !0,
                                    "datetime-local": !0,
                                    email: !0,
                                    month: !0,
                                    number: !0,
                                    range: !0,
                                    search: !0,
                                    tel: !0,
                                    text: !0,
                                    time: !0,
                                    url: !0,
                                    week: !0,
                                    textarea: !0,
                                    select: !0
                                } : !1 === m ? {} : m,
                                maskAttributeFn: f,
                                maskTextFn: y,
                                maskInputFn: g,
                                slimDOMOptions: !0 === S || "all" === S ? {
                                    script: !0,
                                    comment: !0,
                                    headFavicon: !0,
                                    headWhitespace: !0,
                                    headMetaDescKeywords: "all" === S,
                                    headMetaSocial: !0,
                                    headMetaRobots: !0,
                                    headMetaHttpEquiv: !0,
                                    headMetaAuthorship: !0,
                                    headMetaVerification: !0
                                } : !1 === S ? {} : S,
                                dataURLOptions: k,
                                inlineImages: h,
                                recordCanvas: p,
                                preserveWhiteSpace: v,
                                onSerialize: b,
                                onIframeLoad: _,
                                iframeLoadTimeout: w,
                                onStylesheetLoad: I,
                                stylesheetLoadTimeout: C,
                                keepIframeSrcFn: E,
                                newlyAddedElement: !1
                            })
                        }(document, {
                            mirror: Wt,
                            blockClass: o,
                            blockSelector: i,
                            unblockSelector: a,
                            maskAllText: u,
                            maskTextClass: d,
                            unmaskTextClass: h,
                            maskTextSelector: p,
                            unmaskTextSelector: m,
                            inlineStylesheet: f,
                            maskAllInputs: H,
                            maskAttributeFn: k,
                            maskInputFn: v,
                            maskTextFn: b,
                            slimDOM: j,
                            dataURLOptions: C,
                            recordCanvas: M,
                            inlineImages: O,
                            onSerialize: e => {
                                He(e, Wt) && Q.addIframe(e), je(e, Wt) && X.trackLinkElement(e), $e(e) && te.addShadowRoot(e.shadowRoot, document)
                            },
                            onIframeLoad: (e, t) => {
                                Q.attachIframe(e, t), e.contentWindow && ee.addWindow(e.contentWindow), te.observeAttachShadow(e)
                            },
                            onStylesheetLoad: (e, t) => {
                                X.attachLinkElement(e, t)
                            },
                            keepIframeSrcFn: N
                        });
                        t && (Ut({
                            type: Qe.FullSnapshot,
                            data: {
                                node: t,
                                initialOffset: Le(window)
                            }
                        }), yt.forEach((e => e.unlock())), document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0 && X.adoptStyleSheets(document.adoptedStyleSheets, Wt.getId(document)))
                    };
                zt = ne;
                try {
                    const e = [],
                        t = e => mt(Tt)({
                            onMutation: P,
                            mutationCb: J,
                            mousemoveCb: (e, t) => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: t,
                                    positions: e
                                }
                            }),
                            mouseInteractionCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.MouseInteraction,
                                    ...e
                                }
                            }),
                            scrollCb: G,
                            viewportResizeCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.ViewportResize,
                                    ...e
                                }
                            }),
                            inputCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.Input,
                                    ...e
                                }
                            }),
                            mediaInteractionCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.MediaInteraction,
                                    ...e
                                }
                            }),
                            styleSheetRuleCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.StyleSheetRule,
                                    ...e
                                }
                            }),
                            styleDeclarationCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.StyleDeclaration,
                                    ...e
                                }
                            }),
                            canvasMutationCb: Y,
                            fontCb: e => Ut({
                                type: Qe.IncrementalSnapshot,
                                data: {
                                    source: Ze.Font,
                                    ...e
                                }
                            }),
                            selectionCb: e => {
                                Ut({
                                    type: Qe.IncrementalSnapshot,
                                    data: {
                                        source: Ze.Selection,
                                        ...e
                                    }
                                })
                            },
                            customElementCb: e => {
                                Ut({
                                    type: Qe.IncrementalSnapshot,
                                    data: {
                                        source: Ze.CustomElement,
                                        ...e
                                    }
                                })
                            },
                            blockClass: o,
                            ignoreClass: c,
                            ignoreSelector: l,
                            maskAllText: u,
                            maskTextClass: d,
                            unmaskTextClass: h,
                            maskTextSelector: p,
                            unmaskTextSelector: m,
                            maskInputOptions: H,
                            inlineStylesheet: f,
                            sampling: I,
                            recordDOM: T,
                            recordCanvas: M,
                            inlineImages: O,
                            userTriggeredOnInput: A,
                            collectFonts: D,
                            doc: e,
                            maskAttributeFn: k,
                            maskInputFn: v,
                            maskTextFn: b,
                            keepIframeSrcFn: N,
                            blockSelector: i,
                            unblockSelector: a,
                            slimDOMOptions: j,
                            dataURLOptions: C,
                            mirror: Wt,
                            iframeManager: Q,
                            stylesheetManager: X,
                            shadowDomManager: te,
                            processedNodeManager: Z,
                            canvasManager: ee,
                            ignoreCSSAttributes: F,
                            plugins: (0, r.x)([L, "optionalAccess", e => e.filter, "call", e => e((e => e.observer)), "optionalAccess", e => e.map, "call", e => e((e => ({
                                observer: e.observer,
                                options: e.options,
                                callback: t => Ut({
                                    type: Qe.Plugin,
                                    data: {
                                        plugin: e.name,
                                        payload: t
                                    }
                                })
                            })))]) || []
                        }, {});
                    Q.addLoadListener((n => {
                        try {
                            e.push(t(n.contentDocument))
                        } catch (e) {}
                    }));
                    const n = () => {
                        ne(), e.push(t(document))
                    };
                    return "interactive" === document.readyState || "complete" === document.readyState ? n() : (e.push(Me("DOMContentLoaded", (() => {
                        Ut({
                            type: Qe.DomContentLoaded,
                            data: {}
                        }), "DOMContentLoaded" === R && n()
                    }))), e.push(Me("load", (() => {
                        Ut({
                            type: Qe.Load,
                            data: {}
                        }), "load" === R && n()
                    }), window))), () => {
                        e.forEach((e => e())), Z.destroy(), zt = void 0, pt()
                    }
                } catch (e) {}
            }
            Ht.mirror = Wt, Ht.takeFullSnapshot = function(e) {
                if (!zt) throw new Error("please take full snapshot after start recording");
                zt(e)
            };
            const jt = ["info", "warn", "error", "log"];
            ! function() {
                let e = !1,
                    t = !1;
                const n = {
                    exception: () => {},
                    infoTick: () => {},
                    setConfig: n => {
                        e = n.captureExceptions, t = n.traceInternals
                    }
                };
                jt.forEach((e => {
                    n[e] = () => {}
                }))
            }();

            function $t(e) {
                return e > 9999999999 ? e : 1e3 * e
            }

            function qt(e) {
                return e > 9999999999 ? e / 1e3 : e
            }

            function Kt(e, t) {
                "sentry.transaction" !== t.category && (["ui.click", "ui.input"].includes(t.category) ? e.triggerUserActivity() : e.checkAndHandleExpiredSession(), e.addUpdate((() => (e.throttledAddEvent({
                    type: Qe.Custom,
                    timestamp: 1e3 * (t.timestamp || 0),
                    data: {
                        tag: "breadcrumb",
                        payload: (0, f.Fv)(t, 10, 1e3)
                    }
                }), "console" === t.category))))
            }

            function Vt(e) {
                return e.closest("button,a") || e
            }

            function Jt(e) {
                const t = Gt(e);
                return t && t instanceof Element ? Vt(t) : t
            }

            function Gt(e) {
                return function(e) {
                    return "object" == typeof e && !!e && "target" in e
                }(e) ? e.target : e
            }
            let Yt;

            function Xt(e) {
                return Yt || (Yt = [], (0, y.hl)(R, "open", (function(e) {
                    return function(...t) {
                        if (Yt) try {
                            Yt.forEach((e => e()))
                        } catch (e) {}
                        return e.apply(R, t)
                    }
                }))), Yt.push(e), () => {
                    const t = Yt ? Yt.indexOf(e) : -1;
                    t > -1 && Yt.splice(t, 1)
                }
            }
            const Qt = new Set([Ze.Mutation, Ze.StyleSheetRule, Ze.StyleDeclaration, Ze.AdoptedStyleSheet, Ze.CanvasMutation, Ze.Selection, Ze.MediaInteraction]);
            class Zt {
                constructor(e, t, n = Kt) {
                    this._lastMutation = 0, this._lastScroll = 0, this._clicks = [], this._timeout = t.timeout / 1e3, this._threshold = t.threshold / 1e3, this._scollTimeout = t.scrollTimeout / 1e3, this._replay = e, this._ignoreSelector = t.ignoreSelector, this._addBreadcrumbEvent = n
                }
                addListeners() {
                    const e = Xt((() => {
                        this._lastMutation = tn()
                    }));
                    this._teardown = () => {
                        e(), this._clicks = [], this._lastMutation = 0, this._lastScroll = 0
                    }
                }
                removeListeners() {
                    this._teardown && this._teardown(), this._checkClickTimeout && clearTimeout(this._checkClickTimeout)
                }
                handleClick(e, t) {
                    if (function(e, t) {
                            if (!en.includes(e.tagName)) return !0;
                            if ("INPUT" === e.tagName && !["submit", "button"].includes(e.getAttribute("type") || "")) return !0;
                            if ("A" === e.tagName && (e.hasAttribute("download") || e.hasAttribute("target") && "_self" !== e.getAttribute("target"))) return !0;
                            if (t && e.matches(t)) return !0;
                            return !1
                        }(t, this._ignoreSelector) || ! function(e) {
                            return !(!e.data || "number" != typeof e.data.nodeId || !e.timestamp)
                        }(e)) return;
                    const n = {
                        timestamp: qt(e.timestamp),
                        clickBreadcrumb: e,
                        clickCount: 0,
                        node: t
                    };
                    this._clicks.some((e => e.node === n.node && Math.abs(e.timestamp - n.timestamp) < 1)) || (this._clicks.push(n), 1 === this._clicks.length && this._scheduleCheckClicks())
                }
                registerMutation(e = Date.now()) {
                    this._lastMutation = qt(e)
                }
                registerScroll(e = Date.now()) {
                    this._lastScroll = qt(e)
                }
                registerClick(e) {
                    const t = Vt(e);
                    this._handleMultiClick(t)
                }
                _handleMultiClick(e) {
                    this._getClicks(e).forEach((e => {
                        e.clickCount++
                    }))
                }
                _getClicks(e) {
                    return this._clicks.filter((t => t.node === e))
                }
                _checkClicks() {
                    const e = [],
                        t = tn();
                    this._clicks.forEach((n => {
                        !n.mutationAfter && this._lastMutation && (n.mutationAfter = n.timestamp <= this._lastMutation ? this._lastMutation - n.timestamp : void 0), !n.scrollAfter && this._lastScroll && (n.scrollAfter = n.timestamp <= this._lastScroll ? this._lastScroll - n.timestamp : void 0), n.timestamp + this._timeout <= t && e.push(n)
                    }));
                    for (const t of e) {
                        const e = this._clicks.indexOf(t);
                        e > -1 && (this._generateBreadcrumbs(t), this._clicks.splice(e, 1))
                    }
                    this._clicks.length && this._scheduleCheckClicks()
                }
                _generateBreadcrumbs(e) {
                    const t = this._replay,
                        n = e.scrollAfter && e.scrollAfter <= this._scollTimeout,
                        s = e.mutationAfter && e.mutationAfter <= this._threshold,
                        r = !n && !s,
                        {
                            clickCount: o,
                            clickBreadcrumb: i
                        } = e;
                    if (r) {
                        const n = 1e3 * Math.min(e.mutationAfter || this._timeout, this._timeout),
                            s = n < 1e3 * this._timeout ? "mutation" : "timeout",
                            r = {
                                type: "default",
                                message: i.message,
                                timestamp: i.timestamp,
                                category: "ui.slowClickDetected",
                                data: { ...i.data,
                                    url: R.location.href,
                                    route: t.getCurrentRoute(),
                                    timeAfterClickMs: n,
                                    endReason: s,
                                    clickCount: o || 1
                                }
                            };
                        this._addBreadcrumbEvent(t, r)
                    } else if (o > 1) {
                        const e = {
                            type: "default",
                            message: i.message,
                            timestamp: i.timestamp,
                            category: "ui.multiClick",
                            data: { ...i.data,
                                url: R.location.href,
                                route: t.getCurrentRoute(),
                                clickCount: o,
                                metric: !0
                            }
                        };
                        this._addBreadcrumbEvent(t, e)
                    }
                }
                _scheduleCheckClicks() {
                    this._checkClickTimeout && clearTimeout(this._checkClickTimeout), this._checkClickTimeout = (0, C.iK)((() => this._checkClicks()), 1e3)
                }
            }
            const en = ["A", "BUTTON", "INPUT"];

            function tn() {
                return Date.now() / 1e3
            }

            function nn(e, t) {
                try {
                    if (! function(e) {
                            return 3 === e.type
                        }(t)) return;
                    const {
                        source: n
                    } = t.data;
                    if (Qt.has(n) && e.registerMutation(t.timestamp), n === Ze.Scroll && e.registerScroll(t.timestamp), function(e) {
                            return e.data.source === Ze.MouseInteraction
                        }(t)) {
                        const {
                            type: n,
                            id: s
                        } = t.data, r = Ht.mirror.getNode(s);
                        r instanceof HTMLElement && n === et.Click && e.registerClick(r)
                    }
                } catch (e) {}
            }

            function sn(e) {
                return {
                    timestamp: Date.now() / 1e3,
                    type: "default",
                    ...e
                }
            }
            var rn;
            ! function(e) {
                e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment"
            }(rn || (rn = {}));
            const on = new Set(["id", "class", "aria-label", "role", "name", "alt", "title", "data-test-id", "data-testid", "disabled", "aria-disabled", "data-sentry-component"]);

            function an(e) {
                const t = {};
                !e["data-sentry-component"] && e["data-sentry-element"] && (e["data-sentry-component"] = e["data-sentry-element"]);
                for (const n in e)
                    if (on.has(n)) {
                        let s = n;
                        "data-testid" !== n && "data-test-id" !== n || (s = "testId"), t[s] = e[n]
                    }
                return t
            }
            const cn = e => t => {
                if (!e.isEnabled()) return;
                const n = function(e) {
                    const {
                        target: t,
                        message: n
                    } = function(e) {
                        const t = "click" === e.name;
                        let n, s = null;
                        try {
                            s = t ? Jt(e.event) : Gt(e.event), n = (0, g.Rt)(s, {
                                maxStringLength: 200
                            }) || "<unknown>"
                        } catch (e) {
                            n = "<unknown>"
                        }
                        return {
                            target: s,
                            message: n
                        }
                    }(e);
                    return sn({
                        category: `ui.${e.name}`,
                        ...ln(t, n)
                    })
                }(t);
                if (!n) return;
                const s = "click" === t.name,
                    r = s ? t.event : void 0;
                var o, i, a;
                !(s && e.clickDetector && r && r.target) || r.altKey || r.metaKey || r.ctrlKey || r.shiftKey || (o = e.clickDetector, i = n, a = Jt(t.event), o.handleClick(i, a)), Kt(e, n)
            };

            function ln(e, t) {
                const n = Ht.mirror.getId(e),
                    s = n && Ht.mirror.getNode(n),
                    r = s && Ht.mirror.getMeta(s),
                    o = r && function(e) {
                        return e.type === rn.Element
                    }(r) ? r : null;
                return {
                    message: t,
                    data: o ? {
                        nodeId: n,
                        node: {
                            id: n,
                            tagName: o.tagName,
                            textContent: Array.from(o.childNodes).map((e => e.type === rn.Text && e.textContent)).filter(Boolean).map((e => e.trim())).join(""),
                            attributes: an(o.attributes)
                        }
                    } : {}
                }
            }

            function un(e, t) {
                if (!e.isEnabled()) return;
                e.updateUserActivity();
                const n = function(e) {
                    const {
                        metaKey: t,
                        shiftKey: n,
                        ctrlKey: s,
                        altKey: r,
                        key: o,
                        target: i
                    } = e;
                    if (!i || function(e) {
                            return "INPUT" === e.tagName || "TEXTAREA" === e.tagName || e.isContentEditable
                        }(i) || !o) return null;
                    const a = t || s || r,
                        c = 1 === o.length;
                    if (!a && c) return null;
                    const l = (0, g.Rt)(i, {
                            maxStringLength: 200
                        }) || "<unknown>",
                        u = ln(i, l);
                    return sn({
                        category: "ui.keyDown",
                        message: l,
                        data: { ...u.data,
                            metaKey: t,
                            shiftKey: n,
                            ctrlKey: s,
                            altKey: r,
                            key: o
                        }
                    })
                }(t);
                n && Kt(e, n)
            }
            const dn = {
                resource: function(e) {
                    const {
                        entryType: t,
                        initiatorType: n,
                        name: s,
                        responseEnd: r,
                        startTime: o,
                        decodedBodySize: i,
                        encodedBodySize: a,
                        responseStatus: c,
                        transferSize: l
                    } = e;
                    if (["fetch", "xmlhttprequest"].includes(n)) return null;
                    return {
                        type: `${t}.${n}`,
                        start: mn(o),
                        end: mn(r),
                        name: s,
                        data: {
                            size: l,
                            statusCode: c,
                            decodedBodySize: i,
                            encodedBodySize: a
                        }
                    }
                },
                paint: function(e) {
                    const {
                        duration: t,
                        entryType: n,
                        name: s,
                        startTime: r
                    } = e, o = mn(r);
                    return {
                        type: n,
                        name: s,
                        start: o,
                        end: o + t,
                        data: void 0
                    }
                },
                navigation: function(e) {
                    const {
                        entryType: t,
                        name: n,
                        decodedBodySize: s,
                        duration: r,
                        domComplete: o,
                        encodedBodySize: i,
                        domContentLoadedEventStart: a,
                        domContentLoadedEventEnd: c,
                        domInteractive: l,
                        loadEventStart: u,
                        loadEventEnd: d,
                        redirectCount: h,
                        startTime: p,
                        transferSize: m,
                        type: f
                    } = e;
                    if (0 === r) return null;
                    return {
                        type: `${t}.${f}`,
                        start: mn(p),
                        end: mn(o),
                        name: n,
                        data: {
                            size: m,
                            decodedBodySize: s,
                            encodedBodySize: i,
                            duration: r,
                            domInteractive: l,
                            domContentLoadedEventStart: a,
                            domContentLoadedEventEnd: c,
                            loadEventStart: u,
                            loadEventEnd: d,
                            domComplete: o,
                            redirectCount: h
                        }
                    }
                }
            };

            function hn(e, t) {
                return ({
                    metric: n
                }) => {
                    t.replayPerformanceEntries.push(e(n))
                }
            }

            function pn(e) {
                const t = dn[e.entryType];
                return t ? t(e) : null
            }

            function mn(e) {
                return ((S.Z1 || R.performance.timeOrigin) + e) / 1e3
            }

            function fn(e) {
                const t = e.entries[e.entries.length - 1];
                return vn(e, "largest-contentful-paint", t && t.element ? [t.element] : void 0)
            }

            function yn(e) {
                return void 0 !== e.sources
            }

            function gn(e) {
                const t = [],
                    n = [];
                for (const s of e.entries)
                    if (yn(s)) {
                        const e = [];
                        for (const t of s.sources)
                            if (t.node) {
                                n.push(t.node);
                                const s = Ht.mirror.getId(t.node);
                                s && e.push(s)
                            }
                        t.push({
                            value: s.value,
                            nodeIds: e.length ? e : void 0
                        })
                    }
                return vn(e, "cumulative-layout-shift", n, t)
            }

            function Sn(e) {
                const t = e.entries[e.entries.length - 1];
                return vn(e, "first-input-delay", t && t.target ? [t.target] : void 0)
            }

            function kn(e) {
                const t = e.entries[e.entries.length - 1];
                return vn(e, "interaction-to-next-paint", t && t.target ? [t.target] : void 0)
            }

            function vn(e, t, n, s) {
                const r = e.value,
                    o = e.rating,
                    i = mn(r);
                return {
                    type: "web-vital",
                    name: t,
                    start: i,
                    end: i,
                    data: {
                        value: r,
                        size: r,
                        rating: o,
                        nodeIds: n ? n.map((e => Ht.mirror.getId(e))) : void 0,
                        attributions: s
                    }
                }
            }
            class bn extends Error {
                constructor() {
                    super("Event buffer exceeded maximum size of 20000000.")
                }
            }
            class _n {
                constructor() {
                    this.events = [], this._totalSize = 0, this.hasCheckout = !1
                }
                get hasEvents() {
                    return this.events.length > 0
                }
                get type() {
                    return "sync"
                }
                destroy() {
                    this.events = []
                }
                async addEvent(e) {
                    const t = JSON.stringify(e).length;
                    if (this._totalSize += t, this._totalSize > N) throw new bn;
                    this.events.push(e)
                }
                finish() {
                    return new Promise((e => {
                        const t = this.events;
                        this.clear(), e(JSON.stringify(t))
                    }))
                }
                clear() {
                    this.events = [], this._totalSize = 0, this.hasCheckout = !1
                }
                getEarliestTimestamp() {
                    const e = this.events.map((e => e.timestamp)).sort()[0];
                    return e ? $t(e) : null
                }
            }
            class wn {
                constructor(e) {
                    this._worker = e, this._id = 0
                }
                ensureReady() {
                    return this._ensureReadyPromise || (this._ensureReadyPromise = new Promise(((e, t) => {
                        this._worker.addEventListener("message", (({
                            data: n
                        }) => {
                            n.success ? e() : t()
                        }), {
                            once: !0
                        }), this._worker.addEventListener("error", (e => {
                            t(e)
                        }), {
                            once: !0
                        })
                    }))), this._ensureReadyPromise
                }
                destroy() {
                    this._worker.terminate()
                }
                postMessage(e, t) {
                    const n = this._getAndIncrementId();
                    return new Promise(((s, r) => {
                        const o = ({
                            data: t
                        }) => {
                            const i = t;
                            i.method === e && i.id === n && (this._worker.removeEventListener("message", o), i.success ? s(i.response) : r(new Error("Error in compression worker")))
                        };
                        this._worker.addEventListener("message", o), this._worker.postMessage({
                            id: n,
                            method: e,
                            arg: t
                        })
                    }))
                }
                _getAndIncrementId() {
                    return this._id++
                }
            }
            class In {
                constructor(e) {
                    this._worker = new wn(e), this._earliestTimestamp = null, this._totalSize = 0, this.hasCheckout = !1
                }
                get hasEvents() {
                    return !!this._earliestTimestamp
                }
                get type() {
                    return "worker"
                }
                ensureReady() {
                    return this._worker.ensureReady()
                }
                destroy() {
                    this._worker.destroy()
                }
                addEvent(e) {
                    const t = $t(e.timestamp);
                    (!this._earliestTimestamp || t < this._earliestTimestamp) && (this._earliestTimestamp = t);
                    const n = JSON.stringify(e);
                    return this._totalSize += n.length, this._totalSize > N ? Promise.reject(new bn) : this._sendEventToWorker(n)
                }
                finish() {
                    return this._finishRequest()
                }
                clear() {
                    this._earliestTimestamp = null, this._totalSize = 0, this.hasCheckout = !1, this._worker.postMessage("clear").then(null, (e => {}))
                }
                getEarliestTimestamp() {
                    return this._earliestTimestamp
                }
                _sendEventToWorker(e) {
                    return this._worker.postMessage("addEvent", e)
                }
                async _finishRequest() {
                    const e = await this._worker.postMessage("finish");
                    return this._earliestTimestamp = null, this._totalSize = 0, e
                }
            }
            class Cn {
                constructor(e) {
                    this._fallback = new _n, this._compression = new In(e), this._used = this._fallback, this._ensureWorkerIsLoadedPromise = this._ensureWorkerIsLoaded()
                }
                get type() {
                    return this._used.type
                }
                get hasEvents() {
                    return this._used.hasEvents
                }
                get hasCheckout() {
                    return this._used.hasCheckout
                }
                set hasCheckout(e) {
                    this._used.hasCheckout = e
                }
                destroy() {
                    this._fallback.destroy(), this._compression.destroy()
                }
                clear() {
                    return this._used.clear()
                }
                getEarliestTimestamp() {
                    return this._used.getEarliestTimestamp()
                }
                addEvent(e) {
                    return this._used.addEvent(e)
                }
                async finish() {
                    return await this.ensureWorkerIsLoaded(), this._used.finish()
                }
                ensureWorkerIsLoaded() {
                    return this._ensureWorkerIsLoadedPromise
                }
                async _ensureWorkerIsLoaded() {
                    try {
                        await this._compression.ensureReady()
                    } catch (e) {
                        return
                    }
                    await this._switchToCompressionWorker()
                }
                async _switchToCompressionWorker() {
                    const {
                        events: e,
                        hasCheckout: t
                    } = this._fallback, n = [];
                    for (const t of e) n.push(this._compression.addEvent(t));
                    this._compression.hasCheckout = t, this._used = this._compression;
                    try {
                        await Promise.all(n), this._fallback.clear()
                    } catch (e) {}
                }
            }

            function En({
                useCompression: e,
                workerUrl: t
            }) {
                if (e && window.Worker) {
                    const e = function(e) {
                        try {
                            const t = e || function() {
                                if ("undefined" == typeof __SENTRY_EXCLUDE_REPLAY_WORKER__ || !__SENTRY_EXCLUDE_REPLAY_WORKER__) return function() {
                                    const e = new Blob(['var t=Uint8Array,n=Uint16Array,r=Int32Array,e=new t([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),i=new t([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),a=new t([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),s=function(t,e){for(var i=new n(31),a=0;a<31;++a)i[a]=e+=1<<t[a-1];var s=new r(i[30]);for(a=1;a<30;++a)for(var o=i[a];o<i[a+1];++o)s[o]=o-i[a]<<5|a;return{b:i,r:s}},o=s(e,2),f=o.b,h=o.r;f[28]=258,h[258]=28;for(var l=s(i,0).r,u=new n(32768),c=0;c<32768;++c){var v=(43690&c)>>1|(21845&c)<<1;v=(61680&(v=(52428&v)>>2|(13107&v)<<2))>>4|(3855&v)<<4,u[c]=((65280&v)>>8|(255&v)<<8)>>1}var d=function(t,r,e){for(var i=t.length,a=0,s=new n(r);a<i;++a)t[a]&&++s[t[a]-1];var o,f=new n(r);for(a=1;a<r;++a)f[a]=f[a-1]+s[a-1]<<1;if(e){o=new n(1<<r);var h=15-r;for(a=0;a<i;++a)if(t[a])for(var l=a<<4|t[a],c=r-t[a],v=f[t[a]-1]++<<c,d=v|(1<<c)-1;v<=d;++v)o[u[v]>>h]=l}else for(o=new n(i),a=0;a<i;++a)t[a]&&(o[a]=u[f[t[a]-1]++]>>15-t[a]);return o},g=new t(288);for(c=0;c<144;++c)g[c]=8;for(c=144;c<256;++c)g[c]=9;for(c=256;c<280;++c)g[c]=7;for(c=280;c<288;++c)g[c]=8;var w=new t(32);for(c=0;c<32;++c)w[c]=5;var p=d(g,9,0),y=d(w,5,0),m=function(t){return(t+7)/8|0},b=function(n,r,e){return(null==r||r<0)&&(r=0),(null==e||e>n.length)&&(e=n.length),new t(n.subarray(r,e))},M=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],E=function(t,n,r){var e=new Error(n||M[t]);if(e.code=t,Error.captureStackTrace&&Error.captureStackTrace(e,E),!r)throw e;return e},z=function(t,n,r){r<<=7&n;var e=n/8|0;t[e]|=r,t[e+1]|=r>>8},A=function(t,n,r){r<<=7&n;var e=n/8|0;t[e]|=r,t[e+1]|=r>>8,t[e+2]|=r>>16},_=function(r,e){for(var i=[],a=0;a<r.length;++a)r[a]&&i.push({s:a,f:r[a]});var s=i.length,o=i.slice();if(!s)return{t:F,l:0};if(1==s){var f=new t(i[0].s+1);return f[i[0].s]=1,{t:f,l:1}}i.sort((function(t,n){return t.f-n.f})),i.push({s:-1,f:25001});var h=i[0],l=i[1],u=0,c=1,v=2;for(i[0]={s:-1,f:h.f+l.f,l:h,r:l};c!=s-1;)h=i[i[u].f<i[v].f?u++:v++],l=i[u!=c&&i[u].f<i[v].f?u++:v++],i[c++]={s:-1,f:h.f+l.f,l:h,r:l};var d=o[0].s;for(a=1;a<s;++a)o[a].s>d&&(d=o[a].s);var g=new n(d+1),w=x(i[c-1],g,0);if(w>e){a=0;var p=0,y=w-e,m=1<<y;for(o.sort((function(t,n){return g[n.s]-g[t.s]||t.f-n.f}));a<s;++a){var b=o[a].s;if(!(g[b]>e))break;p+=m-(1<<w-g[b]),g[b]=e}for(p>>=y;p>0;){var M=o[a].s;g[M]<e?p-=1<<e-g[M]++-1:++a}for(;a>=0&&p;--a){var E=o[a].s;g[E]==e&&(--g[E],++p)}w=e}return{t:new t(g),l:w}},x=function(t,n,r){return-1==t.s?Math.max(x(t.l,n,r+1),x(t.r,n,r+1)):n[t.s]=r},D=function(t){for(var r=t.length;r&&!t[--r];);for(var e=new n(++r),i=0,a=t[0],s=1,o=function(t){e[i++]=t},f=1;f<=r;++f)if(t[f]==a&&f!=r)++s;else{if(!a&&s>2){for(;s>138;s-=138)o(32754);s>2&&(o(s>10?s-11<<5|28690:s-3<<5|12305),s=0)}else if(s>3){for(o(a),--s;s>6;s-=6)o(8304);s>2&&(o(s-3<<5|8208),s=0)}for(;s--;)o(a);s=1,a=t[f]}return{c:e.subarray(0,i),n:r}},T=function(t,n){for(var r=0,e=0;e<n.length;++e)r+=t[e]*n[e];return r},k=function(t,n,r){var e=r.length,i=m(n+2);t[i]=255&e,t[i+1]=e>>8,t[i+2]=255^t[i],t[i+3]=255^t[i+1];for(var a=0;a<e;++a)t[i+a+4]=r[a];return 8*(i+4+e)},C=function(t,r,s,o,f,h,l,u,c,v,m){z(r,m++,s),++f[256];for(var b=_(f,15),M=b.t,E=b.l,x=_(h,15),C=x.t,U=x.l,F=D(M),I=F.c,S=F.n,L=D(C),O=L.c,j=L.n,q=new n(19),B=0;B<I.length;++B)++q[31&I[B]];for(B=0;B<O.length;++B)++q[31&O[B]];for(var G=_(q,7),H=G.t,J=G.l,K=19;K>4&&!H[a[K-1]];--K);var N,P,Q,R,V=v+5<<3,W=T(f,g)+T(h,w)+l,X=T(f,M)+T(h,C)+l+14+3*K+T(q,H)+2*q[16]+3*q[17]+7*q[18];if(c>=0&&V<=W&&V<=X)return k(r,m,t.subarray(c,c+v));if(z(r,m,1+(X<W)),m+=2,X<W){N=d(M,E,0),P=M,Q=d(C,U,0),R=C;var Y=d(H,J,0);z(r,m,S-257),z(r,m+5,j-1),z(r,m+10,K-4),m+=14;for(B=0;B<K;++B)z(r,m+3*B,H[a[B]]);m+=3*K;for(var Z=[I,O],$=0;$<2;++$){var tt=Z[$];for(B=0;B<tt.length;++B){var nt=31&tt[B];z(r,m,Y[nt]),m+=H[nt],nt>15&&(z(r,m,tt[B]>>5&127),m+=tt[B]>>12)}}}else N=p,P=g,Q=y,R=w;for(B=0;B<u;++B){var rt=o[B];if(rt>255){A(r,m,N[(nt=rt>>18&31)+257]),m+=P[nt+257],nt>7&&(z(r,m,rt>>23&31),m+=e[nt]);var et=31&rt;A(r,m,Q[et]),m+=R[et],et>3&&(A(r,m,rt>>5&8191),m+=i[et])}else A(r,m,N[rt]),m+=P[rt]}return A(r,m,N[256]),m+P[256]},U=new r([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),F=new t(0),I=function(){for(var t=new Int32Array(256),n=0;n<256;++n){for(var r=n,e=9;--e;)r=(1&r&&-306674912)^r>>>1;t[n]=r}return t}(),S=function(){var t=-1;return{p:function(n){for(var r=t,e=0;e<n.length;++e)r=I[255&r^n[e]]^r>>>8;t=r},d:function(){return~t}}},L=function(){var t=1,n=0;return{p:function(r){for(var e=t,i=n,a=0|r.length,s=0;s!=a;){for(var o=Math.min(s+2655,a);s<o;++s)i+=e+=r[s];e=(65535&e)+15*(e>>16),i=(65535&i)+15*(i>>16)}t=e,n=i},d:function(){return(255&(t%=65521))<<24|(65280&t)<<8|(255&(n%=65521))<<8|n>>8}}},O=function(a,s,o,f,u){if(!u&&(u={l:1},s.dictionary)){var c=s.dictionary.subarray(-32768),v=new t(c.length+a.length);v.set(c),v.set(a,c.length),a=v,u.w=c.length}return function(a,s,o,f,u,c){var v=c.z||a.length,d=new t(f+v+5*(1+Math.ceil(v/7e3))+u),g=d.subarray(f,d.length-u),w=c.l,p=7&(c.r||0);if(s){p&&(g[0]=c.r>>3);for(var y=U[s-1],M=y>>13,E=8191&y,z=(1<<o)-1,A=c.p||new n(32768),_=c.h||new n(z+1),x=Math.ceil(o/3),D=2*x,T=function(t){return(a[t]^a[t+1]<<x^a[t+2]<<D)&z},F=new r(25e3),I=new n(288),S=new n(32),L=0,O=0,j=c.i||0,q=0,B=c.w||0,G=0;j+2<v;++j){var H=T(j),J=32767&j,K=_[H];if(A[J]=K,_[H]=J,B<=j){var N=v-j;if((L>7e3||q>24576)&&(N>423||!w)){p=C(a,g,0,F,I,S,O,q,G,j-G,p),q=L=O=0,G=j;for(var P=0;P<286;++P)I[P]=0;for(P=0;P<30;++P)S[P]=0}var Q=2,R=0,V=E,W=J-K&32767;if(N>2&&H==T(j-W))for(var X=Math.min(M,N)-1,Y=Math.min(32767,j),Z=Math.min(258,N);W<=Y&&--V&&J!=K;){if(a[j+Q]==a[j+Q-W]){for(var $=0;$<Z&&a[j+$]==a[j+$-W];++$);if($>Q){if(Q=$,R=W,$>X)break;var tt=Math.min(W,$-2),nt=0;for(P=0;P<tt;++P){var rt=j-W+P&32767,et=rt-A[rt]&32767;et>nt&&(nt=et,K=rt)}}}W+=(J=K)-(K=A[J])&32767}if(R){F[q++]=268435456|h[Q]<<18|l[R];var it=31&h[Q],at=31&l[R];O+=e[it]+i[at],++I[257+it],++S[at],B=j+Q,++L}else F[q++]=a[j],++I[a[j]]}}for(j=Math.max(j,B);j<v;++j)F[q++]=a[j],++I[a[j]];p=C(a,g,w,F,I,S,O,q,G,j-G,p),w||(c.r=7&p|g[p/8|0]<<3,p-=7,c.h=_,c.p=A,c.i=j,c.w=B)}else{for(j=c.w||0;j<v+w;j+=65535){var st=j+65535;st>=v&&(g[p/8|0]=w,st=v),p=k(g,p+1,a.subarray(j,st))}c.i=v}return b(d,0,f+m(p)+u)}(a,null==s.level?6:s.level,null==s.mem?Math.ceil(1.5*Math.max(8,Math.min(13,Math.log(a.length)))):12+s.mem,o,f,u)},j=function(t,n,r){for(;r;++n)t[n]=r,r>>>=8},q=function(t,n){var r=n.filename;if(t[0]=31,t[1]=139,t[2]=8,t[8]=n.level<2?4:9==n.level?2:0,t[9]=3,0!=n.mtime&&j(t,4,Math.floor(new Date(n.mtime||Date.now())/1e3)),r){t[3]=8;for(var e=0;e<=r.length;++e)t[e+10]=r.charCodeAt(e)}},B=function(t){return 10+(t.filename?t.filename.length+1:0)},G=function(){function n(n,r){if("function"==typeof n&&(r=n,n={}),this.ondata=r,this.o=n||{},this.s={l:0,i:32768,w:32768,z:32768},this.b=new t(98304),this.o.dictionary){var e=this.o.dictionary.subarray(-32768);this.b.set(e,32768-e.length),this.s.i=32768-e.length}}return n.prototype.p=function(t,n){this.ondata(O(t,this.o,0,0,this.s),n)},n.prototype.push=function(n,r){this.ondata||E(5),this.s.l&&E(4);var e=n.length+this.s.z;if(e>this.b.length){if(e>2*this.b.length-32768){var i=new t(-32768&e);i.set(this.b.subarray(0,this.s.z)),this.b=i}var a=this.b.length-this.s.z;a&&(this.b.set(n.subarray(0,a),this.s.z),this.s.z=this.b.length,this.p(this.b,!1)),this.b.set(this.b.subarray(-32768)),this.b.set(n.subarray(a),32768),this.s.z=n.length-a+32768,this.s.i=32766,this.s.w=32768}else this.b.set(n,this.s.z),this.s.z+=n.length;this.s.l=1&r,(this.s.z>this.s.w+8191||r)&&(this.p(this.b,r||!1),this.s.w=this.s.i,this.s.i-=2)},n}();var H=function(){function t(t,n){this.c=L(),this.v=1,G.call(this,t,n)}return t.prototype.push=function(t,n){this.c.p(t),G.prototype.push.call(this,t,n)},t.prototype.p=function(t,n){var r=O(t,this.o,this.v&&(this.o.dictionary?6:2),n&&4,this.s);this.v&&(function(t,n){var r=n.level,e=0==r?0:r<6?1:9==r?3:2;if(t[0]=120,t[1]=e<<6|(n.dictionary&&32),t[1]|=31-(t[0]<<8|t[1])%31,n.dictionary){var i=L();i.p(n.dictionary),j(t,2,i.d())}}(r,this.o),this.v=0),n&&j(r,r.length-4,this.c.d()),this.ondata(r,n)},t}(),J="undefined"!=typeof TextEncoder&&new TextEncoder,K="undefined"!=typeof TextDecoder&&new TextDecoder;try{K.decode(F,{stream:!0})}catch(t){}var N=function(){function t(t){this.ondata=t}return t.prototype.push=function(t,n){this.ondata||E(5),this.d&&E(4),this.ondata(P(t),this.d=n||!1)},t}();function P(n,r){if(r){for(var e=new t(n.length),i=0;i<n.length;++i)e[i]=n.charCodeAt(i);return e}if(J)return J.encode(n);var a=n.length,s=new t(n.length+(n.length>>1)),o=0,f=function(t){s[o++]=t};for(i=0;i<a;++i){if(o+5>s.length){var h=new t(o+8+(a-i<<1));h.set(s),s=h}var l=n.charCodeAt(i);l<128||r?f(l):l<2048?(f(192|l>>6),f(128|63&l)):l>55295&&l<57344?(f(240|(l=65536+(1047552&l)|1023&n.charCodeAt(++i))>>18),f(128|l>>12&63),f(128|l>>6&63),f(128|63&l)):(f(224|l>>12),f(128|l>>6&63),f(128|63&l))}return b(s,0,o)}function Q(t){return function(t,n){n||(n={});var r=S(),e=t.length;r.p(t);var i=O(t,n,B(n),8),a=i.length;return q(i,n),j(i,a-8,r.d()),j(i,a-4,e),i}(P(t))}const R=new class{constructor(){this._init()}clear(){this._init()}addEvent(t){if(!t)throw new Error("Adding invalid event");const n=this._hasEvents?",":"";this.stream.push(n+t),this._hasEvents=!0}finish(){this.stream.push("]",!0);const t=function(t){let n=0;for(const r of t)n+=r.length;const r=new Uint8Array(n);for(let n=0,e=0,i=t.length;n<i;n++){const i=t[n];r.set(i,e),e+=i.length}return r}(this._deflatedData);return this._init(),t}_init(){this._hasEvents=!1,this._deflatedData=[],this.deflate=new H,this.deflate.ondata=(t,n)=>{this._deflatedData.push(t)},this.stream=new N(((t,n)=>{this.deflate.push(t,n)})),this.stream.push("[")}},V={clear:()=>{R.clear()},addEvent:t=>R.addEvent(t),finish:()=>R.finish(),compress:t=>Q(t)};addEventListener("message",(function(t){const n=t.data.method,r=t.data.id,e=t.data.arg;if(n in V&&"function"==typeof V[n])try{const t=V[n](e);postMessage({id:r,method:n,success:!0,response:t})}catch(t){postMessage({id:r,method:n,success:!1,response:t.message}),console.error(t)}})),postMessage({id:void 0,method:"init",success:!0,response:void 0});']);
                                    return URL.createObjectURL(e)
                                }();
                                return ""
                            }();
                            if (!t) return;
                            const n = new Worker(t);
                            return new Cn(n)
                        } catch (e) {}
                    }(t);
                    if (e) return e
                }
                return new _n
            }

            function Tn() {
                try {
                    return "sessionStorage" in R && !!R.sessionStorage
                } catch (e) {
                    return !1
                }
            }

            function Mn(e) {
                ! function() {
                    if (!Tn()) return;
                    try {
                        R.sessionStorage.removeItem(A)
                    } catch (e) {}
                }(), e.session = void 0
            }

            function xn(e) {
                return void 0 !== e && Math.random() < e
            }

            function Rn(e) {
                const t = Date.now();
                return {
                    id: e.id || (0, k.DM)(),
                    started: e.started || t,
                    lastActivity: e.lastActivity || t,
                    segmentId: e.segmentId || 0,
                    sampled: e.sampled,
                    previousSessionId: e.previousSessionId
                }
            }

            function An(e) {
                if (Tn()) try {
                    R.sessionStorage.setItem(A, JSON.stringify(e))
                } catch (e) {}
            }

            function Dn({
                sessionSampleRate: e,
                allowBuffering: t,
                stickySession: n = !1
            }, {
                previousSessionId: s
            } = {}) {
                const r = function(e, t) {
                        return xn(e) ? "session" : !!t && "buffer"
                    }(e, t),
                    o = Rn({
                        sampled: r,
                        previousSessionId: s
                    });
                return n && An(o), o
            }

            function On(e, t, n = +new Date) {
                return null === e || void 0 === t || t < 0 || 0 !== t && e + t <= n
            }

            function Ln(e, {
                maxReplayDuration: t,
                sessionIdleExpire: n,
                targetTime: s = Date.now()
            }) {
                return On(e.started, t, s) || On(e.lastActivity, n, s)
            }

            function Nn(e, {
                sessionIdleExpire: t,
                maxReplayDuration: n
            }) {
                return !!Ln(e, {
                    sessionIdleExpire: t,
                    maxReplayDuration: n
                }) && ("buffer" !== e.sampled || 0 !== e.segmentId)
            }

            function Fn({
                sessionIdleExpire: e,
                maxReplayDuration: t,
                previousSessionId: n
            }, s) {
                const r = s.stickySession && function() {
                    if (!Tn()) return null;
                    try {
                        const e = R.sessionStorage.getItem(A);
                        return e ? Rn(JSON.parse(e)) : null
                    } catch (e) {
                        return null
                    }
                }();
                return r ? Nn(r, {
                    sessionIdleExpire: e,
                    maxReplayDuration: t
                }) ? Dn(s, {
                    previousSessionId: r.id
                }) : r : Dn(s, {
                    previousSessionId: n
                })
            }

            function Bn(e, t, n) {
                return !!Un(e, t) && (Pn(e, t, n), !0)
            }
            async function Pn(e, t, n) {
                if (!e.eventBuffer) return null;
                try {
                    n && "buffer" === e.recordingMode && e.eventBuffer.clear(), n && (e.eventBuffer.hasCheckout = !0);
                    const s = function(e, t) {
                        try {
                            if ("function" == typeof t && function(e) {
                                    return e.type === Qe.Custom
                                }(e)) return t(e)
                        } catch (e) {
                            return null
                        }
                        return e
                    }(t, e.getOptions().beforeAddRecordingEvent);
                    if (!s) return;
                    return await e.eventBuffer.addEvent(s)
                } catch (t) {
                    const n = t && t instanceof bn ? "addEventSizeExceeded" : "addEvent";
                    e.handleException(t), await e.stop({
                        reason: n
                    });
                    const s = (0, i.s3)();
                    s && s.recordDroppedEvent("internal_sdk_error", "replay")
                }
            }

            function Un(e, t) {
                if (!e.eventBuffer || e.isPaused() || !e.isEnabled()) return !1;
                const n = $t(t.timestamp);
                return !(n + e.timeouts.sessionIdlePause < Date.now()) && !(n > e.getContext().initialTimestamp + e.getOptions().maxReplayDuration)
            }

            function zn(e) {
                return !e.type
            }

            function Wn(e) {
                return "transaction" === e.type
            }

            function Hn(e) {
                return "feedback" === e.type
            }

            function jn(e) {
                return (t, n) => {
                    if (!e.isEnabled() || !zn(t) && !Wn(t)) return;
                    const s = n && n.statusCode;
                    !s || s < 200 || s >= 300 || (Wn(t) ? function(e, t) {
                        const n = e.getContext();
                        t.contexts && t.contexts.trace && t.contexts.trace.trace_id && n.traceIds.size < 100 && n.traceIds.add(t.contexts.trace.trace_id)
                    }(e, t) : function(e, t) {
                        const n = e.getContext();
                        t.event_id && n.errorIds.size < 100 && n.errorIds.add(t.event_id);
                        if ("buffer" !== e.recordingMode || !t.tags || !t.tags.replayId) return;
                        const {
                            beforeErrorSampling: s
                        } = e.getOptions();
                        if ("function" == typeof s && !s(t)) return;
                        (0, C.iK)((async () => {
                            try {
                                await e.sendBufferedReplayOrFlush()
                            } catch (t) {
                                e.handleException(t)
                            }
                        }))
                    }(e, t))
                }
            }

            function $n(e) {
                return t => {
                    e.isEnabled() && zn(t) && function(e, t) {
                        const n = t.exception && t.exception.values && t.exception.values[0] && t.exception.values[0].value;
                        if ("string" != typeof n) return;
                        if (n.match(/(reactjs\.org\/docs\/error-decoder\.html\?invariant=|react\.dev\/errors\/)(418|419|422|423|425)/) || n.match(/(does not match server-rendered HTML|Hydration failed because)/i)) {
                            Kt(e, sn({
                                category: "replay.hydrate-error",
                                data: {
                                    url: (0, g.l4)()
                                }
                            }))
                        }
                    }(e, t)
                }
            }

            function qn(e) {
                const t = (0, i.s3)();
                t && t.on("beforeAddBreadcrumb", (t => function(e, t) {
                    if (!e.isEnabled() || !Kn(t)) return;
                    const n = function(e) {
                        if (!Kn(e) || ["fetch", "xhr", "sentry.event", "sentry.transaction"].includes(e.category) || e.category.startsWith("ui.")) return null;
                        if ("console" === e.category) return function(e) {
                            const t = e.data && e.data.arguments;
                            if (!Array.isArray(t) || 0 === t.length) return sn(e);
                            let n = !1;
                            const s = t.map((e => {
                                if (!e) return e;
                                if ("string" == typeof e) return e.length > L ? (n = !0, `${e.slice(0,L)}…`) : e;
                                if ("object" == typeof e) try {
                                    const t = (0, f.Fv)(e, 7);
                                    return JSON.stringify(t).length > L ? (n = !0, `${JSON.stringify(t,null,2).slice(0,L)}…`) : t
                                } catch (e) {}
                                return e
                            }));
                            return sn({ ...e,
                                data: { ...e.data,
                                    arguments: s,
                                    ...n ? {
                                        _meta: {
                                            warnings: ["CONSOLE_ARG_TRUNCATED"]
                                        }
                                    } : {}
                                }
                            })
                        }(e);
                        return sn(e)
                    }(t);
                    n && Kt(e, n)
                }(e, t)))
            }

            function Kn(e) {
                return !!e.category
            }

            function Vn(e) {
                return Object.assign(((t, n) => {
                    if (!e.isEnabled() || e.isPaused()) return t;
                    if (function(e) {
                            return "replay_event" === e.type
                        }(t)) return delete t.breadcrumbs, t;
                    if (!zn(t) && !Wn(t) && !Hn(t)) return t;
                    if (!e.checkAndHandleExpiredSession()) return t;
                    if (Hn(t)) return e.flush(), t.contexts.feedback.replay_id = e.getSessionId(),
                        function(e, t) {
                            e.triggerUserActivity(), e.addUpdate((() => !t.timestamp || (e.throttledAddEvent({
                                type: Qe.Custom,
                                timestamp: 1e3 * t.timestamp,
                                data: {
                                    tag: "breadcrumb",
                                    payload: {
                                        timestamp: t.timestamp,
                                        type: "default",
                                        category: "sentry.feedback",
                                        data: {
                                            feedbackId: t.event_id
                                        }
                                    }
                                }
                            }), !1)))
                        }(e, t), t;
                    if (function(e, t) {
                            return !(e.type || !e.exception || !e.exception.values || !e.exception.values.length || !t.originalException || !t.originalException.__rrweb__)
                        }(t, n) && !e.getOptions()._experiments.captureExceptions) return null;
                    const s = function(e, t) {
                        return "buffer" === e.recordingMode && t.message !== D && !(!t.exception || t.type) && xn(e.getOptions().errorSampleRate)
                    }(e, t);
                    return (s || "session" === e.recordingMode) && (t.tags = { ...t.tags,
                        replayId: e.getSessionId()
                    }), t
                }), {
                    id: "Replay"
                })
            }

            function Jn(e, t) {
                return t.map((({
                    type: t,
                    start: n,
                    end: s,
                    name: r,
                    data: o
                }) => {
                    const i = e.throttledAddEvent({
                        type: Qe.Custom,
                        timestamp: n,
                        data: {
                            tag: "performanceSpan",
                            payload: {
                                op: t,
                                description: r,
                                startTimestamp: n,
                                endTimestamp: s,
                                data: o
                            }
                        }
                    });
                    return "string" == typeof i ? Promise.resolve(null) : i
                }))
            }

            function Gn(e) {
                return t => {
                    if (!e.isEnabled()) return;
                    const n = function(e) {
                        const {
                            from: t,
                            to: n
                        } = e, s = Date.now() / 1e3;
                        return {
                            type: "navigation.push",
                            start: s,
                            end: s,
                            name: n,
                            data: {
                                previous: t
                            }
                        }
                    }(t);
                    null !== n && (e.getContext().urls.push(n.name), e.triggerUserActivity(), e.addUpdate((() => (Jn(e, [n]), !1))))
                }
            }

            function Yn(e, t) {
                var n;
                e.isEnabled() && (null !== t && (n = t.name, (0, a.W)(n, (0, i.s3)()) || e.addUpdate((() => (Jn(e, [t]), !0)))))
            }

            function Xn(e) {
                if (!e) return;
                const t = new TextEncoder;
                try {
                    if ("string" == typeof e) return t.encode(e).length;
                    if (e instanceof URLSearchParams) return t.encode(e.toString()).length;
                    if (e instanceof FormData) {
                        const n = os(e);
                        return t.encode(n).length
                    }
                    if (e instanceof Blob) return e.size;
                    if (e instanceof ArrayBuffer) return e.byteLength
                } catch (e) {}
            }

            function Qn(e) {
                if (!e) return;
                const t = parseInt(e, 10);
                return isNaN(t) ? void 0 : t
            }

            function Zn(e) {
                try {
                    if ("string" == typeof e) return [e];
                    if (e instanceof URLSearchParams) return [e.toString()];
                    if (e instanceof FormData) return [os(e)];
                    if (!e) return [void 0]
                } catch (e) {
                    return [void 0, "BODY_PARSE_ERROR"]
                }
                return [void 0, "UNPARSEABLE_BODY_TYPE"]
            }

            function es(e, t) {
                if (!e) return {
                    headers: {},
                    size: void 0,
                    _meta: {
                        warnings: [t]
                    }
                };
                const n = { ...e._meta
                    },
                    s = n.warnings || [];
                return n.warnings = [...s, t], e._meta = n, e
            }

            function ts(e, t) {
                if (!t) return null;
                const {
                    startTimestamp: n,
                    endTimestamp: s,
                    url: r,
                    method: o,
                    statusCode: i,
                    request: a,
                    response: c
                } = t;
                return {
                    type: e,
                    start: n / 1e3,
                    end: s / 1e3,
                    name: r,
                    data: (0, y.Jr)({
                        method: o,
                        statusCode: i,
                        request: a,
                        response: c
                    })
                }
            }

            function ns(e) {
                return {
                    headers: {},
                    size: e,
                    _meta: {
                        warnings: ["URL_SKIPPED"]
                    }
                }
            }

            function ss(e, t, n) {
                if (!t && 0 === Object.keys(e).length) return;
                if (!t) return {
                    headers: e
                };
                if (!n) return {
                    headers: e,
                    size: t
                };
                const s = {
                        headers: e,
                        size: t
                    },
                    {
                        body: r,
                        warnings: o
                    } = function(e) {
                        if (!e || "string" != typeof e) return {
                            body: e
                        };
                        const t = e.length > O,
                            n = function(e) {
                                const t = e[0],
                                    n = e[e.length - 1];
                                return "[" === t && "]" === n || "{" === t && "}" === n
                            }(e);
                        if (t) {
                            const t = e.slice(0, O);
                            return n ? {
                                body: t,
                                warnings: ["MAYBE_JSON_TRUNCATED"]
                            } : {
                                body: `${t}…`,
                                warnings: ["TEXT_TRUNCATED"]
                            }
                        }
                        if (n) try {
                            return {
                                body: JSON.parse(e)
                            }
                        } catch (e) {}
                        return {
                            body: e
                        }
                    }(n);
                return s.body = r, o && o.length > 0 && (s._meta = {
                    warnings: o
                }), s
            }

            function rs(e, t) {
                return Object.entries(e).reduce(((n, [s, r]) => {
                    const o = s.toLowerCase();
                    return t.includes(o) && e[s] && (n[o] = r), n
                }), {})
            }

            function os(e) {
                return new URLSearchParams(e).toString()
            }

            function is(e, t) {
                const n = function(e, t = R.document.baseURI) {
                    if (e.startsWith("http://") || e.startsWith("https://") || e.startsWith(R.location.origin)) return e;
                    const n = new URL(e, t);
                    if (n.origin !== new URL(t).origin) return e;
                    const s = n.href;
                    if (!e.endsWith("/") && s.endsWith("/")) return s.slice(0, -1);
                    return s
                }(e);
                return (0, v.U0)(n, t)
            }
            async function as(e, t, n) {
                try {
                    const s = await async function(e, t, n) {
                            const s = Date.now(),
                                {
                                    startTimestamp: r = s,
                                    endTimestamp: o = s
                                } = t,
                                {
                                    url: i,
                                    method: a,
                                    status_code: c = 0,
                                    request_body_size: l,
                                    response_body_size: u
                                } = e.data,
                                d = is(i, n.networkDetailAllowUrls) && !is(i, n.networkDetailDenyUrls),
                                h = d ? function({
                                    networkCaptureBodies: e,
                                    networkRequestHeaders: t
                                }, n, s) {
                                    const r = n ? function(e, t) {
                                        if (1 === e.length && "string" != typeof e[0]) return us(e[0], t);
                                        if (2 === e.length) return us(e[1], t);
                                        return {}
                                    }(n, t) : {};
                                    if (!e) return ss(r, s, void 0);
                                    const o = cs(n),
                                        [i, a] = Zn(o),
                                        c = ss(r, s, i);
                                    if (a) return es(c, a);
                                    return c
                                }(n, t.input, l) : ns(l),
                                p = await async function(e, {
                                    networkCaptureBodies: t,
                                    networkResponseHeaders: n
                                }, s, r) {
                                    if (!e && void 0 !== r) return ns(r);
                                    const o = s ? ls(s.headers, n) : {};
                                    if (!s || !t && void 0 !== r) return ss(o, r, void 0);
                                    const [i, a] = await async function(e) {
                                        const t = function(e) {
                                            try {
                                                return e.clone()
                                            } catch (e) {}
                                        }(e);
                                        if (!t) return [void 0, "BODY_PARSE_ERROR"];
                                        try {
                                            const e = await
                                            function(e) {
                                                return new Promise(((t, n) => {
                                                    const s = (0, C.iK)((() => n(new Error("Timeout while trying to read response body"))), 500);
                                                    (async function(e) {
                                                        return await e.text()
                                                    })(e).then((e => t(e)), (e => n(e))).finally((() => clearTimeout(s)))
                                                }))
                                            }(t);
                                            return [e]
                                        } catch (e) {
                                            return e instanceof Error && e.message.indexOf("Timeout") > -1 ? [void 0, "BODY_PARSE_TIMEOUT"] : [void 0, "BODY_PARSE_ERROR"]
                                        }
                                    }(s), c = function(e, {
                                        networkCaptureBodies: t,
                                        responseBodySize: n,
                                        captureDetails: s,
                                        headers: r
                                    }) {
                                        try {
                                            const o = e && e.length && void 0 === n ? Xn(e) : n;
                                            return s ? ss(r, o, t ? e : void 0) : ns(o)
                                        } catch (e) {
                                            return ss(r, n, void 0)
                                        }
                                    }(i, {
                                        networkCaptureBodies: t,
                                        responseBodySize: r,
                                        captureDetails: e,
                                        headers: o
                                    });
                                    if (a) return es(c, a);
                                    return c
                                }(d, n, t.response, u);
                            return {
                                startTimestamp: r,
                                endTimestamp: o,
                                url: i,
                                method: a,
                                statusCode: c,
                                request: h,
                                response: p
                            }
                        }(e, t, n),
                        r = ts("resource.fetch", s);
                    Yn(n.replay, r)
                } catch (e) {}
            }

            function cs(e = []) {
                if (2 === e.length && "object" == typeof e[1]) return e[1].body
            }

            function ls(e, t) {
                const n = {};
                return t.forEach((t => {
                    e.get(t) && (n[t] = e.get(t))
                })), n
            }

            function us(e, t) {
                if (!e) return {};
                const n = e.headers;
                return n ? n instanceof Headers ? ls(n, t) : Array.isArray(n) ? {} : rs(n, t) : {}
            }
            async function ds(e, t, n) {
                try {
                    const s = function(e, t, n) {
                            const s = Date.now(),
                                {
                                    startTimestamp: r = s,
                                    endTimestamp: o = s,
                                    input: i,
                                    xhr: a
                                } = t,
                                {
                                    url: c,
                                    method: l,
                                    status_code: u = 0,
                                    request_body_size: d,
                                    response_body_size: h
                                } = e.data;
                            if (!c) return null;
                            if (!a || !is(c, n.networkDetailAllowUrls) || is(c, n.networkDetailDenyUrls)) {
                                return {
                                    startTimestamp: r,
                                    endTimestamp: o,
                                    url: c,
                                    method: l,
                                    statusCode: u,
                                    request: ns(d),
                                    response: ns(h)
                                }
                            }
                            const p = a[T.xU],
                                m = p ? rs(p.request_headers, n.networkRequestHeaders) : {},
                                f = rs(function(e) {
                                    const t = e.getAllResponseHeaders();
                                    if (!t) return {};
                                    return t.split("\r\n").reduce(((e, t) => {
                                        const [n, s] = t.split(": ");
                                        return s && (e[n.toLowerCase()] = s), e
                                    }), {})
                                }(a), n.networkResponseHeaders),
                                [y, g] = n.networkCaptureBodies ? Zn(i) : [void 0],
                                [S, k] = n.networkCaptureBodies ? function(e) {
                                    const t = [];
                                    try {
                                        return [e.responseText]
                                    } catch (e) {
                                        t.push(e)
                                    }
                                    try {
                                        return function(e, t) {
                                            try {
                                                if ("string" == typeof e) return [e];
                                                if (e instanceof Document) return [e.body.outerHTML];
                                                if ("json" === t && e && "object" == typeof e) return [JSON.stringify(e)];
                                                if (!e) return [void 0]
                                            } catch (e) {
                                                return [void 0, "BODY_PARSE_ERROR"]
                                            }
                                            return [void 0, "UNPARSEABLE_BODY_TYPE"]
                                        }(e.response, e.responseType)
                                    } catch (e) {
                                        t.push(e)
                                    }
                                    return [void 0]
                                }(a) : [void 0],
                                v = ss(m, d, y),
                                b = ss(f, h, S);
                            return {
                                startTimestamp: r,
                                endTimestamp: o,
                                url: c,
                                method: l,
                                statusCode: u,
                                request: g ? es(v, g) : v,
                                response: k ? es(b, k) : b
                            }
                        }(e, t, n),
                        r = ts("resource.xhr", s);
                    Yn(n.replay, r)
                } catch (e) {}
            }

            function hs(e, t) {
                const {
                    xhr: n,
                    input: s
                } = t;
                if (!n) return;
                const r = Xn(s),
                    o = n.getResponseHeader("content-length") ? Qn(n.getResponseHeader("content-length")) : function(e, t) {
                        try {
                            return Xn("json" === t && e && "object" == typeof e ? JSON.stringify(e) : e)
                        } catch (e) {
                            return
                        }
                    }(n.response, n.responseType);
                void 0 !== r && (e.data.request_body_size = r), void 0 !== o && (e.data.response_body_size = o)
            }

            function ps(e) {
                const t = (0, i.s3)();
                try {
                    const {
                        networkDetailAllowUrls: n,
                        networkDetailDenyUrls: s,
                        networkCaptureBodies: r,
                        networkRequestHeaders: o,
                        networkResponseHeaders: i
                    } = e.getOptions(), a = {
                        replay: e,
                        networkDetailAllowUrls: n,
                        networkDetailDenyUrls: s,
                        networkCaptureBodies: r,
                        networkRequestHeaders: o,
                        networkResponseHeaders: i
                    };
                    t && t.on("beforeAddBreadcrumb", ((e, t) => function(e, t, n) {
                        if (!t.data) return;
                        try {
                            (function(e) {
                                return "xhr" === e.category
                            })(t) && function(e) {
                                return e && e.xhr
                            }(n) && (hs(t, n), ds(t, n, e)),
                            function(e) {
                                return "fetch" === e.category
                            }(t) && function(e) {
                                return e && e.response
                            }(n) && (! function(e, t) {
                                const {
                                    input: n,
                                    response: s
                                } = t, r = Xn(n ? cs(n) : void 0), o = s ? Qn(s.headers.get("content-length")) : void 0;
                                void 0 !== r && (e.data.request_body_size = r), void 0 !== o && (e.data.response_body_size = o)
                            }(t, n), as(t, n, e))
                        } catch (e) {}
                    }(a, e, t)))
                } catch (e) {}
            }

            function ms(e) {
                const {
                    jsHeapSizeLimit: t,
                    totalJSHeapSize: n,
                    usedJSHeapSize: s
                } = e, r = Date.now() / 1e3;
                return {
                    type: "memory",
                    name: "memory",
                    start: r,
                    end: r,
                    data: {
                        memory: {
                            jsHeapSizeLimit: t,
                            totalJSHeapSize: n,
                            usedJSHeapSize: s
                        }
                    }
                }
            }

            function fs(e) {
                let t = !1;
                return (n, s) => {
                    if (!e.checkAndHandleExpiredSession()) return;
                    const r = s || !t;
                    t = !0, e.clickDetector && nn(e.clickDetector, n), e.addUpdate((() => {
                        if ("buffer" === e.recordingMode && r && e.setInitialState(), !Bn(e, n, r)) return !0;
                        if (!r) return !1;
                        const t = e.session;
                        if (function(e, t) {
                                if (!t || !e.session || 0 !== e.session.segmentId) return;
                                Bn(e, function(e) {
                                    const t = e.getOptions();
                                    return {
                                        type: Qe.Custom,
                                        timestamp: Date.now(),
                                        data: {
                                            tag: "options",
                                            payload: {
                                                shouldRecordCanvas: e.isRecordingCanvas(),
                                                sessionSampleRate: t.sessionSampleRate,
                                                errorSampleRate: t.errorSampleRate,
                                                useCompressionOption: t.useCompression,
                                                blockAllMedia: t.blockAllMedia,
                                                maskAllText: t.maskAllText,
                                                maskAllInputs: t.maskAllInputs,
                                                useCompression: !!e.eventBuffer && "worker" === e.eventBuffer.type,
                                                networkDetailHasUrls: t.networkDetailAllowUrls.length > 0,
                                                networkCaptureBodies: t.networkCaptureBodies,
                                                networkRequestHasHeaders: t.networkRequestHeaders.length > 0,
                                                networkResponseHasHeaders: t.networkResponseHeaders.length > 0
                                            }
                                        }
                                    }
                                }(e), !1)
                            }(e, r), "buffer" === e.recordingMode && t && e.eventBuffer) {
                            const n = e.eventBuffer.getEarliestTimestamp();
                            n && (t.started = n, e.getOptions().stickySession && An(t))
                        }
                        return t && t.previousSessionId || "session" === e.recordingMode && e.flush(), !0
                    }))
                }
            }
            async function ys({
                recordingData: e,
                replayId: t,
                segmentId: n,
                eventContext: s,
                timestamp: r,
                session: o
            }) {
                const a = function({
                        recordingData: e,
                        headers: t
                    }) {
                        let n;
                        const s = `${JSON.stringify(t)}\n`;
                        if ("string" == typeof e) n = `${s}${e}`;
                        else {
                            const t = (new TextEncoder).encode(s);
                            n = new Uint8Array(t.length + e.length), n.set(t), n.set(e, t.length)
                        }
                        return n
                    }({
                        recordingData: e,
                        headers: {
                            segment_id: n
                        }
                    }),
                    {
                        urls: c,
                        errorIds: l,
                        traceIds: d,
                        initialTimestamp: h
                    } = s,
                    p = (0, i.s3)(),
                    m = (0, i.nZ)(),
                    f = p && p.getTransport(),
                    y = p && p.getDsn();
                if (!(p && f && y && o.sampled)) return (0, _.WD)({});
                const g = {
                        type: "replay_event",
                        replay_start_timestamp: h / 1e3,
                        timestamp: r / 1e3,
                        error_ids: l,
                        trace_ids: d,
                        urls: c,
                        replay_id: t,
                        segment_id: n,
                        replay_type: o.sampled
                    },
                    S = await async function({
                        client: e,
                        scope: t,
                        replayId: n,
                        event: s
                    }) {
                        const r = {
                            event_id: n,
                            integrations: "object" != typeof e._integrations || null === e._integrations || Array.isArray(e._integrations) ? void 0 : Object.keys(e._integrations)
                        };
                        e.emit("preprocessEvent", s, r);
                        const o = await (0, u.R)(e.getOptions(), s, r, t, e, (0, i.aF)());
                        if (!o) return null;
                        o.platform = o.platform || "javascript";
                        const a = e.getSdkMetadata(),
                            {
                                name: c,
                                version: l
                            } = a && a.sdk || {};
                        return o.sdk = { ...o.sdk,
                            name: c || "sentry.javascript.unknown",
                            version: l || "0.0.0"
                        }, o
                    }({
                        scope: m,
                        client: p,
                        replayId: t,
                        event: g
                    });
                if (!S) return p.recordDroppedEvent("event_processor", "replay", g), (0, _.WD)({});
                delete S.sdkProcessingMetadata;
                const k = function(e, t, n, s) {
                    return (0, b.Jd)((0, b.Cd)(e, (0, b.HY)(e), s, n), [
                        [{
                            type: "replay_event"
                        }, e],
                        [{
                            type: "replay_recording",
                            length: "string" == typeof t ? (new TextEncoder).encode(t).length : t.length
                        }, t]
                    ])
                }(S, a, y, p.getOptions().tunnel);
                let v;
                try {
                    v = await f.send(k)
                } catch (e) {
                    const t = new Error(D);
                    try {
                        t.cause = e
                    } catch (e) {}
                    throw t
                }
                if ("number" == typeof v.statusCode && (v.statusCode < 200 || v.statusCode >= 300)) throw new gs(v.statusCode);
                const I = (0, w.WG)({}, v);
                if ((0, w.Q)(I, "replay")) throw new Ss(I);
                return v
            }
            class gs extends Error {
                constructor(e) {
                    super(`Transport returned status code ${e}`)
                }
            }
            class Ss extends Error {
                constructor(e) {
                    super("Rate limit hit"), this.rateLimits = e
                }
            }
            async function ks(e, t = {
                count: 0,
                interval: 5e3
            }) {
                const {
                    recordingData: n,
                    onError: s
                } = e;
                if (n.length) try {
                    return await ys(e), !0
                } catch (n) {
                    if (n instanceof gs || n instanceof Ss) throw n;
                    if ((0, o.v)("Replays", {
                            _retryCount: t.count
                        }), s && s(n), t.count >= 3) {
                        const e = new Error(`${D} - max retries exceeded`);
                        try {
                            e.cause = n
                        } catch (e) {}
                        throw e
                    }
                    return t.interval *= ++t.count, new Promise(((n, s) => {
                        (0, C.iK)((async () => {
                            try {
                                await ks(e, t), n(!0)
                            } catch (e) {
                                s(e)
                            }
                        }), t.interval)
                    }))
                }
            }
            const vs = "__THROTTLED";

            function bs(e, t, n) {
                const s = new Map;
                let r = !1;
                return (...o) => {
                    const i = Math.floor(Date.now() / 1e3);
                    if ((e => {
                            const t = e - n;
                            s.forEach(((e, n) => {
                                n < t && s.delete(n)
                            }))
                        })(i), [...s.values()].reduce(((e, t) => e + t), 0) >= t) {
                        const e = r;
                        return r = !0, e ? "__SKIPPED" : vs
                    }
                    r = !1;
                    const a = s.get(i) || 0;
                    return s.set(i, a + 1), e(...o)
                }
            }
            class _s {
                constructor({
                    options: e,
                    recordingOptions: t
                }) {
                    _s.prototype.__init.call(this), _s.prototype.__init2.call(this), _s.prototype.__init3.call(this), _s.prototype.__init4.call(this), _s.prototype.__init5.call(this), _s.prototype.__init6.call(this), this.eventBuffer = null, this.performanceEntries = [], this.replayPerformanceEntries = [], this.recordingMode = "session", this.timeouts = {
                        sessionIdlePause: 3e5,
                        sessionIdleExpire: 9e5
                    }, this._lastActivity = Date.now(), this._isEnabled = !1, this._isPaused = !1, this._requiresManualStart = !1, this._hasInitializedCoreListeners = !1, this._context = {
                        errorIds: new Set,
                        traceIds: new Set,
                        urls: [],
                        initialTimestamp: Date.now(),
                        initialUrl: ""
                    }, this._recordingOptions = t, this._options = e, this._debouncedFlush = function(e, t, n) {
                        let s, r, o;
                        const i = n && n.maxWait ? Math.max(n.maxWait, t) : 0;

                        function a() {
                            return c(), s = e(), s
                        }

                        function c() {
                            void 0 !== r && clearTimeout(r), void 0 !== o && clearTimeout(o), r = o = void 0
                        }

                        function l() {
                            return r && clearTimeout(r), r = (0, C.iK)(a, t), i && void 0 === o && (o = (0, C.iK)(a, i)), s
                        }
                        return l.cancel = c, l.flush = function() {
                            return void 0 !== r || void 0 !== o ? a() : s
                        }, l
                    }((() => this._flush()), this._options.flushMinDelay, {
                        maxWait: this._options.flushMaxDelay
                    }), this._throttledAddEvent = bs(((e, t) => function(e, t, n) {
                        return Un(e, t) ? Pn(e, t, n) : Promise.resolve(null)
                    }(this, e, t)), 300, 5);
                    const {
                        slowClickTimeout: n,
                        slowClickIgnoreSelectors: s
                    } = this.getOptions(), r = n ? {
                        threshold: Math.min(3e3, n),
                        timeout: n,
                        scrollTimeout: 300,
                        ignoreSelector: s ? s.join(",") : ""
                    } : void 0;
                    r && (this.clickDetector = new Zt(this, r))
                }
                getContext() {
                    return this._context
                }
                isEnabled() {
                    return this._isEnabled
                }
                isPaused() {
                    return this._isPaused
                }
                isRecordingCanvas() {
                    return Boolean(this._canvas)
                }
                getOptions() {
                    return this._options
                }
                handleException(e) {
                    this._options.onError && this._options.onError(e)
                }
                initializeSampling(e) {
                    const {
                        errorSampleRate: t,
                        sessionSampleRate: n
                    } = this._options, s = t <= 0 && n <= 0;
                    this._requiresManualStart = s, s || (this._initializeSessionForSampling(e), this.session && !1 !== this.session.sampled && (this.recordingMode = "buffer" === this.session.sampled && 0 === this.session.segmentId ? "buffer" : "session", this._initializeRecording()))
                }
                start() {
                    if (this._isEnabled && "session" === this.recordingMode) return;
                    if (this._isEnabled && "buffer" === this.recordingMode) return;
                    this._updateUserActivity();
                    const e = Fn({
                        maxReplayDuration: this._options.maxReplayDuration,
                        sessionIdleExpire: this.timeouts.sessionIdleExpire
                    }, {
                        stickySession: this._options.stickySession,
                        sessionSampleRate: 1,
                        allowBuffering: !1
                    });
                    this.session = e, this._initializeRecording()
                }
                startBuffering() {
                    if (this._isEnabled) return;
                    const e = Fn({
                        sessionIdleExpire: this.timeouts.sessionIdleExpire,
                        maxReplayDuration: this._options.maxReplayDuration
                    }, {
                        stickySession: this._options.stickySession,
                        sessionSampleRate: 0,
                        allowBuffering: !0
                    });
                    this.session = e, this.recordingMode = "buffer", this._initializeRecording()
                }
                startRecording() {
                    try {
                        const e = this._canvas;
                        this._stopRecording = Ht({ ...this._recordingOptions,
                            ..."buffer" === this.recordingMode ? {
                                checkoutEveryNms: 6e4
                            } : this._options._experiments.continuousCheckout && {
                                checkoutEveryNms: Math.max(36e4, this._options._experiments.continuousCheckout)
                            },
                            emit: fs(this),
                            onMutation: this._onMutationHandler,
                            ...e ? {
                                recordCanvas: e.recordCanvas,
                                getCanvasManager: e.getCanvasManager,
                                sampling: e.sampling,
                                dataURLOptions: e.dataURLOptions
                            } : {}
                        })
                    } catch (e) {
                        this.handleException(e)
                    }
                }
                stopRecording() {
                    try {
                        return this._stopRecording && (this._stopRecording(), this._stopRecording = void 0), !0
                    } catch (e) {
                        return this.handleException(e), !1
                    }
                }
                async stop({
                    forceFlush: e = !1,
                    reason: t
                } = {}) {
                    if (this._isEnabled) {
                        this._isEnabled = !1;
                        try {
                            ! function() {
                                const e = (0, i.nZ)().getPropagationContext().dsc;
                                e && delete e.replay_id;
                                const t = (0, c.HN)();
                                t && delete(0, l.jC)(t).replay_id
                            }(), this._removeListeners(), this.stopRecording(), this._debouncedFlush.cancel(), e && await this._flush({
                                force: !0
                            }), this.eventBuffer && this.eventBuffer.destroy(), this.eventBuffer = null, Mn(this)
                        } catch (e) {
                            this.handleException(e)
                        }
                    }
                }
                pause() {
                    this._isPaused || (this._isPaused = !0, this.stopRecording())
                }
                resume() {
                    this._isPaused && this._checkSession() && (this._isPaused = !1, this.startRecording())
                }
                async sendBufferedReplayOrFlush({
                    continueRecording: e = !0
                } = {}) {
                    if ("session" === this.recordingMode) return this.flushImmediate();
                    const t = Date.now();
                    await this.flushImmediate();
                    const n = this.stopRecording();
                    e && n && "session" !== this.recordingMode && (this.recordingMode = "session", this.session && (this._updateUserActivity(t), this._updateSessionActivity(t), this._maybeSaveSession()), this.startRecording())
                }
                addUpdate(e) {
                    const t = e();
                    "buffer" !== this.recordingMode && !0 !== t && this._debouncedFlush()
                }
                triggerUserActivity() {
                    if (this._updateUserActivity(), this._stopRecording) this.checkAndHandleExpiredSession(), this._updateSessionActivity();
                    else {
                        if (!this._checkSession()) return;
                        this.resume()
                    }
                }
                updateUserActivity() {
                    this._updateUserActivity(), this._updateSessionActivity()
                }
                conditionalFlush() {
                    return "buffer" === this.recordingMode ? Promise.resolve() : this.flushImmediate()
                }
                flush() {
                    return this._debouncedFlush()
                }
                flushImmediate() {
                    return this._debouncedFlush(), this._debouncedFlush.flush()
                }
                cancelFlush() {
                    this._debouncedFlush.cancel()
                }
                getSessionId() {
                    return this.session && this.session.id
                }
                checkAndHandleExpiredSession() {
                    if (!(this._lastActivity && On(this._lastActivity, this.timeouts.sessionIdlePause) && this.session && "session" === this.session.sampled)) return !!this._checkSession();
                    this.pause()
                }
                setInitialState() {
                    const e = `${R.location.pathname}${R.location.hash}${R.location.search}`,
                        t = `${R.location.origin}${e}`;
                    this.performanceEntries = [], this.replayPerformanceEntries = [], this._clearContext(), this._context.initialUrl = t, this._context.initialTimestamp = Date.now(), this._context.urls.push(t)
                }
                throttledAddEvent(e, t) {
                    const n = this._throttledAddEvent(e, t);
                    if (n === vs) {
                        const e = sn({
                            category: "replay.throttled"
                        });
                        this.addUpdate((() => !Bn(this, {
                            type: 5,
                            timestamp: e.timestamp || 0,
                            data: {
                                tag: "breadcrumb",
                                payload: e,
                                metric: !0
                            }
                        })))
                    }
                    return n
                }
                getCurrentRoute() {
                    const e = this.lastActiveSpan || (0, c.HN)(),
                        t = e && (0, c.Gx)(e),
                        n = (t && (0, c.XU)(t).data || {})[d.Zj];
                    if (t && n && ["route", "custom"].includes(n)) return (0, c.XU)(t).description
                }
                _initializeRecording() {
                    this.setInitialState(), this._updateSessionActivity(), this.eventBuffer = En({
                        useCompression: this._options.useCompression,
                        workerUrl: this._options.workerUrl
                    }), this._removeListeners(), this._addListeners(), this._isEnabled = !0, this._isPaused = !1, this.startRecording()
                }
                _initializeSessionForSampling(e) {
                    const t = this._options.errorSampleRate > 0,
                        n = Fn({
                            sessionIdleExpire: this.timeouts.sessionIdleExpire,
                            maxReplayDuration: this._options.maxReplayDuration,
                            previousSessionId: e
                        }, {
                            stickySession: this._options.stickySession,
                            sessionSampleRate: this._options.sessionSampleRate,
                            allowBuffering: t
                        });
                    this.session = n
                }
                _checkSession() {
                    if (!this.session) return !1;
                    const e = this.session;
                    return !Nn(e, {
                        sessionIdleExpire: this.timeouts.sessionIdleExpire,
                        maxReplayDuration: this._options.maxReplayDuration
                    }) || (this._refreshSession(e), !1)
                }
                async _refreshSession(e) {
                    this._isEnabled && (await this.stop({
                        reason: "refresh session"
                    }), this.initializeSampling(e.id))
                }
                _addListeners() {
                    try {
                        R.document.addEventListener("visibilitychange", this._handleVisibilityChange), R.addEventListener("blur", this._handleWindowBlur), R.addEventListener("focus", this._handleWindowFocus), R.addEventListener("keydown", this._handleKeyboardEvent), this.clickDetector && this.clickDetector.addListeners(), this._hasInitializedCoreListeners || (! function(e) {
                            const t = (0, i.s3)();
                            (0, M.O)(cn(e)), (0, x.a)(Gn(e)), qn(e), ps(e);
                            const n = Vn(e);
                            (0, o.Qy)(n), t && (t.on("beforeSendEvent", $n(e)), t.on("afterSendEvent", jn(e)), t.on("createDsc", (t => {
                                const n = e.getSessionId();
                                n && e.isEnabled() && "session" === e.recordingMode && e.checkAndHandleExpiredSession() && (t.replay_id = n)
                            })), t.on("spanStart", (t => {
                                e.lastActiveSpan = t
                            })), t.on("spanEnd", (t => {
                                e.lastActiveSpan = t
                            })), t.on("beforeSendFeedback", ((t, n) => {
                                const s = e.getSessionId();
                                n && n.includeReplay && e.isEnabled() && s && t.contexts && t.contexts.feedback && (t.contexts.feedback.replay_id = s)
                            })))
                        }(this), this._hasInitializedCoreListeners = !0)
                    } catch (e) {
                        this.handleException(e)
                    }
                    this._performanceCleanupCallback = function(e) {
                        function t(t) {
                            e.performanceEntries.includes(t) || e.performanceEntries.push(t)
                        }

                        function n({
                            entries: e
                        }) {
                            e.forEach(t)
                        }
                        const s = [];
                        return ["navigation", "paint", "resource"].forEach((e => {
                            s.push((0, E._j)(e, n))
                        })), s.push((0, E.$A)(hn(fn, e)), (0, E.PR)(hn(gn, e)), (0, E.to)(hn(Sn, e)), (0, E.YF)(hn(kn, e))), () => {
                            s.forEach((e => e()))
                        }
                    }(this)
                }
                _removeListeners() {
                    try {
                        R.document.removeEventListener("visibilitychange", this._handleVisibilityChange), R.removeEventListener("blur", this._handleWindowBlur), R.removeEventListener("focus", this._handleWindowFocus), R.removeEventListener("keydown", this._handleKeyboardEvent), this.clickDetector && this.clickDetector.removeListeners(), this._performanceCleanupCallback && this._performanceCleanupCallback()
                    } catch (e) {
                        this.handleException(e)
                    }
                }
                __init() {
                    this._handleVisibilityChange = () => {
                        "visible" === R.document.visibilityState ? this._doChangeToForegroundTasks() : this._doChangeToBackgroundTasks()
                    }
                }
                __init2() {
                    this._handleWindowBlur = () => {
                        const e = sn({
                            category: "ui.blur"
                        });
                        this._doChangeToBackgroundTasks(e)
                    }
                }
                __init3() {
                    this._handleWindowFocus = () => {
                        const e = sn({
                            category: "ui.focus"
                        });
                        this._doChangeToForegroundTasks(e)
                    }
                }
                __init4() {
                    this._handleKeyboardEvent = e => {
                        un(this, e)
                    }
                }
                _doChangeToBackgroundTasks(e) {
                    if (!this.session) return;
                    Ln(this.session, {
                        maxReplayDuration: this._options.maxReplayDuration,
                        sessionIdleExpire: this.timeouts.sessionIdleExpire
                    }) || (e && this._createCustomBreadcrumb(e), this.conditionalFlush())
                }
                _doChangeToForegroundTasks(e) {
                    if (!this.session) return;
                    this.checkAndHandleExpiredSession() && e && this._createCustomBreadcrumb(e)
                }
                _updateUserActivity(e = Date.now()) {
                    this._lastActivity = e
                }
                _updateSessionActivity(e = Date.now()) {
                    this.session && (this.session.lastActivity = e, this._maybeSaveSession())
                }
                _createCustomBreadcrumb(e) {
                    this.addUpdate((() => {
                        this.throttledAddEvent({
                            type: Qe.Custom,
                            timestamp: e.timestamp || 0,
                            data: {
                                tag: "breadcrumb",
                                payload: e
                            }
                        })
                    }))
                }
                _addPerformanceEntries() {
                    let e = (t = this.performanceEntries, t.map(pn).filter(Boolean)).concat(this.replayPerformanceEntries);
                    var t;
                    if (this.performanceEntries = [], this.replayPerformanceEntries = [], this._requiresManualStart) {
                        const t = this._context.initialTimestamp / 1e3;
                        e = e.filter((e => e.start >= t))
                    }
                    return Promise.all(Jn(this, e))
                }
                _clearContext() {
                    this._context.errorIds.clear(), this._context.traceIds.clear(), this._context.urls = []
                }
                _updateInitialTimestampFromEventBuffer() {
                    const {
                        session: e,
                        eventBuffer: t
                    } = this;
                    if (!e || !t || this._requiresManualStart) return;
                    if (e.segmentId) return;
                    const n = t.getEarliestTimestamp();
                    n && n < this._context.initialTimestamp && (this._context.initialTimestamp = n)
                }
                _popEventContext() {
                    const e = {
                        initialTimestamp: this._context.initialTimestamp,
                        initialUrl: this._context.initialUrl,
                        errorIds: Array.from(this._context.errorIds),
                        traceIds: Array.from(this._context.traceIds),
                        urls: this._context.urls
                    };
                    return this._clearContext(), e
                }
                async _runFlush() {
                    const e = this.getSessionId();
                    if (this.session && this.eventBuffer && e && (await this._addPerformanceEntries(), this.eventBuffer && this.eventBuffer.hasEvents && (await async function(e) {
                            try {
                                return Promise.all(Jn(e, [ms(R.performance.memory)]))
                            } catch (e) {
                                return []
                            }
                        }(this), this.eventBuffer && e === this.getSessionId()))) try {
                        this._updateInitialTimestampFromEventBuffer();
                        const t = Date.now();
                        if (t - this._context.initialTimestamp > this._options.maxReplayDuration + 3e4) throw new Error("Session is too long, not sending replay");
                        const n = this._popEventContext(),
                            s = this.session.segmentId++;
                        this._maybeSaveSession();
                        const r = await this.eventBuffer.finish();
                        await ks({
                            replayId: e,
                            recordingData: r,
                            segmentId: s,
                            eventContext: n,
                            session: this.session,
                            timestamp: t,
                            onError: e => this.handleException(e)
                        })
                    } catch (e) {
                        this.handleException(e), this.stop({
                            reason: "sendReplay"
                        });
                        const t = (0, i.s3)();
                        if (t) {
                            const n = e instanceof Ss ? "ratelimit_backoff" : "send_error";
                            t.recordDroppedEvent(n, "replay")
                        }
                    }
                }
                __init5() {
                    this._flush = async ({
                        force: e = !1
                    } = {}) => {
                        if (!this._isEnabled && !e) return;
                        if (!this.checkAndHandleExpiredSession()) return;
                        if (!this.session) return;
                        const t = this.session.started,
                            n = Date.now() - t;
                        this._debouncedFlush.cancel();
                        const s = n < this._options.minReplayDuration,
                            r = n > this._options.maxReplayDuration + 5e3;
                        if (s || r) return void(s && this._debouncedFlush());
                        const o = this.eventBuffer;
                        o && 0 === this.session.segmentId && o.hasCheckout;
                        const i = !!this._flushLock;
                        this._flushLock || (this._flushLock = this._runFlush());
                        try {
                            await this._flushLock
                        } catch (e) {
                            this.handleException(e)
                        } finally {
                            this._flushLock = void 0, i && this._debouncedFlush()
                        }
                    }
                }
                _maybeSaveSession() {
                    this.session && this._options.stickySession && An(this.session)
                }
                __init6() {
                    this._onMutationHandler = e => {
                        const t = e.length,
                            n = this._options.mutationLimit,
                            s = n && t > n;
                        if (t > this._options.mutationBreadcrumbLimit || s) {
                            const e = sn({
                                category: "replay.mutations",
                                data: {
                                    count: t,
                                    limit: s
                                }
                            });
                            this._createCustomBreadcrumb(e)
                        }
                        return !s || (this.stop({
                            reason: "mutationLimit",
                            forceFlush: "session" === this.recordingMode
                        }), !1)
                    }
                }
            }

            function ws(e, t) {
                return [...e, ...t].join(",")
            }
            const Is = 'img,image,svg,video,object,picture,embed,map,audio,link[rel="icon"],link[rel="apple-touch-icon"]',
                Cs = ["content-length", "content-type", "accept"];
            let Es = !1;
            const Ts = e => new Ms(e);
            class Ms {
                static __initStatic() {
                    this.id = "Replay"
                }
                constructor({
                    flushMinDelay: e = 5e3,
                    flushMaxDelay: t = 5500,
                    minReplayDuration: n = 4999,
                    maxReplayDuration: s = 36e5,
                    stickySession: r = !0,
                    useCompression: o = !0,
                    workerUrl: i,
                    _experiments: a = {},
                    maskAllText: c = !0,
                    maskAllInputs: l = !0,
                    blockAllMedia: u = !0,
                    mutationBreadcrumbLimit: d = 750,
                    mutationLimit: h = 1e4,
                    slowClickTimeout: p = 7e3,
                    slowClickIgnoreSelectors: m = [],
                    networkDetailAllowUrls: f = [],
                    networkDetailDenyUrls: y = [],
                    networkCaptureBodies: g = !0,
                    networkRequestHeaders: S = [],
                    networkResponseHeaders: k = [],
                    mask: v = [],
                    maskAttributes: b = ["title", "placeholder"],
                    unmask: _ = [],
                    block: w = [],
                    unblock: C = [],
                    ignore: E = [],
                    maskFn: T,
                    beforeAddRecordingEvent: M,
                    beforeErrorSampling: x
                } = {}) {
                    this.name = Ms.id;
                    const R = function({
                        mask: e,
                        unmask: t,
                        block: n,
                        unblock: s,
                        ignore: r
                    }) {
                        return {
                            maskTextSelector: ws(e, [".sentry-mask", "[data-sentry-mask]"]),
                            unmaskTextSelector: ws(t, []),
                            blockSelector: ws(n, [".sentry-block", "[data-sentry-block]", 'base[href="/"]']),
                            unblockSelector: ws(s, []),
                            ignoreSelector: ws(r, [".sentry-ignore", "[data-sentry-ignore]", 'input[type="file"]'])
                        }
                    }({
                        mask: v,
                        unmask: _,
                        block: w,
                        unblock: C,
                        ignore: E
                    });
                    if (this._recordingOptions = {
                            maskAllInputs: l,
                            maskAllText: c,
                            maskInputOptions: {
                                password: !0
                            },
                            maskTextFn: T,
                            maskInputFn: T,
                            maskAttributeFn: (e, t, n) => function({
                                el: e,
                                key: t,
                                maskAttributes: n,
                                maskAllText: s,
                                privacyOptions: r,
                                value: o
                            }) {
                                return s ? r.unmaskTextSelector && e.matches(r.unmaskTextSelector) ? o : n.includes(t) || "value" === t && "INPUT" === e.tagName && ["submit", "button"].includes(e.getAttribute("type") || "") ? o.replace(/[\S]/g, "*") : o : o
                            }({
                                maskAttributes: b,
                                maskAllText: c,
                                privacyOptions: R,
                                key: e,
                                value: t,
                                el: n
                            }),
                            ...R,
                            slimDOMOptions: "all",
                            inlineStylesheet: !0,
                            inlineImages: !1,
                            collectFonts: !0,
                            errorHandler: e => {
                                try {
                                    e.__rrweb__ = !0
                                } catch (e) {}
                            }
                        }, this._initialOptions = {
                            flushMinDelay: e,
                            flushMaxDelay: t,
                            minReplayDuration: Math.min(n, 15e3),
                            maxReplayDuration: Math.min(s, F),
                            stickySession: r,
                            useCompression: o,
                            workerUrl: i,
                            blockAllMedia: u,
                            maskAllInputs: l,
                            maskAllText: c,
                            mutationBreadcrumbLimit: d,
                            mutationLimit: h,
                            slowClickTimeout: p,
                            slowClickIgnoreSelectors: m,
                            networkDetailAllowUrls: f,
                            networkDetailDenyUrls: y,
                            networkCaptureBodies: g,
                            networkRequestHeaders: xs(S),
                            networkResponseHeaders: xs(k),
                            beforeAddRecordingEvent: M,
                            beforeErrorSampling: x,
                            _experiments: a
                        }, this._initialOptions.blockAllMedia && (this._recordingOptions.blockSelector = this._recordingOptions.blockSelector ? `${this._recordingOptions.blockSelector},${Is}` : Is), this._isInitialized && (0, I.j)()) throw new Error("Multiple Sentry Session Replay instances are not supported");
                    this._isInitialized = !0
                }
                get _isInitialized() {
                    return Es
                }
                set _isInitialized(e) {
                    Es = e
                }
                afterAllSetup(e) {
                    (0, I.j)() && !this._replay && (this._setup(e), this._initialize(e))
                }
                start() {
                    this._replay && this._replay.start()
                }
                startBuffering() {
                    this._replay && this._replay.startBuffering()
                }
                stop() {
                    return this._replay ? this._replay.stop({
                        forceFlush: "session" === this._replay.recordingMode
                    }) : Promise.resolve()
                }
                flush(e) {
                    return this._replay ? this._replay.isEnabled() ? this._replay.sendBufferedReplayOrFlush(e) : (this._replay.start(), Promise.resolve()) : Promise.resolve()
                }
                getReplayId() {
                    if (this._replay && this._replay.isEnabled()) return this._replay.getSessionId()
                }
                _initialize(e) {
                    this._replay && (this._maybeLoadFromReplayCanvasIntegration(e), this._replay.initializeSampling())
                }
                _setup(e) {
                    const t = function(e, t) {
                        const n = t.getOptions(),
                            s = {
                                sessionSampleRate: 0,
                                errorSampleRate: 0,
                                ...(0, y.Jr)(e)
                            },
                            r = (0, h.o)(n.replaysSessionSampleRate),
                            o = (0, h.o)(n.replaysOnErrorSampleRate);
                        null == r && null == o && (0, m.Cf)((() => {}));
                        null != r && (s.sessionSampleRate = r);
                        null != o && (s.errorSampleRate = o);
                        return s
                    }(this._initialOptions, e);
                    this._replay = new _s({
                        options: t,
                        recordingOptions: this._recordingOptions
                    })
                }
                _maybeLoadFromReplayCanvasIntegration(e) {
                    try {
                        const t = e.getIntegrationByName("ReplayCanvas");
                        if (!t) return;
                        this._replay._canvas = t.getOptions()
                    } catch (e) {}
                }
            }

            function xs(e) {
                return [...Cs, ...e.map((e => e.toLowerCase()))]
            }
            Ms.__initStatic()
        }
    }
]);