/*! For license information please see 9589-afd392215267ee7a.js.LICENSE.txt */ ! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "ea53d840-0d3e-4316-85b9-e8a86dfee19b", e._sentryDebugIdIdentifier = "sentry-dbid-ea53d840-0d3e-4316-85b9-e8a86dfee19b")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9589], {
        89616: function(e, t, n) {
            "use strict";
            var r = n(84371),
                o = n(93887),
                i = n(17890),
                a = n(81129),
                u = n(41591),
                c = n(64625),
                s = n(69309),
                l = function() {
                    return l = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, l.apply(this, arguments)
                },
                f = function(e, t) {
                    var n = {};
                    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                        var o = 0;
                        for (r = Object.getOwnPropertySymbols(e); o < r.length; o++) t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]])
                    }
                    return n
                },
                d = {
                    position: "top",
                    trigger: "hover",
                    escToClose: !1,
                    unmountOnExit: !0,
                    blurToHide: !0,
                    popupHoverStay: !0
                },
                p = {
                    enter: 300,
                    exit: 100
                },
                v = {
                    left: 12,
                    right: 12,
                    top: 12,
                    bottom: 12
                };
            var m = (0, r.forwardRef)((function(e, t) {
                var n = (0, r.useContext)(a.E),
                    m = n.getPrefixCls,
                    h = n.componentConfig,
                    g = (0, c.Z)(e, d, null == h ? void 0 : h.Tooltip),
                    y = g.style,
                    b = g.className,
                    E = g.children,
                    w = g.trigger,
                    C = g.escToClose,
                    S = g.defaultPopupVisible,
                    O = g.position,
                    P = g.unmountOnExit,
                    T = g.popupVisible,
                    A = g.prefixCls,
                    R = g.blurToHide,
                    D = g.popupHoverStay,
                    N = g.disabled,
                    x = g.onVisibleChange,
                    L = g.triggerProps,
                    k = g.childrenPrefix,
                    I = g.getPopupContainer,
                    M = g.content,
                    _ = g.mini,
                    j = g.color,
                    F = f(g, ["style", "className", "children", "trigger", "escToClose", "defaultPopupVisible", "position", "unmountOnExit", "popupVisible", "prefixCls", "blurToHide", "popupHoverStay", "disabled", "onVisibleChange", "triggerProps", "childrenPrefix", "getPopupContainer", "content", "mini", "color"]),
                    Z = (0, r.useRef)(),
                    W = function(e, t) {
                        void 0 === e && (e = 0), Z.current && Z.current.updatePopupPosition(e, t)
                    };
                (0, r.useImperativeHandle)(t, (function() {
                    return {
                        updatePopupPosition: W
                    }
                }), []);
                var V = A || m("tooltip"),
                    B = l(l(l(l({}, (0, u.Z)(F, i.C)), (0, u.m)(F)), L), {
                        className: (0, o.Z)(b, null == L ? void 0 : L.className)
                    }),
                    U = (0, s.mf)(M) ? M() : M;
                return "popupVisible" in g ? B.popupVisible = T : (0, s.U$)(U, !0) && (B.popupVisible = !1), (!1 !== B.showArrow || B.arrowProps) && (B.arrowProps = B.arrowProps || {}, j && (B.arrowProps.style = l({
                    backgroundColor: j
                }, B.arrowProps.style))), r.createElement(i.Z, l({
                    style: l({
                        maxWidth: 350
                    }, y),
                    ref: Z,
                    classNames: "zoomInFadeOut",
                    duration: p,
                    popup: function() {
                        var e;
                        return r.createElement("div", {
                            style: {
                                backgroundColor: j
                            },
                            className: (0, o.Z)(V + "-content", V + "-content-" + O, (e = {}, e[V + "-mini"] = _, e)),
                            role: "tooltip"
                        }, r.createElement("div", {
                            className: V + "-content-inner"
                        }, U))
                    },
                    position: O,
                    disabled: N,
                    trigger: w,
                    escToClose: C,
                    showArrow: !0,
                    popupAlign: v,
                    mouseEnterDelay: 200,
                    mouseLeaveDelay: 200,
                    unmountOnExit: P,
                    popupHoverStay: D,
                    blurToHide: R,
                    childrenPrefix: k || V,
                    getPopupContainer: I,
                    onVisibleChange: x,
                    defaultPopupVisible: S
                }, B), E)
            }));
            m.displayName = "Tooltip", t.Z = m
        },
        7591: function(e, t, n) {
            "use strict";
            n(17670), n(50912), n(46974)
        },
        37962: function(e, t, n) {
            "use strict";
            var r = n(46050),
                o = n(84371),
                i = n(29903);
            t.Z = function(e) {
                var t = (0, r.CR)((0, o.useState)(e), 2),
                    n = t[0],
                    a = t[1],
                    u = (0, i.Z)(n);
                return [n, a, (0, o.useCallback)((function() {
                    return u.current
                }), [])]
            }
        },
        29903: function(e, t, n) {
            "use strict";
            var r = n(84371);
            t.Z = function(e) {
                var t = (0, r.useRef)(e);
                return t.current = e, t
            }
        },
        29069: function(e, t, n) {
            ! function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && "object" == typeof e && "default" in e ? e : {
                        default: e
                    }
                }
                var o = r(t),
                    i = r(n);

                function a(e, t) {
                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var r, o, i, a, u = [],
                            c = !0,
                            s = !1;
                        try {
                            if (i = (n = n.call(e)).next, 0 === t) {
                                if (Object(n) !== n) return;
                                c = !1
                            } else
                                for (; !(c = (r = i.call(n)).done) && (u.push(r.value), u.length !== t); c = !0);
                        } catch (e) {
                            s = !0, o = e
                        } finally {
                            try {
                                if (!c && null != n.return && (a = n.return(), Object(a) !== a)) return
                            } finally {
                                if (s) throw o
                            }
                        }
                        return u
                    }
                }

                function u(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function c(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(n), !0).forEach((function(t) {
                            s(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function s(e, t, n) {
                    return (t = y(t)) in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function l(e, t) {
                    if (null == e) return {};
                    var n, r, o = {},
                        i = Object.keys(e);
                    for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                    return o
                }

                function f(e, t) {
                    if (null == e) return {};
                    var n, r, o = l(e, t);
                    if (Object.getOwnPropertySymbols) {
                        var i = Object.getOwnPropertySymbols(e);
                        for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (o[n] = e[n])
                    }
                    return o
                }

                function d(e, t) {
                    return p(e) || a(e, t) || v(e, t) || h()
                }

                function p(e) {
                    if (Array.isArray(e)) return e
                }

                function v(e, t) {
                    if (e) {
                        if ("string" == typeof e) return m(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? m(e, t) : void 0
                    }
                }

                function m(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function h() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }

                function g(e, t) {
                    if ("object" != typeof e || null === e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var r = n.call(e, t || "default");
                        if ("object" != typeof r) return r;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }

                function y(e) {
                    var t = g(e, "string");
                    return "symbol" == typeof t ? t : String(t)
                }
                var b = ["animationData", "loop", "autoplay", "initialSegment", "onComplete", "onLoopComplete", "onEnterFrame", "onSegmentStart", "onConfigReady", "onDataReady", "onDataFailed", "onLoadedImages", "onDOMLoaded", "onDestroy", "lottieRef", "renderer", "name", "assetsPath", "rendererSettings"],
                    E = function(e, t) {
                        var r = e.animationData,
                            a = e.loop,
                            u = e.autoplay,
                            s = e.initialSegment,
                            l = e.onComplete,
                            p = e.onLoopComplete,
                            v = e.onEnterFrame,
                            m = e.onSegmentStart,
                            h = e.onConfigReady,
                            g = e.onDataReady,
                            y = e.onDataFailed,
                            E = e.onLoadedImages,
                            w = e.onDOMLoaded,
                            C = e.onDestroy;
                        e.lottieRef, e.renderer, e.name, e.assetsPath, e.rendererSettings;
                        var S = f(e, b),
                            O = d(n.useState(!1), 2),
                            P = O[0],
                            T = O[1],
                            A = n.useRef(),
                            R = n.useRef(null),
                            D = function() {
                                var e;
                                null === (e = A.current) || void 0 === e || e.play()
                            },
                            N = function() {
                                var e;
                                null === (e = A.current) || void 0 === e || e.stop()
                            },
                            x = function() {
                                var e;
                                null === (e = A.current) || void 0 === e || e.pause()
                            },
                            L = function(e) {
                                var t;
                                null === (t = A.current) || void 0 === t || t.setSpeed(e)
                            },
                            k = function(e, t) {
                                var n;
                                null === (n = A.current) || void 0 === n || n.goToAndPlay(e, t)
                            },
                            I = function(e, t) {
                                var n;
                                null === (n = A.current) || void 0 === n || n.goToAndStop(e, t)
                            },
                            M = function(e) {
                                var t;
                                null === (t = A.current) || void 0 === t || t.setDirection(e)
                            },
                            _ = function(e, t) {
                                var n;
                                null === (n = A.current) || void 0 === n || n.playSegments(e, t)
                            },
                            j = function(e) {
                                var t;
                                null === (t = A.current) || void 0 === t || t.setSubframe(e)
                            },
                            F = function(e) {
                                var t;
                                return null === (t = A.current) || void 0 === t ? void 0 : t.getDuration(e)
                            },
                            Z = function() {
                                var e;
                                null === (e = A.current) || void 0 === e || e.destroy(), A.current = void 0
                            },
                            W = function() {
                                var t, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                if (R.current) {
                                    null === (t = A.current) || void 0 === t || t.destroy();
                                    var r = c(c(c({}, e), n), {}, {
                                        container: R.current
                                    });
                                    return A.current = o.default.loadAnimation(r), T(!!A.current),
                                        function() {
                                            var e;
                                            null === (e = A.current) || void 0 === e || e.destroy(), A.current = void 0
                                        }
                                }
                            };
                        return n.useEffect((function() {
                            var e = W();
                            return function() {
                                return null == e ? void 0 : e()
                            }
                        }), [r, a]), n.useEffect((function() {
                            A.current && (A.current.autoplay = !!u)
                        }), [u]), n.useEffect((function() {
                            A.current && (s ? Array.isArray(s) && s.length && ((A.current.currentRawFrame < s[0] || A.current.currentRawFrame > s[1]) && (A.current.currentRawFrame = s[0]), A.current.setSegment(s[0], s[1])) : A.current.resetSegments(!0))
                        }), [s]), n.useEffect((function() {
                            var e = [{
                                name: "complete",
                                handler: l
                            }, {
                                name: "loopComplete",
                                handler: p
                            }, {
                                name: "enterFrame",
                                handler: v
                            }, {
                                name: "segmentStart",
                                handler: m
                            }, {
                                name: "config_ready",
                                handler: h
                            }, {
                                name: "data_ready",
                                handler: g
                            }, {
                                name: "data_failed",
                                handler: y
                            }, {
                                name: "loaded_images",
                                handler: E
                            }, {
                                name: "DOMLoaded",
                                handler: w
                            }, {
                                name: "destroy",
                                handler: C
                            }].filter((function(e) {
                                return null != e.handler
                            }));
                            if (e.length) {
                                var t = e.map((function(e) {
                                    var t;
                                    return null === (t = A.current) || void 0 === t || t.addEventListener(e.name, e.handler),
                                        function() {
                                            var t;
                                            null === (t = A.current) || void 0 === t || t.removeEventListener(e.name, e.handler)
                                        }
                                }));
                                return function() {
                                    t.forEach((function(e) {
                                        return e()
                                    }))
                                }
                            }
                        }), [l, p, v, m, h, g, y, E, w, C]), {
                            View: i.default.createElement("div", c({
                                style: t,
                                ref: R
                            }, S)),
                            play: D,
                            stop: N,
                            pause: x,
                            setSpeed: L,
                            goToAndStop: I,
                            goToAndPlay: k,
                            setDirection: M,
                            playSegments: _,
                            setSubframe: j,
                            getDuration: F,
                            destroy: Z,
                            animationContainerRef: R,
                            animationLoaded: P,
                            animationItem: A.current
                        }
                    };

                function w(e) {
                    var t = e.getBoundingClientRect(),
                        n = t.top,
                        r = t.height;
                    return (window.innerHeight - n) / (window.innerHeight + r)
                }

                function C(e, t, n) {
                    var r = e.getBoundingClientRect(),
                        o = r.top;
                    return {
                        x: (t - r.left) / r.width,
                        y: (n - o) / r.height
                    }
                }
                var S = function(e) {
                        var t = e.wrapperRef,
                            r = e.animationItem,
                            o = e.mode,
                            i = e.actions;
                        n.useEffect((function() {
                            var e = t.current;
                            if (e && r && i.length) {
                                r.stop();
                                var n = function() {
                                        var t = null,
                                            n = function() {
                                                var n = w(e),
                                                    o = i.find((function(e) {
                                                        var t = e.visibility;
                                                        return t && n >= t[0] && n <= t[1]
                                                    }));
                                                if (o) {
                                                    if ("seek" === o.type && o.visibility && 2 === o.frames.length) {
                                                        var a = o.frames[0] + Math.ceil((n - o.visibility[0]) / (o.visibility[1] - o.visibility[0]) * o.frames[1]);
                                                        r.goToAndStop(a - r.firstFrame - 1, !0)
                                                    }
                                                    "loop" === o.type && (null === t || t !== o.frames || r.isPaused) && (r.playSegments(o.frames, !0), t = o.frames), "play" === o.type && r.isPaused && (r.resetSegments(!0), r.play()), "stop" === o.type && r.goToAndStop(o.frames[0] - r.firstFrame - 1, !0)
                                                }
                                            };
                                        return document.addEventListener("scroll", n),
                                            function() {
                                                document.removeEventListener("scroll", n)
                                            }
                                    },
                                    a = function() {
                                        var t = function(t, n) {
                                                var o = t,
                                                    a = n;
                                                if (-1 !== o && -1 !== a) {
                                                    var u = C(e, o, a);
                                                    o = u.x, a = u.y
                                                }
                                                var c = i.find((function(e) {
                                                    var t = e.position;
                                                    return t && Array.isArray(t.x) && Array.isArray(t.y) ? o >= t.x[0] && o <= t.x[1] && a >= t.y[0] && a <= t.y[1] : !(!t || Number.isNaN(t.x) || Number.isNaN(t.y)) && o === t.x && a === t.y
                                                }));
                                                if (c) {
                                                    if ("seek" === c.type && c.position && Array.isArray(c.position.x) && Array.isArray(c.position.y) && 2 === c.frames.length) {
                                                        var s = (o - c.position.x[0]) / (c.position.x[1] - c.position.x[0]),
                                                            l = (a - c.position.y[0]) / (c.position.y[1] - c.position.y[0]);
                                                        r.playSegments(c.frames, !0), r.goToAndStop(Math.ceil((s + l) / 2 * (c.frames[1] - c.frames[0])), !0)
                                                    }
                                                    "loop" === c.type && r.playSegments(c.frames, !0), "play" === c.type && (r.isPaused && r.resetSegments(!1), r.playSegments(c.frames)), "stop" === c.type && r.goToAndStop(c.frames[0], !0)
                                                }
                                            },
                                            n = function(e) {
                                                t(e.clientX, e.clientY)
                                            },
                                            o = function() {
                                                t(-1, -1)
                                            };
                                        return e.addEventListener("mousemove", n), e.addEventListener("mouseout", o),
                                            function() {
                                                e.removeEventListener("mousemove", n), e.removeEventListener("mouseout", o)
                                            }
                                    };
                                switch (o) {
                                    case "scroll":
                                        return n();
                                    case "cursor":
                                        return a()
                                }
                            }
                        }), [o, r])
                    },
                    O = function(e) {
                        var t = e.actions,
                            n = e.mode,
                            r = e.lottieObj,
                            o = r.animationItem,
                            i = r.View,
                            a = r.animationContainerRef;
                        return S({
                            actions: t,
                            animationItem: o,
                            mode: n,
                            wrapperRef: a
                        }), i
                    },
                    P = ["style", "interactivity"],
                    T = function(e) {
                        var t, r, o, i = e.style,
                            a = e.interactivity,
                            u = f(e, P),
                            c = E(u, i),
                            s = c.View,
                            l = c.play,
                            d = c.stop,
                            p = c.pause,
                            v = c.setSpeed,
                            m = c.goToAndStop,
                            h = c.goToAndPlay,
                            g = c.setDirection,
                            y = c.playSegments,
                            b = c.setSubframe,
                            w = c.getDuration,
                            C = c.destroy,
                            S = c.animationContainerRef,
                            T = c.animationLoaded,
                            A = c.animationItem;
                        return n.useEffect((function() {
                            e.lottieRef && (e.lottieRef.current = {
                                play: l,
                                stop: d,
                                pause: p,
                                setSpeed: v,
                                goToAndPlay: h,
                                goToAndStop: m,
                                setDirection: g,
                                playSegments: y,
                                setSubframe: b,
                                getDuration: w,
                                destroy: C,
                                animationContainerRef: S,
                                animationLoaded: T,
                                animationItem: A
                            })
                        }), [null === (t = e.lottieRef) || void 0 === t ? void 0 : t.current]), O({
                            lottieObj: {
                                View: s,
                                play: l,
                                stop: d,
                                pause: p,
                                setSpeed: v,
                                goToAndStop: m,
                                goToAndPlay: h,
                                setDirection: g,
                                playSegments: y,
                                setSubframe: b,
                                getDuration: w,
                                destroy: C,
                                animationContainerRef: S,
                                animationLoaded: T,
                                animationItem: A
                            },
                            actions: null !== (r = null == a ? void 0 : a.actions) && void 0 !== r ? r : [],
                            mode: null !== (o = null == a ? void 0 : a.mode) && void 0 !== o ? o : "scroll"
                        })
                    };
                Object.defineProperty(e, "LottiePlayer", {
                    enumerable: !0,
                    get: function() {
                        return o.default
                    }
                }), e.default = T, e.useLottie = E, e.useLottieInteractivity = O, Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            }(t, n(45679), n(84371))
        },
        99901: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            const r = (0, n(28325).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        92692: function(e, t, n) {
            "use strict";

            function r() {
                return r = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, r.apply(null, arguments)
            }
            n.d(t, {
                g: function() {
                    return r
                }
            })
        },
        13973: function(e, t, n) {
            "use strict";
            n.d(t, {
                default: function() {
                    return l
                }
            });
            var r = n(92692),
                o = n(16924),
                i = n(46055),
                a = n(84371),
                u = n(40027);

            function c(e, t, n, r) {
                if (!e || r === n || null == r || !t) return;
                const o = function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : window.location.pathname;
                        return "/" === e ? t : t.replace(e, "")
                    }(t),
                    i = "" !== o ? o : "/",
                    {
                        name: a,
                        ...u
                    } = e;
                u.path || (u.path = i);
                let c = "".concat(a, "=").concat(r, ";");
                for (const [e, t] of Object.entries(u)) c += "".concat("maxAge" === e ? "max-age" : e), "boolean" != typeof t && (c += "=" + t), c += ";";
                document.cookie = c
            }

            function s(e, t) {
                let {
                    defaultLocale: n,
                    href: s,
                    locale: l,
                    localeCookie: f,
                    onClick: d,
                    prefetch: p,
                    unprefixed: v,
                    ...m
                } = e;
                const h = (0, u.Z)(),
                    g = null != l && l !== h,
                    y = l || h,
                    b = function() {
                        const [e, t] = (0, a.useState)();
                        return (0, a.useEffect)((() => {
                            t(window.location.host)
                        }), []), e
                    }(),
                    E = b && v && (v.domains[b] === y || !Object.keys(v.domains).includes(b) && h === n && !l) ? v.pathname : s,
                    w = (0, i.usePathname)();
                return g && (p = !1), a.createElement(o.default, (0, r.g)({
                    ref: t,
                    href: E,
                    hrefLang: g ? l : void 0,
                    onClick: function(e) {
                        c(f, w, h, l), d && d(e)
                    },
                    prefetch: p
                }, m))
            }
            var l = (0, a.forwardRef)(s)
        },
        85671: function(e, t, n) {
            "use strict";
            n.d(t, {
                default: function() {
                    return d
                }
            });
            var r = n(92692),
                o = n(46055),
                i = n(84371),
                a = n(40027);
            n(92869);

            function u(e) {
                return function(e) {
                    return "object" == typeof e ? null == e.host && null == e.hostname : !/^[a-z]+:/i.test(e)
                }(e) && ! function(e) {
                    const t = "object" == typeof e ? e.pathname : e;
                    return null != t && !t.startsWith("/")
                }(e)
            }

            function c(e, t) {
                let n;
                return "string" == typeof e ? n = s(t, e) : (n = { ...e
                }, e.pathname && (n.pathname = s(t, e.pathname))), n
            }

            function s(e, t) {
                let n = e;
                return /^\/(\?.*)?$/.test(t) && (t = t.slice(1)), n += t, n
            }
            var l = n(13973);

            function f(e, t) {
                let {
                    href: n,
                    locale: s,
                    localeCookie: f,
                    localePrefixMode: d,
                    prefix: p,
                    ...v
                } = e;
                const m = (0, o.usePathname)(),
                    h = (0, a.Z)(),
                    g = s !== h,
                    [y, b] = (0, i.useState)((() => u(n) && ("never" !== d || g) ? c(n, p) : n));
                return (0, i.useEffect)((() => {
                    m && b(function(e, t) {
                        let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : t,
                            r = arguments.length > 3 ? arguments[3] : void 0,
                            o = arguments.length > 4 ? arguments[4] : void 0;
                        if (!u(e)) return e;
                        const i = t !== n,
                            a = function(e, t) {
                                return t === e || t.startsWith("".concat(e, "/"))
                            }(o, r);
                        return (i || a) && null != o ? c(e, o) : e
                    }(n, s, h, m, p))
                }), [h, n, s, m, p]), i.createElement(l.default, (0, r.g)({
                    ref: t,
                    href: y,
                    locale: s,
                    localeCookie: f
                }, v))
            }
            const d = (0, i.forwardRef)(f);
            d.displayName = "ClientLink"
        },
        40027: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(46055),
                o = n(15217);
            const i = "locale";

            function a() {
                const e = (0, r.useParams)();
                let t;
                try {
                    t = (0, o.useLocale)()
                } catch (n) {
                    if ("string" != typeof(null == e ? void 0 : e[i])) throw n;
                    t = e[i]
                }
                return t
            }
        },
        96922: function(e, t, n) {
            "use strict";
            n.d(t, {
                q: function() {
                    return u
                }
            });
            var r = n(84371);

            function o(e, t) {
                return "function" == typeof e ? e(t) : e && (e.current = t), e
            }
            var i = "undefined" != typeof window ? r.useLayoutEffect : r.useEffect,
                a = new WeakMap;

            function u(e, t) {
                var n, u, c, s = (n = t || null, u = function(t) {
                    return e.forEach((function(e) {
                        return o(e, t)
                    }))
                }, (c = (0, r.useState)((function() {
                    return {
                        value: n,
                        callback: u,
                        facade: {
                            get current() {
                                return c.value
                            },
                            set current(e) {
                                var t = c.value;
                                t !== e && (c.value = e, c.callback(e, t))
                            }
                        }
                    }
                }))[0]).callback = u, c.facade);
                return i((function() {
                    var t = a.get(s);
                    if (t) {
                        var n = new Set(t),
                            r = new Set(e),
                            i = s.current;
                        n.forEach((function(e) {
                            r.has(e) || o(e, null)
                        })), r.forEach((function(e) {
                            n.has(e) || o(e, i)
                        }))
                    }
                    a.set(s, e)
                }), [e]), s
            }
        },
        66684: function(e, t, n) {
            "use strict";
            n.d(t, {
                _: function() {
                    return u
                },
                s: function() {
                    return a
                }
            });
            var r = n(46050);

            function o(e) {
                return e
            }

            function i(e, t) {
                void 0 === t && (t = o);
                var n = [],
                    r = !1;
                return {
                    read: function() {
                        if (r) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
                        return n.length ? n[n.length - 1] : e
                    },
                    useMedium: function(e) {
                        var o = t(e, r);
                        return n.push(o),
                            function() {
                                n = n.filter((function(e) {
                                    return e !== o
                                }))
                            }
                    },
                    assignSyncMedium: function(e) {
                        for (r = !0; n.length;) {
                            var t = n;
                            n = [], t.forEach(e)
                        }
                        n = {
                            push: function(t) {
                                return e(t)
                            },
                            filter: function() {
                                return n
                            }
                        }
                    },
                    assignMedium: function(e) {
                        r = !0;
                        var t = [];
                        if (n.length) {
                            var o = n;
                            n = [], o.forEach(e), t = n
                        }
                        var i = function() {
                                var n = t;
                                t = [], n.forEach(e)
                            },
                            a = function() {
                                return Promise.resolve().then(i)
                            };
                        a(), n = {
                            push: function(e) {
                                t.push(e), a()
                            },
                            filter: function(e) {
                                return t = t.filter(e), n
                            }
                        }
                    }
                }
            }

            function a(e, t) {
                return void 0 === t && (t = o), i(e, t)
            }

            function u(e) {
                void 0 === e && (e = {});
                var t = i(null);
                return t.options = (0, r.pi)({
                    async: !0,
                    ssr: !1
                }, e), t
            }
        },
        46974: function() {},
        53509: function(e, t, n) {
            "use strict";
            n.d(t, {
                x8: function() {
                    return wt
                },
                VY: function() {
                    return yt
                },
                dk: function() {
                    return Et
                },
                aV: function() {
                    return gt
                },
                h_: function() {
                    return ht
                },
                fC: function() {
                    return vt
                },
                Dx: function() {
                    return bt
                },
                xz: function() {
                    return mt
                }
            });
            var r = n(62438),
                o = n(84371),
                i = n.t(o, 2);

            function a(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function u(...e) {
                return t => e.forEach((e => function(e, t) {
                    "function" == typeof e ? e(t) : null != e && (e.current = t)
                }(e, t)))
            }

            function c(...e) {
                return (0, o.useCallback)(u(...e), e)
            }

            function s(...e) {
                const t = e[0];
                if (1 === e.length) return t;
                const n = () => {
                    const n = e.map((e => ({
                        useScope: e(),
                        scopeName: e.scopeName
                    })));
                    return function(e) {
                        const r = n.reduce(((t, {
                            useScope: n,
                            scopeName: r
                        }) => ({ ...t,
                            ...n(e)[`__scope${r}`]
                        })), {});
                        return (0, o.useMemo)((() => ({
                            [`__scope${t.scopeName}`]: r
                        })), [r])
                    }
                };
                return n.scopeName = t.scopeName, n
            }
            const l = Boolean(null === globalThis || void 0 === globalThis ? void 0 : globalThis.document) ? o.useLayoutEffect : () => {},
                f = i["useId".toString()] || (() => {});
            let d = 0;

            function p(e) {
                const [t, n] = o.useState(f());
                return l((() => {
                    e || n((e => null != e ? e : String(d++)))
                }), [e]), e || (t ? `radix-${t}` : "")
            }

            function v(e) {
                const t = (0, o.useRef)(e);
                return (0, o.useEffect)((() => {
                    t.current = e
                })), (0, o.useMemo)((() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }), [])
            }

            function m({
                prop: e,
                defaultProp: t,
                onChange: n = () => {}
            }) {
                const [r, i] = function({
                    defaultProp: e,
                    onChange: t
                }) {
                    const n = (0, o.useState)(e),
                        [r] = n,
                        i = (0, o.useRef)(r),
                        a = v(t);
                    return (0, o.useEffect)((() => {
                        i.current !== r && (a(r), i.current = r)
                    }), [r, i, a]), n
                }({
                    defaultProp: t,
                    onChange: n
                }), a = void 0 !== e, u = a ? e : r, c = v(n);
                return [u, (0, o.useCallback)((t => {
                    if (a) {
                        const n = "function" == typeof t ? t(e) : t;
                        n !== e && c(n)
                    } else i(t)
                }), [a, e, i, c])]
            }
            var h = n(54343),
                g = n(29980);
            const y = (0, o.forwardRef)(((e, t) => {
                const {
                    children: n,
                    ...r
                } = e, i = o.Children.toArray(n), a = i.find(w);
                if (a) {
                    const e = a.props.children,
                        n = i.map((t => t === a ? o.Children.count(e) > 1 ? o.Children.only(null) : (0, o.isValidElement)(e) ? e.props.children : null : t));
                    return (0, o.createElement)(b, (0, h.Z)({}, r, {
                        ref: t
                    }), (0, o.isValidElement)(e) ? (0, o.cloneElement)(e, void 0, n) : null)
                }
                return (0, o.createElement)(b, (0, h.Z)({}, r, {
                    ref: t
                }), n)
            }));
            y.displayName = "Slot";
            const b = (0, o.forwardRef)(((e, t) => {
                const {
                    children: n,
                    ...r
                } = e;
                return (0, o.isValidElement)(n) ? (0, o.cloneElement)(n, { ...C(r, n.props),
                    ref: t ? u(t, n.ref) : n.ref
                }) : o.Children.count(n) > 1 ? o.Children.only(null) : null
            }));
            b.displayName = "SlotClone";
            const E = ({
                children: e
            }) => (0, o.createElement)(o.Fragment, null, e);

            function w(e) {
                return (0, o.isValidElement)(e) && e.type === E
            }

            function C(e, t) {
                const n = { ...t
                };
                for (const r in t) {
                    const o = e[r],
                        i = t[r];
                    /^on[A-Z]/.test(r) ? o && i ? n[r] = (...e) => {
                        i(...e), o(...e)
                    } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                        ...i
                    } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                }
                return { ...e,
                    ...n
                }
            }
            const S = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce(((e, t) => {
                const n = (0, o.forwardRef)(((e, n) => {
                    const {
                        asChild: r,
                        ...i
                    } = e, a = r ? y : t;
                    return (0, o.useEffect)((() => {
                        window[Symbol.for("radix-ui")] = !0
                    }), []), (0, o.createElement)(a, (0, h.Z)({}, i, {
                        ref: n
                    }))
                }));
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }), {});
            const O = "dismissableLayer.update",
                P = "dismissableLayer.pointerDownOutside",
                T = "dismissableLayer.focusOutside";
            let A;
            const R = (0, o.createContext)({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                D = (0, o.forwardRef)(((e, t) => {
                    var n;
                    const {
                        disableOutsidePointerEvents: r = !1,
                        onEscapeKeyDown: i,
                        onPointerDownOutside: u,
                        onFocusOutside: s,
                        onInteractOutside: l,
                        onDismiss: f,
                        ...d
                    } = e, p = (0, o.useContext)(R), [m, g] = (0, o.useState)(null), y = null !== (n = null == m ? void 0 : m.ownerDocument) && void 0 !== n ? n : null === globalThis || void 0 === globalThis ? void 0 : globalThis.document, [, b] = (0, o.useState)({}), E = c(t, (e => g(e))), w = Array.from(p.layers), [C] = [...p.layersWithOutsidePointerEventsDisabled].slice(-1), D = w.indexOf(C), L = m ? w.indexOf(m) : -1, k = p.layersWithOutsidePointerEventsDisabled.size > 0, I = L >= D, M = function(e, t = (null === globalThis || void 0 === globalThis ? void 0 : globalThis.document)) {
                        const n = v(e),
                            r = (0, o.useRef)(!1),
                            i = (0, o.useRef)((() => {}));
                        return (0, o.useEffect)((() => {
                            const e = e => {
                                    if (e.target && !r.current) {
                                        const o = {
                                            originalEvent: e
                                        };

                                        function a() {
                                            x(P, n, o, {
                                                discrete: !0
                                            })
                                        }
                                        "touch" === e.pointerType ? (t.removeEventListener("click", i.current), i.current = a, t.addEventListener("click", i.current, {
                                            once: !0
                                        })) : a()
                                    } else t.removeEventListener("click", i.current);
                                    r.current = !1
                                },
                                o = window.setTimeout((() => {
                                    t.addEventListener("pointerdown", e)
                                }), 0);
                            return () => {
                                window.clearTimeout(o), t.removeEventListener("pointerdown", e), t.removeEventListener("click", i.current)
                            }
                        }), [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }((e => {
                        const t = e.target,
                            n = [...p.branches].some((e => e.contains(t)));
                        I && !n && (null == u || u(e), null == l || l(e), e.defaultPrevented || null == f || f())
                    }), y), _ = function(e, t = (null === globalThis || void 0 === globalThis ? void 0 : globalThis.document)) {
                        const n = v(e),
                            r = (0, o.useRef)(!1);
                        return (0, o.useEffect)((() => {
                            const e = e => {
                                if (e.target && !r.current) {
                                    x(T, n, {
                                        originalEvent: e
                                    }, {
                                        discrete: !1
                                    })
                                }
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }), [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }((e => {
                        const t = e.target;
                        [...p.branches].some((e => e.contains(t))) || (null == s || s(e), null == l || l(e), e.defaultPrevented || null == f || f())
                    }), y);
                    return function(e, t = (null === globalThis || void 0 === globalThis ? void 0 : globalThis.document)) {
                        const n = v(e);
                        (0, o.useEffect)((() => {
                            const e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e)
                        }), [n, t])
                    }((e => {
                        L === p.layers.size - 1 && (null == i || i(e), !e.defaultPrevented && f && (e.preventDefault(), f()))
                    }), y), (0, o.useEffect)((() => {
                        if (m) return r && (0 === p.layersWithOutsidePointerEventsDisabled.size && (A = y.body.style.pointerEvents, y.body.style.pointerEvents = "none"), p.layersWithOutsidePointerEventsDisabled.add(m)), p.layers.add(m), N(), () => {
                            r && 1 === p.layersWithOutsidePointerEventsDisabled.size && (y.body.style.pointerEvents = A)
                        }
                    }), [m, y, r, p]), (0, o.useEffect)((() => () => {
                        m && (p.layers.delete(m), p.layersWithOutsidePointerEventsDisabled.delete(m), N())
                    }), [m, p]), (0, o.useEffect)((() => {
                        const e = () => b({});
                        return document.addEventListener(O, e), () => document.removeEventListener(O, e)
                    }), []), (0, o.createElement)(S.div, (0, h.Z)({}, d, {
                        ref: E,
                        style: {
                            pointerEvents: k ? I ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: a(e.onFocusCapture, _.onFocusCapture),
                        onBlurCapture: a(e.onBlurCapture, _.onBlurCapture),
                        onPointerDownCapture: a(e.onPointerDownCapture, M.onPointerDownCapture)
                    }))
                }));

            function N() {
                const e = new CustomEvent(O);
                document.dispatchEvent(e)
            }

            function x(e, t, n, {
                discrete: r
            }) {
                const o = n.originalEvent.target,
                    i = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                t && o.addEventListener(e, t, {
                    once: !0
                }), r ? function(e, t) {
                    e && (0, g.flushSync)((() => e.dispatchEvent(t)))
                }(o, i) : o.dispatchEvent(i)
            }
            const L = "focusScope.autoFocusOnMount",
                k = "focusScope.autoFocusOnUnmount",
                I = {
                    bubbles: !1,
                    cancelable: !0
                },
                M = (0, o.forwardRef)(((e, t) => {
                    const {
                        loop: n = !1,
                        trapped: r = !1,
                        onMountAutoFocus: i,
                        onUnmountAutoFocus: a,
                        ...u
                    } = e, [s, l] = (0, o.useState)(null), f = v(i), d = v(a), p = (0, o.useRef)(null), m = c(t, (e => l(e))), g = (0, o.useRef)({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    (0, o.useEffect)((() => {
                        if (r) {
                            function e(e) {
                                if (g.paused || !s) return;
                                const t = e.target;
                                s.contains(t) ? p.current = t : Z(p.current, {
                                    select: !0
                                })
                            }

                            function t(e) {
                                if (g.paused || !s) return;
                                const t = e.relatedTarget;
                                null !== t && (s.contains(t) || Z(p.current, {
                                    select: !0
                                }))
                            }

                            function n(e) {
                                if (document.activeElement === document.body)
                                    for (const t of e) t.removedNodes.length > 0 && Z(s)
                            }
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            const o = new MutationObserver(n);
                            return s && o.observe(s, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), o.disconnect()
                            }
                        }
                    }), [r, s, g.paused]), (0, o.useEffect)((() => {
                        if (s) {
                            W.add(g);
                            const t = document.activeElement;
                            if (!s.contains(t)) {
                                const n = new CustomEvent(L, I);
                                s.addEventListener(L, f), s.dispatchEvent(n), n.defaultPrevented || (! function(e, {
                                    select: t = !1
                                } = {}) {
                                    const n = document.activeElement;
                                    for (const r of e)
                                        if (Z(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }((e = _(s), e.filter((e => "A" !== e.tagName))), {
                                    select: !0
                                }), document.activeElement === t && Z(s))
                            }
                            return () => {
                                s.removeEventListener(L, f), setTimeout((() => {
                                    const e = new CustomEvent(k, I);
                                    s.addEventListener(k, d), s.dispatchEvent(e), e.defaultPrevented || Z(null != t ? t : document.body, {
                                        select: !0
                                    }), s.removeEventListener(k, d), W.remove(g)
                                }), 0)
                            }
                        }
                        var e
                    }), [s, f, d, g]);
                    const y = (0, o.useCallback)((e => {
                        if (!n && !r) return;
                        if (g.paused) return;
                        const t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            o = document.activeElement;
                        if (t && o) {
                            const t = e.currentTarget,
                                [r, i] = function(e) {
                                    const t = _(e),
                                        n = j(t, e),
                                        r = j(t.reverse(), e);
                                    return [n, r]
                                }(t);
                            r && i ? e.shiftKey || o !== i ? e.shiftKey && o === r && (e.preventDefault(), n && Z(i, {
                                select: !0
                            })) : (e.preventDefault(), n && Z(r, {
                                select: !0
                            })) : o === t && e.preventDefault()
                        }
                    }), [n, r, g.paused]);
                    return (0, o.createElement)(S.div, (0, h.Z)({
                        tabIndex: -1
                    }, u, {
                        ref: m,
                        onKeyDown: y
                    }))
                }));

            function _(e) {
                const t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            const t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function j(e, t) {
                for (const n of e)
                    if (!F(n, {
                            upTo: t
                        })) return n
            }

            function F(e, {
                upTo: t
            }) {
                if ("hidden" === getComputedStyle(e).visibility) return !0;
                for (; e;) {
                    if (void 0 !== t && e === t) return !1;
                    if ("none" === getComputedStyle(e).display) return !0;
                    e = e.parentElement
                }
                return !1
            }

            function Z(e, {
                select: t = !1
            } = {}) {
                if (e && e.focus) {
                    const n = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== n && function(e) {
                        return e instanceof HTMLInputElement && "select" in e
                    }(e) && t && e.select()
                }
            }
            const W = function() {
                let e = [];
                return {
                    add(t) {
                        const n = e[0];
                        t !== n && (null == n || n.pause()), e = V(e, t), e.unshift(t)
                    },
                    remove(t) {
                        var n;
                        e = V(e, t), null === (n = e[0]) || void 0 === n || n.resume()
                    }
                }
            }();

            function V(e, t) {
                const n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
            const B = (0, o.forwardRef)(((e, t) => {
                var n;
                const {
                    container: r = (null === globalThis || void 0 === globalThis || null === (n = globalThis.document) || void 0 === n ? void 0 : n.body),
                    ...i
                } = e;
                return r ? g.createPortal((0, o.createElement)(S.div, (0, h.Z)({}, i, {
                    ref: t
                })), r) : null
            }));
            const U = e => {
                const {
                    present: t,
                    children: n
                } = e, r = function(e) {
                    const [t, n] = (0, o.useState)(), r = (0, o.useRef)({}), i = (0, o.useRef)(e), a = (0, o.useRef)("none"), u = e ? "mounted" : "unmounted", [c, s] = function(e, t) {
                        return (0, o.useReducer)(((e, n) => {
                            const r = t[e][n];
                            return null != r ? r : e
                        }), e)
                    }(u, {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    });
                    return (0, o.useEffect)((() => {
                        const e = H(r.current);
                        a.current = "mounted" === c ? e : "none"
                    }), [c]), l((() => {
                        const t = r.current,
                            n = i.current;
                        if (n !== e) {
                            const r = a.current,
                                o = H(t);
                            if (e) s("MOUNT");
                            else if ("none" === o || "none" === (null == t ? void 0 : t.display)) s("UNMOUNT");
                            else {
                                s(n && r !== o ? "ANIMATION_OUT" : "UNMOUNT")
                            }
                            i.current = e
                        }
                    }), [e, s]), l((() => {
                        if (t) {
                            const e = e => {
                                    const n = H(r.current).includes(e.animationName);
                                    e.target === t && n && (0, g.flushSync)((() => s("ANIMATION_END")))
                                },
                                n = e => {
                                    e.target === t && (a.current = H(r.current))
                                };
                            return t.addEventListener("animationstart", n), t.addEventListener("animationcancel", e), t.addEventListener("animationend", e), () => {
                                t.removeEventListener("animationstart", n), t.removeEventListener("animationcancel", e), t.removeEventListener("animationend", e)
                            }
                        }
                        s("ANIMATION_END")
                    }), [t, s]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(c),
                        ref: (0, o.useCallback)((e => {
                            e && (r.current = getComputedStyle(e)), n(e)
                        }), [])
                    }
                }(t), i = "function" == typeof n ? n({
                    present: r.isPresent
                }) : o.Children.only(n), a = c(r.ref, i.ref);
                return "function" == typeof n || r.isPresent ? (0, o.cloneElement)(i, {
                    ref: a
                }) : null
            };

            function H(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            U.displayName = "Presence";
            let $ = 0;

            function Y() {
                (0, o.useEffect)((() => {
                    var e, t;
                    const n = document.querySelectorAll("[data-radix-focus-guard]");
                    return document.body.insertAdjacentElement("afterbegin", null !== (e = n[0]) && void 0 !== e ? e : K()), document.body.insertAdjacentElement("beforeend", null !== (t = n[1]) && void 0 !== t ? t : K()), $++, () => {
                        1 === $ && document.querySelectorAll("[data-radix-focus-guard]").forEach((e => e.remove())), $--
                    }
                }), [])
            }

            function K() {
                const e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
            }
            var z = n(46050),
                X = "right-scroll-bar-position",
                q = "width-before-scroll-bar",
                G = n(96922),
                J = (0, n(66684)._)(),
                Q = function() {},
                ee = o.forwardRef((function(e, t) {
                    var n = o.useRef(null),
                        r = o.useState({
                            onScrollCapture: Q,
                            onWheelCapture: Q,
                            onTouchMoveCapture: Q
                        }),
                        i = r[0],
                        a = r[1],
                        u = e.forwardProps,
                        c = e.children,
                        s = e.className,
                        l = e.removeScrollBar,
                        f = e.enabled,
                        d = e.shards,
                        p = e.sideCar,
                        v = e.noIsolation,
                        m = e.inert,
                        h = e.allowPinchZoom,
                        g = e.as,
                        y = void 0 === g ? "div" : g,
                        b = (0, z._T)(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]),
                        E = p,
                        w = (0, G.q)([n, t]),
                        C = (0, z.pi)((0, z.pi)({}, b), i);
                    return o.createElement(o.Fragment, null, f && o.createElement(E, {
                        sideCar: J,
                        removeScrollBar: l,
                        shards: d,
                        noIsolation: v,
                        inert: m,
                        setCallbacks: a,
                        allowPinchZoom: !!h,
                        lockRef: n
                    }), u ? o.cloneElement(o.Children.only(c), (0, z.pi)((0, z.pi)({}, C), {
                        ref: w
                    })) : o.createElement(y, (0, z.pi)({}, C, {
                        className: s,
                        ref: w
                    }), c))
                }));
            ee.defaultProps = {
                enabled: !0,
                removeScrollBar: !0,
                inert: !1
            }, ee.classNames = {
                fullWidth: q,
                zeroRight: X
            };
            var te, ne = function(e) {
                var t = e.sideCar,
                    n = (0, z._T)(e, ["sideCar"]);
                if (!t) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
                var r = t.read();
                if (!r) throw new Error("Sidecar medium not found");
                return o.createElement(r, (0, z.pi)({}, n))
            };
            ne.isSideCarExport = !0;

            function re() {
                if (!document) return null;
                var e = document.createElement("style");
                e.type = "text/css";
                var t = te || n.nc;
                return t && e.setAttribute("nonce", t), e
            }
            var oe = function() {
                    var e = 0,
                        t = null;
                    return {
                        add: function(n) {
                            var r, o;
                            0 == e && (t = re()) && (o = n, (r = t).styleSheet ? r.styleSheet.cssText = o : r.appendChild(document.createTextNode(o)), function(e) {
                                (document.head || document.getElementsByTagName("head")[0]).appendChild(e)
                            }(t)), e++
                        },
                        remove: function() {
                            !--e && t && (t.parentNode && t.parentNode.removeChild(t), t = null)
                        }
                    }
                },
                ie = function() {
                    var e, t = (e = oe(), function(t, n) {
                        o.useEffect((function() {
                            return e.add(t),
                                function() {
                                    e.remove()
                                }
                        }), [t && n])
                    });
                    return function(e) {
                        var n = e.styles,
                            r = e.dynamic;
                        return t(n, r), null
                    }
                },
                ae = {
                    left: 0,
                    top: 0,
                    right: 0,
                    gap: 0
                },
                ue = function(e) {
                    return parseInt(e || "", 10) || 0
                },
                ce = function(e) {
                    if (void 0 === e && (e = "margin"), "undefined" == typeof window) return ae;
                    var t = function(e) {
                            var t = window.getComputedStyle(document.body),
                                n = t["padding" === e ? "paddingLeft" : "marginLeft"],
                                r = t["padding" === e ? "paddingTop" : "marginTop"],
                                o = t["padding" === e ? "paddingRight" : "marginRight"];
                            return [ue(n), ue(r), ue(o)]
                        }(e),
                        n = document.documentElement.clientWidth,
                        r = window.innerWidth;
                    return {
                        left: t[0],
                        top: t[1],
                        right: t[2],
                        gap: Math.max(0, r - n + t[2] - t[0])
                    }
                },
                se = ie(),
                le = "data-scroll-locked",
                fe = function(e, t, n, r) {
                    var o = e.left,
                        i = e.top,
                        a = e.right,
                        u = e.gap;
                    return void 0 === n && (n = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(r, ";\n   padding-right: ").concat(u, "px ").concat(r, ";\n  }\n  body[").concat(le, "] {\n    overflow: hidden ").concat(r, ";\n    overscroll-behavior: contain;\n    ").concat([t && "position: relative ".concat(r, ";"), "margin" === n && "\n    padding-left: ".concat(o, "px;\n    padding-top: ").concat(i, "px;\n    padding-right: ").concat(a, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(u, "px ").concat(r, ";\n    "), "padding" === n && "padding-right: ".concat(u, "px ").concat(r, ";")].filter(Boolean).join(""), "\n  }\n  \n  .").concat(X, " {\n    right: ").concat(u, "px ").concat(r, ";\n  }\n  \n  .").concat(q, " {\n    margin-right: ").concat(u, "px ").concat(r, ";\n  }\n  \n  .").concat(X, " .").concat(X, " {\n    right: 0 ").concat(r, ";\n  }\n  \n  .").concat(q, " .").concat(q, " {\n    margin-right: 0 ").concat(r, ";\n  }\n  \n  body[").concat(le, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(u, "px;\n  }\n")
                },
                de = function() {
                    var e = parseInt(document.body.getAttribute(le) || "0", 10);
                    return isFinite(e) ? e : 0
                },
                pe = function(e) {
                    var t = e.noRelative,
                        n = e.noImportant,
                        r = e.gapMode,
                        i = void 0 === r ? "margin" : r;
                    o.useEffect((function() {
                        return document.body.setAttribute(le, (de() + 1).toString()),
                            function() {
                                var e = de() - 1;
                                e <= 0 ? document.body.removeAttribute(le) : document.body.setAttribute(le, e.toString())
                            }
                    }), []);
                    var a = o.useMemo((function() {
                        return ce(i)
                    }), [i]);
                    return o.createElement(se, {
                        styles: fe(a, !t, i, n ? "" : "!important")
                    })
                },
                ve = !1;
            if ("undefined" != typeof window) try {
                var me = Object.defineProperty({}, "passive", {
                    get: function() {
                        return ve = !0, !0
                    }
                });
                window.addEventListener("test", me, me), window.removeEventListener("test", me, me)
            } catch (e) {
                ve = !1
            }
            var he = !!ve && {
                    passive: !1
                },
                ge = function(e, t) {
                    var n = window.getComputedStyle(e);
                    return "hidden" !== n[t] && !(n.overflowY === n.overflowX && ! function(e) {
                        return "TEXTAREA" === e.tagName
                    }(e) && "visible" === n[t])
                },
                ye = function(e, t) {
                    var n = t;
                    do {
                        if ("undefined" != typeof ShadowRoot && n instanceof ShadowRoot && (n = n.host), be(e, n)) {
                            var r = Ee(e, n);
                            if (r[1] > r[2]) return !0
                        }
                        n = n.parentNode
                    } while (n && n !== document.body);
                    return !1
                },
                be = function(e, t) {
                    return "v" === e ? function(e) {
                        return ge(e, "overflowY")
                    }(t) : function(e) {
                        return ge(e, "overflowX")
                    }(t)
                },
                Ee = function(e, t) {
                    return "v" === e ? [(n = t).scrollTop, n.scrollHeight, n.clientHeight] : function(e) {
                        return [e.scrollLeft, e.scrollWidth, e.clientWidth]
                    }(t);
                    var n
                },
                we = function(e) {
                    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
                },
                Ce = function(e) {
                    return [e.deltaX, e.deltaY]
                },
                Se = function(e) {
                    return e && "current" in e ? e.current : e
                },
                Oe = function(e) {
                    return "\n  .block-interactivity-".concat(e, " {pointer-events: none;}\n  .allow-interactivity-").concat(e, " {pointer-events: all;}\n")
                },
                Pe = 0,
                Te = [];
            var Ae = function(e, t) {
                    return e.useMedium(t), ne
                }(J, (function(e) {
                    var t = o.useRef([]),
                        n = o.useRef([0, 0]),
                        r = o.useRef(),
                        i = o.useState(Pe++)[0],
                        a = o.useState((function() {
                            return ie()
                        }))[0],
                        u = o.useRef(e);
                    o.useEffect((function() {
                        u.current = e
                    }), [e]), o.useEffect((function() {
                        if (e.inert) {
                            document.body.classList.add("block-interactivity-".concat(i));
                            var t = (0, z.ev)([e.lockRef.current], (e.shards || []).map(Se), !0).filter(Boolean);
                            return t.forEach((function(e) {
                                    return e.classList.add("allow-interactivity-".concat(i))
                                })),
                                function() {
                                    document.body.classList.remove("block-interactivity-".concat(i)), t.forEach((function(e) {
                                        return e.classList.remove("allow-interactivity-".concat(i))
                                    }))
                                }
                        }
                    }), [e.inert, e.lockRef.current, e.shards]);
                    var c = o.useCallback((function(e, t) {
                            if ("touches" in e && 2 === e.touches.length) return !u.current.allowPinchZoom;
                            var o, i = we(e),
                                a = n.current,
                                c = "deltaX" in e ? e.deltaX : a[0] - i[0],
                                s = "deltaY" in e ? e.deltaY : a[1] - i[1],
                                l = e.target,
                                f = Math.abs(c) > Math.abs(s) ? "h" : "v";
                            if ("touches" in e && "h" === f && "range" === l.type) return !1;
                            var d = ye(f, l);
                            if (!d) return !0;
                            if (d ? o = f : (o = "v" === f ? "h" : "v", d = ye(f, l)), !d) return !1;
                            if (!r.current && "changedTouches" in e && (c || s) && (r.current = o), !o) return !0;
                            var p = r.current || o;
                            return function(e, t, n, r, o) {
                                var i = function(e, t) {
                                        return "h" === e && "rtl" === t ? -1 : 1
                                    }(e, window.getComputedStyle(t).direction),
                                    a = i * r,
                                    u = n.target,
                                    c = t.contains(u),
                                    s = !1,
                                    l = a > 0,
                                    f = 0,
                                    d = 0;
                                do {
                                    var p = Ee(e, u),
                                        v = p[0],
                                        m = p[1] - p[2] - i * v;
                                    (v || m) && be(e, u) && (f += m, d += v), u = u.parentNode
                                } while (!c && u !== document.body || c && (t.contains(u) || t === u));
                                return (l && (o && 0 === f || !o && a > f) || !l && (o && 0 === d || !o && -a > d)) && (s = !0), s
                            }(p, t, e, "h" === p ? c : s, !0)
                        }), []),
                        s = o.useCallback((function(e) {
                            var n = e;
                            if (Te.length && Te[Te.length - 1] === a) {
                                var r = "deltaY" in n ? Ce(n) : we(n),
                                    o = t.current.filter((function(e) {
                                        return e.name === n.type && e.target === n.target && (t = e.delta, o = r, t[0] === o[0] && t[1] === o[1]);
                                        var t, o
                                    }))[0];
                                if (o && o.should) n.cancelable && n.preventDefault();
                                else if (!o) {
                                    var i = (u.current.shards || []).map(Se).filter(Boolean).filter((function(e) {
                                        return e.contains(n.target)
                                    }));
                                    (i.length > 0 ? c(n, i[0]) : !u.current.noIsolation) && n.cancelable && n.preventDefault()
                                }
                            }
                        }), []),
                        l = o.useCallback((function(e, n, r, o) {
                            var i = {
                                name: e,
                                delta: n,
                                target: r,
                                should: o
                            };
                            t.current.push(i), setTimeout((function() {
                                t.current = t.current.filter((function(e) {
                                    return e !== i
                                }))
                            }), 1)
                        }), []),
                        f = o.useCallback((function(e) {
                            n.current = we(e), r.current = void 0
                        }), []),
                        d = o.useCallback((function(t) {
                            l(t.type, Ce(t), t.target, c(t, e.lockRef.current))
                        }), []),
                        p = o.useCallback((function(t) {
                            l(t.type, we(t), t.target, c(t, e.lockRef.current))
                        }), []);
                    o.useEffect((function() {
                        return Te.push(a), e.setCallbacks({
                                onScrollCapture: d,
                                onWheelCapture: d,
                                onTouchMoveCapture: p
                            }), document.addEventListener("wheel", s, he), document.addEventListener("touchmove", s, he), document.addEventListener("touchstart", f, he),
                            function() {
                                Te = Te.filter((function(e) {
                                    return e !== a
                                })), document.removeEventListener("wheel", s, he), document.removeEventListener("touchmove", s, he), document.removeEventListener("touchstart", f, he)
                            }
                    }), []);
                    var v = e.removeScrollBar,
                        m = e.inert;
                    return o.createElement(o.Fragment, null, m ? o.createElement(a, {
                        styles: Oe(i)
                    }) : null, v ? o.createElement(pe, {
                        gapMode: "margin"
                    }) : null)
                })),
                Re = o.forwardRef((function(e, t) {
                    return o.createElement(ee, (0, z.pi)({}, e, {
                        ref: t,
                        sideCar: Ae
                    }))
                }));
            Re.classNames = ee.classNames;
            var De = Re,
                Ne = function(e) {
                    return "undefined" == typeof document ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body
                },
                xe = new WeakMap,
                Le = new WeakMap,
                ke = {},
                Ie = 0,
                Me = function(e) {
                    return e && (e.host || Me(e.parentNode))
                },
                _e = function(e, t, n, r) {
                    var o = function(e, t) {
                        return t.map((function(t) {
                            if (e.contains(t)) return t;
                            var n = Me(t);
                            return n && e.contains(n) ? n : null
                        })).filter((function(e) {
                            return Boolean(e)
                        }))
                    }(t, Array.isArray(e) ? e : [e]);
                    ke[n] || (ke[n] = new WeakMap);
                    var i = ke[n],
                        a = [],
                        u = new Set,
                        c = new Set(o),
                        s = function(e) {
                            e && !u.has(e) && (u.add(e), s(e.parentNode))
                        };
                    o.forEach(s);
                    var l = function(e) {
                        e && !c.has(e) && Array.prototype.forEach.call(e.children, (function(e) {
                            if (u.has(e)) l(e);
                            else try {
                                var t = e.getAttribute(r),
                                    o = null !== t && "false" !== t,
                                    c = (xe.get(e) || 0) + 1,
                                    s = (i.get(e) || 0) + 1;
                                xe.set(e, c), i.set(e, s), a.push(e), 1 === c && o && Le.set(e, !0), 1 === s && e.setAttribute(n, "true"), o || e.setAttribute(r, "true")
                            } catch (e) {}
                        }))
                    };
                    return l(t), u.clear(), Ie++,
                        function() {
                            a.forEach((function(e) {
                                var t = xe.get(e) - 1,
                                    o = i.get(e) - 1;
                                xe.set(e, t), i.set(e, o), t || (Le.has(e) || e.removeAttribute(r), Le.delete(e)), o || e.removeAttribute(n)
                            })), --Ie || (xe = new WeakMap, xe = new WeakMap, Le = new WeakMap, ke = {})
                        }
                },
                je = function(e, t, n) {
                    void 0 === n && (n = "data-aria-hidden");
                    var r = Array.from(Array.isArray(e) ? e : [e]),
                        o = t || Ne(e);
                    return o ? (r.push.apply(r, Array.from(o.querySelectorAll("[aria-live]"))), _e(r, o, n, "aria-hidden")) : function() {
                        return null
                    }
                };
            const Fe = "Dialog",
                [Ze, We] = function(e, t = []) {
                    let n = [];
                    const r = () => {
                        const t = n.map((e => (0, o.createContext)(e)));
                        return function(n) {
                            const r = (null == n ? void 0 : n[e]) || t;
                            return (0, o.useMemo)((() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: r
                                }
                            })), [n, r])
                        }
                    };
                    return r.scopeName = e, [function(t, r) {
                        const i = (0, o.createContext)(r),
                            a = n.length;

                        function u(t) {
                            const {
                                scope: n,
                                children: r,
                                ...u
                            } = t, c = (null == n ? void 0 : n[e][a]) || i, s = (0, o.useMemo)((() => u), Object.values(u));
                            return (0, o.createElement)(c.Provider, {
                                value: s
                            }, r)
                        }
                        return n = [...n, r], u.displayName = t + "Provider", [u, function(n, u) {
                            const c = (null == u ? void 0 : u[e][a]) || i,
                                s = (0, o.useContext)(c);
                            if (s) return s;
                            if (void 0 !== r) return r;
                            throw new Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, s(r, ...t)]
                }(Fe),
                [Ve, Be] = Ze(Fe),
                Ue = e => {
                    const {
                        __scopeDialog: t,
                        children: n,
                        open: r,
                        defaultOpen: i,
                        onOpenChange: a,
                        modal: u = !0
                    } = e, c = (0, o.useRef)(null), s = (0, o.useRef)(null), [l = !1, f] = m({
                        prop: r,
                        defaultProp: i,
                        onChange: a
                    });
                    return (0, o.createElement)(Ve, {
                        scope: t,
                        triggerRef: c,
                        contentRef: s,
                        contentId: p(),
                        titleId: p(),
                        descriptionId: p(),
                        open: l,
                        onOpenChange: f,
                        onOpenToggle: (0, o.useCallback)((() => f((e => !e))), [f]),
                        modal: u
                    }, n)
                },
                He = "DialogTrigger",
                $e = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        ...i
                    } = e, u = Be(He, n), s = c(t, u.triggerRef);
                    return (0, o.createElement)(S.button, (0, r.Z)({
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": u.open,
                        "aria-controls": u.contentId,
                        "data-state": lt(u.open)
                    }, i, {
                        ref: s,
                        onClick: a(e.onClick, u.onOpenToggle)
                    }))
                })),
                Ye = "DialogPortal",
                [Ke, ze] = Ze(Ye, {
                    forceMount: void 0
                }),
                Xe = e => {
                    const {
                        __scopeDialog: t,
                        forceMount: n,
                        children: r,
                        container: i
                    } = e, a = Be(Ye, t);
                    return (0, o.createElement)(Ke, {
                        scope: t,
                        forceMount: n
                    }, o.Children.map(r, (e => (0, o.createElement)(U, {
                        present: n || a.open
                    }, (0, o.createElement)(B, {
                        asChild: !0,
                        container: i
                    }, e)))))
                },
                qe = "DialogOverlay",
                Ge = (0, o.forwardRef)(((e, t) => {
                    const n = ze(qe, e.__scopeDialog),
                        {
                            forceMount: i = n.forceMount,
                            ...a
                        } = e,
                        u = Be(qe, e.__scopeDialog);
                    return u.modal ? (0, o.createElement)(U, {
                        present: i || u.open
                    }, (0, o.createElement)(Je, (0, r.Z)({}, a, {
                        ref: t
                    }))) : null
                })),
                Je = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        ...i
                    } = e, a = Be(qe, n);
                    return (0, o.createElement)(De, {
                        as: y,
                        allowPinchZoom: !0,
                        shards: [a.contentRef]
                    }, (0, o.createElement)(S.div, (0, r.Z)({
                        "data-state": lt(a.open)
                    }, i, {
                        ref: t,
                        style: {
                            pointerEvents: "auto",
                            ...i.style
                        }
                    })))
                })),
                Qe = "DialogContent",
                et = (0, o.forwardRef)(((e, t) => {
                    const n = ze(Qe, e.__scopeDialog),
                        {
                            forceMount: i = n.forceMount,
                            ...a
                        } = e,
                        u = Be(Qe, e.__scopeDialog);
                    return (0, o.createElement)(U, {
                        present: i || u.open
                    }, u.modal ? (0, o.createElement)(tt, (0, r.Z)({}, a, {
                        ref: t
                    })) : (0, o.createElement)(nt, (0, r.Z)({}, a, {
                        ref: t
                    })))
                })),
                tt = (0, o.forwardRef)(((e, t) => {
                    const n = Be(Qe, e.__scopeDialog),
                        i = (0, o.useRef)(null),
                        u = c(t, n.contentRef, i);
                    return (0, o.useEffect)((() => {
                        const e = i.current;
                        if (e) return je(e)
                    }), []), (0, o.createElement)(rt, (0, r.Z)({}, e, {
                        ref: u,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: !0,
                        onCloseAutoFocus: a(e.onCloseAutoFocus, (e => {
                            var t;
                            e.preventDefault(), null === (t = n.triggerRef.current) || void 0 === t || t.focus()
                        })),
                        onPointerDownOutside: a(e.onPointerDownOutside, (e => {
                            const t = e.detail.originalEvent,
                                n = 0 === t.button && !0 === t.ctrlKey;
                            (2 === t.button || n) && e.preventDefault()
                        })),
                        onFocusOutside: a(e.onFocusOutside, (e => e.preventDefault()))
                    }))
                })),
                nt = (0, o.forwardRef)(((e, t) => {
                    const n = Be(Qe, e.__scopeDialog),
                        i = (0, o.useRef)(!1),
                        a = (0, o.useRef)(!1);
                    return (0, o.createElement)(rt, (0, r.Z)({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var r, o;
                            (null === (r = e.onCloseAutoFocus) || void 0 === r || r.call(e, t), t.defaultPrevented) || (i.current || null === (o = n.triggerRef.current) || void 0 === o || o.focus(), t.preventDefault());
                            i.current = !1, a.current = !1
                        },
                        onInteractOutside: t => {
                            var r, o;
                            null === (r = e.onInteractOutside) || void 0 === r || r.call(e, t), t.defaultPrevented || (i.current = !0, "pointerdown" === t.detail.originalEvent.type && (a.current = !0));
                            const u = t.target;
                            (null === (o = n.triggerRef.current) || void 0 === o ? void 0 : o.contains(u)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && a.current && t.preventDefault()
                        }
                    }))
                })),
                rt = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        trapFocus: i,
                        onOpenAutoFocus: a,
                        onCloseAutoFocus: u,
                        ...s
                    } = e, l = Be(Qe, n), f = c(t, (0, o.useRef)(null));
                    return Y(), (0, o.createElement)(o.Fragment, null, (0, o.createElement)(M, {
                        asChild: !0,
                        loop: !0,
                        trapped: i,
                        onMountAutoFocus: a,
                        onUnmountAutoFocus: u
                    }, (0, o.createElement)(D, (0, r.Z)({
                        role: "dialog",
                        id: l.contentId,
                        "aria-describedby": l.descriptionId,
                        "aria-labelledby": l.titleId,
                        "data-state": lt(l.open)
                    }, s, {
                        ref: f,
                        onDismiss: () => l.onOpenChange(!1)
                    }))), !1)
                })),
                ot = "DialogTitle",
                it = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        ...i
                    } = e, a = Be(ot, n);
                    return (0, o.createElement)(S.h2, (0, r.Z)({
                        id: a.titleId
                    }, i, {
                        ref: t
                    }))
                })),
                at = "DialogDescription",
                ut = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        ...i
                    } = e, a = Be(at, n);
                    return (0, o.createElement)(S.p, (0, r.Z)({
                        id: a.descriptionId
                    }, i, {
                        ref: t
                    }))
                })),
                ct = "DialogClose",
                st = (0, o.forwardRef)(((e, t) => {
                    const {
                        __scopeDialog: n,
                        ...i
                    } = e, u = Be(ct, n);
                    return (0, o.createElement)(S.button, (0, r.Z)({
                        type: "button"
                    }, i, {
                        ref: t,
                        onClick: a(e.onClick, (() => u.onOpenChange(!1)))
                    }))
                }));

            function lt(e) {
                return e ? "open" : "closed"
            }
            const ft = "DialogTitleWarning",
                [dt, pt] = function(e, t) {
                    const n = (0, o.createContext)(t);

                    function r(e) {
                        const {
                            children: t,
                            ...r
                        } = e, i = (0, o.useMemo)((() => r), Object.values(r));
                        return (0, o.createElement)(n.Provider, {
                            value: i
                        }, t)
                    }
                    return r.displayName = e + "Provider", [r, function(r) {
                        const i = (0, o.useContext)(n);
                        if (i) return i;
                        if (void 0 !== t) return t;
                        throw new Error(`\`${r}\` must be used within \`${e}\``)
                    }]
                }(ft, {
                    contentName: Qe,
                    titleName: ot,
                    docsSlug: "dialog"
                }),
                vt = Ue,
                mt = $e,
                ht = Xe,
                gt = Ge,
                yt = et,
                bt = it,
                Et = ut,
                wt = st
        },
        76235: function(e, t, n) {
            "use strict";

            function r(e) {
                let t, n, r, a, u, c, s;
                return l(), {
                    feed: function(e) {
                        n = n ? n + e : e, t && i(n) && (n = n.slice(o.length));
                        t = !1;
                        const u = n.length;
                        let c = 0,
                            s = !1;
                        for (; c < u;) {
                            s && ("\n" === n[c] && ++c, s = !1);
                            let e, t = -1,
                                o = a;
                            for (let i = r; t < 0 && i < u; ++i) e = n[i], ":" === e && o < 0 ? o = i - c : "\r" === e ? (s = !0, t = i - c) : "\n" === e && (t = i - c);
                            if (t < 0) {
                                r = u - c, a = o;
                                break
                            }
                            r = 0, a = -1, f(n, c, o, t), c += t + 1
                        }
                        c === u ? n = "" : c > 0 && (n = n.slice(c))
                    },
                    reset: l
                };

                function l() {
                    t = !0, n = "", r = 0, a = -1, u = void 0, c = void 0, s = ""
                }

                function f(t, n, r, o) {
                    if (0 === o) return s.length > 0 && (e({
                        type: "event",
                        id: u,
                        event: c || void 0,
                        data: s.slice(0, -1)
                    }), s = "", u = void 0), void(c = void 0);
                    const i = r < 0,
                        a = t.slice(n, n + (i ? o : r));
                    let l = 0;
                    l = i ? o : " " === t[n + r + 1] ? r + 2 : r + 1;
                    const f = n + l,
                        d = o - l,
                        p = t.slice(f, f + d).toString();
                    if ("data" === a) s += p ? "".concat(p, "\n") : "\n";
                    else if ("event" === a) c = p;
                    else if ("id" !== a || p.includes("\0")) {
                        if ("retry" === a) {
                            const t = parseInt(p, 10);
                            Number.isNaN(t) || e({
                                type: "reconnect-interval",
                                value: t
                            })
                        }
                    } else u = p
                }
            }
            n.d(t, {
                j: function() {
                    return r
                }
            });
            const o = [239, 187, 191];

            function i(e) {
                return o.every(((t, n) => e.charCodeAt(n) === t))
            }
        },
        72449: function(e, t, n) {
            "use strict";
            n.d(t, {
                H: function() {
                    return K
                }
            });
            var r = n(86534),
                o = n(84371);
            var i = n(37625),
                a = n(18049),
                u = n(42772),
                c = n(55251),
                s = n(67956);
            const l = (e, t, n) => {
                const r = t - e;
                return ((n - e) % r + r) % r + e
            };
            var f = n(25794);

            function d(e, t) {
                return (0, f.N)(e) ? e[l(0, e.length, t)] : e
            }
            var p = n(48545),
                v = n(87430),
                m = n(29556);

            function h(e) {
                return "object" == typeof e && !Array.isArray(e)
            }

            function g(e, t, n, r) {
                return "string" == typeof e && h(t) ? (0, i.IG)(e, n, r) : e instanceof NodeList ? Array.from(e) : Array.isArray(e) ? e : [e]
            }

            function y(e, t, n) {
                return e * (t + 1)
            }

            function b(e, t, n, r) {
                var o;
                return "number" == typeof t ? t : t.startsWith("-") || t.startsWith("+") ? Math.max(0, e + parseFloat(t)) : "<" === t ? n : null !== (o = r.get(t)) && void 0 !== o ? o : e
            }
            var E = n(72365),
                w = n(17837);

            function C(e, t, n, r, o, i) {
                ! function(e, t, n) {
                    for (let r = 0; r < e.length; r++) {
                        const o = e[r];
                        o.at > t && o.at < n && ((0, E.cl)(e, o), r--)
                    }
                }(e, o, i);
                for (let a = 0; a < t.length; a++) e.push({
                    value: t[a],
                    at: (0, w.t)(o, i, r[a]),
                    easing: d(n, a)
                })
            }

            function S(e, t) {
                for (let n = 0; n < e.length; n++) e[n] = e[n] / (t + 1)
            }

            function O(e, t) {
                return e.at === t.at ? null === e.value ? 1 : null === t.value ? -1 : 0 : e.at - t.at
            }
            const P = "easeInOut",
                T = 20;

            function A(e, t) {
                return !t.has(e) && t.set(e, {}), t.get(e)
            }

            function R(e, t) {
                return t[e] || (t[e] = []), t[e]
            }

            function D(e) {
                return Array.isArray(e) ? e : [e]
            }

            function N(e, t) {
                return e && e[t] ? { ...e,
                    ...e[t]
                } : { ...e
                }
            }
            const x = e => "number" == typeof e,
                L = e => e.every(x);
            var k = n(69202),
                I = n(57460),
                M = n(77553),
                _ = n(9464),
                j = n(96952),
                F = n(63431),
                Z = n(27035);
            class W extends Z.l {
                constructor() {
                    super(...arguments), this.type = "object"
                }
                readValueFromInstance(e, t) {
                    if (function(e, t) {
                            return e in t
                        }(t, e)) {
                        const n = e[t];
                        if ("string" == typeof n || "number" == typeof n) return n
                    }
                }
                getBaseTargetFromProps() {}
                removeValueFromRenderState(e, t) {
                    delete t.output[e]
                }
                measureInstanceViewportBox() {
                    return (0, F.dO)()
                }
                build(e, t) {
                    Object.assign(e.output, t)
                }
                renderInstance(e, {
                    output: t
                }) {
                    Object.assign(e, t)
                }
                sortInstanceNodePosition() {
                    return 0
                }
            }

            function V(e) {
                const t = {
                        presenceContext: null,
                        props: {},
                        visualState: {
                            renderState: {
                                transform: {},
                                transformOrigin: {},
                                style: {},
                                vars: {},
                                attrs: {}
                            },
                            latestValues: {}
                        }
                    },
                    n = (0, M.v)(e) ? new _.e(t) : new j.W(t);
                n.mount(e), k.R.set(e, n)
            }

            function B(e) {
                const t = new W({
                    presenceContext: null,
                    props: {},
                    visualState: {
                        renderState: {
                            output: {}
                        },
                        latestValues: {}
                    }
                });
                t.mount(e), k.R.set(e, t)
            }
            var U = n(7623);

            function H(e, t, n, r) {
                const o = [];
                if (function(e, t) {
                        return (0, m.i)(e) || "number" == typeof e || "string" == typeof e && !h(t)
                    }(e, t)) o.push((0, U.D)(e, h(t) && t.default || t, n && n.default || n));
                else {
                    const i = g(e, t, r),
                        a = i.length;
                    (0, c.k)(Boolean(a), "No valid elements provided.");
                    for (let e = 0; e < a; e++) {
                        const r = i[e],
                            u = r instanceof Element ? V : B;
                        k.R.has(r) || u(r);
                        const c = k.R.get(r),
                            s = { ...n
                            };
                        "delay" in s && "function" == typeof s.delay && (s.delay = s.delay(e, a)), o.push(...(0, I.w)(c, { ...t,
                            transition: s
                        }, {}))
                    }
                }
                return o
            }

            function $(e, t, n) {
                const r = [],
                    o = function(e, {
                        defaultTransition: t = {},
                        ...n
                    } = {}, r, o) {
                        const a = t.duration || .3,
                            l = new Map,
                            f = new Map,
                            h = {},
                            E = new Map;
                        let w = 0,
                            x = 0,
                            k = 0;
                        for (let n = 0; n < e.length; n++) {
                            const s = e[n];
                            if ("string" == typeof s) {
                                E.set(s, x);
                                continue
                            }
                            if (!Array.isArray(s)) {
                                E.set(s.name, b(x, s.at, w, E));
                                continue
                            }
                            let [l, O, P = {}] = s;
                            void 0 !== P.at && (x = b(x, P.at, w, E));
                            let I = 0;
                            const M = (e, n, r, s = 0, l = 0) => {
                                const f = D(e),
                                    {
                                        delay: m = 0,
                                        times: h = (0, p.Y)(f),
                                        type: g = "keyframes",
                                        repeat: b,
                                        repeatType: E,
                                        repeatDelay: w = 0,
                                        ...O
                                    } = n;
                                let {
                                    ease: P = t.ease || "easeOut",
                                    duration: A
                                } = n;
                                const R = "function" == typeof m ? m(s, l) : m,
                                    N = f.length,
                                    M = (0, i.xD)(g) ? g : null == o ? void 0 : o[g];
                                if (N <= 2 && M) {
                                    let e = 100;
                                    if (2 === N && L(f)) {
                                        const t = f[1] - f[0];
                                        e = Math.abs(t)
                                    }
                                    const t = { ...O
                                    };
                                    void 0 !== A && (t.duration = (0, u.w)(A));
                                    const n = (0, i.S9)(t, e, M);
                                    P = n.ease, A = n.duration
                                }
                                null != A || (A = a);
                                const _ = x + R;
                                1 === h.length && 0 === h[0] && (h[1] = 1);
                                const j = h.length - f.length;
                                if (j > 0 && (0, v.c)(h, j), 1 === f.length && f.unshift(null), b) {
                                    (0, c.k)(b < T, "Repeat count too high, must be less than 20"), A = y(A, b);
                                    const e = [...f],
                                        t = [...h];
                                    P = Array.isArray(P) ? [...P] : [P];
                                    const n = [...P];
                                    for (let r = 0; r < b; r++) {
                                        f.push(...e);
                                        for (let o = 0; o < e.length; o++) h.push(t[o] + (r + 1)), P.push(0 === o ? "linear" : d(n, o - 1))
                                    }
                                    S(h, b)
                                }
                                const F = _ + A;
                                C(r, f, P, h, _, F), I = Math.max(R + A, I), k = Math.max(F, k)
                            };
                            if ((0, m.i)(l)) M(O, P, R("default", A(l, f)));
                            else {
                                const e = g(l, O, r, h),
                                    t = e.length;
                                for (let n = 0; n < t; n++) {
                                    const r = A(e[n], f);
                                    for (const e in O) M(O[e], N(P, e), R(e, r), n, t)
                                }
                            }
                            w = x, x += I
                        }
                        return f.forEach(((e, r) => {
                            for (const o in e) {
                                const i = e[o];
                                i.sort(O);
                                const a = [],
                                    u = [],
                                    c = [];
                                for (let e = 0; e < i.length; e++) {
                                    const {
                                        at: t,
                                        value: n,
                                        easing: r
                                    } = i[e];
                                    a.push(n), u.push((0, s.Y)(0, k, t)), c.push(r || "easeOut")
                                }
                                0 !== u[0] && (u.unshift(0), a.unshift(a[0]), c.unshift(P)), 1 !== u[u.length - 1] && (u.push(1), a.push(null)), l.has(r) || l.set(r, {
                                    keyframes: {},
                                    transition: {}
                                });
                                const f = l.get(r);
                                f.keyframes[o] = a, f.transition[o] = { ...t,
                                    duration: k,
                                    ease: c,
                                    times: u,
                                    ...n
                                }
                            }
                        })), l
                    }(e, t, n, {
                        spring: a.S
                    });
                return o.forEach((({
                    keyframes: e,
                    transition: t
                }, n) => {
                    r.push(...H(n, e, t))
                })), r
            }

            function Y(e) {
                return function(t, n, r) {
                    let o = [];
                    var a;
                    a = t, o = Array.isArray(a) && a.some(Array.isArray) ? $(t, n, e) : H(t, n, r, e);
                    const u = new i.sP(o);
                    return e && e.animations.push(u), u
                }
            }
            Y();

            function K() {
                const e = (0, r.h)((() => ({
                        current: null,
                        animations: []
                    }))),
                    t = (0, r.h)((() => Y(e)));
                var n;
                return n = () => {
                    e.animations.forEach((e => e.stop()))
                }, (0, o.useEffect)((() => () => n()), []), [e, t]
            }
        },
        78229: function(e, t, n) {
            "use strict";
            n.d(t, {
                W: function() {
                    return o
                }
            });
            var r = n(84371);

            function o(e, t, n) {
                (0, r.useInsertionEffect)((() => e.on(t, n)), [e, t, n])
            }
        },
        76996: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return l
                }
            });
            var r = n(74646),
                o = n(81729),
                i = function() {
                    return o.Z.Date.now()
                },
                a = n(53140),
                u = Math.max,
                c = Math.min;
            var s = function(e, t, n) {
                var o, s, l, f, d, p, v = 0,
                    m = !1,
                    h = !1,
                    g = !0;
                if ("function" != typeof e) throw new TypeError("Expected a function");

                function y(t) {
                    var n = o,
                        r = s;
                    return o = s = void 0, v = t, f = e.apply(r, n)
                }

                function b(e) {
                    var n = e - p;
                    return void 0 === p || n >= t || n < 0 || h && e - v >= l
                }

                function E() {
                    var e = i();
                    if (b(e)) return w(e);
                    d = setTimeout(E, function(e) {
                        var n = t - (e - p);
                        return h ? c(n, l - (e - v)) : n
                    }(e))
                }

                function w(e) {
                    return d = void 0, g && o ? y(e) : (o = s = void 0, f)
                }

                function C() {
                    var e = i(),
                        n = b(e);
                    if (o = arguments, s = this, p = e, n) {
                        if (void 0 === d) return function(e) {
                            return v = e, d = setTimeout(E, t), m ? y(e) : f
                        }(p);
                        if (h) return clearTimeout(d), d = setTimeout(E, t), y(p)
                    }
                    return void 0 === d && (d = setTimeout(E, t)), f
                }
                return t = (0, a.Z)(t) || 0, (0, r.Z)(n) && (m = !!n.leading, l = (h = "maxWait" in n) ? u((0, a.Z)(n.maxWait) || 0, t) : l, g = "trailing" in n ? !!n.trailing : g), C.cancel = function() {
                    void 0 !== d && clearTimeout(d), v = 0, o = p = s = d = void 0
                }, C.flush = function() {
                    return void 0 === d ? f : w(i())
                }, C
            };
            var l = function(e, t, n) {
                var o = !0,
                    i = !0;
                if ("function" != typeof e) throw new TypeError("Expected a function");
                return (0, r.Z)(n) && (o = "leading" in n ? !!n.leading : o, i = "trailing" in n ? !!n.trailing : i), s(e, t, {
                    leading: o,
                    maxWait: t,
                    trailing: i
                })
            }
        }
    }
]);