! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            r = (new e.Error).stack;
        r && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[r] = "f41c0f14-3f1c-4c5a-8b0a-23a6d190ad1e", e._sentryDebugIdIdentifier = "sentry-dbid-f41c0f14-3f1c-4c5a-8b0a-23a6d190ad1e")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5880], {
        57782: function(e, r, o) {
            function t(e) {
                var r, o, n = "";
                if ("string" == typeof e || "number" == typeof e) n += e;
                else if ("object" == typeof e)
                    if (Array.isArray(e)) {
                        var s = e.length;
                        for (r = 0; r < s; r++) e[r] && (o = t(e[r])) && (n && (n += " "), n += o)
                    } else
                        for (o in e) e[o] && (n && (n += " "), n += o);
                return n
            }

            function n() {
                for (var e, r, o = 0, n = "", s = arguments.length; o < s; o++)(e = arguments[o]) && (r = t(e)) && (n && (n += " "), n += r);
                return n
            }
            o.d(r, {
                W: function() {
                    return n
                }
            })
        },
        79245: function(e, r, o) {
            o.d(r, {
                _: function() {
                    return u
                },
                E: function() {
                    return d
                }
            });
            var t = o(55251),
                n = o(23572),
                s = o(48819);

            function l(e, r) {
                [...r].reverse().forEach((o => {
                    const t = e.getVariant(o);
                    t && (0, n.C)(e, t), e.variantChildren && e.variantChildren.forEach((e => {
                        l(e, r)
                    }))
                }))
            }

            function i() {
                let e = !1;
                const r = new Set,
                    o = {
                        subscribe(e) {
                            return r.add(e), () => {
                                r.delete(e)
                            }
                        },
                        start(o, n) {
                            (0, t.k)(e, "controls.start() should only be called after a component has mounted. Consider calling within a useEffect hook.");
                            const l = [];
                            return r.forEach((e => {
                                l.push((0, s.d)(e, o, {
                                    transitionOverride: n
                                }))
                            })), Promise.all(l)
                        },
                        set(o) {
                            return (0, t.k)(e, "controls.set() should only be called after a component has mounted. Consider calling within a useEffect hook."), r.forEach((e => {
                                ! function(e, r) {
                                    Array.isArray(r) ? l(e, r) : "string" == typeof r ? l(e, [r]) : (0, n.C)(e, r)
                                }(e, o)
                            }))
                        },
                        stop() {
                            r.forEach((e => {
                                ! function(e) {
                                    e.values.forEach((e => e.stop()))
                                }(e)
                            }))
                        },
                        mount() {
                            return e = !0, () => {
                                e = !1, o.stop()
                            }
                        }
                    };
                return o
            }
            var a = o(86534),
                c = o(69682);

            function d() {
                const e = (0, a.h)(i);
                return (0, c.L)(e.mount, []), e
            }
            const u = d
        },
        11435: function(e, r, o) {
            o.d(r, {
                m6: function() {
                    return V
                }
            });

            function t(e) {
                const r = function(e) {
                        const {
                            theme: r,
                            prefix: o
                        } = e, t = {
                            nextPart: new Map,
                            validators: []
                        }, n = function(e, r) {
                            if (!r) return e;
                            return e.map((([e, o]) => [e, o.map((e => "string" == typeof e ? r + e : "object" == typeof e ? Object.fromEntries(Object.entries(e).map((([e, o]) => [r + e, o]))) : e))]))
                        }(Object.entries(e.classGroups), o);
                        return n.forEach((([e, o]) => {
                            l(o, t, e, r)
                        })), t
                    }(e),
                    {
                        conflictingClassGroups: o,
                        conflictingClassGroupModifiers: t
                    } = e;
                return {
                    getClassGroupId: function(e) {
                        const o = e.split("-");
                        return "" === o[0] && 1 !== o.length && o.shift(), n(o, r) || function(e) {
                            if (s.test(e)) {
                                const r = s.exec(e)[1],
                                    o = r ? .substring(0, r.indexOf(":"));
                                if (o) return "arbitrary.." + o
                            }
                        }(e)
                    },
                    getConflictingClassGroupIds: function(e, r) {
                        const n = o[e] || [];
                        return r && t[e] ? [...n, ...t[e]] : n
                    }
                }
            }

            function n(e, r) {
                if (0 === e.length) return r.classGroupId;
                const o = e[0],
                    t = r.nextPart.get(o),
                    s = t ? n(e.slice(1), t) : void 0;
                if (s) return s;
                if (0 === r.validators.length) return;
                const l = e.join("-");
                return r.validators.find((({
                    validator: e
                }) => e(l))) ? .classGroupId
            }
            const s = /^\[(.+)\]$/;

            function l(e, r, o, t) {
                e.forEach((e => {
                    if ("string" != typeof e) {
                        if ("function" == typeof e) return e.isThemeGetter ? void l(e(t), r, o, t) : void r.validators.push({
                            validator: e,
                            classGroupId: o
                        });
                        Object.entries(e).forEach((([e, n]) => {
                            l(n, i(r, e), o, t)
                        }))
                    } else {
                        ("" === e ? r : i(r, e)).classGroupId = o
                    }
                }))
            }

            function i(e, r) {
                let o = e;
                return r.split("-").forEach((e => {
                    o.nextPart.has(e) || o.nextPart.set(e, {
                        nextPart: new Map,
                        validators: []
                    }), o = o.nextPart.get(e)
                })), o
            }

            function a(e) {
                if (e < 1) return {
                    get: () => {},
                    set: () => {}
                };
                let r = 0,
                    o = new Map,
                    t = new Map;

                function n(n, s) {
                    o.set(n, s), r++, r > e && (r = 0, t = o, o = new Map)
                }
                return {
                    get(e) {
                        let r = o.get(e);
                        return void 0 !== r ? r : void 0 !== (r = t.get(e)) ? (n(e, r), r) : void 0
                    },
                    set(e, r) {
                        o.has(e) ? o.set(e, r) : n(e, r)
                    }
                }
            }

            function c(e) {
                const r = e.separator,
                    o = 1 === r.length,
                    t = r[0],
                    n = r.length;
                return function(e) {
                    const s = [];
                    let l, i = 0,
                        a = 0;
                    for (let c = 0; c < e.length; c++) {
                        let d = e[c];
                        if (0 === i) {
                            if (d === t && (o || e.slice(c, c + n) === r)) {
                                s.push(e.slice(a, c)), a = c + n;
                                continue
                            }
                            if ("/" === d) {
                                l = c;
                                continue
                            }
                        }
                        "[" === d ? i++ : "]" === d && i--
                    }
                    const c = 0 === s.length ? e : e.substring(a),
                        d = c.startsWith("!");
                    return {
                        modifiers: s,
                        hasImportantModifier: d,
                        baseClassName: d ? c.substring(1) : c,
                        maybePostfixModifierPosition: l && l > a ? l - a : void 0
                    }
                }
            }
            const d = /\s+/;

            function u() {
                let e, r, o = 0,
                    t = "";
                for (; o < arguments.length;)(e = arguments[o++]) && (r = p(e)) && (t && (t += " "), t += r);
                return t
            }

            function p(e) {
                if ("string" == typeof e) return e;
                let r, o = "";
                for (let t = 0; t < e.length; t++) e[t] && (r = p(e[t])) && (o && (o += " "), o += r);
                return o
            }

            function f(e, ...r) {
                let o, n, s, l = function(d) {
                    const u = r.reduce(((e, r) => r(e)), e());
                    return o = function(e) {
                        return {
                            cache: a(e.cacheSize),
                            splitModifiers: c(e),
                            ...t(e)
                        }
                    }(u), n = o.cache.get, s = o.cache.set, l = i, i(d)
                };

                function i(e) {
                    const r = n(e);
                    if (r) return r;
                    const t = function(e, r) {
                        const {
                            splitModifiers: o,
                            getClassGroupId: t,
                            getConflictingClassGroupIds: n
                        } = r, s = new Set;
                        return e.trim().split(d).map((e => {
                            const {
                                modifiers: r,
                                hasImportantModifier: n,
                                baseClassName: s,
                                maybePostfixModifierPosition: l
                            } = o(e);
                            let i = t(l ? s.substring(0, l) : s),
                                a = Boolean(l);
                            if (!i) {
                                if (!l) return {
                                    isTailwindClass: !1,
                                    originalClassName: e
                                };
                                if (i = t(s), !i) return {
                                    isTailwindClass: !1,
                                    originalClassName: e
                                };
                                a = !1
                            }
                            const c = function(e) {
                                if (e.length <= 1) return e;
                                const r = [];
                                let o = [];
                                return e.forEach((e => {
                                    "[" === e[0] ? (r.push(...o.sort(), e), o = []) : o.push(e)
                                })), r.push(...o.sort()), r
                            }(r).join(":");
                            return {
                                isTailwindClass: !0,
                                modifierId: n ? c + "!" : c,
                                classGroupId: i,
                                originalClassName: e,
                                hasPostfixModifier: a
                            }
                        })).reverse().filter((e => {
                            if (!e.isTailwindClass) return !0;
                            const {
                                modifierId: r,
                                classGroupId: o,
                                hasPostfixModifier: t
                            } = e, l = r + o;
                            return !s.has(l) && (s.add(l), n(o, t).forEach((e => s.add(r + e))), !0)
                        })).reverse().map((e => e.originalClassName)).join(" ")
                    }(e, o);
                    return s(e, t), t
                }
                return function() {
                    return l(u.apply(null, arguments))
                }
            }

            function b(e) {
                const r = r => r[e] || [];
                return r.isThemeGetter = !0, r
            }
            const m = /^\[(?:([a-z-]+):)?(.+)\]$/i,
                g = /^\d+\/\d+$/,
                h = new Set(["px", "full", "screen"]),
                y = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                v = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                w = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
                x = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                k = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;

            function z(e) {
                return j(e) || h.has(e) || g.test(e)
            }

            function C(e) {
                return A(e, "length", D)
            }

            function j(e) {
                return Boolean(e) && !Number.isNaN(Number(e))
            }

            function I(e) {
                return A(e, "number", j)
            }

            function E(e) {
                return Boolean(e) && Number.isInteger(Number(e))
            }

            function G(e) {
                return e.endsWith("%") && j(e.slice(0, -1))
            }

            function M(e) {
                return m.test(e)
            }

            function P(e) {
                return y.test(e)
            }
            const S = new Set(["length", "size", "percentage"]);

            function N(e) {
                return A(e, S, R)
            }

            function _(e) {
                return A(e, "position", R)
            }
            const T = new Set(["image", "url"]);

            function $(e) {
                return A(e, T, q)
            }

            function O(e) {
                return A(e, "", B)
            }

            function W() {
                return !0
            }

            function A(e, r, o) {
                const t = m.exec(e);
                return !!t && (t[1] ? "string" == typeof r ? t[1] === r : r.has(t[1]) : o(t[2]))
            }

            function D(e) {
                return v.test(e) && !w.test(e)
            }

            function R() {
                return !1
            }

            function B(e) {
                return x.test(e)
            }

            function q(e) {
                return k.test(e)
            }
            Symbol.toStringTag;

            function L() {
                const e = b("colors"),
                    r = b("spacing"),
                    o = b("blur"),
                    t = b("brightness"),
                    n = b("borderColor"),
                    s = b("borderRadius"),
                    l = b("borderSpacing"),
                    i = b("borderWidth"),
                    a = b("contrast"),
                    c = b("grayscale"),
                    d = b("hueRotate"),
                    u = b("invert"),
                    p = b("gap"),
                    f = b("gradientColorStops"),
                    m = b("gradientColorStopPositions"),
                    g = b("inset"),
                    h = b("margin"),
                    y = b("opacity"),
                    v = b("padding"),
                    w = b("saturate"),
                    x = b("scale"),
                    k = b("sepia"),
                    S = b("skew"),
                    T = b("space"),
                    A = b("translate"),
                    D = () => ["auto", M, r],
                    R = () => [M, r],
                    B = () => ["", z, C],
                    q = () => ["auto", j, M],
                    L = () => ["", "0", M],
                    V = () => [j, I],
                    F = () => [j, M];
                return {
                    cacheSize: 500,
                    separator: ":",
                    theme: {
                        colors: [W],
                        spacing: [z, C],
                        blur: ["none", "", P, M],
                        brightness: V(),
                        borderColor: [e],
                        borderRadius: ["none", "", "full", P, M],
                        borderSpacing: R(),
                        borderWidth: B(),
                        contrast: V(),
                        grayscale: L(),
                        hueRotate: F(),
                        invert: L(),
                        gap: R(),
                        gradientColorStops: [e],
                        gradientColorStopPositions: [G, C],
                        inset: D(),
                        margin: D(),
                        opacity: V(),
                        padding: R(),
                        saturate: V(),
                        scale: V(),
                        sepia: L(),
                        skew: F(),
                        space: R(),
                        translate: R()
                    },
                    classGroups: {
                        aspect: [{
                            aspect: ["auto", "square", "video", M]
                        }],
                        container: ["container"],
                        columns: [{
                            columns: [P]
                        }],
                        "break-after": [{
                            "break-after": ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"]
                        }],
                        "break-before": [{
                            "break-before": ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"]
                        }],
                        "break-inside": [{
                            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                        }],
                        "box-decoration": [{
                            "box-decoration": ["slice", "clone"]
                        }],
                        box: [{
                            box: ["border", "content"]
                        }],
                        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                        float: [{
                            float: ["right", "left", "none", "start", "end"]
                        }],
                        clear: [{
                            clear: ["left", "right", "both", "none", "start", "end"]
                        }],
                        isolation: ["isolate", "isolation-auto"],
                        "object-fit": [{
                            object: ["contain", "cover", "fill", "none", "scale-down"]
                        }],
                        "object-position": [{
                            object: ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top", M]
                        }],
                        overflow: [{
                            overflow: ["auto", "hidden", "clip", "visible", "scroll"]
                        }],
                        "overflow-x": [{
                            "overflow-x": ["auto", "hidden", "clip", "visible", "scroll"]
                        }],
                        "overflow-y": [{
                            "overflow-y": ["auto", "hidden", "clip", "visible", "scroll"]
                        }],
                        overscroll: [{
                            overscroll: ["auto", "contain", "none"]
                        }],
                        "overscroll-x": [{
                            "overscroll-x": ["auto", "contain", "none"]
                        }],
                        "overscroll-y": [{
                            "overscroll-y": ["auto", "contain", "none"]
                        }],
                        position: ["static", "fixed", "absolute", "relative", "sticky"],
                        inset: [{
                            inset: [g]
                        }],
                        "inset-x": [{
                            "inset-x": [g]
                        }],
                        "inset-y": [{
                            "inset-y": [g]
                        }],
                        start: [{
                            start: [g]
                        }],
                        end: [{
                            end: [g]
                        }],
                        top: [{
                            top: [g]
                        }],
                        right: [{
                            right: [g]
                        }],
                        bottom: [{
                            bottom: [g]
                        }],
                        left: [{
                            left: [g]
                        }],
                        visibility: ["visible", "invisible", "collapse"],
                        z: [{
                            z: ["auto", E, M]
                        }],
                        basis: [{
                            basis: D()
                        }],
                        "flex-direction": [{
                            flex: ["row", "row-reverse", "col", "col-reverse"]
                        }],
                        "flex-wrap": [{
                            flex: ["wrap", "wrap-reverse", "nowrap"]
                        }],
                        flex: [{
                            flex: ["1", "auto", "initial", "none", M]
                        }],
                        grow: [{
                            grow: L()
                        }],
                        shrink: [{
                            shrink: L()
                        }],
                        order: [{
                            order: ["first", "last", "none", E, M]
                        }],
                        "grid-cols": [{
                            "grid-cols": [W]
                        }],
                        "col-start-end": [{
                            col: ["auto", {
                                span: ["full", E, M]
                            }, M]
                        }],
                        "col-start": [{
                            "col-start": q()
                        }],
                        "col-end": [{
                            "col-end": q()
                        }],
                        "grid-rows": [{
                            "grid-rows": [W]
                        }],
                        "row-start-end": [{
                            row: ["auto", {
                                span: [E, M]
                            }, M]
                        }],
                        "row-start": [{
                            "row-start": q()
                        }],
                        "row-end": [{
                            "row-end": q()
                        }],
                        "grid-flow": [{
                            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                        }],
                        "auto-cols": [{
                            "auto-cols": ["auto", "min", "max", "fr", M]
                        }],
                        "auto-rows": [{
                            "auto-rows": ["auto", "min", "max", "fr", M]
                        }],
                        gap: [{
                            gap: [p]
                        }],
                        "gap-x": [{
                            "gap-x": [p]
                        }],
                        "gap-y": [{
                            "gap-y": [p]
                        }],
                        "justify-content": [{
                            justify: ["normal", "start", "end", "center", "between", "around", "evenly", "stretch"]
                        }],
                        "justify-items": [{
                            "justify-items": ["start", "end", "center", "stretch"]
                        }],
                        "justify-self": [{
                            "justify-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        "align-content": [{
                            content: ["normal", "start", "end", "center", "between", "around", "evenly", "stretch", "baseline"]
                        }],
                        "align-items": [{
                            items: ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "align-self": [{
                            self: ["auto", "start", "end", "center", "stretch", "baseline"]
                        }],
                        "place-content": [{
                            "place-content": ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline"]
                        }],
                        "place-items": [{
                            "place-items": ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "place-self": [{
                            "place-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        p: [{
                            p: [v]
                        }],
                        px: [{
                            px: [v]
                        }],
                        py: [{
                            py: [v]
                        }],
                        ps: [{
                            ps: [v]
                        }],
                        pe: [{
                            pe: [v]
                        }],
                        pt: [{
                            pt: [v]
                        }],
                        pr: [{
                            pr: [v]
                        }],
                        pb: [{
                            pb: [v]
                        }],
                        pl: [{
                            pl: [v]
                        }],
                        m: [{
                            m: [h]
                        }],
                        mx: [{
                            mx: [h]
                        }],
                        my: [{
                            my: [h]
                        }],
                        ms: [{
                            ms: [h]
                        }],
                        me: [{
                            me: [h]
                        }],
                        mt: [{
                            mt: [h]
                        }],
                        mr: [{
                            mr: [h]
                        }],
                        mb: [{
                            mb: [h]
                        }],
                        ml: [{
                            ml: [h]
                        }],
                        "space-x": [{
                            "space-x": [T]
                        }],
                        "space-x-reverse": ["space-x-reverse"],
                        "space-y": [{
                            "space-y": [T]
                        }],
                        "space-y-reverse": ["space-y-reverse"],
                        w: [{
                            w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", M, r]
                        }],
                        "min-w": [{
                            "min-w": [M, r, "min", "max", "fit"]
                        }],
                        "max-w": [{
                            "max-w": [M, r, "none", "full", "min", "max", "fit", "prose", {
                                screen: [P]
                            }, P]
                        }],
                        h: [{
                            h: [M, r, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "min-h": [{
                            "min-h": [M, r, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "max-h": [{
                            "max-h": [M, r, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        size: [{
                            size: [M, r, "auto", "min", "max", "fit"]
                        }],
                        "font-size": [{
                            text: ["base", P, C]
                        }],
                        "font-smoothing": ["antialiased", "subpixel-antialiased"],
                        "font-style": ["italic", "not-italic"],
                        "font-weight": [{
                            font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", I]
                        }],
                        "font-family": [{
                            font: [W]
                        }],
                        "fvn-normal": ["normal-nums"],
                        "fvn-ordinal": ["ordinal"],
                        "fvn-slashed-zero": ["slashed-zero"],
                        "fvn-figure": ["lining-nums", "oldstyle-nums"],
                        "fvn-spacing": ["proportional-nums", "tabular-nums"],
                        "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
                        tracking: [{
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", M]
                        }],
                        "line-clamp": [{
                            "line-clamp": ["none", j, I]
                        }],
                        leading: [{
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose", z, M]
                        }],
                        "list-image": [{
                            "list-image": ["none", M]
                        }],
                        "list-style-type": [{
                            list: ["none", "disc", "decimal", M]
                        }],
                        "list-style-position": [{
                            list: ["inside", "outside"]
                        }],
                        "placeholder-color": [{
                            placeholder: [e]
                        }],
                        "placeholder-opacity": [{
                            "placeholder-opacity": [y]
                        }],
                        "text-alignment": [{
                            text: ["left", "center", "right", "justify", "start", "end"]
                        }],
                        "text-color": [{
                            text: [e]
                        }],
                        "text-opacity": [{
                            "text-opacity": [y]
                        }],
                        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                        "text-decoration-style": [{
                            decoration: ["solid", "dashed", "dotted", "double", "none", "wavy"]
                        }],
                        "text-decoration-thickness": [{
                            decoration: ["auto", "from-font", z, C]
                        }],
                        "underline-offset": [{
                            "underline-offset": ["auto", z, M]
                        }],
                        "text-decoration-color": [{
                            decoration: [e]
                        }],
                        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                        "text-wrap": [{
                            text: ["wrap", "nowrap", "balance", "pretty"]
                        }],
                        indent: [{
                            indent: R()
                        }],
                        "vertical-align": [{
                            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", M]
                        }],
                        whitespace: [{
                            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                        }],
                        break: [{
                            break: ["normal", "words", "all", "keep"]
                        }],
                        hyphens: [{
                            hyphens: ["none", "manual", "auto"]
                        }],
                        content: [{
                            content: ["none", M]
                        }],
                        "bg-attachment": [{
                            bg: ["fixed", "local", "scroll"]
                        }],
                        "bg-clip": [{
                            "bg-clip": ["border", "padding", "content", "text"]
                        }],
                        "bg-opacity": [{
                            "bg-opacity": [y]
                        }],
                        "bg-origin": [{
                            "bg-origin": ["border", "padding", "content"]
                        }],
                        "bg-position": [{
                            bg: ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top", _]
                        }],
                        "bg-repeat": [{
                            bg: ["no-repeat", {
                                repeat: ["", "x", "y", "round", "space"]
                            }]
                        }],
                        "bg-size": [{
                            bg: ["auto", "cover", "contain", N]
                        }],
                        "bg-image": [{
                            bg: ["none", {
                                "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                            }, $]
                        }],
                        "bg-color": [{
                            bg: [e]
                        }],
                        "gradient-from-pos": [{
                            from: [m]
                        }],
                        "gradient-via-pos": [{
                            via: [m]
                        }],
                        "gradient-to-pos": [{
                            to: [m]
                        }],
                        "gradient-from": [{
                            from: [f]
                        }],
                        "gradient-via": [{
                            via: [f]
                        }],
                        "gradient-to": [{
                            to: [f]
                        }],
                        rounded: [{
                            rounded: [s]
                        }],
                        "rounded-s": [{
                            "rounded-s": [s]
                        }],
                        "rounded-e": [{
                            "rounded-e": [s]
                        }],
                        "rounded-t": [{
                            "rounded-t": [s]
                        }],
                        "rounded-r": [{
                            "rounded-r": [s]
                        }],
                        "rounded-b": [{
                            "rounded-b": [s]
                        }],
                        "rounded-l": [{
                            "rounded-l": [s]
                        }],
                        "rounded-ss": [{
                            "rounded-ss": [s]
                        }],
                        "rounded-se": [{
                            "rounded-se": [s]
                        }],
                        "rounded-ee": [{
                            "rounded-ee": [s]
                        }],
                        "rounded-es": [{
                            "rounded-es": [s]
                        }],
                        "rounded-tl": [{
                            "rounded-tl": [s]
                        }],
                        "rounded-tr": [{
                            "rounded-tr": [s]
                        }],
                        "rounded-br": [{
                            "rounded-br": [s]
                        }],
                        "rounded-bl": [{
                            "rounded-bl": [s]
                        }],
                        "border-w": [{
                            border: [i]
                        }],
                        "border-w-x": [{
                            "border-x": [i]
                        }],
                        "border-w-y": [{
                            "border-y": [i]
                        }],
                        "border-w-s": [{
                            "border-s": [i]
                        }],
                        "border-w-e": [{
                            "border-e": [i]
                        }],
                        "border-w-t": [{
                            "border-t": [i]
                        }],
                        "border-w-r": [{
                            "border-r": [i]
                        }],
                        "border-w-b": [{
                            "border-b": [i]
                        }],
                        "border-w-l": [{
                            "border-l": [i]
                        }],
                        "border-opacity": [{
                            "border-opacity": [y]
                        }],
                        "border-style": [{
                            border: ["solid", "dashed", "dotted", "double", "none", "hidden"]
                        }],
                        "divide-x": [{
                            "divide-x": [i]
                        }],
                        "divide-x-reverse": ["divide-x-reverse"],
                        "divide-y": [{
                            "divide-y": [i]
                        }],
                        "divide-y-reverse": ["divide-y-reverse"],
                        "divide-opacity": [{
                            "divide-opacity": [y]
                        }],
                        "divide-style": [{
                            divide: ["solid", "dashed", "dotted", "double", "none"]
                        }],
                        "border-color": [{
                            border: [n]
                        }],
                        "border-color-x": [{
                            "border-x": [n]
                        }],
                        "border-color-y": [{
                            "border-y": [n]
                        }],
                        "border-color-t": [{
                            "border-t": [n]
                        }],
                        "border-color-r": [{
                            "border-r": [n]
                        }],
                        "border-color-b": [{
                            "border-b": [n]
                        }],
                        "border-color-l": [{
                            "border-l": [n]
                        }],
                        "divide-color": [{
                            divide: [n]
                        }],
                        "outline-style": [{
                            outline: ["", "solid", "dashed", "dotted", "double", "none"]
                        }],
                        "outline-offset": [{
                            "outline-offset": [z, M]
                        }],
                        "outline-w": [{
                            outline: [z, C]
                        }],
                        "outline-color": [{
                            outline: [e]
                        }],
                        "ring-w": [{
                            ring: B()
                        }],
                        "ring-w-inset": ["ring-inset"],
                        "ring-color": [{
                            ring: [e]
                        }],
                        "ring-opacity": [{
                            "ring-opacity": [y]
                        }],
                        "ring-offset-w": [{
                            "ring-offset": [z, C]
                        }],
                        "ring-offset-color": [{
                            "ring-offset": [e]
                        }],
                        shadow: [{
                            shadow: ["", "inner", "none", P, O]
                        }],
                        "shadow-color": [{
                            shadow: [W]
                        }],
                        opacity: [{
                            opacity: [y]
                        }],
                        "mix-blend": [{
                            "mix-blend": ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter"]
                        }],
                        "bg-blend": [{
                            "bg-blend": ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter"]
                        }],
                        filter: [{
                            filter: ["", "none"]
                        }],
                        blur: [{
                            blur: [o]
                        }],
                        brightness: [{
                            brightness: [t]
                        }],
                        contrast: [{
                            contrast: [a]
                        }],
                        "drop-shadow": [{
                            "drop-shadow": ["", "none", P, M]
                        }],
                        grayscale: [{
                            grayscale: [c]
                        }],
                        "hue-rotate": [{
                            "hue-rotate": [d]
                        }],
                        invert: [{
                            invert: [u]
                        }],
                        saturate: [{
                            saturate: [w]
                        }],
                        sepia: [{
                            sepia: [k]
                        }],
                        "backdrop-filter": [{
                            "backdrop-filter": ["", "none"]
                        }],
                        "backdrop-blur": [{
                            "backdrop-blur": [o]
                        }],
                        "backdrop-brightness": [{
                            "backdrop-brightness": [t]
                        }],
                        "backdrop-contrast": [{
                            "backdrop-contrast": [a]
                        }],
                        "backdrop-grayscale": [{
                            "backdrop-grayscale": [c]
                        }],
                        "backdrop-hue-rotate": [{
                            "backdrop-hue-rotate": [d]
                        }],
                        "backdrop-invert": [{
                            "backdrop-invert": [u]
                        }],
                        "backdrop-opacity": [{
                            "backdrop-opacity": [y]
                        }],
                        "backdrop-saturate": [{
                            "backdrop-saturate": [w]
                        }],
                        "backdrop-sepia": [{
                            "backdrop-sepia": [k]
                        }],
                        "border-collapse": [{
                            border: ["collapse", "separate"]
                        }],
                        "border-spacing": [{
                            "border-spacing": [l]
                        }],
                        "border-spacing-x": [{
                            "border-spacing-x": [l]
                        }],
                        "border-spacing-y": [{
                            "border-spacing-y": [l]
                        }],
                        "table-layout": [{
                            table: ["auto", "fixed"]
                        }],
                        caption: [{
                            caption: ["top", "bottom"]
                        }],
                        transition: [{
                            transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", M]
                        }],
                        duration: [{
                            duration: F()
                        }],
                        ease: [{
                            ease: ["linear", "in", "out", "in-out", M]
                        }],
                        delay: [{
                            delay: F()
                        }],
                        animate: [{
                            animate: ["none", "spin", "ping", "pulse", "bounce", M]
                        }],
                        transform: [{
                            transform: ["", "gpu", "none"]
                        }],
                        scale: [{
                            scale: [x]
                        }],
                        "scale-x": [{
                            "scale-x": [x]
                        }],
                        "scale-y": [{
                            "scale-y": [x]
                        }],
                        rotate: [{
                            rotate: [E, M]
                        }],
                        "translate-x": [{
                            "translate-x": [A]
                        }],
                        "translate-y": [{
                            "translate-y": [A]
                        }],
                        "skew-x": [{
                            "skew-x": [S]
                        }],
                        "skew-y": [{
                            "skew-y": [S]
                        }],
                        "transform-origin": [{
                            origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", M]
                        }],
                        accent: [{
                            accent: ["auto", e]
                        }],
                        appearance: [{
                            appearance: ["none", "auto"]
                        }],
                        cursor: [{
                            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", M]
                        }],
                        "caret-color": [{
                            caret: [e]
                        }],
                        "pointer-events": [{
                            "pointer-events": ["none", "auto"]
                        }],
                        resize: [{
                            resize: ["none", "y", "x", ""]
                        }],
                        "scroll-behavior": [{
                            scroll: ["auto", "smooth"]
                        }],
                        "scroll-m": [{
                            "scroll-m": R()
                        }],
                        "scroll-mx": [{
                            "scroll-mx": R()
                        }],
                        "scroll-my": [{
                            "scroll-my": R()
                        }],
                        "scroll-ms": [{
                            "scroll-ms": R()
                        }],
                        "scroll-me": [{
                            "scroll-me": R()
                        }],
                        "scroll-mt": [{
                            "scroll-mt": R()
                        }],
                        "scroll-mr": [{
                            "scroll-mr": R()
                        }],
                        "scroll-mb": [{
                            "scroll-mb": R()
                        }],
                        "scroll-ml": [{
                            "scroll-ml": R()
                        }],
                        "scroll-p": [{
                            "scroll-p": R()
                        }],
                        "scroll-px": [{
                            "scroll-px": R()
                        }],
                        "scroll-py": [{
                            "scroll-py": R()
                        }],
                        "scroll-ps": [{
                            "scroll-ps": R()
                        }],
                        "scroll-pe": [{
                            "scroll-pe": R()
                        }],
                        "scroll-pt": [{
                            "scroll-pt": R()
                        }],
                        "scroll-pr": [{
                            "scroll-pr": R()
                        }],
                        "scroll-pb": [{
                            "scroll-pb": R()
                        }],
                        "scroll-pl": [{
                            "scroll-pl": R()
                        }],
                        "snap-align": [{
                            snap: ["start", "end", "center", "align-none"]
                        }],
                        "snap-stop": [{
                            snap: ["normal", "always"]
                        }],
                        "snap-type": [{
                            snap: ["none", "x", "y", "both"]
                        }],
                        "snap-strictness": [{
                            snap: ["mandatory", "proximity"]
                        }],
                        touch: [{
                            touch: ["auto", "none", "manipulation"]
                        }],
                        "touch-x": [{
                            "touch-pan": ["x", "left", "right"]
                        }],
                        "touch-y": [{
                            "touch-pan": ["y", "up", "down"]
                        }],
                        "touch-pz": ["touch-pinch-zoom"],
                        select: [{
                            select: ["none", "text", "all", "auto"]
                        }],
                        "will-change": [{
                            "will-change": ["auto", "scroll", "contents", "transform", M]
                        }],
                        fill: [{
                            fill: [e, "none"]
                        }],
                        "stroke-w": [{
                            stroke: [z, C, I]
                        }],
                        stroke: [{
                            stroke: [e, "none"]
                        }],
                        sr: ["sr-only", "not-sr-only"],
                        "forced-color-adjust": [{
                            "forced-color-adjust": ["auto", "none"]
                        }]
                    },
                    conflictingClassGroups: {
                        overflow: ["overflow-x", "overflow-y"],
                        overscroll: ["overscroll-x", "overscroll-y"],
                        inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                        "inset-x": ["right", "left"],
                        "inset-y": ["top", "bottom"],
                        flex: ["basis", "grow", "shrink"],
                        gap: ["gap-x", "gap-y"],
                        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                        px: ["pr", "pl"],
                        py: ["pt", "pb"],
                        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                        mx: ["mr", "ml"],
                        my: ["mt", "mb"],
                        size: ["w", "h"],
                        "font-size": ["leading"],
                        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                        "fvn-ordinal": ["fvn-normal"],
                        "fvn-slashed-zero": ["fvn-normal"],
                        "fvn-figure": ["fvn-normal"],
                        "fvn-spacing": ["fvn-normal"],
                        "fvn-fraction": ["fvn-normal"],
                        "line-clamp": ["display", "overflow"],
                        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                        "rounded-s": ["rounded-ss", "rounded-es"],
                        "rounded-e": ["rounded-se", "rounded-ee"],
                        "rounded-t": ["rounded-tl", "rounded-tr"],
                        "rounded-r": ["rounded-tr", "rounded-br"],
                        "rounded-b": ["rounded-br", "rounded-bl"],
                        "rounded-l": ["rounded-tl", "rounded-bl"],
                        "border-spacing": ["border-spacing-x", "border-spacing-y"],
                        "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                        "border-w-x": ["border-w-r", "border-w-l"],
                        "border-w-y": ["border-w-t", "border-w-b"],
                        "border-color": ["border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                        "border-color-x": ["border-color-r", "border-color-l"],
                        "border-color-y": ["border-color-t", "border-color-b"],
                        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                        "scroll-mx": ["scroll-mr", "scroll-ml"],
                        "scroll-my": ["scroll-mt", "scroll-mb"],
                        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                        "scroll-px": ["scroll-pr", "scroll-pl"],
                        "scroll-py": ["scroll-pt", "scroll-pb"],
                        touch: ["touch-x", "touch-y", "touch-pz"],
                        "touch-x": ["touch"],
                        "touch-y": ["touch"],
                        "touch-pz": ["touch"]
                    },
                    conflictingClassGroupModifiers: {
                        "font-size": ["leading"]
                    }
                }
            }
            const V = f(L)
        }
    }
]);