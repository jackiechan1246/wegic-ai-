! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "d363bd04-a474-4414-92f1-91ca42fb4876", e._sentryDebugIdIdentifier = "sentry-dbid-d363bd04-a474-4414-92f1-91ca42fb4876")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [711], {
        57064: function(e, t, n) {
            "use strict";
            var i, r = n(52818);

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            t.Z = function(e) {
                return r.createElement("svg", a({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 16 16"
                }, e), i || (i = r.createElement("g", {
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeWidth: 2
                }, r.createElement("path", {
                    d: "m12.482 3.997-8.485 8.485M12.482 12.482 3.997 3.997"
                }))))
            }
        },
        47667: function(e, t, n) {
            "use strict";
            var i, r, a = n(52818);

            function s() {
                return s = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, s.apply(this, arguments)
            }
            t.Z = function(e) {
                return a.createElement("svg", s({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 16 16"
                }, e), i || (i = a.createElement("g", {
                    clipPath: "url(#a)"
                }, a.createElement("path", {
                    stroke: "currentColor",
                    strokeLinecap: "square",
                    strokeWidth: 1.6,
                    d: "M8 14.286c3.51 0 6.354-2.814 6.354-6.286S11.509 1.714 8 1.714m0 12.572c-3.509 0-6.354-2.814-6.354-6.286S4.491 1.714 8 1.714m0 12.572c-1.612 0-2.92-2.814-2.92-6.286S6.389 1.714 8 1.714m0 12.572c1.612 0 2.92-2.814 2.92-6.286S9.611 1.714 8 1.714M14.182 8H1.818"
                }))), r || (r = a.createElement("defs", null, a.createElement("clipPath", {
                    id: "a"
                }, a.createElement("path", {
                    fill: "#fff",
                    d: "M0 0h16v16H0z"
                })))))
            }
        },
        12556: function(e, t, n) {
            "use strict";
            var i, r, a, s = n(52818);

            function l() {
                return l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, l.apply(this, arguments)
            }
            t.Z = function(e) {
                return s.createElement("svg", l({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 24,
                    height: 24,
                    fill: "current",
                    viewBox: "0 0 24 24"
                }, e), i || (i = s.createElement("rect", {
                    width: 16.8,
                    height: 2,
                    x: 3.6,
                    y: 4.8,
                    rx: 1
                })), r || (r = s.createElement("rect", {
                    width: 13.2,
                    height: 2,
                    x: 3.6,
                    y: 10.8,
                    rx: 1
                })), a || (a = s.createElement("rect", {
                    width: 16.8,
                    height: 2,
                    x: 3.6,
                    y: 16.8,
                    rx: 1
                })))
            }
        },
        98534: function(e, t, n) {
            "use strict";
            var i, r, a, s = n(52818);

            function l() {
                return l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, l.apply(this, arguments)
            }
            t.Z = function(e) {
                return s.createElement("svg", l({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 126,
                    height: 57,
                    fill: "none",
                    viewBox: "0 0 126 57"
                }, e), i || (i = s.createElement("path", {
                    fill: "#fff",
                    d: "M97.473 6.889a.73.73 0 0 1 1.218-.496l1.14 1.024a.73.73 0 0 0 .44.186l1.53.1a.73.73 0 0 1 .496 1.218l-1.024 1.14a.73.73 0 0 0-.187.44l-.099 1.53a.73.73 0 0 1-1.218.496l-1.14-1.024a.73.73 0 0 0-.44-.186l-1.53-.1A.73.73 0 0 1 96.163 10l1.024-1.14a.73.73 0 0 0 .186-.44z"
                })), r || (r = s.createElement("path", {
                    fill: "#fff",
                    fillRule: "evenodd",
                    d: "M24.114 2.127a2.23 2.23 0 0 1-.446 3.122c-1.325.994-4.96 5.013-7.508 10.576-1.888 4.124-2.306 8-1.764 10.686.55 2.725 1.832 3.589 3.055 3.589l.082.001c.804.03 1.533-.26 2.312-.982.827-.765 1.619-1.94 2.408-3.466.768-1.487 1.455-3.146 2.16-4.848l.037-.09c.403-.972.817-1.971 1.25-2.921.3-.678.629-1.338.98-1.972a69 69 0 0 1 1.499-2.594c.18-.291.333-.532.455-.71.057-.084.129-.187.206-.283a2.297 2.297 0 0 1 1.019-.753 2.234 2.234 0 0 1 3 1.898c.034.366-.035.653-.052.723v.003c-.047.193-.11.344-.129.387a5 5 0 0 1-.157.33c-.1.188-.238.434-.41.726-.342.58-.86 1.415-1.566 2.501q-.392.722-.785 1.59c-1.075 2.432-1.652 4.992-1.547 7.008.065 1.227.37 2.067.77 2.585.352.455.908.84 1.953.94.75.07 1.586-.237 2.622-1.332 1.055-1.114 2.055-2.783 3.034-4.77.672-1.366 1.277-2.757 1.871-4.124q.408-.94.816-1.86c.795-1.777 1.71-3.704 2.789-4.855a2.23 2.23 0 0 1 3.304 2.997c-.95 1.083-1.346 2.745-1.025 4.49.244 1.325.872 2.527 1.778 3.383.903-4.989 4.642-10.09 10.857-11.11 2.871-.472 5.558.15 7.084 2.145 1.565 2.05 1.264 4.694-.097 6.794-2.083 3.213-5.536 5.573-8.968 6.819-.872.317-1.786.576-2.712.757 1.001.619 2.539.927 4.733.186 2.58-.87 5.25-3.214 8.09-6.192.756-.792 1.532-1.64 2.316-2.497 1.277-1.396 2.573-2.812 3.833-4.044a10 10 0 0 1 1.22-1.139q.386-.341.764-.647c1.946-1.573 3.895-2.456 5.692-2.84q.21-.05.418-.091c2.093-.408 3.79-.056 5.071.493a6.55 6.55 0 0 1 2.978 2.543c1.077 1.722 1.453 4.103.513 7.196a205 205 0 0 1-2 6.238c2.168-2.23 3.645-4.304 4.343-5.495.766-1.305 1.49-2.616 2.134-3.778l.085-.155c.644-1.163 1.24-2.24 1.677-2.915.112-.175.237-.358.366-.524.095-.123.32-.409.647-.644.15-.108.552-.378 1.14-.438a2.28 2.28 0 0 1 2.01.837c.37.46.463.935.492 1.12.037.229.037.428.032.558-.016.46-.138 1.02-.265 1.54a53 53 0 0 1-.62 2.244c-.61 2.068-.762 3.596-.719 4.653.605-.837 1.303-1.838 2.044-2.902l.057-.081c1.364-1.96 2.885-4.146 3.906-5.247 3.095-3.34 6.052-4.514 8.613-4.489a8 8 0 0 1 3.858 1.04l.061.031c.301.16.556.324.744.467.043.034.119.093.202.17.03.027.13.12.238.255a2.22 2.22 0 0 1 .487 1.3 2.23 2.23 0 0 1-1.901 2.302 2.23 2.23 0 0 1-1.446-.273 3 3 0 0 1-.215-.136l-.007-.005a5 5 0 0 0-.302-.195 3.7 3.7 0 0 0-1.123-.33c-.935-.118-2.666.02-4.749 2.541-.472.572-1.382 2.277-1.883 4.29-.516 2.081-.404 3.713.2 4.608.603.893 1.301 1.152 2.071 1.112.898-.045 2.065-.529 3.212-1.538a2.23 2.23 0 1 1 2.947 3.348c-1.666 1.467-3.754 2.535-5.932 2.645-2.306.118-4.504-.862-5.996-3.071-.737-1.092-1.103-2.32-1.234-3.558-.771 1.076-1.498 2.038-2.057 2.648a3.03 3.03 0 0 1-1.764.959 3.1 3.1 0 0 1-1.93-.337c-1.032-.548-1.672-1.556-2.038-2.544a8 8 0 0 1-.38-1.442c-1.915 2.686-5.357 6.64-10.157 9.862-.931 2.245-1.914 4.39-2.943 6.353-1.59 3.035-3.352 5.752-5.29 7.724-1.92 1.95-4.281 3.438-7.026 3.349-3.769-.122-6.182-2.295-7.099-4.992-.836-2.46-.434-5.433 1.289-7.4.935-1.202 2.17-2.006 3.81-2.718 1.631-.707 3.853-1.4 6.892-2.281 2.482-.72 4.746-1.787 6.77-3.027q.506-1.265.992-2.57c-1.004.6-2.01 1.094-2.959 1.475-1.459.586-2.956.978-4.181.978-2.426 0-4.324-1.051-5.321-2.989-.488-.948-.703-2-.743-3.053-2.505 2.485-5.367 4.866-8.508 5.925-3.785 1.277-7.131.648-9.467-1.315a8.45 8.45 0 0 1-2.343-3.187 8 8 0 0 1-1.818-.76c-1.603-.927-2.827-2.268-3.667-3.787q-.275.593-.56 1.17c-1.028 2.09-2.266 4.251-3.795 5.866-1.547 1.635-3.642 2.957-6.284 2.706-2.146-.204-3.881-1.125-5.062-2.654a7.3 7.3 0 0 1-.892-1.506 12.8 12.8 0 0 1-1.684 1.94c-1.424 1.318-3.24 2.237-5.466 2.168-4.227-.022-6.63-3.413-7.386-7.168-.768-3.805-.108-8.646 2.08-13.425 2.787-6.086 6.845-10.755 8.888-12.287a2.23 2.23 0 0 1 3.122.446M74.52 20.009c-.5.553-1.025 1.298-1.51 2.19-.706 1.302-1.237 2.755-1.47 4.068-.244 1.373-.11 2.281.126 2.74.122.237.344.57 1.355.57.41 0 1.299-.168 2.518-.658a17.3 17.3 0 0 0 3.733-2.093c2.534-1.869 4.441-4.365 4.666-7.258.092-1.174-.243-1.795-.509-2.13a2.1 2.1 0 0 0-.733-.59l-.021-.01c-.518-.222-1.48-.411-2.74-.157-1.113.272-2.635.968-4.597 2.568q-.405.36-.818.76m1.803 20.541c-.866.34-1.76.648-2.68.915-3.075.891-5.03 1.513-6.361 2.09-1.286.558-1.78.987-2.086 1.393q-.06.078-.125.15c-.536.592-.845 1.854-.44 3.047.337.988 1.161 1.908 3.02 1.968.955.031 2.182-.474 3.7-2.018 1.5-1.524 3.022-3.806 4.522-6.667q.225-.431.45-.878M50.453 25.278a12.8 12.8 0 0 0 3.025-.72c2.74-.996 5.307-2.832 6.748-5.054.653-1.007.398-1.523.295-1.658-.144-.189-.842-.777-2.816-.453-4.1.673-6.748 4.212-7.251 7.885",
                    clipRule: "evenodd"
                })), a || (a = s.createElement("path", {
                    fill: "#fff",
                    fillRule: "evenodd",
                    d: "M85.814 40.19a2.23 2.23 0 0 1 2.253-2.206c11.06.115 22.134.894 33.256 2.59a2.23 2.23 0 0 1-.673 4.41c-10.886-1.66-21.748-2.426-32.63-2.54a2.23 2.23 0 0 1-2.206-2.254m-27.184.699a2.23 2.23 0 0 1-2.149 2.308c-30.738 1.1-45.64 5.092-52.22 6.855l-.765.204a2.23 2.23 0 1 1-1.146-4.311l.746-.2c6.772-1.811 22.006-5.888 53.226-7.005a2.23 2.23 0 0 1 2.308 2.149",
                    clipRule: "evenodd"
                })))
            }
        },
        55043: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ok: function() {
                    return o
                },
                WG: function() {
                    return c
                },
                WY: function() {
                    return l
                }
            });
            var i = n(68767),
                r = n(83847),
                a = n(73258);
            const s = {
                    errorHandler: {
                        onErrorMessage: "请求接口报错"
                    }
                },
                l = (0, i.F4)({
                    baseURL: "/api/onepage",
                    ...s
                }),
                c = (0, i.F4)({
                    baseURL: "/api/user/v1",
                    allowedCodes: [a.h],
                    ...s
                }),
                o = ((0, i.F4)({
                    baseURL: r.YR,
                    ...s
                }), (0, i.F4)({
                    baseURL: "/api/assets",
                    ...s
                }))
        },
        42439: function(e, t, n) {
            "use strict";
            n.d(t, {
                DB: function() {
                    return r
                },
                Gu: function() {
                    return s
                },
                Qx: function() {
                    return a
                }
            });
            var i = n(83847);
            const r = "-",
                a = "".concat(i.QX, "/assets/onepage/user/image");

            function s(e) {
                try {
                    return "blob:" === new URL(e).protocol
                } catch (e) {
                    return !1
                }
            }
        },
        89733: function(e, t, n) {
            "use strict";
            var i = n(75467),
                r = n(9850),
                a = n.n(r),
                s = n(84371),
                l = n(42439),
                c = n(92035),
                o = n.n(c);
            t.Z = function(e) {
                const {
                    size: t = 40,
                    name: n = "",
                    image: r = "",
                    style: c
                } = e, [u, d] = (0, s.useState)(!1), [g, f] = (0, s.useState)(!0), m = (0, s.useMemo)((() => {
                    if (!r || r === l.DB) return null;
                    return (0, l.Gu)(r) || r.startsWith("http") || r.startsWith("//") ? r : "".concat(l.Qx, "/").concat(r)
                }), [r]), h = m && !u;
                return (0, s.useEffect)((() => {
                    !m && n && f(!1), d(!1)
                }), [m, n]), (0, i.jsx)("div", {
                    className: a()("relative flex items-center justify-center overflow-hidden cursor-pointer select-none rounded-full", {
                        [o().loading]: g
                    }),
                    style: {
                        width: "".concat(t, "px"),
                        height: "".concat(t, "px"),
                        ...c
                    },
                    children: h ? (0, i.jsx)("img", {
                        className: "w-full h-full object-cover",
                        alt: "avatar",
                        src: m,
                        onError: () => {
                            d(!0)
                        },
                        onLoad: () => {
                            setTimeout((() => {
                                f(!1)
                            }), 100)
                        },
                        style: {
                            opacity: g ? 0 : 1
                        }
                    }) : (0, i.jsx)("div", {
                        className: "flex items-center justify-center w-full h-full font-bold text-white text-[14px]",
                        style: {
                            backgroundColor: g && !u ? "transparent" : "black"
                        },
                        children: (0, i.jsx)("span", {
                            children: n.slice(0, 1).toUpperCase()
                        })
                    })
                })
            }
        },
        86561: function(e, t, n) {
            "use strict";
            n.d(t, {
                FooterBase: function() {
                    return H
                },
                Z: function() {
                    return T
                }
            });
            var i = n(75467),
                r = n(84956),
                a = n(29172),
                s = n(42140),
                l = n(16331),
                c = n(41868),
                o = n(18562),
                u = n(84371),
                d = {
                    src: "https://cdn.wegic.ai/_next/static/media/allPeople.9fa2fb31.png",
                    height: 1072,
                    width: 1452,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAl0lEQVR42mMAgf8F07h+d/SFMkDB8hlXWRnQwf/uBV5vZy8483PJikAw/zsDIwMItJ6caZv3ZPPxA9c2Lf+/bOX/58u2nWnve1W1s+k/NwMIGF1pnRv/cM7/C3sX3f2/ebHf4XVPli2e++4v3GjJXfYcDPdzTZ9O61L+b+UUfXTNR/O1y35tnjvxkwQDPrBq4WcuBgYGBgDDZ0UHHJwvDgAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 6
                },
                g = n(98534),
                f = {
                    src: "https://cdn.wegic.ai/_next/static/media/kimmy.bd411ccb.png",
                    height: 1072,
                    width: 1452,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAm0lEQVR42mMAgf8VE7n+tvWFMkDBlgUXmBnQwf+pi/zfzp5/5tviFSFg/hEGRgYQ6DsxSyH8+abYGyfW1/5bvur/xxWbNiV1fDQ51f+BgwEEFK62+mbfmz3zyZo5W/7v3Bb1fMm+qn1Tr/eDTVnGwMgQvtGTheFxvuSH7k75/34xSWfmPZJfs/RX5NyJn3gY8IFVCz6xMjAwMAAAJ99DvYEW5lQAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                m = {
                    src: "https://cdn.wegic.ai/_next/static/media/timmy.f5bc0341.png",
                    height: 1072,
                    width: 1452,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAkklEQVR42mNg+L+P8X/qAtbvff06DFCwfMYVZgZ08D9mlvzb2QvSfy5ZoYki0XRyhk3J483npz/f2vR/4fL2Z8u3pbf1vbLd0fyfDazA6VLLHK+nc/9HfFx/6v+MRYoH1z8OXTz3XT3CiP0O7Ax3ss02HOyS+K/tqHN09XuZtct+Rs2Z+ImHAR9YufAzKwMDAwMAH7E/+pSNY9kAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                h = {
                    src: "https://cdn.wegic.ai/_next/static/media/turi.4dc4d795.png",
                    height: 1072,
                    width: 1452,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAk0lEQVR42mMAgf/5U1l/d/RqM0DBvEnXWRnQwf/u+apvZ89P/798hRqKROvJmfK5jzel7L+6KfT/smVtt5fubpo88Xnz0tL/nAwgYHSl1T/+wezJF/YsLvy/o0Rm9+oXU5bOffufgQEKZHa4sDDcy5N+PH2y0H8GBs1DG74br1v2c8uciZ8lGPCBVQs/czEwMDAAAJ3+PgqoQlxkAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 6
                },
                p = n(9850),
                x = n.n(p),
                w = n(16924);

            function v(e) {
                const {
                    link: t,
                    children: n,
                    target: r,
                    className: a,
                    style: s
                } = e;
                return (0, i.jsxs)(w.default, {
                    style: { ...s
                    },
                    className: x()(a, "group", "flex", "text-sm", "items-center", "text-white", "opacity-70", "hover:opacity-100"),
                    href: t,
                    target: r ? "_blank" : "_self",
                    children: [n, (0, i.jsx)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        className: "w-4 h-auto opacity-0 group-hover:translate-x-1 group-hover:opacity-100 transition-all duration-300",
                        viewBox: "0 0 16.4375 16.4375",
                        fill: "none",
                        children: (0, i.jsx)("path", {
                            d: "M2.70856 13.2811C-0.207356 10.3652 -0.207385 5.63756 2.70855 2.72163C5.62446 -0.194285 10.3521 -0.194285 13.268 2.72163C16.1839 5.63756 16.1839 10.3652 13.268 13.2811C10.3521 16.197 5.62449 16.197 2.70856 13.2811ZM3.83993 12.1497C6.13099 14.4408 9.84557 14.4408 12.1366 12.1497C14.4277 9.85863 14.4277 6.14406 12.1366 3.853C9.84556 1.56192 6.131 1.56192 3.83992 3.853C1.54886 6.14406 1.54885 9.85863 3.83993 12.1497ZM8.83648 8.2566L8.83647 9.88891C8.83648 9.99499 8.85677 10.097 8.89738 10.195C8.93797 10.2931 8.99578 10.3796 9.07079 10.4546C9.14582 10.5296 9.2323 10.5874 9.33037 10.628C9.42837 10.6686 9.53041 10.6889 9.63649 10.6889C9.68899 10.6889 9.74104 10.6838 9.79257 10.6736C9.8441 10.6633 9.89409 10.6481 9.94262 10.628C9.99115 10.6079 10.0373 10.5833 10.0809 10.5541C10.1246 10.5249 10.165 10.4917 10.2022 10.4546C10.2393 10.4175 10.2725 10.377 10.3016 10.3333C10.3309 10.2897 10.3555 10.2436 10.3756 10.195C10.3957 10.1465 10.4109 10.0965 10.4211 10.045C10.4314 9.99347 10.4365 9.94142 10.4365 9.88891L10.4365 6.35337C10.4365 5.91154 10.0783 5.55337 9.63647 5.55337L6.10095 5.55337C6.04841 5.55336 5.99639 5.55849 5.94487 5.56873C5.89335 5.57898 5.84332 5.59416 5.7948 5.61426C5.74626 5.63436 5.70015 5.659 5.65648 5.68819C5.6128 5.71737 5.5724 5.75054 5.53525 5.78768C5.49811 5.82482 5.46494 5.86523 5.43576 5.90891C5.40658 5.95258 5.38194 5.99869 5.36183 6.04722C5.34173 6.09575 5.32656 6.14577 5.3163 6.19729C5.30606 6.24881 5.30094 6.30083 5.30094 6.35337C5.30094 6.45946 5.32124 6.5615 5.36183 6.65951C5.40243 6.75752 5.46024 6.84404 5.53525 6.91905C5.61027 6.99407 5.69678 7.05187 5.7948 7.09247C5.8928 7.13307 5.99485 7.15337 6.10094 7.15337L7.73308 7.15337L5.54931 9.33714C5.51306 9.37339 5.48072 9.41279 5.45229 9.45536C5.42378 9.49799 5.39974 9.54296 5.38016 9.59027C5.36058 9.63758 5.34575 9.68639 5.33575 9.73664C5.32575 9.78689 5.32076 9.83761 5.32077 9.88882C5.32079 9.94004 5.32574 9.99081 5.33578 10.041C5.34577 10.0913 5.36057 10.14 5.38018 10.1874C5.39978 10.2347 5.42381 10.2797 5.45227 10.3223C5.48072 10.3648 5.51306 10.4043 5.54928 10.4405C5.5855 10.4767 5.62491 10.509 5.66751 10.5375C5.71011 10.5659 5.75507 10.59 5.80239 10.6096C5.84972 10.6292 5.8985 10.644 5.94875 10.654C5.999 10.664 6.04973 10.669 6.10094 10.669C6.15215 10.669 6.20288 10.664 6.25312 10.654C6.30337 10.644 6.35216 10.6292 6.39949 10.6096C6.44682 10.59 6.49179 10.566 6.5344 10.5375C6.57697 10.509 6.61637 10.4767 6.65262 10.4405L8.83648 8.2566Z",
                            fillRule: "evenodd",
                            fill: "currentColor"
                        })
                    })]
                })
            }
            const b = {
                    title: "Footer_Link_Product",
                    list: [{
                        text: "Footer_Link_Help",
                        link: "https://help.wegic.ai/",
                        target: !0
                    }, {
                        text: "Footer_Link_Changelog",
                        link: "https://discord.com/invite/ZVUReEz9T3",
                        target: !0
                    }, {
                        text: "Footer_Link_Pricing",
                        link: "/pricing",
                        target: !1
                    }]
                },
                _ = {
                    title: "Footer_Link_Company",
                    list: [{
                        text: "Footer_Link_Feedback",
                        link: "https://discord.com/invite/ZVUReEz9T3",
                        target: !0
                    }, {
                        text: "Footer_Link_Contact",
                        link: "mailto:contact@wegic.ai",
                        target: !0
                    }]
                },
                y = {
                    title: "Footer_Link_Resources",
                    list: [{
                        text: "Footer_Link_BestPractices",
                        link: "/best-practices",
                        target: !0
                    }, {
                        text: "Footer_Link_Blog",
                        link: "/blog",
                        target: !0
                    }, {
                        text: "Footer_Link_Affiliates",
                        link: "/affiliates?event_source=lastPage",
                        target: !0
                    }]
                },
                j = () => {
                    const e = (0, o.useTranslations)();
                    return (0, i.jsxs)("div", {
                        className: "flex md:gap-14 xl:gap-20 2xl:gap-32 items-baseline flex-wrap md:flex-nowrap text-white justify-between md:justify-end md:mr-5  xl:mr-28 2xl:mr-32",
                        children: [(0, i.jsxs)("div", {
                            className: "flex flex-col justify-start",
                            children: [(0, i.jsx)("div", {
                                className: "mb-5",
                                children: e(b.title)
                            }), (0, i.jsx)("div", {
                                className: "flex flex-col gap-5",
                                children: b.list.map(((t, n) => (0, i.jsx)(v, {
                                    target: t.target,
                                    link: t.link,
                                    children: (0, i.jsx)("p", {
                                        className: "whitespace-nowrap",
                                        children: e(t.text)
                                    })
                                }, n)))
                            })]
                        }), (0, i.jsxs)("div", {
                            className: "flex flex-col",
                            children: [(0, i.jsx)("div", {
                                className: "mb-5",
                                children: e(_.title)
                            }), (0, i.jsx)("div", {
                                className: "flex flex-col gap-5",
                                children: _.list.map(((t, n) => (0, i.jsx)(v, {
                                    target: t.target,
                                    link: t.link,
                                    children: (0, i.jsx)("p", {
                                        className: "whitespace-nowrap",
                                        children: e(t.text)
                                    })
                                }, n)))
                            })]
                        }), (0, i.jsxs)("div", {
                            className: "flex flex-col",
                            children: [(0, i.jsx)("div", {
                                className: "mb-5",
                                children: e(y.title)
                            }), (0, i.jsx)("div", {
                                className: "flex flex-col gap-5",
                                children: y.list.map(((t, n) => (0, i.jsx)(v, {
                                    target: t.target,
                                    link: t.link,
                                    children: (0, i.jsx)("p", {
                                        className: "whitespace-nowrap",
                                        children: e(t.text)
                                    })
                                }, n)))
                            })]
                        })]
                    })
                };
            n(50912);
            var A, C = n(17890),
                k = n(46055),
                N = n(47667),
                L = n(89872),
                q = n(42466),
                E = n(13561),
                R = (n(77726), n(52818));

            function S() {
                return S = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, S.apply(this, arguments)
            }
            var U, B = function(e) {
                return R.createElement("svg", S({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 16,
                    height: 16,
                    fill: "none",
                    viewBox: "0 0 16 16"
                }, e), A || (A = R.createElement("path", {
                    fill: "#fff",
                    d: "M8 1.442c2.136 0 2.39.008 3.233.046.507.006 1.01.1 1.485.276.347.128.662.333.92.598.266.258.47.573.598.92.177.476.27.978.276 1.485.038.844.046 1.097.046 3.233s-.008 2.39-.046 3.233c-.006.507-.1 1.01-.276 1.485a2.65 2.65 0 0 1-1.518 1.518c-.476.177-.978.27-1.485.276-.844.039-1.097.047-3.233.047s-2.39-.008-3.233-.047a4.4 4.4 0 0 1-1.486-.276 2.5 2.5 0 0 1-.919-.598 2.5 2.5 0 0 1-.598-.92 4.4 4.4 0 0 1-.276-1.485c-.039-.844-.047-1.097-.047-3.233s.008-2.389.047-3.233c.006-.507.1-1.01.276-1.485.128-.347.332-.662.598-.92.258-.265.573-.47.92-.598.476-.177.978-.27 1.485-.276.844-.038 1.097-.046 3.233-.046M8 0C5.828 0 5.555.01 4.702.048A5.9 5.9 0 0 0 2.76.42a3.9 3.9 0 0 0-1.417.923c-.407.4-.722.883-.923 1.417a5.9 5.9 0 0 0-.371 1.942C.009 5.555 0 5.828 0 8s.01 2.445.048 3.298c.013.664.139 1.32.372 1.942a3.9 3.9 0 0 0 .923 1.418c.4.407.883.722 1.417.923a5.9 5.9 0 0 0 1.942.37c.853.04 1.126.05 3.298.05s2.445-.01 3.298-.049a5.9 5.9 0 0 0 1.942-.371 4.1 4.1 0 0 0 2.34-2.34 5.9 5.9 0 0 0 .371-1.943c.04-.853.049-1.126.049-3.298s-.01-2.445-.048-3.298a5.9 5.9 0 0 0-.372-1.942 3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42a5.9 5.9 0 0 0-1.942-.371C10.445.009 10.172 0 8 0m0 3.892a4.108 4.108 0 1 0 0 8.216 4.108 4.108 0 0 0 0-8.216m0 6.775a2.667 2.667 0 1 1 0-5.333 2.667 2.667 0 0 1 0 5.333m4.27-7.897a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92"
                })))
            };

            function M() {
                return M = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, M.apply(this, arguments)
            }
            var z = function(e) {
                return R.createElement("svg", M({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 16,
                    height: 16,
                    fill: "none",
                    viewBox: "0 0 16 16"
                }, e), U || (U = R.createElement("path", {
                    fill: "#fff",
                    fillRule: "evenodd",
                    d: "M14.25 1.91c.69.214 1.231.84 1.415 1.636C16 4.99 16 8 16 8s0 3.011-.335 4.454c-.184.796-.725 1.422-1.414 1.635-1.247.387-6.251.387-6.251.387s-5.004 0-6.25-.387c-.69-.213-1.231-.839-1.415-1.636C0 11.012 0 8 0 8s0-3.011.335-4.454c.184-.796.725-1.422 1.414-1.635C2.996 1.524 8 1.524 8 1.524s5.004 0 6.25.387M10.678 8l-4.355 2.514V5.486z",
                    clipRule: "evenodd"
                })))
            };
            const D = [{
                svg: (0, i.jsx)(B, {}),
                link: "https://www.instagram.com/wegic_ai",
                target: !0
            }, {
                svg: (0, i.jsx)(z, {}),
                link: "https://www.youtube.com/@wegic",
                target: !0
            }, {
                svg: (0, i.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "w-4 h-auto fill-white group-hover:fill-white/70",
                    viewBox: "0 0 17.9765625 16.25",
                    fill: "none",
                    children: (0, i.jsx)("path", {
                        d: "M14.1583 0L16.915 0L10.8925 6.88334L17.9775 16.25L12.43 16.25L8.085 10.5692L3.11334 16.25L0.355 16.25L6.79666 8.8875L0 0L5.68834 0L9.61584 5.1925L14.1583 0ZM13.1908 14.6L14.7183 14.6L4.85834 1.56334L3.21916 1.56334L13.1908 14.6Z"
                    })
                }),
                link: "https://twitter.com/wegic_ai",
                target: !0
            }, {
                svg: (0, i.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "w-4 h-auto fill-white group-hover:fill-white/70 group-hover:translate-y-[0.05rem] group-active:scale-95 transition-all duration-300",
                    viewBox: "0 0 18.56640625 14.283203125",
                    fill: "none",
                    children: (0, i.jsx)("path", {
                        d: "M15.7267 1.2C14.5023 0.629295 13.2246 0.229294 11.8933 0C11.7183 0.333334 11.56 0.666667 11.41 1.00833C10.0017 0.800001 8.57667 0.800001 7.16002 1.00833C7.01002 0.666667 6.85169 0.325 6.66835 0.00833333C5.33502 0.233334 4.05169 0.633334 2.83502 1.2C2.56683 1.58612 2.3163 1.98337 2.08343 2.39176C1.85055 2.80015 1.63625 3.21806 1.44053 3.6455C1.2448 4.07295 1.06842 4.50822 0.911375 4.95134C0.754338 5.39445 0.617266 5.84365 0.50016 6.29892C0.383054 6.75426 0.286374 7.21386 0.210118 7.67776C0.133863 8.14165 0.0783355 8.60801 0.043535 9.07684C0.00873442 9.54567 -0.00520224 10.0151 0.00172496 10.4852C0.00865276 10.9553 0.0364172 11.4241 0.0850184 11.8917C0.792285 12.4224 1.53981 12.8885 2.32758 13.2901C3.11536 13.6917 3.93173 14.0228 4.77669 14.2833C5.16002 13.7667 5.49335 13.2167 5.77669 12.6333C5.23502 12.425 4.70169 12.175 4.19335 11.8667C4.33502 11.7667 4.46002 11.6667 4.58502 11.5583C7.56835 12.975 11.0017 12.975 13.985 11.5583L14.3683 11.8667C13.8683 12.1667 13.3267 12.425 12.785 12.6333C13.0767 13.2167 13.41 13.7583 13.785 14.2833C15.4767 13.7583 17.0683 12.95 18.485 11.8917C18.8767 7.83334 17.835 4.31667 15.735 1.2L15.7267 1.2ZM6.20169 9.74168C5.28502 9.74168 4.53502 8.89167 4.53502 7.85001C4.53502 6.81667 5.26835 5.96667 6.20169 5.96667C7.13502 5.96667 7.88502 6.81667 7.86835 7.85001C7.86835 8.89167 7.12669 9.74168 6.20169 9.74168ZM12.3683 9.74168C11.4517 9.74168 10.7017 8.89167 10.7017 7.85001C10.7017 6.81667 11.435 5.96667 12.3683 5.96667C13.3017 5.96667 14.0517 6.81667 14.035 7.85001C14.035 8.89167 13.3017 9.74168 12.3683 9.74168Z",
                        fill: "#FFFFFF"
                    })
                }),
                link: "https://discord.com/invite/ZVUReEz9T3",
                target: !0
            }];

            function F() {
                return (0, i.jsx)("div", {
                    className: "h-full flex items-center gap-3 pl-8 md:pr-10 xl:pr-12 2xl:pr-12",
                    children: D.map(((e, t) => (0, i.jsx)(w.default, {
                        className: "w-11 h-11 group flex items-center justify-center rounded-xl bg-black shadow-secondaryButton hover:shadow-secondaryButtonHover active:shadow-secondaryButtonActive",
                        href: e.link,
                        target: e.target ? "_blank" : "_self",
                        children: (0, i.jsx)("div", {
                            className: "w-4 h-auto group-hover:translate-y-[0.05rem] group-active:scale-95 transition-all duration-300",
                            children: e.svg
                        })
                    }, t)))
                })
            }

            function O(e) {
                const {
                    isShowLanguageBtn: t = !0
                } = e, [n, r] = (0, u.useState)(!1), a = (0, u.useRef)(null), s = (0, k.useRouter)(), l = (0, k.usePathname)(), c = (0, o.useLocale)(), d = (0, o.useTranslations)(), [g, f] = (0, u.useState)(!1), [m, h] = (0, u.useState)(c), p = L.Nm[m].country, v = p ? "(".concat(d(p), ")") : "", b = (0, u.useMemo)((() => (0, i.jsx)("div", {
                    className: "rounded-xl p-1 relative z-10 bg-black",
                    children: (0, i.jsx)("div", {
                        className: x()("min-w-[120px] scrollbar max-h-[330px] overflow-y-auto px-1 flex flex-col gap-1 rounded-xl bg-white/[0.1]"),
                        children: Object.keys(L.Nm).map((e => {
                            if (l.includes("blog") && ["zh-cn", "zh-hk", "pt-pt", "pt-br", "tr", "nl", "it"].includes(e)) return;
                            const t = L.Nm[e].country;
                            return (0, i.jsxs)("div", {
                                onClick: () => (async e => {
                                    h(e), f(!1);
                                    const t = l.split("/");
                                    let n = l;
                                    Object.values(q.i).includes(t[1]) ? (t[1] = e, n = t.join("/")) : n = "/".concat(e).concat(l);
                                    try {
                                        await (0, E.jp)(e), s.push(n)
                                    } catch (e) {
                                        throw s.push(n), e
                                    }
                                })(e),
                                className: "".concat(e === m && "group/language-text bg-white/[0.08]", " w-full px-3 py-2.5 rounded-lg leading-6 hover:bg-white/[0.08]"),
                                children: [(0, i.jsx)("p", {
                                    className: "text-[13px] group-hover/language-text:text-white font-semibold",
                                    children: d(L.Nm[e].language)
                                }), t && (0, i.jsx)("p", {
                                    className: "group-hover/language-text:text-white/[0.8] leading-[10px] text-white/[0.4] text-[12px] font-medium",
                                    children: d(t)
                                })]
                            }, e)
                        }))
                    })
                })), [m, l]);
                return (0, u.useEffect)((() => {
                    r(!(window.innerWidth < 768))
                }), []), (0, i.jsxs)("div", {
                    className: "w-full h-full flex flex-col-reverse gap-6 py-4 border-t-[1px] border-white/10 md:flex-row md:justify-between md:items-center",
                    children: [(0, i.jsxs)("div", {
                        className: "flex flex-col-reverse gap-1 md:flex-row md:flex-wrap-reverse md:items-center pl-8 md:pl-10 xl:pl-12 2xl:pl-12",
                        children: [(0, i.jsx)("p", {
                            className: "text-white/70 text-nowrap text-sm uppercase font-light",
                            children: "".concat(d("Footer_Copyright_Reserved", {
                                year: (new Date).getFullYear()
                            })).concat(n ? " ·" : "")
                        }), (0, i.jsxs)("div", {
                            className: "flex gap-1",
                            children: [(0, i.jsx)(w.default, {
                                href: "https://privacy.wegic.ai/wegic-privacy-policy",
                                target: "_blank",
                                className: "text-white/70 text-nowrap hover:text-white text-sm font-light",
                                children: d("Footer_Copyright_Privacy")
                            }), (0, i.jsx)(w.default, {
                                href: "https://privacy.wegic.ai/",
                                target: "_blank",
                                className: "text-white/70 text-nowrap text-sm font-light hover:text-white",
                                children: d("Footer_Copyright_Terms")
                            }), t && (0, i.jsx)(C.Z, {
                                position: "top",
                                popupAlign: {
                                    top: 10
                                },
                                popupVisible: g,
                                onVisibleChange: e => {
                                    f(e)
                                },
                                classNames: "zoomInBottom",
                                trigger: "click",
                                popup: () => b,
                                getPopupContainer: () => a.current,
                                children: (0, i.jsxs)("div", {
                                    ref: a,
                                    className: "group/language z-10 flex flex-nowrap items-center gap-1 text-white/70 text-sm font-light",
                                    children: [(0, i.jsx)(N.Z, {
                                        className: "group-hover/language:text-white text-base text-white/70"
                                    }), (0, i.jsx)("span", {
                                        className: "group-hover/language:text-white",
                                        children: "".concat(d(L.Nm[m].language)).concat(v)
                                    })]
                                })
                            })]
                        })]
                    }), (0, i.jsx)(F, {})]
                })
            }
            var P = n(56771),
                Z = n(30664);
            var I = e => {
                let {
                    item: t = "Animation Tooltip",
                    children: n,
                    className: r
                } = e;
                const [l, c] = (0, u.useState)(!1), o = {
                    stiffness: 100,
                    damping: 5
                }, d = (0, P.c)(0), g = (0, Z.q)((0, a.H)(d, [-100, 100], [-45, 45]), o), f = (0, Z.q)((0, a.H)(d, [-100, 100], [-50, 50]), o);
                return (0, i.jsxs)(s.E.div, {
                    onHoverStart: () => {
                        c(!0)
                    },
                    onHoverEnd: () => {
                        c(!1)
                    },
                    className: "relative cursor-pointer flex justify-center",
                    children: [l && (0, i.jsx)(s.E.div, {
                        initial: {
                            opacity: 0,
                            y: 20,
                            scale: .6
                        },
                        animate: {
                            opacity: 1,
                            y: 0,
                            scale: 1,
                            transition: {
                                type: "spring",
                                stiffness: 260,
                                damping: 10
                            }
                        },
                        exit: {
                            opacity: 0,
                            y: 20,
                            scale: .6
                        },
                        style: {
                            translateX: f,
                            rotate: g,
                            whiteSpace: "nowrap"
                        },
                        className: "absolute -top-5 flex text-xs flex-col items-center justify-center rounded-xl bg-black z-50 shadow-xl px-4 py-2",
                        children: (0, i.jsx)("div", {
                            className: " text-white relative z-30 text-base",
                            children: t
                        })
                    }), (0, i.jsx)("div", {
                        className: "".concat(r || ""),
                        onMouseMove: e => {
                            const t = e.target,
                                n = (null == t ? void 0 : t.clientWidth) / 2;
                            d.set(e.nativeEvent.offsetX - n)
                        },
                        children: n
                    })]
                })
            };

            function T() {
                const e = (0, u.useRef)(null),
                    {
                        scrollYProgress: t
                    } = (0, r.v)({
                        target: e,
                        offset: ["start end", "end start"]
                    }),
                    n = (0, a.H)(t, [0, .4], [1.8, 1]);
                return (0, i.jsxs)("section", {
                    "data-follow-hidden": !0,
                    className: "relative w-full h-[46.25rem] md:h-[40rem] flex justify-center pt-[5%] md:pt-[3%] lg:pt-[2%] xl:pt-[1.5%] 2xl:pt-[1.5%] bg-[#FBFBFB]",
                    children: [(0, i.jsx)(s.E.div, {
                        initial: {
                            opacity: 0,
                            y: 300,
                            scale: .8
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0,
                            scale: 1
                        },
                        transition: {
                            type: "spring",
                            bounce: .2,
                            duration: .6
                        },
                        children: (0, i.jsx)(W, {})
                    }), (0, i.jsxs)(s.E.div, {
                        ref: e,
                        className: "absolute z-10 bottom-0 w-full h-[33rem] md:h-[23rem] flex flex-col gap-8 md:gap-14 bg-black py-8 md:py-10 xl:py-12 2xl:py-12 origin-bottom",
                        id: "footer",
                        children: [(0, i.jsxs)("div", {
                            className: "w-full justify-between flex flex-col gap-24 md:flex-row md:flex md:gap-32 xl:gap-48 px-8 md:px-10 xl:px-12 2xl:px-12",
                            children: [(0, i.jsx)(s.E.div, {
                                className: "w-fit origin-top-left",
                                style: {
                                    scale: n
                                },
                                children: (0, i.jsx)(g.Z, {
                                    className: "w-auto h-8"
                                })
                            }), (0, i.jsx)(j, {})]
                        }), (0, i.jsx)(O, {})]
                    })]
                })
            }

            function H(e) {
                const {
                    isShowLanguageBtn: t = !0
                } = e;
                return (0, i.jsxs)("div", {
                    className: "w-full h-h-fit md:h-fit flex flex-col gap-8 md:gap-14 bg-black pt-8 md:pt-10 xl:pt-12 2xl:pt-12 origin-bottom",
                    id: "footer",
                    children: [(0, i.jsxs)("div", {
                        className: "w-full flex flex-col md:flex-row gap-24 md:gap-32 px-8 md:px-10 xl:px-12 2xl:px-12",
                        children: [(0, i.jsx)("div", {
                            className: "w-full",
                            children: (0, i.jsx)(g.Z, {
                                className: "w-auto h-8"
                            })
                        }), (0, i.jsx)(j, {})]
                    }), (0, i.jsx)(O, {
                        isShowLanguageBtn: t
                    })]
                })
            }
            const W = () => {
                const [e, t] = (0, u.useState)(!1), [n, r] = (0, u.useState)(!1), [a, g] = (0, u.useState)(!1), [p, x] = (0, u.useState)(!0), w = (0, o.useTranslations)(), v = () => {
                    t(!1), r(!1), g(!1), x(!0)
                };
                return (0, i.jsxs)("div", {
                    className: "relative translate-x-8 w-full flex justify-center items-center",
                    children: [(0, i.jsxs)("div", {
                        className: "absolute z-10 w-[22rem] h-[15rem] md:w-[30rem] md:h-[20rem] xl:w-[30rem] xl:h-[20rem] 2xl:w-[30rem] 2xl:h-[20rem] grid grid-cols-3 items-end",
                        children: [(0, i.jsx)(I, {
                            item: w("Footer_IP_Timmy"),
                            children: (0, i.jsx)(s.E.div, {
                                className: "w-[7rem] h-[12rem] md:w-[10rem] md:h-[14rem] xl:w-[10rem] xl:h-[14rem] 2xl:w-[10rem] 2xl:h-[14rem] bg-slate-500/0",
                                onHoverStart: () => {
                                    t(!0), r(!1), g(!1), x(!1)
                                },
                                onHoverEnd: v
                            })
                        }), (0, i.jsx)(I, {
                            item: w("Footer_IP_Kimmy"),
                            children: (0, i.jsx)(s.E.div, {
                                className: "w-[7rem] h-[15rem] md:w-[10rem] md:h-[18rem] xl:w-[10rem] xl:h-[18rem] 2xl:w-[10rem] 2xl:h-[18rem] bg-slate-500/0",
                                onHoverStart: () => {
                                    r(!0), t(!1), g(!1), x(!1)
                                },
                                onHoverEnd: v
                            })
                        }), (0, i.jsx)(I, {
                            item: w("Footer_IP_Turi"),
                            children: (0, i.jsx)(s.E.div, {
                                className: "w-[5rem] h-[11rem] md:w-[10rem] md:h-[13rem] xl:w-[10rem] xl:h-[13rem] -ml-24 2xl:w-[10rem] 2xl:h-[13rem] bg-slate-500/0",
                                onHoverStart: () => {
                                    g(!0), t(!1), r(!1), x(!1)
                                },
                                onHoverEnd: v
                            })
                        })]
                    }), (0, i.jsx)("div", {
                        className: "w-[22rem] h-[15rem] md:w-[30rem] md:h-[20rem] xl:w-[30rem] xl:h-[20rem] 2xl:w-[30rem] 2xl:h-[20rem]",
                        children: (0, i.jsx)(l.M, {
                            children: (0, i.jsxs)(i.Fragment, {
                                children: [(0, i.jsx)(c.default, {
                                    className: "absolute inset-0 z-0 w-[22rem] md:w-[30rem] xl:w-[30rem] 2xl:w-[30rem] h-auto ".concat(p ? " block" : " invisible"),
                                    src: d,
                                    alt: "AllPeople",
                                    width: 363,
                                    height: 268
                                }), (0, i.jsx)(c.default, {
                                    className: "absolute inset-0 z-0 w-[22rem] md:w-[30rem] xl:w-[30rem] 2xl:w-[30rem] h-auto ".concat(e ? " block" : " invisible"),
                                    src: m,
                                    alt: "Timmy",
                                    width: 363,
                                    height: 268
                                }), (0, i.jsx)(c.default, {
                                    className: "absolute inset-0 z-0 w-[22rem] md:w-[30rem] xl:w-[30rem] 2xl:w-[30rem] h-auto ".concat(n ? " block" : " invisible"),
                                    src: f,
                                    alt: "Kimmy",
                                    width: 363,
                                    height: 268
                                }), (0, i.jsx)(c.default, {
                                    className: "absolute inset-0 z-0 w-[22rem] md:w-[30rem] xl:w-[30rem] 2xl:w-[30rem] h-auto ".concat(a ? " block" : " invisible"),
                                    src: h,
                                    alt: "Turi",
                                    width: 363,
                                    height: 268
                                })]
                            })
                        })
                    })]
                })
            }
        },
        21658: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return g
                }
            });
            var i = n(75467),
                r = n(9850),
                a = n.n(r),
                s = (n(98046), n(52818));

            function l() {
                return l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }, l.apply(this, arguments)
            }
            var c = function(e) {
                    return s.createElement("svg", l({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "1em",
                        height: "1em",
                        fill: "none",
                        viewBox: "0 0 20 20"
                    }, e), s.createElement("path", {
                        d: "M8.5 3.333V1.667q0-.074.007-.147.007-.074.022-.146t.036-.143q.021-.07.05-.138.027-.068.062-.133t.076-.127q.04-.06.087-.118t.1-.109q.051-.052.108-.099T9.167.42t.126-.076q.065-.035.133-.063t.139-.05.142-.035.146-.022T10 .167t.147.007.146.022.142.035.139.05.133.063.126.076q.062.04.119.087t.109.1.098.108q.047.057.088.118.041.062.076.127t.063.133.05.138q.02.07.035.143t.022.146q.007.073.007.147v1.666q0 .074-.007.147t-.022.146-.036.142-.05.139q-.027.068-.062.133t-.076.126-.088.119q-.046.057-.098.109t-.11.099-.118.087q-.06.041-.126.076-.065.035-.133.063t-.139.05q-.07.02-.142.035-.073.015-.146.022T10 4.833t-.147-.007-.146-.022-.142-.036q-.07-.021-.139-.05-.068-.027-.133-.062t-.126-.076-.119-.087-.109-.1-.099-.108q-.046-.057-.087-.119-.041-.06-.076-.126-.035-.065-.063-.133t-.05-.139q-.02-.07-.035-.142-.015-.073-.022-.146T8.5 3.333M17.967 7.133l-1.444.833q-.063.037-.13.067-.068.03-.137.054-.07.024-.142.04-.072.017-.145.027t-.146.012-.148-.002-.146-.017-.144-.031-.14-.045-.135-.059-.129-.071q-.062-.04-.12-.084-.06-.045-.113-.095t-.102-.106-.092-.115q-.043-.06-.08-.124t-.067-.131-.054-.137-.04-.142-.027-.144-.012-.147.003-.147.017-.147.03-.143.046-.14.058-.136.072-.128.083-.121.096-.113.105-.102.116-.091.123-.08l1.444-.834q.064-.036.13-.067.068-.03.138-.054t.141-.04.145-.027.147-.012q.073-.002.147.003.073.005.146.017t.144.03.14.046.135.058.129.072.121.083.112.096.103.105.091.116.08.123.067.131q.03.068.054.137.024.07.04.142.017.072.027.145t.012.146-.002.148-.017.146-.031.144-.045.14-.059.135-.071.129q-.04.062-.084.12-.045.06-.095.113t-.106.102q-.056.049-.116.092t-.123.08M16.467 15.466l-1.444-.833q-.063-.037-.123-.08t-.116-.092-.105-.102q-.05-.054-.096-.112-.044-.059-.083-.121-.04-.063-.072-.13-.033-.065-.058-.134-.026-.07-.045-.14-.02-.072-.031-.144-.013-.073-.017-.146-.005-.074-.003-.148.003-.073.012-.146t.027-.145q.016-.072.04-.142t.054-.137.067-.13.08-.124.092-.116q.048-.055.102-.105t.112-.096.121-.083.129-.072.135-.058.14-.045q.071-.02.144-.031.073-.012.146-.017.074-.005.147-.003.074.003.147.012t.145.027q.072.016.142.04t.136.054.131.067l1.444.834q.064.037.123.08.06.043.116.091.055.049.106.102.05.054.095.113.045.058.084.12.038.063.071.13.033.066.059.134.026.07.045.14.019.072.03.144.013.073.018.147.004.073.002.147t-.012.147-.026.144q-.017.072-.04.142-.025.07-.055.137t-.067.13q-.037.065-.08.125t-.091.115q-.049.055-.103.106t-.112.095-.121.084-.129.071-.135.059-.14.045-.144.03-.146.018-.147.002-.147-.012-.145-.026-.141-.04-.137-.055-.131-.067M11.5 16.667v1.666q0 .074-.007.147t-.022.146-.036.142-.05.139q-.027.068-.062.133t-.076.126-.088.119q-.046.057-.098.109t-.11.099-.118.087q-.06.041-.126.076-.065.035-.133.063t-.139.05q-.07.02-.142.035-.073.015-.146.022t-.147.007-.147-.007-.146-.022-.142-.036-.139-.05-.133-.062-.126-.076-.119-.087-.109-.1-.099-.108-.087-.119-.076-.126-.063-.133-.05-.139q-.02-.07-.035-.142-.015-.073-.022-.146t-.007-.147v-1.666q0-.074.007-.147.007-.074.022-.146t.036-.143q.021-.07.05-.138.027-.068.062-.133t.076-.127q.04-.06.087-.118t.1-.109q.051-.052.108-.099.057-.046.119-.088.06-.04.126-.075.065-.035.133-.063t.139-.05.142-.035.146-.022.147-.007.147.007.146.022.142.035.139.05.133.063.126.075.119.088.109.1q.052.051.098.108t.088.118q.041.062.076.127t.063.133.05.138q.02.07.035.143t.022.146q.007.073.007.147M2.033 12.868l1.444-.834q.063-.036.13-.067.068-.03.137-.054.07-.024.142-.04.072-.017.145-.027t.147-.012.147.003.146.017.144.03.14.046.135.058.129.072.12.083q.06.045.113.096.054.05.102.105.049.056.092.116t.08.123q.036.064.067.131.03.068.054.137.024.07.04.142.017.072.027.145t.012.146-.003.148q-.004.073-.016.146t-.032.144-.045.14-.058.135q-.033.066-.072.129-.039.062-.083.12-.045.06-.096.113-.05.054-.105.102-.056.049-.116.092t-.123.08l-1.444.833q-.064.037-.13.067-.068.03-.138.054t-.141.04-.145.027-.147.012q-.073.002-.147-.002-.073-.005-.146-.017t-.144-.031-.14-.045-.135-.059-.129-.071q-.062-.04-.121-.084t-.112-.095q-.054-.05-.103-.106t-.091-.115-.08-.124-.067-.131-.054-.137-.04-.142-.027-.144-.012-.147.002-.147.017-.147.031-.143.045-.14q.026-.07.059-.136.032-.066.071-.128.04-.063.084-.121.045-.059.095-.113.05-.053.106-.102t.115-.091.124-.08M3.533 4.534l1.444.834q.063.037.123.08.06.042.116.091.055.049.105.102.05.054.096.113.044.058.083.12.04.063.072.13.032.065.058.134.026.07.045.14.02.072.032.144.012.073.016.147.005.073.003.147-.003.074-.012.147t-.027.144q-.016.072-.04.142t-.054.137-.067.13q-.037.065-.08.125t-.092.115q-.048.055-.102.106t-.112.095q-.059.045-.121.084-.063.039-.129.071-.066.033-.135.059t-.14.045-.144.03q-.073.013-.146.018-.074.004-.147.002-.074-.002-.147-.012t-.145-.026-.142-.04-.136-.055-.131-.067l-1.444-.833q-.064-.037-.124-.08t-.115-.092-.106-.102-.095-.112-.084-.121-.071-.13q-.033-.065-.059-.134-.026-.07-.045-.14t-.03-.144-.018-.146q-.004-.074-.002-.148.002-.073.012-.146t.026-.145.04-.142.055-.137.067-.13.08-.124.091-.116q.049-.055.103-.105t.112-.096.121-.083.129-.072.135-.058.14-.045q.071-.02.144-.031.073-.012.146-.017.074-.005.147-.003.074.003.147.012t.145.027q.072.016.141.04.07.024.137.054t.131.067",
                        style: {
                            fill: "currentColor",
                            opacity: 1
                        }
                    }))
                },
                o = n(9092),
                u = n.n(o);
            var d = function(e) {
                const {
                    size: t = 20,
                    color: n = "#000000",
                    style: r,
                    className: s = "",
                    block: l,
                    mask: o
                } = e;
                return (0, i.jsx)("div", {
                    className: a()(u().wrapper, s, {
                        [u()["loading-block"]]: l,
                        [u()["loading-mask"]]: o
                    }),
                    children: (0, i.jsx)(c, {
                        className: u().loading,
                        style: {
                            fontSize: t,
                            color: n,
                            width: t,
                            height: t,
                            ...r
                        }
                    })
                })
            };
            var g = function(e) {
                const {
                    type: t = "primary",
                    status: n,
                    style: r,
                    className: s = "",
                    children: l,
                    size: c = "default",
                    disabled: o,
                    loading: u,
                    block: g,
                    onClick: f,
                    icon: m,
                    ...h
                } = e;
                return (0, i.jsxs)("button", { ...h,
                    type: "button",
                    style: { ...r
                    },
                    className: a()(["wg-button", "wg-button-".concat(t), "wg-button-size-".concat(c)], {
                        ["wg-button-status-".concat(n)]: !!n,
                        "wg-button-block": g,
                        "wg-button-loading": u,
                        "wg-button-disabled": o,
                        "wg-button-only-icon": !!m && !l
                    }, s),
                    onClick: e => {
                        u || o || f && f(e)
                    },
                    children: [(0, i.jsxs)("div", {
                        className: "wg-button-content",
                        children: [m && (0, i.jsx)("div", {
                            className: "wg-button-icon",
                            children: m
                        }), l && (0, i.jsx)("div", {
                            className: "wg-button-children",
                            children: l
                        })]
                    }), u && (0, i.jsx)(d, {
                        block: !0,
                        className: "wg-button-loading",
                        color: "inherit"
                    })]
                })
            }
        },
        12868: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var i = n(75467),
                r = n(9850),
                a = n.n(r),
                s = n(42140),
                l = n(20344),
                c = n.n(l);

            function o(e) {
                const {
                    onChange: t,
                    style: n,
                    className: r,
                    isExpand: l,
                    children: o,
                    placement: u = "top",
                    background: d = "#0D0D0D"
                } = e;
                return (0, i.jsx)(s.E.div, {
                    style: {
                        "--drawer-background": d,
                        ...n
                    },
                    className: a()(c().drawer, c()["drawer__".concat(u)], {
                        [c()["drawer__".concat(u, "--expanded")]]: l,
                        [c()["drawer__".concat(u, "--collapsed")]]: !l
                    }, r),
                    onClick: () => {
                        t(!l)
                    },
                    children: o
                })
            }
        },
        73258: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return i
                }
            });
            const i = 100007
        },
        72241: function(e, t, n) {
            "use strict";
            n.d(t, {
                B9: function() {
                    return i
                },
                Lc: function() {
                    return s
                },
                Pt: function() {
                    return r
                },
                k7: function() {
                    return a
                }
            });
            const i = {
                    page_view_wegicai: "basic_functions",
                    home_endofpage_dialogbox: "basic_functions",
                    bounce_location: "basic_functions",
                    blog_banner_button_click: "basic_functions",
                    ph_infusion_click: "basic_functions",
                    user_login: "basic_functions",
                    user_signup: "basic_functions",
                    sem_lp_button_click: "basic_functions",
                    button_click: "basic_functions",
                    wegic_signup: "wegic_official",
                    wegic_build: "wegic_official",
                    sem_lp: "ai_abtest",
                    official_click: "basic_functions",
                    user_case_click: "basic_functions",
                    send_message: "ai_messages"
                },
                r = "source",
                a = "plan",
                s = "code"
        },
        11338: function(e, t, n) {
            "use strict";
            n.d(t, {
                GX: function() {
                    return g
                },
                T3: function() {
                    return d
                },
                ps: function() {
                    return u
                }
            });
            var i = n(94875),
                r = n(61213),
                a = n(83847),
                s = n(761),
                l = n(72241);
            let c = !1;
            const o = [];
            async function u() {
                i.ZP.init({
                    actionToThemeMap: l.B9,
                    businessType: "wegic",
                    userId: "",
                    isOnline: a.Gg,
                    serverUrl: a.YR
                })
            }
            async function d() {
                for (c = !0; o.length > 0;) {
                    const e = o.shift();
                    (null == e ? void 0 : e.length) && g(e[0], e[1])
                }
            }
            async function g(e, t) {
                var n;
                if (!c) return void o.push([e, t]);
                const l = {
                        firstEnterUrl: (0, r.g)(),
                        referrerUrl: (0, r.y)(),
                        version: a.D0 || null === (n = window.scm) || void 0 === n ? void 0 : n.gitHash,
                        ...t
                    },
                    {
                        userId: u
                    } = s.L.getState();
                i.ZP.setConfig("userId", u || ""), (0, i.KM)(e, l)
            }
        },
        89242: function(e, t, n) {
            "use strict";
            n.d(t, {
                b: function() {
                    return a
                }
            });
            var i = n(761),
                r = n(11338);

            function a(e, t, n) {
                const {
                    isLogin: a
                } = i.L.getState(), s = t && (null == t ? void 0 : t.app) ? "?".concat(null == t ? void 0 : t.app) : "", l = t && (null == t ? void 0 : t.login) ? "?".concat(null == t ? void 0 : t.login) : "";
                (0, r.GX)(e ? "wegic_build" : "wegic_signup"), n ? open(null == t ? void 0 : t.fromLandingUrl) : location.href = !e || a ? a ? "/workspace" : "/login".concat(l) : "/app".concat(s)
            }
        },
        89872: function(e, t, n) {
            "use strict";
            n.d(t, {
                Nm: function() {
                    return a
                },
                X9: function() {
                    return r
                }
            });
            var i = n(42466);
            const r = i.i.en,
                a = {
                    [i.i.en]: {
                        language: "UserSettings_Language_EnUS"
                    },
                    [i.i.fr]: {
                        language: "UserSettings_Language_FrFR"
                    },
                    [i.i.es]: {
                        language: "UserSettings_Language_EsES"
                    },
                    [i.i.de]: {
                        language: "UserSettings_Language_DeDE"
                    },
                    [i.i.it]: {
                        language: "UserSettings_Language_ItIT"
                    },
                    [i.i.ja]: {
                        language: "UserSettings_Language_JaJP"
                    },
                    [i.i["pt-br"]]: {
                        language: "UserSettings_Language_PT",
                        country: "UserSettings_Country_BR"
                    },
                    [i.i["pt-pt"]]: {
                        language: "UserSettings_Language_PT",
                        country: "UserSettings_Country_PT"
                    },
                    [i.i.nl]: {
                        language: "UserSettings_Language_NlNL"
                    },
                    [i.i.tr]: {
                        language: "UserSettings_Language_TrTR"
                    },
                    [i.i["zh-hk"]]: {
                        language: "UserSettings_Language_ZhHK"
                    },
                    [i.i["zh-cn"]]: {
                        language: "UserSettings_Language_ZhCN"
                    },
                    [i.i.vi]: {
                        language: "UserSettings_Language_ViVN"
                    }
                }
        },
        42466: function(e, t, n) {
            "use strict";
            var i;
            n.d(t, {
                    i: function() {
                        return i
                    }
                }),
                function(e) {
                    e.en = "en", e.ja = "ja", e.de = "de", e.fr = "fr", e.es = "es", e.it = "it", e.nl = "nl", e["zh-cn"] = "zh-cn", e["zh-hk"] = "zh-hk", e.tr = "tr", e["pt-pt"] = "pt-pt", e["pt-br"] = "pt-br", e.vi = "vi"
                }(i || (i = {}))
        },
        13561: function(e, t, n) {
            "use strict";
            n.d(t, {
                AK: function() {
                    return u
                },
                FV: function() {
                    return r
                },
                hJ: function() {
                    return o
                },
                jp: function() {
                    return l
                },
                nS: function() {
                    return s
                },
                rz: function() {
                    return c
                },
                ue: function() {
                    return a
                },
                v0: function() {
                    return d
                }
            });
            var i = n(55043);

            function r() {
                return i.WG.get("/accounts")
            }

            function a() {
                return i.Ok.get("/integral/v1/user/subscription")
            }

            function s() {
                return i.WG.get("/settings")
            }
            async function l(e) {
                return i.WG.post("/settings/user-info", {
                    type: 26,
                    value: {
                        language: e
                    }
                })
            }
            async function c(e) {
                return i.WG.post("/right/check", { ...e
                })
            }
            async function o() {
                return i.WG.get("/notify")
            }

            function u(e) {
                return i.WG.post("/notify/".concat(e))
            }

            function d(e) {
                return i.WG.get("/abtest/".concat(e), {
                    params: {
                        abTestBusinessKey: "refundPromise"
                    }
                })
            }
        },
        761: function(e, t, n) {
            "use strict";
            n.d(t, {
                L: function() {
                    return a
                }
            });
            var i = n(1435);
            const r = {
                    notLogin: !1,
                    isLogin: !1,
                    email: "",
                    password: "",
                    unionId: "",
                    userId: "",
                    userImage: "",
                    userName: "",
                    inviteCode: "",
                    countryBlock: !1,
                    freeRightBlock: !1,
                    isRenew: !1,
                    discount: 1.2,
                    isSupportRefund: !1
                },
                a = (0, i.Ue)(((e, t) => ({ ...r,
                    setIsLogin(t) {
                        e({
                            isLogin: t
                        })
                    },
                    setNotLogin(t) {
                        e({
                            notLogin: t
                        })
                    },
                    setUserInfo(n) {
                        const {
                            setIsLogin: i,
                            setNotLogin: r
                        } = t();
                        e(n), n.userId && (i(!0), r(!1), e({
                            password: ""
                        }))
                    },
                    getUserInfo() {
                        const {
                            email: e,
                            unionId: n,
                            userId: i,
                            userImage: r,
                            userName: a,
                            inviteCode: s,
                            countryBlock: l,
                            freeRightBlock: c
                        } = t();
                        return {
                            email: e,
                            unionId: n,
                            userId: i,
                            userImage: r,
                            userName: a,
                            inviteCode: s,
                            countryBlock: l,
                            freeRightBlock: c
                        }
                    },
                    userSubscription: void 0,
                    setUserSubscription(t) {
                        e({
                            userSubscription: t
                        })
                    },
                    setIsRenew(t) {
                        e({
                            isRenew: t
                        })
                    },
                    isUnlimitedUser: !1,
                    setIsUnlimitedUser(t) {
                        e({
                            isUnlimitedUser: t
                        })
                    },
                    duration: {
                        updateTime: Date.now(),
                        leftTime: 864e5
                    },
                    setDuration: t => {
                        e({
                            duration: {
                                updateTime: Date.now(),
                                leftTime: t
                            }
                        })
                    },
                    setIsSupportRefund(t) {
                        e({
                            isSupportRefund: t
                        })
                    }
                })))
        },
        19697: function(e, t, n) {
            "use strict";
            n.d(t, {
                W7: function() {
                    return o
                },
                bL: function() {
                    return u
                },
                gw: function() {
                    return c
                }
            });
            var i = n(21556),
                r = n(7083),
                a = n(88654),
                s = n.n(a),
                l = n(761);

            function c(e) {
                return new Promise((t => setTimeout(t, e)))
            }

            function o() {
                const e = (0, r.Z)();
                return e.phone || e.tablet
            }

            function u() {
                const {
                    userId: e,
                    email: t
                } = l.L.getState();
                e ? i.av({
                    id: e,
                    email: s()(t)
                }) : i.av({
                    id: "anonymous",
                    email: "anonymous"
                })
            }
        },
        77726: function() {},
        98046: function() {},
        92035: function(e) {
            e.exports = {
                loading: "Avatar_loading__MOrp4"
            }
        },
        20344: function(e) {
            e.exports = {
                drawer: "Drawer_drawer__zH7vh",
                drawer__top: "Drawer_drawer__top__9dDMj",
                "drawer__top--expanded": "Drawer_drawer__top--expanded__WHQRq",
                "drawer__top--collapsed": "Drawer_drawer__top--collapsed__qleP_"
            }
        },
        9092: function(e) {
            e.exports = {
                wrapper: "Loading_wrapper__CveuR",
                loading: "Loading_loading__wheNI",
                "loading-block": "Loading_loading-block__MfopP",
                "loading-mask": "Loading_loading-mask__g2zOn"
            }
        }
    }
]);