/*! For license information please see 8339-aa6dea196483a8de.js.LICENSE.txt */ ! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "cb93fb83-c561-4877-8a9d-ce79432cd495", t._sentryDebugIdIdentifier = "sentry-dbid-cb93fb83-c561-4877-8a9d-ce79432cd495")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8339], {
        81129: function(t, e, n) {
            "use strict";
            n.d(e, {
                E: function() {
                    return P
                },
                G: function() {
                    return w
                }
            });
            var i = n(84371),
                r = (n(99752), {
                    formatYear: "YYYY 年",
                    formatMonth: "YYYY 年 MM 月",
                    monthBeforeYear: !1,
                    today: "今天",
                    view: {
                        month: "月",
                        year: "年",
                        week: "周",
                        day: "日"
                    },
                    month: {
                        long: {
                            January: "一月",
                            February: "二月",
                            March: "三月",
                            April: "四月",
                            May: "五月",
                            June: "六月",
                            July: "七月",
                            August: "八月",
                            September: "九月",
                            October: "十月",
                            November: "十一月",
                            December: "十二月"
                        },
                        short: {
                            January: "一月",
                            February: "二月",
                            March: "三月",
                            April: "四月",
                            May: "五月",
                            June: "六月",
                            July: "七月",
                            August: "八月",
                            September: "九月",
                            October: "十月",
                            November: "十一月",
                            December: "十二月"
                        }
                    },
                    week: {
                        long: {
                            self: "周",
                            monday: "周一",
                            tuesday: "周二",
                            wednesday: "周三",
                            thursday: "周四",
                            friday: "周五",
                            saturday: "周六",
                            sunday: "周日"
                        },
                        short: {
                            self: "周",
                            monday: "一",
                            tuesday: "二",
                            wednesday: "三",
                            thursday: "四",
                            friday: "五",
                            saturday: "六",
                            sunday: "日"
                        }
                    }
                }),
                o = {
                    locale: "zh-CN",
                    dayjsLocale: "zh-cn",
                    Calendar: r,
                    DatePicker: {
                        Calendar: r,
                        placeholder: {
                            date: "请选择日期",
                            week: "请选择周",
                            month: "请选择月份",
                            year: "请选择年份",
                            quarter: "请选择季度"
                        },
                        placeholders: {
                            date: ["开始日期", "结束日期"],
                            week: ["开始周", "结束周"],
                            month: ["开始月份", "结束月份"],
                            year: ["开始年份", "结束年份"],
                            quarter: ["开始季度", "结束季度"]
                        },
                        selectTime: "选择时间",
                        selectDate: "选择日期",
                        today: "今天",
                        now: "此刻",
                        ok: "确定"
                    },
                    Drawer: {
                        okText: "确定",
                        cancelText: "取消"
                    },
                    Empty: {
                        noData: "暂无数据"
                    },
                    Modal: {
                        okText: "确定",
                        cancelText: "取消"
                    },
                    Pagination: {
                        goto: "前往",
                        page: "页",
                        countPerPage: "条/页",
                        total: "共 {0} 条",
                        prev: "上一页",
                        next: "下一页",
                        currentPage: "第 {0} 页",
                        prevSomePages: "向前 {0} 页",
                        nextSomePages: "向后 {0} 页",
                        pageSize: "页码"
                    },
                    Popconfirm: {
                        okText: "确定",
                        cancelText: "取消"
                    },
                    Table: {
                        okText: "确定",
                        resetText: "重置",
                        sortAscend: "点击升序",
                        sortDescend: "点击降序",
                        cancelSort: "取消排序"
                    },
                    TimePicker: {
                        ok: "确定",
                        placeholder: "请选择时间",
                        placeholders: ["开始时间", "结束时间"],
                        now: "此刻"
                    },
                    Progress: {
                        success: "完成",
                        error: "失败"
                    },
                    Upload: {
                        start: "开始",
                        cancel: "取消",
                        delete: "删除",
                        reupload: "点击重试",
                        upload: "点击上传",
                        preview: "预览",
                        drag: "点击或拖拽文件到此处上传",
                        dragHover: "释放文件并开始上传",
                        error: "上传失败"
                    },
                    Typography: {
                        copy: "复制",
                        copied: "已复制",
                        edit: "编辑",
                        fold: "折叠",
                        unfold: "展开"
                    },
                    Transfer: {
                        resetText: "重置"
                    },
                    ImagePreview: {
                        fullScreen: "全屏",
                        rotateRight: "向右旋转",
                        rotateLeft: "向左旋转",
                        zoomIn: "放大",
                        zoomOut: "缩小",
                        originalSize: "原始尺寸"
                    },
                    Form: {
                        validateMessages: {
                            required: "#{field} 是必填项",
                            type: {
                                string: "#{field} 不是合法的文本类型",
                                number: "#{field} 不是合法的数字类型",
                                boolean: "#{field} 不是合法的布尔类型",
                                array: "#{field} 不是合法的数组类型",
                                object: "#{field} 不是合法的对象类型",
                                url: "#{field} 不是合法的 url 地址",
                                email: "#{field} 不是合法的邮箱地址",
                                ip: "#{field} 不是合法的 IP 地址"
                            },
                            number: {
                                min: "`#{value}` 小于最小值 `#{min}`",
                                max: "`#{value}` 大于最大值 `#{max}`",
                                equal: "`#{value}` 不等于 `#{equal}`",
                                range: "`#{value}` 不在 `#{min} ~ #{max}` 范围内",
                                positive: "`#{value}` 不是正数",
                                negative: "`#{value}` 不是负数"
                            },
                            array: {
                                length: "`#{field}` 个数不等于 #{length}",
                                minLength: "`#{field}` 个数最少为 #{minLength}",
                                maxLength: "`#{field}` 个数最多为 #{maxLength}",
                                includes: "#{field} 不包含 #{includes}",
                                deepEqual: "#{field} 不等于 #{deepEqual}",
                                empty: "`#{field}` 不是空数组"
                            },
                            string: {
                                minLength: "字符数最少为 #{minLength}",
                                maxLength: "字符数最多为 #{maxLength}",
                                length: "字符数必须是 #{length}",
                                match: "`#{value}` 不符合模式 #{pattern}",
                                uppercase: "`#{value}` 必须全大写",
                                lowercase: "`#{value}` 必须全小写"
                            },
                            object: {
                                deepEqual: "`#{field}` 不等于期望值",
                                hasKeys: "`#{field}` 不包含必须字段",
                                empty: "`#{field}` 不是对象"
                            },
                            boolean: {
                                true: "期望是 `true`",
                                false: "期望是 `false`"
                            }
                        }
                    },
                    ColorPicker: {
                        history: "最近使用颜色",
                        preset: "系统预设颜色",
                        empty: "暂无"
                    }
                },
                s = n(62438),
                a = n(31532),
                u = n(15844);

            function c(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function l(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(n), !0).forEach((function(e) {
                        (0, a.Z)(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }

            function d(t, e) {
                var n = (0, i.useContext)(u.P).prefixCls,
                    r = void 0 === n ? "arco" : n,
                    o = t.spin,
                    a = t.className,
                    c = l(l({
                        "aria-hidden": !0,
                        focusable: !1,
                        ref: e
                    }, t), {}, {
                        className: "".concat(a ? a + " " : "").concat(r, "-icon ").concat(r, "-icon-empty")
                    });
                return o && (c.className = "".concat(c.className, " ").concat(r, "-icon-loading")), delete c.spin, delete c.isIcon, i.createElement("svg", (0, s.Z)({
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "4",
                    viewBox: "0 0 48 48"
                }, c), i.createElement("path", {
                    d: "M24 5v6m7 1 4-4m-18 4-4-4m28.5 22H28s-1 3-4 3-4-3-4-3H6.5M40 41H8a2 2 0 0 1-2-2v-8.46a2 2 0 0 1 .272-1.007l6.15-10.54A2 2 0 0 1 14.148 18H33.85a2 2 0 0 1 1.728.992l6.149 10.541A2 2 0 0 1 42 30.541V39a2 2 0 0 1-2 2Z"
                }))
            }
            var h = i.forwardRef(d);
            h.defaultProps = {
                isIcon: !0
            }, h.displayName = "IconEmpty";
            var f = h,
                p = n(93887),
                m = n(64625),
                v = function() {
                    return v = Object.assign || function(t) {
                        for (var e, n = 1, i = arguments.length; n < i; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }, v.apply(this, arguments)
                },
                g = function(t, e) {
                    var n = {};
                    for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
                    if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
                        var r = 0;
                        for (i = Object.getOwnPropertySymbols(t); r < i.length; r++) e.indexOf(i[r]) < 0 && Object.prototype.propertyIsEnumerable.call(t, i[r]) && (n[i[r]] = t[i[r]])
                    }
                    return n
                };
            var y = (0, i.forwardRef)((function(t, e) {
                var n = (0, i.useContext)(P),
                    r = n.getPrefixCls,
                    o = n.locale,
                    s = n.componentConfig,
                    a = (0, m.Z)(t, {}, null == s ? void 0 : s.Empty),
                    u = a.style,
                    c = a.className,
                    l = a.description,
                    d = a.icon,
                    h = a.imgSrc,
                    y = g(a, ["style", "className", "description", "icon", "imgSrc"]),
                    b = r("empty"),
                    x = (0, p.Z)(b, c),
                    w = o.Empty.noData,
                    E = "string" == typeof l ? l : "empty";
                return i.createElement("div", v({
                    ref: e,
                    className: x,
                    style: u
                }, y), i.createElement("div", {
                    className: b + "-wrapper"
                }, i.createElement("div", {
                    className: b + "-image"
                }, h ? i.createElement("img", {
                    alt: E,
                    src: h
                }) : d || i.createElement(f, null)), i.createElement("div", {
                    className: b + "-description"
                }, l || w)))
            }));
            y.displayName = "Empty";
            var b = (0, i.memo)(y),
                x = function() {
                    return x = Object.assign || function(t) {
                        for (var e, n = 1, i = arguments.length; n < i; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }, x.apply(this, arguments)
                };
            var w = {
                    locale: o,
                    prefixCls: "arco",
                    getPopupContainer: function() {
                        return document.body
                    },
                    size: "default",
                    renderEmpty: function(t) {
                        return i.createElement(b, null)
                    },
                    focusLock: {
                        modal: {
                            autoFocus: !0
                        },
                        drawer: {
                            autoFocus: !0
                        }
                    }
                },
                P = (0, i.createContext)(x({
                    getPrefixCls: function(t, e) {
                        return (e || "arco") + "-" + t
                    }
                }, w))
        },
        17890: function(t, e, n) {
            "use strict";
            n.d(e, {
                C: function() {
                    return D
                },
                Z: function() {
                    return k
                }
            });
            var i = n(84371),
                r = n(29980),
                o = n(19606),
                s = n(69570),
                a = n(94296),
                u = n(69309),
                c = n(41591),
                l = n(17466),
                d = n(2945),
                h = function(t) {
                    var e = t.getContainer,
                        n = t.children,
                        o = (0, i.useRef)();
                    return !(0, d.Z)() && null !== o.current || a.ET || (o.current = e()), (0, i.useEffect)((function() {
                        return function() {
                            var t = o.current;
                            t && t.parentNode && (t.parentNode.removeChild(t), o.current = null)
                        }
                    }), []), o.current ? r.createPortal(n, o.current) : null
                },
                f = n(43819),
                p = n(93887),
                m = n(81129),
                v = function() {
                    return v = Object.assign || function(t) {
                        for (var e, n = 1, i = arguments.length; n < i; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }, v.apply(this, arguments)
                },
                g = function(t, e) {
                    var n, i, r, o, s = e.position,
                        a = t.getBoundingClientRect(),
                        u = a.width,
                        c = a.height,
                        l = a.left,
                        d = a.right,
                        h = a.top,
                        f = a.bottom,
                        p = e.boundaryDistance || {},
                        m = "left" in p && p.left || 0,
                        v = "top" in p && p.top || 0;
                    return ["bottom", "bl", "br"].indexOf(s) > -1 ? (r = h, o = f) : (r = h - v, o = f - v), ["right", "rt", "rb"].indexOf(s) > -1 ? (n = l, i = d) : (n = l - m, i = d - m), {
                        width: u,
                        height: c,
                        left: n,
                        right: i,
                        top: r,
                        bottom: o
                    }
                };
            var y = function(t, e, n) {
                    return n < t ? t : n > e ? e : n
                },
                b = function(t, e, n, i, r) {
                    var o = t.autoAlignPopupWidth,
                        s = t.autoAlignPopupMinWidth,
                        c = t.alignPoint,
                        l = t.style;
                    if (!n || !e || !i) return {};
                    var d = {},
                        h = !t.alignPoint && t.boundaryDistance || {},
                        f = function(t, e, n) {
                            var i = n.boundaryDistance,
                                r = n.position;
                            return e ? {
                                left: e.clientX,
                                top: e.clientY,
                                width: 0,
                                height: 0,
                                right: e.clientX,
                                bottom: e.clientY
                            } : g(t, {
                                boundaryDistance: i,
                                position: r
                            })
                        }(n, c && r, {
                            boundaryDistance: h,
                            position: t.position
                        }),
                        p = function(t, e, n, i) {
                            if (!n || !t || a.ET) return {
                                left: 0,
                                width: 0,
                                height: 0,
                                top: 0
                            };
                            var r = function(t) {
                                    return document.documentElement[t] || document.body[t]
                                },
                                o = n === document.body ? r("scrollTop") : n.scrollTop,
                                s = n === document.body ? r("scrollLeft") : n.scrollLeft,
                                u = e.left,
                                c = e.top,
                                l = e.width,
                                d = e.height;
                            return {
                                left: u + s - (n === document.body ? 0 : g(n, i).left),
                                top: c + o - (n === document.body ? 0 : g(n, i).top),
                                width: l,
                                height: d
                            }
                        }(n, f, i, {
                            boundaryDistance: h,
                            position: t.position
                        }),
                        m = p.left,
                        b = p.top,
                        x = p.width,
                        w = p.height,
                        P = function(t, e) {
                            var n = 0,
                                i = 0,
                                r = {};
                            for (var o in r = v(e ? {
                                    left: 12,
                                    right: 12,
                                    top: 12,
                                    bottom: 12
                                } : {}, t))
                                if ((0, u.kJ)(r[o])) {
                                    var s = 0;
                                    ["top", "bottom"].indexOf(o) > -1 ? (s = 1, n = r[o][0]) : i = r[o][1], r[o] = r[o][s]
                                }
                            return v(v({}, r), {
                                horizontalOffset: n,
                                verticalOffset: i
                            })
                        }(t.popupAlign, t.showArrow),
                        E = P.left || 0,
                        T = P.right || 0,
                        S = P.top || 0,
                        M = P.bottom || 0;
                    o && void 0 === (null == l ? void 0 : l.width) && (e.style.width = n.offsetWidth + "px"), s && (e.style.minWidth = n.offsetWidth + "px");
                    var C = function(t) {
                            return {
                                width: t.offsetWidth,
                                height: t.offsetHeight
                            }
                        }(e),
                        D = t.position,
                        O = {},
                        A = function(e) {
                            if (t.autoFitPosition) {
                                var n = function(t) {
                                        var e, n, i = t || {},
                                            r = "left" in i ? i.left : "right" in i ? i.right : 0,
                                            o = "top" in i ? i.top : "bottom" in i ? i.bottom : 0;
                                        return {
                                            windowHeight: ((null === (e = document.documentElement) || void 0 === e ? void 0 : e.clientHeight) || window.innerHeight) - (o || 0),
                                            windowWidth: ((null === (n = document.documentElement) || void 0 === n ? void 0 : n.clientWidth) || window.innerWidth) - (r || 0)
                                        }
                                    }(h),
                                    r = n.windowHeight,
                                    o = n.windowWidth,
                                    s = !1,
                                    a = {
                                        left: m - f.left,
                                        top: b - f.top
                                    },
                                    u = d.top,
                                    c = void 0 === u ? 0 : u,
                                    l = d.left,
                                    p = void 0 === l ? 0 : l;
                                if ("top" !== e && "bottom" !== e || (a.left > p && f.right > 12 ? (d.left = Math.max(a.left, m - C.width), d.left = Math.max(d.left, m - C.width + 24)) : p - a.left + C.width > o && o - f.left > 12 && (d.left = Math.max(a.left, a.left + o - C.width), d.left = Math.max(d.left, m - C.width + 24))), "left" !== e && "right" !== e || (a.top > c && f.bottom > 12 ? (d.top = a.top, d.top = Math.max(d.top, b - C.height + f.height / 2)) : c - a.top + C.height > r && r - f.top > 12 && (d.top = Math.max(a.top, a.top + r - C.height), d.top = Math.max(d.top, b - C.height + f.height / 2))), "top" === e && a.top > c && (f.top < r - f.bottom ? (d.top = Math.min(b + w + (S || 0), a.top + r - C.height), s = !0) : d.top = a.top), "bottom" === e && c - a.top + C.height > r && (r - f.bottom < f.top ? (d.top = Math.max(b - C.height - (M || 0), a.top), s = !0) : d.top = a.top + r - C.height), "left" === e && a.left > p && (f.left < o - f.right ? (d.left = Math.min(x + m + T, a.left + o - C.width), s = !0) : d.left = a.left), "right" === e && p - a.left + C.width > o && (o - f.right < f.left ? (d.left = Math.max(m - C.width - E, a.left), s = !0) : d.left = a.left + o - C.width), d.left < 0) d.left = 0;
                                else {
                                    var v = i.scrollWidth - C.width;
                                    d.left = Math.min(v, d.left)
                                }
                                return s
                            }
                        },
                        k = P.horizontalOffset || 0,
                        R = P.verticalOffset || 0;
                    switch (t.position) {
                        case "top":
                            d.top = b - C.height - S, d.left = m + x / 2 - C.width / 2, A("top") && (D = "bottom"), d.left += k;
                            var _ = m - Number(d.left) + x / 2;
                            O.left = y(12, C.width - 12, _);
                            break;
                        case "tl":
                            d.top = b - C.height - S, d.left = m, A("top") && (D = "bl"), d.left += k;
                            var j = m - Number(d.left) + Math.min(x / 2, 50);
                            O.left = y(12, C.width - 12, j);
                            break;
                        case "tr":
                            d.top = -e.clientHeight + b - S, d.left = m + x - C.width, A("top") && (D = "br"), d.left += k, j = m - Number(d.left) + Math.max(x / 2, x - 50), O.left = y(12, C.width - 12, j);
                            break;
                        case "bottom":
                            d.top = w + b + M, d.left = m + x / 2 - C.width / 2, A("bottom") && (D = "top"), d.left += k;
                            var L = m - Number(d.left) + x / 2;
                            O.left = y(12, C.width - 12, L);
                            break;
                        case "bl":
                            d.top = w + b + M, d.left = m, A("bottom") && (D = "tl"), d.left += k, j = m - Number(d.left) + Math.min(x / 2, 50), O.left = y(12, C.width - 12, j);
                            break;
                        case "br":
                            d.top = w + b + M, d.left = m + x - C.width, A("bottom") && (D = "tr"), d.left += k, j = m - Number(d.left) + Math.max(x / 2, x - 50), O.left = y(12, C.width - 12, j);
                            break;
                        case "left":
                            d.top = b + w / 2 - C.height / 2, d.left = m - C.width - E, A("left") && (D = "right"), d.top += R;
                            var V = b - Number(d.top) + w / 2;
                            O.top = y(12, C.height - 12, V);
                            break;
                        case "lt":
                            d.top = b, d.left = m - C.width - E, A("left") && (D = "rt"), d.top += R;
                            var B = b - Number(d.top) + Math.min(w / 2, 50);
                            O.top = y(12, C.height - 12, B);
                            break;
                        case "lb":
                            d.top = b + w - C.height, d.left = m - C.width - E, A("left") && (D = "rb"), d.top += R, B = b - Number(d.top) + Math.max(w / 2, w - 50), O.top = y(12, C.height - 12, B);
                            break;
                        case "right":
                            d.top = b + w / 2 - C.height / 2, d.left = x + m + T, A("right") && (D = "left"), d.top += R;
                            var N = b - Number(d.top) + w / 2;
                            O.top = y(12, C.height - 12, N);
                            break;
                        case "rt":
                            d.top = b, d.left = x + m + T, A("right") && (D = "lt"), d.top += R, B = b - Number(d.top) + Math.min(w / 2, 50), O.top = y(12, C.height - 12, B);
                            break;
                        case "rb":
                            d.top = b + w - C.height, d.left = x + m + T, A("right") && (D = "lb"), d.top += R, B = b - Number(d.top) + Math.max(w / 2, w - 50), O.top = y(12, C.height - 12, B)
                    }
                    return {
                        style: d,
                        arrowStyle: O,
                        realPosition: D
                    }
                },
                x = n(43261),
                w = function(t, e) {
                    var n = "function" == typeof Symbol && t[Symbol.iterator];
                    if (!n) return t;
                    var i, r, o = n.call(t),
                        s = [];
                    try {
                        for (;
                            (void 0 === e || e-- > 0) && !(i = o.next()).done;) s.push(i.value)
                    } catch (t) {
                        r = {
                            error: t
                        }
                    } finally {
                        try {
                            i && !i.done && (n = o.return) && n.call(o)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return s
                },
                P = function(t, e, n) {
                    if (n || 2 === arguments.length)
                        for (var i, r = 0, o = e.length; r < o; r++) !i && r in e || (i || (i = Array.prototype.slice.call(e, 0, r)), i[r] = e[r]);
                    return t.concat(i || Array.prototype.slice.call(e))
                };

            function E(t) {
                var e = null,
                    n = function() {
                        for (var n = [], i = 0; i < arguments.length; i++) n[i] = arguments[i];
                        e && (0, x.N)(e), e = (0, x.W)((function() {
                            t.apply(void 0, P([], w(n), !1)), e = null
                        }))
                    };
                return n.cancel = function() {
                    (0, x.N)(e), e = null
                }, n
            }
            var T, S = (T = function(t, e) {
                    return T = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n])
                    }, T(t, e)
                }, function(t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");

                    function n() {
                        this.constructor = t
                    }
                    T(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
                }),
                M = function() {
                    return M = Object.assign || function(t) {
                        for (var e, n = 1, i = arguments.length; n < i; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }, M.apply(this, arguments)
                };

            function C(t, e) {
                if (!t) return {};
                var n = g(t, e);
                return {
                    width: n.width,
                    height: n.height,
                    left: n.left,
                    right: n.right
                }
            }
            var D = ["onClick", "onMouseEnter", "onMouseLeave", "onMouseMove", "onFocus", "onBlur", "onContextMenu", "onKeyDown"];
            var O = {
                    blurToHide: !0,
                    classNames: "fadeIn",
                    trigger: "hover",
                    position: "bottom",
                    duration: 200,
                    unmountOnExit: !0,
                    popupAlign: {},
                    popupHoverStay: !0,
                    clickOutsideToClose: !0,
                    escToClose: !1,
                    mouseLeaveToClose: !0,
                    containerScrollToClose: !1,
                    getDocument: function() {
                        return window.document
                    },
                    autoFixPosition: !0,
                    mouseEnterDelay: 100,
                    mouseLeaveDelay: 100,
                    autoFitPosition: !0
                },
                A = function(t) {
                    function e(e, n) {
                        var o = t.call(this, e, n) || this;
                        o.delayTimer = null, o.updatePositionTimer = null, o.popupOpen = !1, o.mousedownToHide = !1, o.hasPopupMouseDown = !1, o.unmount = !1, o.isDidMount = !1, o.mouseLocation = {
                            clientX: 0,
                            clientY: 0
                        }, o.observerContainer = null, o.scrollElements = null, o.resizeObserver = new s.Z((function() {
                            o.handleUpdatePosition()
                        })), o.childrenDom = null, o.childrenDomSize = {}, o.getMergedProps = function(t) {
                            var e = o.context.componentConfig,
                                n = function(t, e, n, i) {
                                    var r = e || {},
                                        o = n || {},
                                        s = t || {},
                                        a = i ? new Set(i) : new Set(Object.keys(s).concat(Object.keys(r)).concat(Object.keys(o))),
                                        u = {};
                                    return a.forEach((function(t) {
                                        void 0 !== s[t] ? u[t] = s[t] : t in o ? u[t] = o[t] : t in r && (u[t] = r[t])
                                    })), u
                                }(t && (0, u.Kn)(t) ? t : o.props, O, null == e ? void 0 : e.Trigger, t && (0, u.kJ)(t) ? t : void 0);
                            return n
                        }, o.getRootElement = function() {
                            return o.childrenDom = (0, r.findDOMNode)(o), o.childrenDom
                        }, o.offScrollListeners = function() {
                            (o.scrollElements || []).forEach((function(t) {
                                (0, a.S1)(t, "scroll", o.handleScroll)
                            })), o.scrollElements = null
                        }, o.offWindowResize = function() {
                            o.handleWindowResize = !1, (0, a.S1)(window, "resize", o.handleUpdatePosition)
                        }, o.offContainerResize = function() {
                            o.resizeObserver && o.observerContainer && (o.resizeObserver.unobserve(o.observerContainer), o.observerContainer = null)
                        }, o.handleScroll = function() {
                            var t = o.getMergedProps(["containerScrollToClose", "updateOnScroll"]);
                            t.containerScrollToClose ? o.setPopupVisible(!1) : t.updateOnScroll && o.handleUpdatePosition()
                        }, o.onContainersScroll = function(t) {
                            var e, n;
                            o.scrollElements || (o.scrollElements = (0, a.IF)(o.childrenDom, null === (e = o.popupContainer) || void 0 === e ? void 0 : e.parentNode), t.containerScrollToClose && (null === (n = o.popupContainer) || void 0 === n ? void 0 : n.parentNode) === document.body && -1 === o.scrollElements.indexOf(document.body) && (0, a.Ib)(document.documentElement) && o.scrollElements.push(window), o.scrollElements.forEach((function(t) {
                                (0, a.on)(t, "scroll", o.handleScroll)
                            })))
                        }, o.onContainerResize = function() {
                            var t, e = null === (t = o.popupContainer) || void 0 === t ? void 0 : t.parentNode;
                            o.resizeObserver && o.observerContainer !== e && (o.offContainerResize(), e && o.resizeObserver.observe(e), o.observerContainer = e)
                        }, o.handleUpdatePosition = E((function() {
                            o.updatePopupPosition()
                        })), o.isClickTrigger = function() {
                            var t = o.getMergedProps(["trigger"]).trigger;
                            return [].concat(t).indexOf("click") > -1
                        }, o.isFocusTrigger = function() {
                            var t = o.getMergedProps(["trigger"]).trigger;
                            return [].concat(t).indexOf("focus") > -1
                        }, o.isHoverTrigger = function() {
                            var t = o.getMergedProps(["trigger"]).trigger;
                            return [].concat(t).indexOf("hover") > -1
                        }, o.isContextMenuTrigger = function() {
                            var t = o.getMergedProps(["trigger"]).trigger;
                            return [].concat(t).indexOf("contextMenu") > -1
                        }, o.isMouseLeaveToClose = function() {
                            return o.isHoverTrigger() && o.getMergedProps(["mouseLeaveToClose"]).mouseLeaveToClose
                        }, o.isPopupHoverHide = function() {
                            return o.isHoverTrigger() && !o.getMergedProps(["popupHoverStay"]).popupHoverStay
                        }, o.isClickToHide = function() {
                            if (o.isClickTrigger() || o.isContextMenuTrigger()) {
                                var t = o.getMergedProps(["clickToClose"]).clickToClose;
                                return void 0 === t || t
                            }
                            return o.isHoverTrigger() && o.props.clickToClose
                        }, o.isBlurToHide = function() {
                            return o.isFocusTrigger() && o.getMergedProps(["blurToHide"]).blurToHide
                        }, o.clearTimer = function() {
                            o.updatePositionTimer && (o.updatePositionTimer.cancel ? o.updatePositionTimer.cancel() : (clearTimeout(o.updatePositionTimer), o.updatePositionTimer = null)), o.delayTimer && (clearTimeout(o.delayTimer), o.delayTimer = null), o.mouseDownTimeout && (clearTimeout(o.mouseDownTimeout), o.mouseDownTimeout = null)
                        }, o.offClickOutside = function() {
                            if (o.handleClickOutside) {
                                var t = o.getMergedProps(["getDocument"]).getDocument,
                                    e = (0, u.mf)(t) && t();
                                (0, a.S1)(e, "mousedown", o.onClickOutside), o.handleClickOutside = !1
                            }
                        }, o.getTransformOrigin = function(t) {
                            var e, n, i = o.triggerRef;
                            if (!i) return {};
                            var r = o.getMergedProps(["showArrow", "classNames"]),
                                s = r.showArrow,
                                a = r.classNames,
                                u = s && (null === (e = o.arrowStyle) || void 0 === e ? void 0 : e.top) || 0,
                                c = s && (null === (n = o.arrowStyle) || void 0 === n ? void 0 : n.left) || 0;
                            u = u ? u + "px" : "";
                            var l = {
                                top: ((c = c ? c + "px" : "") || "50%") + " 100% 0",
                                tl: (c || "15px") + " 100% 0",
                                tr: (c || i.clientWidth - 15 + "px") + " 100% 0",
                                bottom: (c || "50%") + " 0 0",
                                bl: (c || "15px") + " 0 0",
                                br: (c || i.clientWidth - 15 + "px") + " 0 0",
                                left: "100% " + (u || "50%") + " 0",
                                lt: "100% " + (u || "15px") + " 0",
                                lb: "100% " + (u || i.clientHeight - 15 + "px") + " 0",
                                right: "0 " + (u || "50%") + " 0",
                                rt: "0 " + (u || "15px") + " 0",
                                rb: "0 " + (u || i.clientHeight - 15 + "px") + " 0"
                            };
                            if (a && a.indexOf("zoom") > -1) return {
                                transformOrigin: l[t]
                            };
                            if ("slideDynamicOrigin" === a) {
                                var d = "0% 0%";
                                return ["top", "tl", "tr"].indexOf(t) > -1 && (d = "100% 100%"), {
                                    transformOrigin: d
                                }
                            }
                            return {}
                        }, o.getTransformTranslate = function() {
                            if ("slideDynamicOrigin" !== o.getMergedProps(["classNames"]).classNames) return "";
                            switch (o.realPosition) {
                                case "bottom":
                                case "bl":
                                case "br":
                                    return "scaleY(0.9) translateY(-4px)";
                                case "top":
                                case "tl":
                                case "tr":
                                    return "scaleY(0.9) translateY(4px)";
                                default:
                                    return ""
                            }
                        }, o.getPopupStyle = function() {
                            if (!o.unmount && o.popupContainer) {
                                var t = o.popupContainer,
                                    e = o.triggerRef,
                                    n = o.getRootElement();
                                if (!n.offsetParent && !n.getClientRects().length) return o.state.popupStyle;
                                var i = o.getMergedProps(),
                                    r = b(i, e, n, t, o.mouseLocation),
                                    s = r.style,
                                    a = r.arrowStyle,
                                    u = r.realPosition;
                                return o.realPosition = u || i.position, o.arrowStyle = a || {}, M(M({}, s), o.getTransformOrigin(o.realPosition))
                            }
                        }, o.showPopup = function(t) {
                            void 0 === t && (t = function() {});
                            var e = o.getPopupStyle();
                            o.setState({
                                popupStyle: e
                            }, t)
                        }, o.update = E((function(t) {
                            if (!o.unmount && o.state.popupVisible) {
                                var e = o.getPopupStyle();
                                o.setState({
                                    popupStyle: e
                                }, (function() {
                                    null == t || t()
                                }))
                            }
                        })), o.updatePopupPosition = function(t, e) {
                            void 0 === t && (t = 0), o.state.popupVisible && (o.updatePositionTimer = t < 4 ? o.update(e) : setTimeout((function() {
                                var t = o.getPopupStyle();
                                o.setState({
                                    popupStyle: t
                                }, (function() {
                                    null == e || e()
                                }))
                            }), t))
                        }, o.setPopupVisible = function(t, e, n) {
                            void 0 === e && (e = 0);
                            var i = o.getMergedProps(["onVisibleChange", "popupVisible"]),
                                r = i.onVisibleChange,
                                s = o.state.popupVisible;
                            t !== s ? o.delayToDo(e, (function() {
                                r && r(t), "popupVisible" in i ? null == n || n() : t ? o.setState({
                                    popupVisible: !0
                                }, (function() {
                                    o.showPopup(n)
                                })) : o.setState({
                                    popupVisible: !1
                                }, (function() {
                                    null == n || n()
                                }))
                            })) : null == n || n()
                        }, o.delayToDo = function(t, e) {
                            t ? (o.clearDelayTimer(), o.delayTimer = setTimeout((function() {
                                e(), o.clearDelayTimer()
                            }), t)) : e()
                        }, o.onClickOutside = function(t) {
                            var e = o.getMergedProps(["onClickOutside", "clickOutsideToClose"]),
                                n = e.onClickOutside,
                                i = e.clickOutsideToClose,
                                r = o.triggerRef,
                                s = o.getRootElement();
                            (0, a.r3)(r, t.target) || (0, a.r3)(s, t.target) || o.hasPopupMouseDown || (null == n || n(), i && (o.isBlurToHide() || o.isHoverTrigger() || o.setPopupVisible(!1)))
                        }, o.onKeyDown = function(t) {
                            var e = t.keyCode || t.which;
                            o.triggerPropsEvent("onKeyDown", t), e === l.AV.code && o.onPressEsc(t)
                        }, o.onPressEsc = function(t) {
                            o.getMergedProps(["escToClose"]).escToClose && t && t.key === l.AV.key && o.state.popupVisible && o.setPopupVisible(!1)
                        }, o.onMouseEnter = function(t) {
                            var e = o.getMergedProps(["mouseEnterDelay"]).mouseEnterDelay;
                            o.triggerPropsEvent("onMouseEnter", t), o.clearDelayTimer(), o.setPopupVisible(!0, e || 0)
                        }, o.onMouseMove = function(t) {
                            o.triggerPropsEvent("onMouseMove", t), o.setMouseLocation(t), o.state.popupVisible && o.update()
                        }, o.onMouseLeave = function(t) {
                            var e = o.getMergedProps(["mouseLeaveDelay"]).mouseLeaveDelay;
                            o.clearDelayTimer(), o.triggerPropsEvent("onMouseLeave", t), o.isMouseLeaveToClose() && o.state.popupVisible && o.setPopupVisible(!1, e || 0)
                        }, o.onPopupMouseEnter = function() {
                            o.clearDelayTimer()
                        }, o.onPopupMouseLeave = function(t) {
                            o.onMouseLeave(t)
                        }, o.setMouseLocation = function(t) {
                            o.getMergedProps(["alignPoint"]).alignPoint && (o.mouseLocation = {
                                clientX: t.clientX,
                                clientY: t.clientY
                            })
                        }, o.onContextMenu = function(t) {
                            t.preventDefault(), o.triggerPropsEvent("onContextMenu", t), o.setMouseLocation(t), o.state.popupVisible ? o.getMergedProps(["alignPoint"]).alignPoint && o.update() : o.setPopupVisible(!0, 0)
                        }, o.clickToHidePopup = function(t) {
                            var e = o.state.popupVisible;
                            e && (o.mousedownToHide = !0), o.triggerPropsEvent("onClick", t), o.isClickToHide() && e && o.setPopupVisible(!e, 0)
                        }, o.onClick = function(t) {
                            var e = o.state.popupVisible;
                            e && (o.mousedownToHide = !0), o.triggerPropsEvent("onClick", t), o.setMouseLocation(t), !o.isClickToHide() && e || o.setPopupVisible(!e, 0)
                        }, o.onFocus = function(t) {
                            var e = o.getMergedProps(["focusDelay"]).focusDelay,
                                n = function() {
                                    o.triggerPropsEvent("onFocus", t)
                                };
                            o.clearDelayTimer(), o.mousedownToHide || (o.state.popupVisible ? null == n || n() : o.setPopupVisible(!0, e || 0, n)), o.mousedownToHide = !1
                        }, o.onBlur = function(t) {
                            o.setPopupVisible(!1, 200, (function() {
                                return o.triggerPropsEvent("onBlur", t)
                            }))
                        }, o.onResize = function() {
                            o.getMergedProps(["autoFixPosition"]).autoFixPosition && o.state.popupVisible && o.updatePopupPosition()
                        }, o.onPopupMouseDown = function() {
                            o.hasPopupMouseDown = !0, clearTimeout(o.mouseDownTimeout), o.mouseDownTimeout = setTimeout((function() {
                                o.hasPopupMouseDown = !1
                            }), 0)
                        }, o.getChild = function() {
                            var t, e = o.props.children,
                                n = e,
                                r = n && "string" != typeof n && n.type,
                                s = e;
                            if (["string", "number"].indexOf(typeof e) > -1 || i.Children.count(e) > 1) s = i.createElement("span", null, e);
                            else if (n && r && (!0 === r.__BYTE_BUTTON || !0 === r.__BYTE_CHECKBOX || !0 === r.__BYTE_SWITCH || !0 === r.__BYTE_RADIO || "button" === r) && n.props.disabled) {
                                var a = function(t, e) {
                                        var n = {},
                                            i = M({}, t);
                                        return e.forEach((function(e) {
                                            t && e in t && (n[e] = t[e], delete i[e])
                                        })), {
                                            picked: n,
                                            omitted: i
                                        }
                                    }(n.props.style, ["position", "left", "right", "top", "bottom", "float", "display", "zIndex"]),
                                    u = a.picked,
                                    c = a.omitted;
                                s = i.createElement("span", {
                                    className: null === (t = n.props) || void 0 === t ? void 0 : t.className,
                                    style: M(M({
                                        display: "inline-block"
                                    }, u), {
                                        cursor: "not-allowed"
                                    })
                                }, i.cloneElement(n, {
                                    style: M(M({}, c), {
                                        pointerEvents: "none"
                                    }),
                                    className: void 0
                                }))
                            }
                            return s || i.createElement("span", null)
                        }, o.appendToContainer = function(t) {
                            if ((0, x.N)(o.rafId), o.isDidMount) {
                                var e = o.context.getPopupContainer,
                                    n = (o.getMergedProps(["getPopupContainer"]).getPopupContainer || e)(o.getRootElement());
                                if (n) return void n.appendChild(t)
                            }
                            o.rafId = (0, x.W)((function() {
                                o.appendToContainer(t)
                            }))
                        }, o.getContainer = function() {
                            var t = document.createElement("div");
                            return t.style.width = "100%", t.style.position = "absolute", t.style.top = "0", t.style.left = "0", o.popupContainer = t, o.appendToContainer(t), t
                        }, o.triggerPropsEvent = function(t, e) {
                            var n = o.getChild(),
                                i = n && n.props && n.props[t],
                                r = o.getMergedProps([t])[t];
                            (0, u.mf)(i) && i(e), (0, u.mf)(r) && r(e)
                        }, o.triggerOriginEvent = function(t) {
                            var e = o.getChild(),
                                n = e && e.props && e.props[t],
                                i = o.getMergedProps([t])[t];
                            return (0, u.mf)(i) && (0, u.mf)(n) ? function(t) {
                                n(t), i(t)
                            } : n || i
                        };
                        var c = o.getMergedProps(e),
                            d = "popupVisible" in c ? c.popupVisible : c.defaultPopupVisible;
                        return o.popupOpen = !!d, o.state = {
                            popupVisible: !!d,
                            popupStyle: {}
                        }, o
                    }
                    return S(e, t), e.getDerivedStateFromProps = function(t, e) {
                        return "popupVisible" in t && t.popupVisible !== e.popupVisible ? {
                            popupVisible: t.popupVisible
                        } : null
                    }, e.prototype.componentDidMount = function() {
                        this.componentDidUpdate(this.getMergedProps()), this.isDidMount = !0, this.unmount = !1, this.childrenDom = this.getRootElement(), this.state.popupVisible && (this.childrenDomSize = C(this.childrenDom, {
                            boundaryDistance: this.props.alignPoint ? void 0 : this.props.boundaryDistance,
                            position: this.props.position
                        }))
                    }, e.prototype.componentDidUpdate = function(t) {
                        var e = this.getMergedProps(t),
                            n = this.getMergedProps();
                        !e.popupVisible && n.popupVisible && this.update();
                        var i = this.state.popupVisible;
                        this.popupOpen = i;
                        var r = n.getDocument;
                        if (!i) return this.offClickOutside(), this.offContainerResize(), this.offWindowResize(), void this.offScrollListeners();
                        var o = C(this.childrenDom, {
                            boundaryDistance: this.props.alignPoint ? {} : this.props.boundaryDistance,
                            position: this.props.position
                        });
                        if (JSON.stringify(o) !== JSON.stringify(this.childrenDomSize) && (this.updatePopupPosition(), this.childrenDomSize = o), this.onContainerResize(), (n.updateOnScroll || n.containerScrollToClose) && this.onContainersScroll(n), this.handleWindowResize || ((0, a.on)(window, "resize", this.handleUpdatePosition), this.handleWindowResize = !0), !this.handleClickOutside) {
                            var s = (0, u.mf)(r) && r();
                            s && ((0, a.on)(s, "mousedown", this.onClickOutside, {
                                capture: !!(0, u.Kn)(n.clickOutsideToClose) && n.clickOutsideToClose.capture
                            }), this.handleClickOutside = !0)
                        }
                    }, e.prototype.componentWillUnmount = function() {
                        this.unmount = !0, this.offClickOutside(), this.clearTimer(), this.offWindowResize(), this.offScrollListeners(), this.offContainerResize(), (0, x.N)(this.rafId)
                    }, e.prototype.clearDelayTimer = function() {
                        this.delayTimer && (clearTimeout(this.delayTimer), this.delayTimer = null)
                    }, e.prototype.render = function() {
                        var t, e, n, r, s = this,
                            a = this.getMergedProps(),
                            u = a.children,
                            l = a.style,
                            d = a.className,
                            m = a.arrowProps,
                            v = a.disabled,
                            g = a.popup,
                            y = a.classNames,
                            b = a.duration,
                            x = a.unmountOnExit,
                            w = a.alignPoint,
                            P = a.autoAlignPopupWidth,
                            E = a.position,
                            T = a.childrenPrefix,
                            S = a.showArrow,
                            C = a.popupStyle,
                            D = a.__onExit,
                            O = a.__onExited,
                            A = u || 0 === u,
                            k = this.context,
                            R = k.getPrefixCls,
                            _ = k.zIndex,
                            j = k.rtl,
                            L = this.state,
                            V = L.popupVisible,
                            B = L.popupStyle;
                        if (!g) return null;
                        var N = {},
                            F = {
                                onMouseDown: this.onPopupMouseDown
                            };
                        this.isHoverTrigger() && !v ? (N.onMouseEnter = this.onMouseEnter, N.onMouseLeave = this.onMouseLeave, this.isClickToHide() && (N.onClick = this.clickToHidePopup), w && (N.onMouseMove = this.onMouseMove), this.isPopupHoverHide() || (F.onMouseEnter = this.onPopupMouseEnter, F.onMouseLeave = this.onPopupMouseLeave)) : (N.onMouseEnter = this.triggerOriginEvent("onMouseEnter"), N.onMouseLeave = this.triggerOriginEvent("onMouseLeave")), this.isContextMenuTrigger() && !v ? (N.onContextMenu = this.onContextMenu, N.onClick = this.clickToHidePopup) : N.onContextMenu = this.triggerOriginEvent("onContextMenu"), this.isClickTrigger() && !v ? N.onClick = this.onClick : N.onClick = N.onClick || this.triggerOriginEvent("onClick"), this.isFocusTrigger() && !v ? (N.onFocus = this.onFocus, this.isBlurToHide() && (N.onBlur = this.onBlur)) : (N.onFocus = this.triggerOriginEvent("onFocus"), N.onBlur = this.triggerOriginEvent("onBlur")), N.onKeyDown = v ? this.triggerOriginEvent("onKeyDown") : this.onKeyDown;
                        var $ = this.getChild(),
                            I = i.Children.only(g());
                        $.props.className && (N.className = $.props.className), T && V && (N.className = N.className ? N.className + " " + T + "-open" : T + "-open"), this.isFocusTrigger() && (N.tabIndex = v ? -1 : 0);
                        var z = R("trigger"),
                            W = (0, p.Z)(z, T, z + "-position-" + E, ((t = {})[z + "-rtl"] = j, t), d),
                            U = A && i.createElement(f.Z, {
                                onResize: this.onResize
                            }, i.cloneElement($, M({}, N))),
                            H = i.createElement(o.Z, { in: !!V,
                                timeout: b,
                                classNames: y,
                                unmountOnExit: x,
                                appear: !0,
                                mountOnEnter: !0,
                                onEnter: function(t) {
                                    t.style.display = "initial", t.style.pointerEvents = "none", "slideDynamicOrigin" === y && (t.style.transform = s.getTransformTranslate())
                                },
                                onEntering: function(t) {
                                    "slideDynamicOrigin" === y && (t.style.transform = "")
                                },
                                onEntered: function(t) {
                                    t.style.pointerEvents = "auto", s.forceUpdate()
                                },
                                onExit: function(t) {
                                    t.style.pointerEvents = "none", null == D || D(t)
                                },
                                onExited: function(t) {
                                    t.style.display = "none", x && (s.triggerRef = null), s.setState({
                                        popupStyle: {}
                                    }), null == O || O(t)
                                }
                            }, i.createElement(f.Z, {
                                onResize: function() {
                                    var t = s.triggerRef;
                                    if (t) {
                                        var e = s.getPopupStyle(),
                                            n = s.props.style || {};
                                        t.style.top = String(n.top || e.top + "px"), t.style.left = String(n.left || e.left + "px")
                                    }
                                    s.onResize()
                                }
                            }, i.createElement("span", M({
                                ref: function(t) {
                                    return s.triggerRef = t
                                },
                                "trigger-placement": this.realPosition,
                                style: M(M(M({
                                    width: P && void 0 === (null == l ? void 0 : l.width) ? null === (r = this.childrenDomSize) || void 0 === r ? void 0 : r.width : ""
                                }, B), {
                                    position: "absolute",
                                    zIndex: _ || ""
                                }), l)
                            }, F, {
                                className: W
                            }, (0, c.m)(this.props)), i.createElement(I.type, M({
                                ref: I.ref
                            }, I.props, {
                                style: M(M({}, I.props.style), C)
                            })), (S || m) && i.createElement("div", {
                                className: (0, p.Z)(z + "-arrow-container", (e = {}, e[T + "-arrow-container"] = T, e))
                            }, i.createElement("div", M({}, m, {
                                className: (0, p.Z)(z + "-arrow", (n = {}, n[T + "-arrow"] = T, n), null == m ? void 0 : m.className),
                                style: M(M({}, this.arrowStyle), null == m ? void 0 : m.style)
                            })))))),
                            Y = V || this.triggerRef ? i.createElement(h, {
                                getContainer: this.getContainer
                            }, H) : null;
                        return A ? i.createElement(i.Fragment, null, U, Y) : Y
                    }, e.displayName = "Trigger", e.contextType = m.E, e
                }(i.PureComponent),
                k = A
        },
        50912: function(t, e, n) {
            "use strict";
            n(17670), n(53950)
        },
        93887: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return a
                }
            });
            var i = n(69309),
                r = n(61699),
                o = function(t, e) {
                    var n = "function" == typeof Symbol && t[Symbol.iterator];
                    if (!n) return t;
                    var i, r, o = n.call(t),
                        s = [];
                    try {
                        for (;
                            (void 0 === e || e-- > 0) && !(i = o.next()).done;) s.push(i.value)
                    } catch (t) {
                        r = {
                            error: t
                        }
                    } finally {
                        try {
                            i && !i.done && (n = o.return) && n.call(o)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return s
                },
                s = function(t, e, n) {
                    if (n || 2 === arguments.length)
                        for (var i, r = 0, o = e.length; r < o; r++) !i && r in e || (i || (i = Array.prototype.slice.call(e, 0, r)), i[r] = e[r]);
                    return t.concat(i || Array.prototype.slice.call(e))
                };

            function a() {
                for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                for (var n = t.length, a = [], u = function(e) {
                        var n = t[e];
                        if (!n) return "continue";
                        (0, i.HD)(n) ? a.push(n): (0, i.kJ)(n) ? a = a.concat(n) : (0, i.Kn)(n) ? Object.keys(n).forEach((function(t) {
                            n[t] && a.push(t)
                        })) : (0, r.Z)(!0, "arguments must be one of string/array/object.")
                    }, c = 0; c < n; c++) u(c);
                return s([], o(new Set(a)), !1).join(" ")
            }
        },
        76374: function(t, e, n) {
            "use strict";
            n.d(e, {
                Yy: function() {
                    return o
                },
                dG: function() {
                    return r
                }
            });
            var i = n(41591),
                r = function() {};

            function o(t) {
                return (0, i.Z)(t, ["onMouseEnter", "onMouseLeave", "onMouseMove", "onContextMenu", "onClick", "onFocus", "onBlur", "tabIndex"])
            }
        },
        94296: function(t, e, n) {
            "use strict";
            n.d(e, {
                ET: function() {
                    return r
                },
                IF: function() {
                    return c
                },
                Ib: function() {
                    return u
                },
                S1: function() {
                    return s
                },
                on: function() {
                    return o
                },
                r3: function() {
                    return a
                }
            });
            var i = n(76374),
                r = function() {
                    try {
                        return !("undefined" != typeof window && void 0 !== document)
                    } catch (t) {
                        return !0
                    }
                }(),
                o = r ? i.dG : function(t, e, n, i) {
                    t && t.addEventListener(e, n, i || !1)
                },
                s = r ? i.dG : function(t, e, n, i) {
                    t && t.removeEventListener(e, n, i || !1)
                },
                a = function(t, e) {
                    if (!t) return !1;
                    if (t.contains) return t.contains(e);
                    for (var n = e; n;) {
                        if (n === t) return !0;
                        n = n.parentNode
                    }
                    return !1
                },
                u = function(t) {
                    var e = t === document.documentElement ? t.clientHeight : t.offsetHeight,
                        n = t === document.documentElement ? t.clientWidth : t.offsetWidth;
                    return t.scrollHeight > e || t.scrollWidth > n
                },
                c = function(t, e) {
                    void 0 === e && (e = document.documentElement);
                    for (var n = [], i = t; i && i !== e;) u(i) && n.push(i), i = i.parentElement;
                    return n
                }
        },
        2945: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return r
                }
            });
            var i = n(84371);

            function r() {
                var t = (0, i.useRef)(!0);
                return (0, i.useEffect)((function() {
                    t.current = !1
                }), []), t.current
            }
        },
        64625: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return s
                }
            });
            var i = n(84371),
                r = n(11059),
                o = function() {
                    return o = Object.assign || function(t) {
                        for (var e, n = 1, i = arguments.length; n < i; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }, o.apply(this, arguments)
                };

            function s(t, e, n) {
                var s = t._ignorePropsFromGlobal,
                    a = (0, i.useMemo)((function() {
                        return o(o({}, e), s ? {} : n)
                    }), [e, n, s]);
                return (0, i.useMemo)((function() {
                    var e = (0, r.Z)(t, ["_ignorePropsFromGlobal"]);
                    for (var n in a) void 0 === e[n] && (e[n] = a[n]);
                    return e
                }), [t, a])
            }
        },
        69309: function(t, e, n) {
            "use strict";
            n.d(e, {
                HD: function() {
                    return s
                },
                Kn: function() {
                    return o
                },
                U$: function() {
                    return d
                },
                hj: function() {
                    return a
                },
                kJ: function() {
                    return r
                },
                le: function() {
                    return c
                },
                mf: function() {
                    return l
                },
                o8: function() {
                    return u
                }
            });
            var i = Object.prototype.toString;

            function r(t) {
                return "[object Array]" === i.call(t)
            }

            function o(t) {
                return "[object Object]" === i.call(t)
            }

            function s(t) {
                return "[object String]" === i.call(t)
            }

            function a(t) {
                return "[object Number]" === i.call(t) && t == t
            }

            function u(t) {
                return void 0 === t
            }

            function c(t) {
                return null == t
            }

            function l(t) {
                return "function" == typeof t
            }

            function d(t, e) {
                return null == t || !1 === t || "string" == typeof t && (e ? "" === t.trim() : "" === t)
            }
        },
        17466: function(t, e, n) {
            "use strict";
            n.d(e, {
                AV: function() {
                    return r
                },
                Ce: function() {
                    return i
                },
                K5: function() {
                    return u
                },
                OK: function() {
                    return s
                },
                Xd: function() {
                    return c
                },
                a2: function() {
                    return a
                },
                kW: function() {
                    return o
                },
                ol: function() {
                    return l
                }
            });
            var i = {
                    key: "Enter",
                    code: 13
                },
                r = {
                    key: "Escape",
                    code: 27
                },
                o = {
                    key: "Backspace",
                    code: 8
                },
                s = {
                    key: "Tab",
                    code: 9
                },
                a = {
                    key: "ArrowUp",
                    code: 38
                },
                u = {
                    key: "ArrowDown",
                    code: 40
                },
                c = {
                    key: "ArrowLeft",
                    code: 37
                },
                l = {
                    key: "ArrowRight",
                    code: 39
                }
        },
        11059: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return r
                }
            });
            var i = function() {
                return i = Object.assign || function(t) {
                    for (var e, n = 1, i = arguments.length; n < i; n++)
                        for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                    return t
                }, i.apply(this, arguments)
            };

            function r(t, e) {
                var n = i({}, t);
                return e.forEach((function(t) {
                    t in n && delete n[t]
                })), n
            }
        },
        41591: function(t, e, n) {
            "use strict";

            function i(t, e) {
                var n = {};
                return e.forEach((function(e) {
                    var i = e;
                    e in t && (n[i] = t[i])
                })), n
            }

            function r(t) {
                var e = {};
                return t && Object.keys(t).forEach((function(n) {
                    var i = String(n);
                    0 === i.indexOf("data-") && (e[i] = t[i]), 0 === i.indexOf("aria-") && (e[i] = t[i])
                })), e
            }
            n.d(e, {
                Z: function() {
                    return i
                },
                m: function() {
                    return r
                }
            })
        },
        43261: function(t, e, n) {
            "use strict";
            n.d(e, {
                N: function() {
                    return o
                },
                W: function() {
                    return r
                }
            });
            var i = "undefined" == typeof window ? n.g : window,
                r = i.requestAnimationFrame,
                o = i.cancelAnimationFrame;
            if (!(r && o || (["webkit", "ms", "moz", "o"].some((function(t) {
                    return r = i[t + "RequestAnimationFrame"], o = i[t + "CancelAnimationFrame"] || i[t + "CancelRequestAnimationFrame"], r && o
                })), r && o))) {
                var s = 0;
                r = function(t) {
                    var e = Date.now(),
                        n = Math.max(0, 16 - (e - s));
                    return setTimeout((function() {
                        t(), s = e + n
                    }), n)
                }, o = function(t) {
                    clearTimeout(t)
                }
            }
            r = r.bind(i), o = o.bind(i)
        },
        43819: function(t, e, n) {
            "use strict";
            var i, r = n(84371),
                o = n(69570),
                s = n(30731),
                a = n.n(s),
                u = n(29980),
                c = (i = function(t, e) {
                    return i = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n])
                    }, i(t, e)
                }, function(t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");

                    function n() {
                        this.constructor = t
                    }
                    i(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
                }),
                l = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.componentWillUnmount = function() {
                            e.resizeObserver && e.destroyResizeObserver()
                        }, e.createResizeObserver = function() {
                            var t = e.props.throttle,
                                n = function(t) {
                                    var n, i;
                                    null === (i = (n = e.props).onResize) || void 0 === i || i.call(n, t)
                                },
                                i = void 0 === t || t ? a()(n) : n,
                                r = !0;
                            e.resizeObserver = new o.Z((function(t) {
                                r && (r = !1, n(t)), i(t)
                            })), e.resizeObserver.observe((0, u.findDOMNode)(e))
                        }, e.destroyResizeObserver = function() {
                            e.resizeObserver && e.resizeObserver.disconnect(), e.resizeObserver = null
                        }, e
                    }
                    return c(e, t), e.prototype.componentDidMount = function() {
                        r.isValidElement(this.props.children) && this.createResizeObserver()
                    }, e.prototype.componentDidUpdate = function() {
                        !this.resizeObserver && (0, u.findDOMNode)(this) && this.createResizeObserver()
                    }, e.prototype.render = function() {
                        return this.props.children
                    }, e
                }(r.Component);
            e.Z = l
        },
        61699: function(t, e, n) {
            "use strict";

            function i(t, e) {
                0
            }
            n.d(e, {
                Z: function() {
                    return i
                }
            })
        },
        15844: function(t, e, n) {
            "use strict";
            n.d(e, {
                P: function() {
                    return i
                }
            });
            var i = (0, n(84371).createContext)({
                prefixCls: "arco"
            })
        },
        92296: function(t) {
            var e = {
                utf8: {
                    stringToBytes: function(t) {
                        return e.bin.stringToBytes(unescape(encodeURIComponent(t)))
                    },
                    bytesToString: function(t) {
                        return decodeURIComponent(escape(e.bin.bytesToString(t)))
                    }
                },
                bin: {
                    stringToBytes: function(t) {
                        for (var e = [], n = 0; n < t.length; n++) e.push(255 & t.charCodeAt(n));
                        return e
                    },
                    bytesToString: function(t) {
                        for (var e = [], n = 0; n < t.length; n++) e.push(String.fromCharCode(t[n]));
                        return e.join("")
                    }
                }
            };
            t.exports = e
        },
        10455: function(t) {
            var e, n;
            e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = {
                rotl: function(t, e) {
                    return t << e | t >>> 32 - e
                },
                rotr: function(t, e) {
                    return t << 32 - e | t >>> e
                },
                endian: function(t) {
                    if (t.constructor == Number) return 16711935 & n.rotl(t, 8) | 4278255360 & n.rotl(t, 24);
                    for (var e = 0; e < t.length; e++) t[e] = n.endian(t[e]);
                    return t
                },
                randomBytes: function(t) {
                    for (var e = []; t > 0; t--) e.push(Math.floor(256 * Math.random()));
                    return e
                },
                bytesToWords: function(t) {
                    for (var e = [], n = 0, i = 0; n < t.length; n++, i += 8) e[i >>> 5] |= t[n] << 24 - i % 32;
                    return e
                },
                wordsToBytes: function(t) {
                    for (var e = [], n = 0; n < 32 * t.length; n += 8) e.push(t[n >>> 5] >>> 24 - n % 32 & 255);
                    return e
                },
                bytesToHex: function(t) {
                    for (var e = [], n = 0; n < t.length; n++) e.push((t[n] >>> 4).toString(16)), e.push((15 & t[n]).toString(16));
                    return e.join("")
                },
                hexToBytes: function(t) {
                    for (var e = [], n = 0; n < t.length; n += 2) e.push(parseInt(t.substr(n, 2), 16));
                    return e
                },
                bytesToBase64: function(t) {
                    for (var n = [], i = 0; i < t.length; i += 3)
                        for (var r = t[i] << 16 | t[i + 1] << 8 | t[i + 2], o = 0; o < 4; o++) 8 * i + 6 * o <= 8 * t.length ? n.push(e.charAt(r >>> 6 * (3 - o) & 63)) : n.push("=");
                    return n.join("")
                },
                base64ToBytes: function(t) {
                    t = t.replace(/[^A-Z0-9+\/]/gi, "");
                    for (var n = [], i = 0, r = 0; i < t.length; r = ++i % 4) 0 != r && n.push((e.indexOf(t.charAt(i - 1)) & Math.pow(2, -2 * r + 8) - 1) << 2 * r | e.indexOf(t.charAt(i)) >>> 6 - 2 * r);
                    return n
                }
            }, t.exports = n
        },
        44010: function(t) {
            t.exports = function() {
                "use strict";
                var t = 1e3,
                    e = 6e4,
                    n = 36e5,
                    i = "millisecond",
                    r = "second",
                    o = "minute",
                    s = "hour",
                    a = "day",
                    u = "week",
                    c = "month",
                    l = "quarter",
                    d = "year",
                    h = "date",
                    f = "Invalid Date",
                    p = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
                    m = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
                    v = {
                        name: "en",
                        weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                        months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
                        ordinal: function(t) {
                            var e = ["th", "st", "nd", "rd"],
                                n = t % 100;
                            return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]"
                        }
                    },
                    g = function(t, e, n) {
                        var i = String(t);
                        return !i || i.length >= e ? t : "" + Array(e + 1 - i.length).join(n) + t
                    },
                    y = {
                        s: g,
                        z: function(t) {
                            var e = -t.utcOffset(),
                                n = Math.abs(e),
                                i = Math.floor(n / 60),
                                r = n % 60;
                            return (e <= 0 ? "+" : "-") + g(i, 2, "0") + ":" + g(r, 2, "0")
                        },
                        m: function t(e, n) {
                            if (e.date() < n.date()) return -t(n, e);
                            var i = 12 * (n.year() - e.year()) + (n.month() - e.month()),
                                r = e.clone().add(i, c),
                                o = n - r < 0,
                                s = e.clone().add(i + (o ? -1 : 1), c);
                            return +(-(i + (n - r) / (o ? r - s : s - r)) || 0)
                        },
                        a: function(t) {
                            return t < 0 ? Math.ceil(t) || 0 : Math.floor(t)
                        },
                        p: function(t) {
                            return {
                                M: c,
                                y: d,
                                w: u,
                                d: a,
                                D: h,
                                h: s,
                                m: o,
                                s: r,
                                ms: i,
                                Q: l
                            }[t] || String(t || "").toLowerCase().replace(/s$/, "")
                        },
                        u: function(t) {
                            return void 0 === t
                        }
                    },
                    b = "en",
                    x = {};
                x[b] = v;
                var w = "$isDayjsObject",
                    P = function(t) {
                        return t instanceof M || !(!t || !t[w])
                    },
                    E = function t(e, n, i) {
                        var r;
                        if (!e) return b;
                        if ("string" == typeof e) {
                            var o = e.toLowerCase();
                            x[o] && (r = o), n && (x[o] = n, r = o);
                            var s = e.split("-");
                            if (!r && s.length > 1) return t(s[0])
                        } else {
                            var a = e.name;
                            x[a] = e, r = a
                        }
                        return !i && r && (b = r), r || !i && b
                    },
                    T = function(t, e) {
                        if (P(t)) return t.clone();
                        var n = "object" == typeof e ? e : {};
                        return n.date = t, n.args = arguments, new M(n)
                    },
                    S = y;
                S.l = E, S.i = P, S.w = function(t, e) {
                    return T(t, {
                        locale: e.$L,
                        utc: e.$u,
                        x: e.$x,
                        $offset: e.$offset
                    })
                };
                var M = function() {
                        function v(t) {
                            this.$L = E(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[w] = !0
                        }
                        var g = v.prototype;
                        return g.parse = function(t) {
                            this.$d = function(t) {
                                var e = t.date,
                                    n = t.utc;
                                if (null === e) return new Date(NaN);
                                if (S.u(e)) return new Date;
                                if (e instanceof Date) return new Date(e);
                                if ("string" == typeof e && !/Z$/i.test(e)) {
                                    var i = e.match(p);
                                    if (i) {
                                        var r = i[2] - 1 || 0,
                                            o = (i[7] || "0").substring(0, 3);
                                        return n ? new Date(Date.UTC(i[1], r, i[3] || 1, i[4] || 0, i[5] || 0, i[6] || 0, o)) : new Date(i[1], r, i[3] || 1, i[4] || 0, i[5] || 0, i[6] || 0, o)
                                    }
                                }
                                return new Date(e)
                            }(t), this.init()
                        }, g.init = function() {
                            var t = this.$d;
                            this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds()
                        }, g.$utils = function() {
                            return S
                        }, g.isValid = function() {
                            return !(this.$d.toString() === f)
                        }, g.isSame = function(t, e) {
                            var n = T(t);
                            return this.startOf(e) <= n && n <= this.endOf(e)
                        }, g.isAfter = function(t, e) {
                            return T(t) < this.startOf(e)
                        }, g.isBefore = function(t, e) {
                            return this.endOf(e) < T(t)
                        }, g.$g = function(t, e, n) {
                            return S.u(t) ? this[e] : this.set(n, t)
                        }, g.unix = function() {
                            return Math.floor(this.valueOf() / 1e3)
                        }, g.valueOf = function() {
                            return this.$d.getTime()
                        }, g.startOf = function(t, e) {
                            var n = this,
                                i = !!S.u(e) || e,
                                l = S.p(t),
                                f = function(t, e) {
                                    var r = S.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
                                    return i ? r : r.endOf(a)
                                },
                                p = function(t, e) {
                                    return S.w(n.toDate()[t].apply(n.toDate("s"), (i ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e)), n)
                                },
                                m = this.$W,
                                v = this.$M,
                                g = this.$D,
                                y = "set" + (this.$u ? "UTC" : "");
                            switch (l) {
                                case d:
                                    return i ? f(1, 0) : f(31, 11);
                                case c:
                                    return i ? f(1, v) : f(0, v + 1);
                                case u:
                                    var b = this.$locale().weekStart || 0,
                                        x = (m < b ? m + 7 : m) - b;
                                    return f(i ? g - x : g + (6 - x), v);
                                case a:
                                case h:
                                    return p(y + "Hours", 0);
                                case s:
                                    return p(y + "Minutes", 1);
                                case o:
                                    return p(y + "Seconds", 2);
                                case r:
                                    return p(y + "Milliseconds", 3);
                                default:
                                    return this.clone()
                            }
                        }, g.endOf = function(t) {
                            return this.startOf(t, !1)
                        }, g.$set = function(t, e) {
                            var n, u = S.p(t),
                                l = "set" + (this.$u ? "UTC" : ""),
                                f = (n = {}, n[a] = l + "Date", n[h] = l + "Date", n[c] = l + "Month", n[d] = l + "FullYear", n[s] = l + "Hours", n[o] = l + "Minutes", n[r] = l + "Seconds", n[i] = l + "Milliseconds", n)[u],
                                p = u === a ? this.$D + (e - this.$W) : e;
                            if (u === c || u === d) {
                                var m = this.clone().set(h, 1);
                                m.$d[f](p), m.init(), this.$d = m.set(h, Math.min(this.$D, m.daysInMonth())).$d
                            } else f && this.$d[f](p);
                            return this.init(), this
                        }, g.set = function(t, e) {
                            return this.clone().$set(t, e)
                        }, g.get = function(t) {
                            return this[S.p(t)]()
                        }, g.add = function(i, l) {
                            var h, f = this;
                            i = Number(i);
                            var p = S.p(l),
                                m = function(t) {
                                    var e = T(f);
                                    return S.w(e.date(e.date() + Math.round(t * i)), f)
                                };
                            if (p === c) return this.set(c, this.$M + i);
                            if (p === d) return this.set(d, this.$y + i);
                            if (p === a) return m(1);
                            if (p === u) return m(7);
                            var v = (h = {}, h[o] = e, h[s] = n, h[r] = t, h)[p] || 1,
                                g = this.$d.getTime() + i * v;
                            return S.w(g, this)
                        }, g.subtract = function(t, e) {
                            return this.add(-1 * t, e)
                        }, g.format = function(t) {
                            var e = this,
                                n = this.$locale();
                            if (!this.isValid()) return n.invalidDate || f;
                            var i = t || "YYYY-MM-DDTHH:mm:ssZ",
                                r = S.z(this),
                                o = this.$H,
                                s = this.$m,
                                a = this.$M,
                                u = n.weekdays,
                                c = n.months,
                                l = n.meridiem,
                                d = function(t, n, r, o) {
                                    return t && (t[n] || t(e, i)) || r[n].slice(0, o)
                                },
                                h = function(t) {
                                    return S.s(o % 12 || 12, t, "0")
                                },
                                p = l || function(t, e, n) {
                                    var i = t < 12 ? "AM" : "PM";
                                    return n ? i.toLowerCase() : i
                                };
                            return i.replace(m, (function(t, i) {
                                return i || function(t) {
                                    switch (t) {
                                        case "YY":
                                            return String(e.$y).slice(-2);
                                        case "YYYY":
                                            return S.s(e.$y, 4, "0");
                                        case "M":
                                            return a + 1;
                                        case "MM":
                                            return S.s(a + 1, 2, "0");
                                        case "MMM":
                                            return d(n.monthsShort, a, c, 3);
                                        case "MMMM":
                                            return d(c, a);
                                        case "D":
                                            return e.$D;
                                        case "DD":
                                            return S.s(e.$D, 2, "0");
                                        case "d":
                                            return String(e.$W);
                                        case "dd":
                                            return d(n.weekdaysMin, e.$W, u, 2);
                                        case "ddd":
                                            return d(n.weekdaysShort, e.$W, u, 3);
                                        case "dddd":
                                            return u[e.$W];
                                        case "H":
                                            return String(o);
                                        case "HH":
                                            return S.s(o, 2, "0");
                                        case "h":
                                            return h(1);
                                        case "hh":
                                            return h(2);
                                        case "a":
                                            return p(o, s, !0);
                                        case "A":
                                            return p(o, s, !1);
                                        case "m":
                                            return String(s);
                                        case "mm":
                                            return S.s(s, 2, "0");
                                        case "s":
                                            return String(e.$s);
                                        case "ss":
                                            return S.s(e.$s, 2, "0");
                                        case "SSS":
                                            return S.s(e.$ms, 3, "0");
                                        case "Z":
                                            return r
                                    }
                                    return null
                                }(t) || r.replace(":", "")
                            }))
                        }, g.utcOffset = function() {
                            return 15 * -Math.round(this.$d.getTimezoneOffset() / 15)
                        }, g.diff = function(i, h, f) {
                            var p, m = this,
                                v = S.p(h),
                                g = T(i),
                                y = (g.utcOffset() - this.utcOffset()) * e,
                                b = this - g,
                                x = function() {
                                    return S.m(m, g)
                                };
                            switch (v) {
                                case d:
                                    p = x() / 12;
                                    break;
                                case c:
                                    p = x();
                                    break;
                                case l:
                                    p = x() / 3;
                                    break;
                                case u:
                                    p = (b - y) / 6048e5;
                                    break;
                                case a:
                                    p = (b - y) / 864e5;
                                    break;
                                case s:
                                    p = b / n;
                                    break;
                                case o:
                                    p = b / e;
                                    break;
                                case r:
                                    p = b / t;
                                    break;
                                default:
                                    p = b
                            }
                            return f ? p : S.a(p)
                        }, g.daysInMonth = function() {
                            return this.endOf(c).$D
                        }, g.$locale = function() {
                            return x[this.$L]
                        }, g.locale = function(t, e) {
                            if (!t) return this.$L;
                            var n = this.clone(),
                                i = E(t, e, !0);
                            return i && (n.$L = i), n
                        }, g.clone = function() {
                            return S.w(this.$d, this)
                        }, g.toDate = function() {
                            return new Date(this.valueOf())
                        }, g.toJSON = function() {
                            return this.isValid() ? this.toISOString() : null
                        }, g.toISOString = function() {
                            return this.$d.toISOString()
                        }, g.toString = function() {
                            return this.$d.toUTCString()
                        }, v
                    }(),
                    C = M.prototype;
                return T.prototype = C, [
                    ["$ms", i],
                    ["$s", r],
                    ["$m", o],
                    ["$H", s],
                    ["$W", a],
                    ["$M", c],
                    ["$y", d],
                    ["$D", h]
                ].forEach((function(t) {
                    C[t[1]] = function(e) {
                        return this.$g(e, t[0], t[1])
                    }
                })), T.extend = function(t, e) {
                    return t.$i || (t(e, M, T), t.$i = !0), T
                }, T.locale = E, T.isDayjs = P, T.unix = function(t) {
                    return T(1e3 * t)
                }, T.en = x[b], T.Ls = x, T.p = {}, T
            }()
        },
        99752: function(t, e, n) {
            t.exports = function(t) {
                "use strict";

                function e(t) {
                    return t && "object" == typeof t && "default" in t ? t : {
                        default: t
                    }
                }
                var n = e(t),
                    i = {
                        name: "zh-cn",
                        weekdays: "星期日_星期一_星期二_星期三_星期四_星期五_星期六".split("_"),
                        weekdaysShort: "周日_周一_周二_周三_周四_周五_周六".split("_"),
                        weekdaysMin: "日_一_二_三_四_五_六".split("_"),
                        months: "一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月".split("_"),
                        monthsShort: "1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_"),
                        ordinal: function(t, e) {
                            return "W" === e ? t + "周" : t + "日"
                        },
                        weekStart: 1,
                        yearStart: 4,
                        formats: {
                            LT: "HH:mm",
                            LTS: "HH:mm:ss",
                            L: "YYYY/MM/DD",
                            LL: "YYYY年M月D日",
                            LLL: "YYYY年M月D日Ah点mm分",
                            LLLL: "YYYY年M月D日ddddAh点mm分",
                            l: "YYYY/M/D",
                            ll: "YYYY年M月D日",
                            lll: "YYYY年M月D日 HH:mm",
                            llll: "YYYY年M月D日dddd HH:mm"
                        },
                        relativeTime: {
                            future: "%s内",
                            past: "%s前",
                            s: "几秒",
                            m: "1 分钟",
                            mm: "%d 分钟",
                            h: "1 小时",
                            hh: "%d 小时",
                            d: "1 天",
                            dd: "%d 天",
                            M: "1 个月",
                            MM: "%d 个月",
                            y: "1 年",
                            yy: "%d 年"
                        },
                        meridiem: function(t, e) {
                            var n = 100 * t + e;
                            return n < 600 ? "凌晨" : n < 900 ? "早上" : n < 1100 ? "上午" : n < 1300 ? "中午" : n < 1800 ? "下午" : "晚上"
                        }
                    };
                return n.default.locale(i, null, !0), i
            }(n(44010))
        },
        44494: function(t) {
            function e(t) {
                return !!t.constructor && "function" == typeof t.constructor.isBuffer && t.constructor.isBuffer(t)
            }
            t.exports = function(t) {
                return null != t && (e(t) || function(t) {
                    return "function" == typeof t.readFloatLE && "function" == typeof t.slice && e(t.slice(0, 0))
                }(t) || !!t._isBuffer)
            }
        },
        7083: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return b
                }
            });
            var i = /iPhone/i,
                r = /iPod/i,
                o = /iPad/i,
                s = /\biOS-universal(?:.+)Mac\b/i,
                a = /\bAndroid(?:.+)Mobile\b/i,
                u = /Android/i,
                c = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i,
                l = /Silk/i,
                d = /Windows Phone/i,
                h = /\bWindows(?:.+)ARM\b/i,
                f = /BlackBerry/i,
                p = /BB10/i,
                m = /Opera Mini/i,
                v = /\b(CriOS|Chrome)(?:.+)Mobile/i,
                g = /Mobile(?:.+)Firefox\b/i,
                y = function(t) {
                    return void 0 !== t && "MacIntel" === t.platform && "number" == typeof t.maxTouchPoints && t.maxTouchPoints > 1 && "undefined" == typeof MSStream
                };

            function b(t) {
                var e = {
                    userAgent: "",
                    platform: "",
                    maxTouchPoints: 0
                };
                t || "undefined" == typeof navigator ? "string" == typeof t ? e.userAgent = t : t && t.userAgent && (e = {
                    userAgent: t.userAgent,
                    platform: t.platform,
                    maxTouchPoints: t.maxTouchPoints || 0
                }) : e = {
                    userAgent: navigator.userAgent,
                    platform: navigator.platform,
                    maxTouchPoints: navigator.maxTouchPoints || 0
                };
                var n = e.userAgent,
                    b = n.split("[FBAN");
                void 0 !== b[1] && (n = b[0]), void 0 !== (b = n.split("Twitter"))[1] && (n = b[0]);
                var x = function(t) {
                        return function(e) {
                            return e.test(t)
                        }
                    }(n),
                    w = {
                        apple: {
                            phone: x(i) && !x(d),
                            ipod: x(r),
                            tablet: !x(i) && (x(o) || y(e)) && !x(d),
                            universal: x(s),
                            device: (x(i) || x(r) || x(o) || x(s) || y(e)) && !x(d)
                        },
                        amazon: {
                            phone: x(c),
                            tablet: !x(c) && x(l),
                            device: x(c) || x(l)
                        },
                        android: {
                            phone: !x(d) && x(c) || !x(d) && x(a),
                            tablet: !x(d) && !x(c) && !x(a) && (x(l) || x(u)),
                            device: !x(d) && (x(c) || x(l) || x(a) || x(u)) || x(/\bokhttp\b/i)
                        },
                        windows: {
                            phone: x(d),
                            tablet: x(h),
                            device: x(d) || x(h)
                        },
                        other: {
                            blackberry: x(f),
                            blackberry10: x(p),
                            opera: x(m),
                            firefox: x(g),
                            chrome: x(v),
                            device: x(f) || x(p) || x(m) || x(g) || x(v)
                        },
                        any: !1,
                        phone: !1,
                        tablet: !1
                    };
                return w.any = w.apple.device || w.android.device || w.windows.device || w.other.device, w.phone = w.apple.phone || w.android.phone || w.windows.phone, w.tablet = w.apple.tablet || w.android.tablet || w.windows.tablet, w
            }
        },
        4827: function(t, e, n) {
            var i = n(45650).Symbol;
            t.exports = i
        },
        16376: function(t, e, n) {
            var i = n(4827),
                r = n(43138),
                o = n(6778),
                s = i ? i.toStringTag : void 0;
            t.exports = function(t) {
                return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : s && s in Object(t) ? r(t) : o(t)
            }
        },
        96043: function(t, e, n) {
            var i = n(97508),
                r = /^\s+/;
            t.exports = function(t) {
                return t ? t.slice(0, i(t) + 1).replace(r, "") : t
            }
        },
        77062: function(t, e, n) {
            var i = "object" == typeof n.g && n.g && n.g.Object === Object && n.g;
            t.exports = i
        },
        43138: function(t, e, n) {
            var i = n(4827),
                r = Object.prototype,
                o = r.hasOwnProperty,
                s = r.toString,
                a = i ? i.toStringTag : void 0;
            t.exports = function(t) {
                var e = o.call(t, a),
                    n = t[a];
                try {
                    t[a] = void 0;
                    var i = !0
                } catch (t) {}
                var r = s.call(t);
                return i && (e ? t[a] = n : delete t[a]), r
            }
        },
        6778: function(t) {
            var e = Object.prototype.toString;
            t.exports = function(t) {
                return e.call(t)
            }
        },
        45650: function(t, e, n) {
            var i = n(77062),
                r = "object" == typeof self && self && self.Object === Object && self,
                o = i || r || Function("return this")();
            t.exports = o
        },
        97508: function(t) {
            var e = /\s/;
            t.exports = function(t) {
                for (var n = t.length; n-- && e.test(t.charAt(n)););
                return n
            }
        },
        131: function(t, e, n) {
            var i = n(15646),
                r = n(50416),
                o = n(88562),
                s = Math.max,
                a = Math.min;
            t.exports = function(t, e, n) {
                var u, c, l, d, h, f, p = 0,
                    m = !1,
                    v = !1,
                    g = !0;
                if ("function" != typeof t) throw new TypeError("Expected a function");

                function y(e) {
                    var n = u,
                        i = c;
                    return u = c = void 0, p = e, d = t.apply(i, n)
                }

                function b(t) {
                    var n = t - f;
                    return void 0 === f || n >= e || n < 0 || v && t - p >= l
                }

                function x() {
                    var t = r();
                    if (b(t)) return w(t);
                    h = setTimeout(x, function(t) {
                        var n = e - (t - f);
                        return v ? a(n, l - (t - p)) : n
                    }(t))
                }

                function w(t) {
                    return h = void 0, g && u ? y(t) : (u = c = void 0, d)
                }

                function P() {
                    var t = r(),
                        n = b(t);
                    if (u = arguments, c = this, f = t, n) {
                        if (void 0 === h) return function(t) {
                            return p = t, h = setTimeout(x, e), m ? y(t) : d
                        }(f);
                        if (v) return clearTimeout(h), h = setTimeout(x, e), y(f)
                    }
                    return void 0 === h && (h = setTimeout(x, e)), d
                }
                return e = o(e) || 0, i(n) && (m = !!n.leading, l = (v = "maxWait" in n) ? s(o(n.maxWait) || 0, e) : l, g = "trailing" in n ? !!n.trailing : g), P.cancel = function() {
                    void 0 !== h && clearTimeout(h), p = 0, u = f = c = h = void 0
                }, P.flush = function() {
                    return void 0 === h ? d : w(r())
                }, P
            }
        },
        15646: function(t) {
            t.exports = function(t) {
                var e = typeof t;
                return null != t && ("object" == e || "function" == e)
            }
        },
        8079: function(t) {
            t.exports = function(t) {
                return null != t && "object" == typeof t
            }
        },
        4682: function(t, e, n) {
            var i = n(16376),
                r = n(8079);
            t.exports = function(t) {
                return "symbol" == typeof t || r(t) && "[object Symbol]" == i(t)
            }
        },
        50416: function(t, e, n) {
            var i = n(45650);
            t.exports = function() {
                return i.Date.now()
            }
        },
        30731: function(t, e, n) {
            var i = n(131),
                r = n(15646);
            t.exports = function(t, e, n) {
                var o = !0,
                    s = !0;
                if ("function" != typeof t) throw new TypeError("Expected a function");
                return r(n) && (o = "leading" in n ? !!n.leading : o, s = "trailing" in n ? !!n.trailing : s), i(t, e, {
                    leading: o,
                    maxWait: e,
                    trailing: s
                })
            }
        },
        88562: function(t, e, n) {
            var i = n(96043),
                r = n(15646),
                o = n(4682),
                s = /^[-+]0x[0-9a-f]+$/i,
                a = /^0b[01]+$/i,
                u = /^0o[0-7]+$/i,
                c = parseInt;
            t.exports = function(t) {
                if ("number" == typeof t) return t;
                if (o(t)) return NaN;
                if (r(t)) {
                    var e = "function" == typeof t.valueOf ? t.valueOf() : t;
                    t = r(e) ? e + "" : e
                }
                if ("string" != typeof t) return 0 === t ? t : +t;
                t = i(t);
                var n = a.test(t);
                return n || u.test(t) ? c(t.slice(2), n ? 2 : 8) : s.test(t) ? NaN : +t
            }
        },
        88654: function(t, e, n) {
            var i, r, o, s, a;
            i = n(10455), r = n(92296).utf8, o = n(44494), s = n(92296).bin, (a = function(t, e) {
                t.constructor == String ? t = e && "binary" === e.encoding ? s.stringToBytes(t) : r.stringToBytes(t) : o(t) ? t = Array.prototype.slice.call(t, 0) : Array.isArray(t) || t.constructor === Uint8Array || (t = t.toString());
                for (var n = i.bytesToWords(t), u = 8 * t.length, c = 1732584193, l = -271733879, d = -1732584194, h = 271733878, f = 0; f < n.length; f++) n[f] = 16711935 & (n[f] << 8 | n[f] >>> 24) | 4278255360 & (n[f] << 24 | n[f] >>> 8);
                n[u >>> 5] |= 128 << u % 32, n[14 + (u + 64 >>> 9 << 4)] = u;
                var p = a._ff,
                    m = a._gg,
                    v = a._hh,
                    g = a._ii;
                for (f = 0; f < n.length; f += 16) {
                    var y = c,
                        b = l,
                        x = d,
                        w = h;
                    c = p(c, l, d, h, n[f + 0], 7, -680876936), h = p(h, c, l, d, n[f + 1], 12, -389564586), d = p(d, h, c, l, n[f + 2], 17, 606105819), l = p(l, d, h, c, n[f + 3], 22, -1044525330), c = p(c, l, d, h, n[f + 4], 7, -176418897), h = p(h, c, l, d, n[f + 5], 12, 1200080426), d = p(d, h, c, l, n[f + 6], 17, -1473231341), l = p(l, d, h, c, n[f + 7], 22, -45705983), c = p(c, l, d, h, n[f + 8], 7, 1770035416), h = p(h, c, l, d, n[f + 9], 12, -1958414417), d = p(d, h, c, l, n[f + 10], 17, -42063), l = p(l, d, h, c, n[f + 11], 22, -1990404162), c = p(c, l, d, h, n[f + 12], 7, 1804603682), h = p(h, c, l, d, n[f + 13], 12, -40341101), d = p(d, h, c, l, n[f + 14], 17, -1502002290), c = m(c, l = p(l, d, h, c, n[f + 15], 22, 1236535329), d, h, n[f + 1], 5, -165796510), h = m(h, c, l, d, n[f + 6], 9, -1069501632), d = m(d, h, c, l, n[f + 11], 14, 643717713), l = m(l, d, h, c, n[f + 0], 20, -373897302), c = m(c, l, d, h, n[f + 5], 5, -701558691), h = m(h, c, l, d, n[f + 10], 9, 38016083), d = m(d, h, c, l, n[f + 15], 14, -660478335), l = m(l, d, h, c, n[f + 4], 20, -405537848), c = m(c, l, d, h, n[f + 9], 5, 568446438), h = m(h, c, l, d, n[f + 14], 9, -1019803690), d = m(d, h, c, l, n[f + 3], 14, -187363961), l = m(l, d, h, c, n[f + 8], 20, 1163531501), c = m(c, l, d, h, n[f + 13], 5, -1444681467), h = m(h, c, l, d, n[f + 2], 9, -51403784), d = m(d, h, c, l, n[f + 7], 14, 1735328473), c = v(c, l = m(l, d, h, c, n[f + 12], 20, -1926607734), d, h, n[f + 5], 4, -378558), h = v(h, c, l, d, n[f + 8], 11, -2022574463), d = v(d, h, c, l, n[f + 11], 16, 1839030562), l = v(l, d, h, c, n[f + 14], 23, -35309556), c = v(c, l, d, h, n[f + 1], 4, -1530992060), h = v(h, c, l, d, n[f + 4], 11, 1272893353), d = v(d, h, c, l, n[f + 7], 16, -155497632), l = v(l, d, h, c, n[f + 10], 23, -1094730640), c = v(c, l, d, h, n[f + 13], 4, 681279174), h = v(h, c, l, d, n[f + 0], 11, -358537222), d = v(d, h, c, l, n[f + 3], 16, -722521979), l = v(l, d, h, c, n[f + 6], 23, 76029189), c = v(c, l, d, h, n[f + 9], 4, -640364487), h = v(h, c, l, d, n[f + 12], 11, -421815835), d = v(d, h, c, l, n[f + 15], 16, 530742520), c = g(c, l = v(l, d, h, c, n[f + 2], 23, -995338651), d, h, n[f + 0], 6, -198630844), h = g(h, c, l, d, n[f + 7], 10, 1126891415), d = g(d, h, c, l, n[f + 14], 15, -1416354905), l = g(l, d, h, c, n[f + 5], 21, -57434055), c = g(c, l, d, h, n[f + 12], 6, 1700485571), h = g(h, c, l, d, n[f + 3], 10, -1894986606), d = g(d, h, c, l, n[f + 10], 15, -1051523), l = g(l, d, h, c, n[f + 1], 21, -2054922799), c = g(c, l, d, h, n[f + 8], 6, 1873313359), h = g(h, c, l, d, n[f + 15], 10, -30611744), d = g(d, h, c, l, n[f + 6], 15, -1560198380), l = g(l, d, h, c, n[f + 13], 21, 1309151649), c = g(c, l, d, h, n[f + 4], 6, -145523070), h = g(h, c, l, d, n[f + 11], 10, -1120210379), d = g(d, h, c, l, n[f + 2], 15, 718787259), l = g(l, d, h, c, n[f + 9], 21, -343485551), c = c + y >>> 0, l = l + b >>> 0, d = d + x >>> 0, h = h + w >>> 0
                }
                return i.endian([c, l, d, h])
            })._ff = function(t, e, n, i, r, o, s) {
                var a = t + (e & n | ~e & i) + (r >>> 0) + s;
                return (a << o | a >>> 32 - o) + e
            }, a._gg = function(t, e, n, i, r, o, s) {
                var a = t + (e & i | n & ~i) + (r >>> 0) + s;
                return (a << o | a >>> 32 - o) + e
            }, a._hh = function(t, e, n, i, r, o, s) {
                var a = t + (e ^ n ^ i) + (r >>> 0) + s;
                return (a << o | a >>> 32 - o) + e
            }, a._ii = function(t, e, n, i, r, o, s) {
                var a = t + (n ^ (e | ~i)) + (r >>> 0) + s;
                return (a << o | a >>> 32 - o) + e
            }, a._blocksize = 16, a._digestsize = 16, t.exports = function(t, e) {
                if (null == t) throw new Error("Illegal argument " + t);
                var n = i.wordsToBytes(a(t, e));
                return e && e.asBytes ? n : e && e.asString ? s.bytesToString(n) : i.bytesToHex(n)
            }
        },
        41868: function(t, e, n) {
            "use strict";
            n.d(e, {
                default: function() {
                    return r.a
                }
            });
            var i = n(94016),
                r = n.n(i)
        },
        60842: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "Image", {
                enumerable: !0,
                get: function() {
                    return b
                }
            });
            const i = n(7630),
                r = n(84533),
                o = n(75467),
                s = r._(n(84371)),
                a = i._(n(29980)),
                u = i._(n(3646)),
                c = n(86027),
                l = n(80608),
                d = n(85462),
                h = (n(16047), n(18768)),
                f = i._(n(33512)),
                p = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    dangerouslyAllowSVG: !1,
                    unoptimized: !0
                };

            function m(t, e, n, i, r, o, s) {
                const a = null == t ? void 0 : t.src;
                if (!t || t["data-loaded-src"] === a) return;
                t["data-loaded-src"] = a;
                ("decode" in t ? t.decode() : Promise.resolve()).catch((() => {})).then((() => {
                    if (t.parentElement && t.isConnected) {
                        if ("empty" !== e && r(!0), null == n ? void 0 : n.current) {
                            const e = new Event("load");
                            Object.defineProperty(e, "target", {
                                writable: !1,
                                value: t
                            });
                            let i = !1,
                                r = !1;
                            n.current({ ...e,
                                nativeEvent: e,
                                currentTarget: t,
                                target: t,
                                isDefaultPrevented: () => i,
                                isPropagationStopped: () => r,
                                persist: () => {},
                                preventDefault: () => {
                                    i = !0, e.preventDefault()
                                },
                                stopPropagation: () => {
                                    r = !0, e.stopPropagation()
                                }
                            })
                        }(null == i ? void 0 : i.current) && i.current(t)
                    }
                }))
            }

            function v(t) {
                const [e, n] = s.version.split(".", 2), i = parseInt(e, 10), r = parseInt(n, 10);
                return i > 18 || 18 === i && r >= 3 ? {
                    fetchPriority: t
                } : {
                    fetchpriority: t
                }
            }
            "undefined" == typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
            const g = (0, s.forwardRef)(((t, e) => {
                let {
                    src: n,
                    srcSet: i,
                    sizes: r,
                    height: a,
                    width: u,
                    decoding: c,
                    className: l,
                    style: d,
                    fetchPriority: h,
                    placeholder: f,
                    loading: p,
                    unoptimized: g,
                    fill: y,
                    onLoadRef: b,
                    onLoadingCompleteRef: x,
                    setBlurComplete: w,
                    setShowAltText: P,
                    sizesInput: E,
                    onLoad: T,
                    onError: S,
                    ...M
                } = t;
                return (0, o.jsx)("img", { ...M,
                    ...v(h),
                    loading: p,
                    width: u,
                    height: a,
                    decoding: c,
                    "data-nimg": y ? "fill" : "1",
                    className: l,
                    style: d,
                    sizes: r,
                    srcSet: i,
                    src: n,
                    ref: (0, s.useCallback)((t => {
                        e && ("function" == typeof e ? e(t) : "object" == typeof e && (e.current = t)), t && (S && (t.src = t.src), t.complete && m(t, f, b, x, w))
                    }), [n, f, b, x, w, S, g, E, e]),
                    onLoad: t => {
                        m(t.currentTarget, f, b, x, w)
                    },
                    onError: t => {
                        P(!0), "empty" !== f && w(!0), S && S(t)
                    }
                })
            }));

            function y(t) {
                let {
                    isAppRouter: e,
                    imgAttributes: n
                } = t;
                const i = {
                    as: "image",
                    imageSrcSet: n.srcSet,
                    imageSizes: n.sizes,
                    crossOrigin: n.crossOrigin,
                    referrerPolicy: n.referrerPolicy,
                    ...v(n.fetchPriority)
                };
                return e && a.default.preload ? (a.default.preload(n.src, i), null) : (0, o.jsx)(u.default, {
                    children: (0, o.jsx)("link", {
                        rel: "preload",
                        href: n.srcSet ? void 0 : n.src,
                        ...i
                    }, "__nimg-" + n.src + n.srcSet + n.sizes)
                })
            }
            const b = (0, s.forwardRef)(((t, e) => {
                const n = !(0, s.useContext)(h.RouterContext),
                    i = (0, s.useContext)(d.ImageConfigContext),
                    r = (0, s.useMemo)((() => {
                        const t = p || i || l.imageConfigDefault,
                            e = [...t.deviceSizes, ...t.imageSizes].sort(((t, e) => t - e)),
                            n = t.deviceSizes.sort(((t, e) => t - e));
                        return { ...t,
                            allSizes: e,
                            deviceSizes: n
                        }
                    }), [i]),
                    {
                        onLoad: a,
                        onLoadingComplete: u
                    } = t,
                    m = (0, s.useRef)(a);
                (0, s.useEffect)((() => {
                    m.current = a
                }), [a]);
                const v = (0, s.useRef)(u);
                (0, s.useEffect)((() => {
                    v.current = u
                }), [u]);
                const [b, x] = (0, s.useState)(!1), [w, P] = (0, s.useState)(!1), {
                    props: E,
                    meta: T
                } = (0, c.getImgProps)(t, {
                    defaultLoader: f.default,
                    imgConf: r,
                    blurComplete: b,
                    showAltText: w
                });
                return (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(g, { ...E,
                        unoptimized: T.unoptimized,
                        placeholder: T.placeholder,
                        fill: T.fill,
                        onLoadRef: m,
                        onLoadingCompleteRef: v,
                        setBlurComplete: x,
                        setShowAltText: P,
                        sizesInput: t.sizes,
                        ref: e
                    }), T.priority ? (0, o.jsx)(y, {
                        isAppRouter: n,
                        imgAttributes: E
                    }) : null]
                })
            }));
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        96091: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "AmpStateContext", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            const i = n(7630)._(n(84371)).default.createContext({})
        },
        26897: function(t, e) {
            "use strict";

            function n(t) {
                let {
                    ampFirst: e = !1,
                    hybrid: n = !1,
                    hasQuery: i = !1
                } = void 0 === t ? {} : t;
                return e || n && i
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isInAmpMode", {
                enumerable: !0,
                get: function() {
                    return n
                }
            })
        },
        86027: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getImgProps", {
                enumerable: !0,
                get: function() {
                    return u
                }
            });
            n(16047);
            const i = n(13049),
                r = n(80608);

            function o(t) {
                return void 0 !== t.default
            }
            new Map;

            function s(t) {
                return void 0 === t ? t : "number" == typeof t ? Number.isFinite(t) ? t : NaN : "string" == typeof t && /^[0-9]+$/.test(t) ? parseInt(t, 10) : NaN
            }

            function a(t) {
                let {
                    config: e,
                    src: n,
                    unoptimized: i,
                    width: r,
                    quality: o,
                    sizes: s,
                    loader: a
                } = t;
                if (i) return {
                    src: n,
                    srcSet: void 0,
                    sizes: void 0
                };
                const {
                    widths: u,
                    kind: c
                } = function(t, e, n) {
                    let {
                        deviceSizes: i,
                        allSizes: r
                    } = t;
                    if (n) {
                        const t = /(^|\s)(1?\d?\d)vw/g,
                            e = [];
                        for (let i; i = t.exec(n); i) e.push(parseInt(i[2]));
                        if (e.length) {
                            const t = .01 * Math.min(...e);
                            return {
                                widths: r.filter((e => e >= i[0] * t)),
                                kind: "w"
                            }
                        }
                        return {
                            widths: r,
                            kind: "w"
                        }
                    }
                    return "number" != typeof e ? {
                        widths: i,
                        kind: "w"
                    } : {
                        widths: [...new Set([e, 2 * e].map((t => r.find((e => e >= t)) || r[r.length - 1])))],
                        kind: "x"
                    }
                }(e, r, s), l = u.length - 1;
                return {
                    sizes: s || "w" !== c ? s : "100vw",
                    srcSet: u.map(((t, i) => a({
                        config: e,
                        src: n,
                        quality: o,
                        width: t
                    }) + " " + ("w" === c ? t : i + 1) + c)).join(", "),
                    src: a({
                        config: e,
                        src: n,
                        quality: o,
                        width: u[l]
                    })
                }
            }

            function u(t, e) {
                let {
                    src: n,
                    sizes: u,
                    unoptimized: c = !1,
                    priority: l = !1,
                    loading: d,
                    className: h,
                    quality: f,
                    width: p,
                    height: m,
                    fill: v = !1,
                    style: g,
                    overrideSrc: y,
                    onLoad: b,
                    onLoadingComplete: x,
                    placeholder: w = "empty",
                    blurDataURL: P,
                    fetchPriority: E,
                    layout: T,
                    objectFit: S,
                    objectPosition: M,
                    lazyBoundary: C,
                    lazyRoot: D,
                    ...O
                } = t;
                const {
                    imgConf: A,
                    showAltText: k,
                    blurComplete: R,
                    defaultLoader: _
                } = e;
                let j, L = A || r.imageConfigDefault;
                if ("allSizes" in L) j = L;
                else {
                    const t = [...L.deviceSizes, ...L.imageSizes].sort(((t, e) => t - e)),
                        e = L.deviceSizes.sort(((t, e) => t - e));
                    j = { ...L,
                        allSizes: t,
                        deviceSizes: e
                    }
                }
                if (void 0 === _) throw new Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config");
                let V = O.loader || _;
                delete O.loader, delete O.srcSet;
                const B = "__next_img_default" in V;
                if (B) {
                    if ("custom" === j.loader) throw new Error('Image with src "' + n + '" is missing "loader" prop.\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader')
                } else {
                    const t = V;
                    V = e => {
                        const {
                            config: n,
                            ...i
                        } = e;
                        return t(i)
                    }
                }
                if (T) {
                    "fill" === T && (v = !0);
                    const t = {
                            responsive: "100vw",
                            fill: "100vw"
                        },
                        e = {
                            intrinsic: {
                                maxWidth: "100%",
                                height: "auto"
                            },
                            responsive: {
                                width: "100%",
                                height: "auto"
                            }
                        }[T];
                    e && (g = { ...g,
                        ...e
                    });
                    const n = t[T];
                    n && !u && (u = n)
                }
                let N, F, $ = "",
                    I = s(p),
                    z = s(m);
                if (function(t) {
                        return "object" == typeof t && (o(t) || function(t) {
                            return void 0 !== t.src
                        }(t))
                    }(n)) {
                    const t = o(n) ? n.default : n;
                    if (!t.src) throw new Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received " + JSON.stringify(t));
                    if (!t.height || !t.width) throw new Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received " + JSON.stringify(t));
                    if (N = t.blurWidth, F = t.blurHeight, P = P || t.blurDataURL, $ = t.src, !v)
                        if (I || z) {
                            if (I && !z) {
                                const e = I / t.width;
                                z = Math.round(t.height * e)
                            } else if (!I && z) {
                                const e = z / t.height;
                                I = Math.round(t.width * e)
                            }
                        } else I = t.width, z = t.height
                }
                n = "string" == typeof n ? n : $;
                let W = !l && ("lazy" === d || void 0 === d);
                (!n || n.startsWith("data:") || n.startsWith("blob:")) && (c = !0, W = !1), j.unoptimized && (c = !0), B && n.endsWith(".svg") && !j.dangerouslyAllowSVG && (c = !0), l && (E = "high");
                const U = s(f);
                const H = Object.assign(v ? {
                        position: "absolute",
                        height: "100%",
                        width: "100%",
                        left: 0,
                        top: 0,
                        right: 0,
                        bottom: 0,
                        objectFit: S,
                        objectPosition: M
                    } : {}, k ? {} : {
                        color: "transparent"
                    }, g),
                    Y = R || "empty" === w ? null : "blur" === w ? 'url("data:image/svg+xml;charset=utf-8,' + (0, i.getImageBlurSvg)({
                        widthInt: I,
                        heightInt: z,
                        blurWidth: N,
                        blurHeight: F,
                        blurDataURL: P || "",
                        objectFit: H.objectFit
                    }) + '")' : 'url("' + w + '")';
                let X = Y ? {
                    backgroundSize: H.objectFit || "cover",
                    backgroundPosition: H.objectPosition || "50% 50%",
                    backgroundRepeat: "no-repeat",
                    backgroundImage: Y
                } : {};
                const Z = a({
                    config: j,
                    src: n,
                    unoptimized: c,
                    width: I,
                    quality: U,
                    sizes: u,
                    loader: V
                });
                return {
                    props: { ...O,
                        loading: W ? "lazy" : d,
                        fetchPriority: E,
                        width: I,
                        height: z,
                        decoding: "async",
                        className: h,
                        style: { ...H,
                            ...X
                        },
                        sizes: Z.sizes,
                        srcSet: Z.srcSet,
                        src: y || Z.src
                    },
                    meta: {
                        unoptimized: c,
                        priority: l,
                        placeholder: w,
                        fill: v
                    }
                }
            }
        },
        3646: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var n in e) Object.defineProperty(t, n, {
                        enumerable: !0,
                        get: e[n]
                    })
                }(e, {
                    default: function() {
                        return m
                    },
                    defaultHead: function() {
                        return d
                    }
                });
            const i = n(7630),
                r = n(84533),
                o = n(75467),
                s = r._(n(84371)),
                a = i._(n(22507)),
                u = n(96091),
                c = n(4552),
                l = n(26897);
            n(16047);

            function d(t) {
                void 0 === t && (t = !1);
                const e = [(0, o.jsx)("meta", {
                    charSet: "utf-8"
                })];
                return t || e.push((0, o.jsx)("meta", {
                    name: "viewport",
                    content: "width=device-width"
                })), e
            }

            function h(t, e) {
                return "string" == typeof e || "number" == typeof e ? t : e.type === s.default.Fragment ? t.concat(s.default.Children.toArray(e.props.children).reduce(((t, e) => "string" == typeof e || "number" == typeof e ? t : t.concat(e)), [])) : t.concat(e)
            }
            const f = ["name", "httpEquiv", "charSet", "itemProp"];

            function p(t, e) {
                const {
                    inAmpMode: n
                } = e;
                return t.reduce(h, []).reverse().concat(d(n).reverse()).filter(function() {
                    const t = new Set,
                        e = new Set,
                        n = new Set,
                        i = {};
                    return r => {
                        let o = !0,
                            s = !1;
                        if (r.key && "number" != typeof r.key && r.key.indexOf("$") > 0) {
                            s = !0;
                            const e = r.key.slice(r.key.indexOf("$") + 1);
                            t.has(e) ? o = !1 : t.add(e)
                        }
                        switch (r.type) {
                            case "title":
                            case "base":
                                e.has(r.type) ? o = !1 : e.add(r.type);
                                break;
                            case "meta":
                                for (let t = 0, e = f.length; t < e; t++) {
                                    const e = f[t];
                                    if (r.props.hasOwnProperty(e))
                                        if ("charSet" === e) n.has(e) ? o = !1 : n.add(e);
                                        else {
                                            const t = r.props[e],
                                                n = i[e] || new Set;
                                            "name" === e && s || !n.has(t) ? (n.add(t), i[e] = n) : o = !1
                                        }
                                }
                        }
                        return o
                    }
                }()).reverse().map(((t, e) => {
                    const i = t.key || e;
                    if (!n && "link" === t.type && t.props.href && ["https://fonts.googleapis.com/css", "https://use.typekit.net/"].some((e => t.props.href.startsWith(e)))) {
                        const e = { ...t.props || {}
                        };
                        return e["data-href"] = e.href, e.href = void 0, e["data-optimized-fonts"] = !0, s.default.cloneElement(t, e)
                    }
                    return s.default.cloneElement(t, {
                        key: i
                    })
                }))
            }
            const m = function(t) {
                let {
                    children: e
                } = t;
                const n = (0, s.useContext)(u.AmpStateContext),
                    i = (0, s.useContext)(c.HeadManagerContext);
                return (0, o.jsx)(a.default, {
                    reduceComponentsToState: p,
                    headManager: i,
                    inAmpMode: (0, l.isInAmpMode)(n),
                    children: e
                })
            };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        13049: function(t, e) {
            "use strict";

            function n(t) {
                let {
                    widthInt: e,
                    heightInt: n,
                    blurWidth: i,
                    blurHeight: r,
                    blurDataURL: o,
                    objectFit: s
                } = t;
                const a = i ? 40 * i : e,
                    u = r ? 40 * r : n,
                    c = a && u ? "viewBox='0 0 " + a + " " + u + "'" : "";
                return "%3Csvg xmlns='http://www.w3.org/2000/svg' " + c + "%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='" + (c ? "none" : "contain" === s ? "xMidYMid" : "cover" === s ? "xMidYMid slice" : "none") + "' style='filter: url(%23b);' href='" + o + "'/%3E%3C/svg%3E"
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getImageBlurSvg", {
                enumerable: !0,
                get: function() {
                    return n
                }
            })
        },
        85462: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "ImageConfigContext", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            const i = n(7630)._(n(84371)),
                r = n(80608),
                o = i.default.createContext(r.imageConfigDefault)
        },
        80608: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var n in e) Object.defineProperty(t, n, {
                        enumerable: !0,
                        get: e[n]
                    })
                }(e, {
                    VALID_LOADERS: function() {
                        return n
                    },
                    imageConfigDefault: function() {
                        return i
                    }
                });
            const n = ["default", "imgix", "cloudinary", "akamai", "custom"],
                i = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    loaderFile: "",
                    domains: [],
                    disableStaticImages: !1,
                    minimumCacheTTL: 60,
                    formats: ["image/webp"],
                    dangerouslyAllowSVG: !1,
                    contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
                    contentDispositionType: "inline",
                    remotePatterns: [],
                    unoptimized: !1
                }
        },
        94016: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var n in e) Object.defineProperty(t, n, {
                        enumerable: !0,
                        get: e[n]
                    })
                }(e, {
                    default: function() {
                        return u
                    },
                    getImageProps: function() {
                        return a
                    }
                });
            const i = n(7630),
                r = n(86027),
                o = n(60842),
                s = i._(n(33512));

            function a(t) {
                const {
                    props: e
                } = (0, r.getImgProps)(t, {
                    defaultLoader: s.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !0
                    }
                });
                for (const [t, n] of Object.entries(e)) void 0 === n && delete e[t];
                return {
                    props: e
                }
            }
            const u = o.Image
        },
        33512: function(t, e) {
            "use strict";

            function n(t) {
                let {
                    config: e,
                    src: n,
                    width: i,
                    quality: r
                } = t;
                return e.path + "?url=" + encodeURIComponent(n) + "&w=" + i + "&q=" + (r || 75)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return i
                }
            }), n.__next_img_default = !0;
            const i = n
        },
        22507: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return a
                }
            });
            const i = n(84371),
                r = "undefined" == typeof window,
                o = r ? () => {} : i.useLayoutEffect,
                s = r ? () => {} : i.useEffect;

            function a(t) {
                const {
                    headManager: e,
                    reduceComponentsToState: n
                } = t;

                function a() {
                    if (e && e.mountedInstances) {
                        const r = i.Children.toArray(Array.from(e.mountedInstances).filter(Boolean));
                        e.updateHead(n(r, t))
                    }
                }
                var u;
                r && (null == e || null == (u = e.mountedInstances) || u.add(t.children), a());
                return o((() => {
                    var n;
                    return null == e || null == (n = e.mountedInstances) || n.add(t.children), () => {
                        var n;
                        null == e || null == (n = e.mountedInstances) || n.delete(t.children)
                    }
                })), o((() => (e && (e._pendingUpdate = a), () => {
                    e && (e._pendingUpdate = a)
                }))), s((() => (e && e._pendingUpdate && (e._pendingUpdate(), e._pendingUpdate = null), () => {
                    e && e._pendingUpdate && (e._pendingUpdate(), e._pendingUpdate = null)
                }))), null
            }
        },
        19606: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return P
                }
            });
            var i = n(54343),
                r = n(84268),
                o = n(14415);

            function s(t, e) {
                return t.replace(new RegExp("(^|\\s)" + e + "(?:\\s|$)", "g"), "$1").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "")
            }
            var a = n(84371),
                u = n(29980),
                c = !1,
                l = n(9435),
                d = function(t) {
                    return t.scrollTop
                },
                h = "unmounted",
                f = "exited",
                p = "entering",
                m = "entered",
                v = "exiting",
                g = function(t) {
                    function e(e, n) {
                        var i;
                        i = t.call(this, e, n) || this;
                        var r, o = n && !n.isMounting ? e.enter : e.appear;
                        return i.appearStatus = null, e.in ? o ? (r = f, i.appearStatus = p) : r = m : r = e.unmountOnExit || e.mountOnEnter ? h : f, i.state = {
                            status: r
                        }, i.nextCallback = null, i
                    }(0, o.Z)(e, t), e.getDerivedStateFromProps = function(t, e) {
                        return t.in && e.status === h ? {
                            status: f
                        } : null
                    };
                    var n = e.prototype;
                    return n.componentDidMount = function() {
                        this.updateStatus(!0, this.appearStatus)
                    }, n.componentDidUpdate = function(t) {
                        var e = null;
                        if (t !== this.props) {
                            var n = this.state.status;
                            this.props.in ? n !== p && n !== m && (e = p) : n !== p && n !== m || (e = v)
                        }
                        this.updateStatus(!1, e)
                    }, n.componentWillUnmount = function() {
                        this.cancelNextCallback()
                    }, n.getTimeouts = function() {
                        var t, e, n, i = this.props.timeout;
                        return t = e = n = i, null != i && "number" != typeof i && (t = i.exit, e = i.enter, n = void 0 !== i.appear ? i.appear : e), {
                            exit: t,
                            enter: e,
                            appear: n
                        }
                    }, n.updateStatus = function(t, e) {
                        if (void 0 === t && (t = !1), null !== e)
                            if (this.cancelNextCallback(), e === p) {
                                if (this.props.unmountOnExit || this.props.mountOnEnter) {
                                    var n = this.props.nodeRef ? this.props.nodeRef.current : u.findDOMNode(this);
                                    n && d(n)
                                }
                                this.performEnter(t)
                            } else this.performExit();
                        else this.props.unmountOnExit && this.state.status === f && this.setState({
                            status: h
                        })
                    }, n.performEnter = function(t) {
                        var e = this,
                            n = this.props.enter,
                            i = this.context ? this.context.isMounting : t,
                            r = this.props.nodeRef ? [i] : [u.findDOMNode(this), i],
                            o = r[0],
                            s = r[1],
                            a = this.getTimeouts(),
                            l = i ? a.appear : a.enter;
                        !t && !n || c ? this.safeSetState({
                            status: m
                        }, (function() {
                            e.props.onEntered(o)
                        })) : (this.props.onEnter(o, s), this.safeSetState({
                            status: p
                        }, (function() {
                            e.props.onEntering(o, s), e.onTransitionEnd(l, (function() {
                                e.safeSetState({
                                    status: m
                                }, (function() {
                                    e.props.onEntered(o, s)
                                }))
                            }))
                        })))
                    }, n.performExit = function() {
                        var t = this,
                            e = this.props.exit,
                            n = this.getTimeouts(),
                            i = this.props.nodeRef ? void 0 : u.findDOMNode(this);
                        e && !c ? (this.props.onExit(i), this.safeSetState({
                            status: v
                        }, (function() {
                            t.props.onExiting(i), t.onTransitionEnd(n.exit, (function() {
                                t.safeSetState({
                                    status: f
                                }, (function() {
                                    t.props.onExited(i)
                                }))
                            }))
                        }))) : this.safeSetState({
                            status: f
                        }, (function() {
                            t.props.onExited(i)
                        }))
                    }, n.cancelNextCallback = function() {
                        null !== this.nextCallback && (this.nextCallback.cancel(), this.nextCallback = null)
                    }, n.safeSetState = function(t, e) {
                        e = this.setNextCallback(e), this.setState(t, e)
                    }, n.setNextCallback = function(t) {
                        var e = this,
                            n = !0;
                        return this.nextCallback = function(i) {
                            n && (n = !1, e.nextCallback = null, t(i))
                        }, this.nextCallback.cancel = function() {
                            n = !1
                        }, this.nextCallback
                    }, n.onTransitionEnd = function(t, e) {
                        this.setNextCallback(e);
                        var n = this.props.nodeRef ? this.props.nodeRef.current : u.findDOMNode(this),
                            i = null == t && !this.props.addEndListener;
                        if (n && !i) {
                            if (this.props.addEndListener) {
                                var r = this.props.nodeRef ? [this.nextCallback] : [n, this.nextCallback],
                                    o = r[0],
                                    s = r[1];
                                this.props.addEndListener(o, s)
                            }
                            null != t && setTimeout(this.nextCallback, t)
                        } else setTimeout(this.nextCallback, 0)
                    }, n.render = function() {
                        var t = this.state.status;
                        if (t === h) return null;
                        var e = this.props,
                            n = e.children,
                            i = (e.in, e.mountOnEnter, e.unmountOnExit, e.appear, e.enter, e.exit, e.timeout, e.addEndListener, e.onEnter, e.onEntering, e.onEntered, e.onExit, e.onExiting, e.onExited, e.nodeRef, (0, r.Z)(e, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]));
                        return a.createElement(l.Z.Provider, {
                            value: null
                        }, "function" == typeof n ? n(t, i) : a.cloneElement(a.Children.only(n), i))
                    }, e
                }(a.Component);

            function y() {}
            g.contextType = l.Z, g.propTypes = {}, g.defaultProps = { in: !1,
                mountOnEnter: !1,
                unmountOnExit: !1,
                appear: !1,
                enter: !0,
                exit: !0,
                onEnter: y,
                onEntering: y,
                onEntered: y,
                onExit: y,
                onExiting: y,
                onExited: y
            }, g.UNMOUNTED = h, g.EXITED = f, g.ENTERING = p, g.ENTERED = m, g.EXITING = v;
            var b = g,
                x = function(t, e) {
                    return t && e && e.split(" ").forEach((function(e) {
                        return i = e, void((n = t).classList ? n.classList.remove(i) : "string" == typeof n.className ? n.className = s(n.className, i) : n.setAttribute("class", s(n.className && n.className.baseVal || "", i)));
                        var n, i
                    }))
                },
                w = function(t) {
                    function e() {
                        for (var e, n = arguments.length, i = new Array(n), r = 0; r < n; r++) i[r] = arguments[r];
                        return (e = t.call.apply(t, [this].concat(i)) || this).appliedClasses = {
                            appear: {},
                            enter: {},
                            exit: {}
                        }, e.onEnter = function(t, n) {
                            var i = e.resolveArguments(t, n),
                                r = i[0],
                                o = i[1];
                            e.removeClasses(r, "exit"), e.addClass(r, o ? "appear" : "enter", "base"), e.props.onEnter && e.props.onEnter(t, n)
                        }, e.onEntering = function(t, n) {
                            var i = e.resolveArguments(t, n),
                                r = i[0],
                                o = i[1] ? "appear" : "enter";
                            e.addClass(r, o, "active"), e.props.onEntering && e.props.onEntering(t, n)
                        }, e.onEntered = function(t, n) {
                            var i = e.resolveArguments(t, n),
                                r = i[0],
                                o = i[1] ? "appear" : "enter";
                            e.removeClasses(r, o), e.addClass(r, o, "done"), e.props.onEntered && e.props.onEntered(t, n)
                        }, e.onExit = function(t) {
                            var n = e.resolveArguments(t)[0];
                            e.removeClasses(n, "appear"), e.removeClasses(n, "enter"), e.addClass(n, "exit", "base"), e.props.onExit && e.props.onExit(t)
                        }, e.onExiting = function(t) {
                            var n = e.resolveArguments(t)[0];
                            e.addClass(n, "exit", "active"), e.props.onExiting && e.props.onExiting(t)
                        }, e.onExited = function(t) {
                            var n = e.resolveArguments(t)[0];
                            e.removeClasses(n, "exit"), e.addClass(n, "exit", "done"), e.props.onExited && e.props.onExited(t)
                        }, e.resolveArguments = function(t, n) {
                            return e.props.nodeRef ? [e.props.nodeRef.current, t] : [t, n]
                        }, e.getClassNames = function(t) {
                            var n = e.props.classNames,
                                i = "string" == typeof n,
                                r = i ? "" + (i && n ? n + "-" : "") + t : n[t];
                            return {
                                baseClassName: r,
                                activeClassName: i ? r + "-active" : n[t + "Active"],
                                doneClassName: i ? r + "-done" : n[t + "Done"]
                            }
                        }, e
                    }(0, o.Z)(e, t);
                    var n = e.prototype;
                    return n.addClass = function(t, e, n) {
                        var i = this.getClassNames(e)[n + "ClassName"],
                            r = this.getClassNames("enter").doneClassName;
                        "appear" === e && "done" === n && r && (i += " " + r), "active" === n && t && d(t), i && (this.appliedClasses[e][n] = i, function(t, e) {
                            t && e && e.split(" ").forEach((function(e) {
                                return i = e, void((n = t).classList ? n.classList.add(i) : function(t, e) {
                                    return t.classList ? !!e && t.classList.contains(e) : -1 !== (" " + (t.className.baseVal || t.className) + " ").indexOf(" " + e + " ")
                                }(n, i) || ("string" == typeof n.className ? n.className = n.className + " " + i : n.setAttribute("class", (n.className && n.className.baseVal || "") + " " + i)));
                                var n, i
                            }))
                        }(t, i))
                    }, n.removeClasses = function(t, e) {
                        var n = this.appliedClasses[e],
                            i = n.base,
                            r = n.active,
                            o = n.done;
                        this.appliedClasses[e] = {}, i && x(t, i), r && x(t, r), o && x(t, o)
                    }, n.render = function() {
                        var t = this.props,
                            e = (t.classNames, (0, r.Z)(t, ["classNames"]));
                        return a.createElement(b, (0, i.Z)({}, e, {
                            onEnter: this.onEnter,
                            onEntered: this.onEntered,
                            onEntering: this.onEntering,
                            onExit: this.onExit,
                            onExiting: this.onExiting,
                            onExited: this.onExited
                        }))
                    }, e
                }(a.Component);
            w.defaultProps = {
                classNames: ""
            }, w.propTypes = {};
            var P = w
        },
        9435: function(t, e, n) {
            "use strict";
            var i = n(84371);
            e.Z = i.createContext(null)
        },
        69570: function(t, e, n) {
            "use strict";
            var i = function() {
                    if ("undefined" != typeof Map) return Map;

                    function t(t, e) {
                        var n = -1;
                        return t.some((function(t, i) {
                            return t[0] === e && (n = i, !0)
                        })), n
                    }
                    return function() {
                        function e() {
                            this.__entries__ = []
                        }
                        return Object.defineProperty(e.prototype, "size", {
                            get: function() {
                                return this.__entries__.length
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.get = function(e) {
                            var n = t(this.__entries__, e),
                                i = this.__entries__[n];
                            return i && i[1]
                        }, e.prototype.set = function(e, n) {
                            var i = t(this.__entries__, e);
                            ~i ? this.__entries__[i][1] = n : this.__entries__.push([e, n])
                        }, e.prototype.delete = function(e) {
                            var n = this.__entries__,
                                i = t(n, e);
                            ~i && n.splice(i, 1)
                        }, e.prototype.has = function(e) {
                            return !!~t(this.__entries__, e)
                        }, e.prototype.clear = function() {
                            this.__entries__.splice(0)
                        }, e.prototype.forEach = function(t, e) {
                            void 0 === e && (e = null);
                            for (var n = 0, i = this.__entries__; n < i.length; n++) {
                                var r = i[n];
                                t.call(e, r[1], r[0])
                            }
                        }, e
                    }()
                }(),
                r = "undefined" != typeof window && "undefined" != typeof document && window.document === document,
                o = void 0 !== n.g && n.g.Math === Math ? n.g : "undefined" != typeof self && self.Math === Math ? self : "undefined" != typeof window && window.Math === Math ? window : Function("return this")(),
                s = "function" == typeof requestAnimationFrame ? requestAnimationFrame.bind(o) : function(t) {
                    return setTimeout((function() {
                        return t(Date.now())
                    }), 1e3 / 60)
                };
            var a = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
                u = "undefined" != typeof MutationObserver,
                c = function() {
                    function t() {
                        this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = function(t, e) {
                            var n = !1,
                                i = !1,
                                r = 0;

                            function o() {
                                n && (n = !1, t()), i && u()
                            }

                            function a() {
                                s(o)
                            }

                            function u() {
                                var t = Date.now();
                                if (n) {
                                    if (t - r < 2) return;
                                    i = !0
                                } else n = !0, i = !1, setTimeout(a, e);
                                r = t
                            }
                            return u
                        }(this.refresh.bind(this), 20)
                    }
                    return t.prototype.addObserver = function(t) {
                        ~this.observers_.indexOf(t) || this.observers_.push(t), this.connected_ || this.connect_()
                    }, t.prototype.removeObserver = function(t) {
                        var e = this.observers_,
                            n = e.indexOf(t);
                        ~n && e.splice(n, 1), !e.length && this.connected_ && this.disconnect_()
                    }, t.prototype.refresh = function() {
                        this.updateObservers_() && this.refresh()
                    }, t.prototype.updateObservers_ = function() {
                        var t = this.observers_.filter((function(t) {
                            return t.gatherActive(), t.hasActive()
                        }));
                        return t.forEach((function(t) {
                            return t.broadcastActive()
                        })), t.length > 0
                    }, t.prototype.connect_ = function() {
                        r && !this.connected_ && (document.addEventListener("transitionend", this.onTransitionEnd_), window.addEventListener("resize", this.refresh), u ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
                            attributes: !0,
                            childList: !0,
                            characterData: !0,
                            subtree: !0
                        })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0), this.connected_ = !0)
                    }, t.prototype.disconnect_ = function() {
                        r && this.connected_ && (document.removeEventListener("transitionend", this.onTransitionEnd_), window.removeEventListener("resize", this.refresh), this.mutationsObserver_ && this.mutationsObserver_.disconnect(), this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh), this.mutationsObserver_ = null, this.mutationEventsAdded_ = !1, this.connected_ = !1)
                    }, t.prototype.onTransitionEnd_ = function(t) {
                        var e = t.propertyName,
                            n = void 0 === e ? "" : e;
                        a.some((function(t) {
                            return !!~n.indexOf(t)
                        })) && this.refresh()
                    }, t.getInstance = function() {
                        return this.instance_ || (this.instance_ = new t), this.instance_
                    }, t.instance_ = null, t
                }(),
                l = function(t, e) {
                    for (var n = 0, i = Object.keys(e); n < i.length; n++) {
                        var r = i[n];
                        Object.defineProperty(t, r, {
                            value: e[r],
                            enumerable: !1,
                            writable: !1,
                            configurable: !0
                        })
                    }
                    return t
                },
                d = function(t) {
                    return t && t.ownerDocument && t.ownerDocument.defaultView || o
                },
                h = y(0, 0, 0, 0);

            function f(t) {
                return parseFloat(t) || 0
            }

            function p(t) {
                for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                return e.reduce((function(e, n) {
                    return e + f(t["border-" + n + "-width"])
                }), 0)
            }

            function m(t) {
                var e = t.clientWidth,
                    n = t.clientHeight;
                if (!e && !n) return h;
                var i = d(t).getComputedStyle(t),
                    r = function(t) {
                        for (var e = {}, n = 0, i = ["top", "right", "bottom", "left"]; n < i.length; n++) {
                            var r = i[n],
                                o = t["padding-" + r];
                            e[r] = f(o)
                        }
                        return e
                    }(i),
                    o = r.left + r.right,
                    s = r.top + r.bottom,
                    a = f(i.width),
                    u = f(i.height);
                if ("border-box" === i.boxSizing && (Math.round(a + o) !== e && (a -= p(i, "left", "right") + o), Math.round(u + s) !== n && (u -= p(i, "top", "bottom") + s)), ! function(t) {
                        return t === d(t).document.documentElement
                    }(t)) {
                    var c = Math.round(a + o) - e,
                        l = Math.round(u + s) - n;
                    1 !== Math.abs(c) && (a -= c), 1 !== Math.abs(l) && (u -= l)
                }
                return y(r.left, r.top, a, u)
            }
            var v = "undefined" != typeof SVGGraphicsElement ? function(t) {
                return t instanceof d(t).SVGGraphicsElement
            } : function(t) {
                return t instanceof d(t).SVGElement && "function" == typeof t.getBBox
            };

            function g(t) {
                return r ? v(t) ? function(t) {
                    var e = t.getBBox();
                    return y(0, 0, e.width, e.height)
                }(t) : m(t) : h
            }

            function y(t, e, n, i) {
                return {
                    x: t,
                    y: e,
                    width: n,
                    height: i
                }
            }
            var b = function() {
                    function t(t) {
                        this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = y(0, 0, 0, 0), this.target = t
                    }
                    return t.prototype.isActive = function() {
                        var t = g(this.target);
                        return this.contentRect_ = t, t.width !== this.broadcastWidth || t.height !== this.broadcastHeight
                    }, t.prototype.broadcastRect = function() {
                        var t = this.contentRect_;
                        return this.broadcastWidth = t.width, this.broadcastHeight = t.height, t
                    }, t
                }(),
                x = function(t, e) {
                    var n, i, r, o, s, a, u, c = (i = (n = e).x, r = n.y, o = n.width, s = n.height, a = "undefined" != typeof DOMRectReadOnly ? DOMRectReadOnly : Object, u = Object.create(a.prototype), l(u, {
                        x: i,
                        y: r,
                        width: o,
                        height: s,
                        top: r,
                        right: i + o,
                        bottom: s + r,
                        left: i
                    }), u);
                    l(this, {
                        target: t,
                        contentRect: c
                    })
                },
                w = function() {
                    function t(t, e, n) {
                        if (this.activeObservations_ = [], this.observations_ = new i, "function" != typeof t) throw new TypeError("The callback provided as parameter 1 is not a function.");
                        this.callback_ = t, this.controller_ = e, this.callbackCtx_ = n
                    }
                    return t.prototype.observe = function(t) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if ("undefined" != typeof Element && Element instanceof Object) {
                            if (!(t instanceof d(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                            var e = this.observations_;
                            e.has(t) || (e.set(t, new b(t)), this.controller_.addObserver(this), this.controller_.refresh())
                        }
                    }, t.prototype.unobserve = function(t) {
                        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                        if ("undefined" != typeof Element && Element instanceof Object) {
                            if (!(t instanceof d(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                            var e = this.observations_;
                            e.has(t) && (e.delete(t), e.size || this.controller_.removeObserver(this))
                        }
                    }, t.prototype.disconnect = function() {
                        this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
                    }, t.prototype.gatherActive = function() {
                        var t = this;
                        this.clearActive(), this.observations_.forEach((function(e) {
                            e.isActive() && t.activeObservations_.push(e)
                        }))
                    }, t.prototype.broadcastActive = function() {
                        if (this.hasActive()) {
                            var t = this.callbackCtx_,
                                e = this.activeObservations_.map((function(t) {
                                    return new x(t.target, t.broadcastRect())
                                }));
                            this.callback_.call(t, e, t), this.clearActive()
                        }
                    }, t.prototype.clearActive = function() {
                        this.activeObservations_.splice(0)
                    }, t.prototype.hasActive = function() {
                        return this.activeObservations_.length > 0
                    }, t
                }(),
                P = "undefined" != typeof WeakMap ? new WeakMap : new i,
                E = function t(e) {
                    if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function.");
                    if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
                    var n = c.getInstance(),
                        i = new w(e, n, this);
                    P.set(this, i)
                };
            ["observe", "unobserve", "disconnect"].forEach((function(t) {
                E.prototype[t] = function() {
                    var e;
                    return (e = P.get(this))[t].apply(e, arguments)
                }
            }));
            var T = void 0 !== o.ResizeObserver ? o.ResizeObserver : E;
            e.Z = T
        },
        53950: function() {},
        17670: function() {},
        31532: function(t, e, n) {
            "use strict";

            function i(t) {
                return i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                }, i(t)
            }

            function r(t) {
                var e = function(t, e) {
                    if ("object" != i(t) || !t) return t;
                    var n = t[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var r = n.call(t, e || "default");
                        if ("object" != i(r)) return r;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === e ? String : Number)(t)
                }(t, "string");
                return "symbol" == i(e) ? e : e + ""
            }

            function o(t, e, n) {
                return (e = r(e)) in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            n.d(e, {
                Z: function() {
                    return o
                }
            })
        },
        62438: function(t, e, n) {
            "use strict";

            function i() {
                return i = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
                    }
                    return t
                }, i.apply(this, arguments)
            }
            n.d(e, {
                Z: function() {
                    return i
                }
            })
        },
        54343: function(t, e, n) {
            "use strict";

            function i() {
                return i = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var i in n)({}).hasOwnProperty.call(n, i) && (t[i] = n[i])
                    }
                    return t
                }, i.apply(null, arguments)
            }
            n.d(e, {
                Z: function() {
                    return i
                }
            })
        },
        14415: function(t, e, n) {
            "use strict";

            function i(t, e) {
                return i = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                    return t.__proto__ = e, t
                }, i(t, e)
            }

            function r(t, e) {
                t.prototype = Object.create(e.prototype), t.prototype.constructor = t, i(t, e)
            }
            n.d(e, {
                Z: function() {
                    return r
                }
            })
        },
        84268: function(t, e, n) {
            "use strict";

            function i(t, e) {
                if (null == t) return {};
                var n = {};
                for (var i in t)
                    if ({}.hasOwnProperty.call(t, i)) {
                        if (e.includes(i)) continue;
                        n[i] = t[i]
                    }
                return n
            }
            n.d(e, {
                Z: function() {
                    return i
                }
            })
        },
        7623: function(t, e, n) {
            "use strict";
            n.d(e, {
                D: function() {
                    return s
                }
            });
            var i = n(19114),
                r = n(29556),
                o = n(26740);

            function s(t, e, n) {
                const s = (0, r.i)(t) ? t : (0, i.BX)(t);
                return s.start((0, o.v)("", s, e, n)), s.animation
            }
        },
        82874: function(t, e, n) {
            "use strict";
            n.d(e, {
                v: function() {
                    return d
                }
            });
            var i = n(57440),
                r = n(95990),
                o = n(74940),
                s = n(37625),
                a = n(55251),
                u = n(32833);
            const c = (t, e) => "zIndex" !== e && (!("number" != typeof t && !Array.isArray(t)) || !("string" != typeof t || !u.P.test(t) && "0" !== t || t.startsWith("url(")));
            var l = n(36153);
            class d {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: n = "keyframes",
                    repeat: r = 0,
                    repeatDelay: o = 0,
                    repeatType: s = "loop",
                    ...a
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = i.X.now(), this.options = {
                        autoplay: t,
                        delay: e,
                        type: n,
                        repeat: r,
                        repeatDelay: o,
                        repeatType: s,
                        ...a
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (0, r.m)(), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.resolvedAt = i.X.now(), this.hasAttemptedResolve = !0;
                    const {
                        name: n,
                        type: r,
                        velocity: u,
                        delay: d,
                        onComplete: h,
                        onUpdate: f,
                        isGenerator: p
                    } = this.options;
                    if (!p && ! function(t, e, n, i) {
                            const r = t[0];
                            if (null === r) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            const o = t[t.length - 1],
                                u = c(r, e),
                                l = c(o, e);
                            return (0, a.K)(u === l, `You are trying to animate ${e} from "${r}" to "${o}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${o} via the \`style\` property.`), !(!u || !l) && (function(t) {
                                const e = t[0];
                                if (1 === t.length) return !0;
                                for (let n = 0; n < t.length; n++)
                                    if (t[n] !== e) return !0
                            }(t) || ("spring" === n || (0, s.xD)(n)) && i)
                        }(t, n, r, u)) {
                        if (o.c.current || !d) return f && f((0, l.$)(t, this.options, e)), h && h(), void this.resolveFinishedPromise();
                        this.options.duration = 0
                    }
                    const m = this.initPlayback(t, e);
                    !1 !== m && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...m
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                flatten() {
                    this.options.type = "keyframes", this.options.ease = "linear"
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise((t => {
                        this.resolveFinishedPromise = t
                    }))
                }
            }
        },
        17495: function(t, e, n) {
            "use strict";
            n.d(e, {
                s: function() {
                    return j
                },
                y: function() {
                    return L
                }
            });
            var i = n(37625),
                r = n(42772),
                o = n(95990),
                s = n(12807),
                a = n(84298),
                u = n(91052),
                c = n(18049),
                l = n(37593);

            function d({
                keyframes: t,
                velocity: e = 0,
                power: n = .8,
                timeConstant: i = 325,
                bounceDamping: r = 10,
                bounceStiffness: o = 500,
                modifyTarget: s,
                min: a,
                max: u,
                restDelta: d = .5,
                restSpeed: h
            }) {
                const f = t[0],
                    p = {
                        done: !1,
                        value: f
                    },
                    m = t => void 0 === a ? u : void 0 === u || Math.abs(a - t) < Math.abs(u - t) ? a : u;
                let v = n * e;
                const g = f + v,
                    y = void 0 === s ? g : s(g);
                y !== g && (v = y - f);
                const b = t => -v * Math.exp(-t / i),
                    x = t => y + b(t),
                    w = t => {
                        const e = b(t),
                            n = x(t);
                        p.done = Math.abs(e) <= d, p.value = p.done ? y : n
                    };
                let P, E;
                const T = t => {
                    var e;
                    (e = p.value, void 0 !== a && e < a || void 0 !== u && e > u) && (P = t, E = (0, c.S)({
                        keyframes: [p.value, m(p.value)],
                        velocity: (0, l.P)(x, t, p.value),
                        damping: r,
                        stiffness: o,
                        restDelta: d,
                        restSpeed: h
                    }))
                };
                return T(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return E || void 0 !== P || (e = !0, w(t), T(t)), void 0 !== P && t >= P ? E.next(t - P) : (!e && w(t), p)
                    }
                }
            }
            var h = n(44205);
            const f = (0, h._)(.42, 0, 1, 1),
                p = (0, h._)(0, 0, .58, 1),
                m = (0, h._)(.42, 0, .58, 1);
            var v = n(25794),
                g = n(89871),
                y = n(55251),
                b = n(78573),
                x = n(81890),
                w = n(56790);
            const P = {
                    linear: g.Z,
                    easeIn: f,
                    easeInOut: m,
                    easeOut: p,
                    circIn: w.Z7,
                    circInOut: w.X7,
                    circOut: w.Bn,
                    backIn: x.G2,
                    backInOut: x.XL,
                    backOut: x.CG,
                    anticipate: b.L
                },
                E = t => {
                    if ((0, i.qE)(t)) {
                        (0, y.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        const [e, n, i, r] = t;
                        return (0, h._)(e, n, i, r)
                    }
                    return "string" == typeof t ? ((0, y.k)(void 0 !== P[t], `Invalid easing type '${t}'`), P[t]) : t
                };
            var T = n(47729),
                S = n(48545);

            function M({
                duration: t = 300,
                keyframes: e,
                times: n,
                ease: i = "easeInOut"
            }) {
                const r = (0, v.N)(i) ? i.map(E) : E(i),
                    o = {
                        done: !1,
                        value: e[0]
                    },
                    s = function(t, e) {
                        return t.map((t => t * e))
                    }(n && n.length === e.length ? n : (0, S.Y)(e), t),
                    a = (0, T.s)(s, e, {
                        ease: Array.isArray(r) ? r : (u = e, c = r, u.map((() => c || m)).splice(0, u.length - 1))
                    });
                var u, c;
                return {
                    calculatedDuration: t,
                    next: e => (o.value = a(e), o.done = e >= t, o)
                }
            }
            var C = n(82874),
                D = n(57440),
                O = n(79120);
            const A = t => {
                const e = ({
                    timestamp: e
                }) => t(e);
                return {
                    start: () => O.Wi.update(e, !0),
                    stop: () => (0, O.Pn)(e),
                    now: () => O.frameData.isProcessing ? O.frameData.timestamp : D.X.now()
                }
            };
            var k = n(36153);
            const R = {
                    decay: d,
                    inertia: d,
                    tween: M,
                    keyframes: M,
                    spring: c.S
                },
                _ = t => t / 100;
            class j extends C.v {
                constructor(t) {
                    super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        const {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    const {
                        name: e,
                        motionValue: n,
                        element: i,
                        keyframes: r
                    } = this.options, s = (null == i ? void 0 : i.KeyframeResolver) || o.e;
                    this.resolver = new s(r, ((t, e) => this.onKeyframesResolved(t, e)), e, n, i), this.resolver.scheduleResolve()
                }
                flatten() {
                    super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
                }
                initPlayback(t) {
                    const {
                        type: e = "keyframes",
                        repeat: n = 0,
                        repeatDelay: r = 0,
                        repeatType: o,
                        velocity: s = 0
                    } = this.options, c = (0, i.xD)(e) ? e : R[e] || M;
                    let l, d;
                    c !== M && "number" != typeof t[0] && (l = (0, u.z)(_, (0, a.C)(t[0], t[1])), t = [0, 100]);
                    const h = c({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (d = c({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -s
                    })), null === h.calculatedDuration && (h.calculatedDuration = (0, i.iI)(h));
                    const {
                        calculatedDuration: f
                    } = h, p = f + r;
                    return {
                        generator: h,
                        mirroredGenerator: d,
                        mapPercentToKeyframes: l,
                        calculatedDuration: f,
                        resolvedDuration: p,
                        totalDuration: p * (n + 1) - r
                    }
                }
                onPostResolved() {
                    const {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    const {
                        resolved: n
                    } = this;
                    if (!n) {
                        const {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    const {
                        finalKeyframe: i,
                        generator: r,
                        mirroredGenerator: o,
                        mapPercentToKeyframes: a,
                        keyframes: u,
                        calculatedDuration: c,
                        totalDuration: l,
                        resolvedDuration: d
                    } = n;
                    if (null === this.startTime) return r.next(0);
                    const {
                        delay: h,
                        repeat: f,
                        repeatType: p,
                        repeatDelay: m,
                        onUpdate: v
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - l / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    const g = this.currentTime - h * (this.speed >= 0 ? 1 : -1),
                        y = this.speed >= 0 ? g < 0 : g > l;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = l);
                    let b = this.currentTime,
                        x = r;
                    if (f) {
                        const t = Math.min(this.currentTime, l) / d;
                        let e = Math.floor(t),
                            n = t % 1;
                        !n && t >= 1 && (n = 1), 1 === n && e--, e = Math.min(e, f + 1);
                        Boolean(e % 2) && ("reverse" === p ? (n = 1 - n, m && (n -= m / d)) : "mirror" === p && (x = o)), b = (0, s.u)(0, 1, n) * d
                    }
                    const w = y ? {
                        done: !1,
                        value: u[0]
                    } : x.next(b);
                    a && (w.value = a(w.value));
                    let {
                        done: P
                    } = w;
                    y || null === c || (P = this.speed >= 0 ? this.currentTime >= l : this.currentTime <= 0);
                    const E = null === this.holdTime && ("finished" === this.state || "running" === this.state && P);
                    return E && void 0 !== i && (w.value = (0, k.$)(u, this.options, i)), v && v(w.value), E && this.finish(), w
                }
                get duration() {
                    const {
                        resolved: t
                    } = this;
                    return t ? (0, r.X)(t.calculatedDuration) : 0
                }
                get time() {
                    return (0, r.X)(this.currentTime)
                }
                set time(t) {
                    t = (0, r.w)(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    const e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = (0, r.X)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) return void(this.pendingPlayState = "running");
                    if (this.isStopped) return;
                    const {
                        driver: t = A,
                        onPlay: e,
                        startTime: n
                    } = this.options;
                    this.driver || (this.driver = t((t => this.tick(t)))), e && e();
                    const i = this.driver.now();
                    null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = i) : this.startTime = null != n ? n : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    this._resolved ? (this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0) : this.pendingPlayState = "paused"
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    const {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }

            function L(t) {
                return new j(t)
            }
        },
        36153: function(t, e, n) {
            "use strict";
            n.d(e, {
                $: function() {
                    return r
                }
            });
            const i = t => null !== t;

            function r(t, {
                repeat: e,
                repeatType: n = "loop"
            }, r) {
                const o = t.filter(i),
                    s = e && "loop" !== n && e % 2 == 1 ? 0 : o.length - 1;
                return s && void 0 !== r ? r : o[s]
            }
        },
        18049: function(t, e, n) {
            "use strict";
            n.d(e, {
                S: function() {
                    return v
                }
            });
            var i = n(37625),
                r = n(42772),
                o = n(12807),
                s = n(37593);
            const a = {
                stiffness: 100,
                damping: 10,
                mass: 1,
                velocity: 0,
                duration: 800,
                bounce: .3,
                visualDuration: .3,
                restSpeed: {
                    granular: .01,
                    default: 2
                },
                restDelta: {
                    granular: .005,
                    default: .5
                },
                minDuration: .01,
                maxDuration: 10,
                minDamping: .05,
                maxDamping: 1
            };
            var u = n(55251);
            const c = .001;

            function l({
                duration: t = a.duration,
                bounce: e = a.bounce,
                velocity: n = a.velocity,
                mass: i = a.mass
            }) {
                let s, l;
                (0, u.K)(t <= (0, r.w)(a.maxDuration), "Spring duration must be 10 seconds or less");
                let f = 1 - e;
                f = (0, o.u)(a.minDamping, a.maxDamping, f), t = (0, o.u)(a.minDuration, a.maxDuration, (0, r.X)(t)), f < 1 ? (s = e => {
                    const i = e * f,
                        r = i * t,
                        o = i - n,
                        s = h(e, f),
                        a = Math.exp(-r);
                    return c - o / s * a
                }, l = e => {
                    const i = e * f * t,
                        r = i * n + n,
                        o = Math.pow(f, 2) * Math.pow(e, 2) * t,
                        a = Math.exp(-i),
                        u = h(Math.pow(e, 2), f);
                    return (-s(e) + c > 0 ? -1 : 1) * ((r - o) * a) / u
                }) : (s = e => Math.exp(-e * t) * ((e - n) * t + 1) - c, l = e => Math.exp(-e * t) * (t * t * (n - e)));
                const p = function(t, e, n) {
                    let i = n;
                    for (let n = 1; n < d; n++) i -= t(i) / e(i);
                    return i
                }(s, l, 5 / t);
                if (t = (0, r.w)(t), isNaN(p)) return {
                    stiffness: a.stiffness,
                    damping: a.damping,
                    duration: t
                }; {
                    const e = Math.pow(p, 2) * i;
                    return {
                        stiffness: e,
                        damping: 2 * f * Math.sqrt(i * e),
                        duration: t
                    }
                }
            }
            const d = 12;

            function h(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            const f = ["duration", "bounce"],
                p = ["stiffness", "damping", "mass"];

            function m(t, e) {
                return e.some((e => void 0 !== t[e]))
            }

            function v(t = a.visualDuration, e = a.bounce) {
                const n = "object" != typeof t ? {
                    visualDuration: t,
                    keyframes: [0, 1],
                    bounce: e
                } : t;
                let {
                    restSpeed: u,
                    restDelta: c
                } = n;
                const d = n.keyframes[0],
                    v = n.keyframes[n.keyframes.length - 1],
                    g = {
                        done: !1,
                        value: d
                    },
                    {
                        stiffness: y,
                        damping: b,
                        mass: x,
                        duration: w,
                        velocity: P,
                        isResolvedFromDuration: E
                    } = function(t) {
                        let e = {
                            velocity: a.velocity,
                            stiffness: a.stiffness,
                            damping: a.damping,
                            mass: a.mass,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!m(t, p) && m(t, f))
                            if (t.visualDuration) {
                                const n = t.visualDuration,
                                    i = 2 * Math.PI / (1.2 * n),
                                    r = i * i,
                                    s = 2 * (0, o.u)(.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(r);
                                e = { ...e,
                                    mass: a.mass,
                                    stiffness: r,
                                    damping: s
                                }
                            } else {
                                const n = l(t);
                                e = { ...e,
                                    ...n,
                                    mass: a.mass
                                }, e.isResolvedFromDuration = !0
                            }
                        return e
                    }({ ...n,
                        velocity: -(0, r.X)(n.velocity || 0)
                    }),
                    T = P || 0,
                    S = b / (2 * Math.sqrt(y * x)),
                    M = v - d,
                    C = (0, r.X)(Math.sqrt(y / x)),
                    D = Math.abs(M) < 5;
                let O;
                if (u || (u = D ? a.restSpeed.granular : a.restSpeed.default), c || (c = D ? a.restDelta.granular : a.restDelta.default), S < 1) {
                    const t = h(C, S);
                    O = e => {
                        const n = Math.exp(-S * C * e);
                        return v - n * ((T + S * C * M) / t * Math.sin(t * e) + M * Math.cos(t * e))
                    }
                } else if (1 === S) O = t => v - Math.exp(-C * t) * (M + (T + C * M) * t);
                else {
                    const t = C * Math.sqrt(S * S - 1);
                    O = e => {
                        const n = Math.exp(-S * C * e),
                            i = Math.min(t * e, 300);
                        return v - n * ((T + S * C * M) * Math.sinh(i) + t * M * Math.cosh(i)) / t
                    }
                }
                const A = {
                    calculatedDuration: E && w || null,
                    next: t => {
                        const e = O(t);
                        if (E) g.done = t >= w;
                        else {
                            let n = 0;
                            S < 1 && (n = 0 === t ? (0, r.w)(T) : (0, s.P)(O, t, e));
                            const i = Math.abs(n) <= u,
                                o = Math.abs(v - e) <= c;
                            g.done = i && o
                        }
                        return g.value = g.done ? v : e, g
                    },
                    toString: () => {
                        const t = Math.min((0, i.iI)(A), i.EO),
                            e = (0, i.wk)((e => A.next(t * e).value), t, 30);
                        return t + "ms " + e
                    }
                };
                return A
            }
        },
        37593: function(t, e, n) {
            "use strict";
            n.d(e, {
                P: function() {
                    return o
                }
            });
            var i = n(75426);
            const r = 5;

            function o(t, e, n) {
                const o = Math.max(e - r, 0);
                return (0, i.R)(n - t(o), e - o)
            }
        },
        26740: function(t, e, n) {
            "use strict";
            n.d(e, {
                v: function() {
                    return S
                }
            });
            var i = n(37625),
                r = n(42772),
                o = n(79120),
                s = n(37656),
                a = n(74940),
                u = n(89871),
                c = n(78573),
                l = n(81890),
                d = n(56790),
                h = n(3789),
                f = n(82874),
                p = n(17495);
            const m = new Set(["opacity", "clipPath", "filter", "transform"]);
            var v = n(36153);
            const g = (0, n(26654).X)((() => Object.hasOwnProperty.call(Element.prototype, "animate")));
            const y = {
                anticipate: c.L,
                backInOut: l.XL,
                circInOut: d.X7
            };
            class b extends f.v {
                constructor(t) {
                    super(t);
                    const {
                        name: e,
                        motionValue: n,
                        element: i,
                        keyframes: r
                    } = this.options;
                    this.resolver = new h.s(r, ((t, e) => this.onKeyframesResolved(t, e)), e, n, i), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    let {
                        duration: n = 300,
                        times: r,
                        ease: o,
                        type: s,
                        motionValue: a,
                        name: u,
                        startTime: c
                    } = this.options;
                    if (!a.owner || !a.owner.current) return !1;
                    var l;
                    if ("string" == typeof o && (0, i.Vc)() && o in y && (o = y[o]), l = this.options, (0, i.xD)(l.type) || "spring" === l.type || !(0, i.hR)(l.ease)) {
                        const {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: a,
                            element: u,
                            ...c
                        } = this.options, l = function(t, e) {
                            const n = new p.s({ ...e,
                                keyframes: t,
                                repeat: 0,
                                delay: 0,
                                isGenerator: !0
                            });
                            let i = {
                                done: !1,
                                value: t[0]
                            };
                            const r = [];
                            let o = 0;
                            for (; !i.done && o < 2e4;) i = n.sample(o), r.push(i.value), o += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: o - 10,
                                ease: "linear"
                            }
                        }(t, c);
                        1 === (t = l.keyframes).length && (t[1] = t[0]), n = l.duration, r = l.times, o = l.ease, s = "keyframes"
                    }
                    const d = function(t, e, n, {
                        delay: r = 0,
                        duration: o = 300,
                        repeat: s = 0,
                        repeatType: a = "loop",
                        ease: u = "easeInOut",
                        times: c
                    } = {}) {
                        const l = {
                            [e]: n
                        };
                        c && (l.offset = c);
                        const d = (0, i.eB)(u, o);
                        return Array.isArray(d) && (l.easing = d), t.animate(l, {
                            delay: r,
                            duration: o,
                            easing: Array.isArray(d) ? "linear" : d,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === a ? "alternate" : "normal"
                        })
                    }(a.owner.current, u, t, { ...this.options,
                        duration: n,
                        times: r,
                        ease: o
                    });
                    return d.startTime = null != c ? c : this.calcStartTime(), this.pendingTimeline ? ((0, i._F)(d, this.pendingTimeline), this.pendingTimeline = void 0) : d.onfinish = () => {
                        const {
                            onComplete: n
                        } = this.options;
                        a.set((0, v.$)(t, this.options, e)), n && n(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: d,
                        duration: n,
                        times: r,
                        type: s,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    const {
                        duration: e
                    } = t;
                    return (0, r.X)(e)
                }
                get time() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    const {
                        animation: e
                    } = t;
                    return (0, r.X)(e.currentTime || 0)
                }
                set time(t) {
                    const {
                        resolved: e
                    } = this;
                    if (!e) return;
                    const {
                        animation: n
                    } = e;
                    n.currentTime = (0, r.w)(t)
                }
                get speed() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    const {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    const {
                        resolved: e
                    } = this;
                    if (!e) return;
                    const {
                        animation: n
                    } = e;
                    n.playbackRate = t
                }
                get state() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    const {
                        animation: e
                    } = t;
                    return e.playState
                }
                get startTime() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return null;
                    const {
                        animation: e
                    } = t;
                    return e.startTime
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        const {
                            resolved: e
                        } = this;
                        if (!e) return u.Z;
                        const {
                            animation: n
                        } = e;
                        (0, i._F)(n, t)
                    } else this.pendingTimeline = t;
                    return u.Z
                }
                play() {
                    if (this.isStopped) return;
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    const {
                        resolved: t
                    } = this;
                    if (!t) return;
                    const {
                        animation: e,
                        keyframes: n,
                        duration: i,
                        type: o,
                        ease: s,
                        times: a
                    } = t;
                    if ("idle" === e.playState || "finished" === e.playState) return;
                    if (this.time) {
                        const {
                            motionValue: t,
                            onUpdate: e,
                            onComplete: u,
                            element: c,
                            ...l
                        } = this.options, d = new p.s({ ...l,
                            keyframes: n,
                            duration: i,
                            type: o,
                            ease: s,
                            times: a,
                            isGenerator: !0
                        }), h = (0, r.w)(this.time);
                        t.setWithVelocity(d.sample(h - 10).value, d.sample(h).value, 10)
                    }
                    const {
                        onStop: u
                    } = this.options;
                    u && u(), this.cancel()
                }
                complete() {
                    const {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    const {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    const {
                        motionValue: e,
                        name: n,
                        repeatDelay: i,
                        repeatType: r,
                        damping: o,
                        type: s
                    } = t;
                    if (!(e && e.owner && e.owner.current instanceof HTMLElement)) return !1;
                    const {
                        onUpdate: a,
                        transformTemplate: u
                    } = e.owner.getProps();
                    return g() && n && m.has(n) && !a && !u && !i && "mirror" !== r && 0 !== o && "inertia" !== s
                }
            }
            var x = n(11663);
            const w = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                P = {
                    type: "keyframes",
                    duration: .8
                },
                E = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                T = (t, {
                    keyframes: e
                }) => e.length > 2 ? P : x.G.has(t) ? t.startsWith("scale") ? {
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === e[1] ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                } : w : E;
            const S = (t, e, n, u = {}, c, l) => d => {
                const h = (0, i.ev)(u, t) || {},
                    f = h.delay || u.delay || 0;
                let {
                    elapsed: m = 0
                } = u;
                m -= (0, r.w)(f);
                let g = {
                    keyframes: Array.isArray(n) ? n : [null, n],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...h,
                    delay: -m,
                    onUpdate: t => {
                        e.set(t), h.onUpdate && h.onUpdate(t)
                    },
                    onComplete: () => {
                        d(), h.onComplete && h.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: l ? void 0 : c
                };
                (function({
                    when: t,
                    delay: e,
                    delayChildren: n,
                    staggerChildren: i,
                    staggerDirection: r,
                    repeat: o,
                    repeatType: s,
                    repeatDelay: a,
                    from: u,
                    elapsed: c,
                    ...l
                }) {
                    return !!Object.keys(l).length
                })(h) || (g = { ...g,
                    ...T(t, g)
                }), g.duration && (g.duration = (0, r.w)(g.duration)), g.repeatDelay && (g.repeatDelay = (0, r.w)(g.repeatDelay)), void 0 !== g.from && (g.keyframes[0] = g.from);
                let y = !1;
                if ((!1 === g.type || 0 === g.duration && !g.repeatDelay) && (g.duration = 0, 0 === g.delay && (y = !0)), (a.c.current || s.c.skipAnimations) && (y = !0, g.duration = 0, g.delay = 0), y && !l && void 0 !== e.get()) {
                    const t = (0, v.$)(g.keyframes, h);
                    if (void 0 !== t) return o.Wi.update((() => {
                        g.onUpdate(t), g.onComplete()
                    })), new i.sP([])
                }
                return !l && b.supports(g) ? new b(g) : new p.s(g)
            }
        },
        57460: function(t, e, n) {
            "use strict";
            n.d(e, {
                w: function() {
                    return d
                }
            });
            var i = n(37625),
                r = n(25040),
                o = n(23572),
                s = n(68138),
                a = n(87839),
                u = n(26740),
                c = n(79120);

            function l({
                protectedKeys: t,
                needsAnimating: e
            }, n) {
                const i = t.hasOwnProperty(n) && !0 !== e[n];
                return e[n] = !1, i
            }

            function d(t, e, {
                delay: n = 0,
                transitionOverride: d,
                type: h
            } = {}) {
                var f;
                let {
                    transition: p = t.getDefaultTransition(),
                    transitionEnd: m,
                    ...v
                } = e;
                d && (p = d);
                const g = [],
                    y = h && t.animationState && t.animationState.getState()[h];
                for (const e in v) {
                    const o = t.getValue(e, null !== (f = t.latestValues[e]) && void 0 !== f ? f : null),
                        d = v[e];
                    if (void 0 === d || y && l(y, e)) continue;
                    const h = {
                        delay: n,
                        ...(0, i.ev)(p || {}, e)
                    };
                    let m = !1;
                    if (window.MotionHandoffAnimation) {
                        const n = (0, a.s)(t);
                        if (n) {
                            const t = window.MotionHandoffAnimation(n, e, c.Wi);
                            null !== t && (h.startTime = t, m = !0)
                        }
                    }(0, s.K)(t, e), o.start((0, u.v)(e, o, d, t.shouldReduceMotion && r.z.has(e) ? {
                        type: !1
                    } : h, t, m));
                    const b = o.animation;
                    b && g.push(b)
                }
                return m && Promise.all(g).then((() => {
                    c.Wi.update((() => {
                        m && (0, o.C)(t, m)
                    }))
                })), g
            }
        },
        48819: function(t, e, n) {
            "use strict";
            n.d(e, {
                d: function() {
                    return a
                }
            });
            var i = n(96984),
                r = n(57460);

            function o(t, e, n = {}) {
                var a;
                const u = (0, i.x)(t, e, "exit" === n.type ? null === (a = t.presenceContext) || void 0 === a ? void 0 : a.custom : void 0);
                let {
                    transition: c = t.getDefaultTransition() || {}
                } = u || {};
                n.transitionOverride && (c = n.transitionOverride);
                const l = u ? () => Promise.all((0, r.w)(t, u, n)) : () => Promise.resolve(),
                    d = t.variantChildren && t.variantChildren.size ? (i = 0) => {
                        const {
                            delayChildren: r = 0,
                            staggerChildren: a,
                            staggerDirection: u
                        } = c;
                        return function(t, e, n = 0, i = 0, r = 1, a) {
                            const u = [],
                                c = (t.variantChildren.size - 1) * i,
                                l = 1 === r ? (t = 0) => t * i : (t = 0) => c - t * i;
                            return Array.from(t.variantChildren).sort(s).forEach(((t, i) => {
                                t.notify("AnimationStart", e), u.push(o(t, e, { ...a,
                                    delay: n + l(i)
                                }).then((() => t.notify("AnimationComplete", e))))
                            })), Promise.all(u)
                        }(t, e, r + i, a, u, n)
                    } : () => Promise.resolve(),
                    {
                        when: h
                    } = c;
                if (h) {
                    const [t, e] = "beforeChildren" === h ? [l, d] : [d, l];
                    return t().then((() => e()))
                }
                return Promise.all([l(), d(n.delay)])
            }

            function s(t, e) {
                return t.sortNodePosition(e)
            }

            function a(t, e, n = {}) {
                let s;
                if (t.notify("AnimationStart", e), Array.isArray(e)) {
                    const i = e.map((e => o(t, e, n)));
                    s = Promise.all(i)
                } else if ("string" == typeof e) s = o(t, e, n);
                else {
                    const o = "function" == typeof e ? (0, i.x)(t, e, n.custom) : e;
                    s = Promise.all((0, r.w)(t, o, n))
                }
                return s.then((() => {
                    t.notify("AnimationComplete", e)
                }))
            }
        },
        5624: function(t, e, n) {
            "use strict";
            n.d(e, {
                M: function() {
                    return i
                }
            });
            const i = "data-" + (0, n(38207).D)("framerAppearId")
        },
        87839: function(t, e, n) {
            "use strict";
            n.d(e, {
                s: function() {
                    return r
                }
            });
            var i = n(5624);

            function r(t) {
                return t.props[i.M]
            }
        },
        32242: function(t, e, n) {
            "use strict";

            function i(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
            n.d(e, {
                H: function() {
                    return i
                }
            })
        },
        3967: function(t, e, n) {
            "use strict";
            n.d(e, {
                C: function() {
                    return i
                }
            });
            const i = t => Array.isArray(t)
        },
        16331: function(t, e, n) {
            "use strict";
            n.d(e, {
                M: function() {
                    return g
                }
            });
            var i = n(75467),
                r = n(84371),
                o = n(50566),
                s = n(86534),
                a = n(89466),
                u = n(48460);
            class c extends r.Component {
                getSnapshotBeforeUpdate(t) {
                    const e = this.props.childRef.current;
                    if (e && t.isPresent && !this.props.isPresent) {
                        const t = this.props.sizeRef.current;
                        t.height = e.offsetHeight || 0, t.width = e.offsetWidth || 0, t.top = e.offsetTop, t.left = e.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function l(t) {
                let {
                    children: e,
                    isPresent: n
                } = t;
                const o = (0, r.useId)(),
                    s = (0, r.useRef)(null),
                    a = (0, r.useRef)({
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0
                    }),
                    {
                        nonce: l
                    } = (0, r.useContext)(u._);
                return (0, r.useInsertionEffect)((() => {
                    const {
                        width: t,
                        height: e,
                        top: i,
                        left: r
                    } = a.current;
                    if (n || !s.current || !t || !e) return;
                    s.current.dataset.motionPopId = o;
                    const u = document.createElement("style");
                    return l && (u.nonce = l), document.head.appendChild(u), u.sheet && u.sheet.insertRule('\n          [data-motion-pop-id="'.concat(o, '"] {\n            position: absolute !important;\n            width: ').concat(t, "px !important;\n            height: ").concat(e, "px !important;\n            top: ").concat(i, "px !important;\n            left: ").concat(r, "px !important;\n          }\n        ")), () => {
                        document.head.removeChild(u)
                    }
                }), [n]), (0, i.jsx)(c, {
                    isPresent: n,
                    childRef: s,
                    sizeRef: a,
                    children: r.cloneElement(e, {
                        ref: s
                    })
                })
            }
            const d = t => {
                let {
                    children: e,
                    initial: n,
                    isPresent: o,
                    onExitComplete: u,
                    custom: c,
                    presenceAffectsLayout: d,
                    mode: f
                } = t;
                const p = (0, s.h)(h),
                    m = (0, r.useId)(),
                    v = (0, r.useCallback)((t => {
                        p.set(t, !0);
                        for (const t of p.values())
                            if (!t) return;
                        u && u()
                    }), [p, u]),
                    g = (0, r.useMemo)((() => ({
                        id: m,
                        initial: n,
                        isPresent: o,
                        custom: c,
                        onExitComplete: v,
                        register: t => (p.set(t, !1), () => p.delete(t))
                    })), d ? [Math.random(), v] : [o, v]);
                return (0, r.useMemo)((() => {
                    p.forEach(((t, e) => p.set(e, !1)))
                }), [o]), r.useEffect((() => {
                    !o && !p.size && u && u()
                }), [o]), "popLayout" === f && (e = (0, i.jsx)(l, {
                    isPresent: o,
                    children: e
                })), (0, i.jsx)(a.O.Provider, {
                    value: g,
                    children: e
                })
            };

            function h() {
                return new Map
            }
            var f = n(67766);
            const p = t => t.key || "";

            function m(t) {
                const e = [];
                return r.Children.forEach(t, (t => {
                    (0, r.isValidElement)(t) && e.push(t)
                })), e
            }
            var v = n(69682);
            const g = t => {
                let {
                    children: e,
                    custom: n,
                    initial: a = !0,
                    onExitComplete: u,
                    presenceAffectsLayout: c = !0,
                    mode: l = "sync",
                    propagate: h = !1
                } = t;
                const [g, y] = (0, f.oO)(h), b = (0, r.useMemo)((() => m(e)), [e]), x = h && !g ? [] : b.map(p), w = (0, r.useRef)(!0), P = (0, r.useRef)(b), E = (0, s.h)((() => new Map)), [T, S] = (0, r.useState)(b), [M, C] = (0, r.useState)(b);
                (0, v.L)((() => {
                    w.current = !1, P.current = b;
                    for (let t = 0; t < M.length; t++) {
                        const e = p(M[t]);
                        x.includes(e) ? E.delete(e) : !0 !== E.get(e) && E.set(e, !1)
                    }
                }), [M, x.length, x.join("-")]);
                const D = [];
                if (b !== T) {
                    let t = [...b];
                    for (let e = 0; e < M.length; e++) {
                        const n = M[e],
                            i = p(n);
                        x.includes(i) || (t.splice(e, 0, n), D.push(n))
                    }
                    return "wait" === l && D.length && (t = D), C(m(t)), void S(b)
                }
                const {
                    forceRender: O
                } = (0, r.useContext)(o.p);
                return (0, i.jsx)(i.Fragment, {
                    children: M.map((t => {
                        const e = p(t),
                            r = !(h && !g) && (b === M || x.includes(e));
                        return (0, i.jsx)(d, {
                            isPresent: r,
                            initial: !(w.current && !a) && void 0,
                            custom: r ? void 0 : n,
                            presenceAffectsLayout: c,
                            mode: l,
                            onExitComplete: r ? void 0 : () => {
                                if (!E.has(e)) return;
                                E.set(e, !0);
                                let t = !0;
                                E.forEach((e => {
                                    e || (t = !1)
                                })), t && (null == O || O(), C(P.current), h && (null == y || y()), u && u())
                            },
                            children: t
                        }, e)
                    }))
                })
            }
        },
        67766: function(t, e, n) {
            "use strict";
            n.d(e, {
                oO: function() {
                    return o
                }
            });
            var i = n(84371),
                r = n(89466);

            function o(t = !0) {
                const e = (0, i.useContext)(r.O);
                if (null === e) return [!0, null];
                const {
                    isPresent: n,
                    onExitComplete: o,
                    register: s
                } = e, a = (0, i.useId)();
                (0, i.useEffect)((() => {
                    t && s(a)
                }), [t]);
                const u = (0, i.useCallback)((() => t && o && o(a)), [a, o, t]);
                return !n && o ? [!1, u] : [!0]
            }
        },
        50566: function(t, e, n) {
            "use strict";
            n.d(e, {
                p: function() {
                    return i
                }
            });
            const i = (0, n(84371).createContext)({})
        },
        48460: function(t, e, n) {
            "use strict";
            n.d(e, {
                _: function() {
                    return i
                }
            });
            const i = (0, n(84371).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        89466: function(t, e, n) {
            "use strict";
            n.d(e, {
                O: function() {
                    return i
                }
            });
            const i = (0, n(84371).createContext)(null)
        },
        78573: function(t, e, n) {
            "use strict";
            n.d(e, {
                L: function() {
                    return r
                }
            });
            var i = n(81890);
            const r = t => (t *= 2) < 1 ? .5 * (0, i.G2)(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
        },
        81890: function(t, e, n) {
            "use strict";
            n.d(e, {
                CG: function() {
                    return s
                },
                G2: function() {
                    return a
                },
                XL: function() {
                    return u
                }
            });
            var i = n(44205),
                r = n(64892),
                o = n(53148);
            const s = (0, i._)(.33, 1.53, .69, .99),
                a = (0, o.M)(s),
                u = (0, r.o)(a)
        },
        56790: function(t, e, n) {
            "use strict";
            n.d(e, {
                Bn: function() {
                    return s
                },
                X7: function() {
                    return a
                },
                Z7: function() {
                    return o
                }
            });
            var i = n(64892),
                r = n(53148);
            const o = t => 1 - Math.sin(Math.acos(t)),
                s = (0, r.M)(o),
                a = (0, i.o)(o)
        },
        44205: function(t, e, n) {
            "use strict";
            n.d(e, {
                _: function() {
                    return a
                }
            });
            var i = n(89871);
            const r = (t, e, n) => (((1 - 3 * n + 3 * e) * t + (3 * n - 6 * e)) * t + 3 * e) * t,
                o = 1e-7,
                s = 12;

            function a(t, e, n, a) {
                if (t === e && n === a) return i.Z;
                const u = e => function(t, e, n, i, a) {
                    let u, c, l = 0;
                    do {
                        c = e + (n - e) / 2, u = r(c, i, a) - t, u > 0 ? n = c : e = c
                    } while (Math.abs(u) > o && ++l < s);
                    return c
                }(e, 0, 1, t, n);
                return t => 0 === t || 1 === t ? t : r(u(t), e, a)
            }
        },
        64892: function(t, e, n) {
            "use strict";
            n.d(e, {
                o: function() {
                    return i
                }
            });
            const i = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2
        },
        53148: function(t, e, n) {
            "use strict";
            n.d(e, {
                M: function() {
                    return i
                }
            });
            const i = t => e => 1 - t(1 - e)
        },
        25794: function(t, e, n) {
            "use strict";
            n.d(e, {
                N: function() {
                    return i
                }
            });
            const i = t => Array.isArray(t) && "number" != typeof t[0]
        },
        21533: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return s
                }
            });
            var i = n(37656);
            const r = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"],
                o = 40;

            function s(t, e) {
                let n = !1,
                    s = !0;
                const a = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    u = () => n = !0,
                    c = r.reduce(((t, e) => (t[e] = function(t) {
                        let e = new Set,
                            n = new Set,
                            i = !1,
                            r = !1;
                        const o = new WeakSet;
                        let s = {
                            delta: 0,
                            timestamp: 0,
                            isProcessing: !1
                        };

                        function a(e) {
                            o.has(e) && (u.schedule(e), t()), e(s)
                        }
                        const u = {
                            schedule: (t, r = !1, s = !1) => {
                                const a = s && i ? e : n;
                                return r && o.add(t), a.has(t) || a.add(t), t
                            },
                            cancel: t => {
                                n.delete(t), o.delete(t)
                            },
                            process: t => {
                                s = t, i ? r = !0 : (i = !0, [e, n] = [n, e], e.forEach(a), e.clear(), i = !1, r && (r = !1, u.process(t)))
                            }
                        };
                        return u
                    }(u), t)), {}),
                    {
                        read: l,
                        resolveKeyframes: d,
                        update: h,
                        preRender: f,
                        render: p,
                        postRender: m
                    } = c,
                    v = () => {
                        const r = i.c.useManualTiming ? a.timestamp : performance.now();
                        n = !1, a.delta = s ? 1e3 / 60 : Math.max(Math.min(r - a.timestamp, o), 1), a.timestamp = r, a.isProcessing = !0, l.process(a), d.process(a), h.process(a), f.process(a), p.process(a), m.process(a), a.isProcessing = !1, n && e && (s = !1, t(v))
                    };
                return {
                    schedule: r.reduce(((e, i) => {
                        const r = c[i];
                        return e[i] = (e, i = !1, o = !1) => (n || (n = !0, s = !0, a.isProcessing || t(v)), r.schedule(e, i, o)), e
                    }), {}),
                    cancel: t => {
                        for (let e = 0; e < r.length; e++) c[r[e]].cancel(t)
                    },
                    state: a,
                    steps: c
                }
            }
        },
        79120: function(t, e, n) {
            "use strict";
            n.d(e, {
                Pn: function() {
                    return s
                },
                Wi: function() {
                    return o
                },
                frameData: function() {
                    return a
                },
                yL: function() {
                    return u
                }
            });
            var i = n(89871),
                r = n(21533);
            const {
                schedule: o,
                cancel: s,
                state: a,
                steps: u
            } = (0, r.Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : i.Z, !0)
        },
        57440: function(t, e, n) {
            "use strict";
            n.d(e, {
                X: function() {
                    return a
                }
            });
            var i = n(37656),
                r = n(79120);
            let o;

            function s() {
                o = void 0
            }
            const a = {
                now: () => (void 0 === o && a.set(r.frameData.isProcessing || i.c.useManualTiming ? r.frameData.timestamp : performance.now()), o),
                set: t => {
                    o = t, queueMicrotask(s)
                }
            }
        },
        24617: function(t, e, n) {
            "use strict";
            n.d(e, {
                featureDefinitions: function() {
                    return r
                }
            });
            const i = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                r = {};
            for (const t in i) r[t] = {
                isEnabled: e => i[t].some((t => !!e[t]))
            }
        },
        7892: function(t, e, n) {
            "use strict";
            n.d(e, {
                j: function() {
                    return o
                }
            });
            var i = n(24779),
                r = n(11663);

            function o(t, {
                layout: e,
                layoutId: n
            }) {
                return r.G.has(t) || t.startsWith("origin") || (e || void 0 !== n) && (!!i.P[t] || "opacity" === t)
            }
        },
        62483: function(t, e, n) {
            "use strict";

            function i({
                top: t,
                left: e,
                right: n,
                bottom: i
            }) {
                return {
                    x: {
                        min: e,
                        max: n
                    },
                    y: {
                        min: t,
                        max: i
                    }
                }
            }

            function r({
                x: t,
                y: e
            }) {
                return {
                    top: e.min,
                    right: t.max,
                    bottom: e.max,
                    left: t.min
                }
            }

            function o(t, e) {
                if (!e) return t;
                const n = e({
                        x: t.left,
                        y: t.top
                    }),
                    i = e({
                        x: t.right,
                        y: t.bottom
                    });
                return {
                    top: n.y,
                    left: n.x,
                    bottom: i.y,
                    right: i.x
                }
            }
            n.d(e, {
                d7: function() {
                    return o
                },
                i8: function() {
                    return i
                },
                z2: function() {
                    return r
                }
            })
        },
        58344: function(t, e, n) {
            "use strict";
            n.d(e, {
                D2: function() {
                    return p
                },
                YY: function() {
                    return d
                },
                am: function() {
                    return h
                },
                o2: function() {
                    return u
                },
                q2: function() {
                    return o
                }
            });
            var i = n(17837),
                r = n(9371);

            function o(t, e, n) {
                return n + e * (t - n)
            }

            function s(t, e, n, i, r) {
                return void 0 !== r && (t = o(t, r, i)), o(t, n, i) + e
            }

            function a(t, e = 0, n = 1, i, r) {
                t.min = s(t.min, e, n, i, r), t.max = s(t.max, e, n, i, r)
            }

            function u(t, {
                x: e,
                y: n
            }) {
                a(t.x, e.translate, e.scale, e.originPoint), a(t.y, n.translate, n.scale, n.originPoint)
            }
            const c = .999999999999,
                l = 1.0000000000001;

            function d(t, e, n, i = !1) {
                const o = n.length;
                if (!o) return;
                let s, a;
                e.x = e.y = 1;
                for (let c = 0; c < o; c++) {
                    s = n[c], a = s.projectionDelta;
                    const {
                        visualElement: o
                    } = s.options;
                    o && o.props.style && "contents" === o.props.style.display || (i && s.options.layoutScroll && s.scroll && s !== s.root && p(t, {
                        x: -s.scroll.offset.x,
                        y: -s.scroll.offset.y
                    }), a && (e.x *= a.x.scale, e.y *= a.y.scale, u(t, a)), i && (0, r.ud)(s.latestValues) && p(t, s.latestValues))
                }
                e.x < l && e.x > c && (e.x = 1), e.y < l && e.y > c && (e.y = 1)
            }

            function h(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function f(t, e, n, r, o = .5) {
                a(t, e, n, (0, i.t)(t.min, t.max, o), r)
            }

            function p(t, e) {
                f(t.x, e.x, e.scaleX, e.scale, e.originX), f(t.y, e.y, e.scaleY, e.scale, e.originY)
            }
        },
        63431: function(t, e, n) {
            "use strict";
            n.d(e, {
                dO: function() {
                    return r
                },
                wc: function() {
                    return i
                }
            });
            const i = () => ({
                    x: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    },
                    y: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    }
                }),
                r = () => ({
                    x: {
                        min: 0,
                        max: 0
                    },
                    y: {
                        min: 0,
                        max: 0
                    }
                })
        },
        24779: function(t, e, n) {
            "use strict";
            n.d(e, {
                B: function() {
                    return r
                },
                P: function() {
                    return i
                }
            });
            const i = {};

            function r(t) {
                Object.assign(i, t)
            }
        },
        9371: function(t, e, n) {
            "use strict";

            function i(t) {
                return void 0 === t || 1 === t
            }

            function r({
                scale: t,
                scaleX: e,
                scaleY: n
            }) {
                return !i(t) || !i(e) || !i(n)
            }

            function o(t) {
                return r(t) || s(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function s(t) {
                return a(t.x) || a(t.y)
            }

            function a(t) {
                return t && "0%" !== t
            }
            n.d(e, {
                D_: function() {
                    return s
                },
                Lj: function() {
                    return r
                },
                ud: function() {
                    return o
                }
            })
        },
        81510: function(t, e, n) {
            "use strict";
            n.d(e, {
                J: function() {
                    return o
                },
                z: function() {
                    return s
                }
            });
            var i = n(62483),
                r = n(58344);

            function o(t, e) {
                return (0, i.i8)((0, i.d7)(t.getBoundingClientRect(), e))
            }

            function s(t, e, n) {
                const i = o(t, n),
                    {
                        scroll: s
                    } = e;
                return s && ((0, r.am)(i.x, s.offset.x), (0, r.am)(i.y, s.offset.y)), i
            }
        },
        27035: function(t, e, n) {
            "use strict";
            n.d(e, {
                l: function() {
                    return C
                }
            });
            var i = n(57440),
                r = n(24617),
                o = n(63431),
                s = n(51767),
                a = n(11264),
                u = n(43377);
            const c = {
                    current: null
                },
                l = {
                    current: !1
                };
            var d = n(57135),
                h = n(19114),
                f = n(32833),
                p = n(29556),
                m = n(55253),
                v = n(96721),
                g = n(78571),
                y = n(79591);
            const b = [...g.$, v.$, f.P];
            var x = n(11663),
                w = n(69202),
                P = n(74173),
                E = n(95990);
            var T = n(93723),
                S = n(79120);
            const M = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class C {
                scrapeMotionValuesFromProps(t, e, n) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: n,
                    reducedMotionConfig: r,
                    blockInitialAnimation: o,
                    visualState: s
                }, a = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = E.e, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        const t = i.X.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, S.Wi.render(this.render, !1, !0))
                    };
                    const {
                        latestValues: u,
                        renderState: c,
                        onUpdate: l
                    } = s;
                    this.onUpdate = l, this.latestValues = u, this.baseTarget = { ...u
                    }, this.initialValues = e.initial ? { ...u
                    } : {}, this.renderState = c, this.parent = t, this.props = e, this.presenceContext = n, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = r, this.options = a, this.blockInitialAnimation = Boolean(o), this.isControllingVariants = (0, P.G)(e), this.isVariantNode = (0, P.M)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = Boolean(t && t.current);
                    const {
                        willChange: d,
                        ...h
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (const t in h) {
                        const e = h[t];
                        void 0 !== u[t] && (0, p.i)(e) && e.set(u[t], !1)
                    }
                }
                mount(t) {
                    this.current = t, w.R.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach(((t, e) => this.bindToMotionValue(e, t))), l.current || function() {
                        if (l.current = !0, u.j)
                            if (window.matchMedia) {
                                const t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => c.current = t.matches;
                                t.addListener(e), e()
                            } else c.current = !1
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || c.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    w.R.delete(this.current), this.projection && this.projection.unmount(), (0, S.Pn)(this.notifyUpdate), (0, S.Pn)(this.render), this.valueSubscriptions.forEach((t => t())), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
                    for (const t in this.events) this.events[t].clear();
                    for (const t in this.features) {
                        const e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
                    const n = x.G.has(t),
                        i = e.on("change", (e => {
                            this.latestValues[t] = e, this.props.onUpdate && S.Wi.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0)
                        })),
                        r = e.on("renderRequest", this.scheduleRender);
                    let o;
                    window.MotionCheckAppearSync && (o = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, (() => {
                        i(), r(), o && o(), e.owner && e.stop()
                    }))
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in r.featureDefinitions) {
                        const e = r.featureDefinitions[t];
                        if (!e) continue;
                        const {
                            isEnabled: n,
                            Feature: i
                        } = e;
                        if (!this.features[t] && i && n(this.props) && (this.features[t] = new i(this)), this.features[t]) {
                            const e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : (0, o.dO)()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < M.length; e++) {
                        const n = M[e];
                        this.propEventSubscriptions[n] && (this.propEventSubscriptions[n](), delete this.propEventSubscriptions[n]);
                        const i = t["on" + n];
                        i && (this.propEventSubscriptions[n] = this.on(n, i))
                    }
                    this.prevMotionValues = function(t, e, n) {
                        for (const i in e) {
                            const r = e[i],
                                o = n[i];
                            if ((0, p.i)(r)) t.addValue(i, r);
                            else if ((0, p.i)(o)) t.addValue(i, (0, h.BX)(r, {
                                owner: t
                            }));
                            else if (o !== r)
                                if (t.hasValue(i)) {
                                    const e = t.getValue(i);
                                    !0 === e.liveStyle ? e.jump(r) : e.hasAnimated || e.set(r)
                                } else {
                                    const e = t.getStaticValue(i);
                                    t.addValue(i, (0, h.BX)(void 0 !== e ? e : r, {
                                        owner: t
                                    }))
                                }
                        }
                        for (const i in n) void 0 === e[i] && t.removeValue(i);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue(), this.onUpdate && this.onUpdate(this)
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    const e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    const n = this.values.get(t);
                    e !== n && (n && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    const e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let n = this.values.get(t);
                    return void 0 === n && void 0 !== e && (n = (0, h.BX)(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, n)), n
                }
                readValue(t, e) {
                    var n;
                    let i = void 0 === this.latestValues[t] && this.current ? null !== (n = this.getBaseTargetFromProps(this.props, t)) && void 0 !== n ? n : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    var r;
                    return null != i && ("string" == typeof i && ((0, s.P)(i) || (0, a.W)(i)) ? i = parseFloat(i) : (r = i, !b.find((0, y.l)(r)) && f.P.test(e) && (i = (0, m.T)(t, e))), this.setBaseTarget(t, (0, p.i)(i) ? i.get() : i)), (0, p.i)(i) ? i.get() : i
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    const {
                        initial: n
                    } = this.props;
                    let i;
                    if ("string" == typeof n || "object" == typeof n) {
                        const r = (0, T.o)(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        r && (i = r[t])
                    }
                    if (n && void 0 !== i) return i;
                    const r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || (0, p.i)(r) ? void 0 !== this.initialValues[t] && void 0 === i ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new d.L), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
        },
        42140: function(t, e, n) {
            "use strict";

            function i(t) {
                if ("undefined" == typeof Proxy) return t;
                const e = new Map;
                return new Proxy(((...e) => t(...e)), {
                    get: (n, i) => "create" === i ? t : (e.has(i) || e.set(i, t(i)), e.get(i))
                })
            }
            n.d(e, {
                E: function() {
                    return Jn
                }
            });
            var r = n(32242),
                o = n(3967);

            function s(t, e) {
                if (!Array.isArray(e)) return !1;
                const n = e.length;
                if (n !== t.length) return !1;
                for (let i = 0; i < n; i++)
                    if (e[i] !== t[i]) return !1;
                return !0
            }
            var a = n(12182),
                u = n(96984),
                c = n(86324),
                l = n(48819);
            const d = c.V.length;

            function h(t) {
                if (!t) return;
                if (!t.isControllingVariants) {
                    const e = t.parent && h(t.parent) || {};
                    return void 0 !== t.props.initial && (e.initial = t.props.initial), e
                }
                const e = {};
                for (let n = 0; n < d; n++) {
                    const i = c.V[n],
                        r = t.props[i];
                    ((0, a.$)(r) || !1 === r) && (e[i] = r)
                }
                return e
            }
            const f = [...c.e].reverse(),
                p = c.e.length;

            function m(t) {
                let e = function(t) {
                        return e => Promise.all(e.map((({
                            animation: e,
                            options: n
                        }) => (0, l.d)(t, e, n))))
                    }(t),
                    n = y(),
                    i = !0;
                const c = e => (n, i) => {
                    var r;
                    const o = (0, u.x)(t, i, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                    if (o) {
                        const {
                            transition: t,
                            transitionEnd: e,
                            ...i
                        } = o;
                        n = { ...n,
                            ...i,
                            ...e
                        }
                    }
                    return n
                };

                function d(u) {
                    const {
                        props: l
                    } = t, d = h(t.parent) || {}, m = [], g = new Set;
                    let y = {},
                        b = 1 / 0;
                    for (let e = 0; e < p; e++) {
                        const h = f[e],
                            p = n[h],
                            x = void 0 !== l[h] ? l[h] : d[h],
                            w = (0, a.$)(x),
                            P = h === u ? p.isActive : null;
                        !1 === P && (b = e);
                        let E = x === d[h] && x !== l[h] && w;
                        if (E && i && t.manuallyAnimateOnMount && (E = !1), p.protectedKeys = { ...y
                            }, !p.isActive && null === P || !x && !p.prevProp || (0, r.H)(x) || "boolean" == typeof x) continue;
                        const T = v(p.prevProp, x);
                        let S = T || h === u && p.isActive && !E && w || e > b && w,
                            M = !1;
                        const C = Array.isArray(x) ? x : [x];
                        let D = C.reduce(c(h), {});
                        !1 === P && (D = {});
                        const {
                            prevResolvedValues: O = {}
                        } = p, A = { ...O,
                            ...D
                        }, k = e => {
                            S = !0, g.has(e) && (M = !0, g.delete(e)), p.needsAnimating[e] = !0;
                            const n = t.getValue(e);
                            n && (n.liveStyle = !1)
                        };
                        for (const t in A) {
                            const e = D[t],
                                n = O[t];
                            if (y.hasOwnProperty(t)) continue;
                            let i = !1;
                            i = (0, o.C)(e) && (0, o.C)(n) ? !s(e, n) : e !== n, i ? null != e ? k(t) : g.add(t) : void 0 !== e && g.has(t) ? k(t) : p.protectedKeys[t] = !0
                        }
                        p.prevProp = x, p.prevResolvedValues = D, p.isActive && (y = { ...y,
                            ...D
                        }), i && t.blockInitialAnimation && (S = !1);
                        S && (!(E && T) || M) && m.push(...C.map((t => ({
                            animation: t,
                            options: {
                                type: h
                            }
                        }))))
                    }
                    if (g.size) {
                        const e = {};
                        g.forEach((n => {
                            const i = t.getBaseTarget(n),
                                r = t.getValue(n);
                            r && (r.liveStyle = !0), e[n] = null != i ? i : null
                        })), m.push({
                            animation: e
                        })
                    }
                    let x = Boolean(m.length);
                    return !i || !1 !== l.initial && l.initial !== l.animate || t.manuallyAnimateOnMount || (x = !1), i = !1, x ? e(m) : Promise.resolve()
                }
                return {
                    animateChanges: d,
                    setActive: function(e, i) {
                        var r;
                        if (n[e].isActive === i) return Promise.resolve();
                        null === (r = t.variantChildren) || void 0 === r || r.forEach((t => {
                            var n;
                            return null === (n = t.animationState) || void 0 === n ? void 0 : n.setActive(e, i)
                        })), n[e].isActive = i;
                        const o = d(e);
                        for (const t in n) n[t].protectedKeys = {};
                        return o
                    },
                    setAnimateFunction: function(n) {
                        e = n(t)
                    },
                    getState: () => n,
                    reset: () => {
                        n = y(), i = !0
                    }
                }
            }

            function v(t, e) {
                return "string" == typeof e ? e !== t : !!Array.isArray(e) && !s(e, t)
            }

            function g(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function y() {
                return {
                    animate: g(!0),
                    whileInView: g(),
                    whileHover: g(),
                    whileTap: g(),
                    whileDrag: g(),
                    whileFocus: g(),
                    exit: g()
                }
            }
            class b {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
            let x = 0;
            const w = {
                animation: {
                    Feature: class extends b {
                        constructor(t) {
                            super(t), t.animationState || (t.animationState = m(t))
                        }
                        updateAnimationControlsSubscription() {
                            const {
                                animate: t
                            } = this.node.getProps();
                            (0, r.H)(t) && (this.unmountControls = t.subscribe(this.node))
                        }
                        mount() {
                            this.updateAnimationControlsSubscription()
                        }
                        update() {
                            const {
                                animate: t
                            } = this.node.getProps(), {
                                animate: e
                            } = this.node.prevProps || {};
                            t !== e && this.updateAnimationControlsSubscription()
                        }
                        unmount() {
                            var t;
                            this.node.animationState.reset(), null === (t = this.unmountControls) || void 0 === t || t.call(this)
                        }
                    }
                },
                exit: {
                    Feature: class extends b {
                        constructor() {
                            super(...arguments), this.id = x++
                        }
                        update() {
                            if (!this.node.presenceContext) return;
                            const {
                                isPresent: t,
                                onExitComplete: e
                            } = this.node.presenceContext, {
                                isPresent: n
                            } = this.node.prevPresenceContext || {};
                            if (!this.node.animationState || t === n) return;
                            const i = this.node.animationState.setActive("exit", !t);
                            e && !t && i.then((() => e(this.id)))
                        }
                        mount() {
                            const {
                                register: t
                            } = this.node.presenceContext || {};
                            t && (this.unmount = t(this.id))
                        }
                        unmount() {}
                    }
                }
            };
            var P = n(89871),
                E = n(55251),
                T = n(37625),
                S = n(42772);

            function M(t, e, n, i = {
                passive: !0
            }) {
                return t.addEventListener(e, n, i), () => t.removeEventListener(e, n)
            }

            function C(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }

            function D(t, e, n, i) {
                return M(t, e, (t => e => (0, T.DJ)(e) && t(e, C(e)))(n), i)
            }
            const O = (t, e) => Math.abs(t - e);
            var A = n(91052),
                k = n(79120);
            class R {
                constructor(t, e, {
                    transformPagePoint: n,
                    contextWindow: i,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            if (!this.lastMoveEvent || !this.lastMoveEventInfo) return;
                            const t = L(this.lastMoveEventInfo, this.history),
                                e = null !== this.startEvent,
                                n = function(t, e) {
                                    const n = O(t.x, e.x),
                                        i = O(t.y, e.y);
                                    return Math.sqrt(n ** 2 + i ** 2)
                                }(t.offset, {
                                    x: 0,
                                    y: 0
                                }) >= 3;
                            if (!e && !n) return;
                            const {
                                point: i
                            } = t, {
                                timestamp: r
                            } = k.frameData;
                            this.history.push({ ...i,
                                timestamp: r
                            });
                            const {
                                onStart: o,
                                onMove: s
                            } = this.handlers;
                            e || (o && o(this.lastMoveEvent, t), this.startEvent = this.lastMoveEvent), s && s(this.lastMoveEvent, t)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = _(e, this.transformPagePoint), k.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            const {
                                onEnd: n,
                                onSessionEnd: i,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !this.lastMoveEvent || !this.lastMoveEventInfo) return;
                            const o = L("pointercancel" === t.type ? this.lastMoveEventInfo : _(e, this.transformPagePoint), this.history);
                            this.startEvent && n && n(t, o), i && i(t, o)
                        }, !(0, T.DJ)(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = n, this.contextWindow = i || window;
                    const o = _(C(t), this.transformPagePoint),
                        {
                            point: s
                        } = o,
                        {
                            timestamp: a
                        } = k.frameData;
                    this.history = [{ ...s,
                        timestamp: a
                    }];
                    const {
                        onSessionStart: u
                    } = e;
                    u && u(t, L(o, this.history)), this.removeListeners = (0, A.z)(D(this.contextWindow, "pointermove", this.handlePointerMove), D(this.contextWindow, "pointerup", this.handlePointerUp), D(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, k.Pn)(this.updatePoint)
                }
            }

            function _(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function j(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function L({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: j(t, B(e)),
                    offset: j(t, V(e)),
                    velocity: N(e, .1)
                }
            }

            function V(t) {
                return t[0]
            }

            function B(t) {
                return t[t.length - 1]
            }

            function N(t, e) {
                if (t.length < 2) return {
                    x: 0,
                    y: 0
                };
                let n = t.length - 1,
                    i = null;
                const r = B(t);
                for (; n >= 0 && (i = t[n], !(r.timestamp - i.timestamp > (0, S.w)(e)));) n--;
                if (!i) return {
                    x: 0,
                    y: 0
                };
                const o = (0, S.X)(r.timestamp - i.timestamp);
                if (0 === o) return {
                    x: 0,
                    y: 0
                };
                const s = {
                    x: (r.x - i.x) / o,
                    y: (r.y - i.y) / o
                };
                return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s
            }

            function F(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }
            var $ = n(67956),
                I = n(17837);

            function z(t) {
                return t.max - t.min
            }

            function W(t, e, n, i = .5) {
                t.origin = i, t.originPoint = (0, I.t)(e.min, e.max, t.origin), t.scale = z(n) / z(e), t.translate = (0, I.t)(n.min, n.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
            }

            function U(t, e, n, i) {
                W(t.x, e.x, n.x, i ? i.originX : void 0), W(t.y, e.y, n.y, i ? i.originY : void 0)
            }

            function H(t, e, n) {
                t.min = n.min + e.min, t.max = t.min + z(e)
            }

            function Y(t, e, n) {
                t.min = e.min - n.min, t.max = t.min + z(e)
            }

            function X(t, e, n) {
                Y(t.x, e.x, n.x), Y(t.y, e.y, n.y)
            }
            var Z = n(12807);

            function K(t, e, n) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== n ? t.max + n - (t.max - t.min) : void 0
                }
            }

            function G(t, e) {
                let n = e.min - t.min,
                    i = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([n, i] = [i, n]), {
                    min: n,
                    max: i
                }
            }
            const q = .35;

            function J(t, e, n) {
                return {
                    min: Q(t, e),
                    max: Q(t, n)
                }
            }

            function Q(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            var tt = n(63431);

            function et(t) {
                return [t("x"), t("y")]
            }
            var nt = n(81510),
                it = n(62483),
                rt = n(60433),
                ot = n(26740);
            const st = ({
                current: t
            }) => t ? t.ownerDocument.defaultView : null;
            var at = n(68138);
            const ut = new WeakMap;
            class ct {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, tt.dO)(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    const {
                        presenceContext: n
                    } = this.visualElement;
                    if (n && !1 === n.isPresent) return;
                    const {
                        dragSnapToOrigin: i
                    } = this.getProps();
                    this.panSession = new R(t, {
                        onSessionStart: t => {
                            const {
                                dragSnapToOrigin: n
                            } = this.getProps();
                            n ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(C(t).point)
                        },
                        onStart: (t, e) => {
                            const {
                                drag: n,
                                dragPropagation: i,
                                onDragStart: r
                            } = this.getProps();
                            if (n && !i && (this.openDragLock && this.openDragLock(), this.openDragLock = (0, T.KV)(n), !this.openDragLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), et((t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (rt.aQ.test(e)) {
                                    const {
                                        projection: n
                                    } = this.visualElement;
                                    if (n && n.layout) {
                                        const i = n.layout.layoutBox[t];
                                        if (i) {
                                            e = z(i) * (parseFloat(e) / 100)
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            })), r && k.Wi.postRender((() => r(t, e))), (0, at.K)(this.visualElement, "transform");
                            const {
                                animationState: o
                            } = this.visualElement;
                            o && o.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            const {
                                dragPropagation: n,
                                dragDirectionLock: i,
                                onDirectionLock: r,
                                onDrag: o
                            } = this.getProps();
                            if (!n && !this.openDragLock) return;
                            const {
                                offset: s
                            } = e;
                            if (i && null === this.currentDirection) return this.currentDirection = function(t, e = 10) {
                                let n = null;
                                Math.abs(t.y) > e ? n = "y" : Math.abs(t.x) > e && (n = "x");
                                return n
                            }(s), void(null !== this.currentDirection && r && r(this.currentDirection));
                            this.updateAxis("x", e.point, s), this.updateAxis("y", e.point, s), this.visualElement.render(), o && o(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => et((t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        }))
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: i,
                        contextWindow: st(this.visualElement)
                    })
                }
                stop(t, e) {
                    const n = this.isDragging;
                    if (this.cancel(), !n) return;
                    const {
                        velocity: i
                    } = e;
                    this.startAnimation(i);
                    const {
                        onDragEnd: r
                    } = this.getProps();
                    r && k.Wi.postRender((() => r(t, e)))
                }
                cancel() {
                    this.isDragging = !1;
                    const {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    const {
                        dragPropagation: n
                    } = this.getProps();
                    !n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, n) {
                    const {
                        drag: i
                    } = this.getProps();
                    if (!n || !lt(t, i, this.currentDirection)) return;
                    const r = this.getAxisMotionValue(t);
                    let o = this.originPoint[t] + n[t];
                    this.constraints && this.constraints[t] && (o = function(t, {
                        min: e,
                        max: n
                    }, i) {
                        return void 0 !== e && t < e ? t = i ? (0, I.t)(e, t, i.min) : Math.max(t, e) : void 0 !== n && t > n && (t = i ? (0, I.t)(n, t, i.max) : Math.min(t, n)), t
                    }(o, this.constraints[t], this.elastic[t])), r.set(o)
                }
                resolveConstraints() {
                    var t;
                    const {
                        dragConstraints: e,
                        dragElastic: n
                    } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && F(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : this.constraints = !(!e || !i) && function(t, {
                        top: e,
                        left: n,
                        bottom: i,
                        right: r
                    }) {
                        return {
                            x: K(t.x, n, r),
                            y: K(t.y, e, i)
                        }
                    }(i.layoutBox, e), this.elastic = function(t = q) {
                        return !1 === t ? t = 0 : !0 === t && (t = q), {
                            x: J(t, "left", "right"),
                            y: J(t, "top", "bottom")
                        }
                    }(n), r !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && et((t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            const n = {};
                            return void 0 !== e.min && (n.min = e.min - t.min), void 0 !== e.max && (n.max = e.max - t.min), n
                        }(i.layoutBox[t], this.constraints[t]))
                    }))
                }
                resolveRefConstraints() {
                    const {
                        dragConstraints: t,
                        onMeasureDragConstraints: e
                    } = this.getProps();
                    if (!t || !F(t)) return !1;
                    const n = t.current;
                    (0, E.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    const {
                        projection: i
                    } = this.visualElement;
                    if (!i || !i.layout) return !1;
                    const r = (0, nt.z)(n, i.root, this.visualElement.getTransformPagePoint());
                    let o = function(t, e) {
                        return {
                            x: G(t.x, e.x),
                            y: G(t.y, e.y)
                        }
                    }(i.layout.layoutBox, r);
                    if (e) {
                        const t = e((0, it.z2)(o));
                        this.hasMutatedConstraints = !!t, t && (o = (0, it.i8)(t))
                    }
                    return o
                }
                startAnimation(t) {
                    const {
                        drag: e,
                        dragMomentum: n,
                        dragElastic: i,
                        dragTransition: r,
                        dragSnapToOrigin: o,
                        onDragTransitionEnd: s
                    } = this.getProps(), a = this.constraints || {}, u = et((s => {
                        if (!lt(s, e, this.currentDirection)) return;
                        let u = a && a[s] || {};
                        o && (u = {
                            min: 0,
                            max: 0
                        });
                        const c = i ? 200 : 1e6,
                            l = i ? 40 : 1e7,
                            d = {
                                type: "inertia",
                                velocity: n ? t[s] : 0,
                                bounceStiffness: c,
                                bounceDamping: l,
                                timeConstant: 750,
                                restDelta: 1,
                                restSpeed: 10,
                                ...r,
                                ...u
                            };
                        return this.startAxisValueAnimation(s, d)
                    }));
                    return Promise.all(u).then(s)
                }
                startAxisValueAnimation(t, e) {
                    const n = this.getAxisMotionValue(t);
                    return (0, at.K)(this.visualElement, t), n.start((0, ot.v)(t, n, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    et((t => this.getAxisMotionValue(t).stop()))
                }
                pauseAnimation() {
                    et((t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    }))
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    const e = `_drag${t.toUpperCase()}`,
                        n = this.visualElement.getProps(),
                        i = n[e];
                    return i || this.visualElement.getValue(t, (n.initial ? n.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    et((e => {
                        const {
                            drag: n
                        } = this.getProps();
                        if (!lt(e, n, this.currentDirection)) return;
                        const {
                            projection: i
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (i && i.layout) {
                            const {
                                min: n,
                                max: o
                            } = i.layout.layoutBox[e];
                            r.set(t[e] - (0, I.t)(n, o, .5))
                        }
                    }))
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    const {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: n
                    } = this.visualElement;
                    if (!F(e) || !n || !this.constraints) return;
                    this.stopAnimation();
                    const i = {
                        x: 0,
                        y: 0
                    };
                    et((t => {
                        const e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            const n = e.get();
                            i[t] = function(t, e) {
                                let n = .5;
                                const i = z(t),
                                    r = z(e);
                                return r > i ? n = (0, $.Y)(e.min, e.max - i, t.min) : i > r && (n = (0, $.Y)(t.min, t.max - r, e.min)), (0, Z.u)(0, 1, n)
                            }({
                                min: n,
                                max: n
                            }, this.constraints[t])
                        }
                    }));
                    const {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.resolveConstraints(), et((e => {
                        if (!lt(e, t, null)) return;
                        const n = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: o
                            } = this.constraints[e];
                        n.set((0, I.t)(r, o, i[e]))
                    }))
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    ut.set(this.visualElement, this);
                    const t = D(this.visualElement.current, "pointerdown", (t => {
                            const {
                                drag: e,
                                dragListener: n = !0
                            } = this.getProps();
                            e && n && this.start(t)
                        })),
                        e = () => {
                            const {
                                dragConstraints: t
                            } = this.getProps();
                            F(t) && t.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: n
                        } = this.visualElement,
                        i = n.addEventListener("measure", e);
                    n && !n.layout && (n.root && n.root.updateScroll(), n.updateLayout()), k.Wi.read(e);
                    const r = M(window, "resize", (() => this.scalePositionWithinConstraints())),
                        o = n.addEventListener("didUpdate", (({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (et((e => {
                                const n = this.getAxisMotionValue(e);
                                n && (this.originPoint[e] += t[e].translate, n.set(n.get() + t[e].translate))
                            })), this.visualElement.render())
                        }));
                    return () => {
                        r(), t(), i(), o && o()
                    }
                }
                getProps() {
                    const t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: n = !1,
                            dragPropagation: i = !1,
                            dragConstraints: r = !1,
                            dragElastic: o = q,
                            dragMomentum: s = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: n,
                        dragPropagation: i,
                        dragConstraints: r,
                        dragElastic: o,
                        dragMomentum: s
                    }
                }
            }

            function lt(t, e, n) {
                return !(!0 !== e && e !== t || null !== n && n !== t)
            }
            const dt = t => (e, n) => {
                t && k.Wi.postRender((() => t(e, n)))
            };
            var ht = n(75467),
                ft = n(84371),
                pt = n(67766),
                mt = n(50566);
            const vt = (0, ft.createContext)({}),
                gt = {
                    hasAnimatedSinceResize: !0,
                    hasEverUpdated: !1
                };

            function yt(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            const bt = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!rt.px.test(t)) return t;
                        t = parseFloat(t)
                    }
                    return `${yt(t,e.target.x)}% ${yt(t,e.target.y)}%`
                }
            };
            var xt = n(32833);
            const wt = {
                correct: (t, {
                    treeScale: e,
                    projectionDelta: n
                }) => {
                    const i = t,
                        r = xt.P.parse(t);
                    if (r.length > 5) return i;
                    const o = xt.P.createTransformer(t),
                        s = "number" != typeof r[0] ? 1 : 0,
                        a = n.x.scale * e.x,
                        u = n.y.scale * e.y;
                    r[0 + s] /= a, r[1 + s] /= u;
                    const c = (0, I.t)(a, u, .5);
                    return "number" == typeof r[2 + s] && (r[2 + s] /= c), "number" == typeof r[3 + s] && (r[3 + s] /= c), o(r)
                }
            };
            var Pt = n(24779),
                Et = n(21533);
            const {
                schedule: Tt,
                cancel: St
            } = (0, Et.Z)(queueMicrotask, !1);
            class Mt extends ft.Component {
                componentDidMount() {
                    const {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: n,
                        layoutId: i
                    } = this.props, {
                        projection: r
                    } = t;
                    (0, Pt.B)(Dt), r && (e.group && e.group.add(r), n && n.register && i && n.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", (() => {
                        this.safeToRemove()
                    })), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), gt.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    const {
                        layoutDependency: e,
                        visualElement: n,
                        drag: i,
                        isPresent: r
                    } = this.props, o = n.projection;
                    return o ? (o.isPresent = r, i || t.layoutDependency !== e || void 0 === e ? o.willUpdate() : this.safeToRemove(), t.isPresent !== r && (r ? o.promote() : o.relegate() || k.Wi.postRender((() => {
                        const t = o.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null) : null
                }
                componentDidUpdate() {
                    const {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), Tt.postRender((() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    })))
                }
                componentWillUnmount() {
                    const {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: n
                    } = this.props, {
                        projection: i
                    } = t;
                    i && (i.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(i), n && n.deregister && n.deregister(i))
                }
                safeToRemove() {
                    const {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function Ct(t) {
                const [e, n] = (0, pt.oO)(), i = (0, ft.useContext)(mt.p);
                return (0, ht.jsx)(Mt, { ...t,
                    layoutGroup: i,
                    switchLayoutGroup: (0, ft.useContext)(vt),
                    isPresent: e,
                    safeToRemove: n
                })
            }
            const Dt = {
                borderRadius: { ...bt,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: bt,
                borderTopRightRadius: bt,
                borderBottomLeftRadius: bt,
                borderBottomRightRadius: bt,
                boxShadow: wt
            };
            var Ot = n(7623),
                At = n(87839),
                kt = n(57440),
                Rt = n(77553),
                _t = n(72365);
            const jt = (t, e) => t.depth - e.depth;
            class Lt {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, _t.y4)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, _t.cl)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(jt), this.isDirty = !1, this.children.forEach(t)
                }
            }

            function Vt(t, e) {
                const n = kt.X.now(),
                    i = ({
                        timestamp: r
                    }) => {
                        const o = r - n;
                        o >= e && ((0, k.Pn)(i), t(o - e))
                    };
                return k.Wi.read(i, !0), () => (0, k.Pn)(i)
            }
            var Bt = n(57135),
                Nt = n(57732),
                Ft = n(29556);

            function $t(t) {
                const e = (0, Ft.i)(t) ? t.get() : t;
                return (0, Nt.p)(e) ? e.toValue() : e
            }
            var It = n(56790);
            const zt = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                Wt = zt.length,
                Ut = t => "string" == typeof t ? parseFloat(t) : t,
                Ht = t => "number" == typeof t || rt.px.test(t);

            function Yt(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            const Xt = Kt(0, .5, It.Bn),
                Zt = Kt(.5, .95, P.Z);

            function Kt(t, e, n) {
                return i => i < t ? 0 : i > e ? 1 : n((0, $.Y)(t, e, i))
            }

            function Gt(t, e) {
                t.min = e.min, t.max = e.max
            }

            function qt(t, e) {
                Gt(t.x, e.x), Gt(t.y, e.y)
            }

            function Jt(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }
            var Qt = n(58344);

            function te(t, e, n, i, r) {
                return t -= e, t = (0, Qt.q2)(t, 1 / n, i), void 0 !== r && (t = (0, Qt.q2)(t, 1 / r, i)), t
            }

            function ee(t, e, [n, i, r], o, s) {
                ! function(t, e = 0, n = 1, i = .5, r, o = t, s = t) {
                    rt.aQ.test(e) && (e = parseFloat(e), e = (0, I.t)(s.min, s.max, e / 100) - s.min);
                    if ("number" != typeof e) return;
                    let a = (0, I.t)(o.min, o.max, i);
                    t === o && (a -= e), t.min = te(t.min, e, n, a, r), t.max = te(t.max, e, n, a, r)
                }(t, e[n], e[i], e[r], e.scale, o, s)
            }
            const ne = ["x", "scaleX", "originX"],
                ie = ["y", "scaleY", "originY"];

            function re(t, e, n, i) {
                ee(t.x, e, ne, n ? n.x : void 0, i ? i.x : void 0), ee(t.y, e, ie, n ? n.y : void 0, i ? i.y : void 0)
            }

            function oe(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function se(t) {
                return oe(t.x) && oe(t.y)
            }

            function ae(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function ue(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function ce(t, e) {
                return ue(t.x, e.x) && ue(t.y, e.y)
            }

            function le(t) {
                return z(t.x) / z(t.y)
            }

            function de(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
            class he {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, _t.y4)(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if ((0, _t.cl)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        const t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    const e = this.members.findIndex((e => t === e));
                    if (0 === e) return !1;
                    let n;
                    for (let t = e; t >= 0; t--) {
                        const e = this.members[t];
                        if (!1 !== e.isPresent) {
                            n = e;
                            break
                        }
                    }
                    return !!n && (this.promote(n), !0)
                }
                promote(t, e) {
                    const n = this.lead;
                    if (t !== n && (this.prevLead = n, this.lead = t, t.show(), n)) {
                        n.instance && n.scheduleRender(), t.scheduleRender(), t.resumeFrom = n, e && (t.resumeFrom.preserveOpacity = !0), n.snapshot && (t.snapshot = n.snapshot, t.snapshot.latestValues = n.animationValues || n.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        const {
                            crossfade: i
                        } = t.options;
                        !1 === i && n.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach((t => {
                        const {
                            options: e,
                            resumingFrom: n
                        } = t;
                        e.onExitComplete && e.onExitComplete(), n && n.options.onExitComplete && n.options.onExitComplete()
                    }))
                }
                scheduleRender() {
                    this.members.forEach((t => {
                        t.instance && t.scheduleRender(!1)
                    }))
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            var fe = n(9371);
            const pe = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                me = "undefined" != typeof window && void 0 !== window.MotionDebug,
                ve = ["", "X", "Y", "Z"],
                ge = {
                    visibility: "hidden"
                };
            let ye = 0;

            function be(t, e, n, i) {
                const {
                    latestValues: r
                } = e;
                r[t] && (n[t] = r[t], e.setStaticValue(t, 0), i && (i[t] = 0))
            }

            function xe(t) {
                if (t.hasCheckedOptimisedAppear = !0, t.root === t) return;
                const {
                    visualElement: e
                } = t.options;
                if (!e) return;
                const n = (0, At.s)(e);
                if (window.MotionHasOptimisedAnimation(n, "transform")) {
                    const {
                        layout: e,
                        layoutId: i
                    } = t.options;
                    window.MotionCancelOptimisedAnimation(n, "transform", k.Wi, !(e || i))
                }
                const {
                    parent: i
                } = t;
                i && !i.hasCheckedOptimisedAppear && xe(i)
            }

            function we({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: n,
                checkIsScrollRoot: i,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, n = (null == e ? void 0 : e())) {
                        this.id = ye++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, me && (pe.totalNodes = pe.resolvedTargetDeltas = pe.recalculatedProjection = 0), this.nodes.forEach(Te), this.nodes.forEach(ke), this.nodes.forEach(Re), this.nodes.forEach(Se), me && window.MotionDebug.record(pe)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new Lt)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new Bt.L), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        const n = this.eventHandlers.get(t);
                        n && n.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, n = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = (0, Rt.v)(e), this.instance = e;
                        const {
                            layoutId: i,
                            layout: r,
                            visualElement: o
                        } = this.options;
                        if (o && !o.current && o.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), n && (r || i) && (this.isLayoutDirty = !0), t) {
                            let n;
                            const i = () => this.root.updateBlockedByResize = !1;
                            t(e, (() => {
                                this.root.updateBlockedByResize = !0, n && n(), n = Vt(i, 250), gt.hasAnimatedSinceResize && (gt.hasAnimatedSinceResize = !1, this.nodes.forEach(Ae))
                            }))
                        }
                        i && this.root.registerSharedNode(i, this), !1 !== this.options.animate && o && (i || r) && this.addEventListener("didUpdate", (({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: n,
                            layout: i
                        }) => {
                            if (this.isTreeAnimationBlocked()) return this.target = void 0, void(this.relativeTarget = void 0);
                            const r = this.options.transition || o.getDefaultTransition() || Ne,
                                {
                                    onLayoutAnimationStart: s,
                                    onLayoutAnimationComplete: a
                                } = o.getProps(),
                                u = !this.targetLayout || !ce(this.targetLayout, i) || n,
                                c = !e && n;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || c || e && (u || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, c);
                                const e = { ...(0, T.ev)(r, "layout"),
                                    onPlay: s,
                                    onComplete: a
                                };
                                (o.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || Ae(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = i
                        }))
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        const t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, k.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(_e), this.animationId++)
                    }
                    getTransformTemplate() {
                        const {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) return void(this.options.onExitComplete && this.options.onExitComplete());
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && xe(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            const e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        const {
                            layoutId: e,
                            layout: n
                        } = this.options;
                        if (void 0 === e && !n) return;
                        const i = this.getTransformTemplate();
                        this.prevTransformTemplateValue = i ? i(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        this.updateScheduled = !1;
                        if (this.isUpdateBlocked()) return this.unblockUpdate(), this.clearAllSnapshots(), void this.nodes.forEach(Ce);
                        this.isUpdating || this.nodes.forEach(De), this.isUpdating = !1, this.nodes.forEach(Oe), this.nodes.forEach(Pe), this.nodes.forEach(Ee), this.clearAllSnapshots();
                        const t = kt.X.now();
                        k.frameData.delta = (0, Z.u)(0, 1e3 / 60, t - k.frameData.timestamp), k.frameData.timestamp = t, k.frameData.isProcessing = !0, k.yL.update.process(k.frameData), k.yL.preRender.process(k.frameData), k.yL.render.process(k.frameData), k.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, Tt.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(Me), this.sharedNodes.forEach(je)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, k.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        k.Wi.postRender((() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        }))
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance) return;
                        if (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead() || this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) {
                                this.path[t].updateScroll()
                            }
                        const t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = (0, tt.dO)(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        const {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = Boolean(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e) {
                            const e = i(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: n(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!r) return;
                        const t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !se(this.projectionDelta),
                            n = this.getTransformTemplate(),
                            i = n ? n(this.latestValues, "") : void 0,
                            o = i !== this.prevTransformTemplateValue;
                        t && (e || (0, fe.ud)(this.latestValues) || o) && (r(this.instance, i), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        const e = this.measurePageBox();
                        let n = this.removeElementScroll(e);
                        var i;
                        return t && (n = this.removeTransform(n)), Ie((i = n).x), Ie(i.y), {
                            animationId: this.root.animationId,
                            measuredBox: e,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var t;
                        const {
                            visualElement: e
                        } = this.options;
                        if (!e) return (0, tt.dO)();
                        const n = e.measureViewportBox();
                        if (!((null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) || this.path.some(We))) {
                            const {
                                scroll: t
                            } = this.root;
                            t && ((0, Qt.am)(n.x, t.offset.x), (0, Qt.am)(n.y, t.offset.y))
                        }
                        return n
                    }
                    removeElementScroll(t) {
                        var e;
                        const n = (0, tt.dO)();
                        if (qt(n, t), null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) return n;
                        for (let e = 0; e < this.path.length; e++) {
                            const i = this.path[e],
                                {
                                    scroll: r,
                                    options: o
                                } = i;
                            i !== this.root && r && o.layoutScroll && (r.wasRoot && qt(n, t), (0, Qt.am)(n.x, r.offset.x), (0, Qt.am)(n.y, r.offset.y))
                        }
                        return n
                    }
                    applyTransform(t, e = !1) {
                        const n = (0, tt.dO)();
                        qt(n, t);
                        for (let t = 0; t < this.path.length; t++) {
                            const i = this.path[t];
                            !e && i.options.layoutScroll && i.scroll && i !== i.root && (0, Qt.D2)(n, {
                                x: -i.scroll.offset.x,
                                y: -i.scroll.offset.y
                            }), (0, fe.ud)(i.latestValues) && (0, Qt.D2)(n, i.latestValues)
                        }
                        return (0, fe.ud)(this.latestValues) && (0, Qt.D2)(n, this.latestValues), n
                    }
                    removeTransform(t) {
                        const e = (0, tt.dO)();
                        qt(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            const n = this.path[t];
                            if (!n.instance) continue;
                            if (!(0, fe.ud)(n.latestValues)) continue;
                            (0, fe.Lj)(n.latestValues) && n.updateSnapshot();
                            const i = (0, tt.dO)();
                            qt(i, n.measurePageBox()), re(e, n.latestValues, n.snapshot ? n.snapshot.layoutBox : void 0, i)
                        }
                        return (0, fe.ud)(this.latestValues) && re(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== k.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e;
                        const n = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = n.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = n.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = n.isSharedProjectionDirty);
                        const i = Boolean(this.resumingFrom) || this !== n;
                        if (!(t || i && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        const {
                            layout: r,
                            layoutId: o
                        } = this.options;
                        if (this.layout && (r || o)) {
                            if (this.resolvedRelativeTargetAt = k.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                const t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, tt.dO)(), this.relativeTargetOrigin = (0, tt.dO)(), X(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), qt(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                var s, a, u;
                                if (this.target || (this.target = (0, tt.dO)(), this.targetWithTransforms = (0, tt.dO)()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), s = this.target, a = this.relativeTarget, u = this.relativeParent.target, H(s.x, a.x, u.x), H(s.y, a.y, u.y)) : this.targetDelta ? (Boolean(this.resumingFrom) ? this.target = this.applyTransform(this.layout.layoutBox) : qt(this.target, this.layout.layoutBox), (0, Qt.o2)(this.target, this.targetDelta)) : qt(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    const t = this.getClosestProjectingParent();
                                    t && Boolean(t.resumingFrom) === Boolean(this.resumingFrom) && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, tt.dO)(), this.relativeTargetOrigin = (0, tt.dO)(), X(this.relativeTargetOrigin, this.target, t.target), qt(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                me && pe.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        if (this.parent && !(0, fe.Lj)(this.parent.latestValues) && !(0, fe.D_)(this.parent.latestValues)) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return Boolean((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        const e = this.getLead(),
                            n = Boolean(this.resumingFrom) || this !== e;
                        let i = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (i = !1), n && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1), this.resolvedRelativeTargetAt === k.frameData.timestamp && (i = !1), i) return;
                        const {
                            layout: r,
                            layoutId: o
                        } = this.options;
                        if (this.isTreeAnimating = Boolean(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !r && !o) return;
                        qt(this.layoutCorrected, this.layout.layoutBox);
                        const s = this.treeScale.x,
                            a = this.treeScale.y;
                        (0, Qt.YY)(this.layoutCorrected, this.treeScale, this.path, n), !e.layout || e.target || 1 === this.treeScale.x && 1 === this.treeScale.y || (e.target = e.layout.layoutBox, e.targetWithTransforms = (0, tt.dO)());
                        const {
                            target: u
                        } = e;
                        u ? (this.projectionDelta && this.prevProjectionDelta ? (Jt(this.prevProjectionDelta.x, this.projectionDelta.x), Jt(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), U(this.projectionDelta, this.layoutCorrected, u, this.latestValues), this.treeScale.x === s && this.treeScale.y === a && de(this.projectionDelta.x, this.prevProjectionDelta.x) && de(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", u)), me && pe.recalculatedProjection++) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender())
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e;
                        if (null === (e = this.options.visualElement) || void 0 === e || e.scheduleRender(), t) {
                            const t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = (0, tt.wc)(), this.projectionDelta = (0, tt.wc)(), this.projectionDeltaWithTransform = (0, tt.wc)()
                    }
                    setAnimationOrigin(t, e = !1) {
                        const n = this.snapshot,
                            i = n ? n.latestValues : {},
                            r = { ...this.latestValues
                            },
                            o = (0, tt.wc)();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        const s = (0, tt.dO)(),
                            a = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            c = !u || u.members.length <= 1,
                            l = Boolean(a && !c && !0 === this.options.crossfade && !this.path.some(Be));
                        let d;
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            const n = e / 1e3;
                            var u, h, f, p, m, v;
                            Le(o.x, t.x, n), Le(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (X(s, this.layout.layoutBox, this.relativeParent.layout.layoutBox), f = this.relativeTarget, p = this.relativeTargetOrigin, m = s, v = n, Ve(f.x, p.x, m.x, v), Ve(f.y, p.y, m.y, v), d && (u = this.relativeTarget, h = d, ae(u.x, h.x) && ae(u.y, h.y)) && (this.isProjectionDirty = !1), d || (d = (0, tt.dO)()), qt(d, this.relativeTarget)), a && (this.animationValues = r, function(t, e, n, i, r, o) {
                                r ? (t.opacity = (0, I.t)(0, void 0 !== n.opacity ? n.opacity : 1, Xt(i)), t.opacityExit = (0, I.t)(void 0 !== e.opacity ? e.opacity : 1, 0, Zt(i))) : o && (t.opacity = (0, I.t)(void 0 !== e.opacity ? e.opacity : 1, void 0 !== n.opacity ? n.opacity : 1, i));
                                for (let r = 0; r < Wt; r++) {
                                    const o = `border${zt[r]}Radius`;
                                    let s = Yt(e, o),
                                        a = Yt(n, o);
                                    void 0 === s && void 0 === a || (s || (s = 0), a || (a = 0), 0 === s || 0 === a || Ht(s) === Ht(a) ? (t[o] = Math.max((0, I.t)(Ut(s), Ut(a), i), 0), (rt.aQ.test(a) || rt.aQ.test(s)) && (t[o] += "%")) : t[o] = a)
                                }(e.rotate || n.rotate) && (t.rotate = (0, I.t)(e.rotate || 0, n.rotate || 0, i))
                            }(r, i, this.latestValues, n, l, c)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, k.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = k.Wi.update((() => {
                            gt.hasAnimatedSinceResize = !0, this.currentAnimation = (0, Ot.D)(0, 1e3, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        }))
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        const t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        const t = this.getLead();
                        let {
                            targetWithTransforms: e,
                            target: n,
                            layout: i,
                            latestValues: r
                        } = t;
                        if (e && n && i) {
                            if (this !== t && this.layout && i && ze(this.options.animationType, this.layout.layoutBox, i.layoutBox)) {
                                n = this.target || (0, tt.dO)();
                                const e = z(this.layout.layoutBox.x);
                                n.x.min = t.target.x.min, n.x.max = n.x.min + e;
                                const i = z(this.layout.layoutBox.y);
                                n.y.min = t.target.y.min, n.y.max = n.y.min + i
                            }
                            qt(e, n), (0, Qt.D2)(e, r), U(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new he);
                        this.sharedNodes.get(t).add(e);
                        const n = e.options.initialPromotionConfig;
                        e.promote({
                            transition: n ? n.transition : void 0,
                            preserveFollowOpacity: n && n.shouldPreserveFollowOpacity ? n.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        const t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        const {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        const {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        const {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: n
                    } = {}) {
                        const i = this.getStack();
                        i && i.promote(this, n), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        const t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        const {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1;
                        const {
                            latestValues: n
                        } = t;
                        if ((n.z || n.rotate || n.rotateX || n.rotateY || n.rotateZ || n.skewX || n.skewY) && (e = !0), !e) return;
                        const i = {};
                        n.z && be("z", t, i, this.animationValues);
                        for (let e = 0; e < ve.length; e++) be(`rotate${ve[e]}`, t, i, this.animationValues), be(`skew${ve[e]}`, t, i, this.animationValues);
                        t.render();
                        for (const e in i) t.setStaticValue(e, i[e]), this.animationValues && (this.animationValues[e] = i[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, n;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return ge;
                        const i = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, i.opacity = "", i.pointerEvents = $t(null == t ? void 0 : t.pointerEvents) || "", i.transform = r ? r(this.latestValues, "") : "none", i;
                        const o = this.getLead();
                        if (!this.projectionDelta || !this.layout || !o.target) {
                            const e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = $t(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !(0, fe.ud)(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        const s = o.animationValues || o.latestValues;
                        this.applyTransformsToTarget(), i.transform = function(t, e, n) {
                            let i = "";
                            const r = t.x.translate / e.x,
                                o = t.y.translate / e.y,
                                s = (null == n ? void 0 : n.z) || 0;
                            if ((r || o || s) && (i = `translate3d(${r}px, ${o}px, ${s}px) `), 1 === e.x && 1 === e.y || (i += `scale(${1/e.x}, ${1/e.y}) `), n) {
                                const {
                                    transformPerspective: t,
                                    rotate: e,
                                    rotateX: r,
                                    rotateY: o,
                                    skewX: s,
                                    skewY: a
                                } = n;
                                t && (i = `perspective(${t}px) ${i}`), e && (i += `rotate(${e}deg) `), r && (i += `rotateX(${r}deg) `), o && (i += `rotateY(${o}deg) `), s && (i += `skewX(${s}deg) `), a && (i += `skewY(${a}deg) `)
                            }
                            const a = t.x.scale * e.x,
                                u = t.y.scale * e.y;
                            return 1 === a && 1 === u || (i += `scale(${a}, ${u})`), i || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, s), r && (i.transform = r(s, i.transform));
                        const {
                            x: a,
                            y: u
                        } = this.projectionDelta;
                        i.transformOrigin = `${100*a.origin}% ${100*u.origin}% 0`, o.animationValues ? i.opacity = o === this ? null !== (n = null !== (e = s.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== n ? n : 1 : this.preserveOpacity ? this.latestValues.opacity : s.opacityExit : i.opacity = o === this ? void 0 !== s.opacity ? s.opacity : "" : void 0 !== s.opacityExit ? s.opacityExit : 0;
                        for (const t in Pt.P) {
                            if (void 0 === s[t]) continue;
                            const {
                                correct: e,
                                applyTo: n
                            } = Pt.P[t], r = "none" === i.transform ? s[t] : e(s[t], o);
                            if (n) {
                                const t = n.length;
                                for (let e = 0; e < t; e++) i[n[e]] = r
                            } else i[t] = r
                        }
                        return this.options.layoutId && (i.pointerEvents = o === this ? $t(null == t ? void 0 : t.pointerEvents) || "" : "none"), i
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach((t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        })), this.root.nodes.forEach(Ce), this.root.sharedNodes.clear()
                    }
                }
            }

            function Pe(t) {
                t.updateLayout()
            }

            function Ee(t) {
                var e;
                const n = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && n && t.hasListeners("didUpdate")) {
                    const {
                        layoutBox: e,
                        measuredBox: i
                    } = t.layout, {
                        animationType: r
                    } = t.options, o = n.source !== t.layout.source;
                    "size" === r ? et((t => {
                        const i = o ? n.measuredBox[t] : n.layoutBox[t],
                            r = z(i);
                        i.min = e[t].min, i.max = i.min + r
                    })) : ze(r, n.layoutBox, e) && et((i => {
                        const r = o ? n.measuredBox[i] : n.layoutBox[i],
                            s = z(e[i]);
                        r.max = r.min + s, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[i].max = t.relativeTarget[i].min + s)
                    }));
                    const s = (0, tt.wc)();
                    U(s, e, n.layoutBox);
                    const a = (0, tt.wc)();
                    o ? U(a, t.applyTransform(i, !0), n.measuredBox) : U(a, e, n.layoutBox);
                    const u = !se(s);
                    let c = !1;
                    if (!t.resumeFrom) {
                        const i = t.getClosestProjectingParent();
                        if (i && !i.resumeFrom) {
                            const {
                                snapshot: r,
                                layout: o
                            } = i;
                            if (r && o) {
                                const s = (0, tt.dO)();
                                X(s, n.layoutBox, r.layoutBox);
                                const a = (0, tt.dO)();
                                X(a, e, o.layoutBox), ce(s, a) || (c = !0), i.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = s, t.relativeParent = i)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: n,
                        delta: a,
                        layoutDelta: s,
                        hasLayoutChanged: u,
                        hasRelativeTargetChanged: c
                    })
                } else if (t.isLead()) {
                    const {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function Te(t) {
                me && pe.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = Boolean(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function Se(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function Me(t) {
                t.clearSnapshot()
            }

            function Ce(t) {
                t.clearMeasurements()
            }

            function De(t) {
                t.isLayoutDirty = !1
            }

            function Oe(t) {
                const {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function Ae(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function ke(t) {
                t.resolveTargetDelta()
            }

            function Re(t) {
                t.calcProjection()
            }

            function _e(t) {
                t.resetSkewAndRotation()
            }

            function je(t) {
                t.removeLeadSnapshot()
            }

            function Le(t, e, n) {
                t.translate = (0, I.t)(e.translate, 0, n), t.scale = (0, I.t)(e.scale, 1, n), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function Ve(t, e, n, i) {
                t.min = (0, I.t)(e.min, n.min, i), t.max = (0, I.t)(e.max, n.max, i)
            }

            function Be(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            const Ne = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                Fe = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                $e = Fe("applewebkit/") && !Fe("chrome/") ? Math.round : P.Z;

            function Ie(t) {
                t.min = $e(t.min), t.max = $e(t.max)
            }

            function ze(t, e, n) {
                return "position" === t || "preserve-aspect" === t && (i = le(e), r = le(n), o = .2, !(Math.abs(i - r) <= o));
                var i, r, o
            }

            function We(t) {
                var e;
                return t !== t.root && (null === (e = t.scroll) || void 0 === e ? void 0 : e.wasRoot)
            }
            const Ue = we({
                    attachResizeListener: (t, e) => M(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                He = {
                    current: void 0
                },
                Ye = we({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!He.current) {
                            const t = new Ue({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), He.current = t
                        }
                        return He.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => Boolean("fixed" === window.getComputedStyle(t).position)
                }),
                Xe = {
                    pan: {
                        Feature: class extends b {
                            constructor() {
                                super(...arguments), this.removePointerDownListener = P.Z
                            }
                            onPointerDown(t) {
                                this.session = new R(t, this.createPanHandlers(), {
                                    transformPagePoint: this.node.getTransformPagePoint(),
                                    contextWindow: st(this.node)
                                })
                            }
                            createPanHandlers() {
                                const {
                                    onPanSessionStart: t,
                                    onPanStart: e,
                                    onPan: n,
                                    onPanEnd: i
                                } = this.node.getProps();
                                return {
                                    onSessionStart: dt(t),
                                    onStart: dt(e),
                                    onMove: n,
                                    onEnd: (t, e) => {
                                        delete this.session, i && k.Wi.postRender((() => i(t, e)))
                                    }
                                }
                            }
                            mount() {
                                this.removePointerDownListener = D(this.node.current, "pointerdown", (t => this.onPointerDown(t)))
                            }
                            update() {
                                this.session && this.session.updateHandlers(this.createPanHandlers())
                            }
                            unmount() {
                                this.removePointerDownListener(), this.session && this.session.end()
                            }
                        }
                    },
                    drag: {
                        Feature: class extends b {
                            constructor(t) {
                                super(t), this.removeGroupControls = P.Z, this.removeListeners = P.Z, this.controls = new ct(t)
                            }
                            mount() {
                                const {
                                    dragControls: t
                                } = this.node.getProps();
                                t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || P.Z
                            }
                            unmount() {
                                this.removeGroupControls(), this.removeListeners()
                            }
                        },
                        ProjectionNode: Ye,
                        MeasureLayout: Ct
                    }
                };

            function Ze(t, e, n) {
                const {
                    props: i
                } = t;
                t.animationState && i.whileHover && t.animationState.setActive("whileHover", "Start" === n);
                const r = i["onHover" + n];
                r && k.Wi.postRender((() => r(e, C(e))))
            }

            function Ke(t, e, n) {
                const {
                    props: i
                } = t;
                t.animationState && i.whileTap && t.animationState.setActive("whileTap", "Start" === n);
                const r = i["onTap" + ("End" === n ? "" : n)];
                r && k.Wi.postRender((() => r(e, C(e))))
            }
            const Ge = new WeakMap,
                qe = new WeakMap,
                Je = t => {
                    const e = Ge.get(t.target);
                    e && e(t)
                },
                Qe = t => {
                    t.forEach(Je)
                };

            function tn(t, e, n) {
                const i = function({
                    root: t,
                    ...e
                }) {
                    const n = t || document;
                    qe.has(n) || qe.set(n, {});
                    const i = qe.get(n),
                        r = JSON.stringify(e);
                    return i[r] || (i[r] = new IntersectionObserver(Qe, {
                        root: t,
                        ...e
                    })), i[r]
                }(e);
                return Ge.set(t, n), i.observe(t), () => {
                    Ge.delete(t), i.unobserve(t)
                }
            }
            const en = {
                some: 0,
                all: 1
            };
            const nn = {
                    inView: {
                        Feature: class extends b {
                            constructor() {
                                super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                            }
                            startObserver() {
                                this.unmount();
                                const {
                                    viewport: t = {}
                                } = this.node.getProps(), {
                                    root: e,
                                    margin: n,
                                    amount: i = "some",
                                    once: r
                                } = t, o = {
                                    root: e ? e.current : void 0,
                                    rootMargin: n,
                                    threshold: "number" == typeof i ? i : en[i]
                                };
                                return tn(this.node.current, o, (t => {
                                    const {
                                        isIntersecting: e
                                    } = t;
                                    if (this.isInView === e) return;
                                    if (this.isInView = e, r && !e && this.hasEnteredView) return;
                                    e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                                    const {
                                        onViewportEnter: n,
                                        onViewportLeave: i
                                    } = this.node.getProps(), o = e ? n : i;
                                    o && o(t)
                                }))
                            }
                            mount() {
                                this.startObserver()
                            }
                            update() {
                                if ("undefined" == typeof IntersectionObserver) return;
                                const {
                                    props: t,
                                    prevProps: e
                                } = this.node;
                                ["amount", "margin", "root"].some(function({
                                    viewport: t = {}
                                }, {
                                    viewport: e = {}
                                } = {}) {
                                    return n => t[n] !== e[n]
                                }(t, e)) && this.startObserver()
                            }
                            unmount() {}
                        }
                    },
                    tap: {
                        Feature: class extends b {
                            mount() {
                                const {
                                    current: t
                                } = this.node;
                                t && (this.unmount = (0, T.OD)(t, (t => (Ke(this.node, t, "Start"), (t, {
                                    success: e
                                }) => Ke(this.node, t, e ? "End" : "Cancel"))), {
                                    useGlobalTarget: this.node.props.globalTapTarget
                                }))
                            }
                            unmount() {}
                        }
                    },
                    focus: {
                        Feature: class extends b {
                            constructor() {
                                super(...arguments), this.isActive = !1
                            }
                            onFocus() {
                                let t = !1;
                                try {
                                    t = this.node.current.matches(":focus-visible")
                                } catch (e) {
                                    t = !0
                                }
                                t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                            }
                            onBlur() {
                                this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                            }
                            mount() {
                                this.unmount = (0, A.z)(M(this.node.current, "focus", (() => this.onFocus())), M(this.node.current, "blur", (() => this.onBlur())))
                            }
                            unmount() {}
                        }
                    },
                    hover: {
                        Feature: class extends b {
                            mount() {
                                const {
                                    current: t
                                } = this.node;
                                t && (this.unmount = (0, T.Mr)(t, (t => (Ze(this.node, t, "Start"), t => Ze(this.node, t, "End")))))
                            }
                            unmount() {}
                        }
                    }
                },
                rn = {
                    layout: {
                        ProjectionNode: Ye,
                        MeasureLayout: Ct
                    }
                },
                on = (0, ft.createContext)({
                    strict: !1
                });
            var sn = n(48460);
            const an = (0, ft.createContext)({});
            var un = n(74173);

            function cn(t) {
                const {
                    initial: e,
                    animate: n
                } = function(t, e) {
                    if ((0, un.G)(t)) {
                        const {
                            initial: e,
                            animate: n
                        } = t;
                        return {
                            initial: !1 === e || (0, a.$)(e) ? e : void 0,
                            animate: (0, a.$)(n) ? n : void 0
                        }
                    }
                    return !1 !== t.inherit ? e : {}
                }(t, (0, ft.useContext)(an));
                return (0, ft.useMemo)((() => ({
                    initial: e,
                    animate: n
                })), [ln(e), ln(n)])
            }

            function ln(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            var dn = n(43377),
                hn = n(24617);
            const fn = Symbol.for("motionComponentSymbol");

            function pn(t, e, n) {
                return (0, ft.useCallback)((i => {
                    i && t.onMount && t.onMount(i), e && (i ? e.mount(i) : e.unmount()), n && ("function" == typeof n ? n(i) : F(n) && (n.current = i))
                }), [e])
            }
            var mn = n(89466),
                vn = n(69682),
                gn = n(5624);

            function yn(t, e, n, i, r) {
                var o, s;
                const {
                    visualElement: a
                } = (0, ft.useContext)(an), u = (0, ft.useContext)(on), c = (0, ft.useContext)(mn.O), l = (0, ft.useContext)(sn._).reducedMotion, d = (0, ft.useRef)(null);
                i = i || u.renderer, !d.current && i && (d.current = i(t, {
                    visualState: e,
                    parent: a,
                    props: n,
                    presenceContext: c,
                    blockInitialAnimation: !!c && !1 === c.initial,
                    reducedMotionConfig: l
                }));
                const h = d.current,
                    f = (0, ft.useContext)(vt);
                !h || h.projection || !r || "html" !== h.type && "svg" !== h.type || function(t, e, n, i) {
                    const {
                        layoutId: r,
                        layout: o,
                        drag: s,
                        dragConstraints: a,
                        layoutScroll: u,
                        layoutRoot: c
                    } = e;
                    t.projection = new n(t.latestValues, e["data-framer-portal-id"] ? void 0 : bn(t.parent)), t.projection.setOptions({
                        layoutId: r,
                        layout: o,
                        alwaysMeasureLayout: Boolean(s) || a && F(a),
                        visualElement: t,
                        animationType: "string" == typeof o ? o : "both",
                        initialPromotionConfig: i,
                        layoutScroll: u,
                        layoutRoot: c
                    })
                }(d.current, n, r, f);
                const p = (0, ft.useRef)(!1);
                (0, ft.useInsertionEffect)((() => {
                    h && p.current && h.update(n, c)
                }));
                const m = n[gn.M],
                    v = (0, ft.useRef)(Boolean(m) && !(null === (o = window.MotionHandoffIsComplete) || void 0 === o ? void 0 : o.call(window, m)) && (null === (s = window.MotionHasOptimisedAnimation) || void 0 === s ? void 0 : s.call(window, m)));
                return (0, vn.L)((() => {
                    h && (p.current = !0, window.MotionIsMounted = !0, h.updateFeatures(), Tt.render(h.render), v.current && h.animationState && h.animationState.animateChanges())
                })), (0, ft.useEffect)((() => {
                    h && (!v.current && h.animationState && h.animationState.animateChanges(), v.current && (queueMicrotask((() => {
                        var t;
                        null === (t = window.MotionHandoffMarkAsComplete) || void 0 === t || t.call(window, m)
                    })), v.current = !1))
                })), h
            }

            function bn(t) {
                if (t) return !1 !== t.options.allowProjection ? t.projection : bn(t.parent)
            }

            function xn(t) {
                let {
                    preloadedFeatures: e,
                    createVisualElement: n,
                    useRender: i,
                    useVisualState: r,
                    Component: o
                } = t;
                var s, a;

                function u(t, e) {
                    let s;
                    const a = { ...(0, ft.useContext)(sn._),
                            ...t,
                            layoutId: wn(t)
                        },
                        {
                            isStatic: u
                        } = a,
                        c = cn(t),
                        l = r(t, u);
                    if (!u && dn.j) {
                        ! function() {
                            (0, ft.useContext)(on).strict;
                            0
                        }();
                        const t = function(t) {
                            const {
                                drag: e,
                                layout: n
                            } = hn.featureDefinitions;
                            if (!e && !n) return {};
                            const i = { ...e,
                                ...n
                            };
                            return {
                                MeasureLayout: (null == e ? void 0 : e.isEnabled(t)) || (null == n ? void 0 : n.isEnabled(t)) ? i.MeasureLayout : void 0,
                                ProjectionNode: i.ProjectionNode
                            }
                        }(a);
                        s = t.MeasureLayout, c.visualElement = yn(o, l, a, n, t.ProjectionNode)
                    }
                    return (0, ht.jsxs)(an.Provider, {
                        value: c,
                        children: [s && c.visualElement ? (0, ht.jsx)(s, {
                            visualElement: c.visualElement,
                            ...a
                        }) : null, i(o, t, pn(l, c.visualElement, e), l, u, c.visualElement)]
                    })
                }
                e && function(t) {
                    for (const e in t) hn.featureDefinitions[e] = { ...hn.featureDefinitions[e],
                        ...t[e]
                    }
                }(e), u.displayName = "motion.".concat("string" == typeof o ? o : "create(".concat(null !== (a = null !== (s = o.displayName) && void 0 !== s ? s : o.name) && void 0 !== a ? a : "", ")"));
                const c = (0, ft.forwardRef)(u);
                return c[fn] = o, c
            }

            function wn(t) {
                let {
                    layoutId: e
                } = t;
                const n = (0, ft.useContext)(mt.p).id;
                return n && void 0 !== e ? n + "-" + e : e
            }
            const Pn = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function En(t) {
                return "string" == typeof t && !t.includes("-") && !!(Pn.indexOf(t) > -1 || /[A-Z]/u.test(t))
            }
            var Tn = n(93723),
                Sn = n(86534);
            const Mn = t => (e, n) => {
                const i = (0, ft.useContext)(an),
                    r = (0, ft.useContext)(mn.O),
                    o = () => function({
                        scrapeMotionValuesFromProps: t,
                        createRenderState: e,
                        onUpdate: n
                    }, i, r, o) {
                        const s = {
                            latestValues: Cn(i, r, o, t),
                            renderState: e()
                        };
                        return n && (s.onMount = t => n({
                            props: i,
                            current: t,
                            ...s
                        }), s.onUpdate = t => n(t)), s
                    }(t, e, i, r);
                return n ? o() : (0, Sn.h)(o)
            };

            function Cn(t, e, n, i) {
                const o = {},
                    s = i(t, {});
                for (const t in s) o[t] = $t(s[t]);
                let {
                    initial: a,
                    animate: u
                } = t;
                const c = (0, un.G)(t),
                    l = (0, un.M)(t);
                e && l && !c && !1 !== t.inherit && (void 0 === a && (a = e.initial), void 0 === u && (u = e.animate));
                let d = !!n && !1 === n.initial;
                d = d || !1 === a;
                const h = d ? u : a;
                if (h && "boolean" != typeof h && !(0, r.H)(h)) {
                    const e = Array.isArray(h) ? h : [h];
                    for (let n = 0; n < e.length; n++) {
                        const i = (0, Tn.o)(t, e[n]);
                        if (i) {
                            const {
                                transitionEnd: t,
                                transition: e,
                                ...n
                            } = i;
                            for (const t in n) {
                                let e = n[t];
                                if (Array.isArray(e)) {
                                    e = e[d ? e.length - 1 : 0]
                                }
                                null !== e && (o[t] = e)
                            }
                            for (const e in t) o[e] = t[e]
                        }
                    }
                }
                return o
            }
            var Dn = n(11663),
                On = n(44761);
            const An = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {}
                }),
                kn = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {},
                    attrs: {}
                });
            var Rn = n(51177),
                _n = n(76380),
                jn = n(57338);
            const Ln = ["x", "y", "width", "height", "cx", "cy", "r"],
                Vn = {
                    useVisualState: Mn({
                        scrapeMotionValuesFromProps: jn.U,
                        createRenderState: kn,
                        onUpdate: ({
                            props: t,
                            prevProps: e,
                            current: n,
                            renderState: i,
                            latestValues: r
                        }) => {
                            if (!n) return;
                            let o = !!t.drag;
                            if (!o)
                                for (const t in r)
                                    if (Dn.G.has(t)) {
                                        o = !0;
                                        break
                                    }
                            if (!o) return;
                            let s = !e;
                            if (e)
                                for (let n = 0; n < Ln.length; n++) {
                                    const i = Ln[n];
                                    t[i] !== e[i] && (s = !0)
                                }
                            s && k.Wi.read((() => {
                                ! function(t, e) {
                                    try {
                                        e.dimensions = "function" == typeof t.getBBox ? t.getBBox() : t.getBoundingClientRect()
                                    } catch (t) {
                                        e.dimensions = {
                                            x: 0,
                                            y: 0,
                                            width: 0,
                                            height: 0
                                        }
                                    }
                                }(n, i), k.Wi.render((() => {
                                    (0, On.i)(i, r, (0, Rn.a)(n.tagName), t.transformTemplate), (0, _n.K)(n, i)
                                }))
                            }))
                        }
                    })
                };
            const Bn = {
                useVisualState: Mn({
                    scrapeMotionValuesFromProps: n(44980).U,
                    createRenderState: An
                })
            };
            var Nn = n(7892),
                Fn = n(70620);

            function $n(t, e, n) {
                for (const i in e)(0, Ft.i)(e[i]) || (0, Nn.j)(i, n) || (t[i] = e[i])
            }

            function In(t, e) {
                const n = {};
                return $n(n, t.style || {}, t), Object.assign(n, function({
                    transformTemplate: t
                }, e) {
                    return (0, ft.useMemo)((() => {
                        const n = {
                            style: {},
                            transform: {},
                            transformOrigin: {},
                            vars: {}
                        };
                        return (0, Fn.r)(n, e, t), Object.assign({}, n.vars, n.style)
                    }), [e])
                }(t, e)), n
            }

            function zn(t, e) {
                const n = {},
                    i = In(t, e);
                return t.drag && !1 !== t.dragListener && (n.draggable = !1, i.userSelect = i.WebkitUserSelect = i.WebkitTouchCallout = "none", i.touchAction = !0 === t.drag ? "none" : "pan-" + ("x" === t.drag ? "y" : "x")), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (n.tabIndex = 0), n.style = i, n
            }
            const Wn = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function Un(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || Wn.has(t)
            }
            let Hn = t => !Un(t);
            try {
                (Yn = require("@emotion/is-prop-valid").default) && (Hn = t => t.startsWith("on") ? !Un(t) : Yn(t))
            } catch (t) {}
            var Yn;

            function Xn(t, e, n, i) {
                const r = (0, ft.useMemo)((() => {
                    const n = {
                        style: {},
                        transform: {},
                        transformOrigin: {},
                        vars: {},
                        attrs: {}
                    };
                    return (0, On.i)(n, e, (0, Rn.a)(i), t.transformTemplate), { ...n.attrs,
                        style: { ...n.style
                        }
                    }
                }), [e]);
                if (t.style) {
                    const e = {};
                    $n(e, t.style, t), r.style = { ...e,
                        ...r.style
                    }
                }
                return r
            }

            function Zn(t = !1) {
                return (e, n, i, {
                    latestValues: r
                }, o) => {
                    const s = (En(e) ? Xn : zn)(n, r, o, e),
                        a = function(t, e, n) {
                            const i = {};
                            for (const r in t) "values" === r && "object" == typeof t.values || (Hn(r) || !0 === n && Un(r) || !e && !Un(r) || t.draggable && r.startsWith("onDrag")) && (i[r] = t[r]);
                            return i
                        }(n, "string" == typeof e, t),
                        u = e !== ft.Fragment ? { ...a,
                            ...s,
                            ref: i
                        } : {},
                        {
                            children: c
                        } = n,
                        l = (0, ft.useMemo)((() => (0, Ft.i)(c) ? c.get() : c), [c]);
                    return (0, ft.createElement)(e, { ...u,
                        children: l
                    })
                }
            }

            function Kn(t, e) {
                return function(n, {
                    forwardMotionProps: i
                } = {
                    forwardMotionProps: !1
                }) {
                    return xn({ ...En(n) ? Vn : Bn,
                        preloadedFeatures: t,
                        useRender: Zn(i),
                        createVisualElement: e,
                        Component: n
                    })
                }
            }
            var Gn = n(96952),
                qn = n(9464);
            const Jn = i(Kn({ ...w,
                ...nn,
                ...Xe,
                ...rn
            }, ((t, e) => En(t) ? new qn.e(e) : new Gn.W(e, {
                allowProjection: t !== ft.Fragment
            }))))
        },
        3789: function(t, e, n) {
            "use strict";
            n.d(e, {
                s: function() {
                    return v
                }
            });
            var i = n(11264);
            var r = n(25040),
                o = n(32833),
                s = n(55253);
            const a = new Set(["auto", "none", "0"]);
            var u = n(95990),
                c = n(55251),
                l = n(51767),
                d = n(59020);
            const h = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

            function f(t, e, n = 1) {
                (0, c.k)(n <= 4, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`);
                const [i, r] = function(t) {
                    const e = h.exec(t);
                    if (!e) return [, ];
                    const [, n, i, r] = e;
                    return [`--${null!=n?n:i}`, r]
                }(t);
                if (!i) return;
                const o = window.getComputedStyle(e).getPropertyValue(i);
                if (o) {
                    const t = o.trim();
                    return (0, l.P)(t) ? parseFloat(t) : t
                }
                return (0, d.t)(r) ? f(r, e, n + 1) : r
            }
            var p = n(15178),
                m = n(78571);
            class v extends u.e {
                constructor(t, e, n, i, r) {
                    super(t, e, n, i, r, !0)
                }
                readKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        element: e,
                        name: n
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let n = 0; n < t.length; n++) {
                        let i = t[n];
                        if ("string" == typeof i && (i = i.trim(), (0, d.t)(i))) {
                            const r = f(i, e.current);
                            void 0 !== r && (t[n] = r), n === t.length - 1 && (this.finalKeyframe = i)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !r.z.has(n) || 2 !== t.length) return;
                    const [i, o] = t, s = (0, m.C)(i), a = (0, m.C)(o);
                    if (s !== a)
                        if ((0, p.mP)(s) && (0, p.mP)(a))
                            for (let e = 0; e < t.length; e++) {
                                const n = t[e];
                                "string" == typeof n && (t[e] = parseFloat(n))
                            } else this.needsMeasurement = !0
                }
                resolveNoneKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, n = [];
                    for (let e = 0; e < t.length; e++)("number" == typeof(r = t[e]) ? 0 === r : null === r || "none" === r || "0" === r || (0, i.W)(r)) && n.push(e);
                    var r;
                    n.length && function(t, e, n) {
                        let i, r = 0;
                        for (; r < t.length && !i;) {
                            const e = t[r];
                            "string" == typeof e && !a.has(e) && (0, o.V)(e).values.length && (i = t[r]), r++
                        }
                        if (i && n)
                            for (const r of e) t[r] = (0, s.T)(n, i)
                    }(t, n, e)
                }
                measureInitialState() {
                    const {
                        element: t,
                        unresolvedKeyframes: e,
                        name: n
                    } = this;
                    if (!t || !t.current) return;
                    "height" === n && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = p.lw[n](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    const i = e[e.length - 1];
                    void 0 !== i && t.getValue(n, i).jump(i, !1)
                }
                measureEndState() {
                    var t;
                    const {
                        element: e,
                        name: n,
                        unresolvedKeyframes: i
                    } = this;
                    if (!e || !e.current) return;
                    const r = e.getValue(n);
                    r && r.jump(this.measuredOrigin, !1);
                    const o = i.length - 1,
                        s = i[o];
                    i[o] = p.lw[n](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== s && void 0 === this.finalKeyframe && (this.finalKeyframe = s), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach((([t, n]) => {
                        e.getValue(t).set(n)
                    })), this.resolveNoneKeyframes()
                }
            }
        },
        81091: function(t, e, n) {
            "use strict";
            n.d(e, {
                J: function() {
                    return s
                }
            });
            var i = n(27035),
                r = n(3789),
                o = n(29556);
            class s extends i.l {
                constructor() {
                    super(...arguments), this.KeyframeResolver = r.s
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: n
                }) {
                    delete e[t], delete n[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    const {
                        children: t
                    } = this.props;
                    (0, o.i)(t) && (this.childSubscription = t.on("change", (t => {
                        this.current && (this.current.textContent = `${t}`)
                    })))
                }
            }
        },
        38207: function(t, e, n) {
            "use strict";
            n.d(e, {
                D: function() {
                    return i
                }
            });
            const i = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase()
        },
        59020: function(t, e, n) {
            "use strict";
            n.d(e, {
                f: function() {
                    return r
                },
                t: function() {
                    return s
                }
            });
            const i = t => e => "string" == typeof e && e.startsWith(t),
                r = i("--"),
                o = i("var(--"),
                s = t => !!o(t) && a.test(t.split("/*")[0].trim()),
                a = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu
        },
        77553: function(t, e, n) {
            "use strict";

            function i(t) {
                return t instanceof SVGElement && "svg" !== t.tagName
            }
            n.d(e, {
                v: function() {
                    return i
                }
            })
        },
        15178: function(t, e, n) {
            "use strict";
            n.d(e, {
                Ei: function() {
                    return d
                },
                lw: function() {
                    return h
                },
                mP: function() {
                    return s
                }
            });
            var i = n(86911),
                r = n(60433),
                o = n(11663);
            const s = t => t === i.Rx || t === r.px,
                a = (t, e) => parseFloat(t.split(", ")[e]),
                u = (t, e) => (n, {
                    transform: i
                }) => {
                    if ("none" === i || !i) return 0;
                    const r = i.match(/^matrix3d\((.+)\)$/u);
                    if (r) return a(r[1], e); {
                        const e = i.match(/^matrix\((.+)\)$/u);
                        return e ? a(e[1], t) : 0
                    }
                },
                c = new Set(["x", "y", "z"]),
                l = o._.filter((t => !c.has(t)));

            function d(t) {
                const e = [];
                return l.forEach((n => {
                    const i = t.getValue(n);
                    void 0 !== i && (e.push([n, i.get()]), i.set(n.startsWith("scale") ? 1 : 0))
                })), e
            }
            const h = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: n = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(n),
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: n = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(n),
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: u(4, 13),
                y: u(5, 14)
            };
            h.translateX = h.x, h.translateY = h.y
        },
        55253: function(t, e, n) {
            "use strict";
            n.d(e, {
                T: function() {
                    return s
                }
            });
            var i = n(32833),
                r = n(45994),
                o = n(24171);

            function s(t, e) {
                let n = (0, o.A)(t);
                return n !== r.h && (n = i.P), n.getAnimatableNone ? n.getAnimatableNone(e) : void 0
            }
        },
        24171: function(t, e, n) {
            "use strict";
            n.d(e, {
                A: function() {
                    return s
                }
            });
            var i = n(96721),
                r = n(45994);
            const o = { ...n(49763).j,
                    color: i.$,
                    backgroundColor: i.$,
                    outlineColor: i.$,
                    fill: i.$,
                    stroke: i.$,
                    borderColor: i.$,
                    borderTopColor: i.$,
                    borderRightColor: i.$,
                    borderBottomColor: i.$,
                    borderLeftColor: i.$,
                    filter: r.h,
                    WebkitFilter: r.h
                },
                s = t => o[t]
        },
        78571: function(t, e, n) {
            "use strict";
            n.d(e, {
                $: function() {
                    return s
                },
                C: function() {
                    return a
                }
            });
            var i = n(86911),
                r = n(60433),
                o = n(79591);
            const s = [i.Rx, r.px, r.aQ, r.RW, r.vw, r.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                a = t => s.find((0, o.l)(t))
        },
        49763: function(t, e, n) {
            "use strict";
            n.d(e, {
                j: function() {
                    return u
                }
            });
            var i = n(86911),
                r = n(60433);
            const o = {
                    borderWidth: r.px,
                    borderTopWidth: r.px,
                    borderRightWidth: r.px,
                    borderBottomWidth: r.px,
                    borderLeftWidth: r.px,
                    borderRadius: r.px,
                    radius: r.px,
                    borderTopLeftRadius: r.px,
                    borderTopRightRadius: r.px,
                    borderBottomRightRadius: r.px,
                    borderBottomLeftRadius: r.px,
                    width: r.px,
                    maxWidth: r.px,
                    height: r.px,
                    maxHeight: r.px,
                    top: r.px,
                    right: r.px,
                    bottom: r.px,
                    left: r.px,
                    padding: r.px,
                    paddingTop: r.px,
                    paddingRight: r.px,
                    paddingBottom: r.px,
                    paddingLeft: r.px,
                    margin: r.px,
                    marginTop: r.px,
                    marginRight: r.px,
                    marginBottom: r.px,
                    marginLeft: r.px,
                    backgroundPositionX: r.px,
                    backgroundPositionY: r.px
                },
                s = {
                    rotate: r.RW,
                    rotateX: r.RW,
                    rotateY: r.RW,
                    rotateZ: r.RW,
                    scale: i.bA,
                    scaleX: i.bA,
                    scaleY: i.bA,
                    scaleZ: i.bA,
                    skew: r.RW,
                    skewX: r.RW,
                    skewY: r.RW,
                    distance: r.px,
                    translateX: r.px,
                    translateY: r.px,
                    translateZ: r.px,
                    x: r.px,
                    y: r.px,
                    z: r.px,
                    perspective: r.px,
                    transformPerspective: r.px,
                    opacity: i.Fq,
                    originX: r.$C,
                    originY: r.$C,
                    originZ: r.px
                },
                a = { ...i.Rx,
                    transform: Math.round
                },
                u = { ...o,
                    ...s,
                    zIndex: a,
                    size: r.px,
                    fillOpacity: i.Fq,
                    strokeOpacity: i.Fq,
                    numOctaves: a
                }
        },
        79591: function(t, e, n) {
            "use strict";
            n.d(e, {
                l: function() {
                    return i
                }
            });
            const i = t => e => e.test(t)
        },
        96952: function(t, e, n) {
            "use strict";
            n.d(e, {
                W: function() {
                    return d
                }
            });
            var i = n(81510),
                r = n(81091),
                o = n(59020),
                s = n(24171),
                a = n(70620),
                u = n(11663),
                c = n(47458),
                l = n(44980);
            class d extends r.J {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = c.N
                }
                readValueFromInstance(t, e) {
                    if (u.G.has(e)) {
                        const t = (0, s.A)(e);
                        return t && t.default || 0
                    } {
                        const i = (n = t, window.getComputedStyle(n)),
                            r = ((0, o.f)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof r ? r.trim() : r
                    }
                    var n
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return (0, i.J)(t, e)
                }
                build(t, e, n) {
                    (0, a.r)(t, e, n.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, n) {
                    return (0, l.U)(t, e, n)
                }
            }
        },
        70620: function(t, e, n) {
            "use strict";
            n.d(e, {
                r: function() {
                    return c
                }
            });
            var i = n(59020);
            const r = (t, e) => e && "number" == typeof t ? e.transform(t) : t;
            var o = n(49763),
                s = n(11663);
            const a = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                u = s._.length;

            function c(t, e, n) {
                const {
                    style: c,
                    vars: l,
                    transformOrigin: d
                } = t;
                let h = !1,
                    f = !1;
                for (const t in e) {
                    const n = e[t];
                    if (s.G.has(t)) h = !0;
                    else if ((0, i.f)(t)) l[t] = n;
                    else {
                        const e = r(n, o.j[t]);
                        t.startsWith("origin") ? (f = !0, d[t] = e) : c[t] = e
                    }
                }
                if (e.transform || (h || n ? c.transform = function(t, e, n) {
                        let i = "",
                            c = !0;
                        for (let l = 0; l < u; l++) {
                            const u = s._[l],
                                d = t[u];
                            if (void 0 === d) continue;
                            let h = !0;
                            if (h = "number" == typeof d ? d === (u.startsWith("scale") ? 1 : 0) : 0 === parseFloat(d), !h || n) {
                                const t = r(d, o.j[u]);
                                h || (c = !1, i += `${a[u]||u}(${t}) `), n && (e[u] = t)
                            }
                        }
                        return i = i.trim(), n ? i = n(e, c ? "" : i) : c && (i = "none"), i
                    }(e, t.transform, n) : c.transform && (c.transform = "none")), f) {
                    const {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: n = 0
                    } = d;
                    c.transformOrigin = `${t} ${e} ${n}`
                }
            }
        },
        25040: function(t, e, n) {
            "use strict";
            n.d(e, {
                z: function() {
                    return r
                }
            });
            var i = n(11663);
            const r = new Set(["width", "height", "top", "left", "right", "bottom", ...i._])
        },
        11663: function(t, e, n) {
            "use strict";
            n.d(e, {
                G: function() {
                    return r
                },
                _: function() {
                    return i
                }
            });
            const i = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                r = new Set(i)
        },
        47458: function(t, e, n) {
            "use strict";

            function i(t, {
                style: e,
                vars: n
            }, i, r) {
                Object.assign(t.style, e, r && r.getProjectionStyles(i));
                for (const e in n) t.style.setProperty(e, n[e])
            }
            n.d(e, {
                N: function() {
                    return i
                }
            })
        },
        44980: function(t, e, n) {
            "use strict";
            n.d(e, {
                U: function() {
                    return o
                }
            });
            var i = n(7892),
                r = n(29556);

            function o(t, e, n) {
                var o;
                const {
                    style: s
                } = t, a = {};
                for (const u in s)((0, r.i)(s[u]) || e.style && (0, r.i)(e.style[u]) || (0, i.j)(u, t) || void 0 !== (null === (o = null == n ? void 0 : n.getValue(u)) || void 0 === o ? void 0 : o.liveStyle)) && (a[u] = s[u]);
                return a
            }
        },
        69202: function(t, e, n) {
            "use strict";
            n.d(e, {
                R: function() {
                    return i
                }
            });
            const i = new WeakMap
        },
        9464: function(t, e, n) {
            "use strict";
            n.d(e, {
                e: function() {
                    return f
                }
            });
            var i = n(63431),
                r = n(81091),
                o = n(38207),
                s = n(24171),
                a = n(11663),
                u = n(44761),
                c = n(88732),
                l = n(51177),
                d = n(76380),
                h = n(57338);
            class f extends r.J {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = i.dO
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (a.G.has(e)) {
                        const t = (0, s.A)(e);
                        return t && t.default || 0
                    }
                    return e = c.s.has(e) ? e : (0, o.D)(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, n) {
                    return (0, h.U)(t, e, n)
                }
                build(t, e, n) {
                    (0, u.i)(t, e, this.isSVGTag, n.transformTemplate)
                }
                renderInstance(t, e, n, i) {
                    (0, d.K)(t, e, n, i)
                }
                mount(t) {
                    this.isSVGTag = (0, l.a)(t.tagName), super.mount(t)
                }
            }
        },
        44761: function(t, e, n) {
            "use strict";
            n.d(e, {
                i: function() {
                    return u
                }
            });
            var i = n(70620),
                r = n(60433);
            const o = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                s = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function a(t, e, n) {
                return "string" == typeof t ? t : r.px.transform(e + n * t)
            }

            function u(t, {
                attrX: e,
                attrY: n,
                attrScale: u,
                originX: c,
                originY: l,
                pathLength: d,
                pathSpacing: h = 1,
                pathOffset: f = 0,
                ...p
            }, m, v) {
                if ((0, i.r)(t, p, v), m) return void(t.style.viewBox && (t.attrs.viewBox = t.style.viewBox));
                t.attrs = t.style, t.style = {};
                const {
                    attrs: g,
                    style: y,
                    dimensions: b
                } = t;
                g.transform && (b && (y.transform = g.transform), delete g.transform), b && (void 0 !== c || void 0 !== l || y.transform) && (y.transformOrigin = function(t, e, n) {
                    return `${a(e,t.x,t.width)} ${a(n,t.y,t.height)}`
                }(b, void 0 !== c ? c : .5, void 0 !== l ? l : .5)), void 0 !== e && (g.x = e), void 0 !== n && (g.y = n), void 0 !== u && (g.scale = u), void 0 !== d && function(t, e, n = 1, i = 0, a = !0) {
                    t.pathLength = 1;
                    const u = a ? o : s;
                    t[u.offset] = r.px.transform(-i);
                    const c = r.px.transform(e),
                        l = r.px.transform(n);
                    t[u.array] = `${c} ${l}`
                }(g, d, h, f, !1)
            }
        },
        88732: function(t, e, n) {
            "use strict";
            n.d(e, {
                s: function() {
                    return i
                }
            });
            const i = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"])
        },
        51177: function(t, e, n) {
            "use strict";
            n.d(e, {
                a: function() {
                    return i
                }
            });
            const i = t => "string" == typeof t && "svg" === t.toLowerCase()
        },
        76380: function(t, e, n) {
            "use strict";
            n.d(e, {
                K: function() {
                    return s
                }
            });
            var i = n(38207),
                r = n(47458),
                o = n(88732);

            function s(t, e, n, s) {
                (0, r.N)(t, e, void 0, s);
                for (const n in e.attrs) t.setAttribute(o.s.has(n) ? n : (0, i.D)(n), e.attrs[n])
            }
        },
        57338: function(t, e, n) {
            "use strict";
            n.d(e, {
                U: function() {
                    return s
                }
            });
            var i = n(29556),
                r = n(11663),
                o = n(44980);

            function s(t, e, n) {
                const s = (0, o.U)(t, e, n);
                for (const n in t)
                    if ((0, i.i)(t[n]) || (0, i.i)(e[n])) {
                        s[-1 !== r._.indexOf(n) ? "attr" + n.charAt(0).toUpperCase() + n.substring(1) : n] = t[n]
                    }
                return s
            }
        },
        95990: function(t, e, n) {
            "use strict";
            n.d(e, {
                e: function() {
                    return d
                },
                m: function() {
                    return l
                }
            });
            var i = n(15178),
                r = n(79120);
            const o = new Set;
            let s = !1,
                a = !1;

            function u() {
                if (a) {
                    const t = Array.from(o).filter((t => t.needsMeasurement)),
                        e = new Set(t.map((t => t.element))),
                        n = new Map;
                    e.forEach((t => {
                        const e = (0, i.Ei)(t);
                        e.length && (n.set(t, e), t.render())
                    })), t.forEach((t => t.measureInitialState())), e.forEach((t => {
                        t.render();
                        const e = n.get(t);
                        e && e.forEach((([e, n]) => {
                            var i;
                            null === (i = t.getValue(e)) || void 0 === i || i.set(n)
                        }))
                    })), t.forEach((t => t.measureEndState())), t.forEach((t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    }))
                }
                a = !1, s = !1, o.forEach((t => t.complete())), o.clear()
            }

            function c() {
                o.forEach((t => {
                    t.readKeyframes(), t.needsMeasurement && (a = !0)
                }))
            }

            function l() {
                c(), u()
            }
            class d {
                constructor(t, e, n, i, r, o = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = n, this.motionValue = i, this.element = r, this.isAsync = o
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (o.add(this), s || (s = !0, r.Wi.read(c), r.Wi.resolveKeyframes(u))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    const {
                        unresolvedKeyframes: t,
                        name: e,
                        element: n,
                        motionValue: i
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r])
                            if (0 === r) {
                                const r = null == i ? void 0 : i.get(),
                                    o = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (n && e) {
                                    const i = n.readValue(e, o);
                                    null != i && (t[0] = i)
                                }
                                void 0 === t[0] && (t[0] = o), i && void 0 === r && i.set(t[0])
                            } else t[r] = t[r - 1]
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), o.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, o.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
        },
        74173: function(t, e, n) {
            "use strict";
            n.d(e, {
                G: function() {
                    return s
                },
                M: function() {
                    return a
                }
            });
            var i = n(32242),
                r = n(12182),
                o = n(86324);

            function s(t) {
                return (0, i.H)(t.animate) || o.V.some((e => (0, r.$)(t[e])))
            }

            function a(t) {
                return Boolean(s(t) || t.variants)
            }
        },
        12182: function(t, e, n) {
            "use strict";

            function i(t) {
                return "string" == typeof t || Array.isArray(t)
            }
            n.d(e, {
                $: function() {
                    return i
                }
            })
        },
        96984: function(t, e, n) {
            "use strict";
            n.d(e, {
                x: function() {
                    return r
                }
            });
            var i = n(93723);

            function r(t, e, n) {
                const r = t.getProps();
                return (0, i.o)(r, e, void 0 !== n ? n : r.custom, t)
            }
        },
        93723: function(t, e, n) {
            "use strict";

            function i(t) {
                const e = [{}, {}];
                return null == t || t.values.forEach(((t, n) => {
                    e[0][n] = t.get(), e[1][n] = t.getVelocity()
                })), e
            }

            function r(t, e, n, r) {
                if ("function" == typeof e) {
                    const [o, s] = i(r);
                    e = e(void 0 !== n ? n : t.custom, o, s)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    const [o, s] = i(r);
                    e = e(void 0 !== n ? n : t.custom, o, s)
                }
                return e
            }
            n.d(e, {
                o: function() {
                    return r
                }
            })
        },
        23572: function(t, e, n) {
            "use strict";
            n.d(e, {
                C: function() {
                    return a
                }
            });
            var i = n(57732),
                r = n(19114),
                o = n(96984);

            function s(t, e, n) {
                t.hasValue(e) ? t.getValue(e).set(n) : t.addValue(e, (0, r.BX)(n))
            }

            function a(t, e) {
                const n = (0, o.x)(t, e);
                let {
                    transitionEnd: r = {},
                    transition: a = {},
                    ...u
                } = n || {};
                u = { ...u,
                    ...r
                };
                for (const e in u) {
                    s(t, e, (0, i.Y)(u[e]))
                }
            }
        },
        86324: function(t, e, n) {
            "use strict";
            n.d(e, {
                V: function() {
                    return r
                },
                e: function() {
                    return i
                }
            });
            const i = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                r = ["initial", ...i]
        },
        37656: function(t, e, n) {
            "use strict";
            n.d(e, {
                c: function() {
                    return i
                }
            });
            const i = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        72365: function(t, e, n) {
            "use strict";

            function i(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function r(t, e) {
                const n = t.indexOf(e);
                n > -1 && t.splice(n, 1)
            }
            n.d(e, {
                cl: function() {
                    return r
                },
                y4: function() {
                    return i
                }
            })
        },
        12807: function(t, e, n) {
            "use strict";
            n.d(e, {
                u: function() {
                    return i
                }
            });
            const i = (t, e, n) => n > e ? e : n < t ? t : n
        },
        47729: function(t, e, n) {
            "use strict";
            n.d(e, {
                s: function() {
                    return c
                }
            });
            var i = n(89871),
                r = n(55251),
                o = n(67956),
                s = n(12807),
                a = n(84298),
                u = n(91052);

            function c(t, e, {
                clamp: n = !0,
                ease: c,
                mixer: l
            } = {}) {
                const d = t.length;
                if ((0, r.k)(d === e.length, "Both input and output ranges must be the same length"), 1 === d) return () => e[0];
                if (2 === d && e[0] === e[1]) return () => e[1];
                const h = t[0] === t[1];
                t[0] > t[d - 1] && (t = [...t].reverse(), e = [...e].reverse());
                const f = function(t, e, n) {
                        const r = [],
                            o = n || a.C,
                            s = t.length - 1;
                        for (let n = 0; n < s; n++) {
                            let s = o(t[n], t[n + 1]);
                            if (e) {
                                const t = Array.isArray(e) ? e[n] || i.Z : e;
                                s = (0, u.z)(t, s)
                            }
                            r.push(s)
                        }
                        return r
                    }(e, c, l),
                    p = f.length,
                    m = n => {
                        if (h && n < t[0]) return e[0];
                        let i = 0;
                        if (p > 1)
                            for (; i < t.length - 2 && !(n < t[i + 1]); i++);
                        const r = (0, o.Y)(t[i], t[i + 1], n);
                        return f[i](r)
                    };
                return n ? e => m((0, s.u)(t[0], t[d - 1], e)) : m
            }
        },
        43377: function(t, e, n) {
            "use strict";
            n.d(e, {
                j: function() {
                    return i
                }
            });
            const i = "undefined" != typeof window
        },
        51767: function(t, e, n) {
            "use strict";
            n.d(e, {
                P: function() {
                    return i
                }
            });
            const i = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t)
        },
        11264: function(t, e, n) {
            "use strict";
            n.d(e, {
                W: function() {
                    return i
                }
            });
            const i = t => /^0[^.\s]+$/u.test(t)
        },
        84298: function(t, e, n) {
            "use strict";
            n.d(e, {
                C: function() {
                    return T
                }
            });
            var i = n(17837),
                r = n(55251);

            function o(t, e, n) {
                return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? t + 6 * (e - t) * n : n < .5 ? e : n < 2 / 3 ? t + (e - t) * (2 / 3 - n) * 6 : t
            }
            var s = n(77261),
                a = n(81924),
                u = n(58376);

            function c(t, e) {
                return n => n > 0 ? e : t
            }
            const l = (t, e, n) => {
                    const i = t * t,
                        r = n * (e * e - i) + i;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                d = [s.$, a.m, u.J];

            function h(t) {
                const e = (n = t, d.find((t => t.test(n))));
                var n;
                if ((0, r.K)(Boolean(e), `'${t}' is not an animatable color. Use the equivalent color code instead.`), !Boolean(e)) return !1;
                let i = e.parse(t);
                return e === u.J && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: n,
                    alpha: i
                }) {
                    t /= 360, n /= 100;
                    let r = 0,
                        s = 0,
                        a = 0;
                    if (e /= 100) {
                        const i = n < .5 ? n * (1 + e) : n + e - n * e,
                            u = 2 * n - i;
                        r = o(u, i, t + 1 / 3), s = o(u, i, t), a = o(u, i, t - 1 / 3)
                    } else r = s = a = n;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * a),
                        alpha: i
                    }
                }(i)), i
            }
            const f = (t, e) => {
                const n = h(t),
                    r = h(e);
                if (!n || !r) return c(t, e);
                const o = { ...n
                };
                return t => (o.red = l(n.red, r.red, t), o.green = l(n.green, r.green, t), o.blue = l(n.blue, r.blue, t), o.alpha = (0, i.t)(n.alpha, r.alpha, t), a.m.transform(o))
            };
            var p = n(91052),
                m = n(96721),
                v = n(32833),
                g = n(59020);
            const y = new Set(["none", "hidden"]);

            function b(t, e) {
                return n => (0, i.t)(t, e, n)
            }

            function x(t) {
                return "number" == typeof t ? b : "string" == typeof t ? (0, g.t)(t) ? c : m.$.test(t) ? f : E : Array.isArray(t) ? w : "object" == typeof t ? m.$.test(t) ? f : P : c
            }

            function w(t, e) {
                const n = [...t],
                    i = n.length,
                    r = t.map(((t, n) => x(t)(t, e[n])));
                return t => {
                    for (let e = 0; e < i; e++) n[e] = r[e](t);
                    return n
                }
            }

            function P(t, e) {
                const n = { ...t,
                        ...e
                    },
                    i = {};
                for (const r in n) void 0 !== t[r] && void 0 !== e[r] && (i[r] = x(t[r])(t[r], e[r]));
                return t => {
                    for (const e in i) n[e] = i[e](t);
                    return n
                }
            }
            const E = (t, e) => {
                const n = v.P.createTransformer(e),
                    i = (0, v.V)(t),
                    o = (0, v.V)(e);
                return i.indexes.var.length === o.indexes.var.length && i.indexes.color.length === o.indexes.color.length && i.indexes.number.length >= o.indexes.number.length ? y.has(t) && !o.values.length || y.has(e) && !i.values.length ? function(t, e) {
                    return y.has(t) ? n => n <= 0 ? t : e : n => n >= 1 ? e : t
                }(t, e) : (0, p.z)(w(function(t, e) {
                    var n;
                    const i = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let o = 0; o < e.values.length; o++) {
                        const s = e.types[o],
                            a = t.indexes[s][r[s]],
                            u = null !== (n = t.values[a]) && void 0 !== n ? n : 0;
                        i[o] = u, r[s]++
                    }
                    return i
                }(i, o), o.values), n) : ((0, r.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), c(t, e))
            };

            function T(t, e, n) {
                if ("number" == typeof t && "number" == typeof e && "number" == typeof n) return (0, i.t)(t, e, n);
                return x(t)(t, e)
            }
        },
        17837: function(t, e, n) {
            "use strict";
            n.d(e, {
                t: function() {
                    return i
                }
            });
            const i = (t, e, n) => t + (e - t) * n
        },
        48545: function(t, e, n) {
            "use strict";
            n.d(e, {
                Y: function() {
                    return r
                }
            });
            var i = n(87430);

            function r(t) {
                const e = [0];
                return (0, i.c)(e, t.length - 1), e
            }
        },
        87430: function(t, e, n) {
            "use strict";
            n.d(e, {
                c: function() {
                    return o
                }
            });
            var i = n(67956),
                r = n(17837);

            function o(t, e) {
                const n = t[t.length - 1];
                for (let o = 1; o <= e; o++) {
                    const s = (0, i.Y)(0, e, o);
                    t.push((0, r.t)(n, 1, s))
                }
            }
        },
        91052: function(t, e, n) {
            "use strict";
            n.d(e, {
                z: function() {
                    return r
                }
            });
            const i = (t, e) => n => e(t(n)),
                r = (...t) => t.reduce(i)
        },
        57732: function(t, e, n) {
            "use strict";
            n.d(e, {
                Y: function() {
                    return o
                },
                p: function() {
                    return r
                }
            });
            var i = n(3967);
            const r = t => Boolean(t && "object" == typeof t && t.mix && t.toValue),
                o = t => (0, i.C)(t) ? t[t.length - 1] || 0 : t
        },
        57135: function(t, e, n) {
            "use strict";
            n.d(e, {
                L: function() {
                    return r
                }
            });
            var i = n(72365);
            class r {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return (0, i.y4)(this.subscriptions, t), () => (0, i.cl)(this.subscriptions, t)
                }
                notify(t, e, n) {
                    const i = this.subscriptions.length;
                    if (i)
                        if (1 === i) this.subscriptions[0](t, e, n);
                        else
                            for (let r = 0; r < i; r++) {
                                const i = this.subscriptions[r];
                                i && i(t, e, n)
                            }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
        },
        86534: function(t, e, n) {
            "use strict";
            n.d(e, {
                h: function() {
                    return r
                }
            });
            var i = n(84371);

            function r(t) {
                const e = (0, i.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        74940: function(t, e, n) {
            "use strict";
            n.d(e, {
                c: function() {
                    return i
                }
            });
            const i = {
                current: !1
            }
        },
        69682: function(t, e, n) {
            "use strict";
            n.d(e, {
                L: function() {
                    return r
                }
            });
            var i = n(84371);
            const r = n(43377).j ? i.useLayoutEffect : i.useEffect
        },
        75426: function(t, e, n) {
            "use strict";

            function i(t, e) {
                return e ? t * (1e3 / e) : 0
            }
            n.d(e, {
                R: function() {
                    return i
                }
            })
        },
        19114: function(t, e, n) {
            "use strict";
            n.d(e, {
                BX: function() {
                    return c
                },
                S1: function() {
                    return a
                }
            });
            var i = n(57440),
                r = n(57135),
                o = n(75426),
                s = n(79120);
            const a = {
                current: void 0
            };
            class u {
                constructor(t, e = {}) {
                    this.version = "11.18.2", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        const n = i.X.now();
                        this.updatedAt !== n && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    var e;
                    this.current = t, this.updatedAt = i.X.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = (e = this.current, !isNaN(parseFloat(e))))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new r.L);
                    const n = this.events[t].add(e);
                    return "change" === t ? () => {
                        n(), s.Wi.read((() => {
                            this.events.change.getSize() || this.stop()
                        }))
                    } : n
                }
                clearListeners() {
                    for (const t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, n) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - n
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return a.current && a.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    const t = i.X.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
                    const e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return (0, o.R)(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
                }
                start(t) {
                    return this.stop(), new Promise((e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    })).then((() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    }))
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function c(t, e) {
                return new u(t, e)
            }
        },
        77261: function(t, e, n) {
            "use strict";
            n.d(e, {
                $: function() {
                    return r
                }
            });
            var i = n(81924);
            const r = {
                test: (0, n(56283).i)("#"),
                parse: function(t) {
                    let e = "",
                        n = "",
                        i = "",
                        r = "";
                    return t.length > 5 ? (e = t.substring(1, 3), n = t.substring(3, 5), i = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), n = t.substring(2, 3), i = t.substring(3, 4), r = t.substring(4, 5), e += e, n += n, i += i, r += r), {
                        red: parseInt(e, 16),
                        green: parseInt(n, 16),
                        blue: parseInt(i, 16),
                        alpha: r ? parseInt(r, 16) / 255 : 1
                    }
                },
                transform: i.m.transform
            }
        },
        58376: function(t, e, n) {
            "use strict";
            n.d(e, {
                J: function() {
                    return a
                }
            });
            var i = n(86911),
                r = n(60433),
                o = n(29029),
                s = n(56283);
            const a = {
                test: (0, s.i)("hsl", "hue"),
                parse: (0, s.d)("hue", "saturation", "lightness"),
                transform: ({
                    hue: t,
                    saturation: e,
                    lightness: n,
                    alpha: s = 1
                }) => "hsla(" + Math.round(t) + ", " + r.aQ.transform((0, o.N)(e)) + ", " + r.aQ.transform((0, o.N)(n)) + ", " + (0, o.N)(i.Fq.transform(s)) + ")"
            }
        },
        96721: function(t, e, n) {
            "use strict";
            n.d(e, {
                $: function() {
                    return s
                }
            });
            var i = n(77261),
                r = n(58376),
                o = n(81924);
            const s = {
                test: t => o.m.test(t) || i.$.test(t) || r.J.test(t),
                parse: t => o.m.test(t) ? o.m.parse(t) : r.J.test(t) ? r.J.parse(t) : i.$.parse(t),
                transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? o.m.transform(t) : r.J.transform(t)
            }
        },
        81924: function(t, e, n) {
            "use strict";
            n.d(e, {
                m: function() {
                    return u
                }
            });
            var i = n(12807),
                r = n(86911),
                o = n(29029),
                s = n(56283);
            const a = { ...r.Rx,
                    transform: t => Math.round((t => (0, i.u)(0, 255, t))(t))
                },
                u = {
                    test: (0, s.i)("rgb", "red"),
                    parse: (0, s.d)("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: n,
                        alpha: i = 1
                    }) => "rgba(" + a.transform(t) + ", " + a.transform(e) + ", " + a.transform(n) + ", " + (0, o.N)(r.Fq.transform(i)) + ")"
                }
        },
        56283: function(t, e, n) {
            "use strict";
            n.d(e, {
                i: function() {
                    return o
                },
                d: function() {
                    return s
                }
            });
            var i = n(6701);
            const r = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
                o = (t, e) => n => Boolean("string" == typeof n && r.test(n) && n.startsWith(t) || e && ! function(t) {
                    return null == t
                }(n) && Object.prototype.hasOwnProperty.call(n, e)),
                s = (t, e, n) => r => {
                    if ("string" != typeof r) return r;
                    const [o, s, a, u] = r.match(i.K);
                    return {
                        [t]: parseFloat(o),
                        [e]: parseFloat(s),
                        [n]: parseFloat(a),
                        alpha: void 0 !== u ? parseFloat(u) : 1
                    }
                }
        },
        45994: function(t, e, n) {
            "use strict";
            n.d(e, {
                h: function() {
                    return u
                }
            });
            var i = n(32833),
                r = n(6701);
            const o = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function s(t) {
                const [e, n] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                const [i] = n.match(r.K) || [];
                if (!i) return t;
                const s = n.replace(i, "");
                let a = o.has(e) ? 1 : 0;
                return i !== n && (a *= 100), e + "(" + a + s + ")"
            }
            const a = /\b([a-z-]*)\(.*?\)/gu,
                u = { ...i.P,
                    getAnimatableNone: t => {
                        const e = t.match(a);
                        return e ? e.map(s).join(" ") : t
                    }
                }
        },
        32833: function(t, e, n) {
            "use strict";
            n.d(e, {
                V: function() {
                    return f
                },
                P: function() {
                    return g
                }
            });
            var i = n(96721);
            const r = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
            var o = n(6701),
                s = n(29029);
            const a = "number",
                u = "color",
                c = "var",
                l = "var(",
                d = "${}",
                h = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function f(t) {
                const e = t.toString(),
                    n = [],
                    r = {
                        color: [],
                        number: [],
                        var: []
                    },
                    o = [];
                let s = 0;
                const f = e.replace(h, (t => (i.$.test(t) ? (r.color.push(s), o.push(u), n.push(i.$.parse(t))) : t.startsWith(l) ? (r.var.push(s), o.push(c), n.push(t)) : (r.number.push(s), o.push(a), n.push(parseFloat(t))), ++s, d))).split(d);
                return {
                    values: n,
                    split: f,
                    indexes: r,
                    types: o
                }
            }

            function p(t) {
                return f(t).values
            }

            function m(t) {
                const {
                    split: e,
                    types: n
                } = f(t), r = e.length;
                return t => {
                    let o = "";
                    for (let c = 0; c < r; c++)
                        if (o += e[c], void 0 !== t[c]) {
                            const e = n[c];
                            o += e === a ? (0, s.N)(t[c]) : e === u ? i.$.transform(t[c]) : t[c]
                        }
                    return o
                }
            }
            const v = t => "number" == typeof t ? 0 : t;
            const g = {
                test: function(t) {
                    var e, n;
                    return isNaN(t) && "string" == typeof t && ((null === (e = t.match(o.K)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (n = t.match(r)) || void 0 === n ? void 0 : n.length) || 0) > 0
                },
                parse: p,
                createTransformer: m,
                getAnimatableNone: function(t) {
                    const e = p(t);
                    return m(t)(e.map(v))
                }
            }
        },
        86911: function(t, e, n) {
            "use strict";
            n.d(e, {
                Fq: function() {
                    return o
                },
                Rx: function() {
                    return r
                },
                bA: function() {
                    return s
                }
            });
            var i = n(12807);
            const r = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                o = { ...r,
                    transform: t => (0, i.u)(0, 1, t)
                },
                s = { ...r,
                    default: 1
                }
        },
        60433: function(t, e, n) {
            "use strict";
            n.d(e, {
                $C: function() {
                    return c
                },
                RW: function() {
                    return r
                },
                aQ: function() {
                    return o
                },
                px: function() {
                    return s
                },
                vh: function() {
                    return a
                },
                vw: function() {
                    return u
                }
            });
            const i = t => ({
                    test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                r = i("deg"),
                o = i("%"),
                s = i("px"),
                a = i("vh"),
                u = i("vw"),
                c = { ...o,
                    parse: t => o.parse(t) / 100,
                    transform: t => o.transform(100 * t)
                }
        },
        6701: function(t, e, n) {
            "use strict";
            n.d(e, {
                K: function() {
                    return i
                }
            });
            const i = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu
        },
        29029: function(t, e, n) {
            "use strict";
            n.d(e, {
                N: function() {
                    return i
                }
            });
            const i = t => Math.round(1e5 * t) / 1e5
        },
        56771: function(t, e, n) {
            "use strict";
            n.d(e, {
                c: function() {
                    return a
                }
            });
            var i = n(84371),
                r = n(19114),
                o = n(48460),
                s = n(86534);

            function a(t) {
                const e = (0, s.h)((() => (0, r.BX)(t))),
                    {
                        isStatic: n
                    } = (0, i.useContext)(o._);
                if (n) {
                    const [, n] = (0, i.useState)(t);
                    (0, i.useEffect)((() => e.on("change", n)), [])
                }
                return e
            }
        },
        84956: function(t, e, n) {
            "use strict";
            n.d(e, {
                v: function() {
                    return Z
                }
            });
            var i = n(19114),
                r = n(86534),
                o = n(84371),
                s = n(55251),
                a = n(37625),
                u = n(89871),
                c = n(79120);

            function l(t, e) {
                let n;
                const i = () => {
                    const {
                        currentTime: i
                    } = e, r = (null === i ? 0 : i.value) / 100;
                    n !== r && t(r), n = r
                };
                return c.Wi.update(i, !0), () => (0, c.Pn)(i)
            }
            const d = new WeakMap;
            let h;

            function f({
                target: t,
                contentRect: e,
                borderBoxSize: n
            }) {
                var i;
                null === (i = d.get(t)) || void 0 === i || i.forEach((i => {
                    i({
                        target: t,
                        contentSize: e,
                        get size() {
                            return function(t, e) {
                                if (e) {
                                    const {
                                        inlineSize: t,
                                        blockSize: n
                                    } = e[0];
                                    return {
                                        width: t,
                                        height: n
                                    }
                                }
                                return t instanceof SVGElement && "getBBox" in t ? t.getBBox() : {
                                    width: t.offsetWidth,
                                    height: t.offsetHeight
                                }
                            }(t, n)
                        }
                    })
                }))
            }

            function p(t) {
                t.forEach(f)
            }

            function m(t, e) {
                h || "undefined" != typeof ResizeObserver && (h = new ResizeObserver(p));
                const n = (0, a.IG)(t);
                return n.forEach((t => {
                    let n = d.get(t);
                    n || (n = new Set, d.set(t, n)), n.add(e), null == h || h.observe(t)
                })), () => {
                    n.forEach((t => {
                        const n = d.get(t);
                        null == n || n.delete(e), (null == n ? void 0 : n.size) || null == h || h.unobserve(t)
                    }))
                }
            }
            const v = new Set;
            let g;

            function y(t) {
                return v.add(t), g || (g = () => {
                    const t = {
                            width: window.innerWidth,
                            height: window.innerHeight
                        },
                        e = {
                            target: window,
                            size: t,
                            contentSize: t
                        };
                    v.forEach((t => t(e)))
                }, window.addEventListener("resize", g)), () => {
                    v.delete(t), !v.size && g && (g = void 0)
                }
            }
            var b = n(67956),
                x = n(75426);
            const w = 50,
                P = () => ({
                    time: 0,
                    x: {
                        current: 0,
                        offset: [],
                        progress: 0,
                        scrollLength: 0,
                        targetOffset: 0,
                        targetLength: 0,
                        containerLength: 0,
                        velocity: 0
                    },
                    y: {
                        current: 0,
                        offset: [],
                        progress: 0,
                        scrollLength: 0,
                        targetOffset: 0,
                        targetLength: 0,
                        containerLength: 0,
                        velocity: 0
                    }
                }),
                E = {
                    x: {
                        length: "Width",
                        position: "Left"
                    },
                    y: {
                        length: "Height",
                        position: "Top"
                    }
                };

            function T(t, e, n, i) {
                const r = n[e],
                    {
                        length: o,
                        position: s
                    } = E[e],
                    a = r.current,
                    u = n.time;
                r.current = t[`scroll${s}`], r.scrollLength = t[`scroll${o}`] - t[`client${o}`], r.offset.length = 0, r.offset[0] = 0, r.offset[1] = r.scrollLength, r.progress = (0, b.Y)(0, r.scrollLength, r.current);
                const c = i - u;
                r.velocity = c > w ? 0 : (0, x.R)(r.current - a, c)
            }
            var S = n(12807),
                M = n(47729),
                C = n(48545);
            const D = {
                start: 0,
                center: .5,
                end: 1
            };

            function O(t, e, n = 0) {
                let i = 0;
                if (t in D && (t = D[t]), "string" == typeof t) {
                    const e = parseFloat(t);
                    t.endsWith("px") ? i = e : t.endsWith("%") ? t = e / 100 : t.endsWith("vw") ? i = e / 100 * document.documentElement.clientWidth : t.endsWith("vh") ? i = e / 100 * document.documentElement.clientHeight : t = e
                }
                return "number" == typeof t && (i = e * t), n + i
            }
            const A = [0, 0];

            function k(t, e, n, i) {
                let r = Array.isArray(t) ? t : A,
                    o = 0,
                    s = 0;
                return "number" == typeof t ? r = [t, t] : "string" == typeof t && (r = (t = t.trim()).includes(" ") ? t.split(" ") : [t, D[t] ? t : "0"]), o = O(r[0], n, i), s = O(r[1], e), o - s
            }
            const R = {
                    Enter: [
                        [0, 1],
                        [1, 1]
                    ],
                    Exit: [
                        [0, 0],
                        [1, 0]
                    ],
                    Any: [
                        [1, 0],
                        [0, 1]
                    ],
                    All: [
                        [0, 0],
                        [1, 1]
                    ]
                },
                _ = {
                    x: 0,
                    y: 0
                };

            function j(t, e, n) {
                const {
                    offset: i = R.All
                } = n, {
                    target: r = t,
                    axis: o = "y"
                } = n, s = "y" === o ? "height" : "width", a = r !== t ? function(t, e) {
                    const n = {
                        x: 0,
                        y: 0
                    };
                    let i = t;
                    for (; i && i !== e;)
                        if (i instanceof HTMLElement) n.x += i.offsetLeft, n.y += i.offsetTop, i = i.offsetParent;
                        else if ("svg" === i.tagName) {
                        const t = i.getBoundingClientRect();
                        i = i.parentElement;
                        const e = i.getBoundingClientRect();
                        n.x += t.left - e.left, n.y += t.top - e.top
                    } else {
                        if (!(i instanceof SVGGraphicsElement)) break; {
                            const {
                                x: t,
                                y: e
                            } = i.getBBox();
                            n.x += t, n.y += e;
                            let r = null,
                                o = i.parentNode;
                            for (; !r;) "svg" === o.tagName && (r = o), o = i.parentNode;
                            i = r
                        }
                    }
                    return n
                }(r, t) : _, u = r === t ? {
                    width: t.scrollWidth,
                    height: t.scrollHeight
                } : function(t) {
                    return "getBBox" in t && "svg" !== t.tagName ? t.getBBox() : {
                        width: t.clientWidth,
                        height: t.clientHeight
                    }
                }(r), c = {
                    width: t.clientWidth,
                    height: t.clientHeight
                };
                e[o].offset.length = 0;
                let l = !e[o].interpolate;
                const d = i.length;
                for (let t = 0; t < d; t++) {
                    const n = k(i[t], c[s], u[s], a[o]);
                    l || n === e[o].interpolatorOffsets[t] || (l = !0), e[o].offset[t] = n
                }
                l && (e[o].interpolate = (0, M.s)(e[o].offset, (0, C.Y)(i), {
                    clamp: !1
                }), e[o].interpolatorOffsets = [...e[o].offset]), e[o].progress = (0, S.u)(0, 1, e[o].interpolate(e[o].current))
            }

            function L(t, e, n, i = {}) {
                return {
                    measure: () => function(t, e = t, n) {
                        if (n.x.targetOffset = 0, n.y.targetOffset = 0, e !== t) {
                            let i = e;
                            for (; i && i !== t;) n.x.targetOffset += i.offsetLeft, n.y.targetOffset += i.offsetTop, i = i.offsetParent
                        }
                        n.x.targetLength = e === t ? e.scrollWidth : e.clientWidth, n.y.targetLength = e === t ? e.scrollHeight : e.clientHeight, n.x.containerLength = t.clientWidth, n.y.containerLength = t.clientHeight
                    }(t, i.target, n),
                    update: e => {
                        ! function(t, e, n) {
                            T(t, "x", e, n), T(t, "y", e, n), e.time = n
                        }(t, n, e), (i.offset || i.target) && j(t, n, i)
                    },
                    notify: () => e(n)
                }
            }
            const V = new WeakMap,
                B = new WeakMap,
                N = new WeakMap,
                F = t => t === document.documentElement ? window : t;

            function $(t, {
                container: e = document.documentElement,
                ...n
            } = {}) {
                let i = N.get(e);
                i || (i = new Set, N.set(e, i));
                const r = P(),
                    o = L(e, t, r, n);
                if (i.add(o), !V.has(e)) {
                    const t = () => {
                            for (const t of i) t.measure()
                        },
                        n = () => {
                            for (const t of i) t.update(c.frameData.timestamp)
                        },
                        r = () => {
                            for (const t of i) t.notify()
                        },
                        o = () => {
                            c.Wi.read(t, !1, !0), c.Wi.read(n, !1, !0), c.Wi.update(r, !1, !0)
                        };
                    V.set(e, o);
                    const u = F(e);
                    window.addEventListener("resize", o, {
                        passive: !0
                    }), e !== document.documentElement && B.set(e, (a = o, "function" == typeof(s = e) ? y(s) : m(s, a))), u.addEventListener("scroll", o, {
                        passive: !0
                    })
                }
                var s, a;
                const u = V.get(e);
                return c.Wi.read(u, !1, !0), () => {
                    var t;
                    (0, c.Pn)(u);
                    const n = N.get(e);
                    if (!n) return;
                    if (n.delete(o), n.size) return;
                    const i = V.get(e);
                    V.delete(e), i && (F(e).removeEventListener("scroll", i), null === (t = B.get(e)) || void 0 === t || t(), window.removeEventListener("resize", i))
                }
            }
            const I = new Map;

            function z({
                source: t,
                container: e = document.documentElement,
                axis: n = "y"
            } = {}) {
                t && (e = t), I.has(e) || I.set(e, {});
                const i = I.get(e);
                return i[n] || (i[n] = (0, a.tn)() ? new ScrollTimeline({
                    source: e,
                    axis: n
                }) : function({
                    source: t,
                    container: e,
                    axis: n = "y"
                }) {
                    t && (e = t);
                    const i = {
                            value: 0
                        },
                        r = $((t => {
                            i.value = 100 * t[n].progress
                        }), {
                            container: e,
                            axis: n
                        });
                    return {
                        currentTime: i,
                        cancel: r
                    }
                }({
                    source: e,
                    axis: n
                })), i[n]
            }

            function W(t) {
                return t && (t.target || t.offset)
            }

            function U(t, {
                axis: e = "y",
                ...n
            } = {}) {
                const i = {
                    axis: e,
                    ...n
                };
                return "function" == typeof t ? function(t, e) {
                    return function(t) {
                        return 2 === t.length
                    }(t) || W(e) ? $((n => {
                        t(n[e.axis].progress, n)
                    }), e) : l(t, z(e))
                }(t, i) : function(t, e) {
                    if (t.flatten(), W(e)) return t.pause(), $((n => {
                        t.time = t.duration * n[e.axis].progress
                    }), e); {
                        const n = z(e);
                        return t.attachTimeline ? t.attachTimeline(n, (t => (t.pause(), l((e => {
                            t.time = t.duration * e
                        }), n)))) : u.Z
                    }
                }(t, i)
            }
            var H = n(69682);

            function Y(t, e) {
                (0, s.K)(Boolean(!e || e.current), `You have defined a ${t} options but the provided ref is not yet hydrated, probably because it's defined higher up the tree. Try calling useScroll() in the same component as the ref, or setting its \`layoutEffect: false\` option.`)
            }
            const X = () => ({
                scrollX: (0, i.BX)(0),
                scrollY: (0, i.BX)(0),
                scrollXProgress: (0, i.BX)(0),
                scrollYProgress: (0, i.BX)(0)
            });

            function Z({
                container: t,
                target: e,
                layoutEffect: n = !0,
                ...i
            } = {}) {
                const s = (0, r.h)(X);
                return (n ? H.L : o.useEffect)((() => (Y("target", e), Y("container", t), U(((t, {
                    x: e,
                    y: n
                }) => {
                    s.scrollX.set(e.current), s.scrollXProgress.set(e.progress), s.scrollY.set(n.current), s.scrollYProgress.set(n.progress)
                }), { ...i,
                    container: (null == t ? void 0 : t.current) || void 0,
                    target: (null == e ? void 0 : e.current) || void 0
                }))), [t, e, JSON.stringify(i.offset)]), s
            }
        },
        30664: function(t, e, n) {
            "use strict";
            n.d(e, {
                q: function() {
                    return d
                }
            });
            var i = n(84371),
                r = n(17495),
                o = n(48460),
                s = n(69682),
                a = n(56771),
                u = n(29556),
                c = n(79120);

            function l(t) {
                return "number" == typeof t ? t : parseFloat(t)
            }

            function d(t, e = {}) {
                const {
                    isStatic: n
                } = (0, i.useContext)(o._), d = (0, i.useRef)(null), h = (0, a.c)((0, u.i)(t) ? l(t.get()) : t), f = (0, i.useRef)(h.get()), p = (0, i.useRef)((() => {})), m = () => {
                    const t = d.current;
                    t && 0 === t.time && t.sample(c.frameData.delta), v(), d.current = (0, r.y)({
                        keyframes: [h.get(), f.current],
                        velocity: h.getVelocity(),
                        type: "spring",
                        restDelta: .001,
                        restSpeed: .01,
                        ...e,
                        onUpdate: p.current
                    })
                }, v = () => {
                    d.current && d.current.stop()
                };
                return (0, i.useInsertionEffect)((() => h.attach(((t, e) => n ? e(t) : (f.current = t, p.current = e, c.Wi.update(m), h.get())), v)), [JSON.stringify(e)]), (0, s.L)((() => {
                    if ((0, u.i)(t)) return t.on("change", (t => h.set(l(t))))
                }), [h]), h
            }
        },
        29172: function(t, e, n) {
            "use strict";
            n.d(e, {
                H: function() {
                    return d
                }
            });
            var i = n(47729);
            const r = t => (t => t && "object" == typeof t && t.mix)(t) ? t.mix : void 0;
            var o = n(56771),
                s = n(69682),
                a = n(79120);

            function u(t, e) {
                const n = (0, o.c)(e()),
                    i = () => n.set(e());
                return i(), (0, s.L)((() => {
                    const e = () => a.Wi.preRender(i, !1, !0),
                        n = t.map((t => t.on("change", e)));
                    return () => {
                        n.forEach((t => t())), (0, a.Pn)(i)
                    }
                })), n
            }
            var c = n(86534),
                l = n(19114);

            function d(t, e, n, o) {
                if ("function" == typeof t) return function(t) {
                    l.S1.current = [], t();
                    const e = u(l.S1.current, t);
                    return l.S1.current = void 0, e
                }(t);
                const s = "function" == typeof e ? e : function(...t) {
                    const e = !Array.isArray(t[0]),
                        n = e ? 0 : -1,
                        o = t[0 + n],
                        s = t[1 + n],
                        a = t[2 + n],
                        u = t[3 + n],
                        c = (0, i.s)(s, a, {
                            mixer: r(a[0]),
                            ...u
                        });
                    return e ? c(o) : c
                }(e, n, o);
                return Array.isArray(t) ? h(t, s) : h([t], (([t]) => s(t)))
            }

            function h(t, e) {
                const n = (0, c.h)((() => []));
                return u(t, (() => {
                    n.length = 0;
                    const i = t.length;
                    for (let e = 0; e < i; e++) n[e] = t[e].get();
                    return e(n)
                }))
            }
        },
        68138: function(t, e, n) {
            "use strict";
            n.d(e, {
                K: function() {
                    return r
                }
            });
            var i = n(29556);

            function r(t, e) {
                const n = t.getValue("willChange");
                if (r = n, Boolean((0, i.i)(r) && r.add)) return n.add(e);
                var r
            }
        },
        29556: function(t, e, n) {
            "use strict";
            n.d(e, {
                i: function() {
                    return i
                }
            });
            const i = t => Boolean(t && t.getVelocity)
        },
        37625: function(t, e, n) {
            "use strict";
            n.d(e, {
                sP: function() {
                    return s
                },
                _F: function() {
                    return f
                },
                iI: function() {
                    return c
                },
                S9: function() {
                    return d
                },
                wk: function() {
                    return b
                },
                ev: function() {
                    return a
                },
                Mr: function() {
                    return O
                },
                qE: function() {
                    return p
                },
                xD: function() {
                    return h
                },
                DJ: function() {
                    return k
                },
                hR: function() {
                    return x
                },
                eB: function() {
                    return E
                },
                EO: function() {
                    return u
                },
                OD: function() {
                    return N
                },
                IG: function() {
                    return M
                },
                KV: function() {
                    return F
                },
                Vc: function() {
                    return g
                },
                tn: function() {
                    return r
                }
            });
            var i = n(26654);
            const r = (0, i.X)((() => void 0 !== window.ScrollTimeline));
            class o {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                get finished() {
                    return Promise.all(this.animations.map((t => "finished" in t ? t.finished : t)))
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let n = 0; n < this.animations.length; n++) this.animations[n][t] = e
                }
                attachTimeline(t, e) {
                    const n = this.animations.map((n => r() && n.attachTimeline ? n.attachTimeline(t) : "function" == typeof e ? e(n) : void 0));
                    return () => {
                        n.forEach(((t, e) => {
                            t && t(), this.animations[e].stop()
                        }))
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach((e => e[t]()))
                }
                flatten() {
                    this.runAll("flatten")
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            class s extends o {
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
            }

            function a(t, e) {
                return t ? t[e] || t.default || t : void 0
            }
            const u = 2e4;

            function c(t) {
                let e = 0;
                let n = t.next(e);
                for (; !n.done && e < u;) e += 50, n = t.next(e);
                return e >= u ? 1 / 0 : e
            }
            var l = n(42772);

            function d(t, e = 100, n) {
                const i = n({ ...t,
                        keyframes: [0, e]
                    }),
                    r = Math.min(c(i), u);
                return {
                    type: "keyframes",
                    ease: t => i.next(r * t).value / e,
                    duration: (0, l.X)(r)
                }
            }

            function h(t) {
                return "function" == typeof t
            }

            function f(t, e) {
                t.timeline = e, t.onfinish = null
            }
            const p = t => Array.isArray(t) && "number" == typeof t[0],
                m = {
                    linearEasing: void 0
                };

            function v(t, e) {
                const n = (0, i.X)(t);
                return () => {
                    var t;
                    return null !== (t = m[e]) && void 0 !== t ? t : n()
                }
            }
            const g = v((() => {
                try {
                    document.createElement("div").animate({
                        opacity: 0
                    }, {
                        easing: "linear(0, 1)"
                    })
                } catch (t) {
                    return !1
                }
                return !0
            }), "linearEasing");
            var y = n(67956);
            const b = (t, e, n = 10) => {
                let i = "";
                const r = Math.max(Math.round(e / n), 2);
                for (let e = 0; e < r; e++) i += t((0, y.Y)(0, r - 1, e)) + ", ";
                return `linear(${i.substring(0,i.length-2)})`
            };

            function x(t) {
                return Boolean("function" == typeof t && g() || !t || "string" == typeof t && (t in P || g()) || p(t) || Array.isArray(t) && t.every(x))
            }
            const w = ([t, e, n, i]) => `cubic-bezier(${t}, ${e}, ${n}, ${i})`,
                P = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: w([0, .65, .55, 1]),
                    circOut: w([.55, 0, 1, .45]),
                    backIn: w([.31, .01, .66, -.59]),
                    backOut: w([.33, 1.53, .69, .99])
                };

            function E(t, e) {
                return t ? "function" == typeof t && g() ? b(t, e) : p(t) ? w(t) : Array.isArray(t) ? t.map((t => E(t, e) || P.easeOut)) : P[t] : void 0
            }
            const T = {
                x: !1,
                y: !1
            };

            function S() {
                return T.x || T.y
            }

            function M(t, e, n) {
                var i;
                if (t instanceof Element) return [t];
                if ("string" == typeof t) {
                    let r = document;
                    e && (r = e.current);
                    const o = null !== (i = null == n ? void 0 : n[t]) && void 0 !== i ? i : r.querySelectorAll(t);
                    return o ? Array.from(o) : []
                }
                return Array.from(t)
            }

            function C(t, e) {
                const n = M(t),
                    i = new AbortController;
                return [n, {
                    passive: !0,
                    ...e,
                    signal: i.signal
                }, () => i.abort()]
            }

            function D(t) {
                return e => {
                    "touch" === e.pointerType || S() || t(e)
                }
            }

            function O(t, e, n = {}) {
                const [i, r, o] = C(t, n), s = D((t => {
                    const {
                        target: n
                    } = t, i = e(t);
                    if ("function" != typeof i || !n) return;
                    const o = D((t => {
                        i(t), n.removeEventListener("pointerleave", o)
                    }));
                    n.addEventListener("pointerleave", o, r)
                }));
                return i.forEach((t => {
                    t.addEventListener("pointerenter", s, r)
                })), o
            }
            const A = (t, e) => !!e && (t === e || A(t, e.parentElement)),
                k = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary,
                R = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
            const _ = new WeakSet;

            function j(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function L(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }
            const V = (t, e) => {
                const n = t.currentTarget;
                if (!n) return;
                const i = j((() => {
                    if (_.has(n)) return;
                    L(n, "down");
                    const t = j((() => {
                        L(n, "up")
                    }));
                    n.addEventListener("keyup", t, e), n.addEventListener("blur", (() => L(n, "cancel")), e)
                }));
                n.addEventListener("keydown", i, e), n.addEventListener("blur", (() => n.removeEventListener("keydown", i)), e)
            };

            function B(t) {
                return k(t) && !S()
            }

            function N(t, e, n = {}) {
                const [i, r, o] = C(t, n), s = t => {
                    const i = t.currentTarget;
                    if (!B(t) || _.has(i)) return;
                    _.add(i);
                    const o = e(t),
                        s = (t, e) => {
                            window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", u), B(t) && _.has(i) && (_.delete(i), "function" == typeof o && o(t, {
                                success: e
                            }))
                        },
                        a = t => {
                            s(t, n.useGlobalTarget || A(i, t.target))
                        },
                        u = t => {
                            s(t, !1)
                        };
                    window.addEventListener("pointerup", a, r), window.addEventListener("pointercancel", u, r)
                };
                return i.forEach((t => {
                    (function(t) {
                        return R.has(t.tagName) || -1 !== t.tabIndex
                    })(t) || null !== t.getAttribute("tabindex") || (t.tabIndex = 0);
                    (n.useGlobalTarget ? window : t).addEventListener("pointerdown", s, r), t.addEventListener("focus", (t => V(t, r)), r)
                })), o
            }
            n(89871);

            function F(t) {
                return "x" === t || "y" === t ? T[t] ? null : (T[t] = !0, () => {
                    T[t] = !1
                }) : T.x || T.y ? null : (T.x = T.y = !0, () => {
                    T.x = T.y = !1
                })
            }
        },
        55251: function(t, e, n) {
            "use strict";
            n.d(e, {
                K: function() {
                    return r
                },
                k: function() {
                    return o
                }
            });
            var i = n(89871);
            let r = i.Z,
                o = i.Z
        },
        26654: function(t, e, n) {
            "use strict";

            function i(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
            n.d(e, {
                X: function() {
                    return i
                }
            })
        },
        89871: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return i
                }
            });
            const i = t => t
        },
        67956: function(t, e, n) {
            "use strict";
            n.d(e, {
                Y: function() {
                    return i
                }
            });
            const i = (t, e, n) => {
                const i = e - t;
                return 0 === i ? 1 : (n - t) / i
            }
        },
        42772: function(t, e, n) {
            "use strict";
            n.d(e, {
                X: function() {
                    return r
                },
                w: function() {
                    return i
                }
            });
            const i = t => 1e3 * t,
                r = t => t / 1e3
        }
    }
]);