! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "0630433d-266b-467e-9b64-8564c86d4ea0", e._sentryDebugIdIdentifier = "sentry-dbid-0630433d-266b-467e-9b64-8564c86d4ea0")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5298], {
        64746: function(e, t, n) {
            "use strict";
            var r = n(46055),
                a = n(18562),
                o = n(42466),
                i = n(13561);
            t.Z = function() {
                const e = (0, a.useLocale)(),
                    t = (0, r.useRouter)(),
                    n = (0, r.usePathname)();
                return {
                    currentLanguage: e,
                    changeLanguage: async e => {
                        const r = n.split("/");
                        let a = n;
                        Object.values(o.i).includes(r[1]) ? (r[1] = e, a = r.join("/")) : a = "/".concat(e).concat(n);
                        try {
                            await (0, i.jp)(e), t.push(a)
                        } catch (e) {
                            throw t.push(a), e
                        }
                    }
                }
            }
        },
        93330: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return _
                }
            });
            var r = n(75467),
                a = n(9850),
                o = n.n(a),
                i = n(29172),
                s = n(79245),
                l = n(42140),
                c = n(16924),
                d = n(46055),
                p = n(18562),
                f = n(84371),
                u = n(57064),
                h = n(12556),
                x = n(98534),
                m = n(73258),
                b = n(89242),
                v = n(89872),
                g = n(13561),
                w = n(55043);

            function C() {
                return w.WY.get("/maintain")
            }
            var A = n(761),
                F = n(19697);
            const j = [{
                    backgroundColor: "transparent",
                    backdropFilter: "blur(0px)",
                    boxShadow: "0 0 #fff",
                    color: "rgba(255,255,255,0.7)",
                    borderColor: "transparent",
                    hoverColor: "text-white",
                    hoverBgColor: "rgba(255,255,255,0.1)",
                    iconColor: "#fff",
                    navBgColor: "transparent",
                    popupBgColor: "rgba(0,0,0,0.7)",
                    popupItemColor: "rgba(255, 255, 255, 0.5)",
                    popupBoxShadow: "0px 0px 1px 1px #FFFFFF1A inset, 0px 0px 0px 1px #0000004D"
                }, {
                    backgroundColor: "rgba(255,255,255,0.1)",
                    backdropFilter: "blur(17px)",
                    boxShadow: "inset 0 0 1px rgba(255,255,255,0.3)",
                    color: "rgba(255,255,255,0.7)",
                    borderColor: "rgba(255,255,255,0.04)",
                    hoverColor: "text-white",
                    hoverBgColor: "rgba(255,255,255,0.08)",
                    iconColor: "#fff",
                    navBgColor: "transparent",
                    popupBgColor: "rgba(255,255,255,0.1)",
                    popupItemColor: "rgba(255, 255, 255, 0.5)",
                    popupBoxShadow: "0px 0px 1px 1px #FFFFFF1A inset, 0px 0px 0px 1px #0000004D"
                }, {
                    backgroundColor: "rgba(255,255,255,0.6)",
                    backdropFilter: "blur(30px)",
                    boxShadow: "inset 0 0 2px rgba(255,255,255,0.63)",
                    color: "rgba(0,0,0,0.5)",
                    borderColor: "rgba(0,0,0,0.04)",
                    hoverColor: "text-black",
                    hoverBgColor: "rgba(0,0,0,0.1)",
                    iconColor: "#000",
                    navBgColor: "transparent",
                    popupBgColor: "rgba(255,255,255,0.6)",
                    popupItemColor: "rgba(0, 0, 0, 0.5)",
                    popupBoxShadow: "0px 0px 2px 1px #FFFFFF4D inset, 0px 0px 0px 1px #00000014 inset,0px 8px 8px -6px #0000000D"
                }, {
                    backgroundColor: "#FFFFFF1A",
                    backdropFilter: "blur(17px)",
                    boxShadow: "inset 0 0 2px rgba(255,255,255,0.63)",
                    color: "rgba(0,0,0,0.5)",
                    borderColor: "rgba(0,0,0,0.04)",
                    hoverColor: "text-black",
                    hoverBgColor: "rgba(0,0,0,0.1)",
                    iconColor: "#fff",
                    navBgColor: "transparent",
                    popupBgColor: "#EEECEAB2",
                    popupItemColor: "rgba(0, 0, 0, 0.5)",
                    popupBoxShadow: "0px 0px 2px 2px #FFFFFFA1 inset, 0px 0px 0px 1px #00000014 inset,0px 8px 8px -6px #0000000D"
                }],
                z = [{
                    text: "Navigation_NavBar_Text",
                    path: "/best-practices",
                    link: "/best-practices",
                    open: !0,
                    width: 138,
                    left: 5
                }, {
                    text: "Navigation_NavBar_Text",
                    path: "/Help",
                    link: "https://help.wegic.ai/",
                    open: !0,
                    width: 121,
                    left: 147
                }, {
                    text: "Navigation_NavBar_Text",
                    path: "/pricing",
                    link: "/pricing",
                    width: 88,
                    left: 271
                }];
            var N = n(88896),
                S = n.n(N),
                B = n(89733);
            n(50912);
            var O, y = n(17890),
                E = n(47667),
                D = n(52818);

            function I() {
                return I = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, I.apply(this, arguments)
            }
            var T, Q = function(e) {
                return D.createElement("svg", I({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 24,
                    height: 24,
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), O || (O = D.createElement("path", {
                    stroke: "currentColor",
                    strokeLinecap: "square",
                    strokeWidth: 1.8,
                    d: "M12 21.429c5.264 0 9.53-4.222 9.53-9.43S17.265 2.572 12 2.572m0 18.858c-5.263 0-9.53-4.222-9.53-9.43S6.737 2.572 12 2.572m0 18.858c-2.418 0-4.379-4.222-4.379-9.43s1.96-9.428 4.38-9.428m0 18.858c2.418 0 4.378-4.222 4.378-9.43S14.419 2.572 12 2.572M21.273 12H2.727"
                })))
            };

            function Z() {
                return Z = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, Z.apply(this, arguments)
            }
            var P = function(e) {
                    return D.createElement("svg", Z({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 10,
                        height: 6,
                        fill: "none",
                        viewBox: "0 0 10 6"
                    }, e), T || (T = D.createElement("path", {
                        fill: "currentColor",
                        d: "M5 .657h3.243c.89 0 1.337 1.077.707 1.707L5.707 5.607a1 1 0 0 1-1.414 0L1.05 2.364C.42 1.734.866.657 1.757.657z"
                    })))
                },
                W = n(64746),
                R = n(29272),
                L = n.n(R);
            var K, k, G = function(e) {
                    const {
                        wrapClassName: t,
                        popupStyle: n
                    } = e, {
                        popupBgColor: a,
                        hoverBgColor: i,
                        popupItemColor: s,
                        popupBoxShadow: l
                    } = n, {
                        currentLanguage: c,
                        changeLanguage: d
                    } = (0, W.Z)(), [u, h] = (0, f.useState)(!1), x = (0, p.useTranslations)(), m = (0, f.useRef)(null), [b, g] = (0, f.useState)(-1), w = v.Nm[c].country, C = w ? "(".concat(x(w), ")") : "", A = (0, f.useMemo)((() => {
                        const e = Object.keys(v.Nm);
                        return (0, r.jsx)("div", {
                            style: {
                                backgroundColor: a,
                                boxShadow: l
                            },
                            className: "backdrop-blur-[30px] bg-white/[0.1] min-w-[129px] overflow-hidden relative rounded-xl pr-0.5 z-10",
                            children: (0, r.jsx)("div", {
                                style: {
                                    "--scrollbar-thumb-bgColor": i
                                },
                                className: o()("max-h-[330px] overflow-y-auto overscroll-none flex p-1 flex-col gap-1 rounded-xl", L()["language-scroll"]),
                                children: e.map(((e, t) => {
                                    const n = b === t,
                                        a = e === c,
                                        o = v.Nm[e].country;
                                    return (0, r.jsxs)("div", {
                                        onClick: () => {
                                            h(!1), d(e)
                                        },
                                        onMouseEnter: () => {
                                            g(t)
                                        },
                                        onMouseLeave: () => {
                                            g(-1)
                                        },
                                        style: {
                                            backgroundColor: n || a ? i : "transparent",
                                            color: n || a ? "" : s
                                        },
                                        className: "".concat(e === c && "bg-white/[0.08]", " w-full px-3 py-2.5 rounded-lg leading-6"),
                                        children: [(0, r.jsx)("p", {
                                            className: "font-semibold text-[13px]",
                                            children: x(v.Nm[e].language)
                                        }), o && (0, r.jsx)("p", {
                                            className: "text-[12px] leading-[10px] font-medium opacity-80",
                                            children: x(o)
                                        })]
                                    }, e)
                                }))
                            })
                        })
                    }), [c, n, b]), F = () => {
                        h(!1)
                    };
                    return (0, f.useEffect)((() => (window.addEventListener("socialClose", F), () => {
                        window.removeEventListener("socialClose", F)
                    })), []), (0, f.useEffect)((() => (window.addEventListener("scroll", F), () => {
                        window.removeEventListener("scroll", F)
                    })), []), (0, r.jsx)("div", {
                        onClick: () => h(!u),
                        className: t,
                        children: (0, r.jsx)(y.Z, {
                            position: "top",
                            popupAlign: {
                                top: [-2, 18]
                            },
                            onVisibleChange: e => {
                                h(e)
                            },
                            popupVisible: u,
                            classNames: "zoomInBottom",
                            trigger: "click",
                            popup: () => A,
                            getPopupContainer: () => m.current,
                            children: (0, r.jsxs)("div", {
                                ref: m,
                                className: "flex gap-1 items-center",
                                children: [(0, r.jsx)(E.Z, {
                                    className: "hidden md:block mr-1 w-4 h-4"
                                }), (0, r.jsx)(Q, {
                                    className: "md:hidden mr-1 w-6 h-6"
                                }), (0, r.jsx)("span", {
                                    className: "hidden xl:block text-[13px] leading-6 font-semibold",
                                    children: "".concat(x(v.Nm[c].language)).concat(C)
                                }), (0, r.jsx)(P, {})]
                            })
                        })
                    })
                },
                M = {
                    src: "https://cdn.wegic.ai/_next/static/media/bg.0435667d.png",
                    height: 160,
                    width: 6035,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAQAAABJCSfIAAAAEUlEQVR42mO4y3OXGwh5YDQAQRkHRTgSOSkAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 1
                };

            function X() {
                return X = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, X.apply(this, arguments)
            }
            var J = function(e) {
                    return D.createElement("svg", X({
                        xmlns: "http://www.w3.org/2000/svg",
                        xmlnsXlink: "http://www.w3.org/1999/xlink",
                        width: 16,
                        height: 16,
                        fill: "none",
                        viewBox: "0 0 16 16"
                    }, e), K || (K = D.createElement("path", {
                        fill: "url(#a)",
                        d: "M0 0h16v16H0z"
                    })), k || (k = D.createElement("defs", null, D.createElement("pattern", {
                        id: "a",
                        width: 1,
                        height: 1,
                        patternContentUnits: "objectBoundingBox"
                    }, D.createElement("use", {
                        xlinkHref: "#b",
                        transform: "scale(.00625)"
                    })), D.createElement("image", {
                        xlinkHref: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAoKADAAQAAAABAAAAoAAAAACn7BmJAABAAElEQVR4Aey9d6BlRZXoXefc3JEcJApIUEBABAEVdFQURUZUEMlZgjo67828+WbG4T1zVqIESQYQREUEM8GAShSUKCBN0w3dTdP55nPO+/1W7Tr33H4zQzcw7/3xdd179q641qpaq1bl2imtMWtKYE0JrCmB/7+WQO3FynirdUZ9/KHF+9Wby95RG35o91bzmc1Tq7FWLbX4q4/Xan3zUt/LHmjV1/lVfd23XFfb6JC/vli418B54SXQat3Rkx7/4Rubw4+/vTb82G6txgL5NyMgt+pjqWvg6dS71f313i1vSaMj19V2Onf2C8ea0osigK1H/+e7W0t/+ZHW6KP7pNRIqdkD5O6UuuqpVgNFo5larSZ+o/xa/KYuSjP2v6bean6htv15D70YGVkD4/mXQOuh/35Ua/D201ujf3l18C/Bv2YXLISHsK/VhHcN+Cr/6uKZ8kya8Y5v1+trf7W27RmPPX/MAf75J289fMpWraEnv9JafuuBIXTjEL5sPKVnRsgARHc1U60HigfRgnUys253qq3Tn9JU9OL4crDPeKY+da9P1nb81leePxVrUj7fEmg99PfbtwbvOLM1ct+ba/VeeNafWovg3bMI2tIx9ISQ4d0YryZ8nAYP14N/RE1dgyn1rPdUmvHmM7p2OPsCYz4f87w1YOuJy3dvPPmvV9aag1unwb6U5kKQv2FqyiDCNwVypvPrBcVCtB7eaW004owuBJCMziDCOj1oyKHUmvrai+o7f/b0Wu1l5H6N+b9RAq0nL3tD88mPX56aKzZNI72ptgDeDcGLpQjfEpi1FJ6tB+/k3wrsS6HK1mwKgjgDCdxyWkprwcte4ve/+kv1Xa//b7R2RFw9g0ivvmnN+e6uzVkf+1FtZMWGaT7pZy+AQIhejOCh3RKVJA3w66mlGu/WNPzGW6lWpzYtpjo9CtFDaMBXTE2tLZDSsZ+f0Lxv5tRWq3UkmVBU15j/whJoLfj5fq2Hj/1+GhubmZ5BZu6bn1rz4cnGIJV36JM0A97JS/5DA6pQRoi7GPYsGYJ/xJ9JxK3h4ehvP9p84EOmOp3fahnAr55pzfvFhuMPH39LfemS7dIcCJpNzennPRM40FWD8NSFm8oRAogab+GfxvDDhH0ZdgV3JnHXoTZttRYwEMj13vfxrh0v+FhEXPP4LymB1txrtmg++g+/Sc1lm6Y5dJfmLktpEULVBS82QOgQwBqiFF12BRCd0loBKQ141qLrJC9JFjx+Gj/5tzlCuO7SVNvohI927Xjul1eH8OhSrk6C5lOXf76+ZP526R6Ivmt5qi2Fwkrj1RDC2jr8GPsmtF70IczQFLQfGjsyZ/9hgHBkLmraHFrdu55NaTkBC7//z62/Xrzv6tCzJu6qlwAtTK0197Kz08i8TaMVuhfhG4V/tlD+1GF9vKfAO/iVBhAwNF+NRqqGsqitzRu+1aZW/jTJtb/Sov0W4ZtLUzf/+59szb1ut1WnKKXVaoJbs7+9b+Pek4+oPYN6WzqcBxMShNCFyoauEMZuCFMDkhcHVFG7WgTyX9ONvYX8KpAte33LycQTaNKt6vXG05d9qtW6ad9a7Q3WszXmxSyBhz93UGvxLe9Ii2HCHISPLlsIGrxCOLHTR58Gk/phXKMSSPErlPIWLejkRigQ3evDR3m8HCG2CR8YHGjNvuDj+Lyd3yqZ1dKAjdnXfCTNXl5L8xEY+3jOEoVmQ+AkWj+1oT/Vtz+1nf0H31VY1Cj7GLhrhhnvGTIwF79Fd+3deOyht+C7xryIJYCA1RsLf/p3aclIqv2Vyq4AyT8HGfJwOmXvqFc++kMLxoBjAOlUO8pbBTH4nHnXkndqSuGMIROzu1Jz1i1vbc35wd74rJJZZQ3YmvPj7Rq/O3r/2jMk6UbibUqpSPW1IUoCdduPmALBzh/1ElhDvmvE7UGZNSBwVLVHPIKjJtmvoCxibmkR79mow+5Gqq37q8Nx3cBvjXmxSmDW5a+sPfOn16Y5AFwEP+yrh8DBA4WPVisECfalPvjmtFmfPNSDOGPwbhwejvAegqeoPpvj1EQL4kxOty3DMm9pvTH3hqPwuZXfcxqwrJppLrz3zWnxgv60HKLsGzjQcJoF4qNm9OHuB9wUqkU3qq0XiWQiOqgbhfCGwkUPdhxNZ1q8FL5ogpknTE9LBxmYSZqFd+zbmvWttWtbHK5YrjEvQgk0n71r/9aiRV21efXUehKAm1DmFHX08ZSC0Hi8uxC4PvgnD3t8VwI4itCOwcMeul6ONhlUOkpuwc60WH7yU5mgIVvzbn1j6+l7ptY2eqXDl//UrLIAthbe9qq0BCSOYJlSac/xmYmoNQhmP1WqH51cBLBuIKYbaRtz+ETEeiV1dWoSYEIjGkeY1kJr0+DCjdPyBdti+4NBa8wLL4HW8lm71NRiGl9orpjXc27PjhzsS72IQxdtbR987EWR9DAqqVcCWEcAu5C2OhHlVUIY6zBLnnXjdjC6jD6kSmfR3C3Tol9tRaQ/8ftPzSoJYOumM7ob82/YPj0DrGGQqfnsN9gvsOlVZfdDbB9ES3wPAb0QbuaUwXHCrFkORJgLjBLopxTIT42a17IwhEmFSwhta/lwvfHUr7fHtUYAKYQXalr3vbe3+ciD26cxmGGfbW3Ku+qb2w9vj3775BM8HIAZ8rFaigu+xdQawidPxxFGR5FMQsdAkqhpjCbZweUSwucP9zTm37sDvi+OAKZ0c3dr8dy1a6MIURMEPWQAOmtMNIeA9SDHar06vy5+PUhl98a4t4AGRlvpYWSOGtKFJrQ5Zp0xtB8hiB9PnNHxxUK02lAjtQZnrVLliMRrHv95Ccxi4LhicXcahl9qLIWQ0kVfVenggVqwhYDJvy4FEXvPBoRvg/8SmPIYvGGu1pbLOK6AdCOIaMFYbKBlDk6Ow9HBRqovvMO5kec0q8bkoSdbaazZCOIRvMiAI1fojIGHTa0aTkG0M9rDhFH3myCuIl5V1/0APzJln6JOWqxZ7WuHdEZSTtG0VOcWhn3ENebFK4Fx1JNaTA3mDIS8o6xbjIJrtmLyxOZWrWczqpDV9yb+rgTSfardiADehvYjXB42Kj7iTAPEH0NzhCYkKvxrjYzb0D+nMflzm3mbQt1fu9IISESMK41CPN2AUOEiV2DMiM1sS7AMkVrmkuZYt81sGBJLGpXHNM0h/O0ezjcQ+1r8SJJe4jBtjXnRSmCcJuZZ+YSwOLRbj7KHLTV4GLyTJwSHUQFobyFRwWD5idoM3mI1LvyPgYd8t1smPxVudE0MUNJUBOW5DdSsgjlmv9HatJfOTv1QtT5InHax+VWLicbaI8WOx4N4VHbrDn734s27OZdw4sRaNcQaXczKsnlTTul2tJxnUgjr9VZrxmv/imONeTFK4G03jNb6N5uVy5YyRq6ULfkXsyzywl8nf9QurXvg3d287+T9UKZEIZRHskreKwMqHnmHUKeZhPXSj19v39m4ntOskgDWamc00/TNH4xaYc1wuI2MRffOUfEg4u9E5AhEj1IFxugQDKOuh7+H3434LeZdwo2D3Zqi5qNbkVaYG4yabwAEU2Ys7V5/t4fDb83jBZeAu1RaM7e9LwZ5lrECo+aie96y/Ecof5fkRmBK/OQRPB25n9+18PF63E+RBtU3ahg/47kCIgzYG3yUpyqh7oHBro12fRDXc5pVEsCAMmPbm1tq1Zm6INi5H7fpmBG6h1CFakbwxpBOp1zih5SOMxU0irv9M44CSxKT+dY4Iz8dcnrp1E57+Z1px4Pm5IA1zxejBFozd725ZR98OvN3bqmS85R/zcWA4AOC4zyffCu8GodX40vxQ8rG9Ye3vpvwugUPmY5puUPGrVvO5dIXbE0Fzlrb3JMeqD++KnTbAK6S6dpw3xsbMzab2xqe9ZLaMjLyTE5mP6LuJHQfxFqzVGYO080s3jFI0T0C4UNkYJCfNWcRxGN1NB/bfIYpEZtiwNR2fesPqLVEWmNerBLo2mavW5r3bP1YGnpoqzQCb2CJGjH68TGRLCa0gRuFxyn6PiI0ZChKR63mBmMFVB4O8xsaj8FxKKJ5RJPXG/LD1DZ747W1dxwiZ5/TWA9WydR2ft2i2qb7XxZazz4fY4QQHpRcy2bYZZhlSM8Kaoy/QQJW8BviN4x7hIxJ/Arococ0zhbR2806w/fUINP9L3k6bfKaK1eJqDWRVrkEXJWob37ghWosZcV5OwcNrmS0luPjmoVabBCmDMMceeZvBSOW4Cf25bqJuAxBRevJ95azbAhycs3YblbvBs/W13v1t/BZJbPKAii0+kvfclbq3Xhey7MBU0mqjNMMt6CrtQC7o6yl1JLlZGA5lC0mYAkCqNuMLWN+D8Kb5CEIn0+GHzedhQEcd1LvcMIXai97vdDWmBe7BF5+6Hm1ga0erlnRHQ3PpvwZKjh57J6/EMToWiFIK1AWS+GfPFwqD+HnClqxxWg++NaiBaspfLA7BqQOklkjrr304DNrr3n3k6tK+moJYG33dz+Vtj/uv8cQXDXdIrnaENmSoNYCMsQ775pFSBfxc5tOnDFAWiGYHfih6UN4bQbsAHcDp0am193nt/Udjj1nVYlfE2/1SqC29e5Lmi8/5bTWOG2qg70G5U6xu83KLl0I0zL4oUZcisdCeOcupSVE8sfG1dazxKX7FYMXQKhFa+P0/YbYZbPujnfWNzj0i6tDFdhW34yds/9Xao/89MO1afYRMI6ggBQTmuvgdkDhTgkzZ8YUc/t3KMJowtWao3hSa5IZbpDJ3o2erO99xhtrb/nAX/BdY/4LS6Bx7lv/pTX7px+vOQfmJgSXR2l+3XDa5p345Z0rX2wobs9YoBhj1OuUjVNu/fBxxQgT2uvPb+z5wTf2vfNj95l0VQ0QVt+wt6y7eeHR57cevvy4Wj9t/2J+TkY7P8goKwhXEJGrGGCIwjD7fAzZa0w+t6aRxvntpyA+bTi7a7M9D6594Id3GHWN+a8vgcZn9/hiWnD7R9NGCJALBbNooRibxFTYerxtqRwha5ydsH+on5PNHjJTMN0NMwUmj6w/r+uI7xxa2/mNt0T81XgA5fmbxhdf+2+1ZX/+59aQW2xRcdVW7bQka8SYKww1DcGesGIdsqbG49/hes1jm727/SHN3P7o2vHffOj5U7Im5fMpgcbZb//H+pLf/nOre/H01gr455Yql0JVIvbCnWKxn68Aulxqy+YmhoX4MSEd58dmvuzOsfX2OKbvhG/8+fnQAOTnZ1pnnNFdX/amjy9b/8R3jg/s9FDMBaqS+9Bs7oQZ5jcEePsZLt8N8RupsyJHf8FcLZ+BQjz0rGVT3/cOhU94z4+SNalWtwRa55/f0zr/pJ76Bkd/Ydm04w8YH3nVI7HMqnaTV4P87CJpH+O3AnuLN5uNWy6dMP3RSlOGhtZ+zyeWTzt6f4UP/hFp9Q0YV88s/8E3d2r+5YF/qw0PbdMcbfQ2hsbGaj3d6/c8+7uN+/r+nLqmMUpyMVvI7huzxtDk1kZ5O9JljXp0cN000rdvqzl1s/vqY8u6atNnjHR1N0fqPV3z0zY7fHrKwcf/bvWoWhN7VUqgdeutA4O33/BPrGIc0Bwe74YXMxqjTXp19Q26F/5m/f7+P8WcLnOwCBj8crnOpTf78i69yk9WQ8aWrA//XjfcmL75Q7WxwWbXlIGRWl/vWGvtGT+cvs42X64dsmpzgNK8Wlqn9Ze/9I3dcMHXe5bc8Wr2XkMQnYI64/DR4dSk+a07McjB9FDN1iY7qs7v2QyTJd+eDe4bWI6i/GWtNlbfkWUb0jCY6WbUMr5FGvtra7vWPffsVnvlc++mFeoas+olMDjv4WP6Fz3+r/XaU/DsSTQcnXJWNVqueEyjOxRr+TAJVimEMWDkFfxzukWDQPZOWc5y7439tZH6K4N/ozTfjbWYXtvkdUPb7TSbWN+JuKvwWC0BHHr07lf2PX7Tqzn9hGajekxlD5XnQJiKqbvPrGg+lXFsPJUCc0CObJ552frW3Bnjz06utYr/eA/+xeH8lsuefGATfB7mt8a8iCXQmPv4q+pL6KrZp5vCKJHWVN7V5GHFx+yHv8pjkiGOioTTcsE/74rhP3goL9kDUF98b6r98WcH4/tfI4DLly7YY3zh/DR9A4i3L6DQFWFjQJG6oEjBCz/IIDhLly8cHvWLTOCuMhOC6AZVBZGJ6OUjc9P4M886t77GvMglMLRodlfvsiWcNVqX8odJ7g+UX/JOnoVA6q4QdyoRvEPgHP0qeG3+acfPzcrsFVz8yN3b3HHSST27X3CBDfdzmtXSgIPLFm8wzKh76gqk3Z0vYUDO/yRh063AhZHyDtPpLHbfZGiEye1lI7V61+AaAewosRfNOjg8OKWLOdve5SvoCrH0UVhU3mKy6Y0mKRzZXsILvwxa2Y5QDrK8t2R8cGDd1sOK8IsvgI3xZnOYrfVDdESnIDCeumxnQqJ0rKy6Iz8dmSqCGRnwQRj9Cnfsr0AAR1j0Ztxi/VpjXuQSoGibQxT0KK2NMyrBv5Ckij/Rb7foC798ayb4FE7j6RU8zG97U4MMMFWOq2NWSwMiXA6P2k2/mjsqjBiDVgILUWGpMqBQtv0r2SqCSEB0IQjnFsEJxbk6uVgTd5VKQLUkRxpUeLkg/4IxehYeBZ8qZhU/o00wEEaZMPO2CSxHzG6QjtXZkJBIsEqP1RNAyQCvgsJYN0hg73JFCgGZporWym1eiJPD8KvyJnV6R3eCt966tayS7hbAGrNaJdDN3TAKYRQzrMhilHkS3MTayZ+wd/pVdsAEXtPL/TKmbOuUCF21x+oJYK3LK0Ri4KPKDTJQgb5tjScRPwl/JjjCKyp9FeEzI2VQLIKehr3aNeZFL4EaR8aqLpJCaJlHL8rS1sPfyiVf+YewaceEF48qqM074bXaTWKO+1zPkJvnitQZnqW96qRBrPSuTHM7vhSuHKFyd3qbubYwRiaicrbBrLG8OCXQU2vW3Dvg5qM45gsT4vaUwgzfHaYoGw/UOUlhP90lf5ta3eWnMvLXtGnu4ZD40f/WAeU/t66WBmSPcqOfc6EDHL10L0Fu+HmXDBRcuiEoTKe98ooX4VEIwOnlQMsYSs97pFeMcQHJzPXYBbnGvNgl0DvWs3zq8BhnvjgRXGnCNo6VhE/+KZxdntfWyE9/JZ72yiB2IYDjSOTy1OzbcoMN9Fol8+8K4Oc+97mN9tx1142fXb68HoeNANUaGBj/41/vH53LpYQzFs7jfHJ32mOrenrZS6EyiOmgbuXMSUqb4I4MkXQBGyB//edGbKBZOjScejfdeeGm0zfd8rvf/e7MrqaTVZVxp4adw/LWG7tnoWZyVvktb0CceU82blZUZ2uew87c+vU3NWqeGBDFf2pKhNJZregwzVte29WaufHKqcWt6aSl0619gr7fQMdT7LkraAz9z40xK2Kwmoc37NHV2nibzlRTG2M3/+HZ1i9/zhTusxOqr82XDv7JLMhZzI7n3/5pnN12dLPkBGJl10nNWFrakiO14WI2rPa8bLuFjz722BY33PD95loDY7Xe3p7Wjq9otvp6p42lgd89xQE3N3m1TVUw2T1r1qy1P/5vH/vU72/9zXuazcZMMQWyHNwaRzk5jbSMbfXrMxd95XlT0iv37GFtulDUMSAhE/hi7CNme+4tVhlQ9MnY//yfg+nMi0fTACtydTLdXa83UbCNbs+UVCbDKa78Ln6L2WF97Ht60ic+1p9ZQFsuzcWEveQy/HVgsQSriP1csHTlFaPpY59hUyU0dDEB2wGiApVzUUCFZwVK+zL2OO76iq500ZlT0kz21bVcglwJyiSfDkchZQrHHG77w3g65e+H0pKlCKDbLQshxu80+uOXvTMwn4NMz27AjWXfPHcgbbMTBckqWxYWhg59DVRDnZbYDo9pBVAhyIDwhYe2bmjJr35hKH3mLJQCLVSh0VSRwrLzPwMPOrTCv7Herq6Rftp6FsZqJxzc1Tr5WJadW13cU7/WA10zT/tEbZ0jfiR+zSQN+LnPffbT37z8spPXW3stGIHISxRI8uJ0FpBxlNIAsvGp/9afdn5ZPS1zHxmZiLVDopukoglbZCe7g95MtPGnsj/w0itH07mXjKRpqPnoHJOpVqNZHx5r1FvDw8CayGxFSmReu0CXw/SdX15PRxwyNS16ZkWcCjVIAybkK4jPDhJFmRmAkUbd09gU+9tbG+nfPjMI01mnrvbYGi3w8K6SmKwNqxAiHEhNM8jPSUcOsLAwmBbMzSmE32lKuQRZBnQgGGDt5/HHWukf/nVFemxWM01jpdPTj0FHRavRJ0BmVwEhOPtm7rY/8fSBtAnX7S56vKr4VcLc9Oqo0kJQuHxURhqnUhG+f91I+vzZw/kiC8NAnKNVFLR5XlXWKrPjjUbP+NhIzwJ2Tm+yYS29fIfetHhhLQ1xeL2ent6zt+9/XDXy9K179m20958EO0kAf3TNNQeut+463M4wyTsjBrs4htnZcuqRvemAN3SnRTSfquCQ1ahJRWSkFgEmQahuENk/NXNNdPh0NjLeelsjfe5rw3Gjh+jK0N6cdnnNR5VdidQvu31ramzoaKX11q2lf/7wQNr0Jd1pKdvIS0UxesS0xDqSRlGFFGS6+6nZC9hc+flzRtKzS+ppOjeE5oSBJFBGmgIs4GWARR+aL87Rp9NP6E+v3bM3Laf5i+gVQzoLr3jpZznYqhm3i/zbiJz19aF074O1tNZMangAmaCj7SatlwBZmEaRJI1eg5w2POo9vem9Bw2EJrRZNJaskTPyykopXk2kjQcBunhNYffzffc30ifPHI5Pg0yJCmnbSyqjtDOBE8AVKRkY6buga4yl1elUoH/9YG/aFQUhb+Rvg7tnhpYuHBibd+VhIAwBLLRID0Bo/ZSmlYzkaVjBSXvu0pVOOrw3DbNZsUGpSVCc2gOBzDCTFq6ENS2kyo9YEdbb20rPcHjps+cOp2cYagzYySVulENg0TbhCq+2O4eJw77fCYf1pj1e1R3Nn/HEIWL/gj1ROvjpk7kQYfrIdLN6wWUj6c57G2icKt8d6I1X6YhMgR6TaGH1hp3Cb9mvOx1yUE8apHI2IS7KpIIjCeEuSfEPsipKpHMK2u8HN4yma38ylqb+O3SYVLTWHcGGxZeAKiMdO7+8K516XF/QMKb0BXJzz4/8F9qaMCUHsTSCJcJ59rDp1DzIm1lzm2kq2/VtCeMXiEWNXxAi5VHKASuAgEcZoCufDj+oO715n66okE0HmJGeFNw5s2zJY+65DjNZ2oBc4Snh8dZPgVuXvs1HT+xNa8/UnTNmiYAzMmdmNEEY5/3qzWcppIUI4XD4WWPUdl/7xmi69c7xNJV+n4SXAqggtl9VQMCc8ITpNL1/89oemt6eNOwdNQKoCLegzURkuMpdCF8FpcCxcH9601j6zg/pf7KbKJJnQoiCBY+2X0VIuMOe8Q3BrJduXk8fPKkv+ms2gfYhJSDiaoWG8gsSDOAnfaIbgI77Hm5EV0S0cR+kEauyzID0yKYIs2kjo7xGKYMZdCX+/pT+tOH6dcrEsPwLPBWubM9TaNpDUUCzMKXGvt4l3xlLP72lmaZwCemzixal+fPmcShuGfSSQDgVLF5hwttHZTxMt/du9XTC+7pjya9BRTBYDFkD0y9teCY0m8kCCJbIWAmt3s7/uPvmlCN60h5oQJsZickAke4qkYLXDAU/nPq4X27Gpqdzo8c/sHNrYygYRL13pV/cMp4uu3o02UmtdxBeSiwoK+T5LvbKYl9ic86SfPSUXuCh7tGEUQjtqLlWSnrQ1QEwyEQaprDY/NgTjXTmRSNc0sDsrJstKzw5ThupYDDCLHDVAPS3KFj7ix9C+LZ+aRenTrN/Rpq1iimFV8pHtx6mV077WJA1P189fyTNYXahv2oNIp4EGReHP01AbZdZxqHG8aaT4w/vS6/fqxveRA5yguoZ6Ys3EqSa0Rn8I1BBtEx+c9t4Ov8bTtOw6ZQ9nkceeVj6wpc/n/Z7w+s5ocmoSFPBya8C1DzZLWIAxEabj57Yk5UUbsstElkISptOaC4GfdRpiNXO4IS/Ur3/vt3p0ANpw6ltLlTYfOVaJPJMV8BujqUe7pebstllXOG6RwAZmP7+VJ/17jR7ztPpSxc00Z61NI0pk0zcRAFnKJVb4FQH6c56mclQOtiOlE87vj9t97KutMzjg0SL/ERZSIGM4R3unL6dE/zUwArP1y4ZpbOP5vBSpAADU0g2USMDgMjbyScsLT4qVEtHHtKd9n8DTa9MNzF4s1gEWVnwwhv/jIQYCkAgjFuMv3n1WPr17xvRL57U/pCuwBLaBBkGmN7b/VppKbzZd+/udPh7exMnI0OojBtCVuGMsgh4OX8KnkYFIA4rwjP05798wUhawtRLk+tUPvnpj6eTTv/7iHfSaX9H035M+s5V301rrRWTI+GfHwDGqKQU5JOP7E677liPo+DSGX8VPskpPM9pO8s7fKSyiq0bu+355pvU0oeP74kCG/XgCtHYPxuZ1K56NlP5N8hZj9dzScLOaekzc9LShXOAsQkXJ7wrffXCZ9OfH7Jv0UlIB75CQxQtpLeZKincsUhhv+uAnnTQW3vijLR4zVAwTntFS3ALu9IU0G0DVTn8bPKuuWE8Xf9z+lvOG7bRV0UjjAnPoMiH4AwBTXQBdtmJvvAxA7EVzgoZuJVeIxhbfJGKt9bixi6mqdyj8vu7xtNF3xqNSlF3Q2ibFuJrhGW+skuPbAscmTcv2bCePkLTO51Npt4nlOPnNPbBTeNbfoWdZ25O9cNAl9cCnk9f+Pa7mwwAR9JmW2yWDjv8MC6zWJiWLJjN/fKD6f1HH8VtKz3R1crlLTjpE4jjgxYD0650yNupkMhMEfIoFyJF6ZoRfxO1fPIouAArGXYeuJtTUqcf3ZO224rRDIOQ9iAFxCVe0BGZlZ56WkjEuaOz6dgzr0asXu4Z+dG1z6Qf/JgONxfj6DeRNgPKboSpojHnTIbjw/8K+ls7bk8nG+1nxsfJYbsJrzSKL+EIozxiTguPFkIyHW13733N0H5i6pbpmiqRrrBOAIjgKhYp2PVBszJzRj39HV2ADbiqbrmjb+XbtAVApOKB50qgAr63Gatxvvq1sZhJcFbAem9Wxa8xXaQtDt8Vofor9L5POa437cTgw9ZAOgoR0mJ4FjztBXIF10B+05k+uv7n4+lb1zBPTDPcYNPwGNvtHnlsdpoxYyb20TSF/Z+z57D4AIHSKB3xqp6DdCO22bIeSkptusy7fyAgFIRoi1IjkWKPs03M5Ca4RBQHUZXkww7sTgf8DX0Ljn+I1lpjMxiE+IDrQU5w3xHTVJbYbk+PP3o9yzivRmuyPLPkj+nyb/6QtFPi0JzoTZrRZRhZeCbsOaO67WQzN4XG+PAH+plycVgPDUVjmJBIwY6wB0nhZ9qSfzvYjhTPvnA4zX/GeTYCi+mwZq/i4btdVtArc1rpA8f2pb326A14FnJUhIiaM5Zpt1TwjExW8KDPrks3fc5LvjWc/sgqwzSnfjATacIVfvlRmD3Z39WOg97Wnd51YG/0P6MUQCMcPglC5Ey37qCjA6JWQ+33Pf5kM51J0zvMuMBBYRfdpwXz56WLv35JOvT9hwOvlp548ul02SWXBIQ66rIMWvRwtI1iTB+ihdxis660lDuCHIhFtkEiS5QZ31YKXtITytf0kwQwaDcCFpm10/b1dPJRfNESP9t4a1iM8vARkIUfGirSKPEi605Tpo2kjaZ/Nc179uVcB9OTLr/8rjRr1jIKe4B0pCSehTIx5DGtECUwAsOuy4w4qjv28J70BvqhVoqo6caQHpFicmqhYnhkd1ijiemjg38xzd2vf8eUi1q4lIgYS/yARUo99Mda4Gqzmdnvtd3piPf1xuDFsLhEPmKbrCqXIAEYAQY/Iub+lhPftfQLRt9Xfs+BmGVQEvMuhE/y01+jp4apEoRv220YfZ/cjzDXYyCT+UIw0TIdUpfT5DqQcWXQzLUiJM49nv31kfTgow36woaY2LnAqenqK69I99xzT9pwww3TI488kuY+8QQtyLQsfFFgGZKT8Mcc2sNUVE9ajibMWk8+ABzEhYrMplwWTOvkpRgwThLAUteimaGgPoJUb8yMuvN/nh0IYQNvAJP50uDDdwiDYWSOQ+obbjCeNt3kj+nbV4+ku++x7zWFqApUjl8KRQozmEwckCYMsG3i9t6zOx1/FEttjFjHKTUF0IxFWuzZkZOZh8h8dkaQUy63ssR1yRUjMdUQAyix8p/jZxoyaSU1bwnjYRaHGOVu+hLK5NSBNI3+lgOPqAgRJ8fL0CrEevGL4gk8rZjznIXGcdTrNJZ0RT4IF0yYYok0+pifYsg//bx+eiF/d1p/2pLR91JWb9oRQCbLjd9ZCtIQhrd9M/loX/gqKsG1N9gXtkJWZQFjaiwEyK+HH7w/3f+nP9GK9ZJnhK8AkXnElzev3rUrnXxML/PUtI4AD1ziEVFlslDi1oswiPj3BdAYphunH3DUu7vTXrszvVBdx5ALW6YIIdfoqHU2x3pk77ZwrLVWT7rtzlq6/ArisvXW9VUJiIxKSBgS8R/1pO1XheAvk9Zbp0Z/qz+ttXbu58TpO+PmpKFdOmFCDiZLpdGc6F6wEKZ/bYT5rFZoIMuvAhFkF7spNYLQrxiv27bZOem4gfTyV7DqwkgxmhkiGNeyCcbi6kwXYRUQF3cs9fPQOA89gsahgq9sVk5reGcsaXCi+Pgj+9Kb3tAXrRSqVeJkCHGNjV1AFEqkDXsWSqFZVgr+Aw+Pp3Mvtjlh7RvaBGHC/Mr9azXh/2FIrwB7JGgtPmD4dx/oS+uuy5KsV7UJXIOiCdmgUAKuafjTLny2xbabYDnVYej3od7f8tp6OvxdTCTS9IUg29+qqrvIyzpxRmihi5gfhaDdOb5laM1zmWdbyKqHHVNNIOeRXW2fHBAxJh7OOzbRdicd259etRvqPSqCxOdflKQZrtxBnoKA25/hajp/FzLCu/seJr7t90mEwfwqa5ueKKS2K6JFRLXd2xl5/+076fchABmnEDC8ojR1gks6gg+4LasQEF4D4L4ObfOjn9Cpp+8VCatnxosDYP4VM2HLPs4CvGrX7nTiMf0oibz2G8hyrcv5AafaKMAIAHqMExoKaw+8MA9fZrVj9hzmHhkQrWyCfqDZBclGS9sR3TH7wlaEPV/N8qO8sQJQ2JE2CFcWMBkYwodLweRFK/jvC6C1a/tt8pSLtcRhfQDxISD+o1kiU5MyWTIKEV0Iq53SS74xkm67Iy9xBT2CqP7aNpu3tl/bFwsTtBT2W9/cm953yADzW2Sm0ED8dqZKBolfKoMERp6JZgf/p78cS1d9dwSmM/HdxiVFjtfzW3v+ZX5p989w6dhh2+70wVOm8BUKZ/GzhEUK8tvGS1xTWwH9CcMwyR6giXuA6adzz0fjMEDoKaPvKh5RsIkvU5Gx52eEAMeNCbYGf/+hgbTu+l0xl5o3FxDDDFe/4JcA27ANgy7KxcFjH+XwDTaB3MSCgMuPoVACuzSbKtMeb2CWv4mwPA31JuY/j2Qp1BWywGXcSmKDhgwm8h+8w9NlWcNUCsV0WPn2MCr1pMO602b0daKzL+0dgHTkzJq8wx6MADjQp1DTf8Xukm9/xyUuM13FjYwVtB3voLZkPPsPo3G22KIrmO4n58rcY0llkkgGbVaI+OkjreCTDj/68/gTzXQ2Gx5cLfETJv+REVaVzUlRxOuGhQ+dNpA2Y4RnBa0wZ0k1kabC61mZ7EYEI995hCiTzj53KM15qhn9t5Lk33tXEAJSsdsa2Pc7jn7w7q9iDpTyyY0lMQrhQQt4K3e7XHDnuJk3t90xhnIYDk0I27Kp3gpbmEql68o/Q3J1ddCx+SbMSJwywLQN20WhKwuxeIgdGc8Vz9RBj/4gywOlkquMapIAHsvM/l67dcfkc0gtcQRqEgFFUnFUgqg7hxGHHPfTtMx5qpW+cvZQMEtNmBPxXkVj0+LI8nT6FltvXY3wAh8Acm7iZT4Dt5mLoJxZozjN4aj9nK8NpUcY4blk9x8ZQzpDI4/4mX8L+32sMOzHCM8lM3GWX4ZXFXDQpR1I/HyZ3srnSPeKq0bSzb9yo0HGVHB04rWro79+5ScO7a59v2HfnnTooX3RLSqwo7IRnuER08j5wasTChUSOhayReor7O9zF5MVNNLlxCbEVI6OpEV4DQ3ekKfTPzCQtt+uq+qOFGEzdWWflJ6EQVeGLgZGBG2sgJswB7+ti4vUWWqLYFDz1tpGQWzdxb+k1M+mV/+zYfq998H06OeUGKv2VoiHqN3vfVdfescBfdH8RTlG8sJsHGZIpFXOqvyFW7vdh2u+P5p+9GP6W9Uu6aCbsEjWTomlMsU/nDhkujttTmDg4f7Nprc6gE96wtYmDN1Q/IyhHSn1bRP3+9vG0kUXD8XuG28uKeb/oKeCUejwjVdUgs03Y7WDpncqZWrfKwTdUCIF7kIUfpHehGHL0KwI/i5gu9dtdzrqzWmNFSZHwxoJK8/JTqOoeQ+mH3zQO/IcaLswCbO7IRniLeB8KxNhwmHZ0A3o/g/6gCFYVYJcm0vaLFx2JCOOSIjXho1DRl9PB/vaH00wvUK9ai+IH+Rqjp13Zlh/4kBsfrDGKZRiKtuGqnKPZlf/Kl+BwyZQbffn+8Yp7OEo9KgYFQVCijIKiJn+kgejFLu7S9ahv/WhDw6kddhdrPYLQ+LQVDizj/gzDaXwDVD7qmEcgJ11znBazBXLvXT+KygZFs9OesKzilDiZY3TSqecNJC2Ze3becic//KGDiNHgniEY8IvBzn3eOPN7Pz57sTco7FLWQTuCkyBEjBxIFYR4kDs5axEncxKlGXgdFiwpiSuEuT0FRSSFlqMq28Pyu9pjhsUs1LPqIplzOhQZsEzZTgZXubipoarDSs8U5hBt6mzk21/pYx6C5LnfIPWEfc0JkM/TH9rQ3bSOqzHu20Cb4UvyKsCY3QlgeQwRngU1FfPGUpPP823dYAnjUY1jb9OU/w7/dxd4vdYTjimL+1Od0SmR7ySWSIHLCJaSfOoLpeKcLSp6dQ4F182nO5kvdfd35GoIPRdmUJTvDv8ja8Wfh8bTA9kfVW7JpMBlpIw+8ZzwjPTI+W2RLNms9pBmYzQFy3dkU5UOfF//LQP7crRR07vT5uwEhXLfuCXhOgu8g4+6BeSZrlXEQwzHi3ITJZCf/W7Zrry5tzG4h0DL99hyijFFFHThV46J1gnFbMICHf/mn2lr9DJfuxxrtV4Pk0vcEYpnGOOYFfx3hQ2S21BtS/wmKmay0vmRMM7aJU+/Qwn2I+0X/7N4XTLryumwwD/ND7LLzw6HwE3x5PRb34Do+/39rPjxU2cVcTAg903frECg70IQpR3FccyuAmNc8V3RqIPmCFXcDocRtd00lWC1Tg7ssb7AbSfMezsR77FqSKocLU1MjRJa6bDcM+2OHhppXPOG0oPsufwuXjTSYd0aYQ3wt2ORxzWl/Z9HRsNrJB4Bp7AxyMIy3HzFW+VV5VB47rn8ln6nv/rrDHmUf/DJjin8GmiYhS8QBN+PNoRcmf2SlY7fv4LO9mmMHb5m+wqvhPvjMEDPXvv1ZWOZIlrRKZ7+DRyKDiKJXbwunsXK9op8EfSTItR7R/d+vuxdCkC6M5e+0adeILkyicnzXnqhKXAbcZeww+e2o8Wh3lo5aDDzBtRIFV5h09Fpv4hOLwt6NmzG6GFXaSP7/VIS0WP6QIURPunCfBhy34K2wBdmg8yAb/JxmwwRRiF73eV80xHFoKCt+D2HeGC5edO62vZcHsdu62jLxw0RFBgrqKBf6Kkii2P6F1+bDLXV0c5wBu6JtH0mm+JliHao6ukH2WKl1d/iCBevD2y4KaWz58/lh54pBmakNRhJjXBZsAlFBNYpAKIvo3OWAwGaAwDJY/dJRTS3X9spK8z52dfK9ZFjYupIGTHSs8qCrDzlqINWe770MkscaHmS5MngPbSDnYZKEEBV3cFUx8nUxfMp5lBC3uwSDi5AHOkSDqJhs7UBBDBroP0n3w8p8lemmf2g+sWsFz1zV+7PASKqco6orqi4Pbz8y8aTg+hcab5MR/+SjzT6tYn4ER6XPr7qt7Dw810IhPwr9+HCXi+RB7MrtLYIoi6gooN+4RHG5YDjfvoC5/HwMM0XVylF81ipIhoOW3lDpoquy9BxkrUek659KeZKBcVhZgVsiBYIdQaqtc3AfyiuKJgsnsm03uXfXc8/eBnjTQzVoBQzZWZJIDCLQUTOQSY23miVlG4IneI7Iinj9q1hKWtr9DJXrCADZVeeiiAytj0NRw+mnkPYJTAQJIzKNNlxweO60+vZH+dtc1oUcSkizxQElG+BCn7ukpBKqAWrAdhLrx0KFY7go4MQVCR1lQTpuKWLw1v49nkve+9fenAt9nfgul6FgBVQRs9/HyVMN+6geOy3zU/HEnXXj8SUy4FheG5K1BFLgEFRo4QoF1334u17+OO6GNXctY4wRMQZNHtwG06TRuswlGLrogj1q+eN5ye5GxHLPsRp6DNiXzqkwV6wi/blCkHficf05N2Y2CoYojjt1XE4I0Ch8mtEuG69fLlGxhu+P3dXY30la+PMjBjLZtWpSuLsEkn9wFJGJU9gOvAUn4Cs5RdHlMOutGSl357JP3+Tlc7yEgkygTYOV+6ZDHImL4HzmLOFoTQ4C+jNEa3P3HAm3rSu97OLheY3kDLmokWgpszg73yM4EF0KzcvgU1he/U/ezG0XT199jP5lbBoFus2fgWV3jEm4yUwCpO9Ld2qHb+oG7GmeqwQ1VqdNRw3NH3gb5YaM8cihpv3AG2nT3wIBoH7adRG07CM9HtyYIQRFVxQGdeHCSsz3GdD7PNf8a0FicQcwXOZUIXxMrPzwxpDz5KR2UvZdZLc/ft79AX/i2rHU65dBqSSZcvnyVUckrFdhpp8eIV6YA3jqTD39OXRgbhX4ORiJVAkuJHAgWuCF31LrT6Huhvpb8+0Ur/8vnR0Kb9dGsC74QCnCyACkcmJL8lUYbqmQEHzfRzWulXvx1L3+JsRx8FHzXUyMTWvoR5h7cecADzcD9h69GN6YMf+iBfeloGsZwYAZyMHOKzTlttUUunHNsbneVRTry7Wh+FqIyQgVzY2EsB++an22apH9yzOJd8zvmM8EjvaoeFKM1xYmxSZnI+cglgJ735UstMQXOddkJf2mgDdrnYzIjb8EJD0IMz8BqWw5t08PWzs2+6cy5gtWNuI1ZPgpmACnxBR8bXLuAJ1kckTxgq+Mdz4nBnDrivcIOp6cXJT1rK1cbijMrAOxqZik7tHqO8ndWOy741QnnkvnBmITCq8ogywt5JYy6vXBGWcAhp7722TZ/4/FVp3e2uTzM2+Dh8o1Q5buH1KXH4DJylfKygAboqMyuolcCZjc+cO5ZmseZsH9QkEbFjE9akJjgyTJy8pgdCEwjUHFDISr5TLi4pnXnhKGqZzr/9LSJGTeIxyPaZbbd9WTrvwgsIm8YorJHO+NRn0xOzZ6drv39tWpsjdRa082IyfQs6/W7rEZV4hBN0hptH8eAdcapHN00vm3XTOReOpIcfbeUpl5ImYJhQA2yskbfiVfyBZSEdc1hPev1raGbcyauwGd4RV2v4RbocFgIqXH59rLx848qRdOOvxicm4E0g0niXhCu/J6Cqhfd/Y3d6zztZdWE+tOkSl5qiijIRs4IB3uBPFUW727QWsNn2y+dxzpkRpy1TlCxhRUlEWUyAnbCZF/5G+ODgjOl96UtfPS9tuOnuHKFcnupTT+LrBxz8f+YTqHYuk1fgSBnXRSr8OAJPCKBwLBMWJb41nm7+g3sNRRMIsEhLkbSV9gNGKA8BZtJzz8WCsNbHth2QXMDJKY8Sln6fCIMg3qPs09l2h1fA2PE0f8GsALbeuuumXXbbJV1z9XfpF7KliFbqaJb93vx6me75YokSOzUaQrULL0xYgqB2gdvEq/2upNm9gbMdMcIjXclj1LSoOQEU4BaPQAvU7G+/Zp9XM/p+b3caYcTasOnV+AJHvMJjgp5I2QbFDQ8w+Xbm+i79tmc7XBUBlwQYMcBVFvNVvAKmFGUMrjFvuXmNgz+9dG04tFWdsIvvt1Vxc2IhYMRhZjE5Z3nKxdbFAeGd98AbOvuRXaKJJXhaJQ+yeJhWQku5qRGHOdp28IFbp+kz109Pzn6cUS9Nb20alWL71DPWxyKaXRMABdxcWyO/QY+aMF88cDMbfy++ygpJ1Iqh0hC426+VBTByk7VQLsNMYotJRGEI7Ee/GE8//Fmu6eYn1DjvYvpYAnjowQfTw488xryTy1h8F4SZzNtuux2tlxfSd+PU1DGHdqMJ6W+hgdoa10yZwShtqcSmIEC1uDTaPbN6/wPN9PVv0sekctgERsZ4lELNsSPFRKDp+alY3CCwPl9vOu3YHvpJrRh4uFtEE7DsW1VCqDvnMy+7iUM6nHBfxGqH284WudcwNA4w2hVceEQM5mTKhJ9zgz/BLq15Uu8D7DzfanNGmkzAhxoOUrLQBrMhp6JMC16VFqpsTkPdyPznd3/o2Q7Dq5IQnAAwE7yq4GbfNlg/hrnrjn3psHcuSg/cf3eaMvNlVIjhNDjK1buL/pA2mzYKP/sCdmTLQtAVJCt8DsRY6ZjXSl+6cIy5SyoofdAID1z5Ab+DKl2TmmDLKYJ4m4F4ygc4ZqYefrSZzvvGeMzI2IQW0y5akvTRDvzloQfTZz/1yfTOgw5idaI7/f7WW9MvfvZz7FMhiMXsY7vTumhyR2pRNryiXyFIvaKGB/rwiP5ORGQpB9W+gu6kXQCOKlDTS/mR0AwEWdjDZGEOecA/fHmohf2dyM6fnbZnfxya0DjR16poCDhFkwErg805FY4rHe6quuTbVK67Wfuu9m6Woo340lAswteJuwiCcemxpCPY/Lv/vvT7FD4FzTiWOylM0wkjp8+wDDKGg6/ZrHacxUjT4wsqisAhnEgcUHKi8DOVIYXLDICoCE6RnM7a92YvGUr3PfLZ9Oicw1Ktex2+hvlw2mLmN6C9r017m04zwU98bjOzH/rFi8bSw48301pOQ1WoIxvgjnfewxb2yQJogTN6K4kUBDWQu5ndJHD2pePp8TkM670+QrxmgvB8dfQEpqncrHPLjb9It//uVqZJuDpj2VKayak0y3XuLulOu+9cj062FJRUmSlQGETqm6ntDFdBcQQiXXLNePoVfQub3twUlVgCnEgrfI10Zi2EAxge3n77G7vSu/Zn9I3dQgtDtGBwcRZ39S5xfMvkX9Dnu/Lacbb5Z2pF7S8Ex3IRM24pKKYIn7lzg+nOnLs5ntbAS4XsG4s/jLC0RGUElv7hF7mJctet9rQvfO6lo+khFERueiMl8TuABVDBFb8MX5cTx/aFP3A4V+69kmXQFf3pJes8mvoWfZLWawqXFS1l8pg14Cbng6BHMenIUkA2t87HXsbpuhtuzuecoyzadFcEkJYt/xWBK2lARSkAk8j64aDDuO7ru/SaRrqJA9RTqW1FWDIUnySghAJhBXrG9BkU6jiFaqd2egxYXr9nPR36jq7ob8n0Utimm1BeZDBo1TMgx0N6FLg/oG2+Qd+vl46/GigTbAJz+n8afU2bjaPvlF66WS2d+P7u6NO68hKhVZQYXBhZ4iAsFJLWTJQkxah5DvNr510+Fgf1bf7MQ2AinX86w4u3oLM9Pw33NoPpfF3qVJreddeiCxB0kC4QSlNOlfGSS534RRkHvAxL3lz9o7H045vytrOIZrw2dtNpckgnHdk/V4TXsdpxCLyxP2rfs4svWK27DsS0OFpbm0rfVty6hY3hgbTEQ5psie78UytdeEWDEbByQ5SIaJwcX7ctXc/EjtzJ0zDNJqd+qkRhIaGL2Xf9mTm/qxtR2zwOmaNUz8AC0VQLBbNKDkaaKSage2gzPdy+6UYscR3dHU25hZ/5axpjUuDVO7vxMa8BzRrHkh/La57tOOuSMU7vu7tkMi5jF9MZUmAY7hKXo7PToGMrOv2DfuE7sBNK8qKdhFTswbY2bfTX0MA231+jK/LgY07hEHeSSujEnila2cdpCje72hrs9SrpqPAHnMh44NdZygdbUCo9pezUwvczGDyf0aah+V7DIDYQT8Zb/Ms7osROn002ZNmPCWe7R+P0jeWwUz65KlFgYcvxVX9OaWb5AAPgYiVqYUpfYKnNSy3dxFuwTJQrPhDumGDKNC6rrAzFOWFGmlv8pdValtEh6QXwVy8ZT8/G3XmRfRLw9j9+uTk2RJMzDQFgVl3bEbW/dOqRXWn7rdnaRA0LqqN0I0FVtvibOSmOzOcJb3Nis6v/hRT0H++3Y5tBBDbCjWNxZW5lSkKA9I8wQFJobpo49MCu9GbOvAzD9CL0wo5CJa72uPm/JAwYGYgMifXVn4yn626kNYAOUvgIGrIlO6IchGdQwBJGjruMZn+/vTh3ww1SzkMqwFmb5PiZfbks4t5EYMQ8NnkwQ07OW5GcKzzz4vE0d75CYJlHMFobi0Z3tlXPyS554wDutKO60w7b5OMHUYzElrcEYcl8kL6gAf/IDyNh8VkhbdbPuWw83fMQ02EOOgIbpWV2I8vujyQiWqWLxfGBqdOvjyg8JvUB197yXz4+508nf3v6lGfX6+eu6WXLutOnmUi8habXc6MrmPdrG7FjlKN8n192h6dWEMt0WuB0LNMcB+zHB24GR1PN/lYQlTPYgCi3mwe1wqzCci5wkHOb2iuuy02v27o9OBWmxA/UOWGmAuaZexzZjfDB6Ndxyu/Iv3WebZQ+DyHEsTDz4FdcQDWBpR3vXMg6DHIp6VdML3yJr1ANMXBpFaZnYirSjWmKnCbsgSoD9wKfrbhR69T395CvseiDFlw5ZU7tM0wkKzCD5JjqGeWcjK3BTznb4UgzdhCVNPGODFQwoAYhmYAPfQQ7eX/C+/qCN4OUSVT8kBqSEW65hBAG/bl4TBj9/ohiHhu0jq30zR+MxQaOCRnJgihOr4OrI4Cten38JZtv8ckvfvGLt2fCKpjF4fv233xjuyVzrj2YOa1tly9bnH78q0aaj3pdBtOdr9PkmoG6HncSpbULg4w9ygEZGRrMJ55bgdaeSU1/Z76w0MI3UxaNvwaT1FOmTX18/bV7f8kl5QE2k2Soxit7nZviZNtVzdrTC+gS0NF1GipMFS0LUOW30suotHZxI8NR76q3XralI8+qcBQ0jMxQuWh8S4iVJ0zloZ/9mit/1Kzd/SB9HpreEqWTs87FdbozkOpJmFe4HfimWtpnt1rL/mgFPhIVzSXuqjAyHZXDbolipPZ7ekErXUCZ2K1wBUhF0DZkuqRv+61kGRtvjjNK3fhv37Ds7Wpyz1xbVsE/EsedfqaRn/wJPn4FD/49vT3L610DP7jo6sboyFhXvW9lOkgjbwam9NUWPbv4iT40389+9rM/CLYYcb4g85Of/OQDf7r3j+f1sX8pE6haz2B9dqG3vQ3L5SPn2YxTkI7SGVx/w42vPu6Eow95QUSsSfy8SuCqq761x9wn5/8ORQBr4A3MifPOSHPwUqh4ujgQos/L/qt9YD/JMHXazL8sWfLU9meccYb16HmZSU3w84LAXdQ9VEFPz+ccZCiKmveI1BFAd87Yl1EzRv/BMBQeV0HTfIyj09aY/xclMMD1B0yeMyvSG0ohazqFTfHL7FQo5ZlvO/OhIbE2aA75yHjac8/j+xBAdPnzMy9YAFcsWzE+nZu+QwAhvDS/ORNZG8ZxPNsPTO4/ZLXeTSZ6utnZsMb8PykBmT/Ad59tmeJPDRfcwKLQET5JAKv+YfFDIhsPPfSLF8S/FyyAYyOD9VN5EQAANPxJREFUrIdyOzy1I+iDnIrOWEGxPmWjcGJTnVeeNfqIK1+IXmKvef/XlwAj01ofy6N1z1VUYpRbqNwch9aTZYQZ7DtvPLF90+10UjUweJ7kvmAB7OnpR5641pXxfJA1IV+SGMJm7aq6hVVm8I9+BZ88zNuvnyf5a5K9kBJwFcX1+aI81H4KliMj2ysbLQXOEXQWTHSeXDYi2kSBjBNcpnme5gUL4EA/3zOCoG4nhCC/aL9CT3FXSm+SAHaN06coI5aSYM37/2oJ9LJsIe8Ups6fMuZo3B/jx5DMEDgYKb/DtBzzM7n6AswLFkDPUfSgwj0TUoTNJZtyODuqVGhFRTB3ZiOj2B158V2aF0D+mqQvpAS6WDrpouvkilVoOBijtnNt2C1XjnY9mxzLbyGQCh5LoCzPZmGstbbccssXQsLkiejnA6mrpyv1MKFqE6sA2tw6xIgqw3PCNtEHhPyqs+tcYLTFzwf1mjQvsAQ4AlFzibPGHsQQKPiiUa85h6sA6q/Ci13ovgtOGcv8zFAsbRXP1X+/YA241pTa8PxnuEsaQdTE3G5InWJGZrBbu7QroGo91brGMyD1nl6mp9eY/xclMH3awLJnFzVb3PoVu/1jL2ZIWB0BhEkyj1+sC7sHQGnEq0yn0co1DzjgAA/+PG8DuMnm/PPP3/jXt9z4xidnzRrYbfc9p9R7euotDyzQUrLmF/Fx1oaHWzUvsXz5Nkv2f2b+krd4q2auRRPwQugqHZi1o/TbVGdt2MNG0Dvv6nr857ducHV8mK+jNQYXrUF+QMA4mY6iKdANlCaX5TbhpvjTjumOTz/Esl5FieWnrAdYSy0P4bJbQAZYzqwEzJnNFnK2m41S8HbKcxB24/GUEm2Blzfk5LIjPcXChxw9o5I3OrxkIzRIVCviOAEaRHigtUJYQRUaY7Aaqw6xDFQnPZdf1s68uNF6dlGr1R1Tq3EkX9RUXHRRJijcPiCLDo8zEFLRavktPyv48YfW0ytepiDlMgga8sjPVPXuetfgiuFl2y56duFxYq9yF3DNaC/nZG76dSN9n6OU3TS5dtVVI7kQIhp+XUs22mijq2vd3SNkghlh85rXc6Zxc5ZTw9ttWasdsE/Pkr7+qUua9eYdPZuc8YucOj8nacCbbrppx4986PQfPP3knK3pH6T77v0TdOcGtSRCacVddR85uS9ttjb3wy1nmY21SHIvJ3K06hUVRnu4q1FTxHPnbI1F9Fb63JeXb3nXvWP/3Y0PVcTIZoh65LYCZtZ1lwDe7qGzmfjkP7Hzeqg3zefTX/I64hVoHbQYpBFEKXC3ddHapH/8l0Fu8R+LcxUFY45dPSNR8QnCMjl46fJ8zMlH8cWkVn+aNwc/CSmAgm6cvKOIfPOLrFQg3RTgDVafP2soncUOa+mKMhWG6ScBqxLFazKSpZxrOehtvWmt3ilpIZsUXKqLutNJf0UI9SxNG3AKprRQWcu5A8qr7c49f0XstnENPBMR6qOym6w1s9FsnqCvRiiFGi3TgPO5f2IX/KKu9Aw7j3rZVTL46D9+bmCrz/yPolAmCeDnPv3p//XIgw9uvS5nODTO0Zn3zLCwxZZxD86c7C2dFPJg3FHcRhvpRJ59rDWVieSQyNu1yxWsx37880Ppnvt7uQioYzHEhFVcuZVxFyATb6N4nuQ4Lkl814H97NaxP5lpNZbh8eyAkRleFbb+MMBJ8vO5w+XHN/EJMuhQa5bU5qKQM2ExPOcv42CdHDre9qbudPqJU2Ld2s2dVSYiYgEZwlfSRh4novlxv2uuG0sXX9Gdps9gZOoOjEmmTclEoo5w8+YZlz1260r/9Hfcx41EL/FQeySbSJubTxJWXlnIs+BZaH41yq8QnAFvHngEQV7LiOSmZLYkzL48c3g4q4dR3WX+rgO602679KSFXM6kVm4NjrEZ+MJ/WG9sw6uJcofRJyn0hx+4f88ZM/kSDgGyqeDMtdV9a/kG1dOP4xvBxPGqhjCRgAe9V8mJX9CVW4xCouxUlbt16NvXjKSf3DgWO3gzEJ/AqEDmtwIbwHMUAOVgz3Dkwj756L7YJBFHFQsiYmsVXwgdiYrwZQAUOBFchL/l1tF0KZeXexXHZOHLKNvPNh0VBRVH6Irky8v5hITb8t3nl3FlnNIRecCiv25Nmx60kZ9HeOgvXOfBJyRsYZwXLjltlweWknbCT0C5fNzd4/dGPnpKX3oJey+90csQ0wTeTtzFn3dEiCzRW6AAvNXrG9xneONvxrhhVtrzz6iZJlX7f2SkMfPmdXvwIR92/GhspRT0Wp1v+/HF9uVDs19RIEwSQE5AOUZYyeSMu63KvXCnHdsX95V4rlegQbtP0zF0bxdyrnowmslmM8/PLph3ntzJdR6XeIrMXc0Udgm3dmZ7iA523cWeyVJI3NC6LtemffgkLi/n3EGpCFkmKqHNhJGooo13JTPhZZM/l8s0z+JsiYdxPOPSxo1qFK95MhsT/sYxDD8IsVbLtFO5RmO7bdhNTKWQWo1xRFSEL96QkhmqhWDKq4eTdG7Ytdmd81TeAGzijKfQVMErtIAz04Q/f06dWCZHcbfO3q/2Rq+CnwSBUzoyXVKVkUsARs1UFYy88WsCl1/FNW5sx8sDxgn+BbacsZw2nhWcsJMXhiQb8QGfD9In964gK2QIGdFC2xJvbJyTTZWZJIA5WyVIgiGcp8NwT5EdyidJX88lQp6pyAUZUXjkkjGFTAk3G1t76oOpt07JtOickVM135IlXJvLTfGLUMsT17iVwvGd7SEAgtJUmbawhe/G7ePe35d29ToPN7iSRDqDWi1hz+7sn8MtCd11OtWCvICrah98hF0dccal4M74BZr/hFb8tAsBNwx1APROLi8/4M3c4cJZ3hytYFQXGDWXlYFBX2gs7GoEjztQqa/kMs1b/H4JGiySdOILr4Lfd/lF1Hh4tuS1fLn+8HfzvTiafwVK+IE7ouf0ymCpEOajCIT2Ppbkn+FMsRVh+SCDl7EVXCawPDYdLFq8OM9Y2GnEZOFXWqqKak6BrfbWeiKabwcGQLFv00Kw3AN3YCUe121VZpIABsUlJN6ZBZ5eew3fgziGz6PGqMpjmoaHxssZFXHOnCEcQpqxT9p4h6vSJjtel9be+DT29Q1S29naf8VYuh0NmHcTC6RNi47KyCop1xhe7Pn8wpv4Jtmh7/LjfMQSffVnjY2BukmC0SV9jiMYBVtGe5742h/nc6sBxKhhOnCHZliZvuyOT4d5nQffyFAru39OI6XqwUxxYRKeBBsjMw8LLj9bZllcwqF2b4/KAmGsDKVopuzO8LM9p/fpLm+b3A+fxLc8ONXmASXxlxiBE4d4AyzvUIZqcOKJKS6Wwn7h5SPpzw+Q//FlaYdXvCJ953vfS7+4+Zb08U9+KrbSs/+zgiz0YsyjQPmWCsrgwDd38+OEH5VCxSXaQFKir/SeNAiZHFPS8ic4vSX0VFTqTHZFq/3svIcRr9HCWIBYWnwbuLZJ6t3g7DTY2iDVKJHutf9XmjLyVPr5z76bvvODvjzSjMgmBEBGle16YQJU9cw+fiymlbbkQJFfy3SI78djBJPjVrEmCKqglNSZVg82eXrsvEtHooAs/DCVZhJaEZ9JXDNSVdBuZfdrnx88sS9tvCFamKY3E1HBiqjma8IdmazyrLdTNosWoXG42QEFQ6WwUC2IYsxbFqVSPBOVMvuoccRwCpXgFdvz/RK7ABWYSEmg4ZEOpHlXUni0+aafZXLDz8fT9/iIY3f3OKPxqYyAv5ZevuMuaLHl6UMf+XtariXpC5/5DAPGdSoCO2mVF3xNgFtcTz6Snd7QYJdA3JZBnofKxOQiKAK00pb8gNyGm5diPL12DBd178JliXGO10gBOR7YLajKLr7E2dTGdqm5hFNn9VlktEGG1klPzHklH0a5HEL5lCvTDRlGG1gG2tZa+k9kQPhjTEXaOf8A/a2ttsw3KmQtN4Fb/oWrejgVUnNaH2MfyH6e/UU/FjN7rqfSiGhwxGcujL+wKiFh8WEB6k9zw9tWZoQNtkcd2pv24RaruDk/BKWkERk/AYDbJS3/glbiSYcMcgnz0itG013xtXbLsErjy/iYiprKpS/+OTvx8hMSB9IFeMdb8/dL1Jghf6rkEs8yjfzoYQ6yEYN2+8KPcb/O+Rzr9BMU3v+y+eZbp3XWXS89/thjLMWNMyqfmXZ65S7sgO6Nfny0NAEm0+nheuGcenQP2tijHPmwV+QZgpwyzdo842cFsJCRVtKAbboDvKe1DtiPT3C+ozsOPEeySngjO5XwBYPMc3gyN7ji0fTUYw9yvcMMCpvLegbGuSn+Nr7O05W8Ky4LjiiqYrD02yQF6nAaGmUOYNX7+2h238ptWl78mGUkp29f54HTGm1mDYkvZYYNOx7Os13KQfIbOWbgyHOSCeIhgogZtqGZqGC8Lpw2LX5B6mimf0bpizqwijQFmEmkQwK0UF5SE05tWLyy92fMAFz5fc5R0C/Ocav4Fc54VQGRnwzASAHc8tiWgc+p3K9j18zjDppqrSBQh5tHgPFR0Vb8Xbxyrffcr4+lR2Z5jRsDhLGe9PRTT6W7774nbbrpZsDlhgNU7e9//3u6GXmSvjNH9snFfTyH/F/H/TrOTuTMVnyQbvHqXfLQAHFlVhZAo0ZE+zhbc3hGlWpz530uZlRtFH+l6QJyziDhYfE299np6TlfIiPv5MMoPemhB+5I1117PX2U6RE3i0chIVNl0glGlbCcF2nZhRujTmIELkNji7iaTUkxt9byoCuny30S6cqwlRHOyvN1yka6rGP0HQUj3hytEpIiLAGSQGELl7MpFPSGjPBOZxLeiuQBnNwdyUJUgQmwmRKTWT2LqceVvbPnNNJ5F4/RTPGFSpq/EsF4gb3Qwzv7VemrPNoaOFl8Ote4bb4p34tj8jmOy0bNIQVvlWCY8CvpcwlHEA+/F/ctplz8ir3lo+lhSWrp0iXpc5/+VDr08CPQfjPg3wPpO9/8BoM1I03kxvgqqb1eVeeqld48PqDj58xAXnRSCI3Fo+JFKORy1I+QyQIYoxprAdqCKZKTj8jnZ+33CTRyJfVFgAWa/wOBuCK4Z3radMM/pPVG/pT+Oquerv7WPAq7nwPuLNfxZ5z80DJhJK6Yit44sW//6DSmXDbcIDe9FdrAafyAtzJAIhnPZljNt5TJ4nMuGs23RqGBwnS+wl55dNBRoDvIsDvi56l22dlLLIlkhfSvSibMXOB6TOQzXNxx7f475eEiDrQ//Ai3BzCF1Gk64RT/iNERIGkeKT2OK3P3887mUAwyxApnKh7+8wtaKjvBlcmayTK9/yEuEOILok6Fxa64Ko63mj3w5z+nT/zbxxDSKWkJ9zv2oYVsgqsMBg7nQDfgfp1Tj+c+Qw6fxZVy9C9yq1ChAyYkRL4DfEhgrBNFBIpwwkREYnlPyHs5Jf+m1zG3xbxOJEQAI4O8o2hLxnh7f3gwwzea0dropz3XXruZfnjDsjRvwRSmG8glyAOGiIIsLcLN7/ATnsEYR1HOIx3J9Wl775ULOypB4OPh27TSJg/CP2dW8PbX/LhhF5XpEu7L+wOfDospl8BNIKbgyq6KDmFWNEWThtQsp+ndn9WO9/ANEzWh4dGpJ6owFCx/7WxZTvxCRfK2z+cnu65jue+6n3JnM/1P/wJ/hSsSY7d8xRvlLOyIl4Er+LszI3GcE/BWCpCGFo68iy+jLPRkDZ3pCpiE9/ItPyukH3Ccx+m6PtwTuEWIhkXb2aINcd5zCifgOQEX/oRGVCujAn7CkYwPdupOK+wWVWDaZWfmwBd5xBrv4hAOZrIGJDsONPalLT+WKRfb9ziKaQHxnzOn3QKK9O1+lszQq8LJWYM6n4RqsaDtKMs0Ob4RIk6nu/IL+DxEp92J3X1ew/d5D+unUmSBbAudEUhn3NzvEWpOF8MFw3BOQdvdxFeKruDOEjVhMCSiVnmokrU1cwDJcIrV0fdWW3KWlxvrFeZRugRBh9EoCEGIK95aNNLlOx7586gP/qWZzr94FMZlbWiwBVlFCRh6TYaVAfr0C5XrrFNPHzp1gCWyeixF5n5uhhNpc3SsztHlCp+1coZrN8rPWVzILICTzjH6DgJMjSm8xtrNqI+hH7aqG0FYRW0MSA94SzcfruGcNXQF98GnXKjkYg+BFRAtkiux1SiXeb3OnFNlJgmg6nwzbmU/ndHMWjPocAsYpE5VWJulzYep9Q9mipC/4i9cl3DuYn7Lj+LZ7Fj7OwtBMG2jI8iZKCxhO/Ht5eWncXn5jBlOdTCyovCMmvua2nNi6ZIG3zln2d8ND0/NY1GdL4IrRN7h0mmKK1emduIcJQOKCuiNXKee6Oibi5bQHJFdYokv2y2TXMAZZmaYCkEwrvjE6JultrnV90sMyHiJUIyJA2+GlQst50uN46YkP2Xxqt3yl4py+WeMZQ6xgBC3xAkunlWAH3D8NcuPV3C7rS1qwDBq4I3stO16a4K/2RIu+31bblHjbu8+8lYnb2gqZKRcOuBG6TiIznRVlBGpCv8dH5OVtsl0Vk4+aJ6O46am7bZmlh9hFLHCEJ3+koSM2MTm5ieH2wQSNSRdLbNkKaf2vzacFi5CvZPJnKMqhwWOzpW8Agj4QusS5o31r7S/hVbWWNujLxq48HAgQg6yIJSKYUzqLUy35l1w8Ui6/0FHvSTqRCgMo2IM8TfJGE4ER5uHHNyX9ufLnStYfoxuhJXRPJtK5Fb5cFrbtedwBcyy8mq7K/lKkZq4fDJW3O1kguhAniuWYMxcDrAM8vdLuLO5WoPPAmg8f1XEsJs3aanCoEHTRxk8zdcEzuIGVSuS01JFMAzvrBAxbWI+IFJaS5i7a7wc9IN8L26rrfPsiDwRv02w76DFYsAd2k/0mQTYFeMJQYYhyoQ5+j096Y178ynQGNJn6iNfYS1uEZDGX2FExQy1nYy/1Fs672pWF2QTEeqDMJNJYCTO7wk7TYbx+A0yujxg/970twf1RUWw1sQ3inmXwsg5kPxMV7ilQ/i0M3YBrudbcdddP8pIU2LzT3y5gLTpy1+FF2cGl31jKWm3V/K19mPZ7kWcJiUcXQ1wBD7fYc94xS2AoLECNoXO/u13NqNM3GliZ1/8RYsHLaQJxBlohGUaM30OOrbge3Gn0/T205dWCAJXCGgpE+BWfBBcMF6L9AG3i3Mfwrzo0mE+3zDRFw46yJvxiJHp8Cks/fErvsIZpkK+9+De9Oa/yZdOESHSRhxgtCPrMclkOiKLUfVy4CQBfM8BXS0nFBsstYUhtglCkoUMUQEARGZGfD58S7BLXLewi+I7fJ/XXRVmLsIiE9iDOmEKJepouwYGZOCocbbZiumfE/pj2if2wqoqqlQBQnyBO+PPNGm376HGqaW/PDrO9zqGoh9rxTB6TqSlcpMw05LfQV8AY/CDlvE+nNNO7Y8vgueBB4GBN7/jTI60dZZiRZfMco5v4aIGGmew+kJlVX7gJziM8SJJJjDTWYWqTV36tN/mF5O2olwG+YZI0XylHM1XNMHSwk/YptFoV44c9PzsF6Pp+9fyGV00cqCrwovd2MU+wS2hZJeKYded+YTE0XzLzwrpJLsJ/LWFfwJCTkdYCDKwbbE0eVY6rJ1FF8Q68BCgUQN4cWSfjIxwwzIqYuLoJ1NPcnnl2ecOx2SttT0MwcIqOC3wbMyUpso0MMqM+mmnDKSX0t+y0y2WSEJ40T6mbAs3QHJlEFr+RoYXEfl93ie4NdQNEJpgS0FevQsFhudY2eY0ggJ4NBtM99qzN1Y7crgpKpv0+POPt2VQ6NPu90v8StIlfK39Tr6Tkde+yWuVf6GYtu0hakypEJFpGGeF9EvtB7Da0b6UiXSCyWjFH0nzA0EIeoQudwmbxujbb/mdQ7dIgbaVCmM5dNATkU0iQMN4RetAJD8hsdZMlh9Po0LyIUc/rWZ41D7ihzUeptc/hwven5FdFXL3D0cAlLIwkwTQJsbIcY0GIZ2AcieXAgR4LvAKAi+XllxiOp+dFA8yt9Q5uWqsksbCzTRWBOPSbU1X8J1XOpSPxbz5TbmTHbQEHSWV2cgmZ6pyxIu+BfCdXL0aDXzTzYzw6HBnjWAqcZXUVTqcOY8GV0zF6gTzG/brTYe/j9G3Gx7s+hE3tIppKjhtaBAT9ooo7X6fw+/FXUXfz8FQZmo7RRCQy6Pyi7RV+agx+Pf21p12zF8PFb9lFH1gyQ0IPktJQL9WfvoaX7erHU5lnctndB9nyc3vF4fcRTzpCkCRLvwrZwaQHWo6++XH8sHs17ya6TCmpLLGy9hVfqIOUBXeaBVCI2dajOF9hk/yhYXruEyzGDg0YUATXYcoBiAKVKgCVsACAXaPJkRmw4NpFgD/+Ccj6UfxTbKQmIoai7iCg61AKHByqL5ubWrF7tmjyaQnsvwmWS5EY1V/IA2awp1pm4BuM1NnCWk8XXL5cGifKBiZSaKCk1SRsECyeQgaqziOlv0+22lsMLUpd5mpjROLmtwphpLG0AK7ojI2WzzxpN8vGQ4BVhNGeWXkAcO4WSgrT4BE+Zhp/v1uil0a+31+PVS6xF1akipVvIQVJqQpu5xD1WmF/N4PWO1g6S9veMhlQRCmShf2HD/7d4Tg4Zej9nt9T3rfIcyBQoewzZB/ll6hq02buKtyj3jEdSaF05/pS9wf/Yd72gpwUu8FYOiQAJ6JDAdua56ERZhpCwHYFT6/i3aeu3nxt78V4bxMFX8Rv8qarw6rdtW5W79DvbPzxkyG8AG/0CNM7W3hD3vlh90zFH6f96tnDaaFC93fJhICKnS5uLKXvhPM15Xxld0lJ7HLxS+C+/3iMEQJ3D5y9HjngoemCo/CbGvg0YDzLxxKD9EauGQWwaXtreIGgwJzeYhJ4Lm87X4czp7HfV7DLMCkr4cSCzoKbhWDeO02TPjhhZTIm7v/6Aez87eTnQ6LsrdoMIEto8xu81cVW5BLXuwCbLIpAyC+F+d3SGzCo8qaDs1YkmeQuMOjIPDNDz83flzxg/F0w28aXEk8ofcmbEFQVeCkKJkxsUBD6oNMIxJOVIXNO+7Oot/nN2klkJD4i3QlvjRkOtrhQSfEKdxeL3Lskf1pj91d4splEJkjzAIuhVyFANWM+ZQ4q02m5VLOdtx2+0QXIOPgaXQkul1cObkggJAriaDUwu84wO/zMvqGjjbREZN4wegAFj6WS9AnI4JWD1vV07XX8bX26/l+icJX4RKL/5mm6l054uWj0mDSsTeCdyQC6JSLZRQJjWNBBqDJwKK1M4w48s4plsV8rObMs4fTPA5/RV+YMFMXEyUSSeTZSgZ/WyK7HaeyDLrdtvW4qL4tFxE9kIkwJ5YIZSMTgV+m3fujf8cn3c7kQs2BmMIroxH41omWGfpYPcrwoMB/YDp6ybClltKgoGze3NF8OecpbmbkmzvZopQYAn374rFy9nIMfAn3YNEb9+tJ73U3LwXPQfXItGkiuZGLKSAjk3hWGfdD1zf/ejR955rhmOtSIvNiOHEAEvhJG7yTrkga0LVFHOfZttu2K53IuqZ9yZGo6VUWcpJIV2jKMHFZMAGFjQV8v+Thh8fThZfwhUr8bHJiRSBH8JlNBaQiP/yMr7cT8Busj8ahC2ATHOurBlQ02F8OXkSqNvrKBVXEU2i8xPKCK4bTH27Pc49BbzQrRq2AVQIfiat8xDouHqK0Ihx8UG9621tQDNz97LmbCIiCxJ7b4lz5tBctBRFaFRUvtV/4bCt9+pwxpvcYgEAXA0hCs4HUCSNSr1PVaJdOJZ5SjIz5EcH4nhvMcU/f3X+s+lsUdGzsFCzERT6Bs3Tp0vTsomfpz3A1b2Q2wyz5V71vtgmFzWqH39kdHRF3VeMDZ7bbnORfoYNoEZVDNFSCuY6++TKkmyLNoCR38IzIQg0WVO8gFFJzRDvp9vdk+mYv6aIiED9wTuALN9EtnigT8ikeAMatAX6KXoadBR3xvTiav2AmkYwWZqLcs18Ucglza1TOr59q3ekVrK/66TATxws4FS+Cu3JYGkkTLDNOVU7Oe/7mVr7lxweze93u1eYyaaAh6AE32DLMioTwxy6rXHPeYdshVjtovmvuFazKFDxmvNyUoFDGXTHhn2kQnLR4+tGZjU+cOZb+8rjzwpW/I6PKtEnTbf5i9l07f5aXfv6yhTwD2HVpzw+c6WoH0u1qRxSOaYjq1bvD3Kv7+n33Swe/+z1sTJhOhlawkpEbQZ/uQ7OmfoD9bNtubW2LEgSneC0YfuCK0sVP+PpF4VfuOqP5JpXCb+I+0NHfCr7yiDf0gA47rsiH70yHQaLwCuDDD+lN++4D013ygzHSURjUvjEAP4H48gN9Ecc3BeVHsq+4ejg08VSmPTQyMvBGKh+ZogqMUSYMMO1+vI3zJe86sJuujfknieWgoEBoKQOb5KCBR/7zA4LEwW03aM7ccb6dPBhC5HJbNhJd7LyxRz+0QzHIb50OgKYMDKb/7x9fn16+w9+yRZ+vCrWWBz32B7LQg9lOM//enBC0tcPyINld3+dcPs491nwnmO/Fib6L9eWFCz0jlM2kJlgvRcjMhsZqN70KBYVKXyeWw6D0cnbz3ukXgpTqjoxZWEOokE9+9nPpxJNPCSyPPPxQOuTdB7M/cC4FhGogfqj3A3vS2/6GXcWuryoJ4g5g2R6JsVZ8q5yGZWNN/579LUbfTq7adJZQwchu+2iZ7TlNJQIRT7snyHbftZ6OYPOFgyG/gKmJ9EaIWhg+kaYNj5tfFVWZOJXCnfhCJd0Tuzjxb3hFBxYhZ/wVTTAve6A96Utv/dJ6OukYuwBWioZNVdCR828aIchzgcup/Cdkyy3OEqORLrqE1Y4H8kdrcpKJcolD6gIRqP8BstBG1SP9yNDy9PEv/mt667v/MeZDp3U/kcZmH4U2e5SEAyEfZjAqoOmBFa1j2HHCS3QOx27zh3yc0De+/+4p/P3vf4s7m1xVK4dCFwQVQL4x+kUNBLBt+q/o813FjHp8ISiXaBXRWrwivXLX3dKh7z8szZ8/L82Z82Taaptt0lHHHEOTghaECjeY7vCyWjrpKFVnVtNR26M5oTDQjgVffuvu8COeTfZD9Le+xlqvsut2/ZBhaeUnXE1mWvaIwidQl2Q70lyfIw6nc8ZkBnOGfrBQPAHIeACM2h704C9ga7lhrhbRFelF8y2kNTibKZfFfC8ub5kjHv/iLn8WdCmqoElYQQmfsqCZss92Cov7W27qRlczKypSB65Mk+7ohwWNRNFtHNzyyGOzP/4Zh61YfvS0nUCiQgctxsHCfzYlrO0R8ZcvH0r77LNNOujg49L8eQvSvHlP8q24jdN41zGpMUrfNrQeaYNXJIm3BGEEBQ5H34/+tZm+ctG4xUX3bAKH9PRzp2Qx/44GrAqqIjbXM+CS0X40zpPs5j3nEs59cCCoaD+bIKOH4V1nh+PTT82Pvp/buD1NZRPhSgEf0YxJWg/0eJprmU0enAnGyyHSB6N4C9MwBaKqsOHnKoufND3rAvtb1HRqWMFPkjajhaVbU4Fu26McKbzj+TL5rju5tYnzrxGa8YbWKfgDUCVO+uEWrlMufq39Eo53xhcqGTR0mkxTpiBG8gU+7xLTOHYBjmYTyJv4emgIn/wEbqQMIBlflIUwKI9OAMbrpw/rJtfzvu7hds+/GDGbDCcnKfZ2GIQovMJ2AOS9Nke+dwqrSAuY5TB2gxswxtPIopE0o+Rc79BKFSnQqGBZGfwIki3JF/lozZNP8/256YYVbLlsSdX2mCSAAglhEr4lREL9bH1V7w3u4rjom+zmfQwVG6fmSzFW8IjfT9W77957009/8tO052teQ2E0qEVPp+9zxK+3tz/mlY48gg2mfBpqBUy3WbcwC5HinaDXgq8YIQoDoMWPIX+D/X0380Vw9xoGjQQVatrpsbTtVXJeYRx92/y/620MOuxvIYzRpAZGo2S4RRCiuclJ4+kAxoHLL9nhcrVfqEQjy5RSkaS800hjmIrIkCHsdgF22bGejn5fD0cqqazVaTLh5yQ5XTTApu0AGzDx8zOxI+Thaxy2euLJUiEtNyLz3+YlcYVZyjhAxQMxkxWUwbGHTU+77TAr3fPwdXwneD/Kukl36Zm0Vut7aa11uapF2QGI0EOMsAtTf7W8HzO/6Irx9OvboIMd/IZZltngkIbYfp19JglgDs1CmDteACdBDSHx1Pz3f9JI19/o5GqBZxYzoyJTRO5i7qExPsIRvk+mvV+3b5pGZ+CPd96Rnnj8MeJOSa/epZ7ez61a1pJx5ric4snLL7kk8rOT4CwWEiI2t1XdRd/z0thraH8r0yKDyFo4fBYIbV8sxc+5yy2YXD2Z77R5sWss8EfEifRGFl8MNnBM1NmMxT6na81fozWwKddtYRccmaqOZ8CfcFte3iFj5/xUPhm7Nvsv3fMYRtyhgoFXBJG3JuMggnGQYke4Nt/f/u5Y+iWTvLHdK8eMZ/tBfIvHV6cJ9/9u71x/7KrKMH7OnDPTmVKoU1qtIAmGxgTFK0giSLwktRq/GCUKXyQQEyCoif8B/4FKjCGiJVy+AIHEBJNGo4lRiQQIiYIYaUQBKa0UbSuUduac4/N73vWevWdaC3P2YeaDe82cvdd9vWu9z3rXZa+L7JmG+sJn2NMr/mkmfXv/B/ps9njn2Gixc87cU51t79ovwStEqUULXjs6x+euimhhX/Ijjw87e+/TIU+Mvh05fKvSxarnyb6gYgUAgzi68gTgKaUyYSUFd5L9SDvKqLlzOYpWgJQMDuPCUj9Iw2LuCN738E9NJXcIc/ndNknNb6qwt+rNXlqnR4SZlhMESu5myxQUAQRKnsnVV7kvTns7XtHom9l1M0TeiKUejc2OLx74IzrmGZlAv1ngu0h7jFmaTsDiXKIgXcBQS79W6nxRGAg8t2srIycrsKEnAeN0/VDwoojdMUVS7orQXLF39iZt+rpct4fmbe1wLfwHTUFD0pf0ZHVQN0hN7ZNa/LtXvAGsdaaXzITUMoAjfNhHjnl6xbfK4iZd2UV/7fjxni4YGnQW5n6pfFFeqqj9zQa8C7nkI8pU9IocvjH/Q0edcF8ca0lj12GkUTFG6WNVUysAqHkrndgqHxZ7yrTefOJixPpDXc7HcWreS+sIyIz86lWyNY6Wwu1LEnLQEXDicBpm9K//2qzu5xX4tG90TEeJZhxYLlXxRoGCUfe3RNvduoX7iafKnJIDQSeUyC+RmpgqUtzSioJitHmt7mjbrf0uXA7tJgVq+Df3iISfwpUIbZLHjJVm/0Ft4t7HDZW0BnKAUcH8CO00CVgCFYFmP/il6f3slTOdq7mhUuXLFKuhR2alHFRhc0Ids+ctpaFMyS/TYUc08KFP/ooW/8bONrmR6UyYyEyfXpkfnLGWmU9r3G55k7pFF56vvS8SDE5c/a65OYnlUoAewEAjcennqORGWrGhiet81T17bugDDMYZIB3T4iRN98xYgkWzHS56DkfbDrpqKxXAF187Rp37Hx50fqdFlbGwM2giYWjjV1eYkxEQgT/mtz53Vb/zpT1a7OpJXoXADaTpx9s/4iI8b+zwo0xjxwjvNzo/5YGfLRfxrlLAoWTOmawlnHR5ZC97fLOn98Pvn9F+F5qZ+OpCIpm2GUeU5ccILkaZstA/2ABwf9ZJVj/WESMkxwQ8cUfS1slUFEYp3PBlP9IzYX7BedpNJim8IAnGRHiMaOXZmS7pKX0UVivKRBb0PDjq5B41vY/9IXlTEoxQfsaDtHEL95SUxAstX/liT5Uh9vS6IshBs0zyLQ9SpOWQgboxbzyPKC9n6aDRB8WXfdpvTb/PakxKxIEdJHAq7jt3nv9seFr1Ka4z/8n7jr/69EdZVcKEH18ZfqF+xU/uXyoohyEZVIXmSMkcJIpoO6kBtYOtnMGLd2kd2XUznU10aNVfcr8NPyCcWECAtXpEJMEsx6fOvujY/9dh57t36Ggv1VD6gV4tY/cSh/WneZTqSnN37mKn851vzHR2nDtwpQiJQMGURBU8Cp0nTKYiQih+6Ozrs9JhXUt6u25rfykkDhPqzrvTsU8ZFaaKEsuxQuLwheDbujX+fe8d+upZb5PN8A4beYLBoYMG6fTyUjlpWWzxcy05u+ehZccHXwqpprWEcLp1/ZgQaWgNPnGpPj9ey+m2mtdUpUywIW1JOyJDupN+8DznW7Ganxt2fvuoukV3cU64UtL/MBc0uxQdiyJCEL3e2Xneeb/as2fPEw9pUIpSUVTqXzMf+f7JpU+/4/jRZ78+P3d88aWDg96dDyx73o5RXgW+EqarOfDlQW9p+aSu0iabKBKMLAMSVlhf9+VZTb2MtB8BdzImxsqb2SxRP+r2TmAdofDjfSsuT5reY//pdm5TBv/ygm7tFPh8eLY8OQqVSi0cYZMA9FIcgRsUXaPm7sLz9aXggFBTAtkz+qJKOWe5p7XrCn3QO+9fHv1ey4m4NJGpnEyMvDjOfCd2FEPSB6EnlfTVu2c6l15Cn2kgiUAuyjBM7o4Pq1o4iCAstKFUEbr7n+t0brt7acQUDnN+mUd7yHhscPoJb1NHNEvqBe3YNpq74erRHHN7h/5Z4ldYVHCJtyywK2mnEaBSIQ8c6r/xvTuXRkdeG3W3QIe9RyQRxDGNNDU33HXxBx67aNeum2+88UaJg1AZbZr9fmTfrdsWd358++tvHJ8/fPjEzL/VhLJZfbVaWFg4ofNDLn/6T8/s1UBDNCnh5KAoZu5vQdbv3qGQKgKTBYVKlYWV3Ki+devWX1951WXfWtZ9Dd3lqDrdfu91OVm2MLuhMu7sf2F16tC01NWF2JHb4rzaDjNObBG46D2nxnF6G1JFkXJdbeo8+7zle93ytPrVdNQ97bog6IkV3xTZkrpYK/NR979avyD/h3Qi7N9f1oHAYvr/UrrPbUXZ1P3Nz8+fPHbk4O4Dzz+5d4bDqcWdADhBAhYWFO6RAzcpV3VzWYBn9dPcox+79Irr//ZSZzA7qzOiT6N0yq7OwZ4ZHj148I0bbrnlRWKpe1shAdPhis/f+qr0/N5U3XXHXbOXfHB2oDOlTQCTzdCJwRJOb5opOrG01GTK4lx5HGq4319YePlDl331j2+aUOth6iVw7733Pr/p7EskyerYUTMsRtUlX8oUA7KIYi4r7M70XvzU7mueaULYaQG4lgi7m7rnLAzm9UEAYCmkwOdGUXq+ZWKxWaB0x7dEDEhRw6Fu2ZxFkLdqI0pAkmn27LO1t5d+jhVSEAES75CE6mcgSgy8ECDohwNN2TA/01A1Zv7s7EJ306ZyahJEFpUgQwqCQ0NOjwAlnlTH5F/3i1SBMnD7XpcS0E33ozl90OfGe/gEk5By/GOUiNDPLpVV4RZNcG+2724SPidVjQE4P98/NhjMLatPF18fBSqDD0LJiHLi+mUUytIjO73l5sGv14lPSn4brkkJALy+FlDyljSw9DPLzDWZHTkADGaicxe+SMmZbv8tddPORGNjANLB5AyRGKYLV1BNkytKc+hlN1NBRmqKPmF8eKlZttr1KgHdQaRueF8DwtIEi3eWgEAuBUmBIQBFpTBBAmqAkXidmOTGAOSi6pNa4sLFNkg7shDEB02nBZ8zGkP2Fn8T865xQLZgqB+nPmDPja2loDkYDIKPiT8nZqP4K2edcmpuNyWiMQAhQFMhpsPSr1AUwBPFgcmxiMeYCvAJtnWrdGrf61QCXEbEBIZ7gWUiGeB5MWxhHlIx4YbIC4ZpGo3DshuqxgAEfMva1hZntyRpQZVrEM1xEikNPnLOOjJFR7dVG1ECEhKSGXFmDOkbdLKxIBGj4E9yz3zDU4XAzohVwA1VYwCe0NEBmuU28gw0MlCIig5rUhhZ8EdtT8Mg/ThNM32nv/a9XiXgq9jElugDSlMGiG69xBYzFWLoDxqVhTKzTIsQasuqJqW5MQB9nK++S7raVBSbHlYLp+im+2qTvUanFwnZ8xKPSclvwzUpAQaQzEREc1skn7kU7ASBCTx4Zb3ewWZtsWQ5TkPVGIB0/5h24cN5hSWqiKuJnvF2fbJ0FBCVCQDL36i5FG9YBP+/wQUorSMRF2iRABhFAV8Msmqx71gCyg2+IkhYJqauYzJ34kJsDEDVDEFPEk0dO0gzgYWsXMsW9jUaS0bsfSw1a+6tdv1KQLxCspkl8MIac7GioXSZklXw8xSeVr7XpGsMQI2BC805DUP6IJA+HrkLesikBZ9dwg5H7Fq1MSUgnkhGAD4xyeArLwEO+zHDTJ6HK/SkZF2k5fi6hMnpj87Y5OFFvG5rkXLF0cOZKfFZvNuh5AV9MWeS06pJGV/7XlsJjNkhTTkazeCzvdkFe83iiBiHEgj8ri21U303loC6WD6IgMb4dFj6FFhEsxzSr6K1DlLkZKs2rgTgBX8xyBAdbm7BWPAPyVjxK1osBi1Dz6U1511jACIBu91YlBYVowCt0O/KUzKBVMfaCm8yeBVtsWpfG1ECFVMSc0g4d5d4i0nwzO/QmMiwbT6H2xiA2tKSElmSj6Y2iRedyoBp5rFa2U5+PSRe7dia16MEJDmkontE584Tz2Nz8BJ3JAVQtM5mW+nRHD6NZWi/r35skXBBqIgVkc6ZSMxZo8oNd3KBJ/3HVjSZW7XeJcA8oNI0ByzraKIAG3wpv6ApwGeG2SL9cWRBM9U4ApIHUIAQJEJqmoM01SwcSw0Kf+ESq73JTKs2ogS0qtnSwAIhMFXICJ5UzxQaSWUAUuEa46dxBCv3iohQ/QEy1yBEnFTQiT4Jx1K9CllpWU9Y4rFV61wCakKziYIZhT/BNsxwE/7xzHfqsbFkQTOxagzAWAgDmILYzA/El38TV2WkgNCOChP5mTgDbcAmJaA9okUlf+AHnISfngosDEqoBRhpsKejGgOwIqNOUuhNNBly7sJnZiDe06hDFQWtbm0lwJL8KkS0XJizy2SRIibyBwtDQkbLFWZbNnpMCYAFYXq5BpWugYGnLCbYTKmzrCzxFVxKHeFp5cXxtY+1lQC84RegI2wNkzKZd/BQbDIg8YGXld5kMZlqDMDNmzezrd4gCgIzM1AIIlcThkVYAtC2D7i6fNbPLHAV7lT8YDombIsT3MJC7Mzulc0ZtCG5jQGIBMvKUBEIVVUGov9QzGPfjZNumPU2uKResu4U0IWIGztb4KUETLdptF5TQQGVwRUiBKFrTHRT6TtUZEeFk7n4J/9TGMm3SGpYAsGHEBAVJuFTERqKHy1wrCDpPmNlnJCGqQCwqkfRQYWWoKxQLbMzMCY3M2YwpmHCLLTBplECAbzkXwiJiBemaf1fmS2Ti8z8xswMbxM+pwJAaopBWGpMBUiRmfTWCCSzdT81p1a77iWQoIuE61KvzqPC2hp105EbUwFgId1SLmtKvZacKSPqEk6nKtWKptWupQQCSAAsu0iErjfFwcscXGbcsK35YoQpATDENKTFrEpiqqolCULVNwvwzEas3RqbWs26l0DFK3iUwKtLwgBnArTA8VSROBHlUwIgxEH8mWkwzfKEN+sJU2H0zIFb17epBIIByTv4Yt6U1NDbrfB27GZzc/g0j6EQCpFj4sYyLqg+1T4CWRaWCem3qXTbaN+kBLL/DgwDbMmzACbBbV/emPFRxAjGRmpKAKyIXUkN9gw4Csl6V2DEZ2R2ZZjWtF4l0Bv1xBp4UCbNzI4YUNKXD0CKS/YTVFVaeNv4cKzm6+FVg1hSOu4yJIEQjeXYwVIxAJcZI0sEj6y1z/UugUF3YPYkC5JXISQQHCH9ACgqzPA0KW0uv5rHMCYtCQziGIzkLZOZsXCJGpZ61bTmy2ojsva5xhLQlwz4X7ZpJ6oSeAG0FChEHYIDeeHOE1aNVWPm61uuzraZmQNkCbSsQVlzbI+g04gDt/AXGdaKDC6kb9UGlMCWLVsOHz36Wu1kM3hjTFraiWHl1ITsOsGz0tzFkW5nOKH6rWWoMQB1vsiRQ4cOPywxrjMSqD3RpIJHzKihtlCxi15KN1+FHRJyaWm5t337Dl2n1KqNKIHFxcVnDhw4ePdwuLxTfBuCKU7bF5skFYOPwNHr9mUhcCJFOBGB+z56W7ac9URTuv8L293xrOH3Z0kAAAAASUVORK5CYII=",
                        id: "b",
                        width: 160,
                        height: 160
                    }))))
                },
                Y = n(83847);
            const H = "".concat(Y.RW, "/maintenance");

            function V() {
                const e = (0, p.useTranslations)(),
                    [t, n] = (0, f.useState)({
                        time: "",
                        dateStr: ""
                    }),
                    [a, o] = (0, f.useState)(0),
                    i = (0, p.useLocale)(),
                    s = (0, f.useRef)(null);
                return (0, f.useLayoutEffect)((() => {
                    C().then((e => {
                        n(function(e, t) {
                            const n = new Date(e).toLocaleString("en-US", {
                                    timeZone: "America/Los_Angeles"
                                }),
                                r = new Date(n),
                                a = r.toLocaleString(t, {
                                    hour: "numeric",
                                    minute: "2-digit",
                                    hour12: !0
                                }),
                                o = r.getDate();
                            return {
                                time: a,
                                dateStr: "".concat(r.toLocaleString(t, {
                                    month: "long"
                                }), " ").concat(o).concat(function(e) {
                                    if (e > 3 && e < 21) return "th";
                                    switch (e % 10) {
                                        case 1:
                                            return "st";
                                        case 2:
                                            return "nd";
                                        case 3:
                                            return "rd";
                                        default:
                                            return "th"
                                    }
                                }(o))
                            }
                        }(e.data.startTime, i)), o(Math.round((e.data.endTime - e.data.startTime) / 36e5))
                    }))
                }), []), (0, f.useLayoutEffect)((() => {
                    if (!s.current) return;
                    const e = new ResizeObserver((e => {
                        for (const t of e) {
                            const e = t.borderBoxSize[0].blockSize;
                            document.documentElement.style.setProperty("--banner-height", "".concat(e, "px"))
                        }
                    }));
                    return e.observe(s.current), () => {
                        e.disconnect()
                    }
                }), []), (0, r.jsx)("div", {
                    ref: s,
                    className: "fixed left-0 w-full min-h-[40px] z-[9999] text-white text-xs flex items-center justify-center select-none transition-all duration-300 ease-in-out overflow-hidden cursor-pointer\n        'top-0 opacity-100'\n      ",
                    style: {
                        backgroundImage: "url(".concat(M.src, "),linear-gradient(91deg, #303030 33.02%, #4C4C4C 43.99%)"),
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                    },
                    "data-follow-hidden": "true",
                    onClick: () => {
                        window.open(H)
                    },
                    children: (0, r.jsxs)("div", {
                        className: "flex items-center justify-center gap-[10px] pt-[8px] pb-[8px] pl-[16px] pr-[16px]",
                        children: [(0, r.jsx)("div", {
                            className: "flex items-center justify-center",
                            children: (0, r.jsx)(J, {
                                className: "w-[16px] h-[16px] flex-shrink-0 min-w-[16px] min-h-[16px]"
                            })
                        }), (0, r.jsx)("div", {
                            className: "relative z-10",
                            children: e.rich("Navigation_Banner_Maintain_Banner_Tip", {
                                time: t.time,
                                date: t.dateStr,
                                duringTime: a,
                                strong: e => (0, r.jsx)("strong", {
                                    children: e
                                })
                            })
                        })]
                    })
                })
            }
            var q = n(21658),
                U = n(12868);

            function _(e) {
                const t = (0, p.useTranslations)(),
                    n = (0, p.useLocale)(),
                    {
                        style: a,
                        scrollYProgress: w,
                        isFromPrice: N,
                        navStyleOption: O,
                        className: y
                    } = e,
                    {
                        setUserInfo: E,
                        setNotLogin: D
                    } = A.L.getState(),
                    I = (0, A.L)((e => e.isLogin)),
                    T = (0, A.L)((e => e.userImage)),
                    Q = (0, A.L)((e => e.userName)),
                    [Z, P] = (0, f.useState)(!1),
                    [W, R] = (0, f.useState)(O || j[0]),
                    [L, K] = (0, f.useState)(0),
                    k = (0, F.W7)(),
                    [M, X] = (0, f.useState)(!1),
                    [J, Y] = (0, f.useState)({
                        transition: null,
                        index: 0
                    }),
                    [H, _] = (0, f.useState)(!1),
                    [ee, te] = (0, f.useState)(!0),
                    [ne, re] = (0, f.useState)({
                        width: 0,
                        left: 0
                    }),
                    ae = {
                        app: "fromHome=Official_website_header"
                    },
                    oe = (0, f.useRef)(null),
                    ie = (0, f.useRef)(null),
                    se = (0, f.useRef)(null),
                    le = (0, i.H)(w, [0, 1], ["#000000", "#000000"]),
                    ce = (0, d.usePathname)(),
                    de = (ce === "/".concat("en" === n ? "" : n) || "/" === ce) && M,
                    pe = (0, i.H)(w, [0, 1], [0, 1]),
                    fe = (0, s._)(),
                    ue = () => {
                        const e = window.scrollY,
                            t = window.innerHeight;
                        e >= t && P(!0), e < t && P(!1)
                    };
                (0, f.useLayoutEffect)((() => {
                    C().then((e => {
                        const t = Date.now();
                        X(t < e.data.endTime)
                    }))
                }), []), (0, f.useEffect)((() => {
                    let e = 0;
                    const t = pe.on("change", (t => {
                        if (k) {
                            let n = W;
                            if (t <= .15 ? (te(!0), !O && (n = { ...j[0]
                                })) : t <= .3 ? !O && (n = { ...j[1]
                                }) : !O && (n = { ...j[2]
                                }), t >= .15)
                                if (t <= .28 && !Z && t >= .177) te(!1);
                                else {
                                    te(ee === e > t ? ee : e > t)
                                }
                            e = t, R(n)
                        } else {
                            let n = W;
                            if (t <= .096 ? (te(!0), !O && (n = { ...j[0]
                                })) : t <= .149 || t >= .509 && t <= .841 ? !O && (n = { ...j[1]
                                }) : !O && (n = { ...j[2]
                                }), t >= .16)
                                if (t <= .144 && !Z && t >= .09) te(!1);
                                else {
                                    te(ee === e > t ? ee : e > t)
                                }
                            e = t, R(n)
                        }
                    }));
                    return () => t()
                }), []), (0, f.useEffect)((() => {
                    const e = ee || de ? {
                        y: "0%",
                        x: "0%",
                        transition: {
                            duration: .5
                        }
                    } : {
                        y: "-140%",
                        x: "0%",
                        transition: {
                            duration: .3
                        }
                    };
                    fe.start(e)
                }), [ee]), (0, f.useEffect)((() => {
                    (0, g.FV)().then((e => {
                        const {
                            code: t,
                            data: n
                        } = e;
                        t !== m.h && n ? E(n) : D(!0)
                    }))
                }), []), (0, f.useEffect)((() => {
                    (0, F.bL)()
                }), [I]), (0, f.useEffect)((() => (window.addEventListener("scroll", ue), () => {
                    window.removeEventListener("scroll", ue)
                })), [Z]);
                const [he, xe] = (0, f.useState)(!1);
                (0, f.useEffect)((() => {
                    xe(window.location.pathname.includes("pricing"))
                }), []), (0, f.useEffect)((() => {
                    const e = new ResizeObserver((e => {
                        const {
                            width: t
                        } = e[0].contentRect, n = e[0].target.querySelectorAll("[data-index]");
                        let r = 0;
                        n.forEach((e => {
                            r += e.getBoundingClientRect().width
                        })), r - t > 5 && K(L + 1)
                    }));
                    return e.observe(oe.current), () => {
                        e.disconnect()
                    }
                }), [L]);
                const me = function(e) {
                        const [t, n] = (0, f.useState)(!1);
                        return (0, f.useEffect)((() => {
                            const t = () => {
                                const t = document.getElementById(e);
                                if (!t) return void n(!1);
                                const r = t.getBoundingClientRect(),
                                    a = r.bottom >= 0 && r.top <= (window.innerHeight || document.documentElement.clientHeight) && r.right >= 0 && r.left <= (window.innerWidth || document.documentElement.clientWidth);
                                n(a)
                            };
                            return t(), window.addEventListener("scroll", t), window.addEventListener("resize", t), () => {
                                window.removeEventListener("scroll", t), window.removeEventListener("resize", t)
                            }
                        }), [e]), t
                    }("sticky-section"),
                    be = he ? me ? "bg-[#F7F6F5]" : "bg-transparent" : "md:bg-transparent";
                return (0, f.useEffect)((() => {
                    const e = new ResizeObserver((e => {
                        const {
                            width: t
                        } = e[0].contentRect;
                        t >= 150 && L > 0 && K(L - 1)
                    }));
                    return e.observe(se.current), () => {
                        e.disconnect()
                    }
                }), [L]), (0, r.jsxs)(r.Fragment, {
                    children: [de && (0, r.jsx)(V, {}), (0, r.jsxs)(l.E.nav, {
                        "data-follow-hidden": !0,
                        className: o()("fixed w-full px-8 py-6 pt-4 z-50", be, y),
                        initial: "hidden",
                        animate: "visible",
                        variants: $,
                        transition: {
                            duration: .8,
                            ease: "easeInOut"
                        },
                        style: { ...a,
                            top: "".concat(de ? "var(--banner-height, 0px)" : "0px")
                        },
                        ref: ie,
                        children: [(0, r.jsxs)("div", {
                            className: "w-full h-full z-10 relative flex items-center gap-2 justify-between transition-all duration-300",
                            children: [(0, r.jsxs)("div", {
                                className: "flex gap-[18px]",
                                children: [(0, r.jsx)(c.default, {
                                    className: "flex items-center",
                                    href: "/",
                                    children: (0, r.jsxs)(r.Fragment, {
                                        children: [(0, r.jsx)(l.E.div, {
                                            className: "".concat(Z ? "" : "hidden"),
                                            style: {
                                                color: H ? "#fff" : le
                                            },
                                            children: (0, r.jsx)("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "w-auto h-8",
                                                viewBox: "0 0 32 32",
                                                fill: "none",
                                                children: (0, r.jsx)("path", {
                                                    d: "M16 0C7.16031 0 0 7.16346 0 16C0 24.8367 7.16031 32.0001 16 32.0001C22.6932 32.0001 28.4367 27.897 30.8267 22.0667C30.5923 22.2974 30.3406 22.5075 30.0934 22.6934C29.219 23.351 28.0596 23.8495 26.8534 23.4401C25.763 23.0699 25.0723 22.1819 24.6534 21.2534C24.4686 20.8439 24.3199 20.4054 24.2134 19.9467C23.6579 21.0293 23.0055 22.0974 22.2267 22.9201C21.3418 23.8546 20.169 24.5935 18.6934 24.4534C17.479 24.3381 16.5135 23.8147 15.8534 22.9601C15.5923 22.6221 15.3875 22.2463 15.24 21.8534C14.9082 22.3451 14.5392 22.8121 14.12 23.2001C13.3115 23.9485 12.2905 24.4665 11.04 24.4267C8.67669 24.4267 7.31477 22.5139 6.88001 20.3601C6.43993 18.1796 6.81404 15.3909 8.08001 12.6267C9.6973 9.09553 12.0463 6.395 13.2134 5.52001C13.7202 5.13999 14.4466 5.25332 14.8267 5.76001C15.2068 6.2667 15.107 6.98 14.6 7.36002C13.802 7.95833 11.6542 10.3242 10.16 13.5867C9.04831 16.0139 8.79612 18.302 9.12002 19.9067C9.44798 21.5315 10.2357 22.1334 11.0534 22.1334C11.0674 22.1334 11.0926 22.1334 11.1067 22.1334C11.6254 22.1525 12.0827 21.9618 12.56 21.5201C13.0615 21.0559 13.5368 20.3491 14 19.4534C14.4514 18.5806 14.8567 17.6034 15.2667 16.6134L15.28 16.56C15.5154 15.9919 15.7626 15.4168 16.0134 14.8667C16.1871 14.4754 16.3706 14.086 16.5734 13.72C16.9408 13.0565 17.2438 12.5545 17.4534 12.2134C17.5572 12.0444 17.6375 11.9146 17.7067 11.8134C17.7392 11.7657 17.7854 11.7053 17.8267 11.6534C17.8439 11.6316 17.879 11.5736 17.9334 11.52C17.9571 11.4966 18.0179 11.4461 18.1067 11.3867C18.1512 11.3569 18.2328 11.3089 18.3467 11.2667C18.4514 11.228 18.681 11.1626 18.96 11.2134C19.2882 11.273 19.556 11.4644 19.72 11.72C19.8586 11.936 19.8934 12.142 19.8934 12.24C19.91 12.4286 19.8667 12.5769 19.8667 12.6134C19.8428 12.7133 19.8 12.79 19.8 12.8134C19.7723 12.8793 19.7322 12.9381 19.7067 12.9867C19.6508 13.0932 19.58 13.244 19.48 13.4134C19.2816 13.7498 18.9728 14.2322 18.56 14.8667C18.4039 15.1515 18.249 15.4715 18.0934 15.8134C17.4584 17.2491 17.1234 18.7678 17.1867 19.9734C17.2252 20.708 17.4082 21.2254 17.6667 21.5601C17.9003 21.8625 18.2588 22.1119 18.9067 22.1734C19.4095 22.2211 19.9511 22.0039 20.5734 21.3467C21.205 20.6796 21.7876 19.6822 22.36 18.52C22.754 17.7202 23.1058 16.9055 23.4534 16.1067C23.6118 15.7423 23.7751 15.3804 23.9334 15.0267C24.3995 13.9848 24.9254 12.8884 25.5334 12.24C25.9616 11.7833 26.6695 11.7528 27.1334 12.1734C27.5971 12.5939 27.6396 13.316 27.2267 13.7867C26.9664 14.0832 26.7 14.6452 26.5067 15.4534C26.319 16.2382 26.2258 17.1454 26.2667 18.0267C26.308 18.9155 26.4796 19.715 26.7467 20.3067C27.0159 20.9032 27.2351 21.1831 27.6 21.2667C28.6215 21.5006 30.0669 19.9838 30.6001 19.3067C31.3027 18.4143 32.0001 17.1286 32.0001 15.3867C31.6774 6.83443 24.6343 0 16 0Z",
                                                    fill: "currentColor"
                                                })
                                            })
                                        }), (0, r.jsx)("div", {
                                            className: "".concat(Z ? "hidden" : "block"),
                                            children: (0, r.jsx)(x.Z, {
                                                className: "w-auto h-8 fill-[#F7F6F5]",
                                                style: {
                                                    filter: N ? "invert(1)" : ""
                                                }
                                            })
                                        })]
                                    })
                                }), (0, r.jsxs)(l.E.div, {
                                    ref: oe,
                                    onMouseLeave: () => Y({ ...J,
                                        transition: null
                                    }),
                                    style: W,
                                    initial: {
                                        y: "0%"
                                    },
                                    animate: fe,
                                    className: "group/nav ml-0 border gap-1 md:left-1/2 md:bottom-1/2 md:flex md:px-1 static hidden rounded-xl",
                                    children: [z.map(((e, a) => {
                                        const o = ce === e.path,
                                            i = 1 !== a && n !== v.X9 ? "/".concat(n).concat(e.link) : e.link;
                                        return z.length - L < a + 1 ? z.length - 1 !== a ? null : (0, r.jsx)("div", {
                                            className: "flex items-center",
                                            children: "..."
                                        }, a) : (0, r.jsx)(l.E.div, {
                                            "data-index": a,
                                            onMouseEnter: () => (e => {
                                                const t = oe.current,
                                                    {
                                                        transition: n,
                                                        index: r
                                                    } = J;
                                                let a;
                                                if (a = null == n && e !== r ? {
                                                        transition: "unset",
                                                        index: e
                                                    } : {
                                                        transition: "all 0.2s",
                                                        index: e
                                                    }, Y(a), !t) return;
                                                const {
                                                    left: o
                                                } = t.getBoundingClientRect(), i = t.children[a.index], {
                                                    left: s,
                                                    width: l
                                                } = i.getBoundingClientRect();
                                                re({
                                                    width: l,
                                                    left: s - o - 1
                                                })
                                            })(a),
                                            className: "z-[1] min-w-fit text-sm/[24px] font-semibold box-content py-1 px-5 h-9 ".concat(o ? W.hoverColor : "", " hover:").concat(W.hoverColor, " flex items-center justify-center"),
                                            children: (0, r.jsx)(c.default, {
                                                className: "".concat(N ? "".concat(o ? "text-black" : "text-black/50") : ""),
                                                target: e.open ? "_blank" : "_self",
                                                href: i,
                                                children: JSON.parse(t(e.text))[a]
                                            })
                                        }, a)
                                    })), (0, r.jsx)("div", {
                                        style: {
                                            transition: J.transition || "unset",
                                            left: "".concat(ne.left, "px"),
                                            width: "".concat(ne.width, "px")
                                        },
                                        className: "md:flex box-content py-1 rounded-lg h-9 items-center justify-center absolute z-0 hidden",
                                        children: (0, r.jsx)("div", {
                                            style: {
                                                backgroundColor: W.hoverBgColor
                                            },
                                            className: "group-hover/nav:h-9 group-hover/nav:w-full delay-100 h-0 w-0 rounded-lg transition-all transform duration-300 ease-out origin-center"
                                        })
                                    })]
                                })]
                            }), (0, r.jsx)("div", {
                                ref: se,
                                className: "invisible flex-1"
                            }), (0, r.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, r.jsxs)("div", {
                                    className: "flex gap-1",
                                    children: [(0, r.jsxs)(l.E.div, {
                                        className: "rounded-xl p-1 border h-12 flex items-center gap-2 relative",
                                        style: {
                                            backgroundColor: "transparent",
                                            boxShadow: "0 0 #fff",
                                            color: "rgba(255,255,255,0.7)",
                                            borderColor: "transparent",
                                            hoverColor: "text-white",
                                            hoverBgColor: "rgba(255,255,255,0.1)",
                                            iconColor: "#fff",
                                            navBgColor: "transparent",
                                            "--hover-color": W.hoverColor,
                                            "--hover-bgColor": W.hoverBgColor,
                                            "--color": W.color
                                        },
                                        children: [(0, r.jsx)("div", {
                                            style: { ...W
                                            },
                                            className: "hidden md:flex absolute left-0 rounded-xl px-5 border items-center gap-2 w-full h-full"
                                        }), (0, r.jsx)(G, {
                                            popupStyle: W,
                                            wrapClassName: o()({
                                                [S()["secondary-btn"]]: !0
                                            }, "hover:".concat(W.hoverColor, " flex items-center"))
                                        })]
                                    }), !I && (0, r.jsx)(l.E.div, {
                                        className: "rounded-xl p-1 border h-12 hidden md:block",
                                        style: { ...W,
                                            "--hover-color": W.hoverColor,
                                            "--hover-bgColor": W.hoverBgColor,
                                            "--color": W.color
                                        },
                                        children: (0, r.jsx)("button", {
                                            className: o()({
                                                [S()["secondary-btn"]]: !0
                                            }, "hover:".concat(W.hoverColor)),
                                            onClick: () => (0, b.b)(!1, ae),
                                            children: (0, r.jsx)(l.E.span, {
                                                children: t("Navigation_Button_Login")
                                            })
                                        })
                                    })]
                                }), (0, r.jsx)("div", {
                                    className: "font-semibold hidden md:block",
                                    children: (0, r.jsx)(q.Z, {
                                        type: "primary",
                                        status: "plain",
                                        style: {
                                            padding: "0 1.5rem",
                                            fontWeight: "bold"
                                        },
                                        onClick: () => (0, b.b)(!0, ae),
                                        children: (0, r.jsxs)("div", {
                                            className: "flex gap-[10px] items-center",
                                            children: [I && (0, r.jsx)(B.Z, {
                                                image: T,
                                                name: Q,
                                                size: 24
                                            }), (0, r.jsx)("span", {
                                                children: t("Button_Build_Text")
                                            })]
                                        })
                                    })
                                }), (0, r.jsx)("div", {
                                    className: "transition-all md:hidden h-10 w-10 flex items-center justify-center rounded-lg hover:bg-white/[.1] active:bg-white/[.2]",
                                    onClick: () => _(!H),
                                    children: H ? (0, r.jsx)(u.Z, {
                                        className: "md:hidden text-white"
                                    }) : (0, r.jsx)(h.Z, {
                                        className: "md:hidden",
                                        fill: N ? "" : H ? "#fff" : W.iconColor
                                    })
                                })]
                            })]
                        }), (0, r.jsx)(U.Z, {
                            isExpand: H,
                            onChange: e => _(e),
                            children: (0, r.jsxs)("div", {
                                className: "flex justify-center items-center flex-col",
                                children: [z.map(((e, n) => (0, r.jsx)("div", {
                                    className: "z-[1] text-sm/[24px] ".concat(ce.endsWith(e.path) ? "text-white" : "text-white/[.5]", " font-semibold h-9 w-[120px] active:text-white flex items-center justify-center"),
                                    children: (0, r.jsx)(c.default, {
                                        href: e.link,
                                        children: JSON.parse(t(e.text))[n]
                                    })
                                }, n))), (0, r.jsx)("div", {
                                    className: "z-[1] text-sm/[24px] ".concat(ce.endsWith("/login") ? "text-white" : "text-white/[.5]", " font-semibold h-9 w-[120px] active:text-white flex items-center justify-center"),
                                    onClick: () => (0, b.b)(!1, ae),
                                    children: t("Navigation_Button_Login")
                                })]
                            })
                        })]
                    })]
                })
            }
            const $ = {
                visible: {
                    y: 0
                },
                hidden: {
                    y: -160
                }
            }
        },
        61957: function(e, t, n) {
            "use strict";
            var r = n(75467),
                a = n(9850),
                o = n.n(a),
                i = n(98573),
                s = n.n(i);
            t.Z = function(e) {
                const {
                    style: t,
                    lineStyle: n,
                    className: a = "",
                    lineClassname: i,
                    mode: l = "dashed",
                    content: c,
                    textClassName: d
                } = e, p = (0, r.jsx)("div", {
                    style: n,
                    className: o()(i, s().line, {
                        [s().dashed]: "dashed" === l,
                        [s().solid]: "solid" === l
                    })
                });
                return (0, r.jsxs)("div", {
                    className: o()(a, s().divider),
                    style: { ...t
                    },
                    children: [p, c && (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)("div", {
                            className: o()(s().text, d),
                            children: c
                        }), p]
                    })]
                })
            }
        },
        29272: function(e) {
            e.exports = {
                "language-scroll": "Social_language-scroll__y_U1S"
            }
        },
        88896: function(e) {
            e.exports = {
                "secondary-btn": "Navigation_secondary-btn__cGeq8"
            }
        },
        98573: function(e) {
            e.exports = {
                divider: "Divider_divider__REh0v",
                text: "Divider_text__SHqGq",
                line: "Divider_line__wsAED",
                dashed: "Divider_dashed__9ImE3",
                solid: "Divider_solid__B9XmY"
            }
        }
    }
]);