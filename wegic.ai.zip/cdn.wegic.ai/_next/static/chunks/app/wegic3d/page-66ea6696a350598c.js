/*! For license information please see page-66ea6696a350598c.js.LICENSE.txt */ ! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "23eedae7-f86c-419f-bbdd-4ce8131fe45e", e._sentryDebugIdIdentifier = "sentry-dbid-23eedae7-f86c-419f-bbdd-4ce8131fe45e")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9527], {
        12605: function(e, n, t) {
            Promise.resolve().then(t.bind(t, 61336))
        },
        92296: function(e) {
            var n = {
                utf8: {
                    stringToBytes: function(e) {
                        return n.bin.stringToBytes(unescape(encodeURIComponent(e)))
                    },
                    bytesToString: function(e) {
                        return decodeURIComponent(escape(n.bin.bytesToString(e)))
                    }
                },
                bin: {
                    stringToBytes: function(e) {
                        for (var n = [], t = 0; t < e.length; t++) n.push(255 & e.charCodeAt(t));
                        return n
                    },
                    bytesToString: function(e) {
                        for (var n = [], t = 0; t < e.length; t++) n.push(String.fromCharCode(e[t]));
                        return n.join("")
                    }
                }
            };
            e.exports = n
        },
        10455: function(e) {
            var n, t;
            n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", t = {
                rotl: function(e, n) {
                    return e << n | e >>> 32 - n
                },
                rotr: function(e, n) {
                    return e << 32 - n | e >>> n
                },
                endian: function(e) {
                    if (e.constructor == Number) return 16711935 & t.rotl(e, 8) | 4278255360 & t.rotl(e, 24);
                    for (var n = 0; n < e.length; n++) e[n] = t.endian(e[n]);
                    return e
                },
                randomBytes: function(e) {
                    for (var n = []; e > 0; e--) n.push(Math.floor(256 * Math.random()));
                    return n
                },
                bytesToWords: function(e) {
                    for (var n = [], t = 0, o = 0; t < e.length; t++, o += 8) n[o >>> 5] |= e[t] << 24 - o % 32;
                    return n
                },
                wordsToBytes: function(e) {
                    for (var n = [], t = 0; t < 32 * e.length; t += 8) n.push(e[t >>> 5] >>> 24 - t % 32 & 255);
                    return n
                },
                bytesToHex: function(e) {
                    for (var n = [], t = 0; t < e.length; t++) n.push((e[t] >>> 4).toString(16)), n.push((15 & e[t]).toString(16));
                    return n.join("")
                },
                hexToBytes: function(e) {
                    for (var n = [], t = 0; t < e.length; t += 2) n.push(parseInt(e.substr(t, 2), 16));
                    return n
                },
                bytesToBase64: function(e) {
                    for (var t = [], o = 0; o < e.length; o += 3)
                        for (var r = e[o] << 16 | e[o + 1] << 8 | e[o + 2], i = 0; i < 4; i++) 8 * o + 6 * i <= 8 * e.length ? t.push(n.charAt(r >>> 6 * (3 - i) & 63)) : t.push("=");
                    return t.join("")
                },
                base64ToBytes: function(e) {
                    e = e.replace(/[^A-Z0-9+\/]/gi, "");
                    for (var t = [], o = 0, r = 0; o < e.length; r = ++o % 4) 0 != r && t.push((n.indexOf(e.charAt(o - 1)) & Math.pow(2, -2 * r + 8) - 1) << 2 * r | n.indexOf(e.charAt(o)) >>> 6 - 2 * r);
                    return t
                }
            }, e.exports = t
        },
        44494: function(e) {
            function n(e) {
                return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
            }
            e.exports = function(e) {
                return null != e && (n(e) || function(e) {
                    return "function" == typeof e.readFloatLE && "function" == typeof e.slice && n(e.slice(0, 0))
                }(e) || !!e._isBuffer)
            }
        },
        7083: function(e, n, t) {
            "use strict";
            t.d(n, {
                Z: function() {
                    return b
                }
            });
            var o = /iPhone/i,
                r = /iPod/i,
                i = /iPad/i,
                u = /\biOS-universal(?:.+)Mac\b/i,
                s = /\bAndroid(?:.+)Mobile\b/i,
                a = /Android/i,
                c = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i,
                l = /Silk/i,
                f = /Windows Phone/i,
                d = /\bWindows(?:.+)ARM\b/i,
                v = /BlackBerry/i,
                p = /BB10/i,
                m = /Opera Mini/i,
                g = /\b(CriOS|Chrome)(?:.+)Mobile/i,
                h = /Mobile(?:.+)Firefox\b/i,
                w = function(e) {
                    return void 0 !== e && "MacIntel" === e.platform && "number" == typeof e.maxTouchPoints && e.maxTouchPoints > 1 && "undefined" == typeof MSStream
                };

            function b(e) {
                var n = {
                    userAgent: "",
                    platform: "",
                    maxTouchPoints: 0
                };
                e || "undefined" == typeof navigator ? "string" == typeof e ? n.userAgent = e : e && e.userAgent && (n = {
                    userAgent: e.userAgent,
                    platform: e.platform,
                    maxTouchPoints: e.maxTouchPoints || 0
                }) : n = {
                    userAgent: navigator.userAgent,
                    platform: navigator.platform,
                    maxTouchPoints: navigator.maxTouchPoints || 0
                };
                var t = n.userAgent,
                    b = t.split("[FBAN");
                void 0 !== b[1] && (t = b[0]), void 0 !== (b = t.split("Twitter"))[1] && (t = b[0]);
                var y = function(e) {
                        return function(n) {
                            return n.test(e)
                        }
                    }(t),
                    A = {
                        apple: {
                            phone: y(o) && !y(f),
                            ipod: y(r),
                            tablet: !y(o) && (y(i) || w(n)) && !y(f),
                            universal: y(u),
                            device: (y(o) || y(r) || y(i) || y(u) || w(n)) && !y(f)
                        },
                        amazon: {
                            phone: y(c),
                            tablet: !y(c) && y(l),
                            device: y(c) || y(l)
                        },
                        android: {
                            phone: !y(f) && y(c) || !y(f) && y(s),
                            tablet: !y(f) && !y(c) && !y(s) && (y(l) || y(a)),
                            device: !y(f) && (y(c) || y(l) || y(s) || y(a)) || y(/\bokhttp\b/i)
                        },
                        windows: {
                            phone: y(f),
                            tablet: y(d),
                            device: y(f) || y(d)
                        },
                        other: {
                            blackberry: y(v),
                            blackberry10: y(p),
                            opera: y(m),
                            firefox: y(h),
                            chrome: y(g),
                            device: y(v) || y(p) || y(m) || y(h) || y(g)
                        },
                        any: !1,
                        phone: !1,
                        tablet: !1
                    };
                return A.any = A.apple.device || A.android.device || A.windows.device || A.other.device, A.phone = A.apple.phone || A.android.phone || A.windows.phone, A.tablet = A.apple.tablet || A.android.tablet || A.windows.tablet, A
            }
        },
        88654: function(e, n, t) {
            var o, r, i, u, s;
            o = t(10455), r = t(92296).utf8, i = t(44494), u = t(92296).bin, (s = function(e, n) {
                e.constructor == String ? e = n && "binary" === n.encoding ? u.stringToBytes(e) : r.stringToBytes(e) : i(e) ? e = Array.prototype.slice.call(e, 0) : Array.isArray(e) || e.constructor === Uint8Array || (e = e.toString());
                for (var t = o.bytesToWords(e), a = 8 * e.length, c = 1732584193, l = -271733879, f = -1732584194, d = 271733878, v = 0; v < t.length; v++) t[v] = 16711935 & (t[v] << 8 | t[v] >>> 24) | 4278255360 & (t[v] << 24 | t[v] >>> 8);
                t[a >>> 5] |= 128 << a % 32, t[14 + (a + 64 >>> 9 << 4)] = a;
                var p = s._ff,
                    m = s._gg,
                    g = s._hh,
                    h = s._ii;
                for (v = 0; v < t.length; v += 16) {
                    var w = c,
                        b = l,
                        y = f,
                        A = d;
                    c = p(c, l, f, d, t[v + 0], 7, -680876936), d = p(d, c, l, f, t[v + 1], 12, -389564586), f = p(f, d, c, l, t[v + 2], 17, 606105819), l = p(l, f, d, c, t[v + 3], 22, -1044525330), c = p(c, l, f, d, t[v + 4], 7, -176418897), d = p(d, c, l, f, t[v + 5], 12, 1200080426), f = p(f, d, c, l, t[v + 6], 17, -1473231341), l = p(l, f, d, c, t[v + 7], 22, -45705983), c = p(c, l, f, d, t[v + 8], 7, 1770035416), d = p(d, c, l, f, t[v + 9], 12, -1958414417), f = p(f, d, c, l, t[v + 10], 17, -42063), l = p(l, f, d, c, t[v + 11], 22, -1990404162), c = p(c, l, f, d, t[v + 12], 7, 1804603682), d = p(d, c, l, f, t[v + 13], 12, -40341101), f = p(f, d, c, l, t[v + 14], 17, -1502002290), c = m(c, l = p(l, f, d, c, t[v + 15], 22, 1236535329), f, d, t[v + 1], 5, -165796510), d = m(d, c, l, f, t[v + 6], 9, -1069501632), f = m(f, d, c, l, t[v + 11], 14, 643717713), l = m(l, f, d, c, t[v + 0], 20, -373897302), c = m(c, l, f, d, t[v + 5], 5, -701558691), d = m(d, c, l, f, t[v + 10], 9, 38016083), f = m(f, d, c, l, t[v + 15], 14, -660478335), l = m(l, f, d, c, t[v + 4], 20, -405537848), c = m(c, l, f, d, t[v + 9], 5, 568446438), d = m(d, c, l, f, t[v + 14], 9, -1019803690), f = m(f, d, c, l, t[v + 3], 14, -187363961), l = m(l, f, d, c, t[v + 8], 20, 1163531501), c = m(c, l, f, d, t[v + 13], 5, -1444681467), d = m(d, c, l, f, t[v + 2], 9, -51403784), f = m(f, d, c, l, t[v + 7], 14, 1735328473), c = g(c, l = m(l, f, d, c, t[v + 12], 20, -1926607734), f, d, t[v + 5], 4, -378558), d = g(d, c, l, f, t[v + 8], 11, -2022574463), f = g(f, d, c, l, t[v + 11], 16, 1839030562), l = g(l, f, d, c, t[v + 14], 23, -35309556), c = g(c, l, f, d, t[v + 1], 4, -1530992060), d = g(d, c, l, f, t[v + 4], 11, 1272893353), f = g(f, d, c, l, t[v + 7], 16, -155497632), l = g(l, f, d, c, t[v + 10], 23, -1094730640), c = g(c, l, f, d, t[v + 13], 4, 681279174), d = g(d, c, l, f, t[v + 0], 11, -358537222), f = g(f, d, c, l, t[v + 3], 16, -722521979), l = g(l, f, d, c, t[v + 6], 23, 76029189), c = g(c, l, f, d, t[v + 9], 4, -640364487), d = g(d, c, l, f, t[v + 12], 11, -421815835), f = g(f, d, c, l, t[v + 15], 16, 530742520), c = h(c, l = g(l, f, d, c, t[v + 2], 23, -995338651), f, d, t[v + 0], 6, -198630844), d = h(d, c, l, f, t[v + 7], 10, 1126891415), f = h(f, d, c, l, t[v + 14], 15, -1416354905), l = h(l, f, d, c, t[v + 5], 21, -57434055), c = h(c, l, f, d, t[v + 12], 6, 1700485571), d = h(d, c, l, f, t[v + 3], 10, -1894986606), f = h(f, d, c, l, t[v + 10], 15, -1051523), l = h(l, f, d, c, t[v + 1], 21, -2054922799), c = h(c, l, f, d, t[v + 8], 6, 1873313359), d = h(d, c, l, f, t[v + 15], 10, -30611744), f = h(f, d, c, l, t[v + 6], 15, -1560198380), l = h(l, f, d, c, t[v + 13], 21, 1309151649), c = h(c, l, f, d, t[v + 4], 6, -145523070), d = h(d, c, l, f, t[v + 11], 10, -1120210379), f = h(f, d, c, l, t[v + 2], 15, 718787259), l = h(l, f, d, c, t[v + 9], 21, -343485551), c = c + w >>> 0, l = l + b >>> 0, f = f + y >>> 0, d = d + A >>> 0
                }
                return o.endian([c, l, f, d])
            })._ff = function(e, n, t, o, r, i, u) {
                var s = e + (n & t | ~n & o) + (r >>> 0) + u;
                return (s << i | s >>> 32 - i) + n
            }, s._gg = function(e, n, t, o, r, i, u) {
                var s = e + (n & o | t & ~o) + (r >>> 0) + u;
                return (s << i | s >>> 32 - i) + n
            }, s._hh = function(e, n, t, o, r, i, u) {
                var s = e + (n ^ t ^ o) + (r >>> 0) + u;
                return (s << i | s >>> 32 - i) + n
            }, s._ii = function(e, n, t, o, r, i, u) {
                var s = e + (t ^ (n | ~o)) + (r >>> 0) + u;
                return (s << i | s >>> 32 - i) + n
            }, s._blocksize = 16, s._digestsize = 16, e.exports = function(e, n) {
                if (null == e) throw new Error("Illegal argument " + e);
                var t = o.wordsToBytes(s(e, n));
                return n && n.asBytes ? t : n && n.asString ? u.bytesToString(t) : o.bytesToHex(t)
            }
        },
        71527: function(e, n, t) {
            "use strict";
            var o = t(84371);
            var r = "function" == typeof Object.is ? Object.is : function(e, n) {
                    return e === n && (0 !== e || 1 / e == 1 / n) || e != e && n != n
                },
                i = o.useState,
                u = o.useEffect,
                s = o.useLayoutEffect,
                a = o.useDebugValue;

            function c(e) {
                var n = e.getSnapshot;
                e = e.value;
                try {
                    var t = n();
                    return !r(e, t)
                } catch (e) {
                    return !0
                }
            }
            var l = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, n) {
                return n()
            } : function(e, n) {
                var t = n(),
                    o = i({
                        inst: {
                            value: t,
                            getSnapshot: n
                        }
                    }),
                    r = o[0].inst,
                    l = o[1];
                return s((function() {
                    r.value = t, r.getSnapshot = n, c(r) && l({
                        inst: r
                    })
                }), [e, t, n]), u((function() {
                    return c(r) && l({
                        inst: r
                    }), e((function() {
                        c(r) && l({
                            inst: r
                        })
                    }))
                }), [e]), a(t), t
            };
            n.useSyncExternalStore = void 0 !== o.useSyncExternalStore ? o.useSyncExternalStore : l
        },
        59597: function(e, n, t) {
            "use strict";
            var o = t(84371),
                r = t(85960);
            var i = "function" == typeof Object.is ? Object.is : function(e, n) {
                    return e === n && (0 !== e || 1 / e == 1 / n) || e != e && n != n
                },
                u = r.useSyncExternalStore,
                s = o.useRef,
                a = o.useEffect,
                c = o.useMemo,
                l = o.useDebugValue;
            n.useSyncExternalStoreWithSelector = function(e, n, t, o, r) {
                var f = s(null);
                if (null === f.current) {
                    var d = {
                        hasValue: !1,
                        value: null
                    };
                    f.current = d
                } else d = f.current;
                f = c((function() {
                    function e(e) {
                        if (!a) {
                            if (a = !0, u = e, e = o(e), void 0 !== r && d.hasValue) {
                                var n = d.value;
                                if (r(n, e)) return s = n
                            }
                            return s = e
                        }
                        if (n = s, i(u, e)) return n;
                        var t = o(e);
                        return void 0 !== r && r(n, t) ? n : (u = e, s = t)
                    }
                    var u, s, a = !1,
                        c = void 0 === t ? null : t;
                    return [function() {
                        return e(n())
                    }, null === c ? void 0 : function() {
                        return e(c())
                    }]
                }), [n, t, o, r]);
                var v = u(e, f[0], f[1]);
                return a((function() {
                    d.hasValue = !0, d.value = v
                }), [v]), l(v), v
            }
        },
        85960: function(e, n, t) {
            "use strict";
            e.exports = t(71527)
        },
        67883: function(e, n, t) {
            "use strict";
            e.exports = t(59597)
        },
        61336: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, {
                default: function() {
                    return f
                }
            });
            var o = t(75467),
                r = t(84371),
                i = t(41678),
                u = {
                    src: "https://cdn.wegic.ai/_next/static/media/noise.fa7582c0.png",
                    height: 256,
                    width: 256,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAlklEQVR42hXJwXEDMQwDQACkfIWng2TSayxKQMavfSy/f36/KOiV11wcaXkwqreGRE83PIA8PsqiMnyiO/xw/iSoxYh+rnhwY1mIFAd51NDu3A5TpEByg1wsFFUjVQPM3cVMOrwWrvOGjS6mT5R0VXxAK4W6RpZp7AN3NgcwEfGT4b6W3FZsd1MCIfqCpmM83TEDHNSqf/zualYEsJ5zAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 8
                },
                s = {
                    src: "https://cdn.wegic.ai/_next/static/media/three-small.b950339c.png",
                    height: 2400,
                    width: 2400,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAR0lEQVR42mNgYGFgkGdlAAEzVwZ2UQYGXgaG1lkMDEBW3OY9j9YmMzAwNN7ZVHlvOgMDE4O2nUNjDgMMcDMwMHFzsIlzMAAApEILmp2EUVgAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 8
                },
                a = t(19697),
                c = "precision mediump float;\n\nuniform vec2 u_resolution; // 渲染的分辨率\nuniform float u_pxaspect;  // 像素的宽高比\nuniform vec2 u_mouse;      // 鼠标位置\nuniform float u_time;      // 当前时间，用于动画和效果变化\nuniform sampler2D u_noise; // 噪声纹理\nuniform sampler2D u_text500; // 另一种纹理\nuniform bool u_mousemoved; // 标记鼠标是否移动\n\n// 使用预计算的常量\nconst float PI = 3.141592653589793;\nconst float TAU = 6.283185307179586;\n\nconst bool addNoise = true; // 是否在光线上添加噪声\nconst float decay = 0.999; // 每个样本的衰减量\nconst float exposure = 0.08; // 屏幕曝光度\nconst float lightStrength = 5.5; // 光线强度\nconst vec3 lightcolour = vec3(0.95, 0.95, 0.95); // 光线颜色\nconst vec3 falloffcolour = vec3(0.6, 0.6, 0.6); // 光线衰减颜色\nconst vec3 bgcolour = vec3(0.10, 0.10, 0.10); // 渲染的基础颜色\nconst float falloff = 0.999; // 光线衰减\nconst int samples = 7; // 取样数量\nconst float density = 0.99; // “烟雾”的密度\nconst float weight = 0.7; // 在超级采样中每一步的权重\nconst int octaves = 1; // 在FBM噪声中生成的octaves数量\nconst float seed = 0.513; // 随机种子\n\nfloat random2d(vec2 uv) {\n    // 使用简单的哈希函数代替纹理采样，减少性能消耗\n    return fract(sin(dot(uv.xy, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\n// Value Noise by Inigo Quilez - iq/2013\n// https://www.shadertoy.com/view/lsf3WH\nfloat noise(vec2 st, float seed) {\n    vec3 x = vec3(st, 1.0);\n    vec3 p = floor(x);\n    vec3 f = fract(x);\n    f = f * f * (3.0 - 2.0 * f);\n    vec2 uv = (p.xy + vec2(37.0, 17.0) * p.z) + f.xy;\n    vec2 rg = texture2D(u_noise, (uv + 0.5) / 256.0, 0.0).yx - 0.5;\n    return mix(rg.x, rg.y, f.z);\n}\n\nfloat fbm1(vec2 _st, float seed) {\n    return 0.5 * noise(_st, seed) + 0.4;\n}\n\nfloat pattern(vec2 uv, float seed, float time, out vec2 q, out vec2 r) {\n    q = vec2(fbm1(uv, seed), fbm1(uv + vec2(5.2, 1.3), seed));\n    r = vec2(fbm1(uv + 4.0 * q + vec2(1.7 - time * 0.5, 9.2), seed), fbm1(uv + 4.0 * q + vec2(8.3 - time * 0.5, 2.8), seed));\n    return fbm1(uv + 4.0 * r, seed);\n}\n\nfloat shapes(vec2 uv, vec2 res) {\n    uv += u_mouse * 0.1;\n    float aspect = res.x / res.y;\n    float scale = 1.2 / aspect * 0.3;\n    return texture2D(u_text500, uv * scale + 0.5, -1.0).x;\n}\n\nfloat occlusion(vec2 uv, vec2 lightpos, float objects) {\n    float dist = length(lightpos - uv);\n    return (1.0 - smoothstep(0.0, lightStrength, dist)) * (1.0 - objects);\n}\n\nvec4 mainRender(vec2 uv, inout vec4 fragcolour, vec2 res) {\n    float scale = 4.0;\n    uv *= scale;\n\n    float exposure = exposure + (sin(u_time) * .5 + 1.) * .05;\n    float timeFactor = u_time * 20.0;\n    float sinTimeHalf = sin(u_time * 0.5);\n\n    vec2 _uv = uv;\n    vec2 lightpos = (vec2(u_mouse.x, u_mouse.y * -1.)) / u_resolution.y;\n    lightpos = u_mouse * scale;\n\n    float obj = shapes(uv, res);\n    float map = occlusion(uv, lightpos, obj);\n\n    vec2 q, r;\n    float _pattern = addNoise ? pattern(uv * 3.0, seed, u_time, q, r) * 0.5 : 0.0;\n\n    vec2 dtc = (_uv - lightpos) * (1.0 / float(samples) * density);\n    float illumination_decay = 1.0;\n    vec3 basecolour = bgcolour;\n\n    for(int i = 0; i < samples; i++) {\n        _uv -= dtc;\n        if(addNoise) {\n            uv += _pattern / 30.0;\n        }\n\n        float movement = timeFactor * float(i + 1);\n\n        float dither = random2d(uv * 512. + mod(vec2(movement * sinTimeHalf, -movement), 1000.0)) * 2.0;\n\n        float stepped_map = occlusion(uv, lightpos, shapes(_uv + dtc * dither, res));\n        stepped_map *= illumination_decay * weight;\n        illumination_decay *= decay;\n\n        map += stepped_map;\n    }\n\n    float l = length(lightpos - uv);\n\n    vec3 lightcolour = mix(lightcolour, falloffcolour, l * falloff);\n\n    vec3 colour = vec3(basecolour + map * exposure * lightcolour);\n\n    fragcolour = vec4(colour, 1.0);\n    return fragcolour;\n}\n\nvoid main() {\n    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.y, u_resolution.x);\n    vec2 res = u_resolution / u_pxaspect;\n\n    mainRender(uv, gl_FragColor, res);\n}";
            const l = "\nvoid main() {\n  gl_Position = vec4( position, 1.0 );\n}\n";

            function f() {
                const e = (0, r.useRef)(null),
                    [n] = (0, r.useState)((0, a.W7)());
                return (0, r.useEffect)((() => {
                    let n, t, o, r;
                    const a = new i.dpR;
                    let f, d, v, p, m, g, h = null,
                        w = null;
                    const b = () => {
                            null === h && (h = window.requestAnimationFrame((() => {
                                if (h = null, !o || !f) return;
                                const e = window.innerWidth,
                                    n = window.innerHeight;
                                o.setSize(e, n), f.u_resolution.value.x = o.domElement.width, f.u_resolution.value.y = o.domElement.height
                            })))
                        },
                        y = e => {
                            null === w && (w = window.requestAnimationFrame((() => {
                                if (w = null, !f) return;
                                const n = window.innerHeight / window.innerWidth;
                                f.u_mouse.value.x = (e.pageX - window.innerWidth / 2) / window.innerWidth / n, f.u_mouse.value.y = (e.pageY - window.innerHeight / 2) / window.innerHeight * -1
                            })), e.preventDefault())
                        },
                        A = () => {
                            f.u_time.value = r.getElapsedTime(), o.render(t, n)
                        };
                    return a.setCrossOrigin("anonymous"), Promise.all([new Promise((e => {
                        a.load(u.src, (n => {
                            n.wrapS = i.rpg, n.wrapT = i.rpg, n.minFilter = i.wem, e(n)
                        }))
                    })), new Promise((e => {
                        a.load(s.src, (n => {
                            e(n)
                        }))
                    }))]).then((u => {
                        let [s, a] = u;
                        var h;
                        d = s, v = a, n = new i.V1s, n.position.z = 1, t = new i.xsS, p = new i._12(2, 2), f = {
                            u_time: {
                                value: 1
                            },
                            u_resolution: {
                                value: new i.FM8
                            },
                            u_pxaspect: {
                                value: window.devicePixelRatio
                            },
                            u_noise: {
                                value: d
                            },
                            u_text500: {
                                value: v
                            },
                            u_mouse: {
                                value: new i.FM8(-.1, -.1)
                            }
                        }, m = new i.jyz({
                            uniforms: f,
                            vertexShader: l,
                            fragmentShader: c
                        }), g = new i.Kj0(p, m), t.add(g), o = new i.CP7({
                            antialias: !1
                        }), o.setPixelRatio(Math.min(window.devicePixelRatio, 2)), e.current && e.current.appendChild(o.domElement), b(), window.addEventListener("resize", b, !1), null === (h = e.current) || void 0 === h || h.addEventListener("pointermove", y), r = new i.SUY, o.setAnimationLoop(A)
                    })), () => {
                        var n, r;
                        (null !== h && window.cancelAnimationFrame(h), null !== w && window.cancelAnimationFrame(w), window.removeEventListener("resize", b), null === (n = e.current) || void 0 === n || n.removeEventListener("pointermove", y), null == o ? void 0 : o.domElement) && (null === (r = e.current) || void 0 === r || r.removeChild(o.domElement));
                        p && p.dispose(), m && m.dispose(), d && d.dispose(), v && v.dispose(), g && t.remove(g), o && o.dispose()
                    }
                }), []), (0, o.jsx)("div", {
                    onClick: () => {
                        window.parent.dispatchEvent(new CustomEvent("socialClose"))
                    },
                    ref: e,
                    className: "bg-[#000000] overflow-hidden fixed ".concat(n ? " scale-[2]" : "")
                })
            }
        },
        761: function(e, n, t) {
            "use strict";
            t.d(n, {
                L: function() {
                    return i
                }
            });
            var o = t(1435);
            const r = {
                    notLogin: !1,
                    isLogin: !1,
                    email: "",
                    password: "",
                    unionId: "",
                    userId: "",
                    userImage: "",
                    userName: "",
                    inviteCode: "",
                    countryBlock: !1,
                    freeRightBlock: !1,
                    isRenew: !1,
                    discount: 1.2,
                    isSupportRefund: !1
                },
                i = (0, o.Ue)(((e, n) => ({ ...r,
                    setIsLogin(n) {
                        e({
                            isLogin: n
                        })
                    },
                    setNotLogin(n) {
                        e({
                            notLogin: n
                        })
                    },
                    setUserInfo(t) {
                        const {
                            setIsLogin: o,
                            setNotLogin: r
                        } = n();
                        e(t), t.userId && (o(!0), r(!1), e({
                            password: ""
                        }))
                    },
                    getUserInfo() {
                        const {
                            email: e,
                            unionId: t,
                            userId: o,
                            userImage: r,
                            userName: i,
                            inviteCode: u,
                            countryBlock: s,
                            freeRightBlock: a
                        } = n();
                        return {
                            email: e,
                            unionId: t,
                            userId: o,
                            userImage: r,
                            userName: i,
                            inviteCode: u,
                            countryBlock: s,
                            freeRightBlock: a
                        }
                    },
                    userSubscription: void 0,
                    setUserSubscription(n) {
                        e({
                            userSubscription: n
                        })
                    },
                    setIsRenew(n) {
                        e({
                            isRenew: n
                        })
                    },
                    isUnlimitedUser: !1,
                    setIsUnlimitedUser(n) {
                        e({
                            isUnlimitedUser: n
                        })
                    },
                    duration: {
                        updateTime: Date.now(),
                        leftTime: 864e5
                    },
                    setDuration: n => {
                        e({
                            duration: {
                                updateTime: Date.now(),
                                leftTime: n
                            }
                        })
                    },
                    setIsSupportRefund(n) {
                        e({
                            isSupportRefund: n
                        })
                    }
                })))
        },
        19697: function(e, n, t) {
            "use strict";
            t.d(n, {
                W7: function() {
                    return c
                },
                bL: function() {
                    return l
                },
                gw: function() {
                    return a
                }
            });
            var o = t(21556),
                r = t(7083),
                i = t(88654),
                u = t.n(i),
                s = t(761);

            function a(e) {
                return new Promise((n => setTimeout(n, e)))
            }

            function c() {
                const e = (0, r.Z)();
                return e.phone || e.tablet
            }

            function l() {
                const {
                    userId: e,
                    email: n
                } = s.L.getState();
                e ? o.av({
                    id: e,
                    email: u()(n)
                }) : o.av({
                    id: "anonymous",
                    email: "anonymous"
                })
            }
        },
        1435: function(e, n, t) {
            "use strict";
            t.d(n, {
                Ue: function() {
                    return d
                }
            });
            const o = e => {
                    let n;
                    const t = new Set,
                        o = (e, o) => {
                            const r = "function" == typeof e ? e(n) : e;
                            if (!Object.is(r, n)) {
                                const e = n;
                                n = (null != o ? o : "object" != typeof r || null === r) ? r : Object.assign({}, n, r), t.forEach((t => t(n, e)))
                            }
                        },
                        r = () => n,
                        i = {
                            setState: o,
                            getState: r,
                            getInitialState: () => u,
                            subscribe: e => (t.add(e), () => t.delete(e)),
                            destroy: () => {
                                t.clear()
                            }
                        },
                        u = n = e(o, r, i);
                    return i
                },
                r = e => e ? o(e) : o;
            var i = t(84371),
                u = t(67883);
            const {
                useDebugValue: s
            } = i, {
                useSyncExternalStoreWithSelector: a
            } = u;
            let c = !1;
            const l = e => e;
            const f = e => {
                    const n = "function" == typeof e ? r(e) : e,
                        t = (e, t) => function(e, n = l, t) {
                            t && !c && (c = !0);
                            const o = a(e.subscribe, e.getState, e.getServerState || e.getInitialState, n, t);
                            return s(o), o
                        }(n, e, t);
                    return Object.assign(t, n), t
                },
                d = e => e ? f(e) : f
        }
    },
    function(e) {
        e.O(0, [1492, 9775, 8741, 8193, 1744], (function() {
            return n = 12605, e(e.s = n);
            var n
        }));
        var n = e.O();
        _N_E = n
    }
]);