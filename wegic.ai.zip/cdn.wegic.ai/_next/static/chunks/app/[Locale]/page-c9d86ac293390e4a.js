! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "b670438d-452b-4f4d-8eb7-cdae2e663690", e._sentryDebugIdIdentifier = "sentry-dbid-b670438d-452b-4f4d-8eb7-cdae2e663690")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5690], {
        96430: function(e, t, a) {
            "use strict";
            var i, s = a(52818);

            function A() {
                return A = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, A.apply(this, arguments)
            }
            t.Z = function(e) {
                return s.createElement("svg", A({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 20,
                    height: 20,
                    fill: "currentColor",
                    viewBox: "0 0 20 20"
                }, e), i || (i = s.createElement("path", {
                    d: "M2.625 13.125c0-.31.126-.592.33-.796l6.25-6.25c.439-.439 1.151-.439 1.59 0l6.236 6.237a1.125 1.125 0 1 1-1.577 1.605L10 8.465l-5.455 5.455a1.125 1.125 0 0 1-1.92-.796"
                })))
            }
        },
        97788: function(e, t, a) {
            Promise.resolve().then(a.bind(a, 13973)), Promise.resolve().then(a.bind(a, 85671)), Promise.resolve().then(a.bind(a, 77142))
        },
        77142: function(e, t, a) {
            "use strict";
            a.d(t, {
                default: function() {
                    return ds
                }
            });
            var i, s = a(75467),
                A = a(84956),
                o = a(29172),
                r = a(42140),
                n = a(76996),
                x = a(84371),
                l = a(9850),
                c = a.n(l),
                d = a(29069),
                k = a.n(d),
                g = a(99667),
                p = a(18562),
                y = a(52818);

            function u() {
                return u = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, u.apply(this, arguments)
            }
            var h = function(e) {
                    return y.createElement("svg", u({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 14.469,
                        height: 16,
                        fill: "none",
                        viewBox: "0 0 14.469 16"
                    }, e), i || (i = y.createElement("path", {
                        fill: "currentcolor",
                        d: "m13.313 10.003-9.844 5.684C1.927 16.577 0 15.464 0 13.684V2.316C0 .536 1.927-.577 3.47.313l9.844 5.684c1.541.89 1.541 3.116 0 4.006"
                    })))
                },
                m = JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":140,"w":320,"h":160,"nm":"Comp 1","ddd":0,"assets":[{"id":"0","layers":[{"ddd":0,"ind":1,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":1,"k":[{"t":15,"s":[10091.5,10154],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":35,"s":[10091.5,10019.66665649414],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":55,"s":[10091.5,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":100,"s":[10091.5,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":120,"s":[10091.5,10149],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":35,"s":[45],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}},{"t":100,"s":[45],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0,"parent":1},{"ddd":0,"ind":3,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":35,"s":[100,100],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}},{"t":100,"s":[100,100],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0,"parent":2},{"ddd":0,"refId":"1","ind":4,"ty":2,"nm":"拼合图形.png 1","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[94,90],"ix":2},"s":{"a":0,"k":[50,50],"ix":2},"r":{"a":1,"k":[{"t":35,"s":[-45],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}},{"t":100,"s":[-45],"i":{"x":[0],"y":[0]},"o":{"x":[0],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0,"parent":3},{"ddd":0,"refId":"2","ind":5,"ty":2,"nm":"矩形 7.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":7,"s":[10000.5,10154],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":27,"s":[10000,10011],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":47,"s":[10000.075469970703,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":100,"s":[10000.075469970703,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":120,"s":[10000.5,10149],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[57,90],"ix":2},"s":{"a":0,"k":[50,50],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0},{"ddd":0,"refId":"3","ind":6,"ty":2,"nm":"矩形 5.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":0,"s":[9906.5,10154],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":20,"s":[9907,10002],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":40,"s":[9906.5,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":100,"s":[9906.5,10025.125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":120,"s":[9906.5,10149],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[90,90],"ix":2},"s":{"a":0,"k":[50,50],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0}]},{"id":"4","layers":[{"ddd":0,"ind":7,"ty":4,"nm":"Shape Layer 1","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[320,160],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[1,0.8392156862745098,0.25098039215686274],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":141,"st":0,"bm":0},{"ddd":0,"refId":"0","w":20000,"h":20000,"ind":8,"ty":0,"nm":"Masked Group 1","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[10000,10000],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0,"tt":1}]},{"id":"1","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALwAAAC0CAYAAAAuGkbGAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAACAASURBVHic7X1Llx3HceYXWXW7Qc0sRULybxhCsxvPbkyBktcmfoJIyscWKVg63onnmN6KA5LW2ASofyDI2zFEgPaZzci7IfAfzAEhL0cE+lZlzCIzMiPyUbduPyAA3dGn+lblq7Kyvoz6MvJFuJAzlY8f3rsl58Mw/LEDMMC9Km5b+AdyPs/zb2c//eb6t79/+yln89wI/aEz8KLJhw/v3XIALg3jmwClAuYd8cpwW8wPjvzR+5iBiwpwenIB+FOSjx/euyUgF2FwBHD+zwXyKQaXWBT/tGwxPzjaHr1/AfyTywXgTygfPrx366Vh82bW0OHPcz5ncAI6N3S9ANxRhjuBQGQrwNbPD47mC+CfRC4Af0z56NHnNy/R8BaBDMg9PJgZHvG8qACApTcU/xME8ICDgwOBiOBA6VzCbv38YHsB/GPJBeD3lBtf3rm2GQ7e27jhVYDhOQB6juceHjMHqHv4AHxmMDME8hn2os0BwMFR1vIDHFwCvMNA4ddR/iI85vnWuy+/9vYfohyeV7kA/B4iWl0oigB95jn+eszwmJnhE+gD2NmA3YqAnshFgCP8ksNADgMcxug3SBgKsWbm+0fTk7+90Pbr5ALwK+WjR3dvHtL4VgvoE8+YOFx7MGb4pPkF9ACilg8iZwQApHg7EAkNMBBhwICBCCMNFfAHuNTofTxvr/348uu/fnol8nzKBeBXyC8eff7FSO6KcPSZPSZ4A/QpURmPGQBzgLmvqExbHIBEcYgMnXFEGOHC4QaMiJo/gt7FBu4Tnm69+/LVC4qzIBeA3yG/ePT5FwPcFQYnUG95xsQR8NEtaHXh7OEXyJYaOW+L5vJBz0sFcJRpzEAOGwwYo8YfKYNfaM6Tebr17uUL0PfkAvAd+eDhZ28cuuE9B3el1OpbnrFlcZsroAuJ8VwDvYQ8mfMIeWWOFPBnPk8YyWFEAPyGXAK/WHSO/AXoe3IB+IZ8+PCzNw6Hze1gXuSgzeGx9TO2PGFCBDxC41SsMpwaqGjq9Q6Dr0CvO6GCVcYZ4GfAh/MDGiPoM8V57Kdb1y9AX8kF4AvRYJcGqVCYI54j2OcActHs0fbOQAI+oOzuC51OgBqAQNYurzuhBPjaejOCopYfsMGAAzdegH6HXABeyQcPP3vjJbe5zdHSInz9iINm3yarjM9mx9g4zX2qSD2r5cCCPoMP/7VmB0pqI8AXO3201GjA04CNC9cODgOAGf7+X7783e+cVZk9b3IB+Cg3Ht69ecmNb4lZceJIYTBFzh5ojI/0hlWnk1dAB8MAH1gGPKkzMm7tIQbBbEmgyOeHyOE3sUEbQD9ixBA5PzCD7//ly69dgB4XgAfQBvuRn7DFnMA+RVoTOpICfzeanUstDySQMwz0a4lgJ8vqS1ojwHfSmCUHB0TrTTBZHmAMGt8FrS8WnAl8/50L0F8APoB9eMsDmBEozNZHGpP4egD7HMGeelA7QM+aHliiMqUYbd/j85QBT0AaghA4vcPGDRgx4oAGHLghNW4dCP5C059vwH/46PNPDkFvW7BPOGIfqUwwQ87KIuMVvH1hkSkpTZbdoKfiLIGdtJZX1EZp+zTWRoE+0Juo7SmD/rxr+nML+D7YZxxhxuSDRWZKjdOs1fP4GAt23VBdNkeW0jJPhv9t4OvRlbZHVjR9oDcW9GGogjvXoD+XgP/w0eefHCiwTzwHzs4zjjBh8j6DnQOvD0CHGggWryut3oL8+hlPJfgJBZ8vLTeK4gzGZOmSyfKABmwi8MdzDvpzB/hdYN9GsM8K7JqvZ0ojWr0GeDXufQ87vPoxYNdcHonOZPBrc6UeZbkxoNf0xmE+h6A/V4DfB+wzy3j2Pl/PYG9YZsLpHk3WIALocK7cil9NcVIjNmr7IZotpRNqJBdBP8YOqvML+nMD+B7YgzUmgH0bx8Usg11bZjq29gWgL9vitVsJ/HKAGRLIU6dUBXrCiAGOXLDTi6bHeG5Bfy4Af1yw68kbwtdtD2pjHCTvx91LKV9IpjDqGm37vAW9mkQSR1QaelOB3t9/5xz0yL7wgF8LduHsxwb7XkBfGjNZu5Tafh3okUZPumiSHBWP16AXvj/B33/3BQf9Cw34fcGerTEMZjtkYImv65lMQAnnk+l4A3zqNGKRQe8aoCfkMfWBz48G9BuXR1q+6Jr+hQX8scHeGB9Tg11ZZlaCfb1ZcvnKUpwa9E5perHV16DPmn5DcTiCAv2LrOlfSMCfBdhrKtOeo7r7qi/tl9HqlFoGvdbsLdAvcfrhBdf07g+dgdOW5xXs/bD1sLPWWB1jRyrG9+he4ryygk8D46Rsjvyc5uUOcFc+enTviz2y/1zIC6XhZbjAjBOC3SyrsRbsy+Mhjyu9HthwXltwdHN2l6ZvcnoKA89eVOvNC6PhTw3sWAA7L4P9bCVXKNOzy/Za53iXppfpizK55YjzcGgxz45wVz589PknT+EBn4q8EBr+g4efvfENN972QJpoXfag9sCuRz+WHUrrzI5no9lLKTW9PmuZLY+r6bOW15qecAS++eOXX/vhGT/mmctzr+FlWt5xwG60+QnA/nSlvrtoeqjrJU2vxwR5o+l9GBrNM6ao9WW06AHo7RdB0z/XgC/noPbA7vfk7Ptq9qdFaJaq3C564zXIYyWQDjYB/RxndtX0JkxWfxFA/9xSmhLsdjz77uECPWvMWrDnBuwZPWAxgKxwrq5KetNryGo7fatHVpb026jx9DLScqABDniu6c1zCfh9wd7tQV2h2fO5SDjzWIn0XrAVJU+tQNHJlQ7ogb4cdLYM+oGyLV5Af0hjsOS4UBkGAE+eU9A/l5RmF9inQrM3wY4a7PLpZ5YlrqHiZBLEHOnDmgOdY1V8hp5w0r63+tqkX01v8nNqemOeqKA3YqsPqzbkZUomnoMNH8Ah6O0bD+/efFrv/LTkudPwHz+698UAd6U1LW8bp+XNuzS7ojE+gcP6AUig0XYYrbC5OjkF6VCZKkg1Zl7pfFKDzPaiNzK0OE8X1KshhInhY6I9Awhf++nWXz1Hiz09V4D/6NG9L8YI9tBAnXHEUxPsS5zd+1LLZ+oi60HGy/ibOU2J7bMxSjbJjAGvclIVwI6iBMKAMzoF0IeJ4Rb0Y1zW+2s/XfvJc7JU93MD+A8fff7JBvS2T5rd4wgTjnhKYNdzUO3kDcbMWXub5fA4DP+VcyBTDqSrBmfn5umpCFUn2aHhpDi6CqM4vJNRlpQB3xtw1gf9gI1zBvSbqOkJhK/942s/ufynzzzoxz90BtbIh4/ufnIAelsWSZrYB63O8yLYZ+YEaLP+o1rVN3Fqn2Hro69W60ugPhVqoyhKLz2SaqpQT0wmGBGDQSnPLn7liAjgkDqD4IhBMUVmAkgqNuA4BJ3hAXbBlcRzDkE9ECfVxrmzm/cAPPOAf+Y1/I1Hdz85xPC2B6cVwJ5wHDIQVwcrwe4Tbck7cLBXqwwAqbEGZGtNOI9uPc7eAXXLeLmf1GNlSu+Wn+bzACLJyBG09nek3UJImR3Vmi5Y7jclqxYbk6Vay3Jmf/+dV57tcTfPNOA/+Ld/euOlzeFtPebjiCNvjxaEiecE9jnRl7jAKXNcLaxuoIoWT1YP1Hb20sbe5OunSG2oe9Fm9VSFKRu0uSHrxE1ATRKiGH5AGfC0APoDN5hhCJtoyjzCfPPHL199Zs2VzyzgP/i3f3rj0ubwNkewTxHoot3T7htezGixoapMianBylqz+24DlZUKl0atCYBlUB+L2qywyhh/dVJWECrCB0wXDVlC5vTIFcBpjZ/catAPhtNnG/2B2pRh+wyD/pkEfAD7we20KljciEC0+zaCfes9WK/mq2jLHGlM0uzgqoEq+DbWGNTuWpZoTdurF7juMOoF61KZ4kS7aSqjB5cJ5SFnO6Sk4Zr2hFUTwQX0elk/Af2BGyPog8YfaMAAemY1/TPZ8TSOm595IExSENOjHt8Bj0mDnRneIzZOo2XGizXGAywjI4N4H/k7q4WVODZqpUMnhi07gzL9sZ1BcoDt9c5OpfIo/1pxoY6Ur04cyWu8TuOIYhn4WIM95+HDPpZFOf5G9p6dmdMWQFulhLacv7YbDG/feHT3mRt388xp+I++uvt/iOg7M+fdN56wXqNdbO1qA2C2y+Al0KsxMh4IYE09k6yArWlMuix8qp9F4e4FrJVlRzptE+VuOpOpkrXJi1cyXZJL16SpDEmDNmyNKevcpDVv4DC6wNsPKK9hKb9DXMr78fbo2k/+6NkxV/7BzJI//91nf+aYX/eA2AHhvQcD35n8nIYNaM0+c1jkVBqxYmcXji78nH3uTJKGKhA2HQMQNbuIstagBngP3GsGjXWDRA9aCiMBGolZ8ySBdD6pDM8Z3cwwtSMUVmzRBn+mkCtigmOGdx6OXTBtqvQHeMzRNLltPASDMZLD4ebgNp4hxfrUMhLGXTAOh/GtAFCfP6eQ66CdZdNfscQEW7vH5GczZGBOHF3GuKhPNpA6ktIaMyWwk7+4ognyFm/nxlkLvS1AL5ke9UUzXIPTk/pnNH3xJZFrsd445S8mS+Hs+RxwzlptHKmOKRCci41YNYlkjNvwDDFu2DF8et8dDPzTb77+j70iOGs5U8DL4KJLw/gWJ57oa17o8+ZgYVx23HIGc1zJd8LkOQ0ZsA1SnxqjqRc1cVefBkZlLS+5s7Z3Dcw2rYlny/g+VdlpmUHbNFmBXzVirT/ZiqCGIbhUKdQsKTVTSiqBi2NqAuidWgIkb62p95EV8BOA2dHfXP/ma08V/GcC+I8efX7zkIa3hFh4FrCK6VC2ZxeAy9gXqRA+Aj1u7+4DyGfFzYW+iO3dp4abALxYzlo19gBf0JoF7r7A21ua/7SkBHJyT//CyZJG1zxeHC3ww5lT8bWdXkCfOqeIMGgzZqwEQwJ9ON9EoMsirrIsiOwzmyoOESbm+0fT9m9/+u3v3z5Bca2WUwX83z36/OYBDW+J5p191sieBbRzdJeeUV9ofqSlIiYO2l/b2GU5PNHcweJQWk2UdULaBwAE+YJRsXJAXQvI19Aa67RHi7aUsgVaOolPS5unk1qjF94pRDmYTOiLBBY7vV3UKZouxTxJJehlPH1eqntM53mRpyF2Xg0Y4jidkPbk5wc/euW7V/Ytun3l1AD/8cN7tw6G8U1EjT3znDU0ZKvHOfJzNQyAhdwg9YrOPnJ0xemzmTGv5itj1lt2dm96UOVccXaDzw7Im7x9f4vNvlLjv1EJupaZ3Vq/Bn7W6uLnIsEXzd4CvXwFAo9HojjC68d4NaSlu6P9vqoELnVufT1vz3Rv2RMD/uOH924dDuObWqvL8F2ZVK3ttl4BXe9xOkdtLFQl74OKOERAaEgEu+Lw2j1o7QxwbXoULW2sMSV/X+DuPXCvsdislkajNDqrk7VmSW2SVP7x3Cnga9Cnc9U55RL9iUDX3D6mNKTGrctmzKT9A+hdHG4s+8uOcUlv+TIQCE94vvXuy6+dCehPBPiSwkye48jFOY59kQ3B5szBfeoOEn1tOj302HXfapjGipG+CxrsCeTiHoQVYFtA13RlF3dvgZt7V7sqQt0qbb+QE1hmesDXfi7dI2t1ubYNWaE/zoy9MXtNxV7aIaZsBqEpujMQBa4fN2DbxB7awYWvwuSnB395BhTn2IDXmn2Gx+xnHLFPW7MH0AfO7hFoStbCst8pLMi1tUVRlZrCBChrs6YAH8zG6mLGuIOtBl/B39uN2Ry2dj+ZlJrcuIlXi8svafT4T1cNDXxNZaRzqgd6M9Asghkkmj6AfEjhxZJDaSPlAHy1+ZrZimcI2j+B3j94PB+9f5oN2mN1PH388N6tS8P4Zur+l+UdEGznMvdxgo+NTgXyRDP0fEqvbOjZli7WF2mYApbCANnM6OHF+JK0vdAYLoBsgb4W5H2t34pzHCFSSbQSFJRyIw4DBA5D3pET0v4xEAgE5uwXzsP4ePHwQBj3TuEdiXYP5UDwxHAI5U+IX1MCCGEMvUNo9Pp4a8c++juAw/3Z2fm1HNNA7NDaOPfqxl36FU6xrbl3Qh8/unfrEgWwe8jALjWnNI518arrfxZdrYEM0eRZs2eKIjw+XutCSec1hanBXmr7/BxNoK/Q+GU4476Ha6vom9y9pc2Vh/4ikA6zk8O3aU7W9kqrC/VR4+mlMSsDE9LgMydUJlMdPeY+UxyXKEzafC0OO97QmObShr1l/YO/+OafnAq92QvwN768c+0/bC79SmiMgF00+xEHtj6xjE0X6lLMKYVqoBptnalNMi0q23ruOUWTwuSeVKFCOe+6l1WbJiu/lSDnhsdJFHzZCF1DZzT4Wzx+DYfXFhtxb4I+ejpyFeiNBUeBPjdqLcWRSpDt93FD5QT6uLesAv0Rz7d+dAoN2b1GSx5sDt8T8M1xOYwtvAV7WnJ5Th1FeqSd5zBSb5bzqInFkqPHr/sC7OFcvgwe8BJWg1ZGR8Zrhq082g6v/YrKY/zN14PtgexXxVl5QKWRvlws+VGf+115aj1X/Ce+Nl75tUT8smalod3D19arXm4oZZbftfS/aDe92pu8zzn20QQs+aQ8t2oIuLCEAxre+vDhvVv74LUlqzV84O2bN0OHkE+jGGXlgClpdl8saae0egJzpiwM2FUEuHwB3oK3S2EE7C13q7WXNDpnj0qL79L6yX1toUbpvYRVwwbQ0Ppa41dUp6ftrbumMtJQBYrGrJNe1+Dm4OJv7pkV02RrT1npbRWz5aA0/QGNOFQbKg9xVOfX09GnP/7W628tl2hfVjVab3x159olN76pNfGULDGxgVoufKRqdGqkKo0t9vUWsLP1JVtVckcSRzoTJGtk36A2MPTFgrldCXQ8FbwKU/odl9pQGV5xc32/qvGpwupLnXdQHkkpfsShYVs2XEt3ab86iuXHAfR5knd4CUz5Pp48iB18nBDu0pfCgYngwKndS/GEmAAKE8XJA5MLjeU0zkdVuDDN8GRTOFbFPnCH74X2t3QgyacnDvCCgH2uPl/C0cPwgDhAzMNSlwj2rPXriiJgZ84tf/EH+wzyHtij2g/x7Kfa0AqhEvoeXIepJnsgp4ci3uKB4uhRpk4+Wnm1z885P0W5ceGeFIouk+ghZQ/kNlRSGuarnBVPev8yuQbyvrOhQr7Yup8mdVzGzkpNfy8N45snoTY7AX/jyzvXNnCvaj42McfRi3E0jBeGXnB2xe8CUL1aTUA/vDpXhZCG9DJUuOJlpoLLJsrEx6FfWsfdVII+eHq8vQdk6DCdA534KU9QoN6Rt/K59NfOTGfUQNbuqVwt6HO5ynsMfh7tewjQTfsr5tGYmxXoS04/yWBBxSRmFiQBLw2bN3fAtis7AX+wOXwPMVOGykjvqRrJmDWHBqcA31cPqH+T5UUaRaowxVwpLzRpNc5jZzSo7YvQgG24NypBE+hogzSFS+686kDlVlQILvPZAP9CXm2ZSJlxxx2pMqR0y7CcYiTQS/npZ/c+lWqaJG960RVGsjFCn2dTtrCIrOWDH4FxXC2/CPgbX1ntPoOrz40MFDCmR7ZzIVNhSA1PBaoA6zV1yYVstY5+2W0Nbl9Q8VJb7kUlEL+u5aMAYD0fVWnLMp7cowR3yntdAXr3XgI+dF52AblTPijCBgBbjQ2VJus0ixlnEt6anAttL+dSAXwYdTVzWJkim7pFy4/H0vKLgD9wh++FRlUc3huBnobrpokbaGZeACj2dlZhpeEKIGqFUMqanogeKQv+5GDnbiVYNl2i1rIxYgvYCTzI8fN9+uHrCtAAv36+AvgJfK1nZJjwvXJKz1VUEHGTPErtzW8p3t/n95/fa9b8GQ9aWQR/Pfdhjtp9RubyjND4vfHlnWvYUxYBH7Q7EieXob0+gT5rd/OS0oPlwpWaDs6DvkTrI8W1LwcxbSBXAFOwK8GetZsAugBdcu8AXcBTpldWBuNuNbZ41PSmFx+CJQv+Vv7Us/bKoFs2vbDJDV03q0CQ3nkKq94doJRfeo+2PHNve8BVsutzsO3PrE3dhMGN38Oe0jVL3vj3O9eC5SloYqEz0rBgH23pOvPm5bH5jAEwL8yrks6tfilcToWYC6wH7B1g3+Pl1+5yB+sn0gqzv+TnTCZKbVgXv5bJMV62/FKGSEyOdXhxR8MtjKNZcIv/PYcxM6J1gzUv2vEjwB259F5DTIbnYKaU9GSpSgFzWnIl4W6Gx4AZjIEZjhjDMPzxvqXdBfwBh8ZqAFRsMLBqgAKotLv+S/PntH/89brmQ/nCaA8Nogwuq3GSWwvsqN16Yde423vWIC8rxN4iONcJrbC1l34lwDPSe/b3NuiNm/wXtxAQFMHpYp6YGMShAyqBWDKRKp9U7thPQDF9JrBUnujuvYd3BA8nRm8wHBiMDejVfYu4S2kcZY2rzYzBEClu9adJ3k0kOxG4uqu/DMvp5fVoSwlAtNywLhzrfKivQJPaMEwlKBun4r8PtUk0pogD2LT0PaGpT+G/V0XmXE1N2BVu0HGr8hWc5LhlPGPO1GVk8JPffjhLpDkPSVG0Bgjzp7GHdDX8yMOrOjPZ0s5pLIUuGmaV5bT8iwWkZ59Ki1WplZUlhYEN04onbq2XvAj20q0XNv7TT9LT+DbPS1ImIKLGAbB1BkTrKc0tfkqDgvuanqJ/0rBca+tmOLmVuMXbhZ/4X8WTocPQ2t/koa3lUyWIWt5D8s6YqdzRJZaF59XDY4AO4D/+97vXpNYyxw4jVRfTXwKCAn78y7bzYtSiKkAz9qUBZK1BYOJxdutUADk5OdiXqM3p0BoC4jj28FwCBGhgShhFZSwnzxUCKnyL3uyqCPJ8S9zdxuM0uicGTWWhK1SojFIJMuvX6jMfFN4V1dqeVShHbi8ev2Cl0fANQNGfIzQyCfVrdWJPu+cxMSnuApB1BajuWcQraZHOa+mWOD+joA7WPaWhaY+OV9zHUJfyKMqu9gsXJuweFdSWzQ7q1yiHXKRs7qF0jfJFI0yJlCI852dE4Z+eP4rMfRZqA2Sr317qHR3A84zvI95UXm4wMWbIm0wx8pUsmRELpgR0LpN6/EtZSdZXgN3xWF30wG7d6rAtfl8Csu6I6vzFMAnUCkg94Jd+pfvuZ1pRHqsAvjtM9sphhQ4DlsvrYQo6MUup87VXqY/O7dVw3Tm0oKynuWGyHCedcR7paP0a5yesAAYIVbz1INDppd9SoyODHAbgsJVh1wH1YpVGT/fRYZp56IN+l5sqzhMD3P4PJ/VyKOW5yRzkXWqg5zzXfsXHYZUsAr6qpcrd8q5C48M+oCmMhIgy3J7avRum9RIXPukLYOf026Y88iUwfroyALWf8kfhJ0/YAn4vjzlOHbYqh/K+vbI5JsCr8myiAHk/Lc4T9evQ8mTqfwJ9jcm1skrD51vDlF51y/QAKH2K88YbaNz5eBXAvizj33iBrOLVYFAFW4HOAj2lJddL1Eb76QqS4sb7av/kXue1LItVFV27LZRPDrMM8Do1XSas4uQwXodRaaayMOlw+tUVfV/pAl6S2qdRkIqEjUOVZvO8rk+779WI03vBa3mqdeuBPfoXQIcGN2PxyC+34PIqPfFvAqFZQVdSuepZF7R8WbAdgK+vOKXk+5Rn4Upp9TRDS/nvyWuagCcmkwolo1OVz6ZwkeFeBWjH6IF5RX1e4Kg53QaVKYHdAjvnuLVWblAbdc/uwTa8Bre5d+GezpsAL+NWxdMBeCGNd9aLU+VrISG50kNLMkYsZUnQZ0aagmX8CTP8/Vb2e9IE/Oyn38RbKMlTz6jyW8R/Ha4Ccx1q3wrQfmn9XLEKs7MCqPtZbW8rRk1tSvpSaPMS3DE9oTo2Dxn0BkIL5dIDeLtAViiLArRtRcaNs8b7qSpkK4f1XXUoMqWxTpqAv/7t798WQMtEXCLEVak6JIf7l7wQsAbbbtm3AqzRbD0tpTVpE+wa6AJipfHB2l0dEqJBZeRpeqDvPjfn/C6JDnNSgO9UOo24pXFDH7pSh0OHrUG/r+zoeNIanQpq0wI+r8pNN0hRoPWj7k50+QUWYVrgLrR7uwLUGteCWAO7eKE6fPJnc58l0LcBvuN5dZh9wLoD4AsxTR59MwQU/84lb1LT5WD8s5LYev5tJ/mmdAH/+3n6NNMYWUAngp9od2uWFy+7Pq0H3hWr/bKWX81qcDfDFC9Iu5WVIJ60Bo6ldFMFWra+9AF+Sm2g8lnNPXqhO+Ga71/x8sVUtU1LyjKce+/NuK5dX7NSuoAnFxquerUot0LHl1lfUcrrtffKGOZFNLRUP84JK0ADxElLl25KS6XKUd7zhADf/bxFnD3KaCnQ3l+BxTuEsgrDCvKWSDI55GAY3/pwj+0xu4AP63Nz0uqyDDK5DPvcjO1JX1WsrZfH0fhLIXpgXkpvjZnNUo/CNImW1hetXgI8OywCvHmx8AzNAGuhuZz2XhGX0isqPUMNGWc9GST+xrbSAYbVS/AtdjxNHEw+aZuTdPQbsCd87nUpVIA4QYqLn++OZmpodx2aVRgN8tKS0wf4AlgLbdyrFEuyJwvYkdiJvGGGS1Rxsoto+TCpe447yqSJo1ir5RcBv/X+t1B0ZoCDYxgNv+9otT3wvEfA47/BU600rQogNIYtlSnTLD/jvXucJlZ3ydncq02M6m8Yp/9poYCk5dV001iuhyu1/CLgr1+++nay0MgagfEgpk7Wn1M5Y63HHfcLKaXN45Emdfu0MJP8ip7/8NHnO7X8zrE0j/10y5oldcP1GDp+RfDVKVJ1sresTWLVHcR4lbrAlReJP7X9V97t+E+6vzzNe3FxaB7PnFc08AgLCkxg6N0dGcAh3E4tvxPwekc120htDDc4FVmf6tqQi+GoebouvSbAi1KKHXZJUdCu+J1zangUuVqd/6eJZCUlN09MkPPcpzKENU9yXC2DI4+XdZLmFEo2w+7JqrUl6wy3m0gMO0WMF9B0IrA2KHqguwAAIABJREFUHI8D1t3hCjvUCoBrLV5tMkCqI49yzCr9fq7zlaS98sHb5Vi7nk05ZllkdSZwyerzkoyymMAETgv5zrFhdMmNi0tp7wT8MI4/k9qjFtaLmdCjmeuHMprpFORUXm6nDjZNrE2tugBw5GfWyzyXR46T110nlWDttoLyVI93+hq/WUaNLJ1EmSVNHi80xQk/0vHE8F5x+bSxEvDRgpZfBPwH//ZPb4xwVxic1qSZpccw1cBO03U10IvF/VtpVGmteJmyzvoiwKtkG3HIere0fAP0CdhUtn7U2CSbVbT4vd6MYNWzFGXWC3ccpbAkyxqfGmc1rSmRVNMaTtYahnD5vAqeTPA+HPpafnmpvXGTt7hJNWtWy+yVNt3uN1lJIDprPm3H0RR9rdiKuKJSCIhNnmy8CvQa+Kg1vAZ6Dlvvp9SrAHXFXKM06tLYWRl2FOAqjb8GEt3btTrcIvBZLbbKc1him/P0o48etbV8F/AfPPzsjZHcFY+8Z09YMVhsyUVWCGm3iZD5PqS1j9aW/ZLpv1BaeKE2hRxmGeANMJcAp5yjiqdDNU53HfJkJbUpvhhyA10BbZ7LIjil8iqecRd4F78gzVpYOOvOuorWcDpPXB4Ac+55zftHAYfU1vJdwG+cS0vtBbBzXm4vcXdLbZoNWeaiIPoqmNqhFj/Z7fgnA3gJ5gRAHS6BOwMY6rxJZfQfZaDrL0F6+vJLEE+W3PIz5TAqxXYZHEcTL8Zpp1J9NQho0eGa1hRWmlQRwjKPM5DG1sym95Waq5J1AT9iuJK6cqGWK4Y3m5AtPlx5VYB1USPsjLPmRbfu0a8ElTZFBmMP9EjALoCvrvvaXQE9udWVQPJdK+eG26oKsKJcqB+mksU4bWEVKC/i1DN/5Cvb+xqUrx5bI3QbYIyoF2lqAv6Dh5+9occvTLH2zKy3pWlbaIwLFQUO49W+6sY5G01mtCS13Xqgt4Ctgb/mkDT71Aa1O3LFqNyq522VW7/S5/P1FaACtkmXWs79OLrDSQ5Wmj/RnjhcmDnSGr0+XogzEl0p15BvAv7QDe9JYrIzX9LuxWye9JOM8JTWCaxruDFYptOzBXj7hZMKs8sNAlAIUK27hE9+FZ1BcTQsNiZ99XRUg7jVcG2Vzz7lYcv1lCoAFb/FRTgrtXiy2xhXPbZG0xogr0g2G1oTYrlx87pOvwL8hw8/e2OIpsiwAcKcth2RxerLm+drnUGYhq0uhDbAG+enCHAdpvUCu25NwIl7rdHF32pyKg7lV4SXp9Smy+Sf/LJbK5+l22IFKN0b5dUMU6bTrADFefHu10nH7I083CA3ZO0aqAAwMP1XHacC/OiG93KvVt5gyvR0FVmQLPUeWJdGv1BUzd+roHd/CSg7GRrQdutp+gwCAzijzUugK8DqowiDFM4CPeWNVD4az1ZWyl0VoHQz5anKaimMDtWvAJ0wKMKUFaBBa4wbW74vDdW8pHtWxJtiKT4D+Btf3rk2kLuS6IzP3D3s0ifJspnYYHIK+xC9gjRX1AzQrgQrAK5jtuItuWUQ1+CmEljGL8ZrVACNdlsJNK2pga61+vKXRsVZ+azHrQDiQJVHFco6L1aAvhYXySFqCw6g9w7zxh2w1hqzXPZm3PwMrLcaCZsOy9Sqel1JoS4qK1R2RulH5PzwjLj8s/YhkGRVHCWsTkXipXvleBT9wjLPXMTLbq1wkl4rrLgnJOh0clHkm8WTVlumA40GyCiDS/mLnwV+H+yEOo1WuqWybVUAqv7rey+EsQ8WcNLyN6JDMBiyMEc+T7qePTxcssMLVh3BrCFvNHzQ7nnHPm3QT+uppBu22bvm7wnIFF+9KZBw1io084KaX4tWvP0ap5Jedmu8WLKa2gDIaPOYj/JA+8hpdMJHB+tW5EuXyS6wL4HWVArr1q4AjfysqgCt8+IGUXrm7jIUkKcA2tWIRd8HGYZsnkwaXsw39Y59rIYSZHDvNEcygWUR/FZ4QlPLE1Q8qjW4jifro4keKDV/cAuaGg03renTG+JcMcVddqmAqrRZ46d/6iFjGbXfpy4CVRilm67gnUq9UJHFvQn2jiKowjUrgMl1B9ytCtB5RqwR+y3gwl13fdr/UdQ6IQnwB+PhzySSbBXopbmqFqSXRoPcrpykDKCmIOmEkmeuBJaOSNq6khgwp8esKwbF2sDHAP1uKtMGPlCCH/El7H6ZLX8qPAwYxa0DdPFbqgDJfaXb2gqwl3ZXFaBbTknZ6HduvQ2vYADEyaCi1fLGDanh6oCg3UeiK8xxt2UWc2QGu7bNaELTZvXIT109eJ/GmBASj7IbFW46rSW3Ja3W04qkwlu/GE/8VZhdVKY80IiLFJ9sPhp5qejZHmCnVhrJrQHUJpBtBaBuBWjhoAP0hugPZ4/s6GZq+avFAcDB5sCMm9EDcVo7Y1cZKVxCkyJLGkhWADwXdA3wNWBuvvSGG2DdDTAXwI2GX5trK64vz7f2gE1vyWKDMtzCM3bde2BXqG9z+RaQs4N53+ZdLleAJVlk8h3PjvpNlH38+Zd3rm3gXhWObnbrA6eeVUmg00Rt352QuHyiDAgPvMTThVcrBhTTspSj5Zbj7kdZqjTUY8kGYJVlRj+6fvt7SiuWvgcpxyawCj8TN+aLVoQ3Gnqtm8pky+xoKkXrmfaQ49JEAMAQfsYxbt8dtHiwxnhGWv6gJDEJBMV50V5LNxeAU8GttX8Gbglwihvd2gc2DdYF0MtJj9NX4JaLnskx+QNS+akoYd3mXSutuqJBXnpbXo3dWn2NewvY+v+SG9Vu5VchO6/T7qcj9Y3GzeD+WKDH0DulKTqzMvmWnu8DvAXm2rLTa5y2K0JLe6tatAPcu2ztTcuMeKQHXllYZTnpsxLQKg/GvafVO357g536X4ay0tVuyxXgOELdixXho4zW2Rp4WtI3TS5cKYCvAXNtaWm7JdBTTK9LZSjvWWrcha7YCtECflmCRpPHcNUnt/XZSwVSuVRSfj10nvYBej5v8fhlsJvKR+i40e5wS8/UkcqvKDZ97qQi5qc0Ia6/8v3bQGdj4laLV58v8fa6qugpfS1q03GDBWcrXKXpRZlHEDepjHLPj5ErhC4nDfwE5gb4qwISoepkUUow2CTa/D2F2ZPfrwV7VTF6lUVlphuuWwz98iF17I5BKj/tEOMB3Ks9bb57WdluzDorEfWJfuxyE/CacLtBn2uXTkBnNxa81vZA/FJEYLdArXi80eScq38LsPuIid7g7so5+3U0Pql/bb82tZHw3Yqhbr5vY3av4qH6otbbotWDiyzpLsv9tu43tjLSqx0nFoLh7i0+33PbDXrsRWVMbYv3rIAP1A1YwNbzFsrbg4k6ZWLjt0p+F39vhlnQ6ukNK6Xb5/E7gF1Ull1uS8+aAV1DW/S8DhMqZgR5qvjKRBwDb+EfSCoVpTEfBFF/VYYyRSm1vJCRVhiCaO6CzxcAR8NNg160dwI90KYyhXvN02OFKIAfAsi1ctD5UFJZZk6g6nfRGnNdhC+BbgBd+K2jNvuBnSo3GLe2tB+4Vxky1Es/te5pPFqqe7QRNfEvk0wsXNg1SrCvEYllGqLKbQ3oK+uLyWLfvdT24SbKrwHqDObiLZyCZaYnZE5WgDw6tsKUwF1fCVZ+BRrANpp6ZdnU2j3jUOfDnsufgwPg4OCIMCAu6R7TOfJP3pc03RTV/c4bNrJXVgqqHasHAnTBUKPgqPFwFF7AQtjavXiRkqZoAOVHugCVP2l/Ey6nA6VRjP++h0lH8tDOB5Qb9POU+RR/BVKbno0HE0eVWYrbAzuZfOV31sd7C0HWSVdLq9XJ/A/3dnCKu4dKkEsvy+hztGTaCcthOxBm9VIIxqYoD6YUXctI0aU+tNLkqKJX/B2IXwCgRWWaPN1weFQcfcky02yYmsfqv+GSMe2S8j4WB7v4uw2zD7/fh9rIXY4H9vpaN26tMlD3Sn8weA37F8Q9DEBwMc6E+YGYJAFgnPz8rwdueNUkRiECsdYxHH1Zuegs66s8ZHNJBOAogVyAvsXf11CZJk9vADs5lG+j4vHRkbP3LrrO8V+puHYB3/g3uHsJqHVAV74q/qpKoMOr+6wFe/28S8+kc2ZptvkaI+tyRwTnHIbI4yVe2Wk6EmUdHYLlT4OL4A/Ar0WqgUYZgdNQ3hxG+ZVpFICttXebv/fdA7i7tvYS+EBhmWk3TrtcXlJp1O90mw66K+eiVlSgKRxIeVAnXAV05b9YCXTlKdwXvwKLYKeOO0BkQ1ntTtWfi/cL2t1lzR4R7GLqmr8DgAP735C6qUQaBPbCZxOvLf5MjdMP03pMW1vzw2bfbiGSCpvcybhbLl68POUn8YzWMHHlaIShMr0yDjW4ffuowqS/zj0NEFR82DKAiZ/fzF78XvLRcLfvrHhP6p3b97wb7BZHnfJIPqGhOlDQ6gM5jAL8mDgj97CKuHdeuXqbkTM3ENJnwZFuCKgsFA+m/6cMF9W8rr+2UFxM05lKpAu/5b4E7jawe8CXuGUYM93OgLwGZLsy7Dg6adQAR1E5GvHLsAXQy/Khph9l8LZArcrexTDyzpzKb5H7DhaWwW7eg/rL2j0AfITDSA4DucjrQzra/i7iAOD3/uiX4SJ/EMS8M0Aas66oYbWW19WAYAu9fNBWYcjLKAuwrAyuCN/V2ljwK0DdBg3qZzaaua4EaMVfC2oTt6X9kYDY0uZQYdEJk1Lq+uVngpQ9US57UvdL5afffxvkaLj2wa4qEhS1zpC32h0DhkRrQiwGYfbT+0UWgh3eESXziyOCY6cSiNo+WkmE5xJB9dzLY2T7PMfbJlu6stdISFsU+czY34Emr3eKa4Ny41fi+B0c3lhmYrqQe6tW6bJlhsxPX1r2q10u2aP0I3NCxl/nlVRgUnmlyj/YrVt+6dtOLfdG2ax4rpr+lGCvqUyws1OyyLhIYUYMGJ1o+GxpPML84J1Xrt4u7+0A4Ecvv/aWZI5AGIhCAs5hoCHdgGJToNLw6cFtPU/FogpIF0SvrEptVGvuUMvT51fur+I4XaCi7STvSxpdP5/W5GikVxzQ6ZmjUV6w90YnzTJcqclT+YqfSVPdsfG8EPCg7ZfKWNJVZQx1v/Kd6sP6yxdS42MJ7FazOwosZKAM8FFzd2V7LxurIqmn9ff+6JffcAc/kB4r4UYzCBMcPHHQ8kTJYkEEOM6mH4qzOJK1A7CaHhS1pjVo9oQoamosafuYhjZHRj+iOO5TW3PQ0egtywwQ+wKoyCibnxR21wPtEGpeUO1X5DP5J8BTM5xTAcn4kwlbam+ttPL5mufRCdhTMs9Vg11ojKhZTWWCdh/CEbl7qd3LxqopAwB495XvvikZkAZr0PIDRhoil48cnyRTpRYSbaj1GtRvLCzNNXeIaRilWh4Pyp+6lsYWLaU1ulP+tdYvviY6XNJu+cna1peGlt55iOZT6Zjyq+OgcG9qcxXOmTDqnulaP5dqN5nyz2XWkrJcJPOmPAtcQMcBqfepgR6sMA5ijSFsyGHjBmwo4pOEu9emSC1mLE3Q8psfiFnSJy3v4DHAE+ICqQ5MHLVvKBTPgIvcPfgRNKe3xRS1f6ocDVHaUyqKtAI8fEjV8PSQknwJIF8eil+ZpNFr/m/vSfkr0dDkrezmL0EnwFrZoTmVMkZVckXcVOlNyExPdHpis9ZpJOUEqRjm1st5bLhQ46pUkroy6gar02CnDPJNbK5mOgN8PW8/vX65rd2BavAY3wHoBxQbr4nWOIfZOwzMYMdgP4PhIGTGI4NexBGDI+g5FXmrg73dI8uNQpWq4+KHSUZcemYDfPFzMXkBvkk41gqpOFXjVNeGsgK0sn0CnJfSBlZDNTQqiAFqcrRxdwGdnACSJHo7f52ct/xbQNf5TFRGc3ZQthaSC1qdHDYQ0GcuDwBH8A/eufzd9dtWvvPK1du/909+iXizQXGlA/l8xEZDpjiqNhafIfm0yedQ1+P6E7frL35NYD+zIIJzeVioc+HQn3ehPvLyEn2IOXOaiphwxdF4tkxDenE6Ry+8TrN4fvTSVnF1eSc3Fc5RHnsi6emyI6fBpsyQ6l3131r5nPWfHr4rDebUQ0rq3hF/g2qkjjRgxFhQmVy1l6iMrXiFfPq7/8VA0IwTz9jyjCOecORnHGHClids48LzYUm+vFwxx259u/4kTOPRNltLYfV/t3gA0EuJsB0/wSw0LN+V2aZv81bkrj1qwOZxbWbXSkNzK6/qRId1RYCs8VVIuRaqEp2zxs/gXchiddbz13mQa50fR7bS1DTGYRMpzIEbcUhjBH+oDADweN5+uku7A505rV/z9OlLtHmTwBiIEFjvAHYAew7rzACYAIA9QA6eZWUySv4c7e+cuH2gBYniGDC16M4uibSFKNInwBMiRw+rLoiWSzUYAEiNAEq8PdrvgcT3bXaeDp1pJkvWtbi0n2kFMECBGOoLgqzxw7krQLkM6CWI63tT9T9Tl5AfC/Lw5RQrYTacaLAnKhONJ8B6sPfzDuCjr+5++g13+ANZjWxiH7Q8z9j6CUcImj+sH583h2VWmh5R06vhtXbVv3zWVJJVm5Fb3sbFK4+08YnS+sxs5m54A+TOQlONzC1+h/bV+M23QD1n466BlIHW0O47gO4aGWlBnRoercph86juHUGdNb3W6oHQOBBGIgw0YEMOI0YcuAEH0lBVVGYfsLefScnHX9379CW3+QEDYW/7RG8y6CeeMYHTljjlPlCsIC5UJ1yJLC0J0nbhwokbfkKt0nm6f3STSmioDGD2N9lFZ06bymgxWrLtnRuTWm9mfi/iokMAWNb50i6xt6xBXYfoZrcZRiqj5vka8EJpRKunXlQacIBsftxQtMrE8Fv4B3/xzf92pVNETdn5Mf6Hf/+X+yOHlQ1q0M/YYo4bFs8K9FnbG8Cj4PAKkFqW+H3pV1WcRjvBmy+MT+E8s0kn56mCvrnZWeK8lDat0VSl4OXKlTKhT5Qhh7OEo8Wzm/lYIDtlpdOuJcjlqyON1AEuGBxAqUNJQJ4aqHAK7PODv/jmn+wF9laem/L3v/vnBxsM/0mDfmIfgO9nTEJv0lbgQmu8alRqbW+h2yY5SgzmWuHKdXSkDWH9PKRxyvkaoV0iccvGbGsBgu43qUt9rHQLfSW1qe3rQXJPquXHQJ4BVNKLFshtZWjci8qs9iqITVODPAAdIHIYgDTycaAhdCy53JMqDVSZ2PFkTxpT52uF1JpeAR8Ttj5qedkzkzmtTymaVYMf6IPXXtdiaJGhLeV5DfwMdpsXaXQjha+/FCZfK9R8+7u11BxsSIezl9TDaO1IYRxK8OarbGbNqZXtgepenSfoafpMu2rTpYtDeUW7iwlyVA1VoS+hl9UBYBzxfOtHL7/29pqia8lqwAPA//jdv9yXhZt81ObbSGcmnrH1cV+ouF1Oojc+b6gApKaloTglX9YZy6skIMXTPnIm5sW8eXLdfujRK0bW9IBuzGaub+/dl30oz9oXoHl3Dd8cyOnGqQq3BHSpGCFqSZZKsJe63fyrwmo6EwAetHqiMUTJvBg6kYKGlwog/B4AHs/bW+9evnpssJf5WyUf/d+7n740HvwAENAHO3wAfQS895neIC+/7bkGXjnnsDewzHwBqoamAjyQNraSr4q1GOkvBKu4MR3N9wt1biw6NtOt09VSvYTGWymapenHlWGSRrXxWtYRAR8hj5XJ2ljdqQPoMnTJ2yV8ALjcM4zGjbMuUk9pAnoc+xTmZIQ4j3m+9e4JtLrN7zHk44f3bl0axjcBUntjSkdUoDszPCaft82ZWYPPdkppatHKou7SL+mQ1uAA0t6ynpfMpLYSSHol6PX9LD1qy24y1peOEVI8AdSmw5KCyHnVSFR8PpsBXRpua0clAnooQqOaVblN96P8XRF/BxcrZrDCkGhv1bEU1pERipOBzgCenIJW13IswANhR4WDzcF7I8L+OSy8PYFb9neN514Dj43pMsTP4GtxydxZ1WmgIgM835fjlps+ticU0JsWpLamz7LQsG657cI+LV52/BrUoaAxS2AvJ1GkpS0Up9ZppXuVA8hSbqxLrpSZKgUAu+q+eZ5FroCS6tfz9tb1UwR6TvmEcuPLO9c2w8F7suNxAl36tRo30xsBVU1rcuYIoQeUIui1aOoRgCr3kcazfGmkAnpWFQOi7TugN9Snfd+nJYtgV0rBgj3zdZddItjymPLB5QkUYvKT3mvq3LPlpoEujVVJwSnapMdd5TyFNJ7wdMt74CyAbnN+CqKBn7UoMsQZ8QxKw1vuXWeu9WHN1o6Whp+9tCd86CPwYXPlmXPFS18ZWNBX9OYZAH0JtHWandQY9khhEm0JmlYPsQ1Dbik1JsuvRJWP6stUNZ9TBcjth5yWjHYlAmb297fwv73+8tmB3Ob1lOXGl3eujcP4nqOBB6IrCTAFwKWH00KtlTmr3SXDJa0BsobfInaKce4Nnj1jit+YOYG8DXpTkZp8vrzz2UibPcvvsmbvgb0cjLWh0G0/wFKaHtjbgEkNiAr6puIQMLG/P3v/WwC4fvn1pwJyLacOeC0///LOtdE5dm54z4Ex0HAFyA3HcC4uSPx8xvzFzPjfAIB5/swkOgA8DDH2DMwDaJ5pBuAGd3VDw5/PHHqAj3zoET7iCVt4zH5OViO/B+iXNP1ZAX6JQpRgF7edYIeLE54HHKphtpvYi7kl/ge/ne4CgBsGxjBDdgOjed4TK3FcYtxM7KfffP0f9y2Ds5AzBXxPbvzu8z8DgBn5P2bgp5dPXih/9+gee+ZEaZ7whCM/YRsrgQx/mPcE/ZKmP23QL2l2AIoeWMuLnianebKsPjG6OOqQwsjDAwoafoDDludPfnr5e39+yo/yzMkfBPBnKT9/+D//7JI7/LU0Wo8w4YgnPPFh+MMU+wmE2ljTpbXerAP96QJ+V+PwOGAfQBhcnimUxpRjwMYNmJm/uP7K1f98io/xzMoLB3gA+O+PPvuHDYYfenhsFa15wlMa0jyJ5UY1ZPUEFq+gnloZZ0xtdoI9UpYe2MUSInb1ZHKMYD+gARs34pAGbDBidKHz50cvv/ZC4qAlbneQ50/+6uXX//zITzcHGWIaeepBGoTkUm9faSLT5jxAeLLYoutGGeLVSRFjyUvf/FiBHX2wUwT7iDAXNAy3jZYZFzj919ujayfM+nMlL3TN/vCru1+M5K5sOVhqnoiWV8OaPVs+r3ckz8MQ1tvoTz60YL2tPa/DKXSmoDJEGeRuwAFtcEgjNrGn88k83fzJt773w2Nk+bmVF1LDixxN0/sEyoOSRMu7PB/SbJFiQEXpWhvX1mh6qtz7slaz98yPGuxUgT1OpHDyhcsLFk3s7583sAMvOOD/+o/+9NdHfntTBikdxFnvovEE9GYdFBJ6YDtMqk6wBdC3gNsK0fJfAru+fwvsQmVkIa0hPqeeRDGSw8x8/8evXP3OfqX5YsgLDXgAuH75ez888tubMrngIK6kNsYeRlnCRy8NrpdcLkFfdqS0QZ9dqHHYMLs1e/mF6S82ijChImr2jVhmonVGVuc6mupVdc+LvNAcXstHX939YiB3RaYjPvFTnpTOU8XnreVm2VypOX283FuWwL5kkdFrueRJFLmRfkAjDl0wQQ5E2Prp5vXL54/KiLzwGl7kCfP7GRRqubao7Qc1WrC23GgKsazp4+VqTVKGbXH2JYtMAjtkuC2Z+aB62MB5BztwjjQ8ANx4ePeTAze8nZYd8TOe8DZ0TsVBZhN7cHfZkWy56Y2lL7V9dErS5/VJpRvObqkVMmcXrq61uyxDlywyQcMPYd2g+++eU96u5dxoeAC4fvnqD4/8fDMNoorjStJahbFXUkYNtlaxLTU9oK/Dv9bOJ/1GKqU5qDlcH+ypoaq0uyxtIWNlNoimSBpSI3zr+G/OrmSfHzlXGl7ko6/ufTEQXZnjeJsjP+FJ5PLbODE9TGSZ8zibcubUriVIRHqEnlqnquJ0OHsL7AMoUxgagq09rtLlQNh6f/P65avnmsqInEvAA8DfP/pnltlZWw6Al0bsFI88U6oFeg18QAOdq/+1tOz3+qz8miyBPXP2MGzgwI1xhS53wdsLOVeURssTP9+UZZg1rdmo2fNOrXIVTH4FvVENR9PAhbWt1KZJ2wTV7rlBug7sQ9GptokWGUcOM/v7F2C3cm4Bf/3y1R9m0McOGhlnQnkrFSqmvukJz3mjrUYvaAXklnvLj9KYdrMbhgF7XjNdW2TC0uZ5gvQFb6/l3FIakRuP7n5ygOHtMGnEx0kjU5o0MvnZrJlpx9pYu3ye3QWsGVdjuHvD7t4bK5MWLoq9xwcY07DfMTZe/9/2ybW//qM//fUZFNlzLece8ADw94/+hdPCUvBxwkjslIrj58uFYuu18BsdUuG0CXxK/2xvrbXMlBOwLdg3MjAsTtPbxJGgF43UvpxbSqPlyby9lUyViGNuaEzzPsNQWpkTqilN7KwybkobKzoiu2lI+CY1Ulq87AQbFNjHBthl2PMMvn8B9r5cAB7A9W+9/raAXtY2lDH0GfSDXTCoAPky8Mte0mKX6YU0XFxXsdz6pQS7rL+4Jbrg7QtyQWmU3Hj42c1DN74lNvhtXCj2yC+sjlyuxoByYjr0FQBlhFRDCMRddzTF6SmhJ9Upe7veDUOB/Wu/vfaTy69f8PYFuQB8IR8/+vyLDbkrMg1QJn9vvWz+4DHBw3ufBpZ5+P6KB0oY5biZ8F/b4C3Q4/YvjjDImulqyG8Y8Rm+Ao+n7a3r33r6y148b3IB+Ib84tHnXwwR9LJQ7BGHxmtYCz8u3wc2wG+th78kSbPHFqyL/9NIyKjVZTeMMYHdpdGPjhwez9tbf4g1Xp5HaW5qdt7l8bT92/+4ufQrGT8etrEnDM7DMWHAjC0cHHvMjtSS4HnPpEB6qIC81fFpK80YL3F8l5eTNrOWZIMA5Ikrj+d/Tay/AAABxUlEQVTpAux7yIWG78iNL+9ce2lz6VdA0NSB04ffCT5pe71grAxB8F7Wvy+HGwQxFCaeB5DHRUWRV9Ud1UwlvXEAESLYn84SdS+KXAB+QW58eefaNyLo07LgnIEe9rUKa+KXS4L7RHL6IusvakvNUNjagzYfUs+q9Lh+zfOt66e0Zvp5kgvA75DWIrGyCcSMOS8RHsHv1SYMnrPNJm0Ra371KgPxNy6fkfYphV5WJFCks1pK+jzIBeBXimwCEXi5T8D3nHc5qZYE98XkECUy9DdtSgA1ARt5nq0AXeQ0tn05z3IB+D0kbAJx+N4m7nMlTdM03CABXoYd5FWNQ+iav1Oh4cNkjjyWRuSkm3ldSJALwB9DgrbfvCnXwtaTHV7G17DtiMqiRkzKZgFxrXeXfAAC4/E8fTr76TfXv/3920/h0V54uQD8MeXGV3evATMOXND4QChM29O6PAmktRa7yNfT0S+ZmH98+fVj7Ud6IW25APwpyI2v7lwDkMBPCfpBdk3iDpv6MH4/Hf2SiPi4m+5eyG65APwpy8df3Q2Lk5L7HjPT6Ib/AgAH8SsAAEfwDyY//ysAEBGD/W/eeeXqBWV5CvL/Af0LTK4Atcu2AAAAAElFTkSuQmCC","w":188,"h":180,"e":1},{"id":"2","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHIAAAC0CAYAAABIbHjUAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAACAASURBVHic7V1drybHUX56Zs6uL+CPkF0jrthgOVKkxEgIECK7kUDcEYdfgaVsfkXWvkb4IyHAVRIRzBonRlwg+9gSv4TYe85MczFdPVXVVd09877nrO24pHPemZ7q6p5++qmq7pn3nICGvPuT+Ggc8e1xwNeHEfcAABGIEZcxAte/weNvfDe807Lzlfjy3k/ik2EAwoQHw4D7CGv5co2P44JfLzN+8fJfhrdrNoJ34elP4+vTiAfjtIIX41pOn0IisMy4fHaNx9/8zleg9sjTn8YnWBDu3MX3LBQC/QoAIjBf4+P5Uzx++ZENqAnke/8U37jzAv4WDLwlrgYRQcUIQX4iqSzXuLx6hsff/IqpQv79rfhwnPDKdAevElCZGIogdD2kHwzIgP7Rn4X72nYB5K/+NV6OI+5FAHFZG4oLsKRjLEBktcKwNjSk2cMNLgsuP32GxwDwrd9iUN99Jz65uJvASxKJFGl8YyojnUDjOQBD+gnDWrZc4+Ov/6kEUwDJQVyWtYH5Gljm7Zw3SLMlDBugoozZnhdcPvsUj7/1V78dgP7HO/FHEQgXiX2ZeIkQmRhREiYm5TCs5AgDMI5AGNfPYQAwJGYyMPNYv/8v8ZLi4TJvAM7smBrjFTOA49Y4zZ4hzSByEQAQIjAv+OjZ/+GH3/qbLxeo774TfwQgXFzgVSqjiR8TEZBAJGIsyxq2CNQQkceMxnEagXEChosEahrz6yu88dKfh1eRquDdt+OjF34HbyEZnq/Xn+trYL4C4pxYCayulRpLFsi1ZvoPwDis4A7keofN19MMXa5xeXWFx5iBLzKov3wzPrl7F69SyNFuk9gXZ2BeNlBzOdMHWJgiRk7p5wKY0nEG8zO8/tJfhO9PAHBxF69lEBMDr58lQBOIcd4SngjkxIcanFmsDMN6TrNnMEBFAIYR9+9OeBsAnv44fvTsGX74RXG9v3wzPsEAEPsWAJjTsBBQMRFgTuczc6sKxCxhtUWhaRhTecyX1zEEgAGIS8qL3v3H+OiF38VbAHA9A/OzFcTrxMolgcmDMhaB49oAJToBwt2OzM0OI3O7oxFPk7F5xuUw4wfPFoTPE7C/fDM+GUc8GCassYkBsSwSJA5edp9EBgIx2QBYojNsYIElOsTK6QKY7qTzEUAAHvxJCOE/fxovxwvco8TmioC8UokO74BmJbDFwnSc2Tky1zps4A6JrQS0TpZisrXM68bD1RV+sCwIf3yLLvjf3oxPAoBxxINhZOBBZfQEEsU8ApHFQnBXSg0UbFg/tGslEkwXK4AXdzYwQwCuPsPr4Vf/HD8KI+4vyxoPrz5bwby6WtmY3cDCXCsDkDom0t8hUT9ssywzMWxulhgqXC8lSWBrKL7cAXA943K5xgdLxM+o/Nt/HX58FLBf/EP8zhDwx9TMxV28GqkxvhHCxoBAmWcG4izj38KSHJr4YuxYHzIL2T1TmArjejxerD93LoDpbkqAxnWZF94nIK9X8K4+Y/HxKjGSBe4cxJVr4B3iGwZ8QZvBVeDxdRLPyvhnnqHUiJKwrq8ueZm1CUVVs3vUA8qSjuw2+RKBwFtWAOOyhR6eiebww2yYHWJZKpDYCOmlhgAM0/ozTsCdOyuQF3fWcVtmXE7DiPs56FIHqJNRzaoof8QoELDUEWzukQoWioUJ1MAYSJ/X5HaxzcSsw12OcuVxnSz3OVgG3rnLy8JO2KTkCcjCxoXHOJ59crcaovRa5IIzWNqtUv+pcEj1AzBQvXFbLYTrTSdjkpLGaeFAsJ9FZVdUmXeSp8xilCK23R8GZqA16JCuzwlUxT4BHgeRXQPL3PgWYfDQ091U953LIooJzJlGzOP5wqLGJS4JN+5CE0PzOjFdWCKbmHO6NqTMFcAwr2DSJKC2BQ4AJhHruAtd5I2JyjVWEiOpw9QjpGsBwPU24MMAzDwuDMAcGVvDBpYGXMQUbG6JewUBHo95acA1gDqJ0eXE5AxeuteF20q3zceF9lWJABzQ7ILT5Ay0w5MmfFiAhSYw5AYCtTFlAKhNfqNAER/E1hJTFC5j6/vqUiNjJQM1YAWNRn0IqcPAloYP600Hxkqym0GFLO8S6idPRNiyirJMkaVii6HFRAC7rsYByR7dJx+73OeQJgR5o1QnYg1JQyKTzlNIptyYdp2MwjzgZ+ConPeWgZJPGSPFbj+YGyRQeUzlgLHzfJxmSnZLbEBYFwqxJhy/H+4GgQ0suhUw8AJ5IO7V+DBwUINiI1gZVqBiuq+4pHwirOVi8oib2I6nrYdbOfe94hEWv85nRJT1ub3U322ZokDN4ULH1LgNRs7oBqWT6okYWRxI4W3mZhgQXERChFKHA1uMAY0hAc3BY+MWBmRChAXbBCYGDmzSMA+RPUUyZcbIzDrtRp0NAXOmsLuKelDZDM2uRYEqAE6Ky5z0tD1yRQdEeBQwFrFyQYCo9JSrBNb+iUke2T1pr7VsIUR4MFpy8fFO9TVOCAlIYpnovKbvsnlaMCMLP9c3zLIzAmphZeKGeUIUS0KJh9fafS6rWz4kmkl0wF1h+tRDQgMfVH2xf0oXyV1rQBmAlAPkdhcgjqx9h0AhApMAEdJlUqUMIKSBAnxli8eDCMauNDj5aQHdM3c/NAakY7GdXT8Vx6I+j5Pagyim8v5nltIF3QDTCUjuNDCvtSAvrwRDCTztARPbJ7AB0gAiQrziwZcg/C4sAOn6wkYo8MRBgcoDv7hhPghQA85vkBe3UFVJF3WZH0Sy491ngHTD8Ceqvs9sLwE4xNJGWLCuH7FiMBhs5P2ddEFuhDGzYBxnrTaqZqtIpKzMjXU+xx8rpqLMG3KhOnTZa5gN/IQZ4fda2E+/MvsIOO5RDPDyvStfbMXPCNhrTdV/Oph4gf4UwBQjiG0NBmxpudkScxN0zl1mlEzLMw+MGRXbUNd73CyBYO5MQYGmjxkYwovBBqQAVE3YTA5K2uLWt6DG3fKGAcq1WpTVN0PGtCuN6nouN5IXc1IwN1YsERyGecD1EFLEOl0hyHHQSxrODrPtYDAUmxfiAIaILeWOJTtdPNT5ZN4lA4YPukVv7hLNejS7vJt3BrMKhjUJdkrhnnnf+CBaoCqXB6ismrndrE+TmiZ2xd2KrDxKPbP/kWJkZF7UAa1gUWQdtmzwumqDIKrPIk4ZHa36S23Qk2CbibpdvkTiNi1Q9STVCZIHCrb61AcBJhx2KgxIJCO9CoYBQXldT08AZScXBXme8bIA8dwg2emRaJsWjFDtc2B1gpbZxHTyW4aNhKZ4uAAFJqtuulrIOpOoAZgguvFQ33AvgKRrdM7sKBqytBQM0QOmGtauDzDYxcJGAWiUdkx2WtmpsmONtzXWE1ThXhCbwDv1xKF2X9pepe6B8FjYymOm4ly+rtnF67GTDAozql0mtVMFk9tJBea4M7GTHeNmDoFosRA2MLmu49JNl1gp7xK9rEntC0YAJbt42wYoQMkyUT+2wQS7luuIhuW9T+Kax8xzg9hisFXfqOcUyQsVygZdWWeSutwClLtMi51qQuwB02KmeQwjRvIO5waVzi4QKyy07HgToDjtpWJFjxhF0pOhAjbDABsYq+5uMDtup+pae+UQiDsA7AHPnBSW6CWIbsfIUPcmNG7s3AsmNn3eSWs8Jj0Ae9l4U3HUq1sr7xLDZVtLD2v9t8dlirqngKkmDe8jmL759KPQv2UQXQA98Cz2GhKck2qG6oDScplU9yxgdtzcYdfa7U6P1KmBb9XvFGvSNDNUDWivy6Q+7gTz6ObGlrUeYFdPY7vs1+roek473aIy1Fx0IKFp7c7skWyKjYuIl1o5ST8jT3CpZ3fB2n7lmpBKhsr7UQDKE6QDLDtVvyakUr6zZPjkPRP+VBBjrU5WyB/yKQv91DpH9ZkNXbeYWPF2Jm+t2zXbgHqw3GW00cE9YnjOcgCVcq29rsFR7AJwOKE5zDRDqrYbEtHxFuGemWN1jhsyQagc94BIrDS398xObfrCnmYob6qHacYt1Ppg2e6o4oofI3f70/O6ix4XbI1irXmdoZK+zhoLZpXVSmbxQo+VXl0Yuo1x1OMlGdkYiLPodrqK5rkRwwrTiqUee62YY7XhHbuew+pPry72jdmuF7R73047SbdxbILIdchNMlcpEiLYdlp9MD1CTQ7qNtUc3aNv2p8kp7jgHjZEfmDFPw8c1adqFxuxst+QUt0T0pgMu2Jhsxe3a8J1uZYRBiivfC432C17QtIOeS6M7JJTEIWMh2d1g522zgV6rwzH35Uw5Ay2QnFwgh2+PvySyy5GnrKHKOzkX3sqVIo5YEFeF33uOP6igi6BrOw87JVdoFd09aUWMBlM4yfABru3f2fXPaMcj5F7QG8oBnViulePQVo/uDiyA2ZG2TL70ZIb1O0VH0jHXR3VbbnBLlZW6lqAlkiyy7psrws+k8cpVA9Smf4Y1Y005A6OpatOTPDUedEXAtRjZSgBpDq6I90u+JS63QptKRm5c6aZbtBXFwfdri0Y56xOAQ6rYzEy29dujk2AbhdsmHalNkEb9ax+cKnHyJ4Bt6r0grNHn53nOoa7FMCqH35d23UnyjnvZ4/oPjYkA3mWQH+EaT36DjsFoAZLaoQUAGtbdKgni+rX3uNzgq770n7VgzXKv4yq/yKH/j5902aUx6Z9SD3+hyVyv3ijoa8PJqj6VJcZAGk7rfNu8UCvyNTl+/f0qAYMG2X6HmGs1Um/+ITJH1ECmu0eQtK/VzOhMnRv0wXrsBAATHnwOg10sbITzGodyHqAURdSzwK2dT/ywLHPdG4cxA59q7+Fa7WMdoPTCya286IOmAv1AOX19Q1zMXRaYjKjBmrDBR/yarX+Of2aLI0bBzP9EnWAwl26gKr+us83ewZPg6TqWgBafQAqIGoTp7DRkQxkq8I5wIRio+dqs4oCNNdnNnr6vksOAGgx9iZcsD7mp37W2vDJVNwNJuBOAMBIaKy4F+XNFiTc+xBQM6py3XORN5oM1fqmZCq0ao0pluXDBpiAw2agDWjS6cpQtbs1pDogxkWP7RaAQtU5L+p6rl232zguYqQ1cyLT6WWZxbBdCc0pGWqsDE6tHuyBF9c7AcyHNQYbLtmq15NASde6A0ygHTOBPnYCPqDChu4j0xeHLT9kqdXAta5ZLrDXlaZr53DBJJOnUMwmBpLJsorLdOOfYrUus26meMtMD8KZxF2g7wTQtHUqiGVVyUhTURuLJTtdhvUmNLzzrQzVGOCjrxBuRvtccaFzAEChxs5N4nj9M/o7FcmJ0Ug0jJouUzGsO6Fx4l7xN2voggLuXO8SbQbNQ7PAAhBosJDVaU4Ap56WybpmzhhiyE0kNPymvGQmlv0yibiHnRYAHXpenAL6AcyH6ry63x1s9obgrSMrPvwmEho3mallqF5meio7nfq7wGN6PbEw2/CY6Ll21vbEkxjLD2fwmJ44hs9OAF0Jzd4Mtbr0OJPUgMuXegC0yhqutAqi1k0yKUzKDmijBIjhaoF9gGob+qa8DFX00XClPd71KJtr2WxxaQ+AzIYJomKsxmkSiqwBi52AAchRQJWNbGJvhmq5urLosFQTqQr7xGGHGy30NYjlJVE2WQbNGgyQ1jZd7iz6M1QTVHEg7Wo5ZQnSnfVWYlU3gEY9j4UWwQqb6VPstZoUtujvucuKqzxrhmqAdvYlCGu7xw174AF1AIWBCg7WpOBtTlYH9ExAwL6EJpSMCkxHb6VVQeV2jb4eXoI4wFfnww7wgGMAWi98WcmQ7sSkzktqGx07KaFhN9JaduRDa0CsTLu4mYPSA/Ie8JK+V990o1Ybjo0A7loVVb1gyzvbAyi34bI0lWmmikPFsiP/WWCPFOYr7Z20L2vY9mKh6z2h1pFe4CXj3fGvlqEmvSKZ0bMtKuw8t3bqPmulDVetpmeBpwpqAPa805ursnP76QcH1OhAsQJoAao73QJV94ldL3C7DWa22jgCno6DRt0qk1UF8WDZ22EoNrPTrxvPUI01Y3VMLaAb0gWUWcmp5nkOQ9ljtoeDayt4r0NqQ6zIin9dW24GqMJeLrA73Fp+kP5ZCWoxqqJTnFrg0S8DjF43CpRueDJ07D5UAFUEk9WYnpnMtDJUZx/YUDlZuiaBB07rumXccakF49WEsphcJDuajSGgeJgMYHeGKjq9I0OtZqe1JcgpUjFYi4NFsWdHu0rS5eUBhZJlMz/9EK4RyhBvOAHeBBQ4a4ZqgZtPz46g2YVGIbtcu+6xjx2aLpTsOnGTzssNAWVA7KEyv1xNaPaA6txka3NcT4SzyI6JUWUcu9aaEFZMzKeehzRs+a9DsvPMWuvJRIWlQB1UwAGW2+fiZaU3zcxe+xbrhCF5aN2jxUoTQGYoQD+PNGlZNtDccuOdPiVD3bv8ULabcsoEqDHOuGDdpygKBrChxNRkM1KyUygaPhiAndB0sjQfNoAVVSxwixNHzsVSZ+Ba7XmDL4o9g54L1aRiUmwIWJUzPnx6RGnQYylgb44Dkq3ZvpaO5Yehvkt2Y+6xqsPoIfA0qYxYOom3yJlBq1PeF2vyqQWq7rzD1ny6d3Ncx9aGepc0jPSCli/VwPMqBXVoAMjLJqswNxKMgQxywHUyozuvQS06f+Lm+E08BemNe65KTY/df811ugAS0RRW5Vt0WgmSUXsyVGGT1z3j5rieFIflwIRogsauu8xjhwI8fd3AhcYugGetekY4yJN+8a0sVEAFzrc5XtsYv0l29tquAacueIwURR6ABSO1HccXWwzJYdJadgA3szleA/m2pQWacbEAz6nibgYErbgell90hQI0qDIcS2aaGerezfFz7ebUxGNPh75ZVAsPGiR2sbWaCLC++2EEXD3oNVAFY2oZquFOTWyiUHFObll64nWHXnMpwsfSIhY7EG8IBK2gkD9rhurN3l6Ald2zSccEMVUa9UJLhzHSY58If0rkYyyqa1E5yrIWqLm4AaxW6QbYqHMqnkfdp6nS0vNcKdVljBShTqtxRprBVSnWMtSCNTuAVSqifgtgLZ6d/gr7RLu3lrKrpryf6RkNdS4FIy0lMXuMZQeA5noyV9HAKh0wHfPGo3loy7mA2mur1n+uo/QE89R1ExdWZ3uwrDSDV5vPrJ4M1Ypxlc1xdtldfjjVno/UmMZ0rNOCderezLU8b5eVZ0Z6vpiXnStDrW2Oi+rOCN3aMuTIpPFivFVgAeyBF1BmsuyafLDMlNxv/lDMbO3G7NwcN5nLbBX1Hdu3Jk67ZnFLt+b9FPMs/YD09MNT4g3t/sN+BrBCxZq5HpI1kLXcwn6rq9aor8es5jJbj7S0B5Xf/fAq8zb1oJ6SoXaAKy71gFSxEeuX+2Qv2C39sI2d6YKDPAzFSWKkaZiB2kpmdmWovdmpl5meiMK5vfAhF6/Dl7ahSOWBl4s4I3Mlx0eT7M5QK8Dmy0czU51AeXo7ZU+M6zFUrarcbDCKTVYGFDlMsWme2WiBSsfcJSq93qVHrmrcaXX5ISq7p7cnlkus6FZOJesM8DQjuRH5PFLrsIqWi+PA3sjmeGOEbmwZ0uMROutX7YTy2GSdHlOTkSIQcktlZZJmIlNhLGCAm/R6lx+qWePkFsRpz+1GS5+Y7bCu5ikB68988iAbWDLDANcusRfYfFi7qUbMPES8hs090qzWUBDepqLLgTNdsDKzvtcalV3GSj3rrfjVC6w6PLQ53vV/PYpKB+qcaGevt8iAeawLzrV03fzKgNmJxEgO9skZqmauYas4fW5ZTSmHXTsHzTPMgCuincHmyXzlkRrRLKslMlaMO8Pywzh129ir0jX2p0wcDyirDZrUNeAU2TiLt5evPOpSbKRKvUuPdP3I8kOonuGZ4o2SuBcspu/VNYFTXst7GG2/fBU2xAswnESmO0MNotomBmAtoN3qR5ciXiw/0VbVXrA/BZYFRZMOI98UjAsesID91EN0tGf/NBrFHsDKrieH49VRcdqoNm15OygMg48DAPcZpdg054dBWJeGuOzZHM+HlbutPQFxTN6KdM+NhqKecMG8wK7zH8tYKpevQzp+OYYtVK4FqmN6kB3WFqrW5njniB1ahpwqO5h+xENwV1kFjl0nne0NAXWhCLhq6QH4e6JWQDb/DGctJhn6n5dliNn0zv5k0Gr12fgX3lR5TPMxFhjiLlNqwBYnNriAA7DVnl3ktneynGmiVP9AhNWewcjs9bzYGdi/ixBxkRsPrLyWoeoExkteOgEW6ic+UL5J6QZKVNo+g1GcT4xQJ4pYBfMvX5mbs6xivtRYeuzKTmsb4yeA9NzmwB6PwlmmGJeLK4zclh8VBfEoq3PpkQ+9nlcAVmbMunvktkDqasvyeOyQg9YCzk12uLGud1qTuH8fQCipw8YdVzNSK5GqmzsshyZBRyXhTlXSYjI5oO4poXd2LEqnXydlqB0Ai9M9I2ix+9xyoIGax6mVcTbWgNNJaf7zLIKAmtZnyFBbyw/j1KXa81yGVOPcXltBjqtpgjGqtqFe/rPsUGBo+FNVdBDcrLrz8UTXmD3P55bc5B6bbOCtOJh1uG6S/N0P0xVwau/NUC1wzYK+m939fz1ugamHlh5AEcoofBURTntGFaJ4PlN8ZYBT2Go8l/ckMHuz0wpYhwfteYkV/2pqmmmhPC02zDkjs/90Am8uj35s2gUu02slBOdchpxNTnH3WtHJETJDHTZa+sXfEKg+QlHKh7PT1l17QDttNcx0ydkI32GowFKzzCEVd6Vap3St3GYqy+zqSWA0c3XP+am3MX50VHX/Dpo51YBZrepXVXHYPnuWIAhqr1VfLOIic8PeupIHbSEdAJtFHbQ6tP7cIU2zJwDONwS0xyuVJbBcVf6TM5bo0I94rxUo3Z6XvPQCnHRdvHa6qs+bVJM0j6UGI4Olw5OdYLhMbUwkMY47LfrVC3DS7QajBvotSZU5e4xwZrExMJNAx0sSq+Xf2QkF0HajvclLA2DDVBulPaA/T/HygpqaZhq5U12sdaD/ESgzWDz56Onknuy0cwlimN1x8YxSuZddEyv4x5qROYYqYIW5hJP4/5Gtt7e0dP8nAGtzvOfuz7QMuVXZGdOLXMMZ/3yJe08eI7VFTt+8/KANAyu9143uWX6gtCmKTwXpOWzruSa8xMZTD+VPLTmS/1LJ8L3iMGybQGdZflRupijeCcrRiXAIy4MTILtOOqeY2AioegkS4PwjUAG+ngk9y48jmWkUH2b9PfJ58LimxyoUKuXKjRakNF0rv8hnRk8CUwGXXTZOyk51A9AC/gbEu7/DxoxwZiU9RR2mRzrFprlbmRuPcp/9lOUHU6sUGLIX+NuWWl5QK9duUYEmQGYF5lfPcyXLbXqdtPZNa6PM9N2bqVfbefGANGbJ4UnkUS6UYJkvYhkNiwfLtczISj5ar1wEpmtd7Br3PRvhz5ueHe0b2G0HBYp2fb6pToXFhkCeBenTW3rsyk6dG6wCTZd6wTkK4hlZvHuSVSqIJIclO56y+FqdRXkzwEcU/72OV3Ab3LkEAVCm4j2bBHukJ2Z7hSd2QocvcMBqQTVAsDHA+RKPcLMKQHEPqrGTN8f1IzLrfm7BfVpNeP8VoWmj1t/WNQas+QYd0yv/PAtKbd4pb7ZmYKOulFWcE9muF6ar4j2gPkHMWMYKvb/Bd6QRPr4iBlr6ymtSUf7KQPE1L12R19/59KPoFLPrjkfHUxDbuFtUl51gkP1iB8l4/8nsi+edgv9TFDFQq1+rGwKwBGNzfGAdjhu4ASp2agZrltcyUiNeW5cPM8+6J89eZalUeNweFzzYXbK23oow54xLCaTVUWvGp8RFv2ahwawSx3LVHrscd3w4ZNYmCH+Q7ul29qf4g8VWyEonwisq4IpxDBDZbBNIV7yBZMw0vExpRt+o15YC3ZtgJwlt+1mDXQkntS8d5dsblD1PkZ0SG8OAcmNASfnnWSzfEd1Tt0Nme84rIwKUClNEqm6ktkdwjdyWxyo9I6PsS0/iU3XJionFN7Q6xGekBjcax9Z5zR6zOehr/JQNHHfdZgw16lvF1b362jPRWE6g4n+FeeulHpek6/RccxnZMsZ1GKDF/5BsLJpdIOhUz8TgAx6MsixGP6q3x+7Lc9+ZuWpCWWzNhwW1nbZVW7mgSmOpU/7/SF7BAU4TNPfRGC0PPDPGOayzdKsx0nNNLc9hXa9tHzbYKv72u9Uf0jOO94aJ/IYANVQbm6hPGIo9QdwExLgLrVds06U4UrS59+51AkMHi7Kpwoq15xEVWzVTu7+F3fJgbIz4dfu/DHBFFasCtplo/SdXs48N8KrADbZ7FU8AWp6AibtOZADxJUNk17NhA1gNaiuuWlLcE01YhQkfLzJbT3YEDRkRg+qst+VmdJKuF51hM27gs49uggE25F+QGR674ZYs6iBPyggs7DhykC1g2T15oApPF2VVbxKb91Dxu/m7Hx69hbtgnWky0oh3HnhhUOdhA45A47N0IHuDtK0nRCFsBEe+oUGJTgJ1SAASiFgS3h6wNCt4yLFArXSN7jsrBHnP5n2xY8FIQWMypGNCaHeIX3TBYx3lnwHIC+DsVsNWFoANWLAyxsge4cyKkIyMy1YWF2w5wLKV0fWwAHHEBrI1DgRqaznC7kVhamNDOgGYLFBoEHW6bXXG9aoOeBwwsB0L2sEYSIeOB3kDsNirb2CPWEDSJwNsXFaXGwlMOh42vcD0zbgatjJz3Pg4sfHKP0PyQoYHyv+JJ7LBDMPaqfyCstEfCuB6/PSgmuCBMSwBRh0cBogtKb7/WCQ2wTzcJZEPCh/duDItu9IIDIyRCzGQAxzSdazlAlTeUSeD9d5xLV6HZOAGAHHB5RQXXIYB96myNmAiRSA6riS7BcYesWeoPocR+WmLAJraY590uiy4nGd8QGFynvHz3/9GeMceolI+eRofXqfjccQrw4g/jBFhSGMh2ktgLCMyQJyhh8Aw9QAAAxlJREFUQQEMDip335RYOWOnn/oXQKbxGRQ2EcC0zPhgGHE/DKvxMKysiOk8JnZSBYGrQQMdswbdAQJt2D61i9UDyUHbC5gnX5M2hL0Pn8aHADBd4LV0D/d5kgVs4xLHBGoCc1kSOxnQWO9B5BzclReehYcNmtxhwyYwr0Uy5TQemzJVyBkbgem5Bc5CzmrmNgMH0WCljqlXV3h9AHDvpfD9GiA3IWyiZIA/fD8+nAa8Noy4n3OHNEYZ1OR+CUDuisOwJU5L3BjJs2agBJIIoAHkhPnsCj8MAPC//73OjxiBZQaWa2Ce0/G8zibELQWnD+4ecoxjIGbQRgM86jCbBFfXzw+8PfLh0/hwuthAzcNAyxTuajk743aNn5PQc9wAiIx9GNbwMwzAOAHDtHm0ZcHl7z0ILwYA+PjX8cnFhFfJpwsQOZAsG4tsRtBnBkuBSL6eYmBSBwIwX+F1APHeS+Hvbmzkb1A+eRofhjv4+zDgRZHxUlyl8Zo38CJzxeRiuavNWSsLP2EExmEFcRw3L/bsU3z3xZfD29nLfvLreDlOuEeNL/Pa4Dyvncgpd2qQvKwIxqM8HyhVVswDgPkar3/embdHPnwaH4aAV8YJDyhh4qDm5Qo/V+MaALE5M7CQlFnJxni+xsdf+3pYE1XqyEfvxUd3XsBbZIwC97Jss6lYG6VPnrzojDc3kNgXZvz8a2dIVj7P8snT+DBc4LVA8RQlqGBjzJconCgYpJfj2X0EMP8Gj2gsRd4pwASbRTSTsDVIrYkdFpWxAl9813mqaNcLQOQb3LUSoDlkUeavcouIzaVSOwJIoASTGtFpM2daEAVAnHF5fY0PXnz5y+M6T5UPn8aHE4DMVBJFkDy+3KMNGzcsEAEDSJKP34+vX9zB91gb7tKDrl1d4Y1hxs++7K7zVEksfW0Y1vUpgOrYEoDXz/DGvZfCq5ZNF0hgZecw4JVhDeD39DIyRlzOV/gvrK7zK/YdkE/ejw/DiNeS27yvEZmv8XFc8IEHIEkVSC0fvRcfAcAM4A8Utb+S88j/vBcfjQDGiLjHs/0/I2joc5o4tiAAAAAASUVORK5CYII=","w":114,"h":180,"e":1},{"id":"3","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAACAASURBVHic7Z1NrzXLddf/1WdfX9+XBL+IxEQONrnXsQR2QEFJRgwQiJAPgLAFjqeIEIkJgyQSM4cPECOYoWQQ+xtEkRAJEiAFB8d5ITjkOhHYyotFFBL7+l7f5zm7GOxeq//rX2tV997nPLYHlLRPV1etWvXSv1q9qrr3Pg2PHPp//szHcLr7EXztjQ/h2196Ab0Dz73t1Utmhx857oUlrdufvsZBRy3fY34oDymvyrQdVedmmc8yNKDVWdtRhVos68cWRVL5WTmRaVJv43zS89XXgbc//xpeeuk1/NlX/hR/+id/gh/+u59srf1O0burQzVMV4X+O1/4CfzRlz+Kd7/jwxHa9QiOowAbm1wlD5ahOgCRyyZJaPE4MSD5SfQw0Ncwv3sF2ig3QKhFuIzAq/C5fkpfFPhEpjHM0sbWRqg5Xcs/efoanj75Vbz55Bfa3/qhnxs7dDw8COj+Xz/7Kbz44kfQcAHj3IF+Xo/ZB4iwahok7YBFTy0vomxmffs5nvPJLRB/w0Ir4FaoAGAZ4c+sdAqkyCmIbM15AjVKVwvdGtCWy4QxuDneGnB3+kX87//1u+3v/Z0fPzwkY0+uC/1//t5PYcE/wdffeq+DfD5fILlfgYaBjUt6F1A1zpZU4S8h5zwU6QrjOfE4Zm4JyRzi+qjcGlJX4YjclWCrsgBiYpGDhaU0k09B1jwqu7StLQbyYoCvHwb8udMv4gOv/PPW2uf3BycZhiOh/5fP/CheeuFf4nR6ZQP5Hrg3y3ze4D6fkULrljlxK7L4mShTy37ID8+sM98dRIbl1FQnjBcjVWUkobgEqWcwAVrT/LiIvgxUVpFZ1yQttdwSH3RR2WVtl8G8NOBuAZa7FfY1/803P93+5t/4aD5IYzgMdP/d3/tJPHnyiQvIK7D3Z+D+Hlta3+LA6HIwiAPkSfycwVnAHPxpsc5nAaxcfGp5Sa5cmmGw8uQ0VFeg9HU1qYBcraqlZQs7QPzma6BO4oukp2CThQYI6rsVbLLa909fa9/3oQ8UI5WN0jz0//brn8ILb/8IOlaLbJ8O9PvNKgMCMYp4Brem4XIeoJ5ZdZCcHjPYgQhyB87gjCG6u4CcJJUhvQKSWO5KrAkMpvPKljezplXZxAJn8O5a5gTihfUkcANksZcV7hXw118HgI+3H/j+6aJxF+j+2d/8FN7+to+45X1qMJ83N0PBDK6BfhLZQY7TWBfyfAX2vB5hZRHzwXpI5hDIhQxykd1QWujiZLbllrkQXsZgpIIMoyVPQSX9nn/QEmduRzYB2BVxoFeoWwOef9tPte95/08XozYHOsBsEN/fX6z0uee7GUA8NxnQeWad00nAaUl8ABsxzTtCsiA5BnmAmwdCId6x1DcDnV0OAXRwRSiNYeXzzPJ6OQE9s8YmW227hbRlBDxN13MFnV2QO+B0t7kgX/1qaalLoPt/+I+fxHve82PoAO6fCtAM3cxCr3mzbbxhMsiOCLscCnVmpR1M2s0YrHJm2bHJeJEMbtY3ZCTpO6ENkTEt5byw2nzOgLuPLNCaSLCsrJPcAQXPdS0Rat2KY986tcyJpXaoF+CuAXenC9R3d8Dbnv9Se+V93z0dTg79Vz77o/j2l392s8xPgae0ADT3YwCZLSwiyGfO2wHb9JyRWGWGMwF18LMhEPbxnE79ZAA3kxtG7oCMBLWqezLB6kpZZzCDl8+LvMWUcByFBbWylUWWD7sdJdjYJge7IMuyLhRPwGl1RZ689YX2fR96NR0qDf0zv9bx0oubz/x0tdC7EBOEwXqfN6j5PNNlgJ3lvPKvNe6ylkdHtb4ZtAOMnCb56SLxEYJCngEd8hDB5HPOD5Ohgr3FeOZHmwyDGWQoT+UOWWlEsHkHxKz0sgBvvPHp9v1/PWzpDUD3z/76p/DCCx+5wEyuhm3ThcWagXktyF3cEMDdk8Gis97KAvPDksSCD2XEkuqiUOFW6+3RBOieyJWhJVcABBnJ0WGLE5xaVkFnoFP/2OSXqNvgUsgHN6SCUc4D2Gtdbr3J2iv4y3LJPy3A6XSBujXgV3/9b7eP/YNftu6fhsF84YWP+AMTg9j2nYHtFh6srJ5n0E7SjrohmVUO4Mp5ap0FdDqklhsQ/TJeUys9y2t1/uAT85FPuoAtMs1k6Nj6Ju/WuG9ls/zlvLWpr4D1FbpuepdL2daAdl7zSH/r2w4GcDGAy/mSfzaZszViHNfz+TI5zrgY2bZa7O/5yz8D4MM6VJe2fnbdb75nV8O25sw6JlCyK3Jerfg5y59YaLfsCahnSb/Kp8Zm7SnJJ6indTmyMEUH2OX8wUGsdlj8iRznD2A3yQNZX5IdXAzLU6jXgssiMqvcQlZ8YQvNcst+vu1Vqy/tVrpdLPTp7rJQXBrw51/9ePuhy66HW+je+wfx+d/9iL9cZO9m9BXQCuYBKJJxkIHofpCumd7g2iDqBwRKscype6LQCviddPFR4xno1fleaLM0tdRqebFaTK6XoZQy7R4biH0t2zeLa5Z6Wcjy4pJ+Nst5pvcyTAelo12ui08ogxi4mNdVtq+AnrGW65f8blacB9LuDtbW+0t7ljOAO+Dpk38BIAKNX/rlH8df+q5LBWfbawYBmcA7WFt50w7YYBysOlnkUKav9Sbbdwx4aIcNbgawQOnyViY7Ipbz8e1FXC/ALSGzxE3iUkdqnekIkH9KZe3WH8CnNIeZrXPfdN2zZV119hVuS7c6+hnA4iy7/GL1gABvl+tsTOtk71iN2OrenM+Xdr/rnR8ykQ3ov/gdP+wN4EWcW2eLCjjsinDamWD1fEpnkEM+gR7qk4lyprhONpsUkPwMXgVSrbOCriPcZ+cHQmaNHUgFeP3DboUfOwK4JttFrrWLD+q7DyuIuCeIewT2frWyfQGWFfYzuwok29d6z53aeV4B7xcAOzYLeyYL3s9bPrC2y05ofHpfDW67tAcN/bXf+6n26vd8YgP6dHo1vCnnfjNG6C6JI5gMq7ogmhesOhCsdWaRM5j1LhBAZXAZbOoPRB4xeZCZxrncFaF0ORLr27mAwBvg5nxyK9AjtOYuuB6B2OC1xVq/j1C7T7zq6uYDm1tCcJobgn6pb8FF3trU17ae+3ZHsDQg3mHs8rnxa8CX/88/BHABuv/7X/pksMAKM+cd+ZjvzNAO+T2C6WCTvFlZy2PQAQyWXO8kfOdweUQ56yMoPXNBbCAzqzycXkH1sEUHBOvM/rJlWcRAZtDDFpzJ2Q7EqtZgtFu+gcyuRjuvfnOX/eY1vQFo96sec0tWuMzF6AT2Yt0yF2S9AAvWHQyDe5Wx9oXhoLE697WN/TKh3vmODwPmcrzvfa/gyRP4y0ZABNDOLQS3Q8/tmLgWbHWHhaMCrpNE2sK+uV18lnH4AW9oaB9D3D266ad4yNSx0DxcFwaeW0wLwDeCtNMRlE5K23pLNlBNcOlbeYAegmDbbmNXwoyJ7x2vcawQ2li7H64WenUtTD+Da4vAcA3IYtudBIhW2q/pujBER/+Vz/zoBejX33gVz90hvKBPZQaXo/ycE3jVGp8xuCipn41YnifOMOkorukQGSSynuYjCp8AbJHDsY9xidZ0tzTqCc4eW2pOQwQ33dFYofDdC3IvzPI6sJTfQS5K23Y02rJZw76CuqwW2haLZqH7ao57vzC/0DiebY96lbFFoFlp85utHaaH7yAA/A5uOtsdsDz3Ixegn3z9VZxeHC86KB4+iMCxlbNZw5aVv2voPrKArotF9Jif5XVpm3dUtvOC5db+gPpJ+dMjC7vSqONoaOVJtKoD0AwlTTqTtf1it27AtrfbN9mwW2EToG1Q++LvvAFvD0TMB77HBjewQn8PYNng72sZ26pDX/WYFbcJSAtDvWZuuS3N1np3a73mcrz4YnQHvIApYivFANmsIyjDa6XyQKZ3XG4/INDOI7RsldmfDwtLahvvSxtsFeyZRfY+s97s6H9qqG8GmqyxnfNirSdpBmxwM1YoO+9amLztbiybLO9WAJu1Nb0Gtj/l69vOhPnIC8Ft16yti8fzCjJD2rCNv0/G1f3oZrUJXrbOnceMxh0A3nzzr51iosCXfVg2hYWgcHB5wScfdUV4K09fhtL9ap5MYW+6aE/pkvDYJDAHuQruhwa7ePank18sYIfbLx2tKD8oUTekmQEQS2zWtWNdwBk5NpnoYclirKwg34Mej/POB3dtlTfjs3Sy1NQ3di9CX0FH0yvX9tu+7YVT/8xnPhbHVC9SjwpsoXUmZemjaf4A/tTxDESLzv66wm7lVI/ADK3rSphVFtkxGSMdH5Y/GoIvnJwHd0PP1QID6dM/9jv56V9wL/oKdSerjS2du2VbcEvb4mFxZ9eHHpObtTY/2eDkcbeJazshJueTam1zGCJq2JkfrPiFp0YpzJvglhZAISubuhPYwFaAs/dBWCbdATF9AvOey8F9hchD8sKRxi+A2yV6BdRsXS8J23m6ZWegsZUGwb0CYDsRAWq2yGb5yTLbNpxbWPKf+SmgbcOZXwysuxxruxdbQJqvDbg70TvcveBtQb/uCz3wWcfd3JLgeuRjfMJbAF60HvEFxwgPW+XMHw1AKaxdYO8Co8CWPjE8k78s+ei0YMSoDyKXpfuxApvY4wFNB/cI1AozCFBgsEb6DgYDapaM3ZAuUFu+wtoov5vFbdsjaPNDvO8GatsWnw4vjx8VD8DamK3tsO07vpM4yOJeWX6juuhajq+PBkvMaZTOwKQv/ScWNgOYt/gqHzvAjcSPlgkHziN5bzvVFdroI58ATuPC/IU0Hq8hkgSxvpbG/rLldxM3d4OttJ0TyJmPHfZyTc8KjO92WJmVZPO1LQ99s+BWr7sHPA7n+OKRj6+NtbVvle20YDRXxK05yVsfPG0c5xFoFhiuh4DmyXLbdz9Z/V1TKjNLYQ8vLkFkefHHFnzVPduj3nM9AtiI0Ps5ivMM6HQQEd0KSWNrzPnDNp24F+nTvr7e1hFlzhQHtucj1lyz2gvp9KeAq6DvH9tuBjY3pNNTPncvl60PJuMTRq+Hya0Tj/NsQrORJYNz8gtj+Z0EUiiwCWWuhu92cxnaq8587LC3XFh83uqD1MtHf3JI6ZmLof0p44j9CUfEY2kINJAAA80eCFtiYIPP01qEW6Fe2uWtOF4gLthgtn40eRPO/OqGDVov27a9Y4bK3B2DtgPDW3b8RNfftLM0AtitNFnjcZ+OhpIHO7gcchX8YiUAZb60W1NOJ0WZy1FZ59kjcCBZaFoeATWAnzxx1P55OyH5lI7kGIaPdB0JBqdbZ7XM6x9+wcjOOyRucDfZmkN4Su1uxxIS4X6xguYTTax0pzbYq5/o21t09hKTuxG018w8mR5+HD8YHHY7aMz9ul0+J9wt2/A7FAp3kZbB6+nkMjikUkc2KUKaPoQh6DErl4G7frIdFG67yULLV0DP4gfC8HjbLDWByvvPwcVgqC0flG+dMUvZtzrdtyVZt9BttcbmIzfagsPmkth7ycHfBcJDltTl6DHdQGXIfczpLuXt9cGSwBaaTbdaJ1bGbsbWAuoAEIE6jzrO8umIfjNIBzRtrcR85exhi7aVnyDagRezWi7Ujy1/95iM5V5oTeJ0wdg683FN3qAl92PYoTAL2emdC2z7x8OtnW4NLoP1YYr1jfac3fKugDMbHRuo7nKYz8wAY7xmPC42CdxVwuZbsyEC+9AmaHkKb7jgIh/gZcBMl+0962QgeZ4Q4b0OSlPd+o6GuiLQ9tKE4g6kMAvYwTVJQA799T87wSC100bHHo/DV6ZER1/jNiF8kWZ6GllpArd3+PcBrdmLXRsC3t+xoLbwNpy9bH9eyy66c2F3Ih57JGk0aTN3JNXl49fjgxWLBLnkwoQZhfgZXhGlY4CY9LgVZiAnH90qBENKjZwBPrglE7DDeMsFCW5KEi9DExk9x3ZtncEEanUv+B2Mc4M/0mYrt1Bd4SGF6V22Sv2poD0sWSeGv1hEbeLvJVpbeML7+DaKaxp9WpLXuBx91hAtdBhMvqj8AMNG2gnONbv1Iz1nExfQ2E8+c72mQ7bi+AJ11ceTh9vEEwGbjN41UpipHm0H5wegQ0SC+s0gq0vADkTbqbgmfJvmN+k64O8mq7VlH9RA99/F6NsL+1bOZNhS+wToW1286GvrtTuDHnnzpVGQ+RrKwxa+VsEdodCB0+XNEr4A1UUwpUg+vWiUNUz0h0nSSe8aZ/Dcyme7FAKkf7Ktvx7boBY5AzlrW5gjGch9ywfleRBLHPxkDPyGJ4HqJ4fH2NZGAsBcDR7/TvL8uxpexuTsjTyTAcFMk8bezziv5+bm+NiolV6vPQC38NH8ygDQMIZdENLpfaserPDFDRr5MxQa0/1U/GeGn/9FxNBAacdg1TmN4ArQQ8rK5IOcu57JNl8AtzoeCG5tQWDTkXc3AtQkbxfa5H3gCUT/kZe2MYMVrGHxZV+pWnX4AxRsW3P+w48EOPu1PmY2UbvIqAuBWEYZsX6wbx3egdkG/BTOmUm+pZafjhGUNe7vXLAs7XiEIHmVu8H53NgMyMw6exEum0wItvzD+yGI+RnImQuXhZbEDVa72GwhhxeZ7MLSheYFn+sp/GR/oNI3i21Wmv1h1sFuR1ikYRujsGgTlyHcMagfmVW+IYiFpovMx7TyBM7s9u3pJiPW2h+TY/RxNd11MnQ6GzPQpW2Dq6MypkLqqWDOxusQ1Axo5jOvR375iJ9Th5fwkYC0lj2LjL/vjCjLTfEffek5zNY/3QWxvg++8drWc798BdDezutnoN8V14keo7O+cG3pWuOMU3Chs6AADgAgVrQVHI/aaLWUVl/eEPGttfPY7gaur/iUECdtCt/kSWQzsCHxKrhVZj8Vm6/sfrLJYHurDdhk2K80WWMfPfqeDi7R2/i8w7/v59tzPX7vj92OLunuRydj65OCjvxQRi36YLFJRw4dTqmlvSooLDRj1I/VKcaWG6CyHYOrkfmwoXppA3/8KSWorPU7g10uQuZWVdY5WIwZ1HRL5/1nffFevwrFT+GIZZglDeAStH6whyAkN1jwvqXzF1wVRrXYw+6DQspDkqSH6zNzPwrYgcm7HIMwb89pdgbmBFzVHSybpaGGmhdsXiiMyHA6TLrBgkh7BqCpba6OJ9k1QB9xNdY892PXC8hP7zhft+Fwjmm2wPOylq3QrRZ8eJCRBIV7Gxhs7gJV4Xeh1c2IyrajuheDXJMim2D0oa/2ARnGDNousoigKPSDbiBswQ31nIci0VqHxO0zJAm0Qxu1rACsPnXo+t44rvlhH3qFmi2puw38oATYfvQFGHc7QNAy4AzEqpctvYNMD0/UKvt/qZWJ1DPASe/2CDMajGG/korxGPObgkmYvOCPybWgiztUjOSjMGMb4/DdxLXhwRfGVpeVYT3qToQBkHKsr/xIfga6W+kEZlehg2NhvXANiL8c2glqhszqsgvtWxNy7RUGvvAtJG0NpQkSmmggQ/zvpB5n0SBOoNyEqB+zsGcE6lDsQ0t8AIVkusjzyZBe+Oulde5Sb4/yneUDsdS2HuWHL9YmfRwGVNK4baG9FNcJHwprIGtmVi/1fytYMKaHr0mZu4LNki8tlu/Ytu3oRxDdoOp+NMt1mjz8TnNP8qr1XLneosmQ+tU9iI9v2/GCpww9b5TqkjojYCpDkE2r5g4I6NyuLmUGP191QD5Zepc6WIbzZOJlQV88Mvgyt0Gh7Yhy7nJgA9YXmtIOnzCQNGyTgO8UvIfdrezaXi9HE5GDjRN5GeE6hHEV8AdFRyy7A93DYdOTgDkDOSvLjQ+KZmXXP3rcK8tyA+x79ZazczxNF4o95lkbZiHsLwPjo10B2cvtWKs9S2Z1c5a+XN+SeKYze1/Z3+Uw5drexHAN7NFnqFbbtAld9qG5IF8gb2SmeJhmyQWcQMiWLIhPZkywxBOZKUgJ8IPPfW2epLv+ou/hMTb5lm5t7YJVlqoClheDE7/X2udyOxZwCnWh/4ic36l5Eidlhpf/67qWLcoQH2hbJeiNVJgV1B0rtmfdMvkjZXrH8PCGm1wubKnNo9KkjjXd2sUPaIZJMNG1m17kHR6Pcy7HxsOO6RjsXMeqfTPRI+IB8C2cBoFdLc84hEErBjHbacgUMYwBKMR43og8+YjP7fUz2KJr8Dk7ZyQVT277U+sqL+qXcmyxKS0r1zFxex4pXMMjyZ2GlNu179YbLnzIP2JJsjTVIx+TudbalxUeyU8mjgO9Lvr6UZAtfwLOUaYyYCtXZPhaVtGMXf/a3gc54NaUOtr+pbC2AFjw+us/+OCZlvGe3LGOKbLDlRAeAf4bGnqMXuVeXJGvE3iv/C2u3LQ9N4zxwMoRg3asngXv+gvvur5FVgnm/XkoUA8p/k2FOQmpzXiGt+xvZDg61IMc3T37HkzHwikd1EMwXFP5NS5FZerttNDFd8lvCZjtNgu6LdOecZCb6dipg/efbyl/bbjRc3hGwkO4+NDf6obi2gHJtyivDATkNfnDOwzqP670hQch2cORI3m39ex42Nt/vmHChAkxWzfM8hNRAOjZjzVmgg8KhaJ0q+gaPQeBK8dkVn4vr2oPqF+tqLttoA7lq8Y+0Io/syDmOuzNS/+f5aYIDd0yFSxD0bpqF8MzpRWla6A7AdeGh1zka/MERP7SKsPL6eH9ZwW/AvtZQf3ACXHTdTqy8zTJ5yGS6msLfUtFjxbMQlb+c2FBD/nOt1jmiVUO/2psnaQGc2mW1Eoz7JA8bcfMih8Ed9jCk3K7TwY1zMzvxP/rHXOb2uO4HDDz9fvQ03ClfzmIUr4+kdpZE3rZsq1XADs8JOnJh9KHSSblqz4MYb0wDo6Vk4kz+OPUj56lUx/LCVGFB94RH+JS6Fy8ao0QhU5DnluHZ2CJh31YSg+NqKjeg/UKC1tZ+2HBwmU0zdwFAxTYnqDtXOHgdpCuo/51o7LDh6Aeil5hqV2Ou2T+8aR/WZu8PVm7HjKZYkhe8Kc60jYTAOksmlnnPes6CV30zurM8sKdjy2Y3gazdEprct5BBmB2YSSfIQ4uCIMuwKYDXpkysZoKfDoRKE8nRFau0gvEu9whc8sTbUfU9CcqdnxotagFOFnnIGnhXV9sg80Xq/WoC5LHnQmzu8cyWXvds+nI+1GA3CSNJ9bwiiVZr7DKV7L4lABmsIPVbDFaWt4C7DSQ/OAzz+C7AsxvaNlLEKAfz/SPeq/wuR+cV1jfMJskvWWyPKEZ7gSE0kBnGQw7W2dEKxcsYmEpSgub9TsLB4C/Km+mcy9vL+yX3f8KVlB2i199K8wVfJaHSd5ssVTo6UkagOCa9DU/fRk+851nboiAa0e/IzHobKEpb0tMdFewXwv8LDwLqB9ixR3obzXLfMvkMYu140r0JI3l9GcBhoVTtijKwN3zqQug7Whgp24IlVdYtY7KDRlgp3qz9Kst/LPKm+ffsA99NMygvCGPgaqsbChaQUtCLZHrWg+DbaAJ1G6c1RfdCfy9P9ddWWkqo8CrznQxOVR+Xfoe8OrXh8mAeV4a9u4aed4O0LdYyqTc0Pk+ds4voCzwLC/dGcnal4DcSLZRYlc51kf5g3Xm+LWuBje1jfHsKaOnt9h+BSodB5EJoENP8vKH0vfKFHkD5Cra0mg+IRoBrQp1F2KAMqvA8vqoS63j0KtrF3dJerp/noCbwQ0g7E2HHw5na30Q1iPBdVJ8BrO3jfNlUkwXklZRi1G9phVQmY68UzfkzcLxcomF3is8g+8WYK8sw1Y8yALjAxpgsMDVk7kmZfQ/r3aO37IQTNLV2voROczBkDCUBPKWOMkXmSxtgF2Ab5WOoXMH0x8SNp2PtG1XQTnLmwDLFlIv8B60fkGStPB0kGXYituFz0DGOEQhrRKApDdJKkC242C1KT4sFNVCY5Kf6QBlakgmpFr3Wfqu/r0wK3Op6xQSpooesMBLZzsB6xesJb5yQ14H6fYkkst2MyoLHXY21u05tsAMtaf1RIaqayGSj83Qdoln23gZzMOiTHQNYCVAVdt8WbtL2CfpA+xI2rWTdyCc5m87CUxeATnY7C9nRQOLFfwVsFK3RbwNyMGtrPTwrnIG9hof3AqqIn2PQdMO+NrZNhyn71lpznOQE+CheSA9GGW0jSXsFcBpZyfpO2VYRCdti/knLbsJtW0xZB/7kfEpmLPZe8D6+oUTkNN3LEygS0cT2MNvMfctjyeo7mpkj7QPQXvDLgefM7wBYjsytFaAoWtRZwZ9lZ/JoEhTyD1tj4MsHBivA6HYtkvgu3mnIhHjW38YDIIqFohpvI3m7VM5hhVxQoRtOJPNrDMS98Hg5k49YOcjwMftLo4zd2Sw3NzOBPrMgnP0qLtSwp5MFm7zOBiJ7jA4u2WO7XI4zDs7FaHhSUcakL81lwAK08GWelWS+dm+t53ACiBY6OnTP+4rHyHcZmAPQvuB2xwApvjUBRGYB1gVKoGmtNBDI+vrq3J5J5PkDHbut6bv13FgUViA6Z3qSdEK2iLd/0m7NWOtc/aedBN9aqHVik/95FUu/PAgyR7eprvBUg9ArxGFWyHmNHZVBneD6xC5ChSeFC0kJo3P+MgmelZ+ll6I6WSSoqeQmMVTL+Kai0YXWxsFbDCrLJdnS53CLm03CFne/eS1U2EbkGSyR9plOAqwLFa13aGdEr92G89lSC5Ap/UoHAm0A0wF2EO5CvYK7CzMxnfMmzz6rmguKd+yq0/phwv0AF0oBV5dkLXc4F4keeyWlE//1ApXRwrlzgdyebWGHm9jfHehuANz5l8rbNqevYXkUA+SOoJCjGEC+1Ck0oEh/fqXkybt24dW0rwDXbKSsg1b2rB4ZFhBVth0rbL+WxJsgdWtQM7gwPOeqzGxypy+CzT3vziWMEPyExmVm271aT7JhNME1hScHZgGcZIvisp3Cqkh7NMego5rKdwBnY2Dj0wghgvXx4kytsv4xAAAIABJREFUwCryBuywq5HIZL5y+ObJ3gJRw1FXpLpoiP3bhdjSM5kMdpYROZXNYDy8kFTQ5VPJhvSDYRXN96FD4sS9CKIEfaO0QYek6YQBMO45M4SrfJdzYAPQ4laWdzVaBbW174CL8dCFIAe1eI+yjWfpFE93PRh4kmPoPQ+Sl8noRODCs3Ki/zDsOnbX7EObAn2TzjpRWdtZB9AQt/GoXJgU4kdnL+F3kgV2djUSqFO4OVyzALzWsiQQczyMRXF02QTsYVfElGfAc1mrQ/M4X9rvDReZdEJksEqa1lPxvYZT+uSbefQGH3EvKiAZwqSsd9ZgTHSp22Bx7qjuWDigB6DOXAuTTS24xrPzA6FJhM93QTY5gXgG8wAbw9NGOSDqCu3V/Jicj4VMCE4bBubAWMqkO3lHqspn0PKpug2emSzu2B9vbbTSDmSSz+AbsMGn7hi+Fc5Q291kgJrCwOWe9U4LHQvXAM3xGcSen8mynMhq3TopQDqAUc+WGHlMF5PZWMik0AkX6sjDxOUooO2SNjxylvImky4qscl4p4sFoO9AEDj6b4MZbG6nyfC/O/NAVjldAFYW+RqAxUXioAYgsFGA7OUSiFOwTVZgHoAtgAfJeTJPiJ187qt+jgTXn5XnNi7yP1ayyaZwDa0TtwEKr5azxjF8LGMXgPxi3YZTkKdP/6xdAuyhnyDgUNUxUzABebDIlpxAzHEGeWad7TjATNWzVR5gZBmeaJwnOg7nt/J00LOXLqe0y8H+6yxYB3ts9PCOhsK9lit+8Wa7IMUC0HxZ3YZDEz+5TaBGAXVilfd+7spC+cXYI7NELzaiLoVrAJnkS4jbJh/gJbJnlptB1jsBkOjI8rXNlYz0N5tgIXMMJwcCEJjXC8uKDeTgNgjIPhATK80y7EIE94ImAoNtICKTE5djgBoY4ZstAC37WlfjCndE28MXkM8V5JlVtiOXaUWZdLFYAU9tq6BX+Kr8TEeQGwaqHifKOmkdYQB2rbXWkBUiuK3x4atQlm9AmQ4bCPapgeAHp7saBn8CtamZvq+R+c7jaZ145eIwBZgiFciVlc4mwBGYTU7dnAByIafQ71nw1MKK/jgYUWYIWz9OWJYeb/OZAnEvBitHILfkky0cgxUnsC2PQWa3ILxcZHIKNXKonbUjC0AL1ywKr4QZLK5QtzE/A7g6lhBbeiIzs9weVeALUFNWivw9iIOvL+Mj4YSXXnoHvv71WCdDHNwLXdwlH3VbejIZ+FcpWwP6eQTfO8Fgsz8ti8Sjj7QPAXcLrDfADC0ygTgFmtOL41GYwXJEj/rXLKNt5+usnQxAJvlafm8xWeg64WtvfC/ulqIiVtQlqc0XeAaaF6VJ4oPGsGIEFirbNr2DtTaoK3AnC0H9xVDPOrrguxFmGxY94TS1iJ5fgcxyCaQVzK2Sk3ZVwIN0aV7zwtJXhngYjFFHKbf15xQaEPIZQOSLO6+Q5WQCsDX1fIG1EdgMrEHlF8ugBsJC7cjTv76p9/Cs/OIhyJihPg1gAnOgOT5ACoIhgz+TTaDPYA+6Sc6jOhkYStGTlpUxSIYoXEuSPQ0NEB5jo8jiBhATmbDAq/IZekT4dN+Z64TIG/h7UJs1n34DxUIB8eE9aMtDkT+5aAEcKr8HMpetYFaL7LJJuQzmzL+uYG2SB80rwPbxaTGZ+69l1sMpDmqmNLPSBCpb2YbcQjc6H6ywgB223oBhV4N1DU//ZoAiToI0ZOUT/3yQz/SgyKOQujNAuHBDfI3MQNZjBv81MENkXU8iw+1j6D3KOiR/GIP0RPodc8b/scLxmZW2hmVbcMjyERvB+8bWQXUvBthFxuPiVphcsNgFjJ3qaa1mdAgzmA8pkIuq6W08H4BGAjDnTyBOwTYFmsf5rI/aOcDaolxmkRviRwchiCeTJtR9iSb/SdZy2eJOfOkm513KZxba3RWWZR0ml7gUAdKWQM0W3do3WQAOQaxzGq8Ct3dHFKpOAabIDOQp3AfA1vxURurw/EJGQda+pQCTfDUukHwdJzT51jdXlv2wi14k9ZPTBaKAzP9EptzVWCvjl5oUVgUsuBOJ65AtCmcuyvS3nh9p4TiIK8DryRRois+s9BR2mRyVv7znXw8TgtqTLfaYt8Gfxlh2OlaXyCk0Igj3WJntVAyWR623NpZBtoaLv+1+MEO7pg/7y5VPXcCtMtnXqWJB7eAk/Wh+Ea4GGgXILJeAzJNAIVYrPcBK8s0rGyHUBVwKPKdTXUEH68ny41DpIOa/PhoAJVKHBaDmc1mrKPO5SQ8awn5yX8v4hRGo2d/luG/p7fjCzLKBP/0lpL2F4I0wW1uyRE3PIOZ4AJnTGdIkPbXeOzArpHt+M/e1JSdNdezo2Toc4V7rT3xoLtSpkMHIFRYLRLbC7Ja475zUwXcBSzc/maE74itX23LTJ4Yzv5pkboJXb11jNAS9gD4mRZxBaMkxS6ssstV/BOYhX3RC5aXtqfWegNzkqAO4hAcrosSuuyoMFrptggPYBCADa520CcHQokV3QV2O4UngxFfmuVdyuOd27EE+A7yAmNNKoKXMALGUVx+Y00qfOQM7katgHsDWerldom/masRORn2bYsnfzrfvFA5mHRuEDgjTISAPC0CyxD4JCHjvXOZSYJNXlyP8XBdPBLoDsIUPOygV3Ucsb+JqHNopmQQFN6RTJIO4ig8gc74AOIX9IMyDz0v53KYUSIFzAqrLWnJq+X2XI5ktmXthUDfJQ3LekvTSWht8pJthVZeDH6gEdsTHZlfDBkPdk8xf5rvEkA7Mgb0G5vRkDjSfp/70QZAVVlC6WtJdmJvo5vq4XQok90vaH8YjmTSav2adhgHYpDaAGsQCUxs6ncyAdR0MaDJJeJ8YVj9Bz6AO39JO+htckMTqp/zd4ivz5D0QBrFW5LX6PAWaZQrgM4ghx9K3pnpSmLk+gbYCnngO/Q/pom8A/3IeLTQLZy8MOcQyUNl7zcENaSTX4uKvAflWnUFKsHMju3VK5A8tAC0kVngqU8klaTL/h5A2qRV5AvUM5CxtODKYGdg7MJfQqy6WTdrtRbJJwuUV+hay+VjvcjB4A6zWoMJPDrsaBp3KIMqwX62Q8q1+AFnavevXFkCW72tkOh4hlGqy9l8LNJehslOI6Zj5x6mb0sZ6dWKksGflZnLjcIQjhfxJYRUcbHIndE86czvA5ySjltRhbcSe+MUMnS4A2T1BduRwy0LwVpkkTMc5yQwQk4ISZCpTHkk+9XUL8GcWvII5wM66kj4M/nU1NiPw+S/4OwMCZQXszO0IMK7p1YMSAONuhYBr1t3bIH3m+MB1sZD0k5kLcuukMDkewx1xvsBZ2hBnvRnQWX5xnPrY7TjM3DaFdAYyC7Uib7Dem9z2+uhw6+pSWHxqdRcC7IgWM8gw1CTDFrj6ZSOz2GrZmVr1wWcg7vHIrs7VMMudi4NeCA1Z/hRiiacuCR8TIPUYIGb9DL5MApUHyUHyVZdaJYZ/gB6j7JosPjQXXCPDL3dyA7I8+vCbetkCsXz5iOL6Nl0IfZTNbtcsW6Yx5IdJL/IwL9/Kkzo/hRgFvFxO0gYAJR1ynMGcyUzlmNIirhPCRbi89muTK96HJmCDhd2SN0gFVP63b9aQAC4Qdi6qb5d4H0OFYn334D1qWR9rIXhQNhVpRX5y4a6yzCxD0B2yzlxmLVjCvAc9gyp1DjLUdQU5jIUy0JJvrBhA6j9nYDOwwTwTlOlWHbkS6n6EhybsW2OTT+GWYzhVWVYI4XDmR1dpk3RrA5+XIYN3TSiBxggvx5vIOzgToCtAVU5hHiYDMACZTagUZGAAOeujQH8aZp0WDheDwUsq920+hpMBpcmSgrzqDBbcOkaTJDPQfNdoISEKDi7FHsAcroRZwwGREV5LbvX5rmXmuMCcgT+DOUAsMLvMDFa6cIN/DdKlEwiFHOvW7xRyZ2wxkz0pVLAraG0rDpyPLc6QDhaX2qS+8mwBeJUPPQsq/wCYr6kWKIzLePG2i57EU5BF13DEBNDJRPD8rNxETvV5P0TedbQow2OzWehssAwSIGzDDV97IqgZ2uCuCHjsUwdIBczyfY01uOWWwBNgd4fjGuuchVvKHAgMaJU2QLxGFNopyJzPx5bIMogkn1rTVsvtwcx98agCj1wOw/9Y4UwrWPnTap0RIbQySwPOAjUa0BcA503O7wyV9V3D7BdDQznKegzrPP0SwBF9Fg6USS+qRDKIq3iwwEsBMsvRcVHZ5GOy9lksncoHmKk+BZXvBNB87kc2jgvG/yTLnVe3w6BNF4ATqMOMpUVlb4OaEpTMb24NOJ8j08sCnHvUk+pO4oPVrtpzBOYjEBfpLTk5BDTihVZLvAgUCnXpitAva5Uwm56JzlSO+5ToZHlu99C/SzjBXogOg4INTIdaoHV/dQdqAPHpn1lmsrR+xMWaz75xsrQLsG0it6zxDrh17T0He7p3nYUjC0cd0L3QJqfjRTsEMccbLlC6nlYccTEICmQKKNXBcoMspYc87V82QaRtw5HKrInJ23YEqfrIwVq36Ev3Fda2wsoTguFLnxiyhWwXHd0uwnlrT/bCvlnpEBLo2qpqGtSqP9RVuSa0NOoJmpate7ysxBe66Apw5jL4ucm2sayn8ccqFdkwScJMlElTxYtJKkMEtORLsjyb3NgYkCA3QaykWc5sT5mhNxh7W401w78eTZc1xKJLA3oCb7DSksdpXr7l+bOyU/lbrHIWiotliYGFAmgvb9cps8wkb0dzR4JcBrEcGVSGUwFn+bbA/fPgLwu4OkHCpKOxogl3CrcK19c2oIN1NfBMRq0uQ28w0+IvWFZq+ALEhZxMluzhCU+CpV2sdEO8E/gAEYht9bEHaI64EhXMDwVZQuUCZdBm5xYfLDPpUHekAjmADoJKdDXgcocGlaE2VH426/T2FDAP4yFjgOBycMMNHmtA5ksT4A41qcp+2ag1WU9y2dVdCe1Yw0LNSfmZWOkM7F1LfWRhOEt/YEgu1CW91XIabzKOCrLFFabKKjOkPAlSHzvRyzBvlYlci5MrlNU+MezwiXS6bLHw+K3wWRm+mzKoKdSWx370Wj57pN2p0QYluyB8Ud21sTZV7kSSlwW7Fbsu0dtZuMu5pT0DmIF4LYb0lp+H65fEs8XicnChmEE7nPMHxVFYG2BmWLUegZknCY0J/Vs3VmiFulTQR8AZat6BcD86kbOZohZn5raW7Kg7Uigsf0bsFlfjGsusM+FAuSnQFEkhRg7vAMoOwAABL4CxH6vQQnQqjApw0Kt9EIh5IIa0S4ivj3LHOiljy2Uy+q8mwquiPGjicljo3d3r7alfcavPvsXdkiMatl0RjHqGuIYjrsYRmBnimWyR14oTTd+DuIpnfnF6pHpS1wLYFp0Ke1WmJTIt1jlYc85L0qgvF6CHa0QgDm/JWZxAyt7j8Lzl4gpYA33RZ+kgNyKBF6vsmaz9smw+uwdzk2zRdwC89HfyHhpu8avb9DRePEorgdYyDMSylRssKqUtCqo8XEGLuxQM6wLEBSLleztIFzXDdbBciGse98FfHzWARIkzRaA2IOwlK9S8q8GTwUD2HY2Zj6x5wLDT0SD7ypRgFojL2V3GDfhjuxrsi90aMnApT9MriDmvkYBa5iBXHblug1tkljaRa9uj8KayWTnSncmlsls/yeXQmSSLPnYpDFZTzlC7BdcBl8WWQZV9ubVTvlppDgOYZuont3yzGGE/+6Guxi1WuQoJuJ4lGQPEdJ6B1VjO8hOA02081cFpDPb60X3tUMcVMKOKJ2PSLkC3UMCEwlemUEPt8fVofrFPCCBs2YWHKdKpvmz6AeHE/HOaOEtLLK61G4hgix/dFsruUTQ9LyjTu8nRMLhMFCrXZwYwnw+Le863uC741j/BRQDBJ5NjkPPflBsnUxM9qYzCzHGuX/tqJ5eME+5OH3Bf1jPJn9S36tgCMFAKPH/til9CcteFFov6s1/ntQ6D3yaP1ecNOK/bdX2rI92LHpPqzCPW+pDiefC7XJbnf+bpTSLZgxSWCz6zgNwon6FrRR4kb5BNQB7OqR2sb2irpA2+99aX8TuF9nGDt54Y1OG7hQaiVeImeAN0sNhrY5YzWdcGtPXcrfWa5wvGNbLQxAFZ9I4J2EfidH6I00dwM6aWOETy9CaZLYtLPVOQAV/M2bUD4NY3PAEk2QzSRuV8AjGIyURRF8ZlIGkUZz292W/bJRWySxEeS6/KdME1fAuFwGj94k40etGIG2vvbZjcct6s9FaZCfuBrhIc7OEFpBnAe6GSv0aPWuED5RTUKn12nkHM8RnIASICKHMX9Ani8ESxbQvBCuZF6sgmCThN2klBXvDnwRFYTUZdiWB51+K8Y3G2hqxpvu9sdap/rRenwa13X31fdzUwhmXV2anj7CvbwnLYpjvqahyBebIoHUKSPyS1PH1YJCr8DK+8Juz5AghA/jGVYQvK1tkttkKvYPN/KxZY9TF6cFmobzphtY/Qt+1UKPjD1jGxrsP7HDSjusjbufm9NhEcZJMnK51Z7b6scgqXVWJBiLcXmYDVPeHF4x54R+RM3xFdGhTGJH8XaCo8vMyvOhKQw8JLLfay5WUuCChdray3g0HlNEi6yJRtHOPjN1bcOiOCHP6viXVMFo9micNL+i3ubhh0Dik9eOGFX1tWf5naF/aoGzb3Q60tTUgPGqcLobsa2c5FtZvB1v8mkDkogJqdZFRWmc+nQIOsq/2hsRm+gkVHt9gEp8Jq57wXXYFfAa++ufaRxiD/oRnzhdmPBkNKi8TgVqDwp0lvb0A7x1dGt5FFXPhhA9a/WXPeFoCWtqzmPUCnLpOke2D3JMuv0jgPk/xrQ6tV6cXUtBYS87x0d6CRHMm7rD4lRL5t5/BSP1JXg3RlFjdMKp2ECn0cD/kF/7ZB7JZ6zdP3Jhql6Zt1oRFmdc2vpl2KLq7FOTbOQ3jDjsA+Sxo6wu958BHYWTDSeUtkMn99tj/9kJCBO0ufAo0cYrbCA/gGJT0mzxZ7A6B2LOD1NMqDnA9xRF3cxuSOlfz66FrALHDwi9nFoMExqK3g8NooDQDOm5UODTsTuOu5W1hq1xnY/OyVMgfb6sgs8mr5fYJC4hQJ8KYkY5wMjxgUzFl6BfEQXyi+BzLDPgE4yJuspQu8gOx2tLFcBvPgjohOCZNdDoiLYRVYOjbgQwUCt+1KBBeEFn7+5E+39daFn+16GOAGJe9hLwRiuRdtei1kXzDUQaqgfYYwD83I4KUTbQYDHvzrJN4k7nenBOhQjqAFEN0NAi8FUOHN2kh1clzbEdIuh9FC83VvIJA7XccWfVPeToM0fsHqUlAd4e26tj1k4QclZ5Zlt8JeQFrB5TYBcB8bUXy02mSxUiv8WDBnunfKD9kFvJBx1fNswdgg4wUE10KvnaeJ9fS6qi23BGh+v6P0pRV4ahNPgGIITxvAIuEw99hRvrODK6LdjWVZfy9jTbeGmVVlF2EhX5r9UYa+dWzbbAR2Q1wI8uLR9Vscka0q7uctSct2P5AETtyDP8lPiyi8hWwGsacrDGz9+FoilindDDk3YNXdSF0RXDiB5Ge+NU+C6QAsmQ/thNMpd5LchuznunhgDMomqvncLShbZ55I60TxxaeC3eG7LuH3OCDQWh+O7mpoOGKZH7LjMbc8l7wM/sQQzcBly5sBDWB4cWl4zG1lDbRkJ0Otc+ULD3KIR4WZ+5GEUwA4sCxg+wAYvG0ENGz1UYXmjZBXctnRMN96PQY3w9pw3qysgm1poa3SKN31CHHZwTArPIAz2c1wy211PzAUi51N/Y6VctgwXvwmxyreuDw9UMms8tR10KNADIwLxcy/Dl2ejXFvyS/498gEv0HHMtktUJ/6cTBIHepO8rb/bPXRg5ZOLoaCbWXMKjOQYS5aQ9XKyoTVd7bTMhoeeYFYQlvkDdDSuYLAeYuUA+QBi/jVAe62tSWz0vphVyRzSZDp5MmXsFYMU75tV1lnBjn9qlQ2oyiw/92wWWl+L6P1FXAgPAlEAnawmtauMzWXYAtxbgydD1aYLf2kQ6kffWNQQOdCNdAOB+WH4RJgtEwoLxYVwOhmoLayemdQa+7l6XE711n2eUxI/jUyRreD05zhpgnRpcgCW+mObUHIvnPvazpBzE8C3WKbm0T71eDJQBMsuAUWT+BtlB0jidW2vj9yUKu6l6dps/MlAcShtCSCjMvrC0vB5aAyao19ItgESCy56gkL06z/WeYlFPvQCJwO3+iGDYJYuUafwe2wRD1iK89bcd4GWQC6/7zKOeBr/kKFPSo7KGpRs+8wKvTqd4fy2tcHhIn1SfOG66aToElcJ4JYSUtbpLyC7BCS3gUjqOEJY/IxmQFmgnYAOWZzmOxyBFMtYK+WlDusPvLgS7POFoVbg/9CKFtrd3EI4tAuKwts/i/l+2JPoOeLnL50VPnFRXomGspcVaCWz4pVAIdkukbqXrAs33XVTUhBJln1pQOoAqsds4cw4c4h7a/GgDLH/yQ7cCeJzJODLWV59jSMX5tqbfupAfaXuYA8RwlguyuxCnVsEyxb+MncTJcHnifAc3o1mlMLfSW8pXjL8wagRUkAt7B6Gm8k6+V3QAYwXRhW1pnjQ/szkDUvTkp6sDIJGeAB5nWXwRZ3aqV5Z+O8nrAscEn3fWbftxu2m7cdDLmLNJLzbLLajcqYrszitmwwsgVjzH643yHWMhWpMpMLP1jqCmLRm+4uHAAZ2Pzs8Jse2QfbcXh1FdK2WR+HgdBfTgrk1scMZrXWwwKQjgav1XnmnQ6rY43buxlcLzcH2MoxWA1ktTEWaFyGZKqdjhlot37zOwsltC5QnGbWjPUdgVjiwbK3+CISMII8+MarfLZQTHc/tE6tbzYGDVg6Tnh6fg2n9mooHBhOIFKYBsAVgIawELQB8AcpywrWedPv72lQGizd4AZnxL4G18QyaPKpn22FB0ObyUneLoTXhkLfHryZnF6HDOqm+pYtrltrBiTnO6wmT7LDnnMrrDLrlPYx0QNXcRCSXQ4ill9I0h+cKa01l2Pq2UQD4ScIAPgbdwHsVd7BJYD66oMzhA4uEKyzx3kSMOwsywOmckfzbgwDnJklkpO9tN1dD4mnkCnUlicgBytOYOtCkeWz+jKrrJOZ06kbJ7z5xht4+SUZBESrpke12hXMbCUbNiPtfnK2w2F5wPbPf/omx18PM4t7SaBJwD2mNrhOtUgZ0CJXgZ7m3xgGoCUxA/6qSYANJM1jwFJ4LW2NlyCjBrhyMSqoIfnZ5OX4/fkzJ7zt9FsAPgz/wXET6DGaHhkwziOY+bisUJqv0ZYVcnrttBPE/ht1Bu7g68AngVlfzkYS5x08z8sAr4At/OVnBjRl7AFfJQ0uRSvia0RBS33sBGS3zED6JBFaHrGugeUE7qF/lNbPOOH+/hcAfNQr37W+yREKL7byw7FfOmuQLkB4XyOAja0w/za1JQMY95013iKMYdHXRxCnC7xZXhUy0gsdU9VqoThLMhhUPR/AncQHl8TAK6AP8UxG9A5+cyabHaWc5X319T+52KM/+MMv4snT9+J8Bu6frr89t1pJB4cA65PjLC8Dz9yKTnn6EwNBB6Ks66zgFLnQFw2Jjt0yW1GJHAwK3ky0mgg7QLNyTh4st6Vl8AEjcBnIiY5DUFcTIJGz5OXusqFwurukf+31j18Whf/3z/4UL7/03s3PIT80LAxBkeQYfv6ArDjLmJVG29wQixt4DZvl9V9t6hhg8TsEolV3PY3OscVnuxxpIF1VGHz3G8Kh3ZJEpoJ0yG+17O5isaGGm0GudB2AGolskEvabj76G2+iffCDP3cB+l3v+BSePPnwpVHrl0/tl4oUWANCfWQwwIgwB1dE0oAtblXpTop1hiG/FIxWm/VZ77lOO093KDLASXbP8D761l1WxxDJ05tkHoJYy2fwWpwgDnoyq5zlT6BWuNPdF21HA15+8ReBdduuvec9/6r/4R//Uzx5a7XSC9Dug6GO/jRGqD2PoL4GZmDjjDiOlnoVsK9w+X63vOLH1poHIrOijSuGgFulc/4YvSkM82FmaeVkBvBwbsmZftp/ZngY3gHGWX0TqFMLXMGt7VkueQvp/+Mvv0ZSQP+DP/pJ3D/5BO775cnd+f4CgP/IOPuXE7/2iK8LLSMyHA2+vOgb2qNxqePIeRVSy72fdDikBr6yxJWOQmC6F02KU2uscbHOg9ysnNQ5hTrJs3hrwN1y8Z+Xu4uq734vl7iE/od//EU8eeu9uD9vUIdfzd8BOAN9D/Aj56G+Qs8RuLNF3wB4UneR9KihhLWyxDNd2UTYgTiNY4SJlWR3lZl1LifPUZixWWcHegHe+vqn2yuvfFR6CfQ/+vJP4MnXfxq9I1jqXag5vme1/c+xc03PLHUaT9qIh6QX7RpkDoajcHKBqsyhXY5ETtNmVnUX4KyOg1CX+ckkVJhbc+scumCh/4/P/wZefunDOHe4pe7nGuprAJ+BPU1L0sv6UMB9wFrPwhHXJBXJEjOwDrRhtvCc5klk6lLM9BVQB53IQRzSDwLO6eY3L8sF6rYAbz35dHvlr3xUWhND/+IXOzouEJ+vhPrqOK4HOcuvLPQgU7ShTJu04UaxIRzdIZmKFZZ2KJfAk7VjzwXas9aH3JrCnZnC3IDldDl/80207301tCT/kuzXvvZxvPjSz27fUlguMC8gqBvif726Ng44QNxJV0/1WGCI04vWVn1qrUnUwS+sTToZsvREzvVfEa7Z7qturFOAEyW7lliUpCKZu5GV24O6iGd5rQFtfYjSALz+1X89aXUM/Qu///N423Mf9Z2OdOcDmFveSq44pwOSrCktZdaev16l7dR3dTsmobqNH0xOhdQqH4L4Gp18vmfpd6xvKrf+MZCX6DfzQjBtUhYGqM3tOK971KmfrOcHQJ7d5meAPAS+6eJd87pRAAACt0lEQVQv0Ve5MTeFysLeqGfv9j+r6Jq6MzelSj9qrdNzckkaCOQV5ifRbx6qnYX+2hc+heef/whglrqPPrW+93FJvB3kKSuVNb0hZL77gWpvu1MUYfcK3HDrf1DdO8oqq+xJWXuPgkzn4Z94rkCjAef719r73/eB3ebNQv/cb/wM3v3OfwZgeyTOUAdLfQvIe9b4gLV+rHCt5f6GhBm0DwA6UXUw8bg/79G98zXC74WYVTa4759+ob3//a9e3YUs9N/+nY/hHd/2j3B//mF/G47dEAM1tda4yB31mQ8DnAh8M3jTcE0brr7l3xIegfhdy5zkXeOK8MtGbplpAfhW7WakTTka+q997pN46eUfw9uf327ZDjfDXFhrOuynJ3L9qOw3Mey6J3tuRKX3ETo9s/RXlZ9Z7oN+dvhPXU2+f7gQzPkCcNq8a0P/wu//PJ57bq2EQGNrbXnoxf83QQHm3oJsr/y3QthbC3yTQzU5rvWrr/GpOX32n7Ds2y6n576E1v5Ne893/HTdgMMtPRb6r33uk/jO73wFT+///pqCzf0YpB8JzlT57QA9OnhJPx/Dz73JQs8qvmLStfIkSd5xS/gpYXgVlUDu/d+273rPJw62bq9lt4X+ud/4Gbz80ruxnH4A6MDp7tXbAT64k/AooDyCjmet9KHq0nHKgL7W9dATurYBYpELP0u2Hk/PfQmvf+U/tVdfPeRe7DbrWYb+27/9MSzP7V+W+/t9ZXd3HV97/Yfw8ovv2gZleThBb3/+nXjrrQ88ziRZldwt3/sI2pLwDbt0SXU7Vv+wG9KBp/dfwHNv+3f48698sf3VD/7cozbz/4dv/dD/++f/sZ/c3T1c4Ztv/CBefPu786eH+hX5IqsLR8vdD8Sf7gXwtTfewPPP/xb6ueHFl34TX/mzL7UPPhxgDf8P0TCMP2mNlpgAAAAASUVORK5CYII=","w":180,"h":180,"e":1}],"layers":[{"ddd":0,"refId":"4","w":20000,"h":20000,"ind":8,"ty":0,"nm":"Masked Group 1","sr":1,"ks":{"p":{"a":0,"k":[160,80],"ix":2},"a":{"a":0,"k":[10000,10000],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":141,"st":0,"bm":0}],"markers":[]}'),
                f = {
                    src: "https://cdn.wegic.ai/_next/static/media/public-poster.873e1885.jpg",
                    height: 4320,
                    width: 7680,
                    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAAm4H/xAAeEAABAgcBAAAAAAAAAAAAAAARAxMAAQQSFCEiMf/aAAgBAQABPwCSlO03hIXa76JAPsf/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==",
                    blurWidth: 8,
                    blurHeight: 5
                },
                v = a(19697),
                w = a(71393),
                b = a.n(w);
            const B = {
                    rootMargin: "100px 100px",
                    threshold: 0,
                    root: null
                },
                C = (0, x.forwardRef)((function(e, t) {
                    const {
                        className: a,
                        style: i,
                        options: A,
                        src: o,
                        onLoad: r,
                        autoPlay: n = !0,
                        ...l
                    } = e, c = (0, x.useRef)(null);
                    (0, x.useEffect)((() => {
                        const e = new IntersectionObserver((t => {
                            if (t[0].isIntersecting) {
                                const t = c.current;
                                t.src = o, t.addEventListener("loadedmetadata", (() => {
                                    n && t.play(), c.current && e.unobserve(c.current)
                                }))
                            }
                        }), { ...B,
                            ...A
                        });
                        return c.current && e.observe(c.current), () => {
                            e.disconnect()
                        }
                    }), [o, A]);
                    return (0, s.jsx)("video", {
                        autoPlay: n,
                        ref: e => {
                            c.current = e, t && ("function" == typeof t ? t(e) : t.current = e)
                        },
                        style: i,
                        className: a,
                        ...l
                    })
                }));
            var Q, E, D = C,
                I = a(18438),
                H = a(57064);

            function P() {
                return P = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, P.apply(this, arguments)
            }
            var j, M, O = function(e) {
                return y.createElement("svg", P({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 32 32"
                }, e), Q || (Q = y.createElement("path", {
                    fill: "currentcolor",
                    d: "M1.453 16.205c0 3.15 2.118 5.91 5.185 6.627 1.271.297 2.512.57 3.375.722 2.754.484 2.918 3.088 5.54 4.46.447.234.876.413 1.27.55 1.138.396 2.093-.597 1.969-1.795-.273-2.64-.67-7.156-.659-11.055.008-3.14.412-7.761.679-10.483.116-1.187-.827-2.2-1.955-1.813a8 8 0 0 0-1.304.576c-2.59 1.432-2.786 3.977-5.54 4.46-.86.151-2.097.423-3.363.72-3.068.716-5.197 3.48-5.197 6.63z"
                })), E || (E = y.createElement("path", {
                    stroke: "currentcolor",
                    strokeLinecap: "round",
                    strokeWidth: 4,
                    d: "m22.132 10.679 7.653 10.647M29.782 10.679l-7.653 10.647"
                })))
            };

            function N() {
                return N = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, N.apply(this, arguments)
            }
            var Y = function(e) {
                    return y.createElement("svg", N({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "1em",
                        height: "1em",
                        fill: "none",
                        viewBox: "0 0 32 32"
                    }, e), j || (j = y.createElement("path", {
                        fill: "currentcolor",
                        d: "M1.453 16.205c0 3.15 2.118 5.91 5.185 6.627 1.271.297 2.512.57 3.375.722 2.754.484 2.918 3.088 5.54 4.46.447.234.876.413 1.27.55 1.138.396 2.093-.597 1.969-1.795-.273-2.64-.67-7.156-.659-11.055.008-3.14.412-7.761.679-10.483.116-1.187-.827-2.2-1.955-1.813a8 8 0 0 0-1.304.576c-2.59 1.432-2.786 3.977-5.54 4.46-.86.151-2.097.423-3.363.72-3.068.716-5.197 3.48-5.197 6.63z"
                    })), M || (M = y.createElement("path", {
                        stroke: "currentcolor",
                        strokeLinecap: "round",
                        strokeWidth: 4,
                        d: "M24.39 8.316c1.021.907 3.2 3.134 3.2 7.38s-1.972 6.917-3.2 8"
                    })))
                },
                L = a(53509),
                z = a(99901),
                J = a(13122);
            const S = L.fC,
                G = L.xz,
                T = L.h_,
                W = L.x8,
                R = x.forwardRef(((e, t) => {
                    let {
                        className: a,
                        ...i
                    } = e;
                    return (0, s.jsx)(L.aV, {
                        ref: t,
                        className: (0, J.cn)("fixed inset-0 z-50 bg-[#F7F6F5]  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", a),
                        ...i
                    })
                }));
            R.displayName = L.aV.displayName;
            const F = x.forwardRef(((e, t) => {
                let {
                    className: a,
                    children: i,
                    hideClose: A,
                    ...o
                } = e;
                return (0, s.jsxs)(T, {
                    container: document.getElementById("dialog-container"),
                    children: [(0, s.jsx)(R, {}), (0, s.jsxs)(L.VY, {
                        ref: t,
                        className: (0, J.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-0 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", a),
                        ...o,
                        children: [i, !A && (0, s.jsx)(L.x8, {
                            className: "absolute top-[20px] right-[4%] md:right-[6%] lg:right-[9%] xl:right-[11%] 2xl:right-[14%] rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none  disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground z-10",
                            children: (0, s.jsxs)("div", {
                                className: " hover:bg-black/5 w-10 h-10 rounded-lg flex items-center justify-center",
                                children: [(0, s.jsx)(z.Z, {
                                    className: "h-6 w-6"
                                }), (0, s.jsx)("span", {
                                    className: "sr-only",
                                    children: "Close"
                                })]
                            })
                        })]
                    })]
                })
            }));
            F.displayName = L.VY.displayName;
            x.forwardRef(((e, t) => {
                let {
                    className: a,
                    ...i
                } = e;
                return (0, s.jsx)(L.Dx, {
                    ref: t,
                    className: (0, J.cn)("text-lg font-semibold leading-none tracking-tight", a),
                    ...i
                })
            })).displayName = L.Dx.displayName;
            x.forwardRef(((e, t) => {
                let {
                    className: a,
                    ...i
                } = e;
                return (0, s.jsx)(L.dk, {
                    ref: t,
                    className: (0, J.cn)("text-sm text-muted-foreground", a),
                    ...i
                })
            })).displayName = L.dk.displayName;
            var X = a(43248),
                U = a.n(X),
                V = a(21658);
            const Z = {
                    show: {
                        display: "flex",
                        transition: {
                            staggerChildren: .07,
                            delayChildren: .1
                        }
                    },
                    hide: {
                        display: "none",
                        transition: {
                            staggerChildren: .05,
                            staggerDirection: -1
                        }
                    }
                },
                K = {
                    show: {
                        y: 0,
                        transition: {
                            y: {
                                stiffness: 1e3,
                                velocity: 100
                            }
                        }
                    },
                    hide: {
                        y: 30,
                        transition: {
                            y: {
                                stiffness: 1e3
                            }
                        }
                    }
                };

            function q(e) {
                const {
                    open: t,
                    onopenChange: a
                } = e, i = (0, x.useRef)(null), [A, o] = x.useState(!0);
                return (0, s.jsx)(S, {
                    open: t,
                    onOpenChange: a,
                    children: (0, s.jsxs)(F, {
                        hideClose: !0,
                        className: c()(U()["promotional-video"], "w-[100%] max-w-[100%] h-[100%] max-h-[100%] rounded-none shadow-none bg-black"),
                        onInteractOutside: e => e.preventDefault(),
                        children: [(0, s.jsx)(D, {
                            poster: f.src,
                            ref: i,
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            className: "w-full h-full",
                            src: "https://cdn.wegic.ai/assets/video/wegic-video-1080p-250106-full.mp4"
                        }), (0, s.jsxs)(r.E.div, {
                            variants: Z,
                            initial: "hide",
                            animate: "show",
                            className: "absolute top-[62px] right-[40px] gap-[20px]",
                            children: [(0, s.jsx)(r.E.div, {
                                variants: K,
                                whileTap: {
                                    transform: ["translateY(0px)", "translateY(2px)"]
                                },
                                children: (0, s.jsx)(V.Z, {
                                    onClick: () => {
                                        const e = i.current;
                                        e && (e.muted ? (e.muted = !1, o(!1)) : (e.muted = !0, o(!0)))
                                    },
                                    icon: A ? (0, s.jsx)(O, {}) : (0, s.jsx)(Y, {}),
                                    className: U()["close-btn"],
                                    type: "primary",
                                    status: "plain"
                                })
                            }), (0, s.jsx)(r.E.div, {
                                variants: K,
                                whileTap: {
                                    transform: ["translateY(0px)", "translateY(2px)"]
                                },
                                children: (0, s.jsx)(W, {
                                    asChild: !0,
                                    children: (0, s.jsx)(V.Z, {
                                        icon: (0, s.jsx)(H.Z, {}),
                                        className: U()["close-btn"],
                                        type: "primary",
                                        status: "plain"
                                    })
                                })
                            })]
                        })]
                    })
                })
            }

            function _(e) {
                const [t, a] = (0, x.useState)({
                    x: 0,
                    y: 0
                });
                return (0, x.useEffect)((() => {
                    const t = e.current;
                    if (!t) return;
                    const i = (0, n.Z)((e => {
                        const i = t.getBoundingClientRect();
                        a({
                            x: e.clientX - i.left,
                            y: e.clientY - i.top
                        })
                    }), 16);
                    return t.addEventListener("mousemove", i), () => {
                        t.removeEventListener("mousemove", i)
                    }
                }), [e]), t
            }
            const $ = (0, g.default)((() => a.e(622).then(a.bind(a, 70622))), {
                    loadableGenerated: {
                        webpack: () => [70622]
                    }
                }),
                ee = {
                    show: {
                        opacity: 1,
                        scale: 1,
                        transition: {
                            duration: .2
                        }
                    },
                    hide: {
                        opacity: 0,
                        scale: 0,
                        transition: {
                            duration: .2
                        }
                    }
                };

            function te() {
                const e = (0, p.useTranslations)(),
                    t = (0, x.useRef)(null),
                    {
                        scrollYProgress: a
                    } = (0, A.v)({
                        target: t,
                        offset: ["start end", "end start"]
                    }),
                    i = (0, x.useRef)(null),
                    n = (0, x.useRef)(null),
                    [l, d] = (0, x.useState)(!1),
                    g = (0, x.useRef)(null),
                    y = (0, o.H)(a, [.55, .56, .57, .62], ["#ffffff", "#ffffff", "#ffffff", "#000000"]),
                    u = (0, o.H)(a, [.42, .7], [.6, 1]),
                    w = (0, o.H)(a, [.42, .7], [.5, 1]),
                    B = (0, o.H)(a, [.55, .65], [1, 0]),
                    C = (0, x.useRef)(null),
                    [Q, E] = (0, x.useState)(!1),
                    H = _(C),
                    P = (0, x.useRef)(null),
                    [j, M] = (0, x.useState)(!1),
                    O = _(P),
                    N = (0, x.useRef)(!1),
                    Y = (0, v.W7)(),
                    L = () => {
                        var e;
                        (d(!1), i.current) && (i.current.currentTime = 0, null === (e = i.current) || void 0 === e || e.play())
                    };
                return (0, x.useEffect)((() => {
                    const e = new IntersectionObserver((e => {
                        e[0].isIntersecting || L()
                    }), {});
                    return g.current && e.observe(g.current), () => {
                        e.disconnect()
                    }
                }), []), (0, s.jsxs)(r.E.div, {
                    ref: t,
                    id: "anchor-three",
                    className: "w-full flex flex-col items-center justify-center py-[20%] md:py-[15%] lg:py-[10%] xl:py-[10%] 2xl:py-[8%] px-[6%] md:px-[6%] lg:px-[9%] xl:px-[11%] 2xl:px-[14%]",
                    children: [(0, s.jsxs)(r.E.div, {
                        className: "flex flex-col gap-4",
                        children: [(0, s.jsx)(ae, {
                            children: (0, s.jsxs)(r.E.div, {
                                "data-follow-hidden": !0,
                                className: "flex items-center gap-4 text-left text-white text-3xl leading-normal md:text-4xl md:leading-relaxed  xl:text-[2.5rem] xl:leading-relaxed  2xl:text-[2.75rem] 2xl:leading-relaxed",
                                style: {
                                    color: y
                                },
                                transition: {
                                    duration: .8,
                                    ease: "easeInOut"
                                },
                                children: [e("Home_AboutMe_Hi"), (0, s.jsxs)("div", {
                                    ref: P,
                                    className: "relative min-w-[92px] min-h-[40px]",
                                    onMouseOver: () => {
                                        N.current || M(!0)
                                    },
                                    onMouseLeave: () => {
                                        N.current = !0, M(!1), setTimeout((() => {
                                            N.current = !1
                                        }), 32)
                                    },
                                    children: [j && (0, s.jsxs)(r.E.div, {
                                        onClick: () => {
                                            ! function() {
                                                const e = document.createElement("div"),
                                                    t = (0, I.createRoot)(e);
                                                t.render((0, s.jsx)(q, {
                                                    open: !0,
                                                    onopenChange: a => {
                                                        a || (t.unmount(), document.body.removeChild(e))
                                                    }
                                                })), document.body.appendChild(e)
                                            }()
                                        },
                                        initial: {
                                            opacity: 0
                                        },
                                        animate: {
                                            opacity: 1,
                                            transition: {
                                                duration: .1,
                                                delay: .1
                                            }
                                        },
                                        className: "flex items-center py-[8px] px-[10px] gap-[10px] cursor-pointer hover:bg-white/10 rounded-[12px]",
                                        children: [(0, s.jsx)(h, {
                                            className: "fill-white"
                                        }), (0, s.jsx)("span", {
                                            style: {
                                                color: y.get()
                                            },
                                            className: "text-white text-[14px] font-medium leading-[24px]",
                                            children: "watch video"
                                        }), (0, s.jsx)("div", {
                                            className: "absolute ".concat(j ? " " : "hidden", " w-[120px] h-[68px]"),
                                            style: {
                                                left: "".concat(O.x + 10, "px"),
                                                top: "".concat(O.y + 10, "px"),
                                                pointerEvents: "none",
                                                zIndex: 100
                                            },
                                            children: j && (0, s.jsx)("video", {
                                                autoPlay: !0,
                                                loop: !0,
                                                muted: !0,
                                                className: "w-full h-full rounded-[12px] border border-white/20",
                                                children: (0, s.jsx)("source", {
                                                    src: "https://cdn.wegic.ai/assets/video/wegic-video-1080p-250106.mp4",
                                                    type: "video/mp4"
                                                })
                                            })
                                        })]
                                    }), (0, s.jsx)(r.E.svg, {
                                        variants: ee,
                                        animate: j ? "hide" : "show",
                                        className: "absolute top-0 left-0 w-auto mt-[5px] fill-white h-8 md:h-10 xl:h-11 2xl:h-12",
                                        style: {
                                            fill: y
                                        },
                                        xmlns: "http://www.w3.org/2000/svg",
                                        viewBox: "0 0 68.78515625 29.94580078125",
                                        children: (0, s.jsx)("path", {
                                            fillRule: "evenodd",
                                            d: "M12.8989 2.25399C13.4521 1.83905 13.5643 1.05418 13.1493 0.500942C12.7344 -0.0523018 11.9495 -0.164425 11.3963 0.250508C10.2493 1.11077 7.97111 3.73187 6.40669 7.14886C5.17835 9.83176 4.80758 12.5493 5.23862 14.6856C5.66387 16.7933 7.01233 18.6973 9.38556 18.7094C10.6356 18.7486 11.6547 18.2322 12.454 17.4921C12.8021 17.1698 13.1152 16.7997 13.3993 16.4036C13.5316 16.701 13.6969 16.9851 13.9004 17.2488C14.5633 18.1072 15.537 18.6244 16.7423 18.739C18.2253 18.88 19.4013 18.1374 20.2699 17.2199C21.1283 16.313 21.8232 15.0998 22.4007 13.9268C22.5071 13.7107 22.6119 13.4907 22.7149 13.2696C23.1865 14.1227 23.8737 14.8755 24.7733 15.3957C25.0931 15.5806 25.4357 15.7213 25.7941 15.8226C26.081 16.5007 26.5226 17.1187 27.1094 17.6117C28.4207 18.7133 30.2993 19.0668 32.4242 18.35C34.1877 17.7551 35.7946 16.4187 37.2008 15.0236C37.2235 15.6149 37.3438 16.2053 37.6178 16.7376C38.1776 17.8252 39.2428 18.4157 40.6049 18.4157C41.2928 18.4157 42.1334 18.1954 42.9525 17.8663C43.485 17.6524 44.0498 17.3757 44.6137 17.0389C44.4317 17.5261 44.246 18.0078 44.0566 18.4814C42.9203 19.1773 41.6496 19.7764 40.2561 20.1804C38.5497 20.6753 37.3022 21.0644 36.3869 21.4612C35.4657 21.8605 34.7724 22.3122 34.2476 22.9869C33.2805 24.0909 33.0546 25.7602 33.5242 27.1416C34.0388 28.6555 35.3938 29.8751 37.5094 29.9437C39.0503 29.9935 40.3765 29.1589 41.4536 28.0635C42.5419 26.9567 43.531 25.4313 44.424 23.7275C45.0016 22.6258 45.5532 21.4212 46.0763 20.1611C48.7706 18.3524 50.7031 16.1324 51.7787 14.6241C51.829 14.9185 51.9006 15.1887 51.9915 15.4338C52.197 15.9887 52.5563 16.5545 53.1357 16.8619C53.4394 17.0231 53.8151 17.1148 54.2191 17.0512C54.6269 16.987 54.9645 16.7799 55.2093 16.5129C55.5234 16.1707 55.9311 15.6303 56.3645 15.0265C56.4377 15.7209 56.6434 16.4105 57.0573 17.0237C57.8946 18.264 59.1287 18.814 60.423 18.7481C61.646 18.6859 62.8183 18.0865 63.7537 17.263C64.2728 16.8059 64.3231 16.0147 63.8662 15.4956C63.4092 14.9765 62.618 14.9262 62.099 15.3832C61.4551 15.9499 60.7997 16.2213 60.2957 16.2471C59.8633 16.269 59.4714 16.1238 59.133 15.6225C58.7938 15.12 58.7308 14.2041 59.021 13.036C59.3019 11.9053 59.8128 10.9483 60.0781 10.6273C61.2472 9.21231 62.2188 9.13441 62.744 9.20084C63.012 9.23474 63.231 9.31659 63.3746 9.386C63.4468 9.4286 63.5034 9.46761 63.544 9.49551L63.548 9.49835C63.5732 9.51563 63.6166 9.54479 63.6688 9.57438C63.6886 9.58557 63.7498 9.62008 63.8317 9.65261C63.8648 9.66575 63.967 9.70558 64.1044 9.72683C64.1722 9.73732 64.3095 9.75334 64.4805 9.72794C64.6507 9.70263 64.9619 9.61843 65.2225 9.33231C65.5005 9.02707 65.5581 8.673 65.5479 8.43525C65.5386 8.22017 65.476 8.05968 65.4436 7.98554C65.3776 7.83513 65.2968 7.73372 65.2742 7.70543C65.2139 7.6298 65.1572 7.57745 65.1408 7.56218C65.0945 7.5193 65.0518 7.4859 65.0271 7.4671C64.922 7.38678 64.7787 7.29494 64.6099 7.20509C64.5986 7.19908 64.5872 7.19303 64.5755 7.18695C64.1337 6.93717 63.3872 6.61341 62.4093 6.60374C60.9719 6.58955 59.3115 7.24844 57.5738 9.12374C57.0009 9.74202 56.147 10.9687 55.381 12.0693L55.3494 12.1147C54.9334 12.7122 54.5416 13.2744 54.2017 13.7439C54.1778 13.1505 54.2625 12.2925 54.6052 11.132C54.7579 10.6149 54.8738 10.1971 54.9536 9.87183C55.0251 9.57995 55.093 9.26594 55.1023 9.00751C55.1049 8.93479 55.1051 8.82252 55.0845 8.69373C55.0679 8.59017 55.0159 8.32341 54.808 8.06571C54.5355 7.728 54.1122 7.55114 53.6797 7.59557C53.3497 7.62948 53.1239 7.78097 53.0397 7.84153C52.8562 7.97351 52.7296 8.13405 52.6763 8.20281C52.6039 8.29616 52.5342 8.39869 52.4708 8.49691C52.2262 8.87572 51.8909 9.48086 51.5296 10.1339L51.4816 10.2205C51.1205 10.8732 50.7136 11.6087 50.2839 12.3414C49.8916 13.0105 49.0622 14.1747 47.845 15.4265C48.2455 14.2462 48.6206 13.0677 48.9682 11.9246C49.4962 10.1879 49.285 8.8516 48.6805 7.88459C48.1107 6.97312 47.3102 6.58406 47.0084 6.45724C46.2892 6.14909 45.3367 5.95135 44.1616 6.18012C44.0839 6.19524 44.0057 6.21216 43.9268 6.23092C42.918 6.44712 41.8237 6.94237 40.7314 7.82549C40.5899 7.93988 40.4469 8.06148 40.3024 8.18924C40.2967 8.194 40.2909 8.19876 40.2851 8.20353C40.0528 8.38608 39.8298 8.59696 39.6179 8.82853C38.9103 9.52009 38.1827 10.3153 37.4659 11.0987C37.0259 11.5794 36.5902 12.0557 36.1655 12.5008C34.5713 14.1724 33.0721 15.4884 31.6236 15.977C30.3921 16.3926 29.5288 16.2198 28.9667 15.8722C29.4865 15.771 29.9994 15.6253 30.4892 15.4473C32.4156 14.7477 34.3543 13.4231 35.524 11.6189C36.288 10.4404 36.4569 8.95572 35.578 7.80522C34.7218 6.68447 33.2132 6.33574 31.6015 6.60036C28.1125 7.17319 26.0132 10.0372 25.5062 12.8377C24.9977 12.3572 24.645 11.6826 24.5081 10.9391C24.3275 9.9588 24.5498 9.02589 25.0833 8.41786C25.534 7.90408 25.4895 7.12374 24.9832 6.66456C24.4769 6.20537 23.696 6.23702 23.2285 6.73567C22.6232 7.38138 22.1092 8.46368 21.663 9.46135C21.5094 9.80491 21.3578 10.1538 21.2049 10.5055C20.8711 11.273 20.5316 12.0536 20.154 12.8205C19.6047 13.936 19.0433 14.8727 18.4511 15.4983C17.8693 16.1131 17.4004 16.2859 16.9792 16.2458C16.3924 16.1902 16.08 15.9738 15.8828 15.7184C15.6583 15.4276 15.4867 14.9559 15.4505 14.2672C15.3911 13.1353 15.7155 11.6984 16.3189 10.3328C16.4666 10.0085 16.6122 9.70992 16.7596 9.44055C17.1561 8.8307 17.4464 8.36149 17.6383 8.03609C17.7351 7.87208 17.8132 7.73401 17.8686 7.62826C17.8936 7.58044 17.9278 7.51281 17.9571 7.44349C17.9675 7.41898 18.0031 7.3344 18.029 7.22625L18.0294 7.22443C18.0389 7.18497 18.0774 7.02421 18.059 6.81857C18.0496 6.71164 18.0166 6.48753 17.8654 6.25172C17.6864 5.97261 17.3923 5.76004 17.0342 5.69497C16.7296 5.6396 16.488 5.71071 16.3739 5.75295C16.2496 5.79899 16.1589 5.8551 16.1105 5.88753C16.0138 5.95222 15.9473 6.01642 15.9217 6.0417C15.863 6.09959 15.8199 6.15313 15.8021 6.17564C15.7591 6.2298 15.7184 6.28756 15.6864 6.33443C15.618 6.43467 15.5317 6.5696 15.4311 6.73325C15.228 7.06404 14.9439 7.54955 14.5894 8.18973C14.3925 8.54523 14.2082 8.91582 14.0393 9.29647C13.7962 9.82984 13.5637 10.3907 13.3377 10.9365L13.3168 10.9869C12.9212 11.9423 12.5356 12.8738 12.104 13.7085C11.6612 14.5651 11.2166 15.2247 10.7526 15.6545C10.3149 16.0597 9.90588 16.2226 9.45457 16.206C9.43922 16.2055 9.42388 16.2052 9.40852 16.2052C8.72216 16.2052 8.00215 15.72 7.69349 14.1903C7.38926 12.6825 7.62377 10.5065 8.68372 8.19136C10.1138 5.06791 12.1547 2.81213 12.8989 2.25399ZM55.0166 2.896C54.7618 2.66694 54.3552 2.8326 54.3329 3.17452L54.2771 4.03323C54.2711 4.12516 54.2344 4.21242 54.1728 4.28092L53.5974 4.92085C53.3683 5.17567 53.534 5.58239 53.876 5.60462L54.7347 5.66044C54.8265 5.66642 54.9139 5.70317 54.9824 5.76476L55.6224 6.34007C55.8771 6.56913 56.2838 6.40347 56.306 6.06155L56.3618 5.20284C56.3678 5.11091 56.4045 5.02366 56.4662 4.95515L57.0415 4.31522C57.2706 4.0604 57.1049 3.65368 56.7629 3.63145L55.9042 3.57563C55.8123 3.56964 55.725 3.5329 55.6566 3.47131L55.0166 2.896ZM40.5992 11.7699C40.8712 11.2689 41.1659 10.8508 41.4465 10.54C41.6011 10.3908 41.754 10.2483 41.9058 10.1132C43.0073 9.21537 43.862 8.82437 44.4872 8.67189C45.1938 8.52919 45.7342 8.6355 46.0247 8.7604L46.0367 8.76539C46.0702 8.77943 46.2742 8.87749 46.4482 9.09672C46.5975 9.28478 46.7855 9.63368 46.7342 10.2927C46.6077 11.9165 45.5368 13.3179 44.1145 14.3671C43.4167 14.8819 42.6766 15.2783 42.0188 15.5425C41.3342 15.8176 40.8352 15.9113 40.6049 15.9113C40.0375 15.9113 39.913 15.7248 39.8444 15.5913C39.712 15.3341 39.6368 14.8239 39.7738 14.0533C39.9047 13.3161 40.2028 12.5004 40.5992 11.7699ZM29.6342 13.0935C29.0227 13.3155 28.4492 13.4454 27.9361 13.4982C28.2187 11.4363 29.7054 9.44954 32.0072 9.07162C33.1158 8.88961 33.507 9.21974 33.5879 9.32553C33.6459 9.40155 33.7892 9.69108 33.4226 10.2566C32.6138 11.5041 31.1719 12.5349 29.6342 13.0935ZM47.7877 21.8703C47.795 21.1789 48.3615 20.6241 49.053 20.6314C55.2617 20.6965 61.4789 21.1335 67.7225 22.086C68.406 22.1902 68.8757 22.8289 68.7714 23.5126C68.6672 24.1963 68.0284 24.6659 67.3447 24.5617C61.2337 23.6295 55.1353 23.1996 49.0267 23.1356C48.3352 23.1283 47.7805 22.5618 47.7877 21.8703ZM32.5268 22.2624C32.5516 22.9536 32.0114 23.5339 31.3203 23.5585C14.064 24.1761 5.69774 26.417 2.00318 27.4066C1.8525 27.4469 1.7096 27.4852 1.57419 27.5212C0.905846 27.6989 0.220015 27.3011 0.0423407 26.6328C-0.135332 25.9644 0.262432 25.2786 0.930774 25.1009C1.06346 25.0656 1.20297 25.0283 1.34954 24.9891C5.15141 23.9717 13.7042 21.6831 31.2307 21.0559C31.9219 21.0311 32.5022 21.5713 32.5268 22.2624ZM40.9537 22.5857C41.471 22.4357 41.9728 22.2632 42.4588 22.0719C42.3751 22.2387 42.2908 22.4032 42.206 22.5648C41.3641 24.1708 40.5092 25.4521 39.6679 26.3077C38.8154 27.1746 38.1264 27.458 37.5904 27.4406C36.5468 27.4068 36.084 26.8908 35.8954 26.3357C35.6676 25.6658 35.8412 24.9576 36.1418 24.6255C36.1664 24.5982 36.1898 24.57 36.2119 24.5409C36.3841 24.3131 36.661 24.0719 37.3831 23.759C38.1303 23.4349 39.2282 23.086 40.9537 22.5857Z"
                                        })
                                    })]
                                })]
                            })
                        }), (0, s.jsx)("div", {
                            className: "flex flex-col text-white gap-2 text-2xl leading-normal md:text-4xl md:leading-relaxed  xl:text-[2.5rem] xl:leading-relaxed  2xl:text-[2.75rem] 2xl:leading-relaxed",
                            children: JSON.parse(e("Home_AboutMe_Items")).map(((e, t) => (0, s.jsx)(r.E.div, {
                                style: {
                                    color: y
                                },
                                whileHover: {
                                    scale: 1.02,
                                    y: -4,
                                    transition: {
                                        duration: .2,
                                        ease: "easeInOut"
                                    }
                                },
                                children: 0 === t ? (0, s.jsxs)(r.E.div, {
                                    ref: C,
                                    "data-follow-hidden": !0,
                                    onMouseEnter: () => E(!0),
                                    onMouseLeave: () => E(!1),
                                    children: [(0, s.jsx)("div", {
                                        className: "absolute ".concat(Q ? " " : "hidden"),
                                        style: {
                                            left: "".concat(H.x - 10, "px"),
                                            top: "".concat(H.y - 10, "px"),
                                            transform: "translate(0%, 0%)",
                                            pointerEvents: "none",
                                            transition: "transform 0.1s, width 0.1s, height 0.1s",
                                            zIndex: 100
                                        },
                                        children: Q && (0, s.jsx)("div", {
                                            className: " w-40 h-auto",
                                            children: (0, s.jsx)(k(), {
                                                animationData: m,
                                                loop: !1
                                            })
                                        })
                                    }), (0, s.jsx)(ae, {
                                        children: e
                                    })]
                                }) : (0, s.jsx)("div", {
                                    children: (0, s.jsx)(ae, {
                                        children: e
                                    })
                                })
                            }, t)))
                        }), (0, s.jsx)(r.E.div, {
                            "data-follow-hidden": !0,
                            className: "w-fit flex justify-start mb-4 mt-16",
                            initial: {
                                y: 60
                            },
                            whileInView: {
                                y: 0,
                                transition: {
                                    duration: .6,
                                    type: "spring",
                                    bounce: .4
                                }
                            },
                            style: {
                                opacity: Y ? B : 1
                            },
                            children: (0, s.jsx)($, {})
                        })]
                    }), (0, s.jsxs)(r.E.div, {
                        ref: g,
                        id: "anchor-video",
                        onClick: () => {
                            var e, t;
                            i.current && n.current && (null === (e = i.current) || void 0 === e || e.pause(), d(!0), n.current.currentTime = 0, null === (t = n.current) || void 0 === t || t.play())
                        },
                        className: c()("mt-[100px] md:mt-[150px] relative cursor-pointer", b()["video-wrap"]),
                        initial: {
                            y: 60
                        },
                        style: {
                            scale: u,
                            opacity: w
                        },
                        "data-follow-hidden": !0,
                        children: [(0, s.jsx)(D, {
                            onEnded: () => {
                                L()
                            },
                            ref: n,
                            autoPlay: !1,
                            style: {
                                zIndex: l ? 1 : -1
                            },
                            controls: !0,
                            muted: !0,
                            poster: f.src,
                            className: "w-full h-full rounded-xl hover:rounded-2xl transition-all absolute top-0",
                            src: "https://cdn.wegic.ai/assets/video/wegic-video-1080p-250106-full.mp4"
                        }), (0, s.jsx)(D, {
                            ref: i,
                            poster: f.src,
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            className: "w-full h-full rounded-xl hover:rounded-2xl transition-all",
                            src: "https://cdn.wegic.ai/assets/video/wegic-video-1080p-250106.mp4"
                        }), (0, s.jsx)("div", {
                            className: c()(b().play, "absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%] flex items-center justify-center w-[170px] h-[90px] max-md:w-[85px] max-md:h-[45px] backdrop-blur-md rounded-[20px] bg-[#1c1c1c]/50"),
                            children: (0, s.jsx)(h, {
                                className: "text-white w-[40px] h-[36px] max-md:w-[20px] max-md:h-[18px]"
                            })
                        })]
                    })]
                })
            }
            const ae = e => {
                let {
                    children: t
                } = e;
                const a = (0, x.useRef)(null),
                    {
                        scrollYProgress: i
                    } = (0, A.v)({
                        target: a,
                        offset: ["start end", "end start"]
                    }),
                    n = (0, o.H)(i, [0, 1], [0, 2.8]);
                return (0, s.jsx)(r.E.h1, {
                    ref: a,
                    className: "py-4",
                    style: {
                        opacity: n
                    },
                    initial: {
                        y: 60
                    },
                    whileInView: {
                        y: 0,
                        transition: {
                            duration: .6,
                            type: "spring",
                            bounce: .4
                        }
                    },
                    children: t
                })
            };
            var ie = a(86561),
                se = a(93330),
                Ae = a(78229),
                oe = a(41868),
                re = {
                    src: "https://cdn.wegic.ai/_next/static/media/Arrow.a8b8f8ab.png",
                    height: 85,
                    width: 96,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAQAAACfUMTVAAAAf0lEQVR42mOQOyC3W41BN1j3ph6HHoMeC4Och9x/2ekOXHpfdC9rM+gxMMgxyLnK/ZeuMxLV/a27R5+JQZZNlkF2mdx/BkkDS93/epMZgNxWuf+SUQbyuj90T+tJMMguB2oINFHT/a971IBRj4FBbpdclCqDbovuPl0GPQY9FgB+CCAI2zuFPQAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 7
                },
                ne = {
                    src: "https://cdn.wegic.ai/_next/static/media/bgTop.3a236362.png",
                    height: 58,
                    width: 340,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAD0lEQVR4nGPk4+NrYMADABPYAKz4pb0uAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 1
                },
                xe = {
                    src: "https://cdn.wegic.ai/_next/static/media/CirclePath.ab3f30ac.png",
                    height: 231,
                    width: 693,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAP0lEQVR42mNIe7tOAIj1gVgTiFWB2A2IA4DYIe3NOl4GkCQDFgCUZATKGYMU6AKxChArAbECFCsBsXra23XqAO0IKQhqr1l4AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 3
                },
                le = {
                    src: "https://cdn.wegic.ai/_next/static/media/createPoster.bd6d5620.png",
                    height: 680,
                    width: 680,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+0lEQVR42hWPO0oDURiF/8dNZu48xAmoAcup7BNxA4NNGrFzCe5D3YGNYJEVuAErG7sgyhRiCiGCMRlGHZTcmeTe/Pmq/3HgnIPHg0GcAHbf6sZ2yIAGgJojUITEjJ+Y7u6djEP/uhfov9oFVFoH+7qxzrnwaVKeq/HXlO5Oz3a6gY6O7h+qg2SbHkcjCwAhe5FSMnDeLPh9VhFs2bC9LPHi8soyoR4Ob1F1RHAznYDQ7uvYn//8wmG/Z40xKs9fWX37HtDzi4uT5P8DHDExZFm2sYhBUL6cVp6HlTEtCcYgpGm6ErAoClLMRLKAPFuASE5azOYFgbMbLa0B8eNh1sR3pOcAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 8
                },
                ce = "https://cdn.wegic.ai/_next/static/media/EditPoster.0f20e0ae.png",
                de = {
                    src: "https://cdn.wegic.ai/_next/static/media/FeatureBg.123bfed8.png",
                    height: 1361,
                    width: 2037,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAAJ0lEQVR42mOQZbRlDGVMAsJQRltGWUYGd0YGBADxIlAEIrCoQDcDAAiwBicxy8j+AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 5
                },
                ke = "https://cdn.wegic.ai/_next/static/media/publicPoster.f374b1a9.png",
                ge = a(64746),
                pe = a(83847),
                ye = a(42466);
            const ue = window.innerHeight,
                he = [0, .25, .4, .5111111],
                me = [0, 32, 32, 32],
                fe = [0, .15, .35, .4, .5, .6, 1],
                ve = [1500, 2e3, 2e3, 2e3, 1e3, 2e3, 2500],
                we = [0, .25, .25000001, .37, .45, .6, .7, 1],
                be = [0, 0, 4e3, 3500, 3e3, 3e3, 3e3, 4500],
                Be = [0, .28, .2800001, .35, .5, 1],
                Ce = [0, 0, 2500, 4e3, 3300, 4e3],
                Qe = ue < 900 ? .37 : .4,
                Ee = ue < 900 ? .4 : .41,
                De = .48,
                Ie = .258,
                He = .73,
                Pe = .8;
            var je = a(21242),
                Me = a.n(je),
                Oe = a(30664),
                Ne = a(56771),
                Ye = a(45896),
                Le = a.n(Ye);
            const ze = {
                damping: 30,
                stiffness: 100,
                mass: 2
            };

            function Je(e) {
                let {
                    children: t
                } = e;
                const [a] = (0, x.useState)((0, v.W7)());
                if (a) return t;
                const i = (0, x.useRef)(null),
                    A = (0, Oe.q)((0, Ne.c)(0), ze),
                    o = (0, Oe.q)((0, Ne.c)(0), ze),
                    n = (0, Oe.q)(1, ze),
                    l = (0, Oe.q)(0),
                    c = (0, Oe.q)(0, {
                        stiffness: 350,
                        damping: 30,
                        mass: 1
                    }),
                    [d, k] = (0, x.useState)(0);
                return (0, s.jsx)("div", {
                    ref: i,
                    className: Le().wrapper,
                    onMouseMove: function(e) {
                        if (!i.current) return;
                        const t = i.current.getBoundingClientRect(),
                            a = e.clientX - t.left - t.width / 2,
                            s = e.clientY - t.top - t.height / 2,
                            r = s / (t.height / 2) * -14,
                            n = a / (t.width / 2) * 14;
                        A.set(r), o.set(n);
                        const x = s - d;
                        c.set(.6 * -x), k(s)
                    },
                    onMouseEnter: function() {
                        n.set(1.05), l.set(1)
                    },
                    onMouseLeave: function() {
                        A.stop(), o.stop(), n.stop(), l.stop(), c.stop(), l.set(0), n.set(1), A.set(0), o.set(0), c.set(0)
                    },
                    children: (0, s.jsx)(r.E.div, {
                        className: "relative w-full",
                        style: {
                            rotateX: A,
                            rotateY: o,
                            scale: n
                        },
                        children: t
                    })
                })
            }
            const Se = {
                animationData: JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":1000,"w":1282,"h":426,"nm":"Comp1","ddd":0,"metadata":{},"assets":[{"id":"0","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAw4AAAI8CAYAAABYh/xfAAAMTmlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnltSIQQIREBK6E0QkBJASggt9I4gKiEJEEqMCUHFji6u4FoRESwrugqi2AERG+qqK4tidy2LBZWVdXFd7MqbEECXfeV7831z57//nPnnnHNn7r0DAL2LL5XmoZoA5EsKZHEhAaxJKaksUg9AgT6gACvgzBfIpZyYmAgAy3D79/L6BkCU7VUHpdY/+/9r0RKK5AIAkBiIM4RyQT7EhwDAWwVSWQEARCnkzWcWSJW4HGIdGXQQ4lolzlLhViXOUOHLgzYJcVyIHwNAVufzZVkAaPRBnlUoyII6dBgtcJIIxRKI/SH2zc+fLoR4IcQ20AbOSVfqszO+0sn6m2bGiCafnzWCVbEMFnKgWC7N48/+P9Pxv0t+nmJ4DmtY1bNloXHKmGHeHudOD1didYjfSjKioiHWBgDFxcJBeyVmZitCE1X2qI1AzoU5A0yIJ8rz4nlDfJyQHxgOsSHEmZK8qIghm+JMcbDSBuYPrRQX8BIg1oO4ViQPih+yOSmbHjc8741MGZczxD/jywZ9UOp/VuQmclT6mHa2iDekjzkWZSckQ0yFOLBQnBQFsQbEUfLc+PAhm7SibG7UsI1MEaeMxQJimUgSEqDSxyoyZcFxQ/a78uXDsWMns8W8qCF8pSA7IVSVK+yxgD/oP4wF6xNJOInDOiL5pIjhWISiwCBV7DhZJEmMV/G4nrQgIE41FreT5sUM2eMBorwQJW8GcYK8MH54bGEBXJwqfbxEWhCToPITr8rhh8Wo/MH3gQjABYGABRSwZoDpIAeIO3qbeuGdqicY8IEMZAERcBhihkckD/ZI4DUeFIHfIRIB+ci4gMFeESiE/KdRrJITj3CqqwPIHOpTquSCJxDng3CQB+8Vg0qSEQ+SwGPIiP/hER9WAYwhD1Zl/7/nh9kvDAcyEUOMYnhGFn3YkhhEDCSGEoOJtrgB7ot74xHw6g+rC87GPYfj+GJPeELoJDwkXCd0EW5PExfLRnkZCbqgfvBQfjK+zg9uBTXd8ADcB6pDZZyJGwAH3BXOw8H94MxukOUO+a3MCmuU9t8i+OoJDdlRnCgoZQzFn2IzeqSGnYbbiIoy11/nR+Vrxki+uSM9o+fnfpV9IWzDR1ti32IHsXPYKewC1oo1ARZ2AmvG2rFjSjyy4h4Prrjh2eIG/cmFOqPXzJcnq8yk3Kneqcfpo6qvQDSrQLkZudOls2XirOwCFgd+MUQsnkTgOI7l4uTiBoDy+6N6vb2KHfyuIMz2L9ziXwHwOTEwMHD0Cxd2AoD9HvCVcOQLZ8OGnxY1AM4fEShkhSoOV14I8M1Bh7tPHxgDc2AD43EB7sAb+IMgEAaiQQJIAVOh99lwncvATDAXLAIloAysAutAFdgCtoFasAccAE2gFZwCP4KL4DK4Du7A1dMNnoM+8Bp8QBCEhNAQBqKPmCCWiD3igrARXyQIiUDikBQkHclCJIgCmYssRsqQNUgVshWpQ/YjR5BTyAWkE7mNPEB6kD+R9yiGqqM6qBFqhY5H2SgHDUcT0CloFjoDLUKXoCvQSrQG3Y02oqfQi+h1tAt9jvZjAFPDmJgp5oCxMS4WjaVimZgMm4+VYhVYDdaAtcDnfBXrwnqxdzgRZ+As3AGu4FA8ERfgM/D5+HK8Cq/FG/Ez+FX8Ad6HfybQCIYEe4IXgUeYRMgizCSUECoIOwiHCWfhXuomvCYSiUyiNdED7sUUYg5xDnE5cRNxL/EksZP4iNhPIpH0SfYkH1I0iU8qIJWQNpB2k06QrpC6SW/JamQTsgs5mJxKlpCLyRXkXeTj5Cvkp+QPFE2KJcWLEk0RUmZTVlK2U1oolyjdlA9ULao11YeaQM2hLqJWUhuoZ6l3qa/U1NTM1DzVYtXEagvVKtX2qZ1Xe6D2Tl1b3U6dq56mrlBfob5T/aT6bfVXNBrNiuZPS6UV0FbQ6minafdpbzUYGo4aPA2hxgKNao1GjSsaL+gUuiWdQ59KL6JX0A/SL9F7NSmaVppcTb7mfM1qzSOaNzX7tRhazlrRWvlay7V2aV3QeqZN0rbSDtIWai/R3qZ9WvsRA2OYM7gMAWMxYzvjLKNbh6hjrcPTydEp09mj06HTp6ut66qbpDtLt1r3mG4XE2NaMXnMPOZK5gHmDeb7MUZjOGNEY5aNaRhzZcwbvbF6/noivVK9vXrX9d7rs/SD9HP1V+s36d8zwA3sDGINZhpsNjhr0DtWZ6z3WMHY0rEHxv5iiBraGcYZzjHcZthu2G9kbBRiJDXaYHTaqNeYaexvnGNcbnzcuMeEYeJrIjYpNzlh8htLl8Vh5bEqWWdYfaaGpqGmCtOtph2mH8yszRLNis32mt0zp5qzzTPNy83bzPssTCwiLeZa1Fv8YkmxZFtmW663PGf5xsraKtlqqVWT1TNrPWuedZF1vfVdG5qNn80Mmxqba7ZEW7Ztru0m28t2qJ2bXbZdtd0le9Te3V5sv8m+cxxhnOc4ybiacTcd1B04DoUO9Q4PHJmOEY7Fjk2OL8ZbjE8dv3r8ufGfndyc8py2O91x1nYOcy52bnH+08XOReBS7XJtAm1C8IQFE5onvHS1dxW5bna95cZwi3Rb6tbm9sndw13m3uDe42Hhke6x0eMmW4cdw17OPu9J8AzwXODZ6vnOy92rwOuA1x/eDt653ru8n020niiauH3iIx8zH77PVp8uX5Zvuu/3vl1+pn58vxq/h/7m/kL/Hf5PObacHM5uzosApwBZwOGAN1wv7jzuyUAsMCSwNLAjSDsoMagq6H6wWXBWcH1wX4hbyJyQk6GE0PDQ1aE3eUY8Aa+O1xfmETYv7Ey4enh8eFX4wwi7CFlESyQaGRa5NvJulGWUJKopGkTzotdG34uxjpkRczSWGBsTWx37JM45bm7cuXhG/LT4XfGvEwISVibcSbRJVCS2JdGT0pLqkt4kByavSe6aNH7SvEkXUwxSxCnNqaTUpNQdqf2Tgyavm9yd5pZWknZjivWUWVMuTDWYmjf12DT6NP60g+mE9OT0Xekf+dH8Gn5/Bi9jY0afgCtYL3gu9BeWC3tEPqI1oqeZPplrMp9l+WStzerJ9suuyO4Vc8VV4pc5oTlbct7kRufuzB3IS87bm0/OT88/ItGW5ErOTDeePmt6p9ReWiLtmuE1Y92MPlm4bIcckU+RNxfowB/9doWN4hvFg0LfwurCtzOTZh6cpTVLMqt9tt3sZbOfFgUX/TAHnyOY0zbXdO6iuQ/mceZtnY/Mz5jftsB8wZIF3QtDFtYuoi7KXfRzsVPxmuK/FicvbllitGThkkffhHxTX6JRIiu5udR76ZZv8W/F33Ysm7Bsw7LPpcLSn8qcyirKPi4XLP/pO+fvKr8bWJG5omOl+8rNq4irJKturPZbXbtGa03RmkdrI9c2lrPKS8v/Wjdt3YUK14ot66nrFeu7KiMqmzdYbFi14WNVdtX16oDqvRsNNy7b+GaTcNOVzf6bG7YYbSnb8v578fe3toZsbayxqqnYRtxWuO3J9qTt535g/1C3w2BH2Y5POyU7u2rjas/UedTV7TLctbIerVfU9+xO2315T+Ce5gaHhq17mXvL9oF9in2/7U/ff+NA+IG2g+yDDYcsD208zDhc2og0zm7sa8pu6mpOae48EnakrcW75fBRx6M7W01bq4/pHlt5nHp8yfGBE0Un+k9KT/aeyjr1qG1a253Tk05fOxN7puNs+NnzPwb/ePoc59yJ8z7nWy94XTjyE/unpovuFxvb3doP/+z28+EO947GSx6Xmi97Xm7pnNh5/IrflVNXA6/+eI137eL1qOudNxJv3LqZdrPrlvDWs9t5t1/+UvjLhzsL7xLult7TvFdx3/B+za+2v+7tcu869iDwQfvD+Id3HgkePX8sf/yxe8kT2pOKpyZP6565PGvtCe65/Nvk37qfS59/6C35Xev3jS9sXhz6w/+P9r5Jfd0vZS8H/lz+Sv/Vzr9c/2rrj+m//zr/9Yc3pW/139a+Y7879z75/dMPMz+SPlZ+sv3U8jn8892B/IEBKV/GH/wVwIDyaJMJwJ87AaClAMCA50bqZNX5cLAgqjPtIAL/CavOkIPFHYAG+E8f2wv/bm4CsG87AFZQn54GQAwNgARPgE6YMFKHz3KD505lIcKzwfe8Txn5GeDfFNWZ9Cu/R7dAqeoKRrf/AjofgyjZ4DnTAAAAOGVYSWZNTQAqAAAACAABh2kABAAAAAEAAAAaAAAAAAACoAIABAAAAAEAAAMOoAMABAAAAAEAAAI8AAAAAOKXjE8AAEAASURBVHgB7L1psF7XdSV23gQ8zCAAYiTBERTnSRJFarZEDdZgtWzJ8tDyUB5kdcVO3B46lVSXu1KpSqddnR9JdVLpH6kk1WnHjtOyLUuy40mSNYsSB5EURUqUOIIAQRIgAGJ67yFr7XX2Pff73nv8SIkkHoB1Hr57ztln733OXfe8h7W/c8+9Y6WUk/g4GQEjYASMgBEwAkbACBgBI2AEFkVgfNEWNxgBI2AEjIARMAJGwAgYASNgBCoCDhw8FYyAETACRsAIGAEjYASMgBEYiYADh5EQWcEIGAEjYASMgBEwAkbACBgBBw6eA0bACBgBI2AEjIARMAJGwAiMRMCBw0iIrGAEjIARMAJGwAgYASNgBIyAAwfPASNgBIyAETACRsAIGAEjYARGIuDAYSREVjACRsAIGAEjYASMgBEwAkbAgYPngBEwAkbACBgBI2AEjIARMAIjEXDgMBIiKxgBI2AEjIARMAJGwAgYASPgwMFzwAgYASNgBIyAETACRsAIGIGRCDhwGAmRFYyAETACRsAIGAEjYASMgBFw4OA5YASMgBEwAkbACBgBI2AEjMBIBBw4jITICkbACBgBI2AEjIARMAJGwAg4cPAcMAJGwAgYASNgBIyAETACRmAkAg4cRkJkBSNgBIyAETACRsAIGAEjYAQcOHgOGAEjYASMgBEwAkbACBgBIzASAQcOIyGyghEwAkbACBgBI2AEjIARMAIOHDwHjIARMAJGwAgYASNgBIyAERiJgAOHkRBZwQgYASNgBIyAETACRsAIGAEHDp4DRsAIGAEjYASMgBEwAkbACIxEwIHDSIisYASMgBEwAkbACBgBI2AEjIADB88BI2AEjIARMAJGwAgYASNgBEYi4MBhJERWMAJGwAgYASNgBIyAETACRsCBg+eAETACRsAIGAEjYASMgBEwAiMRcOAwEiIrGAEjYASMgBEwAkbACBgBI+DAwXPACBgBI2AEjIARMAJGwAgYgZEIOHAYCZEVjIARMAJGwAgYASNgBIyAEXDg4DlgBIyAETACRsAIGAEjYASMwEgEHDiMhMgKRsAIGAEjYASMgBEwAkbACDhw8BwwAkbACBgBI2AEjIARMAJGYCQCDhxGQmQFI2AEjIARMAJGwAgYASNgBBw4eA4YASNgBIyAETACRsAIGAEjMBIBBw4jIbKCETACRsAIGAEjYASMgBEwAg4cPAeMgBEwAkbACBgBI2AEjIARGImAA4eREFnBCBgBI2AEjIARMAJGwAgYAQcOngNGwAgYASNgBIyAETACRsAIjETAgcNIiKxgBIyAETACRsAIGAEjYASMgAMHzwEjYASMgBEwAkbACBgBI2AERiLgwGEkRFYwAkbACBgBI2AEjIARMAJGwIGD54ARMAJGwAgYASNgBIyAETACIxFw4DASIisYASNgBIyAETACRsAIGAEj4MDBc8AIGAEjYASMgBEwAkbACBiBkQg4cBgJkRWMgBEwAkbACBgBI2AEjIARcODgOWAEjIARMAJGwAgYASNgBIzASAQcOIyEyApGwAgYASNgBIyAETACRsAIOHDwHDACRsAIGAEjYASMgBEwAkZgJAIOHEZCZAUjYASMgBEwAkbACBgBI2AEHDh4DhgBI2AEjIARMAJGwAgYASMwEgEHDiMhsoIRMAJGwAgYASNgBIyAETACDhw8B4yAETACRsAIGAEjYASMgBEYiYADh5EQWcEIGAEjYASMgBEwAkbACBgBBw6eA0bACBgBI2AEjIARMAJGwAiMRMCBw0iIrGAEjIARMAJGwAgYASNgBIyAAwfPASNgBIyAETACRsAIGAEjYARGIuDAYSREVjACRsAIGAEjYASMgBEwAkbAgYPngBEwAkbACBgBI2AEjIARMAIjEXDgMBIiKxgBI2AEjIARMAJGwAgYASPgwMFzwAgYASNgBIyAETACRsAIGIGRCDhwGAmRFYyAETACRsAIGAEjYASMgBFw4OA5YASMgBEwAkbACBgBI2AEjMBIBBw4jITICkbACBgBI2AEjIARMAJGwAg4cPAcMAJGwAgYASNgBIyAETACRmAkAg4cRkJkBSNgBIyAETACRsAIGAEjYAQcOHgOGAEjYASMgBEwAkbACBgBIzASAQcOIyGyghEwAkbACBgBI2AEjIARMAIOHDwHjIARMAJGwAgYASNgBIyAERiJgAOHkRBZwQgYASNgBIyAETACRsAIGAEHDp4DRsAIGAEjYASMgBEwAkbACIxEwIHDSIisYASMgBEwAkbACBgBI2AEjIADB88BI2AEjIARMAJGwAgYASNgBEYi4MBhJERWMAJGwAgYASNgBIyAETACRsCBg+eAETACRsAIGAEjYASMgBEwAiMRcOAwEiIrGAEjYASMgBEwAkbACBgBI+DAwXPACBgBI2AEjIARMAJGwAgYgZEIOHAYCZEVjIARMAJGwAgYASNgBIyAEXDg4DlgBIyAETACRsAIGAEjYASMwEgEHDiMhMgKRsAIGAEjYASMgBEwAkbACDhw8BwwAkbACBgBI2AEjIARMAJGYCQCDhxGQmQFI2AEjIARMAJGwAgYASNgBBw4eA4YASNgBIyAETACRsAIGAEjMBIBBw4jIbKCETACRsAIGAEjYASMgBEwAg4cPAeMgBEwAkbACBgBI2AEjIARGImAA4eREFnBCBgBI2AEjIARMAJGwAgYAQcOngNGwAgYASNgBIyAETACRsAIjETAgcNIiKxgBIyAETACRsAIGAEjYASMgAMHzwEjYASMgBEwAkbACBgBI2AERiLgwGEkRFYwAkbACBgBI2AEjIARMAJGwIGD54ARMAJGwAgYASNgBIyAETACIxFw4DASIisYASNgBIyAETACRsAIGAEj4MDBc8AIGAEjYASMgBEwAkbACBiBkQg4cBgJkRWMgBEwAkbACBgBI2AEjIARcODgOWAEjIARMAJGwAgYASNgBIzASAQcOIyEyApGwAgYASNgBIyAETACRsAIOHDwHDACRsAIGAEjYASMgBEwAkZgJAIOHEZCZAUjYASMgBEwAkbACBgBI2AEHDh4DhgBI2AEjIARMAJGwAgYASMwEgEHDiMhsoIRMAJGwAgYASNgBIyAETACDhw8B4yAETACRsAIGAEjYASMgBEYiYADh5EQWcEIGAEjYASMgBEwAkbACBgBBw6eA0bACBgBI2AEjIARMAJGwAiMRMCBw0iIrGAEjIARMAJGwAgYASNgBIzApCEwAkbACBiBpYfA2PhYWb5qRTl68LkY3KaLtpWJyYmy7+E9ZdP5W8r6HZvKvkf3lJNHZ8vqLevKM489VWaPz5SV61eVZx59soyNjZVx6B9/7ujSOzmPyAgYASNgBE5LBBw4nJaXzYM2AkbgTERg5Tmry3lXX1LWbd1YxibHy8atm8qOqy8uW3ftLM8++UyZmJgo23ZdUI4hGDh+9GhZe8465MfKgX3PlNXr15bjx4+Vpx97sozPnCwHnj5Qnn5kTxmfGyuP3/9Q2O/f+1R58vu7y+TyqTJz7MSZCKHPyQgYASNgBF5GBMbg++TL6N+ujYARMAJG4HkQ2HLJjnLZm24ol77uqrL9qgvLGH5WrV1dNp23pWf14u4qnZudLeMTY+XkyZNYsThSVqxdWZ55ZG95Zt/TCCz2lXs/+/VyaP+hcvuffb4wWHnumUO9vlw0AkbACBgBI7AwAg4cFsbFUiNgBIzAy4YAg4Rrbr2pvOotN5atl5xXxnFb0uSy5WVq+bJ5fc6VuTKOHyaWX0hKfenShvYtP3HsOFYpDpS5EzPlrs/eVvZ87+Fyx599oczOzZTnnj5UZiF3MgJGwAgYASMwjIADh2FEXDcCRsAIvMQIjI2PlyveckO56sdeU657181l04XbECyQzI/HXoTh7gYDhFwUXvzPNTXYungabFVgoUCCfT2H1YdjR46W7952d3nsOw+Xb//918ve+x+D/ODiLt1iBIyAETACZx0Ci/9PdNZB4RM2AkbACLx0CHBj80Wvvrxc+WOvLlfd+ppyzpZNZfnKlbGqwI3LGRyQxKusAGGxMOHk8F2l/WgB5Tm0j8NvqGWcADn7yjRY6jtgCKNxcM/EcwcOlXs+981y3z/cVu761JfKzOwc9kQcTzfOjYARMAJG4CxFgP+P8H8PJyNgBIyAEfgRERifGC9rN2/ABueLyxUIGC696aqy5cIdZRU2LvdTP1CgvP9HmPsSGAQMpwgcKtfvylSKYEH6/SAh7blnIhPWN2JpQpJ+CzV6eicR2IydLM8dPFQOY//Dp//t/1UeuvP+8tjdD6Yr50bACBgBI3AWIsD/Keb/D3UWAuFTNgJGwAj8qAjwCUhv+rl3l6vf8bqy5aLt1V1ubM41Bv3JzT+8GQQwWIifbABxRwyBJIGCCWx4xk9S/E61SlOujlVT7xkkIA+x6hlIMGigWBY6ykc7PnTHd8q3/uZr5Y5PfbHsefAxP+a1QeOSETACRuCsQYD/Q+T/PWfNSftEjYARMAIvFQIr1q4ql9xyVbnlp99Vrn/XLWVyeipu+0n/GS7wT23+sY0SKi1YoCRXGhQctFUHWfHIQGJsjHsTWJ5P8E8i2BinHNFB/HGHPh6uhH7GygRtImdLDRTqbUwZNjDIYLmKo4ZDl7hp+vH7flDuwS1Md37mS+Wxe39Qjh0+0rW7YASMgBEwAmc2AvF/y5l9ij47I2AEjMDLgwBvDbr5I+8ob/qFd5cLrr28LJteHh0tFizMaQkhggTektSChSwrOJCcrhRaaPTcF8HwYTDRT7tFCYEDiL+S8qxxDwP1UppBgvQVLETQEBp4eRycUFe+04s8nzhyvOzfs6/c9VdfLnf+9VfK/V+4Mx79qlYfjYARMAJG4ExFgP8bzP+f6Ew9W5+XETACRuAlQGDtuevKVe+4qbzlo+8vO6+9BBuepzuv/f0LDBSS7EdosGCwAAvuKeg0a7gAXSYGBhkLRJkyBgC1PZR6B7WR8EsYwUCUFQzQGasRSCBnYMDggT+RR3BBjZSxxIR6Oo06DyfxQrnHy/e/fl/59P/wH3EL06Nlbk4rIp2KC0bACBgBI3DGIMD/Dxw4nDGX0ydiBIzAy43AFFYV3vaxD5RbPvLOsmPXhWTeQfqzXwYITLMMBCq5zwBCbXNdGyl26sfaAkwzwGgBB71FQzB4vAgakcVif7ZF8fFaCCWoJdnXygLrKsWKQg0EJnAjE/VolgFFf4VCQQVdKphIn+oEw5mZKfsff6rc+VdfKl/5v/+mPPHdR+Pxrnn+qefcCBgBI2AETm8E+P/EYv8Dnd5n5tEbASNgBF5CBFauW12uwGNV3/pL7ysXX4fbklauCO/9FQaR/rzBCKsNCBzYPstwAGX+sY0AQaGD7EOntUMxdCKEAJkX+R78M113OcC+FyHUMgOClrhKoNoYVjXica2V/FOPqxPjcD3BoIGK0JlAYJF6CCd6qxAKGxRYZL8MRFr5BB7leggvlrvrM18ut3/6i+WBL3+rzOIt1g4g2hVxyQgYASNwOiPAv/iD/yOdzmfjsRsBI2AEXgYE1m7ZUG7+qbeVN//y++vTkvLdC+xMAQGPEShEgKAbjyhj0DA7JIsgIgOGaseNzeENcvrMG35YY7BBok9ZEH76q4Q9b1lSve1xkK5IfR5pywCCTkj4YyN1BBIIHhgiUBb5Sa5BRL1KIoSIACP05TFubUKdqQUQGBve+/DM7n3le9+4r/x/f/hH5YnvP1qOHzsWej4YASNgBIzA6YsA/+I7cDh9r59HbgSMwMuMwIbzN5f3/d5Hy40//ka8j2ENGXL0yHUEprilCH9F49Yk/DlVkEDiPxOBRAsc8Mf2ZA0oMmhAsBArEBEs5B/jDBqw6Rl+acGnIvXTGPycxMoA02JltuXtSYwVJnCoQw/qn+0k/LkagRI9agUCOYMI3vZEHQYWChTGu3b6oM3CAQQaEb2cmJspX/rfP1X+/n/9RHkKwQRXJZyMgBEwAkbg9ESA/0s4cDg9r51HbQSMwMuIwOTyZeXSm68q7/ntny2Xv/76MjbOB5qKyDPnagJXDnIvA+sKEuqtSWDNsyT4XB3ATwQIzKtsNlcYoo0eFYTkbT38wzwegQYfzzqccu2B8sXKsuEfeaa2IqCAIutcWcj2CAAQYIzHPggGCww2BgMIhg+UZ1sGGxlAhK+eT9Z5/oeeOlC+9v/8ffnW332t/AArEccOHfFGaoLjZASMgBE4jRBw4HAaXSwP1QgYgVcOgV23XFPe97s/Xy675doyuWw56DkJOhPJfz8QUPBAAs8ggisODCAYADBIYJn6vBUpZNAhke68VV/yDO+ot5S9UpYhQLb3ZbTo/zlPXXnS2oTKsT6QSw8QRbAQwQHbFRDE3odazoCAwUSuOUzgXMbH4uYmaOEn7KMUdXpaaBWC573vB0+UB776rfKVP/mbsvu+h8uze56mupMRMAJGwAicBgj0/6c5DYbrIRoBI2AEXn4ErsajVn/idz9adl63q0xMToHkk+aT9ipxJYEfygZXGWYjcOg2RUfAoFWHbsWBfuCIdSYGCuk3w4RoCGm2aF0h9HHIsCBb8w95ymWvY72hqYoYNvQT6D1IP+1I9JkykMiAgLc4McWmaeh0AQSCBz6NiRupM0igL61gKIigXbaxzHYmPrL1KFYcvvGXnyu3403U3/3it2IFIhp9MAJGwAgYgSWLAP+K5/89S3aQHpgRMAJG4JVAYNnK6XLdu24uH/qXv1o27NwSXWplQOSeJD9vTYqAgSFFrCpQCkIcAQV1tfoAQeEtSdTlJmYGBtyvsFiwoGBCf5Ln/WHuBRgvBIv84x5kHbZJ2tNW6wcKSBhMSA+EvwYCIvyUoxQylBFEZABBWdyuhNCAsi7QYKn6UPigYGGhAIJjOfj0gfLNv/5iuevTXyr3/cPtZebYCUZTOUznRsAIGAEjsIQQ4E27/2oJjcdDMQJGwAicEgQmpibLVT/26vLe3/unZfOu8/ndOkg+CWwLGljvVhPQOhPBQK4y6DYlhgZxexLyOQQNsS5BvZMMLrRfgTr0qlBCPUQdeupxIQgamdZaB4g81BYrD3sY8Atiz141CmmyZ0nHEOzozOU9VCMoOhnLFTwXjSXeKQE7/VCPPum5lxQ3hKBXVB3jWL5iulx4za5y0WsuL9uvuqgcPXykHD14pJw44k3UPRRdNAJGwAgsCQQcOCyJy+BBGAEjcKoRuOS1V5T3Yk/DhddeVibGJ0GARYFJgnlbUj9g0D6GWTw3CcEAyDLbI4hAfhKkuwscaAd72SZRp4SJKxHM+sFCo9xJwCnRp69Hw0GC3ixTf37eiLt8yQuOaKB9jBUl6nG1IPZloJ4jzrGyPTZ3wyiCBgRISkNjrH6jrVemFlcgMnGFYhXek7HjsgvKq950fVm7fWM5fuJ4OfjE03i5nJ5elbpne06snIyAETACpwoB/gXKv/inagzu1wgYASNwyhCYmJwol9x0ZfnIf/vxct5Vu/hCg5pEmOMpSCTPCAK4ZoD1hdjHMMOggEFDlaGIkr7DJ9FmMDF4S9JMOoZWJfU06v0Jzu/5tZbQ/jR3xL3z0C9QL8mkylwYoM3gfoa+Te51yP8CGCYoNWIqHRJ8bZZmL7zBiaQf0nzyEnN0G3sdQGq7DdShQzjxAzl/6CtvY5I3yQdGRmKMPRBPP7GvfPUvPltu/8TnykPfuL+vcsaWV+Jxv8ePHI3btTbs2FJWn7OmHEDwNDY5XnZceXFZtmpF2YsN5Ws3r8eG/anyva/eXdafv6UgVi27v/dQWb1xbTn63NFy/PDRwJnzz8kIGAEj8FIikP9rvJQ+7csIGAEjcNogcCFukfm5/+aflYtuuiLItgYe36NHgEAyH0EAWhksRKAQQYNWFljn+xm0ygC7vCUJpI2hh0g/SyJxcYw29ZTyfgDBliZHS4//kVdnXWU2Ju2Xz9Rh4FD3Ng/oDAYUChBkyaN88cjgoOkm6Rfl7wKICBAUFDAwUAChR7ZGoLBAAEEPGUxkQKGe23kogDlZfvCtB8qdn/lS+eqf/H05gPdAxB4IKp8BSbdpXVbOvXhHWb52dZleu7Js2L65bN91QTlx/ESZw1u3z0F99Tlry+H9B8vE8qmyYevGcnDvM+UYAoSVsDmw56ly+ODhMj09XZ56Ym958qHHoHu43Pmpfywr1qwqj9z9QLy9mxvSnYyAETACPyoC/Cvd+y/pR3VneyNgBIzA6YPARrzc7f3/5S+V1/6Tt5Rly6crzSfhb7cnaUWBqwtttaGtPkBWA4QZWMUKQw0KFDLo2F95IDr9oKD/J7gvb98W/6h/ptNepJxBhVJX6AUHrY0BA0l9HJExCGDKVQOWGS60AKIGD+PQiE3U2kidgQFbJ+CCW6oZNKikYIQ6/GFSsKEy61QlSX7k3u+V2z/5hXL333ytPPng42X2NL2FiSsJr3r9deWSG64q5195CVYRpss0VhbWbd9UprCKEHMFm+pxvxywGJF6MSMDg3FgP3NiJlYtxuFj9/ceKQd3P112f/fh8v277iv7dj9RHr/n+2XuBFbNoOdkBIyAEXixCPCvswOHF4ua9Y2AETjtEZjEt7e3fvwnyzs//uGyauO6ej5cGQCx54oCfrqg4CR3M5yMfQy6BYlt+MQmYq5IMLwYi1uXaqgQfvLPK29p6srRU/uzu3CwUIdTs75OvyW/Q06CyXqWqZdkv2/TyiLnCiQaUe/bKzSgRdUlva+RRwYQ1Gcr63mbEnXiSUtDT2FicEAdvo1aKw5RG3yka+i0QIK9M9Hnc88eLI9/+wfly3/6t+U7n7sTAcRjalzixwuwb+aad95SrnzbTWX7ZReWkyD5vNVo2eqV3cgT97ymXcOIQtotpsYAi7fjHXrmWby5e2955sl95Y6/+Hx5/N4Hy2P3fr/MYmXDQcRi6FluBIzAMAL8e9/+Bxtudd0IGAEjcIYicPM/fWf56X/5sbJm4/oIEniaXGvQbUkMEkjX5wpoVQQS3PzMAEGBA8p1EzS/IZYNVxJI+xQkcEtvrhqI+OtP7SAx1CoF++4n6SiIITEctOlrvvByn2DODyhqYBCZyk1f/03IpuqB3JPIp47KJPuLBxAZaOSjW+P1cTBQAKGXyQ28E6IGEDxDeda5si9ifPc/fL18FW+ivvOTXyzHsC9gqaUr3vrqcu07bilXI2DYfNF5veEJw56gV9RqlzT4BC5tVKcCZ0/KVaNUWLCUrSrrmNdHNelyTh4/eixWIXY/8FD55qc/X564/6HyxL0/wNvR0SdXO5yMgBEwAosg0P+rs4iKxUbACBiBMwuBq955U/nov/3tcs62TfXERNgiCCD9R9CAO8yR50pDf/WB26NJ6kn6GUiIxkEjfIUcJQUNIv9J9DIgiAWIDtJ+QJH6XeO8QiOQ8ioyOU9tpKBPKlsg0bwFP69UdSFdkXkFEOyMOiL1Cih4nAzKD5/YKzEJh7yF6aUIIDJ4OPzMwXLP575ZvvGJz5b7v/StcgT7ADJYGwnAS6wwvXIFgoSbyzUIFq5FsLAS+xIWIvOtW133OMZF1RzECWBu6TrwNrBIUcUh2oA167l5RarVgtr9MEt1HvvXUONCwDuDGTk5Vr79lW+Wh26/v3zhjz9TDj7yZDl24DBNnIyAETAC8xCIPz/zpBYYASNgBM5QBNZv3lB+6g9+rdz0kVt7ZwiyBlLGG46U41GrvBWJP5DH6gPqM2yvOiyT1mkzNF2xhbc5ieyplfIMBiTvE9um8/yrCpU+0lmQRzD0VmaJ9dpv1yaNIJS0rxZVOpglqVTe12RgkLpthYGSwWBDZFUrD2oTuecmaT2FiSPQW6fZzh/6bvsgcgWCLSxz9YGbs/Umalor6GDf6o0llKG376Hd5YEvf6t89U//rjx69/fKwX0H1PgyHzfs2BwrCgwUGDAodYAN9d6uIkOEvFz9+dE0qikE1BWWeekzwCA+7cqqVxzxb7yKG05ZamPLax4G6OPoc0fKc0eeK1/5478u3/zLz5dH73wAeyGwc8crEEPX0VUjcHYjwL8i8/5Wnd2Q+OyNgBE4UxEgAXvtT7yl/My/+c3eLUotaCCpZ0DANzRE4MA6b1liEMEPbk9iYBBBA3L+8aQ2A4D4Qxoy/UnNoIDBRD9Y4J/cfttiWPdt6COJHssvJKV+p4tzH07zJa2fFhikFYlqK6f/pqdGUlTizPYMDljLTdSi/QwYJGWAEG+g5mNd8ZMBBB/jSj9sy9ub2Dt1sk+WQ4aM73vgffy3/fnn8flseei278RG4VB4CQ/nX30JgoTXx56Fi197VfXcAYO6rr/mA2uqS1FBZE9D7RD0Ze0aU8pblhY+yqeOuh6JCPSBHVNKIhCrEq5W1OaQ5LWk9rGjR7Gp+uFyB97m/a1Pf7E88cDDeLzrkdDzwQgYASPAvyz6e2UsjIARMAJnOALnbN5Yfunf/X65DC8ZG8ez8YPWgeznC9sYHDAomKl7GeKWJW6AxmMxZ/DtLtcUYsP0UNBA2LTSIGKYf1ZFAEEdoZ+JQUMjhimFRU+H0kGdrHHMWW62i5eSEtKG5H0odeRySB7aTZZEXZI+6cwAQaOSXiOsCiBUb5uh2woErRVAoFSDhFxliPCgrjg8XwCRxJhjE1k+WZ56bG/5wn/463L7pz5fdt/7UDuRH7L0qjfdEPsVuMF5y6U7qxedlyq6vnGsc4PyDBBZZlsGEZRzsYB5ytg6fGVDApJPW64unCThpzMa81YlYMY6p44upa4HaiHX9Sa2YSRbHDOIkFY0UqHOD+5zwO/AzEw8yeobn/ocNqP/TTm8By/jO+4nMQVQPhiBsxiB+JtzFp+/T90IGIGzBIHJycnyjl//YPnxf/ELZTkegZk0rj05iWsHvEWJm6FLDR4g4SZoBBQMIvKRq1xjYGIgQcJPYifipxJrQQq7KimgKn1y2Jrnk0Z6eOlTBh4thIgSWWdln41Gtt5Te+EAQhapQ6sMINjCsgi9SC3LSW/ZxnCGRDb1YoUhbHibUqxF1A3U8sMVCQUh9JN9tzL7zwDiu7fdW+7At+Z34DGu+/EitRNHjrF5ZJqaXhYrCrlfYTU20JOMt9RdOV3Vbg7ouqdePyzQfKCd5kvOh5gZCAI4l5ia51bLmUCMWWbcwEvGsrCmrkao6xBohoAIqi0xplg/LaAYxE8+aKdbmHZ//9Hy//53/7589+9uwxOY/CbvANQHI3CWIqC/DGfpyfu0jYAROHsQOHfrlvIHt/9vZWpqWT1pUDYQPhI4rjLMIWCYwWboE6jzmfjcFs0AIW5RgqxthI5wIewWChqS5PH2pkzso9UkDYJIsl5TEses9/MMTUjvstxvH1Wm3eJJKxEiodAiI2UWx8FDCw6S+qtdRJ3lQblIbSWpaNUbqKUjGxFcHuMzL4CAFDLdtsS3UEs/A4e8hSnPT629kaN47NDR8ui3Hyxf/09/X+7526+Xpx7aE9dXI2/H9Vs3xabmq+vm5jG8R2EQhXatWOqvELUgQDq8RsRT80My6ehIebRH95xbUdCcgm3b+NzaqHESEQM3mKuM0UFVl0sIZDkUcBAezKmnEIJHynluxLaW6ipEIjl4HecQST+zb1/54n/4VPnyH/11efrhJ+LldNmPcyNgBM4eBPg3o/7JOntO2mdqBIzA2YXA6vVrykf/x98p17/nDfXEQdxq0MA8VhoQKsyAIEXAANIfqwygcny6Eoke6/xjyXUJllgWeRQJVCvdJ9mjXH9e+0FD9wc3+qd+pqYl7yl/afOkhvO9trCgK4mJBrmcry9CKhKarSKjrHU+oiyyy76DzIZfkdPhACLWGNBOvfiwXG9Ziq3ScNUPILThmp71E/5RziT/JV6K9tCd95e//fefKN//2rfLgSeeKjuuvDg2NfMWpEtfd001abb9/x4VBKTXtrKQ14p5zAtcYJUz13Wl/Vi95oPtedtS+k6PtT5vnqQeMI6harx5FO7AArjlmbAsXHhdUIo2ySbgLuu00G1MaUudTGPl8IFnywNfv7t84f/8ZLn/C7eXI8/66UuJjnMjcLYgwL8r3f9jZ8tJ+zyNgBE4exDgi7ZuQMDwC//T75RlK3iLkgidAgFuftbKAnNuhOYtSWxrKw4MGkjmFDB0wUAQOv751J/QJI30L52UU6IUEtgxiU6+MsGCeh88khryrJIiDrY2utiVQDaZkoymfraTmLYEr7Wa8sypwz5ZJ2FlTWSWuIQ0jhlAxOoCvmWPPAIIauMHpmEHe648dLc70S9+mOStDoQCFEngd9//SFm+clXZdP52SpGajoJBSfsUPq87WyjPtrzurEcZ7VqTUl/NX78d2jGnoItlg3FMg/TP6ZErC3N4PBJXFZjY3sdQUh2FYy1zRQIXZbyuTPSxzkCD1yzwpUdcg1yFIIa6OgogWn8tgJibnSv7H3uy/NX//EflH/+Pv3hZNqDrTHw0AkZgKSLALxv+1VIcmMdkBIyAEXgpEFh77obyT/6rX8Sm1vPDnQibSByDBBIyBgnc18CAIW5Pqi93Y8AgMshcuuRxIoN98kgZ3YvliURmreVUYqiQR1q8mKSxyF+MA8aj8iTRz9cPdTjmptu86ixbS0YESbVTk/5Z7mlGjZxc/gfbqRthUzBj9pLqtZztaCCfJQ9O3Em2mWRT9VFRPZq6A8fZHxNXKNZsWldWrF2p8aKuayeT1rvIOn3qwxb98DrkihX3vXCeRF7nSKxiYS5p1sgmNuDH9WdgihacA3+ole8FiesLeVgiTzlHQKzkUe2UsZ0p5ayxrHkG74EZhOlTJ0IT2CKhPW9+myNQvUTVDOzy+gWWiD5WrFtdLr7h8jK9YW3hKs4M3j49AGLPj4tGwAicWQg4cDizrqfPxggYgR4CfBPu63/6neWmD7+9cMNrpgwBSLK43sCXuJHMYc0BH+QMIGpQQbJKfabgXaizFAQNpQgEqow6InEsKVE7SZW86Bji8Ci94SP9qKfa77CCHEhKRhcdVaUeCRz20SfRVXuBrK8lx6K5Ci7inGFFYqmuKSEFVWI+zwMUB9up286RjpLEsty0K8mF8WAAAZUg39I8yadfVbPI49vz5j9csr0m1uNJRbjiTOPYA0BPiXv1FiMMAh/zIAMEzhGVYy6hQ80SHGPeMACVTganMZ/qnGIbf2jLMudH9IERZP88B5VzTLLhuCnnh2VJod1hoTY0RZuuFbSgHNOUefVBQcirF9oQZLbrWqg95HFoV3XZyuly/pWXlM2vOq8c2PNUeRZPXeLTmJyMgBE4sxFw4HBmX1+fnRE4qxHYtmtnefd/8ZEFVxsYEOjbYgUJpFu54qB9D5AE0xK5C4IWdWoqkbz1kwhdk0QrbETeKE9LkbqmOVga8DvYxaBir8bxNVrXa8hiEEc4S4KJYvbDLgY/cbaVQKYD5aKrKaMHUkz1nLctsTW/waZfElwllOKfyGlrU3/xxuRoZx1jCkOWlEKGgwKIvD5oq+dErbleAME6N2RHHh41lsRJgQ871MZ4ynkuJPRxLePaVVLfL7MdQQBHKT1ZcLUq50600QZjo44CA5X7x7APT5oTtFfvMexoETq1va/bL8MO1ehL6CHgQt/NC9vkozvi1LnSFgnlXrEGFAEt5ECm80U9IcjbALdduLOcu3NbOfTU/rLne49WZ86MgBE4UxGYPFNPzOdlBIzA2Y0AVxve8KFby6U3X90BIaInwhc7Fkj+wJYYROgWJWiASUmDZknhIIcOiZWoP3WUKGcSAawyZXRc9VI725OipaLsu9r8ZjSp/05ngULToAMR5hg0i9Wnhts6SJsk03TbrHP8used58iRZoBw8iRLoJFBjtVCCT/cCJy98Dt92chzfMtOHdwmRJ+y4SBJvEnceY8979PndeEeBgZvqQtyDx0+XYj7HuhR7zdAfxhHyOkJNhMnsY2a44Ce3g/B1QvR3rh/vw6QbVM8BzxVi630x3HFSlT0wD54PrqObFOdEpY5cvaDAv8FHtSvdeYcUy+nTbRDTuyz3GaKbMIwDqyzlWj121pZ/eli6yzH4nyjzLFFP5JxX0PIca7MJ5hz3DF24I9rSx0AhzbiphmiJ1rxvDUnJpZPlSve8pqyYcfWcujAwfLgV+9GP05GwAicqQh4xeFMvbI+LyNwliNw/a03l3f9858t02tXBckjHEHuQJO0soBQAYFDd286mJza6wpDrYcMZdIuET8RNUoWCho62MNevaZMXrLWcvmtdbnvGhez6RRQ4LfUNHshH923PtRJOOtbN++koY3iSp6apJz9pFt/hFOsHoRlo7nUlj/yURHc9B2kO/RJY9u5pEH0hQa2JiYivqzhJxzX1tCDEyQGEOw1fUa30aJ+olgPscEaiuMgz4AUZBmfunk+Vxj0ZnEGOJonsVeB+Afh5hzSD8fE6xqrELXMb/djPvU65eiIS35oTVv+8ExbjRLqtR/hn5bDtfSZdjRWmSs0TDqGGP3UOoQhr+cTisCE+CmhtQNRuLJ11Tlry4XXXFaefHh3efbJZ/C+B78sLhFzbgTOJAQcOJxJV9PnYgSMQCCwYdu55R0f/3C5+OYrURfliRUGUCJ+48wfET98+8qnKYEkRTvIoH5oI2JIhyJY1S7qKEsYxI6kK1OI0dhkzTp1Mh8gkdUf29jTQok+k8D1g4Vh3bSmLn2lDfV0FjonUdMsL5TPJ6OtL7Wlbz7hiOw9x55xAQm1vlGXf41BejFOOMgxsp5jph59dOOtHdFSt0E1H3mGtNdHEvWNzc8RPKTvimH1l/rtCUIMHMbLJNqn8OEYGGie4DyJvjFD4vpqZLyGOWv6cyzklajnuJKcq875FWcDD/ypIQIbkdhvzCHUqyjkUUYbhSwzYMp2+dFVVZn+sz1bs05bWSroQh1VPskpfLMJg5AGddmpsIsrGrZNxmY+iGDLZReUIwcOld3f+QH8pXWY+mAEjMAZgIADhzPgIvoUjIARaAjwm+zr3nVzedtvfLBMLl8W5EWUiXyIqw0MEuqG6CiJ9lEe7XBFwkNpSIL8iNZFL6HHkmRB7qIWrTQW4YujfNaWgYzeuzRQ7FWgoFGwNyQcmA9qqGG+jHKk521ojZUXyqY7sj0/rSS6KHm2DpwPrchGg1w2Sh432aAj2shH11GQVMrkL1cIWKNM0kAT9tQLLyiIJqcd8uokx9OuACxqANHtv6Bu+JK9/FYh5AwgptAfPyTOR+cQOmAouiaaI4PBAvzU+cERDwcKsqszK04tDhxCPcMssZ7jSB3Wh8up07OHiGOkuTIeiULDPTFJby2ASOO0lwZXVegjrmTFnxIUpQjfLPJ3b93mDWXH5ReXI8eOlsfu/q4GQTUnI2AEzggEHDicEZfRJ2EEjEAisOn8LeXHf/vnytbLzi9j46Sqw0SPwQO/7cXaAxiWyqBS3WpDCwhEAjMQSD/02HRY6xL8KZDIcKJr6Qoij6gma4tir4J66oS019SKWap5Vmsvg4SVNFHdDefB+6I/tYv+QZAN6Rf1+kV0kMMQ4xCxQWcvI7a1EirsHcST8iTc7Ce7SG3q8YfyvOWJtaYnDbJi+hLZZXvzH3L1GGOjLvtkkvcooqzrQ99qRQGVtI8x1J5JhnkL0/LxifhwpeoENlPzDeNavYJdHRO9D2Af/dezrp11/bWeB20gz3Eoz3rmCgDyfOiWfTJvSTpxTnDSrShUz4lr30f4qU5ijCizKpGuQ2CuaKGT5xygZujjd271xnXlgmt2lfu/dmc5tO+An7bULoxLRuC0R8CBw2l/CX0CRsAIJAIkea//MB6/+qG3lWWrpiuhS8JVgwQGCJXQ8dti3qakoIH3tIPkoS0IIfRIoJJ4BiEMRhUH6LQkcdJRkVK2queml77CcRXP1wnDzki9sZqlmmcVLfSrn9TqNXaeQO0oFhPM29yjlTRT4vSNHDhUjhg6zSNLbdRBFsNt0wg6z4Yq4n6HqOIQbWgQFkmCc1jSSyKsAEJ90ZVaa+8Q5Chi9Dg5eqPewCc6zv7CicaCIhN1KQibGB8FqtO0n6YQPCwDMeYL5xhA8NYlzpeYG1Dk/KGjXK1inmdGP7pOtS/aQhb9s3GRlL45ln451dM+fQmFfq/1LLqTySvA/oVo+gifNchLWT/PACRcYXLoB33FRJEmj2yfXo0X7F20ozz9yBPlqYefyOE6NwJG4DRHwIHDaX4BPXwjYAQaAqvXrC4/94e/Wc7ZuTmEpEYia1hhANFTQMDHsPJWJQUI2iuQbUn5aClCSEckbEn3+uQvpSTZ0knNpFthGIcgyj0x/Wca3q/QWljKD8aBYtY0wvnEczA4EI0kkRNvZF1ljlSyhQkpmrvE23Rav/0xUEVtfV9pKJnIacjopCbuieA32PlDP9RPlShHBf6zgpz6qcdypMhqrQYQtZt6XWBHowCH5bRMb2yTBfXoLkddxV2dQQNXH1aOT4W7Y7j9aRbvL1CQQCw1B+iNJfrKj0psGW7TOKSnsaUNplYEcFHvleMxqjHWdm1yrPTf2UeZZ0NJ06VT1vRDS/VLNQUI1O9giUKFrwWUMMs+I3ZATT+QQ3DO5k1l3aYNZc8DD5UDe58Ofz4YASNweiPgwOH0vn4evREwAhWBycnJ8uE/+LWy6803lImpifpNsGhRbmZlzluUSOIlA83Lb46D8ikA4LfITJVKRd5kIn21Wyhl0CCLTl4LGWj05fQ7HCy0dvadH/SFYquxND+R0JHAicQNBge0SHLXJ7L0orCi+QzLeu6yUlsSzLjxC86yPzoOjdpJUnpW+eFKQ9LolOVYksTTJx/sGWQeSnNioJDKh/rWWGlLQirS3HrTdRIp5vVgX7SIW2uirINODfJQwDWIwVC/+gw1CqFQWbJ8cYz8hEFoMYBYMT6JAGIyZhSfthTziv3KQ+j1D338cz7xdDvIQzl7ZKWOpe9koNzGE2L6gg1HwLy1qk7Pkgmr6AkDSItEFMb81wUI0mMP8tnq1Ml+kIdzHiSbmJqMd6isWrOmfPMzn8d5hiUdORkBI3CaIuDA4TS9cB62ETACDYFx3D6y63VXl/f87s+XFeesDoIi8kQCRGKv1QWuOvAnVhtADLu9DqROsSJBEifLJLxB/CvfETFUv30KpNBBElr3U1dDIcYS/vsakncStDeC2Vl3zVngexIaRWt6zTY16R+p00cZhqhSyGch4RiMj4LQZVN+sqXlWQo3PUvsg6h2CgbYTs84a5rAIUkm/SbVRDGcEBfaaCTyrw25CjwoQWgRfqgrDflihXXK6ZtJOXBUZyFhkX3ouspXjA0yBglsD7sARr5DGv7VI+ss5fi592EKb5xehdWHKQQStD+GeZQp5g4q6VuYZ2v0lpWBnB7Uo8bb2UPOMtvyOqceRAOJJL7Z5YibvZShFA7adUn/0V4rzLo6DDqd2vlg8FCF0FOvY2XD+dvKseeOlKce2o38aHpzbgSMwGmIgAOH0/CiechGwAgMIrB8enn54H/9K+WC11zeNYi0geqBrcVjNOvtJCwrYFAYwL0KpOpRg26QxZCJwMuhqBOPjUSplESUemkrG5K7qo2MbVxlyDSg24nZZ1dJ1chboDBIHKk98EEfQcLB33rdDej0Hau3hfokAdQo2Zp0UL3Rg2zat8wpUa6QQXbNVuSd1kyyjVL99l+2pKayqT1Dsf9tdYwMZD/9xkhQGa5HJ3FNsw+hG/aQx7VLo1hhSBl9N4JMFNpYOcbWNz1z9WG6rj7wNqbjWIM4UQOI/jVoCDXiz7HTHz2qrHmjecXAiW2yzDyDBtZ51ilnnqcTTXGoEmQ6q/SVwYTs05C11AtzOOW5R1+RY37xetS+GOC1py2xL/gNLFnWeCaXTZYNeLv0kWcPlofuvD/kPhgBI3B6IuDA4fS8bh61ETACFQGuNlz/7lvKG3/pvWX56hVBMEXESHZExLXSwDJXG7ifASXk+oEW2J02O5MOyYbuw08wpj6ZqyQK7SJ3OlK3n4Lw9VjjYNBQNXu+o6++A5T7wQKbBgljU+6TakoHR5J6C0tDH01JjHPIQRZ7Jizmp1FCEe0gmxDmk5e4wiBqKVRolzQ1fWQuX2xX0v317CvJqTSTzMZboCGiPnXZmpoho6Q6YxvLkeOoHNrRXq8bhEnOqZ6rD7TSrU7yrrY4dge6yfPit+6TWH3g3oeVY1PAYqwcnjve6eracQzyl31yTMOfNNJ4eawnFJqD5fm28t+3kj8S+uxLo05beax26b6Ok7YRByAnbtGMA8s8R80bXZ1ceYha1Y2eUF6NF8Rtvvi8ct+XbseTlvZrSD4aASNw2iHgwOG0u2QesBEwAn0E1m08p7zrtz5Sdl5/WcevSMoYFGi1gUECVx2Y6zYlBQ0MFkQeQx86JFKStJxUS/76vQ62D7ZUIpoMnD67cpJXypLEJX2Tl36wILKZeuoTHCwCClotnFoLuyXBC0kTD5mxgV4z9esLGZFg5g/tKqWHangBk+x7o9cYAweDBnlvfpNIp5Xaw6oS3STCraW24vqyhIQ+E9k6mugnGW+ooW+OK0fOit5urSueWNEwdKhc9XPc3XWsvtRezzu0ORTcvoRgduXEsrIKH27EP4aeOIc4jvyoRCONvXYXXmK80dK0oqEeqEudvo2aEiu168wS2WoMK5J9jUNt7RpQp3pFxlaNRWOPetesgoKKUIaB/NF/luWF1fGyBo9p5Vx4+I77fMtSXg7nRuA0Q8CBw2l2wTxcI2AEGgIkaVe8/rry7t/7OWyInowGUpwk+qRr7YVvXGlQsMD2eJQmcq02iEZRTkoVhD1YafNF5yJRLIhIicpT3rVEkNDqkrNOd/1AoHkDbUNbcC12UpNInypRhgPqMLXeVO9LYtgpRp5+eW6yb7e/pL+e+vMUF9fmePjR+dWTQUaSSCo5aCkyShnbCUwjsqgjJUGlT2rnnon0p6vS/HYrLtGf0JdtJb75lXkdSHQL36EZNixTAAnqsWk6gERP1Sba4Ud+pZ/jCVO0VFVWcfvSGG5fmiqr8VkO0nwi5iKvQniqx1CtnaOcDqRSG19AlnY9F7JK4s8uGl7ZJtybvOnAYfVJD5TzdiSVkEdb6tAeP3AWuzzolPpQ4g//8RAZSmvxlKUDe54pj977XcD9Yk+UvpyMgBE4lQg4cDiV6LtvI2AEfiQE1q5bW37h3/1uWb/93I6EiJrlPgbmLViIlQbUY88DiBzfbsyVCPIXkiLSGBH2RmhYajVWFFikplohg5J0B7TxqM6sy387YdAxNIlQpU6Sb2klsUrS1bcVSed4mrRaIZNF0tRUYR5lHqASdRwiD5HOjURRMlHFVtY5qJ46fXs4qYk6TGGRfdW6KGg0o6c8O1mIzGawIJKqa5L7I+ARJpWmxjg7D7g24SXa21jZh8bc2lmnneSgvGFTe4KQdSrkNeDFki6vEdYqgiDr/GoxToha+a5s6vD2pRVYeVgzvjx8HY11LnYQ6nHoX6fs48XmHY4cd01ZzOvJE6LflKceBWnf2kMY2myjDY88P5YDH5ZYQeJc5m1kCh74sF0KYVFVaEVVvt9h/fbN5b7P3VYO7z9ILScjYAROIwQcOJxGF8tDNQJGoCGwfHq6vPWX31du+sitnZCkhiSMn1hdAJHMN0TH6kPItfLAYKGWIBVhFg1EjewpZClnjaI4dtrSgo7EkLOgigKJ2jBgQZLVqBx9ZBAQ1mGSdmxV6pNLdkESJs6mMao86KsOJRR5mw29kr71fVEmeY5c/f0wx/TVz0UXSfoxwjrIfjv7Uf95BpTISuRUAQNJKRN11V6tIE9/fQ+hB4GoLu2Suqoc9Bftec3kA9j0nPBys9vY64By6IZP0OKocyi1BzLnGFk0dcEDZfn0pbUTy7H/YbIcmj0eKxC0kBW1frSUvpgn5om3Tqnh1NOoncZJYSwVd0g7P2GsUbI1f2gY2FQbVvIaK5cvmvM2JdmhjNu4ztm6sRw6fLg8+NW7y9xshoX06GQEjMBSR8CBw1K/Qh6fETACCyKwbdcF5Rf/l98vfGJLfissQqxVhggeehuguZ+Bqw8MFtimDwgS2SHq/GkURkRJLdl9fM8MLSZohy8RLMkk71Yeqt8MCnJ1Ielbymmb+xqaH/piEBBUNfps9oPytGEeXYalDn37FKd+1jMPe1SYB9mDs5CBELLO8QaHnFdWO8QLpvQbY4HPyq87kslOMkBIXfbDcqbot54cdbONufDEGOA4iW/aMQ9d2KRP1kVsG7ZslE/MgfCjWtpH13Xg0QvKef0EukZB/bYSoT4THcr54dOXNk5Oo8vxMnNyNla/aNdP/TNZrNzXb2Wepc6FZ8BP9C9xYEAJ5Rx/bY1SlAOHbsQD+hh86MsnfVfvEKcFHU3QiqpIcc6oZEAhTTWu3ri+PPngo2Xvg49J2UcjYAROCwQcOJwWl8mDNAJGoI/AKjyh5T2/9TPlotde0RE1hQOgM2B5GSTkasNMPEmJVIdhA0gP6qyR+lAmEiUyVPkpZCKH7DdKYKzUD9qeJLZKqKFP+kjNMKhkOXtrmmwlH+1IaKg3W7aRZvGzUBBA9VxJoJX0+qOhxvyUgRaJXZb7WhqBJKJ58p06KWNdqPQt0D8VIMo3Tvf1qRnaVchyEEvkTDEm5NKLdYFaJj2FERrSvnYTdblDS6i0UUnet9F1T7kuTr22AJxPhor5QPDhOfqKEnTygqCeERCvS1RxUAnH6px1frq+qIjE25e492HFxBRqJ/HuB83eaHyRhz5pX8i0jQGjqANRpnOeH0DAC4McZG3sfVu18ciVFPmULOoURJDBLG9Zkoha6XMF3vI+uXK63PeP3ygnjhxbaOiWGQEjsAQRcOCwBC+Kh2QEjMDiCJBYXoG3Q7/1Vz9QVq5fE8S3BQF5ixJXF3RzUuQgfCTYbbUBpCjqpDEkSC1IEF3SUa3SEEGEZtjJprOFjLpNX+QzVxKol8Q/bKCvVAlrzzKbSNzSJrWr0UCwkDLmfT323a/39V5Imbb8cBxMJJijyqEIrdRjnmW1iUCyHL4rwcy+1B+PSoNBBGU6JwYaacMO2IfqFc+QNW8qySfLGhR99cYKm2iTWlTCjs7DQBRb1yfnCzQwt2THco6jysJW9uqNKhLmux/WTUyXSciOI3jgBmoleVS/w+XOadWdn2Uf/RZ64Sfa4KJ5yTnYrHhZUnfYTj6FnHToVLb0yWvGnEHEeHSiFYcMKthK8cTERNl+2QXlwbvvL098+weQOBkBI3A6IODA4XS4Sh6jETACHQLLV60o7/6tny27Xn9NJxPBJpmrqw0oadUBOYgdb1FS2ABCVFcbkqLRhokaSdopy3a2xu1HodZ0ZcE2yiQPP+wLVdIx+lAriBaEQawGtBUc9My71uyfPpn6KwuSzD/2Vw/aiObrLSbJMQYRrOONvQW1nHY8j1xNoEznuFAukshzCQ5J5eEE37QnWRVqg37oof9UJZ2XeowNuFjeCKxgH36q/9CDTLRYx347O1TPsssjBxq2MRpd+9AMOQ5IbE+sMfzwE6ss2UaNCCikH0cVQ7cW6SpeHrcmNk8vK8fnTsRmfW7eT50+dv1yGHcHanNUadU1QDIok1aVIVNJ+LCW2graevVwKQMFbmpLf7x+CieoyDb96DalWtNFritMkMGGe5Eevft75blnnm2DdskIGIEli4ADhyV7aTwwI2AEFkLghve8ofzYr32gLMdtDiRv/MnAIV7uBhkDBT4/n3USOK0+cAWiknm0K2AQdQxCBgaUvlhvCXZkR7CgXBY4QjaohzYIk1DSIsxY6KxS1oIKDK+XmpzGOq+06an1iv3+euKBIgOCysxDngECSSK7T2Ku81M9yzSgTn5ow8R81IcKtGNK+0YumzzaocBz0TfTags5LBNnklD2SZKe1Jp+g5zSnga1T2lO4H3QAABAAElEQVQ2mahxSiEnJlU/QwhK6DtpdHQmrdofri8uGNs5jrg+KOjxrVTESCNgQBGONHI6lE3fH+1zNCTpy7j3YWplWYZdAgx6dfsSfeoc6mjjHGOcVU4/TMQoyyGYV2utaR/9Q6wW1nTmXR0Fjpz1zEMb401dBQaQQklSrTaEVejxmuaVy1WI1ufylcvLgb1PlYdu/46G7aMRMAJLGgEHDkv68nhwRsAI9BHYtHMLXvb202Xntbs6sQIAfHMZtya1FYc53jcOMjMDgkjKH0R4YLWBctExBgNJzPQGaZE1sMuqk7m6JeeUbdpDjmJy0egLIhL05pm2VR8ZyRg/QT5rS9qjGhJpq9Y/dqS3Lxwq94MDNvV9sZyfbBtup3yhlHYc+6iU59jyoJNhJvJPDAY9CTONj4Q6k8YnNJOs5lioneMfC8IOXEHWY0Wi+mc7b53RFRnqNQhu9qTrQjPpQp5l5tBVX6jg6kWCQPsfqFDHgiLXSlSDDdWRmKtIPxxjbUAbCfZK7HtYO7asTJ0cx4vjsHmawe9iCaYci8bTys1jK6WL/pnTLupQo2bz1bR4CTJoaHkYhm32EHnFkda8dgwCs8xN05ThX8jSFx/POrVuVfnKf/xMDtG5ETACSxgBBw5L+OJ4aEbACDQExvEYxxvf/+byjv/swxCCdFVSTuKtraVaaeivNkTIAOKVL34LYgQ72iQdC5IfzEtykSetMoQkGB+k+oe+pSeahWNl+5lzxCSE4K1dH5SFlM4jqZBjoG+mgSBCojgmme6JFiz2g4U4L2jRddftAlZjJKZkc9QLkoqxo57l5iE91Zw20OeYad9vlbcFOutEpJO8ikqNTLO3lHI89NoNL9ok0ZFtCg6gC7P0GWQVKoFvfNsfXmKMoQOCTg/8ZG/hMXyI6qstBNCTLLTRIN04opwe6ngTy9CCDppDM+Zr7a/qcFRsowchghxtU+MTZe0kH906hX0Px8vRuW6m0OT5U+2vjYrqrZb9pBP1j3b9C90YbxtRTA+eJ70o75RDn/L0G8EB6kxayWILrGKjdNUMc1nw93rNuevLPZ/9WnkWL4bDRZexj0bACCxJBBw4LMnL4kEZASMwjMCOKy8q7/8XHy3rt81/2Zs2PvP2JK0txIveQBgZUJDqxCoCSC7pnyiYqGC0BlGRnHWS79mgSNIk/Qy9GFAGDYP8piO4YauRi/6kj0H95g/eYUPdYbqUPultuE096Dist7Av9RikruIgr0mIh62er8fsPW1ZT3vlQhflXkBByjiYKKF+Uk619jh1tFXpQA/pV5RUXjKA0HsYROezPd/NoB5TihxzhJoahXpimZefUpFkngYt+9ahFbJYaQhdGlYkqjqvbZ5PBFhSqftiUIl+qEw7jTkqOLDPFbh9ad34ilg9OTHHR7e2+dTpxbiy1nIGUv3zUov6YpkoZJIe6voXrTrD1CJWWQ610KE+cRdOPAOOGwc08M3RrLBO2wlqIo9VCAojyefU5GQ5cfxEeejuB8rxQ0dqmzMjYASWIgIOHJbiVfGYjIARGECAG6Jf96G3ldd84C1lHE9jYSJNIRlTOKDVBhK1WT4bH+Q4ViGQnwgdaWmTdI/8o030Sv74bWcj9eiBxA8qjfSJHImsi1pRnzSIsrzNCVVKhr48bfrRLTSa3zAIHyotfnyhqw+DKwbpT+PP2sufC9/2/b7qxEZkfHgESSjrSkKrhmIEByCd9EL7yAN9etRnOIBgPW9fInGNa1V15Z7kNn2hIVPI6LVe327lIq+3+kt/UOdZ4UfknvtiQoY8UOdEQqIOJxVrKdG+CY2GLSqFepnE6sP68emyAi+Oo94RzO/Fks6u1xpjUj/NZ7/UyhxL2EMkqTCpUjmNNmpRA8dQVL1Koo23hBFT3aqEm7FQpjftdZDH7jam8DxWVp+7rnzv7u+Up77r9zoIbB+NwNJEwIHD0rwuHpURMAI9BLZecl55z+/+fNmwY3MnzYAhggWQEr6zgcGCPggAEDTw6TSxYtAFBKJrkoKisRAaLKsiWoabm1DtBwPqT7IsUymsqm2thc/0FxVp1U3WChhq1wvoyqJ/7AcLfbu+DssLBwvDWq1OLpv+SLCz3DReWCkJsojkfBv65Sd4Ztec0oWCiCStgwFEji/6qz7pVL7lPb1GwABFXc+63wGNQetJbMOe/ZDQclAsiRJHretM1ytUcEgxS+kjCjAKb6ET2nSDpFmhKQLrXtAQWqmKPIu0YjlHQ8LNdz6sRQDBh7ceRTj8fHsf0o5+0inH3fz3S60sHdT1LyzoKzUywKLbTpeVUJBepw/s4wd57knJN0jnqkOnC81V69aUPXv2lIe+ck+Zm1k8OGJ3TkbACJw6BBw4nDrs3bMRMAIvEIFbP/6T5Zpbby4TU5NhQSqmm5JYYpCAcAHMLF/0RmLPAELf/bIMrWButCPlSQIoOX0w0YJlqqZ+pw1hljOnIjkT+6EsukBea1HKKj2nXmvIfvoSlYf3K8zXAF8buu1oIR3K2rgGNXQekvXLg1o/fI0Ev58CIwiGxJC0loVsaBGBQLWltvQUYMTY4TTk1bs8MiihPNcB2q01VNM45IPl1JUfCKpGBFXhp0pA/mVL3+op6lUnpNDh9aY8NFjAh/M0EutswS098lDFIY9D2JJcZ+Lqw5rJZWUV9j4cR1h8FLcvPV/q29IN+2neaJn9NGnoAIhsYZ16WSdGqvVlLBOJ2kJ76PF2JeY8TFCGHwYN2hDOtmiEVOno4SPl8XsfLM8+8VSVODMCRmCpIaD/hZfaqDweI2AEjEBF4KLXXF6uvvWmsgyPbSSZ548IPkkYVxj42FU+Dz5JP9ohV4CA9krURPDkNDRhIyIvasRy1NkH789GTTLQoapLa8pI6pl0HCxJWn12CiKRYUS7ap/1zNMv6+xnoaRVBbV07hdQXKSLIU32QlrM1OuRjpPNoZ3Y6gYx4ox3D1A97NImfURDd1hsDHQfEHeaOQpcmTgp3NyE/ptX4qcBUcbrQcW4xQffxjMNEnLaSp9YU4P+crTXTZ/fnd5dxx4N3fAP3bGxudpvWMVc0ONW6Qcdoz+NhXVS4dr3GHbGnOSd/BgrCTFUJ+BrBpJxHvGUpJP4kECzLeYj3iDNGcy2iTgfWssn9VQW0aaU50KyvW5yRVmOFYg944fKUzOHy3NzWlsjDv2Ucz48ErMeBkJNQuqpV1kTS60SUJ64cRzVSai1MkvDib9jszSmb/hj8E5siR37o436pQ4Vx8p5F+8sWy67oDxyx/0UOhkBI7AEEXDgsAQviodkBIyAEJhcNlXe8LPvLudddXEHSZB+UA7mQU5IuEi/KjnRSoOoTOqIqEs/HZGAk65Qk4QyQg366gUNqAbNSRv6S3Kf5J8y6imxoIre/dA1pEKQv67SK9BvEtueOIr9YKHf1vodpPF9HZXTM0gvzpuJt+fk+ymkM3Tshi6c0gMxUzklOGMQwiDzPb+6/Yf0lHqiqSiof5J9+E9pn9RLJn8aAigsO01cWYwEIgsFoQbaK6UIIG5csbNcvWpnuRwBAtOrVpwX+fMd7j+qe+sfQH7fkceLAgqOBiQ6BoJVi5gwItMUzeG8OUNIsgNL1NlKLGI4uEC5AZstk8BiBkHCZNWDKL6B5wxmOBb0Gu3jcMAgg9/OMxQR0pXMh++xMo09Dzun1mH/w/Kyd/ZQ2XPiufACR4sndhNYDl8VnmWMfFFbjp/nyXmvzeYBRlxDzkPKOFJqUYePrWWgwbYIPFFnH7xeDM0UhLC7OiCUzt25vWx/1YUUOhkBI7BEEXDgsEQvjIdlBIxAKde883Xluve8HlCIsCQmQT9AgIPEICcx4RuiT4K9hawSFJaZqJ+J1CblLCf91QZa6lECEoVi2oUEvkh9mGQv29pF2NBCZDy0eIhE/TaClOKsmnE3jmxdLFho7VlSnufRpE3SxjQs46hEAJvdcL21DOo2PWKXKftSrv4YWOSKhQIKaedoRMyrrLkCuWTidWYOqlnbJK/XDsJf3PSGGNrlK84vlyNo+GHSZdM7woz5e9fLw3cRRPz5/tvK3ciTBDMg4HXjbGBiYMDQKr6hxzj1/gjOV84WEn/OCiq21QcGDxP48Hx4Ow8DBdpRxnPjZ5Lu0caMQRF/iBffh5DzV6sP03j3w7JyzsTK8vDxA+Uw3j49nHL2hbcYDJ2mFgVdJYVEXefUSfSbwbHxehAHJo4pZFFTPc4cOjwn9sl2BvbCAq08X9R1boP9b7/o/LLt0p1l93cfrh6dGQEjsJQQcOCwlK6Gx2IEjECHwIbt55ZX470Na/GM9yRKJECkabztIUg/yAfzfFpSrjaQikQ7c7Kc1K/yYD4oM5EEzkQJFtUfeE21p610knylL+qoVUfqiSz36tU2CTJ1mBYLGEYFC7SN02FhKOVKAskox7Z4Gm5UnX5FBnGmVUUkmVgMtqVe62PYZ7aIXQrPlJFowmMlnrXWNWYQwfNI3Eg8WdN5wRptv7TpjeUKBgorL+hsX+rCpQgifmerAgoGEX/BIOLY4zEuBhK5EkEizBPK4ELfvmt+8Da6OFfkvOmL38Rzbup8MH9Rp+UEJg/9TOAzh5Nn4MHblehrAmUGCVx94BvRZcEjQcR7H3DL06ZJvHUa+aPH95enZ4+jB/YxmFIWdmimbyaOm37YLp8hjt8dBkTo+kWl6CdcsoQfTKgIFlDmesNsnE9dwQgZy0xjZesl55dNF2534PCiELeyEXjlEHDg8Mph7Z6MgBF4gQiM4Wvpi2+6slz1tlfDgqyFN3GQRjYiwoCA+xsoGV5tICkLshIMWAQqrOvtSdpSShIjckf9IHPQZ28si9yhd8iyjKbwKwIbNR4iZYCSdfYvXylRLn+DMta00Xm+nJI4jQWaMljoN2lsOue+PMuL+QpsQeiUZE/d9KRbuFLe18uyLEkAiavIZlqrTddS7Z1jaLdViLwtB/owFZmEfu3il899czj64MY3psNXLGcQ8c8RRGQAcW8EEBgkx8mMKwo4aRLtcQDXggcGtpLn3ocx7Ifg7ODqAfc38JoxMEAWq2YTvJUL5xx7IuDrJOqx0oD22COBnBjzBXwk+rSlwdqJ6XLJ8o1lFfY9PInPEex9eOGJvc8PHmjP3zH2EH2yvzqJeD4MOijnygl/D3NlKeyoB1muMDCPc2TjImnb5ReVc/ClgZMRMAJLEwEHDkvzunhURuCsRmANnunO9zasWLtqAAfSjggVQEhmQZpI6J9vtYEkhbSHeiTyUYtcdUrohTokb6kfimGTMuqpVZnIEvXaKoPaRa6anXyRPw22U95fYajeQ51jST9pnzkDKLbPTwsKQ3fQ18J68vdC2/p6/XIbtwKNNsrgtolhJ1ZEIAwpnB9E/PK5bwrtn9ykvDM9RYUMID594OvlT7ECkcSZp0baHcEBaTbqDB4mQ8p5Gxw69KmZwRDnVewNiOCCSsKEcz1mLjdck3DzNqaYpBMg5+yMKxe6tYlVJgYQy8enyo6pNWXN2LKye/ZgeXrmqBp7R3pmwBF26q7XOrpYhwhFdpwOOEaeF2eb9jAorKEG+otzYM/ESHmUYyTNz/jEeNmCxy9zpfHZJ/ePHow1jIAReEURcODwisLtzoyAEXghCPDRqxfeeHkZw8veYuUgCEolGwwaRD/iyG85Z+dAvyAXuVdZgUILLkRySE3hpxItBQ1oQT0DC9Kevg7tWA/O1vWhs9AqA8tySB+kUYNEXb5rlzKkBQKfhVKMZV6DdJN8tubmlXYttUortdaFShy7NrRqvNRhPQOe4fIEHHNUJJGBTfLHzvlgzxpfUxL57OuojUHEr2x+S3h5+YIF9tXvuxv0iEKze8+615ZLl+8onzpwW7kHtzExBQ6cLzi5vG3pOIQMHrh6whkcNxqha65SEAMS7Ro6lEleg9j7wHmkVQauxvBWJY5WPnRdSM0j4AjiTW0ohs8x7I+YKBumVpTVeHTr98sz5anZIxFgc4yZOJYMHnJ1RJgsvOqQdi3niIgHU78sSUh50XH+7Inzi7+rxIXjZlChOQFN4oCMbaxsv+LisnL9OgcOBNHJCCwxBBw4LLEL4uEYgbMdgenVK8vNP/P2snbzhiAbxCOIPEgFA4Z4etLQagOpiXRAYcBGSEI6WWUnIeOtHeAmahPSQZg7nQwSqMHEI2iPKrWO8XR16ijRz3DqSHev4fkChp4aihwxEtzWEvmVBJGjaaDLgUrVGMw4nvQ12KIa2/tecvxsHS6nH44hbKph3HIDoW6fGe6lee+vSJBA37TywnLN6p3lJze9edjoZai3cbw454P47JreVv7z5e8rf/XsbeU/7f9GYMtbdoiygofgzVGuKIEcs8S5HKFF3KrEGqOIfHRr3qI0N557H5CTXNcAgtSbfnj7EnHm3gf+bjBHRu7NFux5mCy7cOvS6hOHyu6Zg7p1qbYPnzevJ31m4hjpI8Ia9hs+2/xhoBK/a5BH0FINh5GN34v4BYIi0iCCqg0P6YLrXlVmDh2pHp0ZASOwlBBw4LCUrobHYgSMQHnLr/9E2XnNrg6JpBZ5ixK/5Sd9URDBHNQGMhIcUuwIIMhmSVGQieCqTv6ShDe+8wxfbGNKnSRH8qmgQQGL1FI/augjPTbfSdAHNdFDTzd6HFaQSxDE5rP2UltqrbPrCgu2B9kLLBby0n8ng8oDTl5gpX9PO00ygMpcbkhwhx1q7L+y+a3lp+rehWGNpVLvo6zz6klwXu9e95pYffjXe/4CQ0Ybgef8w1GBVAYSlYiDdMdcJSHnjCQ4UM7N09EGjXFEqON46dsMZzXKkwgkOO/5L2Y6VhZi43TthzKGDAxeMvGt09umVpdVeO/DEwgenp45Frf5ZfsLyfk71Q8O2Es/yKAP6aDAsS14uxLk8fsGFfxS8bx1KxNLDFFgGLiUsmrtGnxxsLHs272Xrp2MgBFYQgg4cFhCF8NDMQJnOwI7rr643Pj+N5Xp1drbIHohAk/CxtUG0g2SFJLrICAgVAoj6jegADHsgjCTjMgeBtBj4lOUVOIx1GpObSV4QEPSL2mjhaQoVVhNY5RT3v9mPlWHA4aUD+byELcjDTS0USnwafW+Wn8sKVfQkzUGB7TVWXGcLOklXZBWtwo2ms2oUtpLT76HgwkC14Oq/OqWt5YrscJwxaoLRrk/Ze0N5Rx7k3QTA6PL637x9Nby+5vfX/7N3k+CVFNXQQKLSbK1r4EYyRflnKu5eZqbq4kdfcY+BuQn8HZokn8GF5z3eoxrzcOebbx+PJCAa4M5fbPGRPt12Di9CvsfVowdKo+fOBhvWWffTLJVvzn2aPghDjrzZhjzMgIFzDc0xv4GTAbOvohvUOZYOVSeN/ufOXa87Lr5mvLgnd9ujlwyAkZgSSDgwGFJXAYPwggYgcmpyXL9T7yxXFhXG0g4SJT4w5ykN4IF1OKxq2injK38xpK0I/Rphw+TSJ0ICwk5aVpog7FEsCG1GgCwwnbq02/qQ4qgg4ltmfrBAPvJgEF9Squv0+yy1M8xqupaVK/fT9PLUaWkniaqTZ9tOtdOKwtB3Pq6QdSqaTdu1Ae9deYLFvLxqWqUJX0FKYzrQtlY+RiCBaafOvctkS+1w+A5A+kQVKkuSjfkDisg1ddj8PB7m99b/nDvpwAA5hGIfBLxnM98YpLs6VT+SZwjYESVOW0YkKmVBfaDoAK2xJVltvHInP701CX0h3atDtArSDl04wdjmeJL45atLSvHJ8uDx/aX4yd7M0UOYdMSvWfwwd8pvpAue+bvQt6uFCsmzSzG1KvG+DiaORxiVBgjfw+5uZt90BfHn2kMfwt2Xt1WHVPu3AgYgVOPgAOHU38NPAIjYASAwI5rLyk3/Lhe9kZARImUB+kCcSHBiA/K+QhW0g/SGxEz6gdtjaAirEGI2Na1kHmFDntRGz2oHb1SHzXJ2N7Kqc+cqRHIwfJCAQP1YxgsdInhC4OOFHSFnm6TUYt9Sn9Q3qOAXRCT+iRrWa5FZLLvn0Nre+GlZt+IH60ZUNy8ivsWLiwfqpudX7jXV0ZzEEFd+8Slx2MHrjPbdR1lPeijlEumt0fw8N8jeNBjWfP2JGKSVB8EHBeRAW8QavgMQh2+UWLAgRU1bqTmP87F2AiNzuhhjsEHBhF7GgIq3exTIEdzaPOFc6T5vD70TTnTGHT4zocp5I/PHCr78dSlDFqlwSOVB69na1Op84uqxtfrK+wVGHAFJeZrHOiX+CHv6uxH8uxzavmyMr1mVVm1fk05vP8g2p2MgBFYKgg4cFgqV8LjMAJnMQJT08vKte99fdl8wXaRiooFKEaQklhZ4K1JqOVqA9tY7682FDxdiVqkIY2MyEd1iYw6aIWSAgq1pKzZidsM64hO0acSVxqyXEXzMvY1P2EckDd61pT6ffbtKG/6gysLueJB/cHx5PiSoMlj8DYUGUdlWS0/7BG418F9bMuPlStxG9KVqy56Ec4Gx/ciDF+UakM5r39PUsdPh8MY9q9Jz2Kg75h5aLxoOW9beg9uW/pLBAD4Xh6BgPwhAEA7qjH/oh8GCdGfvsGP+RkBBoMLNEA/9z5w5sb+BQ4A+x0KVgx4ux41+O09XyI3i4Che+s0HPCb/HxsKwMJJva4Hm+aXj42VfaOHS6PnXhWwQNctScsheqih7bnoQfaotq1AeMDHPH7yVEHpsSis+Nc5eiwn2N6qmzYsdmBQ4eNC0ZgaSDgwGFpXAePwgic1QhsuGhruf59byzLV64IHHhLkgIAEA0S8yDnujWJ5eHVBj1pibRNFCRsSYLgLYk9c7ZSxnbdcqEyqUsjhiLa5GPU44cpfWWZeZ+ss77QSgO67SUFC03QGgf1ehoLNGiVYjCIEDFNu+Y3gwISzCxLSzqDsrR/MbnY7a9vfVsYfQibnX+41Mb8w9nTSmMZtm+eeZ3Z2iRhUg0ahvP1ehYD7jlv+JMpSxct31Y+uO7G8okDd6CLpO51vsEmXvJGS5S7dz9UPwwkwk/4hjWDCwoQFNBTeCEJj8BAc3OCunGNQb3x7oeTfCJTRIV6bCuDC1rmUBnMrMAtS+dP4dYl3ML00IkD5Sj2U7QUHXKEGH8NDiAKl5ARq+cLHtTevLGuwJLnjDFXl6mn3uiTaaxsuGAb9mFQ6mQEjMBSQsCBw1K6Gh6LEThLEXjrP/tg2Xze1jj7JPAkLCTt/dUG0ibV1dpfbUh95mJHyklMmGjLcgQNJFnBSdRHBgDSYEAgPQYpTBxT5TlhT1mzYY062ZPqkrUyS1xhaKlVciytjf5Yazqs8dwzDfbW5GxfKBiQrOkN2qfXZhsEEeoie629X/oYggXi8sMHC31vL0W5nV+/NIBlXsjaXcOhzQk2NfvBccX8Ii5VY1ivj9eta28s9x/dXe45tgdEmT1V8o6SAlKtNnB8unVJZFxtWoHIW9liJSD01MoAYhKdsX8FBDqxeDQr3kyt/UC6mSmO6F8hAPuELjqNPRi4ZencqVXx7ofdWHnYP3ccHofPCqIFks5IuOW7K6jGPRiISyIRJ/aslQ/9DvDRskzqZeG+Nu/aWQ7vfUaKPhoBI7BkEHDgsGQuhQdiBM5OBC57+43lijffWJYtWxYAiGiQapCQgHTU1Ye8RYktkkmHb5CWHi1EyKKOGsk9yXreWc4OQsa86ipIYIsITAYNlDDRVyb22CfgSTqHg4aeCUyl1YKGfj/pufVBSb/P9h1w9p0em43GtLCvHKO+p04d4SAUoseuodOv7nku+hZY/bL861vfXj5cNzt3hqe40NDgQDh3lMewKlFlOc8v5KlHAPVPYlZihnRatT2cRmtVDH9JkinrXztS5nevu77cs/czMR4FDwofqKcgQ7fmaLxcXZDnvF7aPszB4XYktHHfBPc+TCAQOAHViZj/oOWxv4E+2SvaueqAUly7OD+EC7FCMfTOB2hRfs7kNN46PVEf2Xp0cOO0hvRDH/k7F2+9rh74ezTZgzgww7lRxOvDMR/B3oZLbrq63P7pf6xWzoyAEVgKCDhwWApXwWMwAmcpAstWTpc3/Pp7y7Yd2wKBJF0iECRICgpIgEg2crWBZZKjkJKABeuqWjRGygCBdIRkRIRRZRHtPrmkXMScOZNWG6qzak+fmRgstFpKSRxbmaUWMLDWGoetZdfaqc3U77OR3hZESGvQrunRvmnk7VmUJB5qnX/s+2D5N7C6cBU2O1+5+qL5yqdI0j/rnAPdUCoBZ71/LrwGOc/YFj76jijE3IJWNEaeetGmA4MF+mU3g/4Ge+MtSx9Yd0P5s/13UBPkn/NW5Fibp1GJengKXyTyWk3LgTG4wIyJFYbc+yDCL094hCnmY36rH5uw4W4iAoa5eLEcB6onLGHM4Z++tcGa46dsJR7Xev7Uety69Fx5FLcuHR+azJyz6ZujzQTTEUnnrMf0aiVFezPCY7XFGAJNVk+WE8dPlDXnnjPCr5uNgBF4pRFw4PBKI+7+jIAR6BC46v2vK1e9+lrUQdQqSSGV4E/cagFuMxs/CBHQTh3KSdlCi/VWq34pY+sgoSMZyT5Ypk7LMQJUJQvDnq7kScBrJ/OyOvyenGPuVaP/rA80RHDQl+QtSRpT2jDva6VcGGSNNo3HDbalzvy8+eWY9S11KR/DygLTT2Oz86lISWj7fbeR8nqypUl6Jx7zIu103ZteK6WGcupp5tR6r1mrA02Qt7FRshjKGt5YefuaG2OsnzzwzRjtGG8lAs3n3CWZZp7nwduI8rxIyBlAcNWBOrwu8gk5Ghl4MJyeRZlrC7HSQJ1YfaAFtKOM90GgjNfFxaqF9j5wnozBmpboiKrwM4WXym3FC+NWYN/DA8efWXDloc0vdMFewpYja0FROIxRY+UjDHigToRAEYCw2+EUcw8N6/Hm+H0PPzHc7LoRMAKnGAEHDqf4Arh7I3C2IrBu+6ZyPV72tnrd2g4C0TauI4DCg2MwaGCKzc8gHST2/PBWDX7jT3mSQpE+aktGeyZ5A6UJf8xFwtQuJdp2QQNs5DPMQ66goTqMdnptie2tFX1GcJPt/ZZ+mf1Qh2etpPvZ+c2rUp9QUqJx1EZY5Rj68v55pGbmJLt8zj/TYFAjGY8f33Zqg4WnnnqqPPPMM2VqaqqsXr267N27txw/caJs3rwZo8O1n50r27dvKycgo47AIoIirTyHwLRiq1oI5x0Ceei1K8ByS/1goT8nqNHQb/ohj1WBvkxX6da115c/P/CN2gFXDShXSKD1hLThN/JK2ivAnqjBucw2jhYXEf3k41ohiFuX4rcFc+8kblPirUvU4xzjOXF3BT3Ff/qMSNBAHe5/0EigBEUGD8RyLW5dumxsQ9y6tH/2ePyuoeEFJ/aphPHGGMJ53EqVLTl/WZ/D+UTXtfH4c8fwIkg9LCH1nRsBI3DqEXDgcOqvgUdgBM46BM6/+pLy5t/8yXL9228O8pIAkBjxhwS3BQ9VShlIEWsRDJAgwTBt5INtmVQO8hUWIErhl5yJloO6aRUrG7VC331STvFC+xnoraU2gmBiaIjumkKU+kS0v8LAxuZhuP/WE3VybEIi3A4c+t+KZ8NCAcPHt72N3k7ZysI999xT7r333vLww4+UY8ePIbgZL88++2x59NFHy6ZNm8qqVauivmr1yrJly9YyOTkZwcP2HTvK+vXry5ZtW7FHZgqBBPfJCKOGVJ65cs4v/VtYb7FgoT9b+h7DyyLBAvX643j/ulcXrjpwHlLO4EErPCTxiuh07XU7D61z7nCFIRODCHlgcM0rFwIEDwyeWJvFrUvc/4A6lDkPEGLFhOEtTRFEYGWBT2KiBV/sJqn8cCz8WYu3TfN9DyvGjpTdeOcDA/VwT1/zksbHsSmx3quhGljwBJu46iogonM1nyzHjx0r5+7cUdudGQEjsFQQcOCwVK6Ex2EEznAEXvWmG8o177ilXPPOm8uWS3eW52YPluUTdUM0CIl+9NQkEmHeQhG3KaGNxJp1BQkgIBFAiBCJXJHWkZaQaOlDOGmB71yjjYSEGiJtkpEHUSdTBA0UIg2ScckyaEiLqlrNJW3EPG3YrHJVjDFmWasMqslD083AIO2zX2pnEJR+Ml8oWFBb88t6W1l4W5q+BDnJ4mA/CzmdmZkpX/nKV/D5arntG98oR48cKdPT00GeuZIwMQFSWz+5AjGOx4sePny4PLl3X6w03HXnXWXlypVl47kILJBfd9215bwLdpYLL7pwXpecW/qnsQ2P8EcPFvpXZhCBvu+3r70uVh10SxHnKYeKb/wRQPC7fyYiSG+cf+TXcRsRytRl7EDb1oa+wgl9QBnlWJGIQECzf4J2kJ7A7VEMJOLN1ZDFfglMML5Mjnsj1PtCj2ydKjumsC6BwTx+7FAEOjwn/V618aF3pBxbDEYiHHUOtTovaKA8HFYFZavPWVsOHzo0IHPFCBiBU4+AA4dTfw08AiNwRiIwibe/XvvOW8q1CBauRrCwZhM3OpJQ4Ikpc0fxTeYkaryVItgTyBDpEAkSjyiT3OAn39lAeWiwPXToiXqUMylHtdZD2JVJtKESdfmRjbRUpi+l/jf9ko0KGoYDhvAYpumTZK2V47YSDIjBQaOd/X41Jh7ZTj2StUzNBu09v9muvOnT/je2521IL2Ww0O+x9deXskzSf9ddd5Yvf/mr5fOf/3w5ePBgBAq83YgrCMfwDTNz1jNoYM6AIfP4JpzsGYm6x48fL4898mjg+u17v10uuPCCcsmleAP5q28sGzduLCtWrQhb6vdH1ifz0dbDL2cT5f0U9jBsftoVaDJZ9P33rzlb34+N0p88cDvGzFtzaMk5zNuFZuOb/1xroC574FxVAMH5I0IuCBpJjzHDR8wpqdRbl2CJIDt8IbLg3gfO4wgS2DduaVIvChv468k1CP709z2MY3Vi++RavGBuvOyZPVyO4cVz+bsczmnYJZV15G+1QqKYv321Th8FyDlKjkJxxVhsjj68z49j7cPkshFYCgg4cFgKV8FjMAJnCALrtm6KYOGad9wc+RiIX59gkESR5MydPFZW4DaITJTyhysLJEra01D3MIQ8wwrm/AHRAAEi36Mdj5SJpLFOIoI7wGs7fUpL/kMhbKRLR6JXbIFuFbMckiRfUWM/tRAZxtPVUz/bu4YBG60yqE39Nj1Z9tuAYFT7Y6QWhPjXxj2/T9r9Ru5ZqC9oS61XIuf12L9/f+GtSAwY7r77rrJnz94IEhgMkPxnkMByfobbxhg84NMPHHL87GOObwzH51EEEXvh/8477iyXX3F5ueq6a8quy3bFo36fj8wPI9t89wMFShvacUlSEfli/of1ZMIeQc7RyKcLMWxQ8NBWDPocO3vlagITA4i5mBTUooxEn1rc91B/44AL35fAOuf/JF/ZzBRRB38fVOd+iFilCHs2c/VB3kKjngDlm/G+Bz6ylcHDs7MnoNUfZb8cHeGgPtg/b4eKkWq4VGip9kF3PAuO59hzR8rGC32rUgPJJSOwNBBw4LA0roNHYQROWwR2XH4xbj/SLUiX3swnJDE1EiEyLynpylGsNqwYb7cosYWhANuoS0qFLHKuNsyCEAY5zPbQIdPQh5Yq44g2kaz0ISJCf+RZ9B5HZr1Em/441SSlXGlIdfpqieFJnm3qZ6vqQeeqEXXZP8eicarOY/BAFtCebbFKAknWozlUmo5kbVBvWHVJuXbNheWq1fxc3JmcigJvM/rEn/1Z+ew/fLY88MADsXrAFYX+qsJwsDBc54rDOG9bYl6DhzyXmC/AlvnsLG5mw1yZOTFT9j+9v3z5i18uXIW49obryns+8L5u5YK2w+h1/qLxpQ0W+gEFe34bNkk/gJfC3Xfsibiu/Haf11fBA641fnX0tCQIQbbzN0nzXCMlHeeUQvPA3JCccwHe2IiAN8g9boWagXQysAItR5uCFm6qpjN6Z2DGvtUnAwX6oc8cBfeerJ9cgeBhsjxWni0HsGmarTwvJZaVUkL7DDBaK4ThvyrXTD2qMo3VooPY5+JkBIzA0kLAgcPSuh4ejRE4LRC47PXXYb/CzbgF6Zay/VUX1TH3aQHJnMQi6yrP4BYHEhUSkExspypXGUhfhlcb2Ep6Hjl04hvUIECyox/21WqsJ22RT5Ik+m4EXHLaDt7mAy9hKvt+0EDbzi3K3HNBsq+zTn16VDlKMEhU+hugNY6mp6BB9Rzj8B4GrWo0G/rPvj6ej009BasKGsfgcR8Chi996UvlT/74j8t9932ncE9DP1iIYABBwEKrDRk4MM925mnTX3XIwIEBA9uZs51BBPvc9+S+8oXP/WN5+AePlJvfdEu59LJLy/pz1g0MNhAFWW7I5hWQWpMD7byY1UObZ3klqs2A3vCcKuXS5VvLvcd2d4Ra1mmkFbUg7Zg/JPmtJYceNL/Oc7RjAnEFg35I0mN2xzlBhn+c/yWCBwYCOD+0aU8E/aEx9jngka0ocrWBNq1X/q5i9aKuWBBfvu/hArzv4dGxZ8uzM8dq3/TVkhAllvpdjznOIdI5EsfU/R3gGPHhMJXGysyRY2X/D3anwLkRMAJLBAEHDkvkQngYRmApIzABEnfNu7hf4eZYXVi7eSOGKwLQxq3/9uNIwlMb+t+UktBwcyZTki62tx/d9iPiw3ABrfAVOtWniL78i2KxXf5E+ZJ4SS5SHj2C6MsXa0wZNGgsWgloI5dO6OEA015S0CBBPW+deKfT149ViWr//7P3JtCaFcedZ1a9V6/2faOAArEVFDtiByEKhAAhDAgt1mbGsmS3Z9rT7j5nus+ZsWemT/csPTP2TPuc7j49Y0uW3bZka7e1L2hDAoEkVol934qlqqgqal8nfhH5v5n3vu9VQVFUPYmb792bmZERkZGReb+MuJn33pAx0GrZBB+8ytCqPF1gKwmnsapgH2Q72KsKarAkfOmlNenL//jl9IUvfD49/PAjzXMLMvyJa4dAaTkKteMgmHCglePQjB9zFuQ44DCoHLnA2bpla3rw/vttC9Nz6RRbfXjbFZelufPteZt9cBZUZ7fNXld1OWg8NXhSTgaw6vCP62/3cYsBzc336H9WAmwcArAAzFcfKudBcK4JnhKyhlg7284DOGHu45AbH0NzQx1ccyC4dsnvMDiuLWOVcR9XJtS2OmE5rj+qwIlorguXd0IasVWHpZNmp+d3b0hrd23170QEpc7Ilq916vE2AYtgIudAYSSlB7YqbVizPs2YNVNIfdxroNfAONFA7ziMk47oxeg1MN40MHvhPH+omYeb2Yo0ZK+7dCuiETTP9pYnVRtVGDUEGRvEwNiBLceBcncMwDLLhfJYdTCHwfI7sSfsNnusNoSRH3ftAz9qDcNIaUwtPUDq9WOEmSi4EmEuAXUsI5H8Ln3GU7m1tPNcQ5Tks0hNZkKwaoCtfDgNtEMhZIpc0LhsmbzgRZtFFa9M5WNslwp00OOqxd7mF154Pn3yk3+VvvTFL6VVq+LtR3IY6lWDPTkPXcehdh5qx4HG+7ipHAeVq4xyDt7UxLMP3/zK19PL9qae33jXtbbyYA/7+jM4ZfRIocWojToauBI5LnjUA7DSSElWVIbnud3p6llnpK+sv8PGRRjx8aA0Y9PyhhUbmMib8W3M3QTPDoVsbl1nlNXOg+PmeoiQzVcYuP6Mk3//wc4IM8EaEa9stY+/Wa1cCI5vdMPUB05TL7LBMGB8LG4xzz3sHEov2HMPvAK21A1iO6hMW5dUmtlbVi0zWSYNp8d+fp9Q+rjXQK+BcaKB3nEYJx3Ri9FrYDxoYMmyN4WzYI7CsgtOzyJpMidrlkEObpQpY7GMmGIahTOAERIwe5c8don9BW3wogwHgrv/bMdxV8HS4VRg8GPIkLc6LNYWHuBNndC6DEGPWMUYj3pER1nBspQV13f+Ka2dhnA8gBKQM1LwKKGkkVUBR6fLW2Wi9/odGG2I8t3pvOmsKhyVVxWOKmQHMVVahhD0S8Tc8X/gwQfTn/9/f54++5nP+SoD31WQIV/HpLuHVhQUj+U8iE6GrI+L/GyD6vCxZYIpRrb6+Jk9pL3d3sb0lkvemk448YRGm8UJYEyUlpZUoBa80n7XQhexcM4jJRDkGF5ir2bFcUCPwDCm40oTI113UepnHyyCxxiPasKxkNg4CUElQ9544iC4IwCuvjbN9WUPQ1sxLsF2thJazHZCXj4wgbcumbU/kW1KtlJBmfjSKPphkq08LJhozoO9Je3JHet9hSO/o8lEa7BDzOqME4GzFK2xs3sPyBaQdc+vTkOTexOlUlmf7DUwLjTQX5Xjoht6IXoNHDwNHH3GibaicEE67aoL02EnHZ0Fick7MmHI+BmDLGPIaCcLVCVh6AdMaQzoETMShqtnG7zM4Hq2AROGP/Jsp4jVBoNg8PjDm9QsZyHLFEK5RDgGIUMYYhh/bLCgHsyXaFHOqxHADY9yePu5VeagfGLto/Dp4nbzsdJQG3fUlVllmciFjAH/fXtGAZT3Lb4kAOPg3IjsspiGTV9NyMNk85bN6XOf/Vy68Ts3uv030TasY1RyyKCvYzkAxN2VCJUB7zoQKiOWYwAezzPUzgTyUc7WpZqG9JbNW9LPb/1pWvvSWn/eYbF9hVr4noBWCdL1pWAl0fzAqFVRkTiHjOHgGF9tDHJX2arD19x5wFA3A93rYryTDg7hToQB7merNLb9aCxqjMnoRkZ0D73x8tbEKgbJ2H5kFVl6yK6zWNEICXEsoKJdvlXJvv2Asx6GgtHYP998YMXCn4UA2QI2/6zhyenwCbPSqu2b0hZ/XSsluAec80oFacaF/UWI8pzxCElw3FevtC+Gb91eF/XpXgO9BsaBBnrHYRx0Qi9Cr4EDqQEMrGPefFI6/i2np5MuPTctOf7INHnW9DRsb7vJdkAjjpkgbkUIHkZIFFPm5ZYF7oZcTmP4OMzOWF4YG5PMRsBgCDxRE+Mc2NloMGp2mtHAHVNKdrrVxmfgCINWG6JejA3JCCbOAACHezLqQybqihC0YcIEzI0W5MkYlCmNfDJ3KG7Y5JojH3zCaWg7JGEHVvVY8twZR6XTePuRPatwoqVfn4DUUe8r5V+w0RFUBVIrAd28+OKL6S8//vH0d5/+dFqz5iV/9WntMNRpDPduvmvYa9WhjuVACAYPOQ44BwrAtLoAX/Br50F14zzc+bPb08zZs9K177k2LbIvT1ctbDkL8KzbH/pQjXUcY0wQjRvlFYMV/8RdLOqKUcY4jVeYAgMauH62FQBM7tqBiNKgZ6sTzoNe2UoeDl63pXx8WkznYvRHDeZC+HcdQAXC+DUdRqHlJroDgQsATbgcuAT0hZEYcA5fmrb86l2b08adO1zG4iRYCkKCRcDJBQcHeQHt2mUXG+3Z0H/HwbTQh14D40sDveMwvvqjl6bXwOuigWHbL7zwqMPNYVieTrrgzWnx8qPS7MMWpGnzZqeJw7GxINsHblyEsRSiyFmQ0UHMpC6DCjpWFNxoA06pGS3E0PIQ5rDdSh22/dAK4qnVBhwGxzYLBF+BFQZw+AMHrlgnesYBPrWMsdoQ3F02SyKB0zVxlOucbSOrJ4IbP03O6I1cZSUFzyhDNoValkHbk+Q0sP3oFHuoGdL3Ll4h8tc5LnLuqaKCZS3zTIG4hZeJi052p5fsrv3nPvOZ9Kf/1//t/cGbkwgYiDoyWZMXvBvLgQCuNLGecaidB+A+3mwbEmkFwXAeaocBHPGt45//5LY0Y+aMdPk7r0hzFy3IbEa3P/ShWkocY6Doqeim4JBCrsANuChW2Halr6+/q+WoMDgoD7M68AedqYsHp61hTXHUH9zdscjFtVwBByde2TrRHfUw4X1gWl7PPUyCHu52anRgacp5ExPXOHKy+kAb0e00+xo8K4vPp43uPAzl6975OCulMmOiqMVTfrK9Uk/ea6/vtd+tnTuKY1gQ+lSvgV4DB0sDveNwsDTf19tr4ABpgDciHXn28nTh+96Rjjv31LTomKXsF+jUHsYGQDe+3HRxMwKI/7khb2jkMETCvIntO24YZcsi8AoNdyAnT+AcxkXQFa7cWYU0VhuCDn7hVMgUAidkhD8HIWSFF6Z9lsrwZPRDIlynyzy8dkuLuzPLp4AVV8E5R3UNmnAA1E6L38n1OhvU9E/ytqP3LFpRgOMg1W5S9EFo0oTrDI/S3oKH7vmw29/9/Wf8C844DRiOOtRE5YkJdX4QrDbySXOwciDHgRgYAecAHj4OshMh/jUfwRRDS3r9uvXph9/7YZo1d0668tqrDBpaaYYJiK3A+CTEueilhWSlVu7/gVco2njkrjTn4Wvr7zR5bKSZQR5blHB7Y3xyR56gmsOhiJpZERj8zYeggDauG1YfnI1zcjhXhjv4GP7w13MP6NZqMdF5QQGrFkOmkCEAuTmshJCeYA4CtFy7tfPAdx4OnzAzPbdrY9qcrzJDc4eDnx7awJpJ1IQL46V+pmVbN21Jm17emHZu4+sTfeg10GtgPGmgdxzGU2/0svQa2I8amD5nZlp24enp3He/PZ1xzYoxOWOQhHEhh6AYKRjblPHnaeMSawGGg3XlZcDaePGcgpWbtTLTVjSG7GuzCsFHjgHmChy5y2ns7ORblbxGB0Sp3QVFBiRTXfDDyCiGOzIADXnAjcNBlsyFlqWuuI8ZsCgKY4wyQkQmWc4LErgN0GUAXysNv+uOwu403hyF0iZShOizSNu5MSxDrw3c8chFm5uWm/H413/11+m+X9xbUDspjPM61Hmlifd2yAmoHYgYsyZrdhiEo5h6u3VIlhq+6rnn07e/+s10wsnL09I3HdE4JcJ1PXkmWh6jpJQq5ePTUGKcSlsqbcfCAcqIhqevHgBwnVFXdohMhXIeKIY2nAdy0VdheEde55Czfu4hWLNGIOmgoyZe2Sowzz2wyWjYrjnekjSU+xBcnI/mzUmWZhvTTivHaeA6djkNhn4n2krDQnvj0ks7N6dNxosKdL8iszQYYDZhhfNClnq2bNiUnn3g8bSr2oZGWR96DfQaOPga6B2Hg98HvQS9Bva7Bg45emk6972XpdOufEtadOxSn4ypJIwJUmZ+2ASPEQKMmD8ChjnGOLFvQXKY5QwGBnFtvAONfNA6nlnf2AojZhSMZKch6KMOaPwPnshhJxwGwUjDLeoPp4JSDgVoCIHJmRCyU0Kx8P0ZCi8PHNF6ztmE8RalDWLlNAQsqox6lf6YbTkC8p6FFxfCcZQKaSU/uQqCDZmDNEg29FPwSiqQt9lbif7qE59M3/rGN9PGjRub5xoyq1Ykp0BAGe3k67TKBRedcOo8zgEOg8pEW+frtMrFu86TfvrxJ9J3v/7t9BvvvS4tWLTQIDE+hVfrRjBisOI/NNTV0yjcDNC4JHuxrTh8df3dDSovBZggC7vC7zoPFJXnHszctgGJ0Y0h7pGdQu6QijI9NI2h7riO6a1w5wFSthbWH4uDZiiIzUFg5QFG9uwI16jB+dK083IHIFYR0An6n2TX/ryJ09KIfWF6wy4edA4nEXxWVnCAYMemJzlDyLx+1br0woNPWqoPvQZ6DYw3DfSOw3jrkV6eXgOvQQMLjliSTr3s/HThh65KR5y2zDkxEcuACBOiGEUYMMDCsCYVZeBjpsfzBaUcg5I/L3fLOae5Tc8/DgPlYVUntiwMepMSfKhbqw3EO+1Op1YbrHpLY1Jwxz9wgbm8mTcydFcbQm4woy2kCLWhhqj1agOlCrkZOSs4vIyjRefYQ8ynTD/S8+9e+FaPx+MpJEYy6w3PFIhballotXAQXkXRaiJvMLrnnnvS337qU+nZZ571L0J7Tblfuuluvu20RS0+rjK90oNiPbsggcgPwuvWKfxuDC2B7zzc+qNb0jEnHJsuetvFDiu68Wxz8vp8fAVoLD1RyrWgUI9BwRS/c9ap9qxDOA/Uy7gO34FVB4zwGMO18yDaiENabV1yGEQWSjvCschN9tUDytyIt9hltYeu+ShcfCzO3HY9l4Se8zMNlkBAp+Ta5O1LjKnYehQc4ammc/3PHprsDsf6XfE+JrkLjgduPSgt9+Rd9/fblFwv/anXwPjTQO84jL8+6SXqNfCqNcAWjhMuPjNd8P54jmH2IXzZuTYawjDAaMCA8T/LMP0rH7GdDc70LwOJdPOwcqY3UJS7AUF54QkfaEbMYJhujgNGgng5nZXjKOxmhQF+HhuNGR9RtxwKeAYO0sNXATyCy+Zn0lptMLpKTvhHCJqgVTpKhJERLYotSh9ddLGld6flU49My7PDUHDGTypaI3mi/cjtwfRah9LWNl6bR6GgF+I/MDZv3ZK+8+3vpLvvsId6cz+ArTv8NYx0Ny/ONbyGiUZOAbEcBlYaCHUZzzlwCE/0g2JoBe+mn3nq6XTbj29Nx59yYl51AIOmt9sfMC8adXLcClqP2QrsSeGiVWSKfomtRTF+zRj3vkOHoV/xkwMhHrpb7+PWTXjvMq9H3V/z91aZA1C/shWeLoXBMe/xVuoVjWHvfuDIy4PVsVWJSiiiZ/wVrXYDACQcCclFPGPiiDkk29NWawy40QZKjFEVttnzDWseW5lefn5NBe2TvQZ6DYwXDfSOw3jpiV6OXgP7qIFFRx6Wzr56Rbr4o9eluUcsdi5M3TIUfL63qd2fOzA4xkGsJGB2YKRjCAANsyTSUQbEDS3HM078m7MAnOleDoMMGsfP/KbbXcZJZuhBT4iy4OfyGRwHQmVm+QWOwdkewbqA+Aun8DLTBDynBt8TmRvpUmfUEOXQxGoDbQZWSs8y5+Dk6Uc44vULLgqCcXzOTc4Shl4bcStbrLSQUukqqNs8GmqwXIUeO1Upe96eCfj6176etm7d6s6Cjw/6Ih/CVF8JXse14V+nhSMYDoG/UtXuVE/cWZwGORByGmrHQQ6EYvEkFl/BkFVp4gd/eX+65+d3pRXveNuY7Vf7FEtHyutaUF5xjed6R1+58CJbcfjay/d4jv6Klpq8GUEPIzuC9S11yHkAJk5hhHMdAYxtQ7yyVcMhxkIwpQ6uM72yFS7hPEQ518mQOd2+RuDPPdjb0XA2KDaPZherBzAGECTuVMSKBJuP4oFplfEg9TR3Hnb6cxJGGfQeOyNAaffWbenub9/cjC0H9qdeA70Gxo0Gesdh3HRFL0ivgVevgdkL5qZLfvu6dOa1l6S5h7E3uzaFmc/tD4MpUm6I8NyA590oyGaO4cTzBCpzyjDcbU6veZCOegKXtEMqQ4jtCbOG8puUct2BFzQ4BKoP5yH+oiyciag/qgq47BPqxwHACHJXwyqnFeFI0N7IUx/1RIg4spE+cxqOwlJbTViaTrD0r0JQa5A1+qGCyDq0sjAQo0VdvIoiEPIZjcd/YHTx3JczXJyGhx98aNRH1zQuiOs07Ml3jXbhqYxyOQpK4yAA89UMEwg4h1Y3lGf7FIccCeA1X+EJVsekdTz/3HPp5h/8KF185aWoYszgusql+QoaiFvjeR0DsVD77nTlzFPSN7LzMBotOLkLgGDW19RbOw+jaTKE9o1yHiiLO/9W7AZ8PWbCqbA6rB6l9dwD1xwPRU+0azzZB+ImmYPiY8NgzgNvwtJDVs61jMwup9czIU2x7U877Ldny64d9iX5ySGklcm7efweG1tbtjVjKBD6c6+BXgPjRQO94zBeeqKXo9fAq9DA5KlT7FmG89KVv/e+tPS8k4oh5TyYhcMYiVUGM9ow3Gw2ZyInxfMDxJ7DcrBDhjx3IP0v07DTJ8yW4AGN87fySHnWeCneleZNsA9BaX+0gaHhj9jrMabNH3xUv6fZIGGSWtotkIZv1EY9YSOTCpgciUAVXsSZ3Ou4YcFb0glTD/+VcRSQvbQCPbUhMraASv/eWx28wgPMEsKYLaUlZVxCyQ0yuI898mj6zje/nV584UWHO733WfShDHbgSiuGQHAZ8v6hr+wMNmWtWQAAQABJREFUCIbxj8OgQ3SibRyJih/v+t9pd8DlPCiueSqtWPzqeOOGjenWm39iH7VblRYs1HcdkMC1Ggk76xpoAFWCcU7wM7qpyupkXYIMbxpZJCrjb8Y2hHYtYniz8sDDxA6i0yPhctTOg3i6g2GlMSZMl1kOOVzIEWV5lcHKuapwFCKEU0G9lOTq7HcGKvgZb6NhFYFHnnlnGv4CMvsLVOFjab2uFSo+Akk7kWGS0Q0b8rYJ5jzsHnFaQ0k7bLVh9RMr07MPPUG2D70Geg2MQw30jsM47JRepF4De9LAkL3e9IwrL0wXf+z6dPiZJ/pEDH4YAszX9mcTNHlMB21R4iWLvCdehrs7EY4HfhhDvg0JGICKD2k3/g1OCUH1RdpMHeNNfVPtuYbp9q79MF5CHnAauYxH46RQl/9l/pbOkkDiNNQrQ412EQIrYpfIDZXSDkfKgt4w/wJzFpam46ce4eDxfpJ+Q85oE5rwQDurUPqgjdfmUQhcV1bocQbXuLWzIF2LesfO7enhhx9OP/z+DwTyGLzugXFew2SsK6ZM6W4sx0FGLrgEYjkTKqtpoatXHuQ8AK/xou6ASY463rRuQ/rJd3+c3vmb13i9OmkMKl/H0qdLij7qwipdl1BnHQ6fguNAAN7paIfHCR5+bWU05KqdB7AanEzHOPGVA4u7nAu9URlPHACwAh688otW3THY7duW2AZlXCWqxSSHobU3Ltnaj1fEygTS8rE4fm/KygP1mAPhVPwa8HthYeeudMfXbzJ0W8WwMdSHXgO9BsafBnrHYfz1SS9Rr4ExNTDNvs1wyUevTxd94Ko0d+niNNHfkygjHnPBjHI3XMwws9gdB4NFGoPdIJTboTRTO0YCh4FzjBlQYPAl1FM5vGvjhzwGzVQzB6ZNjC8Iqxx6+MtpAdf/siyUgys5JKPqY5tStMEMjiw78ikgNwF6hQ+bw3DtvAuUHddxkRox0UXELrRbVJ6y9tWhjdfmUfDQbfwHRhdvLGeB3qgDzzR846tfd+O8htNv3nfV9iDla4O9TmPM8+wC++R32rMLtUOAQSnHQPWIH3h1ueDwhmfXeRCsG9crHeKhePuO7enH3/+hOw71eJIsxK7TDHB9ooMaoSlrQ6lDodY7MDhcYduVvunblcCrOt5y9AbGPwHcrvMAvHYgJBEuAAGznYHlPNCxw7zITiFX8BcFZeGU+FjID0TDg1ey2rqQl/OSAx7i9lUHF9tOu4cb5wFJs1tQ2pAbz3YnHJHdvk4xnFY+8lTasHZd7zSg+j70GhinGugdh3HaMb1YvQa6GphvjsKKG96VLv/D97uhRblMO4wEJne2FmBg4xQAMVOqWXHgVadhuBvc0np1KnyAxwPTmPNGydxvfwTVEWkrpTAH4UTZbnv96sQ0dxL7lovRE5LAM47II2txFHZ4bcFbPKOWQkMd9ZYk5IInTgU0Idbu9CFzGK6Zez7o4zoULUY7aEUTivpa+veWRkMdtaJoSEm4DrNeIt8qbm1Davdn3duFhnpWPr0yPWOvX+UbDnVQv9Yxhjz5wc6C9X029OUwKK6dgm4d0FAu56Fbn3hq1UFx7TTU8gif8i785u/flDZv3pzYEqjgOs0Zr1sFnbjGowhchdpZqPEcw/DcQHfkSPGNBB/g1fXU8DLs2nkAzrVVOw/A4Fq7CTgQvnUpOw9BVzklWV4rbo09M/HjejNu/F7EtiWoDVFNJGky7/ItSPZqVyvlA3KsRtJ3vHWJEYbLETI5tXPcvmNXeu7Rp9Izv3zMSvvQa6DXwHjVQO84jNee6eXqNVBpYMqMaenc69+ezrGPuk30D6rVJkZM6I1TYLO4VhMamBkD7kzgPPheaaN3QyX4uJGXZ3/gCkzyuBKyDCgqpZJBEPtK9NAUcx7iK9FhXGG2gBcxUnjO5anhUQt41O8rDJZWCPksZwW1fDXeB+afd4AdBrOSKhkl657iqkVmYIFZINhfCsV8p2+BFrySEnbE0regNV5tsFIOrgK9MCg4hhEK86X169Iv7vnFKFTvGzPqu8b3oDxGOoa/vykpp+UIyGlQrIrgL7oal3Jvs5XLCSDWFiU5DoprB0Jp0ZGv5WU74G033ZLecvkKFyN0wRgeHOqSWrdg17rv4rX57U4Xzjw5fevlX1aVBIUb2SBXY8R5m0RNGQAr5xoi1A4EXGSoxxU92HkIxyMM+3izmWEbTwx9rlB46m1LVBavbaXUoD6mrG5bRUCE7UbnW5Vs6xIPUcerWuNZB3+GA66g46FYGLFljC0vv5xGpo6krRs3O6w/9RroNTD+NNA7DuOvT3qJeg20NDBl2tS04oNXp4s/8q407/D4qm2YemFU+OqBzcAY1JjlOAg7d7PWYOUYVQ63ad9iN8KAY15Q5inm7yhTxfCPOgIvTBFgSgmz5IfNAJg5YZKZAxgSEcAX75BNMkZ9fGPBVxuybHDDGQAXqUTfcHMrLMONBpPjNHvYebkd18w9L9AO2Lm0fU9VFizaDGaGhL3UkBbzvY1X6BtUT6DX+C8YJWVFFf9Rxmzu3TZHo6kchSgrUj360MNp3UsvdUlCFsZSXkWILUjFkcAoF0xpYgxGHIHaGZAR6WPT+Cmu8UgrUC4cGf7w7joPgg1yImo6pe2zhemun96ZLnz7xeotVdnErv+cQ4Y6tHSfOTgG8taIVU7wYycvSg9vfaGF1YwZH/HtInEc5EC8WucBzupxVhjsarSD6403I0UZcJwHrlO2LO3mt8b6kmt1mJVMyHhdK1QNC6jhZdzNseBBafC9J8Eh2JalUy49K734wOPp5s98J728el3A+3OvgV4D40oDveMwrrqjF6bXQFsDrDRc/tH3prf/8w+kKTOneaEmdgyG8jxDbEPS1iQMb3cYmMjB82naYpvJHSKDy0tj5hZfdw/cgAwI9KVMs3zICS8FPvBUP9sAnWjlzLhhyqqH88yyGAP4w8udG7MviBXcMMwZjJE6vH/euenqA+4w1BKMThfJKTMNOCBDsZ1yaLekjdfmIQrnxgmuDuzitQzWWocdvYmj0+/BWaj5P/jAg37nX7R1LIO7NuIx1mXwD0rLcZCzQMwhHsQc0OJ41PjCo5yg+onB1yFHQY6E4HuLt27bmh42R6luv3Sudqtu8rXePV/3D+0QUZUKPIijUFhHTlqQHQcKqgHjaINgQT/ozDW1N+eBAeoGPPrPTHRdA88qtpUHSkNYh1tup2X9Q3CWZhPSDjsPExucGwiBFzSQUhNGB5z4NoVvm/I8/Z7S7CXz0xX/4oNpxoI56Sv/z6fS1g39yoOppw+9BsaVBnrHYVx1Ry9Mr4GigZFpU9KZ16xI53zg8o7TgIkRToMb2jb9YojzbnQm/B0YKtk417MM4WBYqZWBq7/aeA2jnBIm+DgjjYyISHMmUG5nj3bbV6KH0lzbpsS722VQQed/7ryAy9YG3rdiUCMsX6OOPLheszPNTkVUk+uS4RL47593Xrp6zrledrBPlZi5/RVE1pgJWeu7tDWkryhazXG9WGHoh7gdaqNVugcDDQ4K2oJS+LTxCtx4ZNlffP4F3/O/ft36QSyjP6sVBwxznIbuliQ5EnISiBVqZ4B2+BgxntCIn+hEQ1zjglc7D3IYug6E4MKvHQ/SPAi+23g9+vAj6ahjj26qa+m3iN70jcsTQlX9VDRaUsGy5qfrbOnkhWnXBgzvGC8yvjHrud7ja9JV5cGqkeHVrjxETVkei8Q5RoUcD/rDyrywrBZ4e+zECgRpva6VlQeet9ph+P6cBo0AAyQLOBvD7ljQ6nj2QW7L9Hmz0iW/c23aZn3wrf/4+cSXpGs9BYf+3Gug18DB0kDvOBwszff19hrYiwYOO/Go9NaPXJcWHnWYY8q8Y+7FEcDwxgjniDR5Juwwuu3lq5R4Xsa6G1kG5S/4lXOUhVAyYpjpVS8loyfwuFs51d6iNMMO7ArkixowNozejpDTzm5QwDMsCM5yWKzQciWwzUFyOp9K4v/50PekZVNCL4XiwKaKtNY+e40k0mLkEvimAEYzYbT+akpHGXWKvhiMJ2NeRHWftHtLGCZZJnKOnPx9/FFeasl5Nw5zOvfJlClT0gP3PdCsCERp+4wcGOIy8mXAY+zXDgNpOQCKxcnbbXxqQ160NZ3wiaERfi2DZCGW46B0t6zOK73JHo5eu+Yl56/6at0zNhVcbmU8rspa8JBXIF0HyhMv9e851JBBae/EQQV+zVBQOxB8m6W78tDg+BVo49b06E6K9ZeGQIxd0UadIXNc6Y6PHvIbl/iOg17XysoDKxK8WpXfANyN5gfCKvcHpw2gD8XxDAQ1o8tJM6ekFR+9zt4aN5Ru/rtvpRcfW4m4feg10GtgHGigdxzGQSf0IvQa6Gpg0bLD03v+7X+b3nTaMje6ZHxirLCKwJ87A24msEGJSTpWHRyHu79mLPAHrhU5XeSjtjDYSRuUCd/+CDIWPOOngIMDlgJ4GBG8NeWQ4el2J7S92gAe5f72Jrv9yJ/LjFyWpyxkI456MRqiDugspYbDzMPu9D8tefdBcxpK63f7R8KefeaZtGXzljRj5oy0/uX1ae3atWmqPZMya9bstH37jjRnzqx02NKlacOGDWnBgvnWYmuTtRGDuQ7oJv7rGgpGy2CNjmgKQ3tNtkn4tjDlYCtnAb0KnuOx+Atvh42ndevsNZmdums2lMlZqI190hjjMvwx4hXQA3Tiq7R4wa/mBd0o3WV6OQ+SQbFWF+Q81LGcBMGUh/aZJ59KU6ZNa1ZdqNv7yWNOylFCiHyY1AFxqOHVgXE/VuBaGRza4yVwwB0EVynGeimn3tp5AAuJAycuNN86RLvGcB6in4wisxVP+HgzgZtYQzbWmm1LXPsG5zkJ/84DKIaD8cFvBr9nOA/BixbFtqWZtvJw8W//Rpo5f2765n/6bHrx0WeMog+9BnoNHGwN9I7Dwe6Bvv5eAx0NzD9icXrHP/utdMwZy0c5Ddyxj0naz749ye/m20zMqgNQX32widvTxtu3KWEMUOZ1hcvgRlpTt8rCcAm8SIexEIi1HU8NhHkTpzZvUiJPPXXM3Ub/cxmz82AQdyLcYo1yUYpv1Bu8wq1I6Y8PsNOg2r1BJvO9996X7rrzzvTgQw+ll+0NMJPsQ3dsa3nBvqSMgTtr1iw3gjdu3GiOwoI0xV7nSfnxJxyf5s+fn5aaE7HokMVp+ozpaeasmW5kFX1FLTp3jXlkCbus7gVhOys7mdFVQJbKuEbYhjtqg1n3cY0nGV547oW0cBEP5o8d4CFjvTb2taogx2GQ4S+u0IsP+OTFS3zAFQ/JXdNJBpwA0nIcyMtB6MZyGBRTvvKpZ6xutgeZyYuDQ8U+lkkQak2VHFDJ5Wh20phWXnHtKNBTet3wcbbq8Mg2HpDmerYVG78JIBO/dgCojVExODC2nCqjSY7agWhwnAW/DfZsQm6n9Ixs0Mb3GIyCvnbvIUYkcvJEg4EtxZ/1nTuq8ZyD3wEwfHvjqjsRPFRtSB5wHppxanQU6LWt0+fPThf99lVp8vRp6RP/9H/3Gw5B1Z97DfQaOFga6B2Hg6X5vt5eAwM0MDx5JJ16xYXpdDuGzChtZlefjPMqg83OGN080xArDTbZW3q7HfEnoxxnICZ58AmUi2dABKe0pEcbPpSPNoAmmTEwe2jE7iQy4UfwOpt6LYeR4X8mS7XaEMYCZZYy2TE3OCOHS+l04onTcP0BXWlwSUyGn/30p+nmW25Jt/7k1vSSvVVo8uTJadj6hnaxHYn0kL2CFiNr06ZNbuhOmjTJHQucC+A/vfWnaerUqdanQ2n69OnpxJNOTEvfdEQ68+yz/G68tjXJUKfVdR+ERtRDoRPH8VPtLKC5EqJHIz+Kd1VYJd2wqzlYM9PQyJCtOAx+vqHghswy3GtHAR3ICK3xlaat0icxPKDHkO86Dl0+ohUdNIynXbZ9TI6Ax+YMbLeDdO04KF/HpBcvXJKefuLJdMzy44yfNKQ4JK9z1K8Q41i5dlw7Cy5zVSwOS0cWZMehKhwzCdWenQdI+ZaChwGoXHvhlgQKoyhM+DZntQvHg+ZOsOtZb1xidPLHK1qJcT5Y9eQFrH6tW/0822BFEXKaXzmXjbwdyMHvWmxcCuAZV5+fPrT1X6Rv/4fPpRfsI3G1rjO3Puo10GvgAGmgdxwOkKL7anoNvBINLD728HTe+65I022LS5lhmZxtEraJmAmT15f625McxhtMrHSA08Dky+Qek70MSuOVJ+6AaxYXnqRsw0VdZAq8kQnD9u2GEcswwYfpoBhnhbp8ZcGlCPkxKqibtjQrKNB6lZSRLvWT/s25576uTkNVW9qyZWt68MEH3WG46aabfDWBVQOMexyCkNvuvprD4E5Ddh4wcMHpGrrogyDDdPOmzen73/1+mjd/Xrr1x7ekcy88Px1+xNI0z7YyQSvDODQRtPU51DTYWSjtCArZiuRqnXo+UPw8Gq9woiuQb5U9IP1KghwHOQtqk9rV5SF9EkOrQ3oUPTGhy2cg/SDHITsM6oexnAfKOYYm2fRoDg/jVaGkAlLrNK4nYbZjOQuMba0qtDFeWY7640rr4o9dIkzaodUHnnkgDF55iKsd052LEq1L55REL0DN9YtDGHVH+3ltq/Ujv0lWG69d3emrn+BbmaHiPHjtDCwak2G+mmF0bFuKgHPimGnS1Mnp3OsuScM2Bn7w119Jj/3s/ozTR70Geg0caA30jsOB1nhfX6+BMTQw015FeNkfvD8ddsLR2CtuQIPKhO/bfWwSxQjXNxr0gDTlpPWqVaZs3cGPqqp1hpiHnWuevks9XhYIYTqIOmLODbmlMULmTLQ3KWVTQpO81W5/nJGLtN35ddkNYnFeN7E4nJW4mxv41EEQL9Kn2EPQ75xzDsn9GkpbMIAw7G17ysqV6ae3/TT96Mc/To8+8qg/s4DRhMMgp0AOQx1TpgMDlzRBxi5p2uTtz8bxurXr0no7nnzqqXTMMcekE05ant58zptte9NU0FsBWfWAcxSUHirtiJLRTkCGR9ScC160v+5d9FGHtWvWpeNOWJbu/UX9cbIao6RpI0Y5etNRStsp6aTWixwPdAg9OuSoeZEmQEeARjwUY/yLl5wBxbXTMCgN3sonn05HHXe0X3vd+rxS6m1dEYJGPJaz0FFtQ8R1HP+k4pqVCY0DznYlt7Rz1BA2iTELGowmkVGRf7DzAGZxE1zP9GeGBl04EXSBf9eBvnLJM9xxzf2wgca2JkrB5FWtGB62luRnZ2o4vMzBOtl1oAemoeL3hTpGZkxJZ12/Is1ZsjD9zX/379OqJ/oHpk2Bfeg1cMA10DsOB1zlfYW9BkZrgDtq53/4ynTedW9Lw2akKmBCuINA7EfensQEbUZ5A/P9xBiAUMSfTEsmeewEJt9i6GCaECiJMqWBFzwv5RSYge7l02x7zqyhyf6Ao8pVF85AOC9IGFBkYxWErQ2+0uB3JUVJHKaKGyk5DezauWcTveaQRc98TCcOCOimzZvSLTffkr74xS+544AMOAsc9apC7SwoLadCjkNt8MrglPDwlTFLjNG6dfNWM8jvTY89+li658670zXvvi7NX7zAnp8Yyb0javWoekpwy4cd7QDpj0y7zTVeu/2hi8KvpGLsbN66MR1y6CEF/ApSGN/F2K8EhNYqRM76QB/SDTqEvus0FH4hgNoqPtCTFh/xRM9yGoiVr50GwVV2yNJD0/r16xPv7lI91Nq+NkIOznIUSNNT9cpCtx/AIbh2rTC0HLBB53gFa5TASyNBjkWhqWvq6NyQVI+7AKAaCu3pOg/wk5vgKw+W9+cesvNAecgg2qgXGLyCp+EYmJLYrGS/BTgGBvEbCpb09Qz7HYivTccD1f4QvxFNsJUH6JAZWeiDSVMmpxPeelp6/7/7b9Jn/8f/19629KxvSTO0PvQa6DVwgDTQOw4HSNF9Nb0G9qSBY84/JV38oWvMaWDbD6Y2gSmTvzCG3ATPX4QOpyE7EdmBCDrDxnBy+rhraVnjEfyUavh7QZQGLAwJR6+octINgihLaRavYPVtSsbV62ykNbz4AzdWG+QAYVLYH3dPqRbhLADNADO4IgX8vXPOSse+hteuBnc4EazeXJ9ns131lN3x//KXv5K+8fVvpGeejje3DHIGMGLlHMhpqGOVEdcGr9eVTzJkKcdQlSGMsfry+pfdgVjz0tp0zvnnphNPOdEepF7kOJDXbakdBS+r2jU2Hu0vnCoSgFWghwhxZlwsWLggTbStWehl+/btXrq3E7qmXSVkrganjJzHOY9O0E8dk0ZHiuFFXnFNr7R0rBg9kyaWc6BYTgKx0pTBa/GhS9LIyEhrzHvF1al2FqDRNQRKtLZCzklaDu6gEFqxrWGTF6Rk33JohzxgKyD1jXYehEAdo2kopZ7GebB893WtLRxvVa6FvhrDeYg2xXMMYMt5QApey4ooIY2vT/i2JeoB6LQUGp6PGEsPWXpnfnAaWd25MdiEoYnppBVnpS3/cmP67l/8g29bGkufzr8/9RroNbBfNdA7DvtVnT2zXgOvXgPT7LWDp9nD0PMW89YaGR/EdjBRM4Famrv0TLm77DZeOBFM//zFxBvPC1A/kOw0NBhAIkQMP/AKLIx3QYKv5wytXWbbBsygm2uvYGXWL3xCGpcZCqPz5yyQgXbYH6sNSEYZPDn4U/C7tNmAAHbVPmxRKtyMs2cKBCNFYasZwHfefkf69Kc+nb71zW+5QYphjLFYG/8YrRy1Y0BaToPSdSwaYgV0IGNW5XIchINRzgO5a9essY+PPZze+a5r0uIli724dhaKzoOyaqEZduIW4yLGQ8arEQuapdr9oLEilEn2QPjMmTPtOYx56fmVzwu8x9j73NqMIV6HWnbhoBd0Qowela+dBulSjsMgPsCkY8XUz0GeuHYQlJbjQAyPSSP2TRKT5yh7MLob5Cygo3pVoYtX572d1ThvlVXwwMPQNsOevvK+tDZZpzZblWrivaYbJqMwdd3FykK5xrurD1Eevye4KXtbeTDRfWtSOA9QRE2MApwBf0Da3R2DIB4BZ4SBS3t322oTqxDGgGci4q1LyOcgKzdd2PMnp155YZo6e0b60v/2yfTU3Q/DpQ+9BnoNHAAN9I7DAVByX0WvgT1pYMkJR6aTLjk7b1GKmZSzG9Y2C7uTYDMsRjgTqse2NUlblZjSwwAPB4O6gjZqDSMw+AInMLkToizwA9IuD5yMHAg+5c+cOGLblEZinjd4mJ3hCFDHTpvceYAbQwj5kVkyiidlJY1M0IdsxH90yLVe/kpORUKTxDMFUjsLai8SP/HY4+mTf/mX6WbbooRBidOAcSpjVcY9hmx94DAoXzsPWqUABi04tWPgusgGrHirbZTpwMDl+Ydbf/wTe8ZiXXrvh9+fFi1Z5PI1+ErkGJsrwuj2ZzULoYnpM/SgUHQjSMQul+EdtewYa1c8u9HG2HOO9tQBfgRiGffE6ET5ug+UJiYo9oydQm+R22Uf3hMP8a+dBtL10XUcJNv2bdvTKWeemjau35Cmz5oRK2RWBS2pnYWivahfZ9etFYaOBS2x4E5P35cid/ye2baqguw5iUzFPR2EC/dmgAxCKMNgABrSybmA2OtDZvVHhokJstDF4SBAEQEnAOeBKvzXwekNiJNAC3iIGkL3mHiuwRw4K2EFQm9tA5MHrimbPH1KOuVt59h3U+xVrX/wf6RVT74yh9ZY9KHXQK+B16CB3nF4DcrrSXsN7A8NnPO+y9NC20/NxMvEyERNKvYHh6Oww7cohelNaTx07FiWttgmX2gJYaJHGm5xxIQPVMYR+HBUgK9CDReMOCSbkA4bnmFTfUzuwBvJjAU41MGfnB7ywdPO4NihtkIPFSG2KUV6T1uUAsNJ7ER9pDO0Y/xIL8LbunVL+tEPb0r/9t/8r+nxxx5zg5xVBgzX2kiVcS8YeZwBxV3noXYiVAatDF10AK2MZOCuJ4O7fsx4pgxaGb8P/PK+9MW/+1x662Ur0ilvPk0N9ngsZyF00ULNGXqEEOeil1ycI8cyFGGL4szzz04Y1K820DaM9W5b0ZfaKZ0Qg9vVvfQoXdYywJcgHSquecNTvAc5DpJPfBfa6t/SZUelabOn+xg+EM6C6kbzz2x5sWTd1K6yA5L05b46D+pndw5MlXvftsS1GysPNrgbadoyGFcboBQHPPcR2F4HzgOBWwoT03DuQzYkxUPSgWeP2Hu7wOVDk7QyKCwNS4Mdc8HJ6d1//LH01T/7dHrmvsf6bz2YWvrQa+D11EDvOLye2u159xrYiwZOetvZ6aQLz7LVBjOiGlwcAQwhnAabeDG8bJYE5s8LmHEVEzKTM3gY5QrZhGdShSaDIwbfCxwehnzgZbSYjJtMSRhlk1kwPMW2KpWfjroMBvFMQxiKyB11BhZyZAktVXgGc6PFHjDwyQOea2hji28WC5siB7U5suCRCuqdpru77ro7feLjf5meePxx06MZJtlhqNOCyYAdK+46El3nQXzQAQf43OV2iTJMZTJs67rA5YFpvjw9xb5IfezyZU5Le+p2RToXtSLD83yc27opiI5lKG3sUk7q0MMPS0fbqsPqVau8Le3Svedon9qKHkjXxj3tJq/21/1BWgc1kSbAQ7F4d/lKr4prx0FpZ1KdFtizJYe9aamPZedfldVJ9CUZanjQhGyRtrPJKkhx+ppSElFueDu8eVy/GM5QVQPcMUef6Nt9dR7ghnS18wBs8LYlSrg9kbctWa70h60QmPcPnW9RMtGjq8oD07SGZx5Yu/LtS7bS4F+Z9t87k4LnGpomk6YckPE0NfCWpaat4Fk4+fJzbfvSxPTt//yF9PCte3/zV1D1514DvQb2RQNl9t8X6p6m10CvgX3WwJSZ09O5770iLT6K97ZEYPJ2A8hiDGymZ/6A+TYlm0TZY81dN8rDGInZMyDQwwtaxYI5IMMjDV5g2dmSzlNFOUYmBbYMzJ4wOU2aEIYfZdD4HzJajruzUX/Ebsg5A8O0Mr97G0K6LFEetVAG1bX2UDSh1GzpzNcLOFW2VG0Qd/FqHs8+82z6+F983D/mhlHO9iKMHhn4Mk5rmMrqWMYtMUZwfXSdB8krw1V5b3c2lKHHiK35SoZt27alX951jzuXH/zYDYm74eBlFYpdFUd/CFDrRjBi17QpJzTe1nWN1+Ba4q2XXZJ+dsttuS+6WHvP02bd3Ucf9UGbpIMhS/OMgfqDMtIKSkdfB1T67MY7tX0pfxBO/SA5xFMxdc21h8GPttfPDgrwl8665TU88ArG3pwFjVPix7atduO7UHdTYBV9qFR9PbYDMZhO9E2c0bi2cQIU1D53MOzqxXkg8NyDewgZVb8jlLLyEN+NoNDfo2TncB7oUqC4AkFjFDQCD8F+63ZNwGVwF8TwzNUw2EQjgsbRLCY3MmNqOuWK89O0GTPTp//oP6VnH3zcSvrQa6DXwOuhAZz+f/16MO559hroNbBnDSy79Mx0+e//pt1JnuaTYGBjfJsxjlFlsyNrDnzwjXmZqZUJ2MvByQZMGAsx7YJHCJicByBRABzMjNbEJDTZg00oWJHjPNVWGpaOzLZtA2WvO7zARa5YbWCzgd01xcmxP+QOmamdPFD+qjosQx4Mvttw1RxewWo4ADMmKbcYsBpcNyoZjedkTlBOvDHpT//PP0mf/ttP2V1/+8DXEB9wy19+NsMdgx8DXoa/8oNgwumW4YhQ1o0xRjkU3Kik//JBf5OuDek6T3r1i6vSju077HmHJWnGzBli5bG0GRoJPaKDrh68PvSaS7rlNVPhAIs+S2mG7ff/4qc+u09bllq8c1uBqZ0um/SRy1VW64U0Rj+H4MrXMY4hh8Osv4lrGLwHBb7u/eE//Fg64dQT07A9JO16MNTQ2mga6clLkJ82ZcbuLOTxWqDR5hZeJcjT21el+zY/ZZC4wx5FZh7Dxy8AO1fpKG+fxdvR2kU5N3YJCG6aZxR4hameSVv5Tmk26sGkpDgdIT98gkIYwRkYTWs9TWFA2umHFTsOSGC5bH5yCOQTrd/mH3VImrdwfnr89vvSlg2bfWxR1odeA70G9p8G+hWH/afLnlOvgVesgWlzZ6UTV5yTZsydbTQxJWJyYHjzh9MQD0Jb2mBm/liMAY4ZbhhGguGDQU5whwCgp4kjTZzBgVPBHdnQ4NcNyFBCSc+1bUp6UJHyMChDJtLx7AWyGwecHNtflSVuZBbvqDd4SwZM6+OnLDFcWmQhbINI2zlDLaV2BX2RsEH1hNdlhXyn4Stf/Ur6/Oe/4HAZJMLWHWzd4a7hY93tBldlcgwU1w4FMAJGK8H7La8uqL5BMbiCk96yeUu67Ue3pOnTZ6R3fejduYekPzBGB7VfOgdjj7qqWKhPKlA66fRT/FmLO277edpqX9h+rQGdSIc4AdJfrds6TX3k0aFiYOTrA17k5VjUMfA9hRNOOzkdb07D5GlT/JobhCt9OifqrpAGrSwMxKtoal3f9vL9Ps65z86bhtr8RNS5MATuxLpeissaCPymcOd+rECL/C1HIBga8hUnwK8+Jw2znyucJ54i0FZx5qaHfxHa4tErDzgR9pu2O2i725YanYqhxdQHNr97Q7bFCdckzpbMBMvfdla6fsfvphv//IvpkZ/d6+MgJOvPvQZ6DewPDfSOw/7QYs+j18Cr1MDsJQvSCRe+2e9wNzOez3xMsDEx4xYwQboBZEAmb/+zNAY66Qh1OmBhMEALBrR1CBzKoOyGwpeSQstqA1+K1usRRQe+P5ztxr7nDGJ/VgHU7NMORyB4+fMbTpx5h5AuI9IcZ46DLI+u3GoP5KMld6ZeN4XULrwnn3wqffGzX0gbXn65decf41Ohmx6UF4y4mxZMhnDtPMiQ5a43eMIRTZeXZOrGL77wYvrm176RTj/3jHSo7cFndaMbvN2d9ndxlJeOyA8aC4PwLrvmyvT040+mp+3LyvsjoBsCsfRSOxCDdKR6ayfAx5sNEOnarxvjWedFN1bMSs4pptuTzz6tGT/g1nryUeVjO7iMNuzLuOMCjNzo8Vrru27HY9vWNOLxzI8M8gaIPMZXY6aGj5VGwzWf+KAckpXx36VFcncMMprk7ToQxXkwDtkJaH/rITRA/fUD02gEXvEbEVyRBlfAn3mwkh2MDSe08ZFFRS7WO+E1nK9f2sfblgiTpo/YtqXz/LXKX/6Tv06P/+Jhh/enXgO9BvaPBurfkv3DsefSa6DXwF41cPQZy9Oiww/J0yZTqP7CgGOSZjKMB6NJkc+wjAuUEM5FpGNyj4nabAsLkQ5a0tRj5wCD0IQiAaDAbQotEa9gneIgN9KcV5EpVha4g4jLE0cjuc3pyOC1+/weAtiihLez1LMrHW1blbztBvR6cJL8KBJ2xfcSqxcHBpqoK1q7efNmexj6E+nOO+9q7vqrPnDHCmOVvRqDDd41vtI1b6VVJnnqvNLgvvDsynTjN76TVj9f3rwzdvvFrcTSIjF60lEwIlXjUS9jkeOCFRelZSct76K/5jx1aKsR37PQwTMepOuYtPIq68KAs6Ihx2FvAqLjOfadind/9AMx7vJ4DT3EtUj7XRc2hnEYwmlgDMXhuFlPjteUxPiXrn18Zl7giX6lPdtQgl8oJVulsr1cQfae1O9FG1N1t6HK0R4PORJ8rzFty0i6lmkz7WzdRBDM4Ta+7K4C+mBUsuGRFVa2PG63mGubmPzO/CFMTxsMCnAJqHPS9Mnp5KvPS9f9D7+TJk+J3ywv7E+9BnoNvGYN9I7Da1Zhz6DXwKvTAG/HWXbmyWnS5Ek22SlglIVx4tOmzX5jrTaEoQEdpnoxB2JiBkrQtK18wAQFV/iO3joFliZ8WHE3b9HEac5V9cd0jdxIzITN29lJB2/wVEcYAyFDWzZJFK3hbUqO6w4AEmTenoK+BOdveKOdBaPKRt02Mxy/e+ON6Uuf+0Ja+9JLhTinZJCThd+gEPKUMsezbI2vNLEMVWIMYQxaDFjSKgNPh+oclK/LTBUekPlnN9+W7r37Hm/7oPaLTnH0SpzV9+ob4RALz/uWtuSjtD6lE+yL1he87aI0b/68mnS/paUH9CW9dZ2E2qlQGbjCl55fjVCTp05JK665PM2xPfI+fur2019jOQsdvBi1ocuurtU2YjB0KHXrxvsdFhNzPEg8uA1jOxWD8QMavw2DMCTB6DLGhIeMojYJU2Mm8vGL5PWgMyHlWGPOm2+l4MURXPn9YHtTbNmEV6T9WrJcM9blPPj1H06D5Ci1TkjLLjotffhP/zAdccqxrZXGjlh9ttdAr4FXoYHecXgVyupRew3sDw3MXjQ/HXvBaf7gpQyEmJPjHFMok6QM74hjgo3p0SdmE8ZzPjsHreSTYSIawY0gbJUGEIky2TqzUpqzcyaMpJlDk/NmgFyvMQtZY3L3jVV5Iqd+yiAPGYzGYSUGzooDIdI20fN8Q6ajKBc7TrTV+GZnQfyFVxt2XpcZ7i+tXpM+/TefTk/a15gJwDkGpR2YT46HHB1c0UsW8jJSiXXI6JWBSwxMh/DETzyUJ5aMJkSTVjlfl/6pOQ+rrX1qfxY9cF2HLqWn1E/E3SAs1yftscPr6SAKj/jct56fznrL+R2M1ydb60J66upPenktEhx53NHpvLe9xR8Ar9uvcRWjMWsh66lxmq1i9UPRdRlvRT5hwafQIPfK7WvSE1tjmxLXA0Fx5MpZOimQ/ZUaPT7gHNLmOjJKV7aCEyV+Zixlsja+wb2A34k6xPijxuI8hEa1usDzXv6sl/0O8H0b3Av6gVTk4GE0BhuaOpJOf+eF9hKK96SlJx9dV9Snew30GthHDfSOwz4qrifrNbCvGjjjHW9Jcw9b6OSaNGWskY9J0GZV/2diZfJloo1D9YoWRKUdN2Zkh5GPAIcIBRYGQSkJDJcB1ExA+eJJMxKvyNSeaPEIwz/kAg/anQYsho1hIjf8PChFLLkFa6rMuFk+o5chQL1BmblVd4Gln6jPJDE5br/99nTXHXc6slYXhAdwULqBZbGUJ64NV+VlxOIUkB7kNMiBqO+Ii66OR9XFw+Xoz3XYCITg6aH7H0r3/OyuUARtqf4AoisdDVIHz/VJu5o6CmbNz9PCsfjo449L19/w3jRzDg/3/+qHGbNnpQuvvDid/paz7XsA9qrhZlzFaFP7pSfGucYhsfQsfaof21hwKRD3wlk4sIO3pX129c2WIfAAcMQeDTjty1YlsUH2wQHpCIojp7PGg/Lg0d46RAuBUAsmvQXGDbEF8qwoBJ3BrSz4UAYcjHAapEucgViFsFK7vnAg5ERAwbdZ/M94gUttwZ+qd/urWt98/VvTNf/qhjRzwa/HeDUl9aHXwEHTQO84HDTV9xW/ETUwa/G8dNjJx6Qhe82jQkxyMYHGpGeQPAliqMQUHBNrlEMZE6QV5xB4kWmATZlD7KQJVVQlDhqf6AFmFtQ3x1Yapg4hL1YORVEYsli9JoT/IbNN6vEtBqZyyWT4Lmi7DkAYQNE+w7a3pBw3Oa84WOG+OAvUqFrZwvLdb9+Ynnvu+ZDbeMqg21OMcUL5ngx6yuQoKC2HQVtm5Cwgh7bTAFM5+DrqukhLvkYHtUyum91p1fMvpJt/8KPQvbdarY/YG51PuYcCN9PLCI5eCcQaD4jk8Nj6Sgb1pCkj6dKrL09v/40r0/TOq2Fzlb8yEQ9in2EfYfzIv/yv04i1ixHO4X9ZVz4empK4jmKkha5rPYk+4k6OSygf0Pib0+ya+Yc1t1iBQumRsSdomOx7aK7zFouaZ5GhhaJMVYwe6oDeSuB3wIK1tQ0tv0VWFNdbJoKfa9UKcBjq3xMcAx3uPJjuWH9g5cGdBnTq9MWJgO2QvSZ5ub3++j3/5vfSQvtuzsShsTWbxeijXgO9BsbQwOhXcoyB2IN7DfQaeO0amGbfbDj+nFNHTVxMqn4wi1aBV5q2jRIK82TseEyxCuBGOozxyPjZTmNP8IHX8ImsT7882zDTnIapE8PRQRYCU7sbPjn2O36kTd54BSs4VqPh+5GlDBkkc5SFxGZP2RtZDJLxBTU+tT1D3Wqky9FIXQgcntI9d/8y3fKjm9NG++oyQbJ4psoDl7GuWLjKE2Pk86Yk0oID674BSHUBp5yVjpoftGM5D3IkiFWP6urGmzZuSrd+/6a0bu3agXf+0aXLEgLlnINaJ+EFWu78jFHrvosH5rW/9Z60yr4v8cNv3Nji+auSoW+OO+WEdP3HPuCvX/V+qoSvtTHq+qnGIaNdoaQyJI9f6O3yGHUd3r7hIdui1P7gG6OaqyG+HC3OVUzdr2XZwVjpyhnbhKYlnYvPIBoHe3tda7xtKWT29pjM7bctRRntjHqIFXjbkv0ZyN+mZDGvX9UXpneAWgtuvx0TWIkw2LCV+denDcXbyM0M+xsaGUlvvvritGPLjvS9v/xyevqe/m1L0nYf9xp4NRqoL71XQ9fj9hroNbAPGjjm7JPS9MVznTImbmbAmCB5UFp3y7gbvNMmSgyZMEqINdnLwHaQnWSIkw88lSg/yuhp8Dr4OcukTcCwWjjEx8aKAQEv/lzWfMcPCRyKcWB/5KLOIlvkna3fRSSFDuQGEaMDatadbY/hWR/OOWow1Cb4e+KNYJcdW7ZsS3f87OfpzrxNSUjw6RrkLd5VeRdXdDLqte2IvBwBYq00KK5XG4ApLxo5CzU/1VXLoLRicDZu2Jhu+cGP1TzXvfTveNJbgxGJ6KV8Fo7FhJbuM0e0LX6xwuSY6dSzTk+/+dEPpmNOOM5pf9VO02dMT5ded0VafuYpeeUsjz/0YEeMshjLtL8+akwfs5nGdcDlYgdbkKDx1ydbXF8D4K3cuird/PKDLRsYwpiYyzXnPOuTF0V/1eB9Scc1OBbl2HUwejzkqNu2ptxa3Vzl6LCqSvpFl6EnMEPv0i/POoDnurcUqxD8Mf5ZZYhtSzz5YCsUeeVBr6sGTwH6kWmT09nvuji9859/IM07YpGK+rjXQK+BV6GB3nF4FcrqUXsNvBYN8DalQ48/2t69H3fv4eUToM9tnJggbTK0pCZKTaLEJSgHvoJxynOkaChpWAvNYRkxwwJfyCGT0OfZNqUR+34DISZuJI6JHEwmboJewQqOy87ZqhGNIw04dX+AjplyaBiuRuy0xM4RrnGIDa2onYVoVbRm08aN6cv/8GXnIXzihmfmvycDHYMefDkKbqjklYDa2JcDIKdBce0kyFkAVuMrLX6SR3nVrbzKFe8weX783ZtMN1nvJu/etiCB29KDGaF7cxYc3+gMszlIMaYvsS1LH/j9G9LseXN/pd5cw/MZ1/zO+9LVH3lfmm2vYVXLykhr66luO2nhE7tfjTFvh3/dHYfaDvQGP4Va7zgNn13zEy+Kq0hYJe5eH6UkV1YArzk1lgzR7r2wL01sIYaWBMq3CLj2BLI4rtgCCZ0V5wFsYO4wOC3OQzgNvtXL0uE8cL2Sjm1Lch7Qf13j5JnTbeXhwnTdH38sTZ9vzzygyj70Gug18Io10G9VesWq6hF7Dbw2DUyePjUtPPLQNHGEy46JMqazmNay4ddMcjGRasKrtzj4RNjMs00i86xljLKW4eL1CqeirZIq5eNKcydOHfClaJPKJvBYcSivYBWs1EebCMV4AoeDQFmZs4HHlh7KREm6Dk4JXgNsmzuCP/DAA+ll+9ib6hK66sfwrtMyxIkx0tlmxLYkpRVrWxIxqzE6xEuxyokJwBWrDnjiOCjuOhHAOWrZlIaf0rf98GZ/QBRZ6qCxI5hkcDkq1Bov9DsK4iyk20H8rnj31Wnt6pfSP/zt59NTjz4hlHEZo6f5ixakKz54bfqd//4P0hS7LsuYLX0Vwrdb3crVOqQ/qlFZN7yl9zwOKL91Q1lpGOwgUFtVSc3U6xqrrIW4nzKDZdFI8W1JhoLTRIjPuUXV4NTblhxqehi9ban9+lk2GPFLgG6cq9HsmGDfjbZM2bbE9i/DNFR/tbWV8xE61h8yeQgBXaRCFru2z7zm4rRh9dr0g0/8Y3r+oadzaR/1Gug1sDcN9I7D3jTUl/ca2E8aGJk6OS09bVmHW0y0mL9hYNgMyJ3KnCeFrUEcJjKpmFBlMgdtsCUd1JpsAz76XOqty2QIABu2qXbupKk+0SKbyrw+y8UqQ9yV5y53yBhYRd7CXfICkYyC0ca6leQUvGgMZyFaIUxrs6kGA3z16tXpwft4J3470A4MbsXdtIxxYox2DP/agZBDMMpIjwY4X9EJt5agy1/OQdeBEFyx6JQnFgzan/7oJ+mci85v+og6YzyV2tGNgvqSfPStShzSZFr6tUxNpz4Eee6C+emaD78nTbWtP3/1Z39uH6l7ruEx3hI8GHvRNZelKz5wjX0cjIehu7oqrS6p3IqsQ9peO/O5tIlq3ddpEOiHL6/+SXrSXr9aG9gNcZNQhyluCg5SAm0MloVxIecBFPRTt60pt5K45nEADIrznVsT8KDjcprgTohtPXRejD3hGp2LAi8SPIlFDZa23840YYfFOA/mKth2zxLC6SDP9Ts8PDGdfd0Ke+ZhW/rHf/fXacfWbQW1T/Ua6DUwpgZ6x2FM1fQFvQb2rwaOPHWZGaFx/6yZzpjrmEBj2vOJkHQY4lG/yslpct27ZEyo7eATawWqZQDcLV8yPMumZN2nC2MAHN5yEoYTuUjzUDRffY1gpTkZ5RlsuK80+OpDC7mRdhSXlkFsFWPo33fPL+1ZAzMgBgT0ieFdOwV66Bl4N41hjqEhR4B07Th4/xhPYox58AbhCk8Gf+0EdB0H5cGp06KtY6ss3f2zO9PZF53nMtRNbunGeyuXIm+NWOVqODLXIQy1GhJpsJYceVi64Q8/5obxf/mzv3DnoUs/mvLAQg454rB01W+9K1394evToqWHeuUhY2lnSWXZsmUbYz6uA0q6eHVbW2lZxkazctua9LnVt4RR7XC4FIRWfxlYJROVoGIPowAqeE0xV1m54gexass7CMMVY+Khr8HOA1QY/XtyHvhdNCxvJqdYedhl25BIAR9qKuetSrvtRofdNLBrk98O9+rMidhpedeiOxQQWJ0B8fOshXPTJR+5Jq15dnX6/p9/EYQ+9BroNbAXDfSOw14U1Bf3GtgfGsCQnDZrRppRvUecKTgMMVIxlWJwMHljiPvM6bOwFzensOVEA7ikxzLsGmJPBH6d7JqRU+25hhn2LMZElv4tqJyYOrTCQNXIHOW5TBQuKHXlNlkS2sCN9sY9xChnin9oy8p0zOQw6MBQqCR2UMvACoUE3M4Y2k899bQ7B6KvYxndruu8siBHgn7qpmunAT6100De228ywBdaHA85F/BTEF63XuiQWQ5CN4bnno5tW7akJx55PORAiVWQrl1/3k8qbGu0ziGfwp7Gk4/RjEhPhUNpb1q64X1phr2i9euf+Yd0109uT1s2bxG7gxZPtD5Z/uZT0jtvuD5d9p6r0jR/hWxpZ0nRkCIm7a9XFmq8Wk9Q1Pl6fHqZ8cFp+LytNLSDKovYL/sMIh2y2NgyhnIeRNHms/9yuurKyO3ybgRrFWis+TWdUdBf7Ty0CJRhXOKM53zUH3QMxfbKQ6wtsF1JL1IQIc80+GPltsrAWAQ+YRfXonH0LUzEVGItc75kJ9h3Hqakt3/s2vTC/Y+nh352b9q+eask6+NeA70GBmgAp/1fD4D3oF4DvQb2swYu/yfvS0tPX+ZGpc1bFmKqZaLkIWMmWc7+7AAf/jLLoTHQHTvMOGg1uZIOOy94BV+fF/0UFIbUCUHfAVbZ2cMjaekkPpbEHbzgGvLFsw08foi0vPnJ33rC3b0sv1ZLZEi4jFbmwXiRon5SbD8oqd3p/BnL0rzh6RlmUQ5uiIFqh/g2ZUpYDN5TTzyVfnDj99Jdt99RlbSTMuxrp6CGKQ2V0oprTuime+AIAJODIqNfDgJ5OQd1Ws5DXaZywYQjnsRbzHE44pg3pRPPOCVNN+dUwTWe9R2w3AeWKalcYngK9DO5AlEJ+jWo+oE2VnjCnzxlsslzVFpu8uzYtiOtsu9obLK3Px2sMHnqlHT2Jeen9/7TG9Jb3rEiOw2d9uU2+fjydqGDaJHahfy6FtSWOr+nMfrz9Q+lb627W2Q+psIwt+vL6pbZzA3ysiXHoMjlCmcc1mnPNPxejwTt5hi7prFLkEdtqtsHnBBloWNvbzSuqQvOpW7L+T9OQ8jjsdGAh7PAN2CkucChxIJHgTfR8KmLmID+IzkhTZs3M809dH5au3JVevGxlV7en3oN9BoYrIF+xWGwXnpor4H9qoEZ82elKbNn2BZcmyyHYuJigmPqLIaapQEC99uNOWN5GfoyZhxpzFOhE0qhC2PP4arLp2Nh2rMNdnduyfBMA+TJ11LISAhDybhZ1h0FS/ClaL0yMeRU/dE2JwxqN5La1WFkxyQOlQ7Q3RBzOtWbM5SV5Ci8qdOmpAfvf6DCGJ3EiMfo7m5LAsYqAYccBeJBQc6BYniKVisN4iEDk7jGlxxyBLoOgvIqV9yFb968Ka19aW1adLh9QA+FNqGkSyoKazz1b0NWJbSyQN9qVaEqHpVkrE2dYd8rOf3E9Ef/8X9JJ3z8pHTjF7+RfmnbqTZt2px22urKgQgjk0fSSWefni5731Xp0uvfkWbMmeXVNnrI3UrbudzG0kGtpzoNs9YYrUZljXf7yw+nm+1B6LHGUTgQoZF4IJi0HIqAx2pDCDzGcAzE1+Gs355azldbDbqtVx4YI3Is4MXNBvhr5UF1cqU73BQdD16HDvyF1M1WJPtWSvNbZde09eUO0NTRlqZ/Gce8z46VCrZgQgWunIejzznZVh52pUduuzdt2bDZsPrQa6DXwCAN9I7DIK30sF4D+1kDM+fPSzMX2esq7RkHJkUmzhKY1SLvhkj2HsCrjZl6Mm3R5kyNC/tWvhDsNTXLPvg2Y0J8QRexkLX+Y5JHWl596KsjLjswq9HSLreVKZQUMmESdUPQMPk/unVlOnrKIY5QG1+hnUJXDDar1wsDgzRVb9uy5+0GLmd2HmTsY4xj3Ckvo7+OJQH09QFN7TiIBnzShBofXPI4Aq/EeUA2HXIe6vjZJ57x1QZ40mMKJRX1C068p/ExlrNQ86t5+YiwQo/rAktf81vv9e8k3HHTrelbn/+av3Vp7ao1Haz9kx0aHkqz589NR9lrj09/67npzBXnpWNPPt4f2vYa8uCj7bWz0G1X6DFkaqU7g7dub40HJTr86qpb0+O2RWlPgWuiGOVIQiXIZ3GnvuAzEBhFr+O5LScVSWuD5YkxkU16Q0Hng52HijPXlV0v4lhKDG76iG1L8TuCBGxZ4nmHiVaGKxLOhT3nZHx2sQqRRfRL0B6Y3ulblgxofWOfcqwkmpAm2UrZ8Zecma7+Vzekr/7J36TN6w/eKhlt60OvgfGqgd5xGK8908v1a6WBNU+uTIuODIOYhjExcpeemS3OMRlifDBZ1iHPfQ5ykkg5XuRrmuBX0+8p3cVGrrkTpqVJE9nFSA7eIYFkY1sVW5W4c0cZf7xjvQS1SBDDyMW+99jposwfZMxoXo8hygCrOYKyJ2chs/DoqSeeTPMWLqhBA9MY3nISiDHwlZexD2GdRrY4TB5LY/TLYVAMfn3UlYseXNKDHAdgtZNAWjBiHYKTf/bJp+0tMfQZvVECddRBfVnDSMtRIM34q1cW2hzAiOA1WWG7RpUW+NDIUFpmX2c+8rij0hXvvzZ97dNfSj//wS3p9ptu84/lbdsPb7NB32xJWmwPPL/V3ph0zmUXphPtmYYRW31SoO1jOQtdPdX5Mu6qdmemNZ63mEvGwu3rH0w/sZUGjOBuKMZzlBWnAUw23kRMvaOpKaNHBpdQ+nqGYsi/wlpQOLLmiD4o7Y8xEm5Cflh6AGwcSR4AAEAASURBVNtCE0zaMtg16GBO9ou0eyiPZcOSAilyfeFa2GrXhGEfB0jCaimyoU3G0MRJE9M571qRXnjs6XTr57+Xtq7fBHEfeg30Gqg00DsOlTL6ZK+B10sDyy8+M2225e/pC+Kr0TK22nadz3AuQhh4yiuupWOqs4mQOblVHPAas6QrxCpZyu2DXvZQ9Ex7viGm0lKCvMi0y27nU18YTEzhpEPawDbMzNvxAwhWOBkmcKENIyK2ZwRR88AjFDSlCeIbeKqjKW4Su+29/FNs285LDWRPCQx4DG8Z+nIgoBGMmIDc9bHLHryEXg4DfGrHQ/ROXNGTF51iOQN1LOdBDsKOHW2HAlyVLTpsSXrisSfSwkMPyfqNWuueCUg5184C7YrejPLchQU5pxgH0X+jiihpgJ5CX4LYShvfMeH44D/7iD1rcHF6/IHH0k3f+F56/omn05OPPJFWP/eiPcM6MW2x7Ux7C9NnzUzDxnOHvTlrzsL56dzL35IufMel7jC4FZgZRLsaKYo8Vt5tR52vx17VCufaxhvN+w5zGm42p6HtEAxukWxbSus6yY9N37owQD3IAR2MLRP6c+cgozEm9+Q8WMdE2+26g2v+lfE6eIUrl2M8Bs2YxdGyGuw3aJdfp7ZVySC8sYng6xDmHIDJA+bw4rsPO7JycbX97U6OayejmL1kQbr4o9emNS+sTr/4avdhdnD60Gvgja2B3nF4Y/d/3/oDpAHeFc6+7xKYEovRwf02mxM9uEFnab8ZJqBPeYFQJlKMn8IxU3tUG4y14VMbh11K8jMnTjLnIb5sjYGkP/jxh5yayv1OHxO2MzID3PBJg1eC5XK2WzfwMAwK/kNbnk2XzTnDycNAK2XiU3grFbIpd9SyY9LKZ55Vdo8xhjvGt4x8OQnKQ+x6sMplMCovo58YfJ6XkOMx0Telx8qDBBAdeWjIi4ccBvK1QyDnIcrLdiU5DKJjC9ykkZHg2dK/ao9YzgJ9Ua8qtLHaOZd7DJ51XwdeoW0bwlU/Gsrhxx6VDjlyaTrn0gvSM089k1568aX05EOPpfvvvCdtt2vlqYeeSBvWrU+z5s1JG1/ekNaYU7HUVizmH7LAV1YmT5+Wjl5+bDr5vDPT8WecGAPJ+DJOuW7q8V8kir5UHnnrUMvbbVcbr9CVVEo/z6sMNe7e0sjqljCRpWsZBtFyvRzswNgZ7dR4Q8YUDX2+Uueh4c41VzkPOAh0tPoNRwGYnAeU569vNTrHxcGw3ycPpO2wq9SyxtdweNuSb3GKTsiw0PDhJxyV3vpb7+wdh9Bef+410NJA7zi01NFneg28PhqYPme2rTbMGci8beQwOUbAiGBi4zkCQimJ8oCMhg5AFMEeYyb2WRMmp0n5FawgSzYmWtL8EcdboNzd8XxMzzEh13RRYVvGPJV7kdwO2gL8XnvGgbuHClbtgIAUhFJYKFJ6wd7ic9qZZ6Qbv/6tAbRtEO3C+JbBL4eBmDIdonI9mHEfBr/JnA196MWn5iU6xeLX5iN+4TTIGZBzMCiWQ6GyNatW25uMjvS+UF2Kx3IWivaEGbFr1wql5XZpgTs9OqoQ2oZvKfF213iWHpo07McRy45ORyxL6ZRzT09X/1fvTi889Ww4cuaIPWev1R22Z24OO+aI9JJ9mZqPdM1dND/NWTAPK9AD47F2FkqtUU7dCq10pm/KqpbUeJRLh54WAXDjfYe9Menmlx906IR87WBY19uUGE8Ev9Ne1Yu+lG3rztHtpNLI05I2RHj7Eu87N66319N50CpA3aq4xrVaEX0qp0ExXejPPHAl8BE4U9aw979958Fi3gKHAmO8sFXJ8lkN8c2a7OBYxcvOOjmdefVF6e7v2Ja6vTwzVcvZp3sN/LproHccft17uG/fuNDAwqMOS5vXbUhT7c1KEWLia5tdMYdhQcuIwCiKCRMqTIagCx4yIWpYlIw+Vzg52a17xJ5rmD081UkxiLp//lC0Caa3KSFX4DBJh5zBMyoochcHZLRcAQncoPN5fhRicFb7a941Klg8GL1o8cIavNc0xvogp6Em9DaOWimIL0vjLOio+Yhejgj5QXy6Kw+DnAc5CV2nAdxDjzzcDetZc+fECPG7qOgdI6mMoWoUSDSPXbtWKC23Ci0juNP72CgYGqsByX1IpsLr1su4VkAfhAm2akJYtHSJx5zmLyn96G9FykMe+rGcBfETkzrflrW0C9waz0t0eVGWmXmc23XHOrYkPaQFg4yxtwgOeo6ha3yXCpFTudfvjUqqYW8yv5ryaN9YFIyjV7ry4M4Dus6rDvDU7wQOGMNG33iI+mKU0ire2zXs2PEING9MYBskr2JlZXTCBN6pFG+GQx62NDGmeNg6fLwJ9ha86WnF712b1q9dlx76UXmVrpH1odfAG1oDvePwhu7+vvEHQgPD9lrIzfYe+0n28GYdZIxlG8+NE5/C8nzOxIgpxYQXgUmZY18CTPdMO2/i1DRizzh0AwYVEzarA/yRx7AJuEz4QbwNj0YMCPFQtGjzPmWbvuH/uH0E7k1TMB6loeAh7C47xzIUYc8/ZFGaODzshjwG+SsJ4GGQe9uyzLpLDL3ginESoNHrXLtOA3lClwcw8SCWw0CMA6BYjgOxHIU6LRj4hMWHHWLfJ5hu/RI612t9KRvcA6EvZBgUpMuG3vCE2Ta+Bc311HgdxoOchUApPJr6RJuvBYejr0remqrbjjpfy1takWuu+eULsebbyJPbhbNAwGHYt1A1yBjQe+XOve6m17BuLW36bumBzOvKKvKrdjRYy0m6aJU+2BfnAe5winrRlXG1zo03KVEaeqNLMf59FcIyO7MobE3aYWVcmhNZjcjad+fDieAc6w7w4to95uyT0nnve3vvOKCQPvQayBoYbSX0quk10Gtgv2pglz3AOe+IxWl4pHu5MaPZvS6LmLcIYdiQiUOTs8cZJ8oCW2kZZQ0Kxa8i2PdV0+yhKf4NhyCLO3Dwh7f/GfOccuMXoZmcm7q9EYEvueFFufIhH7k8m3tlBUr2YduudOSUxV4iOs9UJ9cT8viELy0EAl8tnjV7dpozb25iC88rDTLCMRhk8MO/PsDhkOOgNHloFNc86vprXqTFj7ScBcFwDgRTWg4DcPCgmzptapo0aVKau3hBflNXXWM77fVbfwwKrtNcEHgFqza+0fajG55Jj738lKVi8N6/8ZmMHP3KnVuF2L1T+vuYGYd60ZumH9oYzUunl1UGDQ3GTb2qIH6KkVGhTgOr5e22SzSBV/EAgMVpfB1q8bNbVqeVW1alZ7atTo9vXQVC/oJzmMugK+xtm5LjVfjk20a3ChWLcx0j2Z7Ka9wDk9Y12m5LLWfR8SiJarRRhQC4lWCrefR1pWzqjPq4Prleg5gx43BDd4fC6PwBaCv3bZ82oHg4mt8trcTtttUHxKAev3VhTgX8cG7YTnfqpeekI089Lj15j70lCzn60GvgDa6BriXzBldH3/xeA/tfAxh4UyZNSds3b0tDU3ljUYSY66qJqEoWjAAyGfqds8YiEjJc4k4lk+bYoV1WG1PQTLOVhllDIVs9OYLnfzZhhvlvZ5t8/e1KXmITrJfBpVNHzsqwAMPdiNwG4KKocR7c+ly6xHHbJ+TiT8FToUSBmvjYE45rvhDbAF9Bgr7COPe6rD4Z5+RJ65DjgAFPWoccBsWDquzyFk/FchYGxbXjIN6b7S1Ep9pDwtu3bk+TJseD7SpzfZmiar2pjFhw12XTj4HRDDXP7k7fWRlvmPn7Z29x46zewy9jNrbVQBAdEwZd6SS2ivwiOxnoqA76ou9yHIpcdvQ0XmE8IR0x/RAbc2DHWD982uKWEdeWtbTLKaxddRj0vMKzW15Mz2xa5Q4H19pN6+4341HyyTBVvuY2Ou1GLbrM9H59NLyE3+YpXEppS9QkJ0U0xK9Mhpri4KXR+2B5Ne4wzrmktWqA6U6g3Ms8V5yH9ralGAuOYvjxnAO/MNmpwEEwdvCM5x122XMObLWEs/1aWhm17TRHgQTfzUBiZBnywpB/1qI5acXvXpu+/u8/lV545JW9dCFk6s+9Bn49NdA7Dr+e/dq3ahxpYLJ9WOillS/4O8JrsZgcmeS4q+qBWczTJNqhGNZCbpcr5ywaPoISV8AqGSUT0pzhKbZNKd44AgzZ+NMXod1w9jzuif2ZGGZeGyaTeuBFTvIRKw1HBcwyWuMtN+MseHkpirAJ+wFbcSBQT/wXPiXlKM3JcZtcSmdecHbaun17BXnlSQx4GfcemxAy6hV3tyjVKw1KU2MxPqP+Fl+MSzvEk1grCXIagGm1oYbVrTnyuKPToUcc1jgNg/RW40tXrktkqAqxl0qIkm+Zw/BZcxYIcohqGuDFYXAsTuFc+LjzbOMM5JxFXS5Rct9GHo5mnNjD8htXBh03+y0UfbK9jeEyIR0/NVanVOaGYqsdgQd9jL6gfdSchWhv4cUVQBCvSDvIT4EfshVoOyW5BJVTIKNY1FwBSocuQmj/PWjJ38qI7biL2+2RePTxvsnPyNyT80B96M31bdWUPtO4ot74jeUFrXCzzYV2ZvsSdFbG9Wcx6YApV9VtNwZOvfy89OQDj6QX/sMXvdb+1GvgjayB3nF4I/d+3/YDooGdO+1O15C9Qcb23RNiwouqmfRiJYGJShNeiVtmncBMeEFu5wAy3RH83OA5aPTJypmQxZu7u3MnTjMIQZMtpZmnTa7+hWgrBWLZXGa1kmlCpJFNYMkFipeqoKFp6yNjpcfstaxHTrZvElR43aTkA17XQ/6o445JR7zpiHTvXb/oyEjp3gPtwlBvDPuhstogAx8HoX4FK4aLnAbSxZAp9cFv0CHnoXYcVI8cBpUVbpFaYg8TH3rUEcF3gMZqPakPpNe2owC/KOH8bXMWPmtOw1htGW0QxghyQ86SjGgFrSBE3kxot45ViuNRcOU0RGmBl/qKoQ/OA5ufb9EXxyFo9XBxyJVhlWxFClpd10dJO18b9c4vE9cyy1Fw6qpdHVaV01DXY9elVdmuNSqpWeVqx13EtY9e2mGQXgODsenOQUbhOpaDBUZT7uiZO9cQ15fB4ncwaPxaNSD0wccZ+KoD5DzXEB98Myqrb6cJChd+2/g15IjfOYQJudQPM+bPTmdfd2n6+d9/L61/cS3s+tBr4A2rgd5xeMN2fd/wA6WBHXbne5KtOmy1D8BNmhFvLaLumPokhU1bHSvOJ0eHMTHKwYipTO8vD2omur2FsXH4dsNUc2yQyI1amzQ9MEH7HxO0TcWW1x26mNJdKp+8wXslISZ6YUITbavhpB/Z+nw6whyHbqjrwTgYK4B3yRVvS/fd/UuXeyy8PcFpb+08ePvzdiUcBA7KlZaBTZ4gx0Ex9ATi+pDToHh3XnnYqbh6nsEZVKcp9sD90Sctsw+/LbIWF32001GnyNrDrKZx4dKNK29Nn3kutiVJdtEyRhTGXGXoWLi1U+Bm3R6cBvFWXOqwq6VUreJRcTE6a+Q6XQzb0EOUtdPtK7OupMhjOm2zdTR6vmjUtEVfjxJchIqjhhg1Rb663ki38UeXj2cIWhksP2PVNZ5R9uQ88NsgPY1ubTAQjmJqjd8Ke4rBnAe9rnWndSAuBoGUb2KyvhriOrUxutO2OvGotK6BJUcflk698rz0o//yDafpT70G3qga6B2HN2rP9+0+YBpg4lnz7PM+NZVKYzqLvE+bMa/6nGVl/DMPVgGKNqjkdJfNcUYjGuVAoMs0096TPzJBmzSiwljAz2c3eEnb9GtC7bbN5jHdxjalMIhDloAXuSKf5XY+Jgk8CkrTwpDdJm4zmOuAYaGwN2cBPMe2Ci65+vL0yf/8Cf+QmOj3JZZBTzxsq0Y4C1ppGOQ00N8yNhSr3sZhQEr7F2/gShNTBwfp0K84tONZ9gD4hZdfEo5I1pPa73FGbxu5pcTlyTjfNYeBh5zvtoee24GeiVAbzjGmMtwi6sAErMOrcRrc6K6+IVJoa56x2lDXHZtPSq11WyVvGJviozhovF5L6goohin9KL5Wr6czpwau8sGxnIbi0AQeMopFLW/hovoK5Fclpau36FGSM+7UasEifuXOA7858bD04FUHq8F/OFVP/NbEdUj9SMcrWpEkftPoG+pntWHibnshwYRh++2NazjkQsYJadqMmemcd12Sbv3s9/rvOqCSPrxhNdA7Dm/Yru8bfqA0wFd91z23Ko3MiNexMmkxIUVggos0KXch3JIpcLK8l7wY26I1oGgBlbmSgrFDYZ2GzDKaba9hrQPGOex4DSyGpZmwDmGZf6c5Dfw5DsZuRRhGvZW6eIHTFBfhnbfo6pY4rgEo++q6O9KKWac6KPg2nFqJkDRrweqo+Z1xzpnphJOWp3tuvzNt3Q8fcMKI326rRxghpGungTTw+kDQMFiKyHIC3GBHf9kxcD1XjkINL9SjU2dceFZaah9+4xsIzrNCaRukoRk/d/QEjFWGzz13a6bWQApjus2nqiAnY7gWmgCbcecGnPDRT907due4WOWOtLtyGrrOQKDKabD+rqpTuhjnVWFzUQSNjFnRUHGkRaNYcu/fWPUrDu6lTmQpOUoj11HV/hXqdeLGddxuJxUxBtotBErg6vXfv8ju4bwn58H4mBJ5wJm6GxmsWlYaCKwyxBuUoj5WUbVdiW2j/ryDy8JvWBlzXOPL3/rmtHT5m9Ljdz3k125w7M+9Bt5YGugdhzdWf/etPQga2LljZ5o2f07aZB+Am9Z8AA5BmMligvNcZElGSZU3M8zuhNk0aJMcBlIY0wVBb4ppm2bOavSpQuJtStNtq5Im89r0pg6cByZfGaXEwDkr1DTwGWtFIShEV4SItpS8+N64/o50yazTlfW4rsspOkawkIX39muuTM89uzI9/fiTKnpNseuBOu2Qk1A7EIJRSdtpqPrKaAm1c6C0YkfYy2newvn2NqU3pyVHHhb9QxWtEPV09RTQQHzcVhi++ext6e6NT+U76i0G1s/dUCqRMYv5VYdwCETJyLXx03EaanzS9TMCjKFi2IfhVtehu/jQjXY+gEborjaEEVvLKt7t1YYiOVcnQTTBIbiXs2SPdgq30/8GHl1/4aGywTWAV/gWqteQomGvluU+0HC1j27TXhjlYn4XijNIX4ShP1arS11cnzgPUbfgai4vfMA54GBcej35Fa2MVs8DB89i1RruRkpnX39pWrdqbVr91PNjidLDew38Wmugdxx+rbu3b9x40cD2HdvT9k1bU8qOQ9xZK+YQk2v90S5mdYcB90Zw74tJTHkH2onpUBNx8MPo4p3lYZCDIUrRRAzlbHsF63DeplScAiZeeEZMrdyRgx9/koA8e7jBCxktCYaByBcY8BKoF4OPiZmAgbfLLcXIO7A6RZ0BcMO9KquTNR5wcM+/5ML08x/ftt8cB9XncmT5MfblJMhxUCx8ydONxYf41YSh4SF3GK760Lu8X6L+wsNTxlMQxdShcfG9536avjBqlQFMemh0YDx6NzVFo/G6hrw7kQ1+JEbjtE1LGfw+cq0Kyf7/s/emYZod13lYTfdsmMFg3xcCXEAQJCXSpiiaEkmRkhiLkiwxkSPFshNF0eMkP5zlUZ7kl38ojxP/iJ0njuVEUeJYibVYiihRCxeR5gICIEiCBAiQIAGQWAYYrIOZAQYYzGC27pz3vPXec+797tfTPd2Dmf66qvu7t+rUOadOnbr3q/d8dZel2gfApG3ZpsijTiX1IfSpJvevr08yg66sqIjzQW3ql/WsN2y0cz9MWlEby2Y+Hf2nI2MGqd9928aPMxyx7ptajWN1PHiIVQc7+TrVQ/6uwvTgFNPjWUH388ACBojj2xXfklhdxRixzO9OBBrzxgMO9OXNH3hnefCOe1vgACe2tCE9gHOkpeaB5oEz7IHH732obN22rd8K5jufkABYagEkRxMA5QAaDCAkCK7TT1VXVbLFAoYLNm13EJ91YvLGpEowixncyrCzgltMqv6LntVEcMDggSyUkU6UyMct9AccFJf2qKOBnzr4rc4OvynblKM2J1C6P9Tnj6l5yzvebvcAfKDsuuiCLLamebSJ4AEf3Jegdy3gsqZjx4755U3I46NHq2q/khWGbPSuiy4sf/s//btlm72VnLiJfe/8BJtMQJ7GeOoDPV989q7y8ed0aRIBLfUbPDK/aWJAXp84RjE++ERCMBABAaTx2620kK/PU2k9nqwj68/nQNAFriNoyPZIP/aS0T5oOMcm721gn6mBW/G4ZFIzbbUhywr4xj7Xhq973vIDnQ3B/6eVhifLaSk5k0LjBuJ89lR3DvCTGV29HdF+jOOcr/Uok7+eD1VRPhd4VvBsQDV+FMFqLs4QbL3sOWjlJwf2193yhvKGH36ra26b5oGN6IHed9VGdEDrc/PAa+GBg089X47ai7qU9KsaMAF+Y8MKAeIFBxd2VhIM5V89AcOMQTwdGJLGle+32DXl588jmEEggMmXf9DEXEymAuQGja0OEyynYvAtlbzWdA9Tf3VlWBvlL71470QLstP3sLt+IAUfdh9IWvndH/iR8t4fe18ofQ1yPZuyfSl/umZs2bql/NCP/Y3yA+/5a/5m2y5YQP/Th6PHgEH2PGZvfP4v7/vfLGj4unEiSGCg4Dea1rwfD5435/lxpr0Va8LTZhQIRMDASqwy+EqD7TPgliz2ANz4YKyYzA5FAt4meFDTMRhv5KPNoImXdaLrvGIrag8TH48T8aGs/HAP2ZVNlVwBquez1NU2oQ2JtqhysFeRrOt+i2+L8TT53dDjO0V1j7cWoi2eDSwzj/NA5wUGAHkEj0a2bzYr1fMz8+k7TnscCm98z9vK9W9/w1jzjdY8MPMeWNm34cy7o3WweeDMeGCbPTbz8XseSMqxBI/kIYTvvWgbBBFKCBaixAku6gJcQZcHFuI3IZbFPbm/2IKGAGBRr0kTjyv0MKFOpgwZZA0AO2Q4EVOakzPymrzFzXpwu9CgXXJRnzixJy9ken9pcoerep/KCUDg/TDeG970+vLzf+8XypXXXp2Vr9v8FddeVX7s5z5crr7xevezvI69QJH6LyAEX9669xvlf3nkz0b6nUcp5/usOFb0mbxngSsMAsxZUjKZ1s9Drx3LfgCwfWF4Htcc45AJG1GfTpdgsZzqsFdQ4dnujLIneJFgQUroTFmv7eIZaAk2D3yq+Cl3tIE2hS2hLPcht0fFwXfKhnjKrFjslHrXgEHfCZOqstGsxfneJcvieF5JEv/kd0po8R9AjMHPlfp94d8zRoOczh3kXV8y4cobry1v/tF3hLKWax7YQB7Q99kG6nLravPAa++BEwsny/7dfCNyd9JVFKKyBwnACDZB4XKlIfCPiTfNYMvsSoQf0GuXZ1jb523C/Q1qnZMjJk6fSL2JaAc0nzxtyzwazvVhCPlYHucI3rGcQBT6/6mXv+UsMYmbheaj7mM26A/tKlhwfrfPfvW2Jw594Kd+onz4ox8pO3buGGty3dCw2vC+n/7x8qGP/lSZs/scOBYcG/VfvuL4YAQQNNxd/txWGQTitVfHUVZinseF+HI9+VDPj6+F2c+2k8EExin0Qg4SurwHZYDoAMrkpQjyLFOH9AR/nB/Bm+0cth3HFY8fb35iE+2gqnrBuZinQO4D6LmtHIR0MUpkqKBuqVNt5qoxWq6fkj9NsSna1pyM77D4HltaPc7rnPrfK6qrq58O9kVjG+Tv06APFJ03KPMHEfJh9Y5/WFv1M8rL4Mv27Lrs4nLL+/oPbgBPS80DG8ED+btwI/S39bF54Kx44OD+F8orB16ydyBo2iSU77Y24WPOd9CBTD0zHexYGUUCNFSuPgFgXbIZIJqXKXFa5OSJCRKTKeCo/+EGQvzsZglbZvM0yprKgkIkI6rHQWSur6FO3D0m0r508L4IFKz7kOv+oL9+crBArmqv6dy8ZXP5uV/+hfKeD76PPu61sz4KeHrT+z7y4+WX/sGvlE2b+fQXWK5AAfvoMb0Lyr987BMWNNwN1omkwAAV/TyeKDM81ngU4kjU5Ui6JCkrlp6hPC9NylNOBAEKEiJo4DGfATl4FGQgaFDwqLajzi10MltTP7CPfF5t0DE60WWxm6QCDyhetHNiuUk9zn3L/YJe8Qx19oKQYeU6Lk96j+f6SrrEI5wS0jemBeeFgggPBaxMGgIIk+zKopMf+hVUqC3t8XCCK9/0unK1fVpqHthoHpj2fbXR/ND62zxwxj1w6IUXy0vP7J9oB9hEv54ikGAwAYhjQMnqVIYgcQzpKEFOgAS81FMlEuiBbE6Xbj6vynGq1YSLJ4hwkvUp1UE5nm0OGj/QggmW2sgrzdKisu0nkFjUCRQB+C+VPvPSt7pAAe35pA877UNRyPMTOeAB8mp/09tuLr9oNxS/7V3r7xIDf4b8u95ePvJ3P1ouvcreEp36pr77uHSeKGXPK8+U/+b+3y7ftUeuEujjeOFRon34PU8FkQ8+O7LqvQvYT0u492GYQMm/0KOewYU461HtOx7b1JIPYKPX4mQLfT0oDcG4QD9kkVfQoDOq3x4bYnu1JptiOtQf6otKHdOwQee02hC4RR3GiprBp8S+i3+JU0cC63rf9we6Mnlc2RnMPk5WnWbfoUjKuMfWv1eMjlWzOLfSvV92vvl3nX/hIL9QduzaWW56z9tP044m1jywfj0Q31nrtw/N8uaBdeGBpx/eU44e6t8gzV9lCfT9hlPrCS4j4qVKBB+rOUkDvACOEOCgnZ2LWwpujgYVkzMDAE6qmBtx8zKW6rH3idQn21h5oMPBj0kXPJ51PQIETvIKUciDLduLMnIKgJDvA71N5XY8Ycl0hS3Qbh9M9MxxLx7bo4382WJPIPqRD72//Nqv/2fl8quvLPP2Fuj1ki658rLyt371F8s7P/DDdkM0YG/0OnJGxhDb5za7NOmfPfYXE90DMNIqgYIJgF3kESTgT3TkxQ/atJRXGIaXK02uMjBoCF0Eyxp7HesYfx0D4FXQoA6yjp1FnVY3IB+/5rNevNKNl8spsV2Wcl71eS/5TFsyH814X3Quyh7KJiYQBsUl9W+QSp7h1lk7BIffG12d1fhPHTj/q1/wrcNvHlImv4UmHajvC0hQI7bQSR3SDcnz7NHaN737bZNKGqV5YMY9sOLvwhn3R+te88AZ88Aj3/xOOXEc74BWIpQHYAGo0K+VwA4AQgRA3KsOkqvFFtB16ZadbgSAuAIKTIqYIBfwojmbLv3LYY5UZybFJ1KfxUnsbXuTs4P3qNbkG5R+Lk/Kw17uPvqsMctC5eoeYKF+NPEPAQZaAqid2zpfPvAzHy6/8l///fKmW97cN+AcLM3Nz5c33HJT+Qf/+L8rP/Mf/ntlx/m8R0Oj4j7DAVE/8APuZ/jL5+/2Y0iAejldg38y8M/5oXwOFibqYE59alKukwxpNBjHmIC0JiMd95LNfQh+1WKfzwjmQxf5ohy8EWBkHVmeUpLVsb2S1QYFC9JBa7SyAD+Rgj5EcBQ05TbOvv8tMNbvsXN7jA808eK8wLcFv9nwTcTvDH5f2Nbqsdrqf3YegJ7/VM7tbDlvW7nura8vF11xSSa3fPPAzHsAP139xsz3snWweeAc8MDCyYVy/VvfVK55yw1lzq65Z4rpiROblQ1M+C/9PnWBCzzcO0iyepSBOTrY7wBEIQBXEVzEeZTj/hK7TOnizdttZYNwBto5gdZreu36bVzbe9L2/mcT6onK4ROvT7DUxemY1qkV0qyE4MeJ/XqQnFLJuTby6BkTaPtOvFLsjQXl+m1XOJFAgPWc1KtOkrqtg19ThPdQYFkE9s/ZzdLX3HB9ufCSi8qeRx4vL+ybvHysU3CWM298+83ll/6LXynv+9mfKFvye0DQH++Xecf+BWxue/6b5ZMWOOTEFQUGpsjDnwDj2K8kQUa6psk5qDa+fqKxmeyAuvYBHRGwzmBe7UGXB9bGxyADFLbRDypYT119XnBDty5R8n5AjSf0K/JogyC+Ers6HNKytFoQgu6bTkul44yEPqqQTaAiqd1a8h3zXpt0O/sMbnAM4hO9Vif7FHlMjF25squs70OMr5KCN9LI2W2NDZzObTIYXfDzeOvW4Ox48LU4Y6ySLjdnj9h+tTz90OPlWVtNbql5YKN4oAUOG2WkWz/PCQ+ct/O88la73GTbjm0dCMKkpQmUYI4AN/9K1g8vFEgYEKm9CpgdujgZYlIMPlymdKE9hvVSvzE6XOLBgwcK1jYAdg0a/ObASjeytQeIisQcgDjouYySJ6sQr0jaky7bUHJrHcCpjpM0bQfoe+PWy7vAYaXBAtrt9Fp+x/k7y1ve+bZy6RWXlW/ddU85+urRgsDuXEoIGv7Of/WflB/96Q+V8y+0F9jBRfZZwGVD9h8jYfczHH62/MXTt5c7X/y+jTCPhtzf3C+BKgfPAELL/GQdOc/VBerJdAF/U+/j2nUAnUBfaocA1jwgAGNKshMkP4a7amYE7iEPCo4RwvrK6DvSGHCo3vi7tsjLIvMMqJl3fcyaDLXDHuRykBP6CDxhkACr7IScG+q9YUHtRjtsLOtzuRnfVBenXo5RKs12OLZxTOTEMr5zbJy78QWHOG1vdEh1Wy+jZH8+vjhGkNfHeE0AdR5Q2F68aAn3Hr341N7y4Jfvy6a0fPPATHugBQ4zPbytc+eaBw7tP1g+8EsfKdsu2hmTn0+EFZLbZUL69RiTIwCPAKCXjeZQGrOfpVxHCmmkVyarwGQHGvav33pR2WoTHkpIao8t270Ni/FMJQQvXHcAYEUOidqxZc6Jns9l8koiagR4qUnBBUq0JzhJQRmfR4/utVWHUq7bdrltI2lVAeJ5ZQEcWVdIgG419n/19VeXG99yUzl+7EQ5uP9AOfLK4cx2VvJXmk0/+e//TPnP/9Gvl3f/xI8UvANkLFiQcXfs/Wb5Awsanj9+iCQinQ78IJCY5gfpWOl+WrDAEcM4AnhlrSzQNNajNgB4Zu4DP0A1An9IkI/AsOr0+siDaxgo4L4hB+fQkAwjQIQEEtrl3ovDbJbzumpLL280km1Hu1kUUXb066i68pi+bCPUz3qKnueeTlLhU0+26/JVJMo1Z04FNz9VDrx1HDuKZXCM4b+uK1hAgHEyeePFsYYVB1C08qDx2bp9ezly8FD55qfvLAsnTlZL2q55YLY90AKH2R7f1rtzzAN4e/Sbf+jt5bI3Xls22fXrTAJ2nMocWFs2bkwmECL4Ay8nRIAj5EB3SZ8QY+0h6GqllAvmttpjWM+zG6PneV+ASaM9wHtoXrCgAWVcmuQ5CxxOMuf26HIfaIR+WY6ypk2381SrDc4EKephjttU5f1iO+zjI8f2lg9e8HYDhkZFp+3D4Cb0ZPm+XrPW7QqOzfZehGted315+7vfUXbaU1L2PvVcedEenXu20s4LdpWf/dW/XX7ql3+u3HDzGw3JYHxpb1jNPsPGO/bdW/5q/70OcFjvR0LffDsuCJC5h6f462qV8F9as3aKA0QZo239N1zPS0+/AZQ4GADeOAz9UNQA2T7TFLJCQgBf+rhKwZIDN5MNHkjAJdx73jZaaSBV/KjF2RH1oIA3pGmXbEc9/YKc+qC8wg6AS+phTZ/RtVsDDkStKgciWqEY2hT9oWUCpa4fwxIGO2kWN9O72e98N3pGpkzUd3V13HHQoVZHNku2rfRchk95vHPsGCZ4qOB08PpDK2zv42WKQcO5+fILL5Unv/NIefHpfbM4NK1PzQMTHmiBw4RLGqF54Mx6YOfFF5Sb3/OOMm+XKylxgiNE5EQHkMvVAEx9APOs1UQoLuIKlPARptKk6DQ0Uie68+e3lis27/TJE2Qk6GXwsFBOmIA/TclofIY5AgjjMTq4tH4AfiQEN2wZtvYTOcJu1EoO+jpbLQNe+AAJ9C78sbxAGAOlYkHPpnLd1su8PcixHRed2ChQkO8yg2jz9k6EXRfuKu947w+V1930+nL86DFfecD+5GvwKyIud3j9W28qH/47f6v8t7/535cPfPTD5ZKrLrfAMsAq7EZflJD/8v77yl/ti0skCOrlO3hTHpUU9wKm5CeP8nnfiWNAxlW5QgApZ+nxAHRZgqjTsak0yzmI9goJ4f4DMEOIY+4Bg6prRQbiAvDhpX7QwHo8erVTkoIO2szWWJ9102bWYiufqU3ViI6yH6e1KQeVlmdRRPWfFaoL/1Br1plMV5Mzu69eGvRvksrvNmOzKn5vBA/rKoc5VjXYd3WV3i9j9BhQw//8SYdBAo4Lfup6hORtj3TSViufvPfh8tRDu73cNs0Ds+4B3aE56/1s/WseOGc88MAd95TDdknM9kt3OfjF9ENQbDnLzNmv6Sd9bxOY7Rfto1+7HMTbBEeQjqlP8BfAReDdNY7296JN2yuQYzWBvE2/BkQxCWuLHF76JrC6iCctOW71jQvnQEEBgRplXeZQDfeYc8Pyft30EoDhYvncS/eX9+y6ZZTNdaI7NHaCR3R2RSWymZvLuz/43vL6W95Uvvnlr5c7/+rWct9X7ylP794zoWe1BAQL59lbrC+75spy0zvfUn74J99f3mbB5NWvs5WoCkjQhvw/zP/ek58t37P7Gpgw3kjoFY8fL/pmUwruph8XwT8tpzb4DgT4ajxFBXlYDnBvVqb+0V5q0pGlQJHU0Be/zEdgQb3B42jSBAXwCQDZZthg500nwgxtDY7cN61CSGeu6+WrTtmvPXhyn9GWWmKwElry2Af1LOV4OJ2lxlfTLH7gMJCP7y8baAwLv4nwyGEbC+vXgh8A9lZ5r0Vb6KytwiJrW3vwtB0j+kGF8q6jjnEnZtxX3nht2bwdF1G21DywMTzQAoeNMc6tl+eQB559dE956oFHygXXXFrm/F0CmNw4wfF3r3mbwmzys4nLf821OtBP2mQHqMt3PBB6nKyAHqUheI8uQ/di2TI3X7bP45S3kgcK0IY/TJX2hxkV7Vpe70yADp8+rQoTJydWUJGixImZVJ+Za3Z0F2KD6qhgfwbVXsTMvVj+cP+t5T+49INO8R6YKHvipN5GdNfu/Y7qPgA2f9vqw2XXXFF+8hc+Ut7zkz9aHrz3u+XffuwT5Tt3fas898RT5ZVDr/gNkQvdG8BD16lyCBbgY4DDXRdd4CsL7/2pD5R3vO/dBZcoIfm4+DhQG8ek5q3rTx7eW/7vPZ/xscA4Ov6xntuhYrSMatBb+ir/kg4aVolA42pRPw+grUvOhqCWVuRRF0XtmvbI+jErjgycRcMe7fm42J5HNIJD1CB1GT8PSAMfecQPOmXIDzrKChpQT17k+jaizH4GR+4D6qelDPJzUAN+tC/r1R/Zm1qqqsm53Han2bPmdHVgzRWPK8R3SPhmnGc11BzISY++OxhILNgPNfXRAqnvfg7iBLMjFd+N+C6N0UV2sVx0+cXlPHvgwhH7fmipeWDWPdACh1kf4da/c9IDWHV43btuKbsuu7jah+AAExNDCGwxiaIMULJod/0C4GDawg3AApQ+v3nZc5TxMiZhTnAMKDaVnXOby3b75AQpAWuEDB4cmBjADvIduLQ8nnOOpAAFc6lkvcI25FCJ9Wwj5KI2cugj2vNVDusjJuM5MwJtOfAaKH7k1efLnbby8Dd2vTWU1Fy2ycVSsCAQR9ZQOuSz6KDsuvii8u4P/Uh5q93/8Nh3v1++9bV7ylOPPlG+9ZV7yrEjr9pjXF8oL7940G9ePmplJLx3YdGCCo3PhZdebE/Qspub7ZInrDC88wPvLn/jb76/vPdvftCCFEJb8IofOnp5OK+mO+3SpM/u/7ZjFn+9htHhMxDQLwIayJPmVfBll9hfBQTao1p5cIyDN+kBh/Lk7fs06qAXqV8PCo9lr8MGZd9n3tAj28ACPugTP2jSn2nxS7Jp7yHy0Bv9CMnMqpUGtMF2syyoTAKk1EIe0cgRcrBVpdyvIV9VfQZ3/XE8gw2tUvWknTi/8f3oXza2w3dE399LN5nHWJz8zuAZ5N85+N7BeekBA5uCJaQhYx+v4/fWdbe8oSz03tEjzW3fPDB7HuijiNnrX+tR88A56YEHb7u7/NDP/7gHDgAcDthtRusFD4YyAF7mbZLC6gMepVrqCgOmTsxenayVlEeHMTniEicFD5jwts3hbdH5d1i2y3sZMFFCElMof1kDAZOo22Z7Jk7SJ5yLFPBMJkJa0Hu1vcKkFCjsmepYwi/WuPRAfkKA8cWXH7AnLF3h9zvAZiWf3FWwvYAlSYkPdey0V0UNwQj57Q2x9tK1W979g+VNP/iW8vLBl8rWbVsseLjbbqJ+sbzw/IHy8LcftLdQ2+iYb595fE85/6Jd5Sq75Gi7BQp4Osvl115V3vyOW8qb//rbpdLbVdvaqzLbq359xQIGDxqciYECPKsAAmStOBAYRW8q9jEOghxXscJNHFs4JkOYx2GUwac0vspg45jkBfiiz1FJPpapl/1WHu1QLmSG5WHQELZXvX5jOC2OOvWA+9wn1Uiv10XzXp31wJ6Qx/mIlAWYlz6vfk022YbXpMHXpBGcLx5U2Nmgy5V0wCrAwPk29De9wXMGW3zP4JsS37vgj28zdINljSt+4Hi9/Qh09OhRVLbUPDDzHmiBw8wPcevgueiBPfYUjodu/2a54a/dbDMUpihMd5iycGMeJibc14AcYD3AB2qNxyYpABNwAzTy/c4nrYTpDAnghPKiYII7YQy7Nm21GuMio8kig4nRtpWMen+kqb3ToLL5xAnNEowaUnvbbpJFq/3pNvO5HZmwzPxQ6+/u+1L5e5e9v1y75bLOXqgigJRS9QT97LccNbA2SkMwj75vsYDhkisuda73/tSHXPnhlw+VHRecX1468GI5ZHm8F+KkrTiAvnnbVr8kqbMCTq4p6+/bipaCb8/h58qdB+4v3zvynEnGKFONAgirMd0CMqhTEIE8fzWlLLYIJNRmzsM8gd5Mdx2QQ8ZT5HKb4JBecWo/vJQHvJDt8ye9nmWZfJGXJZQVGKeupVYa1DfJ5wBGdmqfVxuGAVAfdE7aJf3UxXrQon07n0VWg+t6j+P13O8Qvo3ieKXNHa07+I2yyKMI34NzYKhd40WcQw2ot7Hdsqlcc/MN/jI4o7TUPDDTHgBi+Y2Z7mHrXPPAOeoBvGjq6ptvLBddTdCrqZdTGrYIAGwPxGETmy4bAh0JAJMyNplVYQQUlDcGTGiVvn3TZnsM6w5bddhsNPDoj4AZk+IJBCl42RvaMuSopypBRdyUHW2HHcrBKuUx4/YTJfu0XEI7Amlutm0k4+XaSacZgbRSDp08XN563g0EoSB6heyEUvSVuqTPip7g364O4KGXohy5ylDbmbdgAgq2nLfNXtK2yy8/2mxvBccqxVYLHHKaCBY6W6EiWhDfV/ffX/5s79fsrdl8PwPGkmOXBNUAKznmRhMH9zgq0Eal+kGBvKWU92zH45Vg8A8CVx5bBOpVE8eraxsyOSEIxjFY26pV1GX2dGRpI6Amf7QDGwC0xe7HSC1oxQKq8QABpX6bsKGr8QyBO0GgzO840iqEc4QwgWct5zr3jbVBvWwMdrIFaJYNrKMK5blX++tvv3b24ywY1zZJhc/F7PnquMjD51HScaexYA22OL6ihHc1IEEWdKz04jjGnWf5PQ7gAg/O3cP2LoenH9pt967thmhLzQMz7YH4XpvpbrbONQ+cex548oFHy3c++xU3rE5VPhE52LLJClMZJi3P2WSGQIMTodVgzsQmJRV1UmuPiRKT2/l2qRKSgCmhKoIT/okfv1ATQxP8Y0sZSrDsqjywIReAqZIoKg9+zU+cwUFp2QCbkTIQY/8ExqxPtfuPHt1XPrbvduOGDvQU9iPQqvuuxjKWECzoAz59JK89tbHk5qA9+0D/SQuw8PF2rKwkXdgj5TLs7T6uBZrqX7ID/v/KC98un3/xfufH+OOjBJ/wI5r25ABg7X/YLvwH/8aHvmSZbYzXhd2oz7plU+xhCwMG2KgxUh+wlw8oE7ZzVYJltOPHrRmtcecxIX7spYv9dRHbwL5Ikgel6vYdWwi+8Vxf10B3bUdjI5uhKcshn03iMT3eXqOu0AP11MP5rIQziok/gkRJOXHGnjX5uIk6fJvxg21oz4O645ILyo7LLwyhlmsemGEPLO/bc4Yd0LrWPHC2PHBw34Fy5x98uhw/zBtrYYdBDA8I/NcuwEUEDLZHMAGAgsezYu/hhKERBhYAgziVIa2kHEHLxXPn1YueWK+J9mSdS3E/BFYY8HGwa3tc7kIAPH3CVWtj+zTFsnrFatSHMe2gRf2jx/eVP95/+2iwoCBB+wzmAQT0iRwprt6a0HXOChbkO1mV9U3kTV5AGf7QH2R7vAjWPGC4v/zjh/+/8oUD3zUO9k/yBKgcf7UNsE0gCl7yqy72qiPABpDlB7ZFHvK5HPm+fOhFLtqULTlgQD3sVh+wp4x0DoMgBjayD9y5DcnjaBdQx7I5Pkg8b5iHnHWvJmboq5j2oh6yZql9kEJ/FbddDtQ5FrIBdeDrGnOhaMWLg3ryZp3i2lj7FX8pjLpH44HK/C04HAOeu3auWbP8eaOe9UbI3w/9RvTNwB8d/IeV7nuDnOft2uGZLdvj3Tx9Ha3UPDA7HhieV7PTs9aT5oFz3AMAjvufe7588y9uK8dS8ACzASsAcjAhEpBxD2CDPwQSdtGRgxnSwAvgQxonUoA2XMIxV7baJUqbKyiCfiSAWN/i127k7R+XQ/HXNVCwEsEyeSGFBLm1TJP6JikEWgSOAdiyFb7ysP/L5alj+zoQIJCfQTrtRwvsFXNVE5qxTw4WICs9ai/ry3nUZ5CMFro/+Dl/arBAIFLKXQe+U2594bs+3mqHR0L0XUDXjwsYWpMfK1aMX+1RF/Xi6+9zPcF91Oe6oDIn3Tgm2SbbDT7Zh+NPY5b7Is6wF2OK45XBC+T46Qcd5KE0ggsFDKD0QfjKggZqjK2CJlGybtiAf98j40l79LefRz+UGLhEvehtHx4goI8yc5PfCEOOlZTTELlYaLfjzSjd+V6NyfV22lLG9yzgvL7AnqC2uKCHGZOnbZsHZtED7eboWRzV1qd144GTJ0+Wr3/ii+W6d95UrnnL6x2o4xczAIwFe6Y43ucAlOLBAoCmoTAHNXbnHoMEqwUYNS4ClDmTwLoBy1g1QP1Fm3G9PeRtlxIkSbIgwZ/YZFfCD5kqf39C1y90rHQdJtfnSQ2tIAswiYmbZsAXptcbgB8sb/W6GRg3MGoiR/93H33eP7906Y+Ua3DDdIfRouORq0ZVHrQJXQINQz6AA6VevmuDtfIoSpnP/Z94pe1rFizc5isMotjYVWSDy62Y0Hfapj7BVoJXcshugtMq1gHbyiN1ddQdAY/kEZhmCNTXKd39fbZFNgYHO+7HqGfDETxuAbjJzXLUkxpl8iloAN3GrYcEcW6oZWZov1qyXnf1VXtaaQClc5Pls24FDZSizaF1sg9Rpwa17+uVvo2xh3flB+1X3nOcZzbSLohjX8dfn27nCM6h4YAPmptqhQ1g73zuHRlQQsnFE4vlshuuLifsLdItNQ/Mugfie23We9r61zxwjnrgwS9/szxw2zfcOp6QAIkAzASQfpmSTXz4w+qBX7qEvQUWzue8yGn6o6wmtfM28QZelTkR2raCUt7hYBOklQHKCEAVAgQfptB+Unt9Kkpsg3QB2iGdtZNbtZxrMnCVj1jPX6SVBz5AH/5o/53lrlceMjJspjXMWRFm14/fBL6M+xXcN/CPPrUdtAXtvT/xuD+txhA+P7IGPra81X/dAobbLXBwPWb88AsZAUQXRJhMZ7h1gDKmB32x1B0L6ThgTWx5TPG4ou7xPHQGb8gzVxu0Qm6zbw948ge8ldTZR3nwIRhGvfo/1KU6/pqvoAEKTRqD3iU7C7oiM7zZVZrB3zF7RpcniZpXDLJu9FWme14CIlJb14doh+djPoajrlOygTKDATgLPbdTzxK/z/xc7GxAMMLjEt9b+bsI5zjqMk1ic1vmyolXj5Wt9s6WlpoHZt0DbcVh1ke49e+c98CrLx8ud/zup8tb3v9D9ki/G23WwvTEQMFzhjIQJGDWOm6/AwO0+EqC7RFU4Bd4PJr1pAFU7BFOIBgAWMU9EXiS0ubB+xs4ZfKlbljFwCQKGsAsEvQL8NeaSgePZ23TZUSw/di0OoU1SU1maRPpOU8KTMYv7pP1wfvllx8sTxx7vvzI+W8pV2271FnRJ8ipb9KgvfqPcs57Gaprok9U6vPC70qRq94y54F29wsPlFsPPlD7ANBMkALQima06iNvKniA80XzA6I2lNtE8wFsk9HGi37z+KFlS+WhmvzI9fWo7IcOqj0NeUjtbLci4Tv42L7kg04ZbqkPdeKbfmkSJMaCBmrSdgjYc9AAvy1mdC+hwZ62WmtmHkdL9qn/DOpYEg1KMiXTBw20oh/j8nO4A8dM+E2+j/opuTToOHdCb+jKkjjD8P232ZqzkUxVGNe+Bh7HZokdoMfse3zeH62dRFq2eWAGPYDv4d+YwX61LjUPrCsPHLL3AOCX0Wvf+oay/YKdbntMa5wiuykMFWkO9YlQzDZJApp2v5sZGrpg0/Zy/mY8UYlMAIP4w35h00l/IzSmyhM2KeLt0Jw40QYuekJTbBlb5S3bu5QlAG1nJVg8TVJUM74Xf/61F7Zj/me/AjLIFegaexd75F60R7Xef2RPedaevLRr/rxyvn2kX63nACHnUe+AFYrtk/s+yWdaOz5pNpkaKKjNu194sPzRc7eXx8weTyYDMWz5h3ZQRAV/hZcsyKDBL/j06Goce6vLReXRDtpAnxAw4M9V1nymq9/g81/gKTyp13Wo0tX5BsGC7BQVx2nowq/wtEBbtUmz2Hdo5goAg2Tqom7phVGwk3KgQsr66LuAib3zBFz18iTnDQHkPOn4g5znTR+1UT/crLbc51ZCPewlH+sjFpEc96htaboHxr3Up/LYMR1G7vJeFB+PFZV8LP34CLofO5D24xFa7OcYy2N1F3X+CFbkMa72AwxoqPda26PlRbuW8oWn95W7/uQLEz84TO9hq2keWJ8eaCsO63PcmtUz5oEFe2nYvZ++vVx7y43l/f/xz3vv8KsXQQcgKycqBySGGPkLM8AjP3wxnE1lDlTBK1i5ycAyTnNNneE4aO1WG6DTqkDz1QrfBy+CDCboAccgYQK1tpdK0D2ZxmjBtZRaTN5oUi+8A/DkL/WY2NEPq3M0ulh2H9tfdu+7s9xoKw/v3nVzuWrLJV0jOQhw9q6G/lAx83lNcql64fsaLEjunhcfLHssUNj96j4PtiBGYIlVHdOEn7otcRdjxzoAGdWRT76PX/Ktr1YFnarrjzfkzFdur/LUZRW9FP0Hs42Yy/imxzdWCHv6tQRmpLHfuZ66++3KP/ANYFwkjHkk5v0YcWLU8fIkclIER1/UD4MGBidJ80g7VRtbclXUJ1mNafRR529uN/LRWsstzwNTfDeF3OnEl0RvPFGj45/nYD7GJIdzKYI+UbnnWRk0rDT42+PnbbXXvstbah6YZQ+0wGGWR7f1bV15YP/Te8vn/o8/Ke/4yPvLrisurpMdpij+4UZpBz82CeJOB0x98zH/2VxoKwQ2ieI3sZPGiyBim727QWCLv34DQBFUwzkIAfgHRfbBJNsla83LpHE6VL32dQruyXUK1iADVKC2AMQIkk+tmACcklWH+W330QPl0aN3uviNWy8pP2xBxJW2V4JvcsrBggC+6sXpe+s/9s9YgPDMkf3O8qQ93QnBAl1DbgcoZgduX0egQLBP5CP9CAKRFPzB7wLwlKGugCcCqFWfNQjAwxvKoYn6kIt8prFmcjvJ0wEpmjACyKglBwsRFKD10JnpkOrLkK8P6EIW/H0sGHWdja5TR0/UK2gQwBfwh07BkipZAABAAElEQVQknS/Iu01VFHnYrAAB9UrSFTbh+OunqOvTW2ncAzi+hz4c5zwdahwPkMbhHBS0bKsORgwauFDqEyWH79CX9x8sOy+6oBx8/gCYW2oemFkPtMBhZoe2dWw9euDZR58on//tj5Uf+7V/t1xy7eU2HWG6wrI5Xjrm05lRDFL6E5CsBpdbODK1Sc3vg8AUhoDA6MaD9Yjtdo+DklYOEBCADxMfQwnbWgFl3t+AWuT7yZvqk7yUuTP4VnsjIlNJAAu5Xa4swDIm1nMSB5AD0Oaqg9lv6Ez3B4Cb9QQg0gkACLt2HztQHrdVCNARRCBdaysSeTUCPrxq22VeBwues8AA/MgrQEDlk1hROIqAgQEB26LNBIxYHYk+YFQVKOC+FPKjT7CZOsCDpAACeTxFqqO7OuqkPOqMvyLUDKDdYjVvOiKooAzlgi5ZX8kYQ7w0LYTRbrUXRPhdCePFRGLUBRN4RMd9OzllIK++53rRZDNHmxzSKX4FDSovJ2ig/bQp5/uyDCrIVe33Xc17gzkvC9p++R7AATziwylk6PXxGjt+vVHq4pg6wTahX2I63z2SqHLpVKKgXdOJdzm8bJecttQ8MOseCEQx6z1t/WseWAcewDL3Nz75pXLh9VeUH//Vj/rEByCP6QzX1CJg4CqDUWxmwwQGuqOuOdyRgGlwwW/sg9yuTfZCoomJFUEDwwWv8w2Y+MEWE2jH4+VVbKhwRMF4RQbBEkL/ZRcmcO+loUIH1VaJS64mgwfSOjloCEWu2sGfAXoEEUjYK/CQHYu2kjNMvRjAKrHCA9VowIG/8t54taAiEQQQ/CWdjzwVP37hZEsEoeoxdKIOaakgAiBZtpNb+lBCpaimJ+WDOkkf8glkwc4cKEBHBunio+5oLHgwNpEEwvsrDGay0Fuw4rCvqcvU/oTG4BEvdEU9cmpTHLkt71unnhnq7IguJo3ol/KooN+CN+tWe21/5j3gx6mdbxhrjAaPW7RbTyijghbHHegsiY6x7Ma+Hlhx7HOM5+wSpS3nbSkLJyHVUvPAbHsgf9fNdk9b75oH1okH9j6yp3zmN3+/PPPIE8liA1o2afmteZgEDQTZVbX2tKR6E1+t06NawbsFHMZnWf+1WysBmBo9bMCEatMmpjr8sowbozntWchgeSbtUaIkcr3pseNFzRlK6ESXcp5EAdLJLzT4ijyY7L3eyvpVHjUAdRnYTQJK+LCvWTqpmVAjQHbYRz6UMw2BAcuAKPyFncECyGiJn5BD/9jHoAWfgA14WK+99ARvAHbR1AeUlVTHPWQoB734wF+yCXs0m2XYX9lC22V/6KK90Ec/sHWNR4wJ9UAn2qlcypwyaIBdGj/ZSP90Krw/KsE+DZfnrUK2iyfLIw+9TJbvbKyUQVmcs7PP3xFnslen78hJyT4l90A1Cta9R84gLv/27I4R1ONb9Pk9z5YdF59/Jh3QdDcPnBMeiO+7c8KcZkTzQPMAPHDgiefKp/7Z75Wnv/+EIXrBdAI2wBS8NRpBwmbb4lGreCs0bgj1wMHo/kQQO7vP88uUOBWatGnG5McJEJMdNCNIcGBk1VhlYGtGqwGBaIoPUFZCjvydlKpclwqYapeTqGWcUxO6avnllamRz8BuKuA0f/TAgRTbHvIArvkLUuBTbAFiQQEnxqCrtQwLwddVVr0okzYMIGQ/tYovg/WgUQdtBT/a0x56MLbcR56AGGXI8TPM92Wog/aot5JFn/v2sE3I9OsgrzoETDlggI4IFiDHhP7oE+2YDUbnTdDQGrzKY48xW6xBn7jQr5xym2NBA9gVQEBO8tRHv1Of9GLPPHWLTi7ToMyM7If9W5tuabxC28r95jrSePd10u4hTa0kMQ1nNaX21xnJvXDspH8PH37hUJjbcs0DM+qBdqnSjA5s69b698A9f36rrRrMlY/8+n9ULn39Nd4hgP95m7f4BmkjdW+XtunP6CcA4x2tAeoYqKlzHITr72TGwcuQXGEHYiJQwESa3xrMWdOuu/d2KbXsrUcbyYhlC44wmgEGda3vqDOdhvph64L1d3jJEjjyW6VRhlsQKMAzHvygTI2odtCqYMkJIxsHounSJYELBVXQDp/7pUuy02wOPqusPu/T0FhcwoTSSfTXFMNu3QdB28nrw4ysJfQLgHYYCOVLm8hZtzDDku8GeQRvfTDlrHVTmTMJPpwgkzDUI9CNgCGnDN5Jp7x8lGloi/Khvc9XuWvAoHbUtsrY53Y9OKj98LzXOxc2nqSDLZu/Kz88mc818U/ucVB0QpPVjbJCDyztTz+W/RzCmT4tRV0cUfxBJK9MYtygAzwhQa3zWzaXV4+8Oq2BRm8emCkP5PNkpjrWOtM8sN49cOzwq3a/w23l87/z8XLilVc7MIdJCwAWv9jq8iV/o3RdecDqA1Yets/xUqWhH3yFAUDTEBiCCbw4biHdLYtLlvoJZQF2rTBUjgnevmRCVoOKyeJSqw3Bnaf/yTyBnOj8RZ2yCC7gN5YEDI3kdOnPQBI0B+MmlL8ohysP4JNe5JHg/wCSaJQNg2/sV2jRc/sAxwQuBOZqA7bAfvaBegXcsdfH2CzJB+Bb6kNe8ITeSX7pHu6zbtpGgAWt8KE+eYUBfdUHfEqkmUY0n2z2fhsNvg3t4pM0ymZBChrAnf0KzmG73mdvj74FD/ponNh4ykEDjwvVBI/4QRm2Se7MK/m2H3oAYzaZxnxntDGyC9s5WJVMZfH6+L7DdxB4+8ewUZwl+PC9mds9efxEee7hJwvudWipeWDWPdCO8lkf4da/de2BIy8dKnf8zp+Xuz7+ufKqBRJKDB58G8GDzWTzhrZw+QbufcBqRZ4w8Su7T3g+C2IS1ERoVGPkJUj+PCasW3h9XJaUNXllJ83SlK2amFK9YjLm64EpAdCpTYBPX24sR0sqd94xfV3e2MYAH4Ci9EETgGkuk4ZtTgwewj4YTuPRB7YZwYwkh6CWYBuX9QQAjz4I5Eh37MEjPuWn7xmcTK+XrtAv+9En+EIfBQnuM+uoggXswUvQDT05hd6gBo/3w4MBeh1b+BCfnFgbFJTRXk7D8fV+VBYdBxBRHrJoH7qoPx8LON+M7vK+qU3lfCW13So9MOXLZEDGt2IvDcYfdUEK3hhfSVudfRE6h22gN44JI6R2X33lcNl2/nnt5mi5ru1n2gPtUqWZHt7WuVnwwFFbAv/M//6HZdPcXHnXz32wbD1/h3cLExnAmD9Lyecxm/owmdnboAFxtjqa8WnP+bXphQ9YxoeIrxwodGAZwQMmSlI5SzKgkKb+nppIi4CjzxOlNOsacSm9IaMcwTYvK2L/+H4H5Hn5krQDDPB5R6Jg8g9L1b9N5qs5M0J2A1wOL1tyIFxXWGAvrp33Fk9x6RKsnsPjcy1xYYd2AoxSHlsl2Wl11QYH2rVdgm+MOQErLynj41sBhvqXKvGJMfSB9Pf3vMSpT6sHkROHsigryX7qiD7IRvFpD29JhrSQCSCHmqATkOdWKQk9OWmFQd6TxOkGDdkGthUNRh+ClvmHgUm2s+VP7QGNXZ8z+7pfkw4Xr8DZPRE8DERQjHZMdz4A7YBGHVrkWEJbtA+a10FJTVt2bCt77ebolpoHNoIHWuCwEUa59XHde2DvI0+Wz/7WH5b5HVvLu3/2Q/6WUgBizHd4PCumSsBe/A7u09ymE75Hx/3SJAfLuPGZ0Io3RuNKfOdwegDsuEFa/MSt9Z4Cl3kNNzBZ87b2I81jslcf4Bf3jxnu9AoMGCDRb+gbQK/Xo4PQ7SiRPnKAYHT6iA1mEC8TAFqHj2ytzRldXGgF6qlNL3kDDW+59r3taD9KyQavZMepT/dC6Fp/q7N/BBF9QG19NzWgYT+aKDqoMmJKtJwEAnEqwwqI2pwWLGQQPTRBPqLmfpuwmTqj9T5/GAiOrNvLI8zZFg/5apNsgQWKhS0KPMTjvvSmyTNcachthIUtdyY84PC9G8MYM6enBqMG53ouiQlHD+gMtHkpXPBh7PGZGNt0jB07fLQc2f+ScbXUPDD7HmiBw+yPcevhDHgAzwd/+oHd5eP/w/9Vtu3cWd7x4ffWXhEEAzk5kLP5Dvv5RXveUgWkufsgATALaCEHMKoyYK2CCcll4KxAQnXcZ45UI6WJdFrZmMN74pjIY1XAmNA5bxMCDBgYUI0HPA4GjZXvgIBqE3ZRrbIYxdpwUkQAHQ1BiHo+Fjz0jK0FghLc+Gzv4zDa2AoEWa1dM4f+Zn9Az8AWbTMQosQkeDdgb6KgY99PcJSI0/IC7wxKQr/koj7rmgBYXcMhlzBXV6sMn5Sk0tJ793tiwZgK7CdyD/SNBQ3DgACyQaMm2KweMGCodPDaZ6k+kbNtl+MBHNd+bi6HOR+6A36e3xqxXAlapkeoARnWUHEONDzY7wY5y5dycN+BsuX87bmRlm8emFkPtMBhZoe2dWwWPXBg9zPlY//wX5TDT+8v7/iZD5Sdl15AIOugGTdF8xGrmP0MVpsLOMERgHLFwTGwVSFoWLACABKiB3ATAmnrhNGN8ybgPMpUidK8FM/p1hGkWgtuEC7fQZ+gzTvlYA6BgXrkgQCZOx5Uw32SgSgAA3yjhHtHhjeNQ9dc8kF3ucySly5RowIIXMIU9qIu2nTgahsGJ9EH2TQGjCKQUjv9vWR1XLAM3Uo5L1oOEIKmAKEP9IbyUe4wV6eCdeyHiF5SYSoYl6/FKKlh0CAbg8/arCYJFLqfnSFs9bGVkAn4MTLgkSKM2LCdTrRlVuwBjWUIxrgEreaWqOofl+PByGRbpHD8Tbn9+9jbwYsxRnMKM3LTW7ZvK0898PiEeY3QPDCLHmiBwyyOauvTTHsAL4j79L/4N+XlAy+VH/7FD5eLrr3c+ouJzSCMPZ4V1/DzV1sA6gREq1eGQL7HE+zdr+kUSxXeWoa4VXHd5VWJYVt9zrUqYQqXfePBAy4BAshHWqgIVpctwV96dCtgA4E6gwfoRRkfAIfsKyN50NbpBcGSQG2+fKk2WVcRyMctb6D2Fsy8uFQJteY961oAFLQvWWRyv0kfAlj0ESCIcrb+kvoAulYscr9BR0LdUB9b6W8nwVeyOLLQ2AmiX0ixijGiJdjJbFv5tiM4zfqXCTU/tD0/WlNBA1hzXn0Pdabb7KB1NKhdnhTeOVs5gXe0n8cv7MH34PJSHGbUCn2Q1fHT11+PgYHq5x63JyrxF4BBTSs2D8yeB5Z7bs1ez1uPmgfWsQee272nfPJ//dflU//k/ykvPfl87QmCB350YqNM8E5oJSCPuxvwC/qiBRv4I1jmlmAS/KJTFgEBOVCjJIrKdR8Mg4ozU4zJn/rjUpI80ec8QL9sAVCA31Bm3mtQNmIGDgITXl83DsydL1MJcjUOqvFAoGtXVOyNE09qqnW0zQ2wOu3dHLeT4yzQFPVZI/ICwuibbKdsgCOUwZfpsFv8Q51RVrshC1vZFm1FOT4hiRUXrrqgpfAS25Vs8COXgwZJhaR4sy2kkRd2sCWNp+wkV2ylG3aDJ7eh8QnuljtrHuCQ9pq3EYsyjulaimMgjylqyYFjAjzxtWV0+2qTBuzxx2NBWql8wR7F+ux3niiH9h+srbVd88Bse6CtOMz2+LbezaoHbIZ79dDhcse/+VR55dCh8tF/+PfLpdddXeY24w4HTYc2EfKn5m5CBMzHxUwCQyiDJ4ICy0NBnUHBNxoauIxV1qSAROWl9zE9L823glogvNpX9h6rLma7N8UOOWh3RK72AZh5gzRbMmiAQMqqCS5roGTicyanlRQBavlWVjr4tgICL/ls7MlL4Ie5Sp3ZTojgoeBGarNFumJUwYg+VPtdDhsrq2sdLWeWrEyM9BcJydDMMU6u/RqvnHbvQs8XqQ1kc7CQqxQQZRr5g9KBPDOny9dqthl2KlDTeQFfhl0GGDvWLmP1kY9WW+50PRC+P10NAzmcDKNj1B+3PI5YlYId4CCdAQM0O93qvQ4Ez9lLN4+fLC8+s6/gXQ4tNQ9sBA+0wGEjjHLr48x64OTJk+XeT3+5HD18pLzvl3+23PJj7yrbL9gxCiB5jT4h/kkDngH2CSgBeD2X8CVA6ygYxYQ8WrFyVwcwXrlslhAAIKAnOMj3POCSJMz1vBla4B58qcPGoOABzH4ZExoxNgQPSKcTQAgAb7L7H4b9FbbBlWb9OoMqaLe26m13ptIWZ3D7UcalRc48ZcNKDBt0ojsaQpTVNnUwCJmuTw3JIJX7TS8nWOhLREk+E4V+gN2TbWnsxev7UT5xhI6+PgRj8nnwUCrKo+1Jdduv2AMa20nB8LnqCN1Z0uqR6rR3fSPjr3rth9p5NINqH1OCp5HhoieMd25X44+6E68eK7vvflAq2755YOY90AKHmR/i1sFZ98CJo8fKtz/71bL3kafK+x776fITv/YLZeuO/qntIQF+TQc6xOxYP6ATMHIL0O28ndM4laIoYOkUIc6O79zNDFcegCfG7nmAUwDeARr0iNT8xCVfiUF1uAQl4IvON05IGwGizncj734QOwArIItS38XUFL9826Vmxih7KZOlQYGhoinP4EJdELZSbehREDKUJ0ds86/xoqrXKi9/PwwWICltfYCPGtgGO2UjeGu+7ijLAv0bvChDh/R7yWjBYfq6QpfptQeZlrIH+kdSrpmWz/7v84TP+3QrjVQFsM+jzuNHxwVqJNpvF1RyKXCcsxMe73fBd8Gc3TsmQemCTfgZ4JnvP14Ov/QKii01D2wID/TPnQ3R5dbJ5oHZ9MBzdtP0J/7n3y3f/dJdBipj2Vy/kPtPqQa0MLUv2GRIOiEktwbDKggT0KWnVDvutxxodG0Za6ZnyTN9D2EGkpztM7glbMAXn/oaX4KCFLAWef76PASYvJwheKEHbYYeyFN/biPXAyCPgWRKcouhqMORyTXPewTwiz7ArfawVR/2QaKyF/tTfSAjnpAPEE1AzXZRj57lj2T6e/Vn2Cf5YugPaIRf4UP5URpBh57+WEOgfmxHgAcC+TLgoz7WOYOPdb8c/Q36RHsUbtvOA+GrjrREJp8TfbZxPTbqfbYVlXg+U6TqsYNIx4XOa5R5fLE1bFEGHSsMvWTR+2F7SMW+x5/pkVuheWCWPdD/WXKWe9r61jywATxw4sjR8rJdb7tw3H6JHZzdChX893aLBRxgeoTAMAGgP67b7wcLOSAYuhETq4IETK75MaZDXpQDkE3/pX5MbiU0Abzoj036CJa8WwANfLeDeanLwwsElEat3SeoUO8AHGCzVZqY11lWvoEstOV7HKzYA73TnsDkfOkxrigrASAr9VchRBWYQTCRkr9sjhYnqq9UiA+rFniBoBsOppxHufbYs5bPY0da3cJ2D4ZYhp1omUFXj9MLwyBBHOoJysNgQTzDvY9D9RHlw2HZd5KTXrWFMvKU4nZcT+iVrrY/sx7A+TpxzNVh4LnJ9nnmMe9jNzLwJMX4QkYjChl8VyB4AA3vbFAgoaChO0JcESXxzfDgnfeVE0ePs/G2bR7YAB4YQIsN0OPWxeaBGfbAxddeVi689tIyt4XQZ8EAHSY3bAGMsbTOPRCiPuEQSOH+ByQH0sx6edpGsJoyJoA5dRly4Ed7aOdMJczxAbYZPKCtBUe0uMwF7RtYMHv9HgjUWXnspmnYST6Chi6AqOh4GEBE0IIWmTrQWo3Kffdf3mvwkOmSxd4xSyIowBnn5zFAL4eQggZQPM/ukCHnOxHp6Qi9DHFUn8f93uOaXsiS8s+QW4HgkJ6DBtZFB+irKHOYGCRk3mgfx8ewhQ4uTlY0yqo8EH6friaPR8D86fw61vMw5gBDbeJY0LlDbcbFA9m+B3CMWGtW9qDBmJmfbPfl5w+U5x97uiycQAjeUvPAxvBACxw2xji3Xm4QDxzae7Dc8PabvLeTwBW/pHNKBdgHdgW+B1BWYDGJ9ycpECRQHYerSwcNI/rO6Nhg0mdf2Qz6LxuYdzBhWb0oDmUGDwAXwUs+9j0CCCvTpcu+eRp2CCBrBQI0eBNPYUKqKj2f3wfhhLSpw9njV3Vnuggr3NMPIUQgDj+ZfdnAYJmagy71bcgkXwzpKhPQqZSgofzuVSzAH/QgiGGk2sjeHfKOybGfoSesaLkz54El/F2rcjBgZ3hnio9hOjjHxhTHhd4CHUECViCtZLL+qTqhG2UPJCzPPZsD/8EDB8szj+6xc0LfE50pLdM8MLMeaIHDzA5t69hG9MAP/jvvKScW49ev7lfwOrGhjD8m7KMUtFrtO0zK4s/0tclPCT1OUznsDBARSjD5A/CqH/hlmXmuPICTqw8MHgA+GSAQcMalS9DvdaaPKliGhtUEEJBXEDH0yfCynqUCCehRSvhJpBXtp3pzzMVV89BWNSjPowwwJyCv+rH9MGAAD4BbHmICwzDI65MyBlYYo0jyC6W4jV+2Q9dY+6Gl5U7HA3kcxuXD/7keAP7UaXg01OOlE+zryCUcIQwYcF5bjR0keLA172lg8AAbeExQEmu3j9/7YDnwuN6j0zXUMs0DM+2BFjjM9PC2zm0kD8zPz5fNm+bLzgsv6HVboQFwMwAcADTuQwiAauGElQGEQQs64Z5WI6CUFOTOxZShwKR9nPTNG94J8OKaZutvVwZeoF/gC8AQ+oK8obECUWMKXeCvPq1mLPfxrdIrMK0AAvQYC3HBxoBfeLwrfslfbjARWk4/F36hjmzPNK0OysxZ6ONSxxDHaFILrjdXGsLDWDkIHvDKn5IzzxkNWyUbxygYMQqpOTG3/So9EEftNEXh/1GOWp2DwwgoCPEB+CcTAD/PZ4wx7IjjDPy0zB+9aow41hA0+DFrtXwzTtWKg7c2ceTFV8qDt91X8EjslpoHNpIHWuCwkUa79XWmPYAJ7Mb3vK1s2bVtop8Ea9gCaNrOCTl4sBqgZUfC5PbiCMwjmOVWQQkaRIChlOmi1UajaDlM2WPguMe0poWu86aVCCBWH9iQwwgDD3AFggGkBSCPmvLlSyRHAEEIMhZAhK8DtMDd4TPpz4AXrUZ75Mj+0uU/Y+BdQcXYuyPU1nAPPQpCpBNl9EttweLwRl8D+88xzf0EV+6XpKh3XFsGiJk/ty5wp3rs/fg2C2ULaRUwOiPbi6Ah2ud4RtnZ22bVHshjMa5s3OcRGFBq7JjI+rIWtZnHlDRqhS6UIeN6jRGrDX7cSpELgx+8qIvWXtp/oDz14O6y2O5vCKe03IbwQAscNsQwt05uBA9sP297ufCyi7onKvXB+6I/TQegE0AQ4GrRf2oXDDU4OMCwEWD0vYfJVlL9GiifoFTCeMVUPdPUrAFdk39gdqAB2SdkwEuXJm+cNk4HGOKHQQIUSwUQBjxcJAIIl5Qx0GIGjfkDN2rrV1HIDFckpo1HB/QtGFCvIH+qpIBBfB5MqDCyJxhjhYKDpdrLAUX2olR31iYlHc2Ykssk0u3VPm2iAhzHYaONQ9JL2EjxbFensGVeAw/0BmS8vREWgHklH990YKDMY4Y8Mf55xCFtXCYHXv+rea06zFvNvNFYB/5o87FvPFSe/94eEFtqHthQHmiBw4Ya7tbZWfbAJdddWc6/4uLuiUr4NRt/WAkgIMUWUA2Tnyi4MXoSrjrnGKqbAm47v0L1mJy32a+YbLXTcoYznPyHN00TUJqv3Ex2BIAD9y7wpnI+wtV9U0FKfzXA4IWDfHNB1UHAUv3vzY4HEOiwByS2nwwgMuwhH/iRaGU/mAAdNkpK+eX42/sLBZaG8qRyK4AOW5XP9cP8ckC5t1f9Cnm2707zQHdIUxse4JonwE9u1ihgIC3XoD7KbDLKlG7btfCAjqHpuqb7HWDdU93l4LGvz1pxcE8q2hRvHlvSqAx5fFDyvTHO2wEzZ18C+MML3/zlb1AJuiuS7Fx5ad8L5f7PfKWcOB7vywFrS80DG8EDLXDYCKPc+rghPHDM3l567c03eF9HL4GxCRB41sMJyzi2rZ4hqFSAIXdljj4/OKBnIo2QyNOvWA6IndC95gSDCIYF+r4CSKCtemSrgx/jw+oDkn7xRx8Imvs3T4NnPICADtPtaqwdMFa39C7zMqPYEhiG9pE23A7BO+TlcdkL8N4PdKgFsqIjL37pzLpO1W6uX1awYO0Nk/vFiVEHcDeWZGPUkQ9qQwJjGhy9mpH2M+dp5eH4XnunpWXdC8U4TuvKdCd1Z0BlGY5/V29n0fR2KJzrQYnj0rTieLfBinsaTLPRePxgvcH+/BhBi9S3sLBQXrAXvn3/6w8Mvjum9bPRmwdmywMtcJit8Wy92cAeuOlHf7CcnHiiksF7//kbaGbyQ3CJCZFhACbZAPWkL8elIbMc7teAZwXgjUACfpJd7DfAZn7qkgAI7ncA0O7KBijw6zZ8WGMOyzvBAAiVwj/IBgDKqxAIRsgPLTmIQDmADkrWirUNWj/gYd3YNoPrnM+8mZ7zmedUefhjObIEYpPawjfwE3RN8oCS29AYiB7lEB6jgd/xIDJrnaLptda8LvSFv5cyd7qTBNBxCuVjQtq6eqv1tnA+qjLtOb6soZ7Io4yS7yFvH+ShEZcmzdtDJlgHhagPxXNzc+XBr99fXtp7IIgt1zywgTzQAocNNNitq7Prgc2bN5ft5+8o23fu6HVSWBigGHkAWFyKE0DfYGqHmMUNFcizHLygR8LUq1UHTODT+EKCueXyDeVWVE4T/fLkCA7CFxVkGNqPS5egqQYMhiToNgUQCAQUQCBIkC+rHvjSsug7YwmAFKZYhWB5qSACHAoktKcU2wSojj6oZm33w3alXT1WOe+XEywoUIBfqKs/iKwPGv3HMurkT3e06YhVhpDxXEaB2ciWP20PhO8nVeD84VjEOExykYLvFE9TWLt6YxprEzQA/u4YSMpw3IZa47IyePESRJyTXnYe8vkqhNVDp+QQWOx75rnyva9+uyy0pym5d9tm43mgBQ4bb8xbj2fRAzYzX/Wm68vmnVsnekdwDygG2IpZHFldloSp8KStVKAeHKQL9w5//c6gX0GD5FyBbTKdNOpWvTevwjm2FygO8G3AwVHDZABB/KkAIoCMe5mVIwGEdZiRQxdEEOjAEfCT3XNS60Hp6qoLh+MBHiX9Eq8+iJ736JfqkcdY5GAj1ymf5ZfKQ1dArH7Wq+qm65OVFSygKtMra7dT38gnsgG8iui4E7wzXV22yxD8RVFKzq09D4Fzy6Yp1nC8p1Qm8rSgMbF4toP1dYyGx0NX79y1dQf61AQKZXRcQJGAP6VRjw+Obe6Nw/O20gAK9NWy58Hr6rnFk+t23/Ngeezr32Wjbds8sAE90AKHDTjorcuz5wGsOFxx47X2aECbCO2sHoJ3PGncAa0BE2ATAmMGEjkYIPADuATPpJ8wOY/dTO2cI/yTGgYUyHBOHlSc3SL6D0dFl5YbQGgFovrbFVkXe85kh/1Rr7XvrBa9Nm6O6QKFygew40ZVFtSD1vGdwm0AQ0rIq3+Z7mOc+MSvfW7PQWGnRByTe7e7kpcTLAwDhbDaul9tq9DRtLI2ggU0FBJkj3I1o+1W6IHw90oEl+d3wXMNWz5e0FpX700vfYmSrAt7zYbumIE91M7AwPK4Edrq8cHqA7SjPfx5rpOdK4ePvFK+8fEvlZf3vqhm2r55YMN5oAUOG27IW4dn0QOXvu7KsvXC7RY0xKUqCB4CUDJIIOok0uPNvsgL+cEzzPdwrhxmxH6QwYquDczJWZXkltovD1cspeEM1QFs4N+8OOiTAOrwEibiC4B4kzMhARf3fAUfcFAsKETnWc2GUN/diA0julQNMZKPg+0BbJB8j2oUKxvoSAouTp0HRwQh0g1qT29qt6uzDPlz47QNPKcTLLhu34Qe+ClKqGSJY9Kv8VonTdJd7bmy0bi5weeKUbRDx/CZsgrgvEs12zvurDJ4aI1v7UCQJMqSYQAMwI+kPY+SzIM8LkXC/QzM29bz87HyYPVsg1v8YPLgrffYasMDE+eYN9c2zQMbxAMtcNggA926ObsewIS3cPxkueamG7pOasoDAcAR2KT7WAZ5JKw8MBgQhfTgUHnpvZlg74VYmifXYmJfAXsWfY3z5kn0rYseCCLgn2kBhPfN3+7MIEEvkYPh+T4I6IggArXUDZAdawH0E/nUNoCSUowbHhvrSftaFGBCcaX5qoK7qldtY/yyvswEn2l8wZ+PR/Jxy4BiYHDHQDp09VMQNAbynfgIIFU6x/fRnXPCUI3v6Rtz6g71jofEPjyeenxmkNtmB0QSSWaSKvt13EUwgXq2wCDB9NgBiDw+CCSwgoY/zyNnZSSsQuARrPd+8o5y4Km9Tmub5oGN6oEWOGzUkW/9nhkPANRe97Y3lEVbbVA66bANv5ZXYOk7XKdvNKBQ7I3ZgRuKEuz20BXUyJGB0h0z1K0oCVSuSOgsMgtAdP40UME0HkAoWCCYNwDi/umvQnh4UNX0L2WCZukHaDFhBzAM8gCI4L/pwQTk0aB0RJ6rD6inDsAorRgRUkUblHfDjVu6XNQ3sIPAn7ZUjFUZ4tfekGBOMiyFXgE+0HE5Ui7n9iNYAGfIe6lfBKmlZXig7+tlCPRYVuZ0APMu1ewwYOjqu0xcntSRLAO7JYu8dJNG5blvOI9R5zc+e573Nmy2QJ+rD9xDD49n6sBqw1P3fb987U++kJtv+eaBDemBFjhsyGFvnZ4lD8xvni8XXHVx2bZ9e9ctTI56NRFAveCfM3So3SBjV9FljAV5ljvWTvPGzkwPIAzAEMn3nsJE0GK+dPyhy5gIeLKPdd0+vDs9iAgw7Xq9PSgOsJ8DCgD0yeCCQAjtCFAJeIEGQ0EfymawLzlyV32dLaD2U+5bvyZsAD3z5Taq81x06iVJqCXSc762WdoDff8uzTteG8fReP0kVaDea5J4//jDaKfKepS6vTa+wxrKEuTb+l2tJxfO1ZozLXbrs5URhM9bkAC5ebu3gY9eBd05GFBYHeolDXtfevZA+eLv/GX8EDPZvUZpHtgwHmiBw4YZ6tbRWfXA/NYt5cKrLi2bd8QTlfQrMuE/tvjNzPY2Ay/iiUqsQHGFT1RaOpQYrkSM+XxpDWMS5x4NoCRWH2QfYYoCCFCH90EQAJF/0dE4ViEgVwcEMqa7n6Kuxia1WnwE+yBSP/kd+PQFOrUeTJq48xsVY5LtoCzYky4UpybZQoYcBGQRtSda5uvXhb5pKwzhpuCV3raf9EDfv5P1p6acvp8zCM/t8JgLSp+PFvvWBju3DlpfNp8D5AU/ePDp50EzqgUQ+Mz5Hjz25+0wr4B1wd4O/dg3Hijf+eI3Rs75sL3lmgc2igda4LBRRrr1c6Y98LofeBNRah9lWZ8X7WGrBIbAkICBBLyE7xnEY4JFcAFAFisR1W0ThErXjvhSpbSfWpF41mdWqw/0avaZIM7YZUzwB+rpZ+QxBrjWWkmXOamsG6VRTmwjKxOSCF0CP6rRHmOcuQJUZiq4h2Vp4J7AX2McvKFvjJ808IQEaFHqH8ZBp6RxOmmSrvq2pwemjcPy/bM6HwOCdyll8V0zTD1eq+xsdzAf3KCHPMG+eEXHuck82rEcdFjWVxZ8xYGrDZudrnsaIFEDjWTekcOvli/960+UY0ePhREt1zywgT3QAocNPPit67PhgUuvv6LMbbUHCdobTREU6E+rDgwbeDmLQO7YE5XEPxojYNb1CkzROdyoPvSoJM22U1w7IjmF82yTBfCXYwf7rbdEh//kjwggAI77qxAAM9aWWK05BBHhp7gvIluC+vxrfa7jGFebqjEIOLT4kPN9uSiNBwSTAQIl2JbAW6Yhn4OdaTxOTz7oOYQKfRvBWiK2bM8DfR/3qlZY6A3ICmUxgkm+ZgXsh8p6vA7vjQOgfsDY75vVG0PQwG3AH8SaUIcS2lXQgPc1+BOVfFtwERNrvT3Luzx1LJ5cLN/57NfKnm8/LJVt3zyw4T3QAocNfwg0B6xrD9gkt3nL5nLljdc54BxeKuQAs3bQAwphP6PhUhkC1ER03mHZmauWgLSVgMo+OoyKiRwm8jENE4xnnRDgY/mmUMZxhwH28GLWFUEEAgj6I9fDlbhaW0ljxLLA/3BVQtz0LUBSDRfdGNZmAJ/zkp3c0wroQkKwyTx6FhZ6pW+ClpodcAZPf1UBCqIudBo1K8sVLe8e0PisrTvGx+JUbfSg/kDFWgQNoYNBA48ZHZegsVGGArqvgXQPFvydDbw8Ccff/CY8frU+gtWObtzzILMRaOx98ulyl90Q/fK+g6fqeqtvHtgwHmiBw4YZ6tbRmfSAAdSLrruibN213QFnQqs1C1Dv/959AEZdm8+nK0Vd+AdTJ8AhU+REGe411Q7pG7jcARB6b3IVwoKGGgU4yDc2ABndexIgerDiUF2ty5dc1twcAQV8zjbXDlCyUQQrWInQZVXQj+MJwcpkW5DRkVONBl9krdQrWJnJqbERef3s0e3xrq1ZHyb9vVaqV254QO3JfgfQ79vXk/Eq9iivFmQJBgKk5BUBSFGSGmE9AD9ozNtlSH4ukgrZ4Q3RoEl/tgvH9d1/+oXy7c/dZbmWmgeaB+SBFjjIE23fPLAOPbDJkNgVN15tEx/eeTpI+NVb2M2qHJTWly3gwiUFEAHwIA8BCmllABNwUgOmZabTk1qm8nXCRiBm2MRT+BzFSrQcAbVWI0gfXtLkCuomrzg4cApV3cqAxg/1yCu4ANjPeahEWasQOY86AjPnosW1LY1urgdXJDIuK1hI9lN+ghBqz/XcGTI9/LzWDli5wRlgd9YM1KwkaMh9y2pE5141WmHAsQlaDRo8AFDQgNUD5FHHlQS/RKneDO1rDJbX+xqcTycpNNrJd++nb7N7Gz7Vda9lmgeaB+iBFji0I6F5YB17YPPWrWWLPVVp+/nxKFbcqxAXyiCnIMHyNs/Gr9p2SYxHFrgcBn+RdL8DKAKIhJ/Bc+ocJvWQPjX/7HPoUgr4Ba4HVongDv6KpGAiKJYzGY5Tnzd4YoVCoAt1nq8ivst5MFi5kvp51PVSx9WjZv29Ci+My6jvxGvjPJO6NhYlj+Fyeo5zux+oTZNamb9HAwWpTqpWEixInMcOlSRVfsyGPrPAKxU0pD0rPEigv0zKaP6xo9pXGKwWurpAweqRFw9Ud320E+zp7z1RPvvbf1r273lOZrZ980DzQPVACxzaodA8sI49cPzVo+XGH7h5tAeA7PgoIWjggoNCBEyX5MKkmoMFyfjekK0kUI6gBCDW5GsjmU753DopbSsPCAgZYLGf+CeDiOBTzh1tQzYGJiMYxJieuSRQOglQc7sY91wOexzjddXhg+BoubHxXa5XND7j/ONjMs6bgPQYQ1IV4H6McYwmeG91FfQndS4AjtBLgI8KSkbQoEAcvPj41nRuthLKWHXgzdBzBS95w6NXN3f3NYCbfKFnrrzyyqFyq72zYfc3HnRb2qZ5oHmg74EWOPT90UrNA+vKAzsuvqBs2mwXrthkickX4D0AfAbuzGcKuBUQKGiIX7+TGzC5j1ZUHjacBKZn1d50jo1YEwC64ihzAoOJvjeG8KpD4AaIlO+PcF9+iZLEl2BhFW2I9sYEwk7PRaeyijHBDUlbfqCw7EGqfoxxWK5j+S0ywp1UAZDny91GuJ00qet0AgZqzz5C+0jYYtUAOdRr9cCDBjvmPHDwl7wxYMD9E1h9cLrJgB95Bg3q4EL57q13l2999qvlxLHjprWl5oHmgaEHWuAw9EgrNw+sIw/suuTCcsEVF9fJj4ZjClTwoEuQANgRHNiUb/slVhcGfXcYulTQAP6pWJWWDFS24rI8AECTGcPJMRyZQXnts+wy8isW6wt0tjq27dcto/UNx5KB8PI7vxy/Loen3+IkwK/1SZXAuiQ9TlUh7afqMoje9dkOlqS6k0YbHY/leUz1aR4gmESAfdbXEMBXGKAdrWGFIdMh2z1ByZT7Y1jdlrDmuaf3li/9/qfKgXaJUjcuLdM8MPRACxyGHmnl5oF15AFcqnTlG67tWQzspkCBFbEKkeCn8yjACAV+R4TXBe10c9EaNLTVhtP1I+QC3BBQZV3mZ/5n4hnJE7BxNYT5QTNh5qCiFQMUr7UvVu50SozIjZCGQcOY9dNCAfHmpyXlJrJPmK+W2S63yzxb0XHHsIA188aPt0BjBWLelkNwiRKCBgQPCBDQ/mYPG7j64AHFIGh46dkD5Y9/47fKQ5/7hsxu++aB5oERD7TAYcQpjdQ8sF48cOM7birH7M2mO83g/MQefzKO07DGYKDdJtZFvxCeYB6/WmOingTzmFKReBkTpnFKOHHqZjIAmcraKtbcA0BNObTIDWD0MIpIY3mNrnjIufRWvwYvzdVqdU3+mfDESsYr2h8F+FNUEZKH7FhuUl+EAl3OAfqkNOrZho5LHVf6DoIM82oHQQNDAlBMg5W7G56N0t3TYAED7mfwJysZz5ZB0MBHtIZNL+19oXz6n/9B+daffTmILdc80Dww6oEWOIy6pRGbB859D2AS3bxlS9lhlysNU9y0bJMy5uV6fQsCBYQEmLTtpaiedH9DZbRaBg2orCxkXGKLaXwyeAAiCQ1oczJQWUJpq1oDD2RUOJbPtDVoboOrwDF+ZtLqxknA221bQtXpBQvsMS4PykkrA5mGvLjYFoyhQQwKxK3ggZZLl4IGDzlqEMHVBQQNCCIULGDPMu554KoD92ihtuiNHT9yrNz36TvLvZ+4s/64IhvavnmgeWDMAy1wGPNKozUPrAMPYIXh0qsu80exCp4zCGAJQB65BS0/JBBPAE8+TMYnEC5IyaDvGezn4CACDoQHY8JjtIHyVmweWOceEBBe+24sgfCX0VgvWBD/QOVyAgWIjuoyei9YMKA+LWUf5TZDRIECNHBVgTkrGZNkHPpXoc2wyvJ6rKoHDQgRQPMVBz5dSUED+gALcUlTTrvv/E659V/9RTnw9POZ3PLNA80DUzzQAocpjmnk5oFz3QNz83PlktddWU68erzMn7e1MxdwPYB8wH5dnnSycip4QACAiRkBxljwgGk2tHTNMLMhYgN0cjooGnhkdcXTaep0ZFZn5YaX7kPPtXTH6o6zaQA/H74C4aeyepquacHCNMvhq36bprkyD+nyK+rVPnjEpyDCdSI48DquJKjO72vwR65yxQGXLEGXAgz1e/HESXvk6gPlY//o/yxPffcxkdu+eaB54BQeaIHDKRzUqpsHzlUP7LzwgjJnlyrNb+Np3AULAJI1AfBjZQKPT0Q6YXUKGEjhdmpg0DGdmqNj9UwyolZM1wDeabCjr/XslF5D206nqdOROTuOXNetCtSufSdOfwAFrkdtSmoFvEf5KnFJXQbRu/4L9ZtcaqKnmoA+k4ITAH8yMThQDWyhzdhbzmRQB5oChHl71Cry8zVI8JUG4+DKA/Yma0EDypKXxYt2nebj936//Mn/+K/K7vsfnjSnUZoHmgemeqAFDlNd0yqaB85tDxx5+VC5/uYbbDbllM6p1e5PsJUD3AfdDxCMYAHEnFG54oBpGIBdaXK1wWtNZjrgl+xq94ILq9WzTuTh2A3W5XUyMj0zO6Dco65FYXWDz/N8ih1JNUD2qdJ0Xf3ee6kC/mlas0TOA7TnlOvCRgYE5ESwUIME5BAcIAgwGgMACwZqQODvZVDeOBA8INDg5UnoHfTidKNmhT9PPbK7/Nvf+lh5zFYcWmoeaB5YmQda4LAyfzXu5oFzxgMXXnpxKVvs5W/1+iKsOOAPySdZrDR4KbZ4h4NJWPAAGunO4hNrLhPb4sVyY9cvnfr+Bmpt2xEPEMOMVDTS2fYAzpu1TPGG7dUNuoDvhG1JbYDwCa4eYaou/9Yg69APQ/AvhZkvt9/nJ+iXDL9Z6ndUBfSgIThgIvhnkMAAYngDNPqwyX4wwX0OCha4ugA9ZokHE84Fzq5pvNfm4J695bO/+Ufl/i98vZw4fqKra5nmgeaB5XmgBQ7L81Pjah445zxw6Q1X2Y3RO/xXOAUPMBJxBIA9VgowZXqIYERNn4t23RLqQI/VBOcyStBAGQsaQAZIUPCAiVkhCuqY1LLKG3wPZ2oANrgrzrXuZ/C7trYB1J6+xgx4e1qSzgzWezyDwlRd04IF/GBQU+RIyP7qt585Ix/8CAiCDpsUYICHddyCjhw+yOv+BL7AzSWNZiGCqVOgsAXcxgsp8Udr9r12YqE8YSsMH/+f/t/y4G3fVPfavnmgeWCFHmiBwwod1tibB84VDxw/dKRcdO0Vk+bUm5wB5rmyQBaB+8VNFi54VEB6BA8MOCYV9uVRUtCAvPQi39IUD2QEM4WlkYceOHPRVoDZYZurLa9uoAF7R1MiE1qPcnXEqXqcI3ofOatYIliQ4gD4ooRhCgJQk/VmewnsKSs697Z10A9ZPqwBqwboh79zAS91q4EBqHpq0vCyJJRRj1UIReqgYGXhwTvuKZ/6p79fvv+1+2lA2zYPNA+clgda4HBabmtCzQNn3wOvf9ct5cSJE2VbNQVg3v9SUIAJ/AQCCX/5G0C+cQ3qIR7BAybcYAg6uAYp2AYVKC5ZOcLfSM0DQw8EKB3WrLScgexKZZfmX52NSwL8pBpg+FRpSV0GnpUiZ5RTBAvkxW/4w0R7QrzPk+0Nu5hTHfe27QIG6swBAgMB3NMAWQYEqOcfgwnnZ63byQAm/LWwcKJ876v32Qve/rDs/uZDw460cvNA88AKPdAChxU6rLE3D5wLHpjD9b3bt5Wt9hmCdEyZ3aVLwO/2wZujFxYjDFA9go2gomdjgL/PAa6VptVrWGmLjX+je6APdnFcB5hcnW9WpyeA9MCKgVoB7KXOnam6EtTv+wFuiIYiF7ZMDxYg2peQjZDOefna4b6LILCgLEA/ctCF1QXwMs/eKCjAqgHleS+DazDBzb72YFwuDyo1cpUBlrAd5I68fLjc9ZdfLJ/8J3/g9zaA1lLzQPPA6jzQAofV+a9JNw+cFQ/Mb91cLr7y4rJlJ97fgIlyBPDXm6P9Uawj1dnwvArR0UeJXe2KMgAjSwGgFSlrzM0DUzwwAZI7vgCTHWlFmdXJExLnBmsgk9QKWGcu5Id9mtQlieCMnNUNwH5qUoK1DYDwyZSDhWxjzlOKmt0+y8pO8AHaI0mXnpLk4QYCgBoEQGoelyXZZUrIg67VBqwscHWh3sPgLVAz9UbP5kzHgb37ypf/6DPltn/5l+Xg0/u8/bZpHmgeWL0HWuCweh82Dc0Dr7kHThw9Xi674ZqycPykvcuhfxrjciU8PaT4Y1kBUIzSCxxU4B5TtF4K1+sIAEdf0KtP5/6GFjT0PNsKa+iBMbC7NuoDiJ6OPgHnCVlXS92T4HuC2+HxJFWU6H3krA7nbk2RE4V78E9rXwAfnJkn5wHsldDXMRm0IVBPbrzN2bndROhDPT4A+wgx5u2OZ+asbTwdCfVG9z/wdSXQQ39nC4KGZ54vn/udPyt3/8kXy8Fn9quq7ZsHmgfWwAN9xLEGCpuK5oHmgTPvgcuuu6IsztvEuXneL0tCsOCrDgnoD8E6HsWaQb+sHPKJPhY0oA4Tt/Rg6mbbnVTLNA+cUQ/0APKatxRgeKWqCWOnSCW1ffA9zr+ULgBonbM9XxioVoqcKNwTdCOP74s+1xjwB2e0IX5YZ3n/Jy33KYIFtQCLCfjRhj/xyIMEo3lQQH3Ka4UhBwqQ5iqFa7c8zK92IG8J/C/t3V/u/dxXyif/6R+UA088x4q2bR5oHlhTD7TAYU3d2ZQ1D7w2HjhpKw2XW/Cgyb67Z8Hm8XoftBnCYAKxBOA90iabsJnzYt0sh5L5I39WggaYS7wShrTcTHsAcDHeibCWXV3dgeQAesycgdoMrMfYQZuqywCxknLaAzwrRU4UgX7A7mGy1pIsarONfX5ploWUzfzQJRlwq44hA/hrzirxHeRBQqUhD1lsYRIDBzxsNdpBy/iDXrRFi7iF7UjHDh8pd/zep8tXP/758oK9q6Gl5oHmgTPjgRY4nBm/Nq3NA2fUA1s2bylbd9k7HCwq0K+Pgv+YhPGuBpQdY9v8qoWIeBSruGEmJuBczhRqzwGCVhsguZwk+5bDuyyePl5YlkhjWn8eEBCV5at5J4J0cL+6A0iwta/TSkmtgPMET48wVZNxRe8jhzZSIyj29LFAfoLxYXUOFrKNvTZcSJplI0G7fa04eAc/Xg6JPTkRGOA7pAsVnA/8DCp47wK0aWWBdON3neTDegRXFsCpP+hEO/Y36D9qjrx0qDx0hz016Tf/sDx+z0Pl5MnRCy9NQ0vNA80Da+GBFjishRebjuaB19gD1/7A6+3NqRYcYCJVVGA2IDsE9lyNIPS32x78fgZM8QHoUcInaCyBgikbFzkhECEVgENtZDq4mULayygSXdT6tmseGPcAjrYzk5ZxAC5xnOI4H02JnIH4KG8lTtXl5xqZen5IYDk112sC/NPaz2A78/Ta6PUPFrIl8Ese/MsJFsDvH/Ony5sOyIound6K8fLxql4iP+TrHzrpfXMfTPb+Rbs06c7ft1WGP/58eeZ7T4C9peaB5oEz7IEWOJxhBzf1zQNr7QFMwK8ePFwuvOziSdX+zgaEAQTvfAwr2QT3sUqhFMHDZMAhHuylD3kFDci31DywGg8AFJ65NAk0l2wrsQO4Tk2pKgPxafxL6nJYTMmeLxwok56a6zWBtnsyqRbfEUrZxj6/eGShlf0felkHfukSJa8sQAD1uqyIlyE5tV6OBN01cIBWU+JrEpYhnXvSRYmAw5icL/piL3M7drzsf+q58v277i93/+Vt5aEv3VuOHzkqlrZvHmgeOMMeaIHDGXZwU988sNYewArCje+8uSxu4VQO/QDzDu5xbUANGnzvNzzwp1SFC1qlEIhg8MDJPQcFpOfQYrInOaDItb3r0cPMzNLyG9QDOu7WvvurO9AAW0fTgCxQPcpbiVN1DaB+zxdAz528crEn73iwIHAv7mxjr42uj7KQQYIuQYI8dEkGFoUuh/zg8KAAdPBiFZOXH2FvVKMhkEDyevC7FvJDN1pnO54jr3OpzqWdnjcLdhnSd2/9Rvnqn36hPHjr3eXlfQdzdcs3DzQPvAYeaIHDa+Dk1kTzwFp6ABPutl3n2YRtv/2l1QO2EVBeVZjYF+oDVz3AqBU5SIhgIyzFBL9gkzm2mN6lGYBBspkekgAQudTyG90DAqJr74fVHWg4fkdTIgdwHuXsiFN1+TlEtp4f7DzOqV/K/AHke/xJfmhjr52uj7IQ+nCZI4MC8C51CRKhfA0CrE3IjgUL0M7VhEVw1HxdjbA2FCigD6gHB5Lrs5IS+HKCzr2PP1W+d8e3yu2/98ny6NcfyNUt3zzQPPAae6AFDq+xw1tzzQOr9cCOC88vOy46v2zescVUGQBQhNBTjDc5cI2BKwyYpHnTYOQQEhhoqEsR4u+pqQUFDShmvkwfkwMN7S29bjFNstHXswcIC89ED/rAcqUtALKOpkQeAvFRfiNO1VVBMeR6fkigODXXUw/+ae1nUJ15em30+keITjtWGiyYrNmLzzxWFdxK6uNTkWoe1lokgRJAPp+SxDqYQjq2SNzT9soDavKLs9lmYWGhvHLwlfLMA4+Vuz9+a3no9vvKs4/uUXXbNw80D5wlD7TA4Sw5vjXbPHC6HnjlxZfLNW+5wQOG4YQ7BPKLNqEv2nVDAPsE77ZagJ8LLVoQ2MB9EAoeOpuMQP4pkL8GGx3/EpkpGpaQaFXr1QM6ptbe/mkw+9QtCbKOcia1GYiP8hpxSV3dGSWQXbUkUJya6zWBtqf5Lp/j2cY+f2imjSyDX/LgV161S9+vYP1A4GByOVCAF7iygJw9PtVK0OttgeL/LKOT0EAt8AskjOZ6mXdCb7NolyC9VL75idvL1//8S+V7t9/bq22F5oHmgbPrgRY4nF3/t9abB1bsgcuuv7KcsF/jMCVjEJK1BQAAQABJREFUtaELFrqVA39vdKdX9QAOJ7EK0fEtsRIAINAFD52qyGDOHw0eRokh13Iz5YE+eF2qazgupgHFMbmV8E7KC6hO1AzUCshO8CXCVF0Gg3Pqlez8UYqcKAosAK4nk8C9arKNfX5ploUE67oECfIE9NQE7tDl0B8csUIAMG/DNBksgJe60BIlLWcKoc//an+lHzQk7DNt2Ddnql8kB5563i9H+tbnv1oevvP+cmj/wXLy+AmytG3zQPPAOeOBFjicM0PRDGkeWJ4Htp6/vey8ZJeDAkgoeOBKQtZBEC94Mf7Lv4UVY1h/qaDBG83t5DxaC4XjbWb+ll9vHuiD1+Var6NwKf7l8EyXF1id4EhqBWIneAaEqbocQpO554cUKKA2NdlpJj+A9GTKgHpoY59fmmUhgbmCBfDqfgW0QpiP8xE1bBuSaI9Bhe2tuh8swAJK5kuQwD+86RltkFt2MVgQHXvo8n3PR/yOOGAvattz/yPl4a9/pzxx3/fLvseeLQf3HijHX21PSXKntU3zwDnogRY4nIOD0kxqHljKAy8feLFcfv01HYsmZkCDEwba8UhEJEzNw6CAQJ6TtjP5pE7qNJCvFQvyt+3G8ACOkQCDffC6lh6INk5Hq479CdmkdgjEJ3grYaquBPV7fkhAODXXUw/+ae1PCxZ6baQxIARnS9A5FiyoduISJONXsID7FZAE+PNlSLwEafJ+BfDLXvhJsqAjyXcT9OQj/aDw/BPPln1PPF2eeeiJsufeR8uT9z9cnnt4TznaHqlKZ7Zt88A57oEWOJzjA9TMax4YeuCW9/31cviVV8r2i3Z2qw3gOVkBAQIAgX3M2woe8P4GgJLJ96oCbrCuCx6SIECB9BnjKVIOSk7B2qqX9kAfuy/NewZq+wB2rRogtD1dbQKoo/JJNQDsqdKSuvxMoYaeHxIQntYC2u7JJEMEvkHKNvb5QzNtZNlBeW0f/NKl2olgwXjxN4+9HUu9VQXUuC6tLAD89+9XgI3RRj9YgF4ltyuVJcP6RV89eH4PgoVnynO2ovCUBQpPf/tRW2l4tCyc7L5xpK7tmweaB85xD7TA4RwfoGZe88DQA0cPHSk7L9jlZEzSeqoSwIQHBZtsMmb0UAE/ECgn6EpOKgPok6P+LqhoI3EuLwtAETqXJ9O4Rj0Q2Gy0eq2J08Dr6ttZXUcySO3ZMlCbgXiPLxWm6hpA/Z4vHGBTyaBJJ5J3rYIFWUigrlUFNIRzXXbBjujvau9XkG72TsAfluSgQJapXZXF787wc3+xHLGnIe3d80x5HsHCw0+WJy1QeOrbj3iefG3bPNA8sF490AKH9Tpyze4N64HL33ydvcdhu/dfQQMKeHISIPsi0IYQjhEYEAByTK41MD5YGujn1Yb8KFa0OZmW1jXJ3yhn0wMComtvgw7A09MsUDohndQKwE7wDAhTdXUwHCB8kFYRLGQgPbSx3446Iwv7wQJ4X6v7FdR7WLKcYAH80U+e8wf3vuCBwvOPP1Oe/d4TdgmSXYZkwcKLT++T+rZvHmgemAEPtMBhBgaxdWFjeeDSqy635f9jZcv2bUt0HJM5H6kKIBCPY+2LYPJX8AGggiADcCbDf4CJHDxIwxhNdRtqD2cJA66DjvfB61oavDonCD5PWJTUDoH4BG8lTNWVQoTOD7iOJ9FTcz314J/WfoDoPk/XRqdJ2mEh89CplQXwK1hQ7cQlSJC08xYf8PtlSK7NypUO3Wt9v0LXBbTpxi2WfXue82Bh3+PPlae+i/sVHrGVhUfL4YOHMnvLNw80D8yQB1rgMEOD2boy+x7Ai99OLC5Y0LC16yxXASrUr5cYYWevb7CEDSA+1x1wn0M/RRnvhyZvnyOXFISABnAyGTxQR5ZZdR4mEkWtWtUZUXAu21Y7PAlg18oTp995HD9TU6qaBtaz7JK6UlDQ8wPRr6mZLg3+ae0vL1iIjrAVlqFT8g7+qy2qnQgWEBDY38T9CtJT6xks8HTJ71eAr9Qe9Hj7tnd63SOf6V6ZNjDxxNFjBfcr4Abn53c/6zc2I1DApUgnT7RHpyZ3tWzzwMx6oAUOMzu0rWOz6IFXXz5Srn7jtdY1TvrqI56D4iEAfn7Ef92DT5cqzdmlSicgZsHD8JKjYVl6sc/BwVJ8lHErsvjq8/2url7fBtDQA8hr2t/VDQZA69SUqqaB9Sw7XVe/971SBejQk5rr1JKXv+R3xJQR+AYp29hro9MsC9kSZCUDfulCrejIMW+yxo/Hn2LvqwrYgxd7z4OXelDjeUhbnfQhj8R6bKMMesdX6aDlBPFXXzrcu1/hqXoJ0rPfa29xzr5q+eaBjeKBFjhslJFu/ZwJD8zNz5XN83ba4gVwcxmuELD7/Q0WIGhhgSsMvACprjmYHwgePMKoeWriugRqlwP/c0Bx+s5FS7Ln9LU0SYDAM5VWNz4CqxPWJbUCsBM8A8JUXan3E36o4BmqUpOdZvKPBwsC3mAe2thvR5plIcH72CVI0IVarSpI9//f3psG2XVceX6nFhQKBRR2oLCjsJMgAVDcF5EitVEtqTVqSaNWd4fbbo+nJ2xPO/xxIjwf5pMn5oPDEeNoRzg8MzFbzGjarelN6pa6tVKiuIkiCWIhse9LYUcBKKBWn/8597x776v3ql7tb/ln8d2bN/PkycxfXjye8zLzXpQ0hyAx/Ec7C2iBlyz3fgXTPQVnIVDdvpLsV9ANzpc+Pmv7Fc7vPyHXz/egCgYSIIEGJkDHoYEHn12vPQKrtqyVJnUe8k5D9ANGuLsHME1gtNiVeQGIIWIXRWefgYiSIaFCFmCshJMA0yVmHbLpIeumWbGGNHd0LAyu0TlMGZ9A3ngdX75yiamNC+6NkiGTXGyIl5TXxLK6yjkLYf1a2dJaJ+MsjGYdnUELPY4+lXIWIjecBe+7l0udBe2r/tNBHuSbmzSmfcGfL0GavvcrZKkEruvneqRHn4KEJyFdOHSy4CzcvdmbFWecBEigwQnQcWjwG4Ddry0CeELJqk3py99Ktd4dgNR4HzYDC09UUqPGpiI8LxyFUjoqSQtnYixZGFtTrWcs/fk89CuMuXxOPV2NNmCnq3eTZ+embpl2ZNS6wVxGLkkeU9cUnYVy9ZebWcizTjvibfRrM/QT6xvy425uTpyBUvsV1FMochb8jp6J/QpD/QO6X8E3N+NJSOd1Y/M5nVXA05AGNY+BBEiABEoRoONQigrTSKBKCazuXuv7F5L2hfEeT0bKNxu/UOIXTN3UiJ9B1YSHgeTLmZBe2DJtMulMQsxLhAuSdULSeL6uuBovP+Rm4pwadjOhfa505o3X6WzF1HiNaeBnVJcz1rM9GVPXJJ0F54Zf60uHiTkL0ULvGMpGv6A/dCE30hHzuDsD1bBfoa/3bvIkpAvSc/yCOQnn9h/XtzifLg2JqSRAAiRQRICOQxEQXpJANRPoXL3cljN4G90xcFPdN0EX/7rvex2yqaUM+3xaegWTCM9amshSpWqmVzttK2fsTqwHGMmMBW+Fi68npjHM51GlMmpTw3mUVC6hrC41tyOksSRFDfYIaSxS3ElGn0eVU5Ew7kM62868fGiOFrqTUGoJEnQh15cg4Sp1FrCJGXWg3onsV0Ct0Z5os6fh6G2Lc/QhrtGCCIGq9+pNW36EF7Jd1g3N/jK2E3JNZxsYSIAESGCiBOg4TJQY5UlgjgjAiLh55oosXbdSWwDTAnMEMA71CMskdkRbWtJIS4d5Aechlip5XtadiNmGpFRyykrkc8pfwbBJXQ/IeUvLl2COEwhjcfp4pAbwVHSWMkpNX6jXizBgx6unrK6Cqez3S0FPWL9JQqbKgohzS43tQoZGwvBGWraNo1mHZrTQ45Av5SxEbvn9Cl5X3llQbXAg9G869iugP9FOxCMErmu6ifma7lXo0cemXjx8Wp2FY3JWX8Z29zr3KwQrnkmABCZHgI7D5LixFAnMOgEsR9r67G7p7xuQBfPT9zigITBSYEoguCthUT0gzd0LM+D9smCm+bsbwlgr/VSlWA4FjVkHI5uOvNoOoOb8ZrMfow3Y6ap9an0pZZRayzJqs4Z4uVaX1WMF0t6nMc0I6xfRMoohX67+qToLUR51THa/AlqePjY17yzMxH6FYX2Hgr1bAZubbb+C71XA7AJeFslAAiRAAtNFgI7DdJGkHhKYBQKt8+ZJS0tLUlP+l/30l36YW7F/wZ+YhAJZo3/cuQQYbyMwncosVdLsJv05tn6ch3ImKshNX8gZyNOnNtE0+T6MaeBn1JYz1rNdGVNXwWUNZzWanlaSxlKtzq30rAKkwthHPNvGPO/QHC30a5SNMpAPXciNdMQ8rmVVvqL9CloCng/+tVoNmXrSOrzutEXepqg30lVFLuCf5/2798xZuIqZhRO6X0GdhLO6wfnioVM5WV6QAAmQwHQSoOMwnTSpiwRmkECrzTI0SVtne1ILjAz/pTx1BPxVcDA4YARFupsjpRqXzk+ErEkVlj2VKqNpxT5LTizalSZm25KmNkYMfZ+ZUH5UK6mvnFEKYzcbwojNphXHy+qyu9ClR3GA9ZuENBYp4Vj4fZymeiwMb7PM9WbMtjFfT2iOFrqhHkuQoA26ogykU12pszDmfgUF1qSPTi1eggS9+CvoTvrraZ5n9SfAo17kFIdAdfdWr/ScPG97Fi4dOedPQtIlSFdPc79CMTNekwAJzAwBOg4zw5VaSWDaCQw+6JcNu7tlqH9IWtpi1sFNJxgnQ2pwuD2fnOEJJBZHsZ0PeXcU1ExROwXLoCKtWHbiHZm6honXWV0lwlic/laNNionUkcpo9TKZ9SGATue3rK6CqZyGP+JprB+47JEBc4tNbazIqmzkDXu83GXj85EC/POAuoYdwmS/ltCc92p0Lje0rb0SMva+xX0XHAWLI52KDkthNkIhGgvWhFM0xa5THG6FUwOgQv/mgb13yf2K7zzpz+Sk28e0NmF49J79VZWnHESIAESmBUCdBxmBTMrIYGpE8ASpQF1Hlpb4xkubqDHciE/q9Mwkp07yBrxMFZCOm1P8eSCSanV0qwZ/g6IEsuVbNN1qoMxGI4zFdzInKz2MFZHlc+oDQN2lExRQlldmd7nOIT1q3oy1eW0Qr5c/WF8o0BWJldHTjNa6DVBPspDvjJnQQ1/bXPWUUDLZ3O/Avo6rP9s4Szg3yZckeHBYfnb//s78sa//ktkM5AACZDAnBGg4zBn6FkxCUyMQMeSRdK+tFOamtOZBbNw1LiwyYVEnRlLGd8BBlTWXYBZBXfCbDpEphBgpGV1u6qoIa8YxlumWfnMGrzKG6/T3YFyZvb49YThXFIyozZriJeU1cQxdU3JWcCv8KVDGPvIzbYxLx8diRb6NcpGGciHLs/FnABueJsbQK7lj71fIfSpVlUymf0KWpG1KVqK62yAXvwbgqMwrB4D3PRmzFuMYBs16m2SS6dPy9EfvpMtxjgJkAAJzAkBOg5zgp2VksDECfRevyXrdmy0ZUVmxagKGCP4g5FkzgDUwkpKPtjA7DkwXtxLGHJLxX7NRNqwXpd+gRyUeRjtHEROY53zxut09h3jNPlQzii1+yCjNozqTNKoaFlddpel4jkWuKeSkMYiBfcegt+naarHwriP9Gwbc3UUOhMtdKN+Wvcr6F4F//cEgx37hVAH4oil7Y82e5rnof2IIUQf4toSk0OggqMwNDIkg+osDNk/TcwtwI3Rj+2Z0NIqPDQ4JMd0edK923yUapYj4yRAAnNDgI7D3HBnrSQwYQLL13fJras31Jhogbmv5WFtuDPgBoobLVjeYEFFzG8oXCI/+9K4JMN0hFHkmk0SFk6iDPon5jx4XVFDLZ/zxut09gSMJh9KGaWmLaM2DNjxaimrKzH5UT7HIazfRHGmykJVlToLxW3M1ZMY4qlJnncWIDv+EiQtre3FB3VllyHZfgXk6Z87CHlnAWY8QrGjYGmRl5yjH9BVHALXgDoK/UP60eWEg8PqFOBflf4jbWtqlVZ1FkbgMCRtxT9jaBocGJRDr/9K7t24U6yW1yRAAiQw6wToOMw6clZIApMjMDw8LDcvXtPC2HnQrMdY+KMmhloYWBeNAGPDTBdd0mRGkl7D6Ee2v7chEdTrMUPBAxktBSNpGMr1PxhKpZ0KtKLCukZXMacpeeN1OptiIzNphaWMUlOWURsG7HiVlNWl91aENKYpYf0iGgJFZ8iXqz+MbxTJyuTqyGlGC70myEd5yI/vLLh8Yb8CKjVt6iAkhjl0FzsLyIu2RX0uh6O3Jc7QaO1K0nGdDYHrwfCg3DdnYUge6L/hIf13pZMI0trSLPP0R4BWtEf/QlfUH9fnjxyXc+98lFXNOAmQAAnMGQE6DnOGnhWTwMQI3Lx4RXqv3JARNT6amvPmFowiNzg0XQ36Zv0VE3Y9AmYd7JlJ5gioxaIBRpFvfrZLPcyOgY9Wh7sTNU/fGX0oZ9JWVksx1cpKjSc1+TZljdRRtWTUhrE5SiaTMKYuvXsipDFNCesX0RAoOqPuXJlMfhjfSMq2MS+favY2+jXkozzkIx65U92vAD0z8jI2/Xd2H86Cfsxp0FmGB+rVY2kSSM3TTyto4N+oOQ2YZXDU7tSAlvdy4P4DOfHGAbl5lo9bBRUGEiCBuSdAx2Hux4AtIIGKCcB5uHnpuixbtzpfJrH7zcCynDCv/DGtqWOAdCyPCEfBjT5dNZGkeT5UwKgp92Qlq6LqDt7nyTYrb8xOVgvKTa0dZQ38IrVZQ7xca8vqUsM1G3JX4zgLLlvaWQjjPnRn25iro8AoWgh9OnOlfYwydv8litD1SEfM41oG96iWMwNcb2kzvCELgxwfk/V7Oa5wRhdDX7TZ8y3XakUMoSCXXFticoAehAFdehTOwv0hdxr6bDmSv2MCMx9YFtWi8lZ3OA1IV71YEoV864vGIQPV/X335ejb+3XT9My529YBHkiABEigQgJ0HCoERTESqAYCF4+clfu996wpMDOwXAlGEhwBN3ncEIEjgFkHrJ9u1qkH5OaXE4XjkO8VjLuciQLDRnWP91hW1J3Xn9ebvRpVRzazZuMw8yYfwkgdpSGjNgzYUTJFCWV16f0SIY1pCqzUTMhfeYbL494aHcLwRk5xG/PyoTla6PdqOAuQjSVI0IXcUbMKSNf24mNG9ihnwU1vM8H1vkdNHnfj3PQm/Y1WeAlvWzbN2xBtxpWHwNU/PCR9QwPSZzMLQ3JPHYY+TcM+BndgMLPgGq0dSZvtWUkahzOBpzTZciqN218iE625cOKsvgn6ZFTNMwmQAAnMOQE6DnM+BGwACVRO4MSvP9YXwA1mCrhxpFaHGvhuVMkITCE1/9UIsQ8cCFu3hCVMKAojv7yhDwMu5zxkaisZhZWDukvqTDKLCk64jqLy032ZN3Ar1Y6+TT6AV8mQScZIVhLK6lKzOUIa0xTcG0lIY5HiZ8iXq7+cs5CrI9d2M4tNMXSWcha8HaWcBS0Lw1o/LXb/erugMZ1ZCAchdRaQF+2P9loZLYe/CBGHbMQjL86Bq29YHYVBzCioo6Dxu+YsDNj+IncWUMI1OYukjdhvpDnRjma9tvahX/grzDakQ4NZhpPvHpQ7125GM3gmARIggTknQMdhzoeADSCBygng7dGn3zsiXTs3ybz5bVYQtpSbJTBZEHcDxdZQq4WGazPW9OizArpHQg0WrFZCij83Xp0FFfQ0LWDprgu/AlsGkicV0ILE4ptU+ZkplDdyK60DfZlciDEqWTqjNozdknI2momzWFpAU9OepTFNDusX0TJlUXeuTEYujF4kZduYl081e3/9GvJRHvIRj1zch3AZvGUui+U7kIPPG0a5nZGmf5D12QQvNVP7FeAsYDbhPhyFJH5Hr9EG25uQnLVBGrRF2r7oo7UyuUaaLUnS/UnoF5jg8as246B5moQjDnpskgd37sjRNz+Q+7fuWhoPJEACJFANBOg4VMMosA0kMAECR9/+UJ765meSEjAxfB01HACYHVj+YM4EjBN1HGCg4LGPUwkwesouV4JuVGyncjMZiUCmEa4zkzCFKHQVh1KzJqXkisvlr92Qy6dVfuUjUkK+SC3GaLyQ6iqWzfcqd+XWqKkuLoVEl3VDt1T9YeC7bKohV0eh7dFCv+diVgFl3VD2GqAl7a+Z/pBw5yAxqEs7C4lroTL485IaU4WhL9rr+S6HWhFDKMgl15aYOUAX9itgCRJmFLAM6d5wv9zRWQYsQ8K/JxSFNt/Q7OxcP5wGd+qiHagPcci3YCZQC/kSJex3QHrkRzxtzPmjZ+TMW4fTBMZIgARIoAoI0HGogkFgE0hgIgQO/uzX0jrPTTcYT/qAR7Vk3PDAGhC8uApn/LqJl7vhr0WvLY4pBQtILd6VAPMm8hOxzAk1ljbGsTDKvIZJOQ+ZKgrRUvUUMpNI3ngtzoWR6O0dT250SXCYfADZkiGTHAZsSblMYlld1jsXzPVPxzsb8ldZeTd4s7KIh8GLeHEbc/UU+hgthD69o7RCnCFbbr8CzG7ko6QZ1dpmlDFnwVJhlCPPUjVPz4lB7nG/t9HGbHuhz0t4r3GNgDSEuLaL5BC4+tVBwGxCn84kwFHAEiR8BtRZQJ8KbdY4HAbTlrQbV6jF25zWY21RWdSButHWFvRJFfpMhcY1DX8o61pctr/vgRz+2a+k767vZ7JMHkiABEigCgjQcaiCQWATSGAiBG5evGpvkt3x3GP2C2aUNQNEjRCff9BfPmFsqZFihooKwZAxY05/+YRJDUcCZko8ltWWLWla8XKl0J815lFX1u2AbnMeEuHi/NCB+sZyTkIujNRsnciL9JAb71y5vBtu4+krl4/+lgyZZDCqJJTVlel9rl+J0Qnd5WqAfLn6s8Z3ViZXhzU8tKOFHod8KWchcnFPmVFt8l7OjGVtc36/gkrBqNZ0/BU7C778x7VGe13O5a15esAVAtoVcUvIHAJXzCrc09kFOA13MMswOAA3vBAgmzLRC1dv7Yx0a621G9loOcokbUjSYxkV/i226Psb0DabebB8lPJN0lHxgwf39aVv78rAvfuRxDMJkAAJVAUBOg5VMQxsBAlMjMD7339DNj/+sMxf0K4FYc1klyvBEIFZjzMMfBj1kZaa+zBWYJiXm2NAWTgDZiupgWPy5nRoIdNYwnmw2Q7kjxW8vWNJRB7qnLmQWIGTqKCcUWqqMmrDuByrijF1GXUvnWOh4xEhjUVKyPuY5VP9KoxvXGXbmKvDR94KeBu9JshHechHPHJHOQuJcWxLc/Rms1/mUW+SrgqgUduhmlUJ9IShHW1L64Ccy6NhiEXIpkdanKF3WD1i36+gjsKIfgZ1CRKcBnUWbB+PCkd9KIcy3j+7wiHJ9zrdYUIa/o1omt77KB9M4ox3Nni6L08qPEnJUt2BSPuHUiLHPvhIeg6csjgPJEACJFBNBOg4VNNosC0kUCGBAz96R179n79pjgPMEixXgiFjBoxGYJQNJUaa7X3Qnc8wTiA7kux4QDrcBhxhrsSv+zCYYkVTNh1NK75G2qgAhRrw6ypC6qrYZXJIhDR39kLUObkas0bqKA0Z1Vnjc5RcklBelxuOUS53hYEplI9YenZZN1zT1DQWxilSsm3M1WF3AySihV6n3zseh3zoQkqqyw1kK6ttHXtzM2RdD2oqlLR7NK1TRawlqCNtUbQjkdOcUgG4BnW/AmYU7AlI2NiszsJtXOsyJF9yhAry5XHpSVFnnqnne5r3PSUPLtDmj1wFG5VIZlJi1sS4WDpmGdA/Zxj967tzV068/r7cu36rVLeYRgIkQAJzSoCOw5ziZ+UkMDkCF4+ckVP7j8ijK5dIS+s8U+JmDgwan2WA8TKMX0HVgG/S5RHN+vZa/LJqv4uaZ6CbPbXkECwhOBmmBYY8NlMjjGXUQ9q3Y2cdA9SdXbIELWhXVgZpaYDZhDBWXS4xuWPon2zpMuUzyW48jq8/DMPRkk4e6WkskcLYRDQimbPL5w3byA7jHtfFbczXE3VEC5N7SJNRDrLl9yu4DEqa0aztRRlMPOVmFirYr4B2Rpuhz/To2dKTc/QD+cUhUPl+Bd3MjNkEW4LUL706q/BA9ytEsdinEDoKelWt6wlC3v9og+1NSCqKMphBsHYXZhygBInuDiGKf4vYZ9SiCtypaJJW1WO9tLPGcVZuty9fk49+/A6qZCABEiCBqiNAx6HqhoQNIoHKCBz66bvSvW+XLOlaoQVgnsRyJZg0vnwC5o8tU1KDBC+Dg1WEXDxlCWc3/bOmvuuBEVO818FyrLwv+4DJOKbz4KpUppIAYQQ4ENmC2bgJVHAIXRWIlhApZZSaWEZtGI0liueSyuoydi4aJqrXkVaSxnIqk5KpQZvNDcMbadk25uqwAqEdLfQ45HGL4Az5cBYid9QSJJSEsZvcE+YsIA11z/Z+BWxsVufANjXjKUjqNMBZGNQ7PEJhhiFJSJmgD56IczG3yINE8EVZT/d/aTGbgHsXf9CBpVmQQ9z2Gen0gvFCnsloTlF9eJHj0V++L1eOn0d1DCRAAiRQdQToOFTdkLBBJFAZgaO/3C83v/k5cxzw2ybeIo0XvZnhhlkGtUpgsPgZRko4E+owwGJJNkm7sYM5AZSE4e7BRPQShk+4FiEBg8hNMo9pLVoyLVsogwIaxl625DJ+TApYWyI90uJ6es9oe9mQyUKfxgtj6jIz0jWAWiEAdBLSWKT4OQzQfKpfhTGLq2wbc3Vk2u5t9JogH+UhP66zgHtK/0btV4B+5CX5vkQHd9bM7FeAgY3lR7axubBfYVBuq7Ng93ACMs9AszQEo+h3pIXTlA4HeoqQd9LQd0/FWXuaXAc/5NkL3qycs8LsApwFcxg0bq6FnRHXv0RH742bcvBn78iD+w+ghoEESIAEqo4AHYeqGxI2iAQqI3D2wAk5c+C4bNyzU5p1KRJCYoaoIYKlETAEW2x2AQYL5hhazLh3Awbvn24252EocSQg4Q5BnN30S9O9DujVNLW00t9zve5i5wHy5nTAxtL2oH0IWTlLmOVDtKNktd5Eywojs6Rcklhel49JlM1dJYYi8jLVhaiNA3JyZQq5mpMpn21jXj40Rwv9GmWjDORDF3Ij3Qxia5mWVXncPzjbrALOkMXZ4nATXA9yLA5Nmhf6EEfwfBzTa6QX5JJ0pGUDimf3K/TZI1MHbL8CZhkKQeXyDAo5lu5L9ZDmfYpcOA1oI1zfaFvoibP11ZttUsYoccajrP0PVfXgL5YwgY45Wpreov8ebdmSSTgf9C3C9YuX5egb78vIYPbZTpHLMwmQAAnMPQE6DnM/BmwBCUyawMdv7Jdtzzwi63Z0F3TACINh7gYcfvHFtRtKw2ohId2v7Q0Qeu2WS/bN0XAIIIc9Elji5MYT3jLtASkjTfpKOHMeTNIyYDAVOwXQn3UeIBjGWbGsa5+ZY9Q5SnvGcAsWo2SKEsrqSkhB3JllCmYsxEyVBQGXD9aFZIuE4R2p2Xbm6wnN0ULo0zHRZJwhG7MK0IUUX4KEK8RRXlO1rYibsazWtDkJkND0sd6vgFqjPdFmT8PR2xZnryu9F9CCCIGqX/clpE9C0vcr6IwCNjcjHSHux6gzysc52oBrb0HwcQnngsy03cgJfcassMbJZdwlCBbQOyJ4cpKekGiMzFHQNLy3AY6COfL2L1FbgbrA0ap13qgT/xa+/y+/LX03+KZo8GAgARKoTgJ0HKpzXNgqEqiIwIm3Dsqhn/5aHYdNap74ciVYJLZESSMwWmCQYIbAnQW/btKnzbjJiGcswUyCCRaLlWDMwApCgKGjZWE8mqlT7DxoOjI1F0ulkhJ2Ro0RULbgPESiZrv55EZTJOfP2bbkcyq5Cv2jZKG2KHj/ihIzl2V1GT8XDIPTrsL61YsS1ZmIy+eNVtekZTLls23L1eEVJUXQQq8J8qWchch1ZyF1FKwkjFkVQFkd8oJxO937FdDYaGfScDtFdx/gZWzqIPiTkNJHpuKNzsUhWDiruN9S2lluqDXkwQZSMOARckfLC1nkpHHE8HZoK6NZ9uAB1QG9UOVOgXNF3Yi5E4HZBv8YX8vLUzj61n45f/C4DA1kZlCsJh5IgARIoHoI0HGonrFgS0hgwgSunr4kr/3b78pn/sFX9CEubhbB1MEvnTDcw7BpGsESCXcemnR5kuWapaPGDoxETYNhjyR4CdBkm6o1LdwBmPduiEUaTCpNRaHEeUh/A9aMohBGnDkQyLPCLhQmVNJCS/Q4ah07ZMtCMq5HlUJ9JUK0q0RWIWm0zjBBlV1BSiMG0BPKVGfy5eqszFnIakbL/Bo6ozzaFDMLkTvKWdC24s8MW9wDdo3+aAnEk3wzg5GkOv3XcxjErjXqgx6rP9KTM0hk03GdDVqFjq++X0GXG/nMAt7grE9BwuZm/WAvQ4SoEyVwT0bdnu/tQTyVw1U23TKRaKlocwToSscR6Z6XpifSBafBrz0/iSezDa1aFpzCaQBXe4JS8ESnUYOdPT7w4IGceP+wXP74tOXxQAIkQALVSoCOQ7WODNtFAhUQgGF1+ehZ+fVf/EL2/cbz0tyOf9IwRjB7oH9qnMApaNFlRTCpYByFA4HHQyKoeWZnGDyQwpIlJMHQdOchSUOyORUu4A5FUpvVA/kwv/x5TVAMwzAbwrAbawYC8m6OpeesjlLxkM/leRdzSbiINozKyCSM1hd9Q/lMSAxBpJSqzmWzhmmmLMpkymfblaujoDla5TWF4QqNkA9dyE11memPXMuvaL8CtKkSW6cPTRjfpA1pHZ6WtsjbVJArtFmrzgR0F/sV+nRm4b46B/4ytkF9ElK/vV8hRE2bsfH7J72LUGPK0+9sSHv9GZymKssx2oqM6AfiWRlcw5lCyDJN+4WYOtEqYyxVzlqkzjqWLLnToHnqSJhTpnKoC7IoiT8/WxVWx8XjZ+Xd7/zIE3gkARIggSomQMehigeHTSOBSggMDw/LW3/+E9mwZ5t0bV9vxj/KuXkDg8VnE/w30HAcdImSWmJN2Keghozvb4CZhGt1ANTQwY+97jy4AQVXwEP5mQcsW3KHwnVBHoYSQikHAs6D1a/ngnqTLjrAaoQanBHSpqRxz8kdoXsiIdrqZVJzMo0l2pRPhDQWKc4LDRtVzkS8RKjItjEvH5qjVW5wllqCBLXI9VkFXKXOAgxc1AHjNb8ECWmW49KaiZqsJGQtDl2qO2msp3mepasMQvQh6ZmlxSEpKgMjul9BZxawBKlvRM/25uZBe78CltIhYNIM910EGNt+38V9EjnpGf8TS3xgS8wyRHqoQ3q0JUqHrLc/ab2eIOd5zg7ylqsZLRlOrkd5xF4GyJmMOxAFJ8IIqS7Ni7FINNoTlD74wS/kyrFzro5HEiABEqhiAnQcqnhw2DQSqJTARz9/T46/fdAcBxh+tt8ABhCWJalz0KJnWI0whmCI+TVmEkbsl1BYVzDsIx9XMJT8iFYkeZpo74Owa5cYNfNg4vnZByTB3LQsLRshDM44RzrOhSVNuPCi6RlpCJqOsiFbSo8Llj9Gu1zCzUXE05hewJLMhPxVmhFlRrcjLRFGOEqN/gIOuWiVG5qlnAWXxGiDp5n7ekY5/dNM1IN2wCaHwQr5sfYrmMFrUl5WxVHadSTpkYZz9NE1IyUNgQv7Fe6bswCHAS9lw56FQXUi4q7xukIHUrGnJoL1zC6TPRtJlvMIKRTyOIpmnQikBm8UjXqQjvbHeIWMSaguT0+UWjnXg3TXERL6b0m9HTg4tofBdEJCdcMpUxCe7jKWo2pdB1ohcvnsBdn/g19K321uinYiPJIACVQzgdH/36rm1rJtJEACJQnA6Hjrz34sO1/cJys3rjUZmD0wWobUkoKRBNNf30GlZ3cRkAIHwsyjZCkTZiHgdiD4kiWUMgkzzhH32QlIRF7MMsAgQqoGrddMK5uBQCxjKCb6imcgUCwbot5sWrn4RGShI2u4uU43BP2Y1BLWr8knaSVO2TL5djg3FAnDNGTj7MRCqZmVdgE92TKT3a8A/eY0aF/wZ+6FWteI49dw1BFtjvpczuWt7SobwdqVuY50k1MxjP39xFnA2Z2FQenVWQYsc/PZhLhvvHR6ZyDdWcWsgzkBqtdnppDpZXCy+8wvC32w/EQmyTKdUSr6imv0FzpQJ9LD4fCxSe5fTcdtYEyMIWSdAjKwlCvvNODfWHyccZZzMb9h7ehr//F7cv7D46qJgQRIgASqnwAdh+ofI7aQBCoicOztQ/KmrpP+7D/6mrQtaNcybl65UaRxzDqoqYQ5huEmfXe0XsNYQoq/KM4NJMgVOw8wNVEaRp4tX4I1pQEGnhtebtwh33MsW/UnBpjqdAMxNRNhjEUYz4kIuYmcQ7/1L1NXsQ70thCSfuE6bV0h1yIZ6eQ6K5nGwxAP+TinmqOFXiZrxEM2ynsuWulmLsYTOpAPoxXn/KxCkqZ5bqiqNi0ymf0K6GCxsYu0CMAF4xdOwoNYioRlSNjsPIT3k/t4Wx+MLfqgV8kJEbQL91H01+6hZNbBymm+9zlq9TMYxd1kqi1Z+14Q80qyZbNyKB95SPdyfr9GW5CKPMjBAQgpPKEVDhkcc5PRfMhEmp2hHzKa4/W4rtCBdzV8+NO35eDf/FKGHuDFdQwkQAIkUP0E6DhU/xixhSRQEYH+u33y5rf/TrY+s1seeu4xK2NmlNo2sWRpGE6BGmXYGA2j3n7jHVYDy2ws/K7rMwrlnAcXhCEFow2GkJrl9lNt/IocpqI3GWYVVMP6QhnodWMvTD4kuunlMchbibgc94w+Rhnrb1EJT/MWe5a1xKIWM+PPc9DeUiEt4UZkKpMvEQYn5LNlwlhMe+qGJtClxmvCSMtCa6QjFoYnDFHESzsLluPSOi7ot5XUMh73VkcbPc3zkIMYQtQb15aYHAIVNjc/0Hcp2FIkvGtBnQbMLvTrB8He/WHCcAvsneauPVGA8cL9B/8g6yigLLjh3srzQ46Xwdmv0ha6bH4sgnm0GWWib4iDAzShbDCxdCMRLFAC93ZSgyYjxRw2ayPagBkGZ21Ogu13wJOUIIV/b5BJy1gd6induHhV3vrPfyNXT5xDEgMJkAAJ1AQBOg41MUxsJAlURuCybrB87d/8lWzds0vaF3bYHgaYQLFkCWfMNLQmNhZ2BwypoTOsdhGMOP9V2l8MV8p5CAOtsHREDaJ4SRwMOjfMRjsP0XqbgcDPyyqZdx3Sq9QcjFLjn0uX8daitMeSa2WQDfmrNCct7cZimpOWyBqckM+WCcMVZy8BM1L56wXOkI0ZGc+HeepsnCPK6Z9moh6kYYzcEMVZUzQdf+4g5J0FmK0I0UaXS9IiLzl7fWlLrWByCFzYlzCgswiYWYDTcF/P9/V6QDfnp3tMknHVpW9WExxUa106vuaeWrutcXrPqUNgzqdXiCjS0NdMMoQLrXZJ7wviYIkanClS0hB9Q0rE0Sfojus4Q8ZrgcEPnvpJGEf5wiyPpbvTAIfBnIZkv4M7Damz4GPmdweO9/seyLv6QAPsTWIgARIggVoiQMehlkaLbSWBCggc/MHb8vp//L489zuvSvuSDi0BUyiMehg4HmCk2h9+IYW9qgY93vswqNcw/X2PA0xSN/pwDU1YmhKGmhYy48tkXYXleX7egUCtZuqpwWXmsTkQSIXR50aVX3lKag7iOq0xlYlYlA3T0dMj1a5gKSYhjUVKes6WyRqTSctNMAzxkI1zVsZJeU3Qky1TmbOgRicMUzgKXquxNwPUDNbRzgLyos1RH8bL6nfypiN6m02PtDgHLswswDEwp0HPD/TTr87CoDZsKLkvWnXdDvbGxKN63Ynwu2Y4cSAw4wUHE/cLDG8MfTxJyVglg2K3hMYhinsq+o5yHiDocZ+x8Dj6G/d1oiqRhw5PgaOAWPQNbBA8P670WgUwk+bsXCLG2BhrfrDDGIXTgE3SSEcaYjbfgLjV63VBG+7S0+9/JG//2Q/l3s1eJDGQAAmQQM0QoONQM0PFhpJAZQTu37svb/yXv5UV3Wtk7xeeSwrBGHJDDCYRZhNgnZkth/0OauggDMHwwVGFBxPjLZ15wPyE/5IMHe5euEEUcdSBEEYktMKQdNfDsuxgYioc5qDVnnEkvKXFDoW30XWmujzVZWHYmVWK7GgMoviofhib2RBlIy2MTC8RqVDl5UI+zqlcGJ4uB/nQBdkoH1rAC310GYwNuPsZY2LGKyQ0HXn4c1k9qhKfGUI80rN1eBrKIMQZcejIXiMtAvSiVUPKaVA/cBDhEOA+GNABHNCSw2p9N7foywTxVCQIa2Nx9+AMeYw7+mGzCpqN1w7aHaC64Twg4G5AXWk7oMiDO6caV4FwBCIPXGD8o2ThCEUanA1i1ihELJi8i1iptM4ok+hSPTGmUIk+QALBxg+tNZlgq46BXtvYgEmSBycC73JAGyMNoxxthr47127IT//dX8rp/UdwyUACJEACNUWAjkNNDRcbSwKVETj94TH5m3/5bdmlT1lasHCRmmow+BMjSQ0ZPKLVnQc9ma01pIph4MA6w1mNJ7XUmtVAHEQxS8O8gP9yDJMf5VzSHQOPw0z0ekyJysGoQ15ZB8IFzai3qpJrnEwnKoI1h5DEo664RhbSTCpkkZgJ4TQUympeanBCMNtuGIVp4Sjj58jIElUimhz6ULYQz9WTOgthWLrxqfJaCJrtbPHE5LQ4GEIj2uU80TrE7azpSW7hGpG0DS5nmckhKWqmNrDCWdCTjTWWDsEJwDg36T1gbz7W6yH9+XxYr9EOtNNmFzQd8wu2ZE3l4XigXncmoTChpk2AfuyzyYZwJLSYSZqx7y3JiDkbVWshdSKUgZaLvsQY4hrOqrXTClnPrF2h1Dm6wiiPK2fmbcQROvCkJItjdg4pWsBmGrQvWDIWMw+tJoe0RJOp9zpQ/u6tXvnr/+s/yfvffS2awTMJkAAJ1BQB/Kjzz2qqxWwsCZBARQRuXbom85csktVb18v8Djxlyc0qGEJmRqk9A9PQ/4Mx5MaVS/kxjG2TUaMIZUOPRROLq6AzqcMMJxPFIcq4cRvGbNRmCgtSLh2l7Kx1FK6zcZQpuo66Qmec3QD0XO8FdBa0Wu2mC/rs40ZsSESZNBUp+lFZGJU4u8EPh8t1I9+XscDURAwGph51SQsMTEtNzlgT74/xxLnVdKTXLTJP86HflsNYXUndSR3eGhy9JpxRX7QkOGhRbavI7Ws3pe/OPZ+BaZmniZgbwG/lrXpPJL+3J8LWL2hSZ9ONZ8SdDK5Noen12goOlKbFfRB8YOWblJa35UCJDNJC1mvHWGX/ohqkeRz14vHC3kxNN53B30cc0hEzGibjsrhOmw9ukEYayOHoLK3/GKdkrCxd43AYWrGnQYvoiNmYWn3IQ1nUZfq8Df33H8ivv/sz+fH/86fSxyVKxp4HEiCB2iPAGYfaGzO2mAQqIjA8NGxLlhZ0dsgL33xVWtvVQIQpo8YbnqpkRnBm5gHehO1VwDIUGKowenQDLN6Ki+UoQ0j3UvprrhtD9ouzGkixNAn6LU3lrbyq8FJW1CYI4K4gD8aZy3oejlnZNLXyWPzKHYaf60zaUlCDvntwA9jjKBPB2h4X4GAfo2eGauRr1y0UrrVXEccZvXSD1vsL38zT9TqMWJOCnBvV0IA8yCFEGxNtptXSk3zEQyfixQFtxPhcOXNJPxfl2ulLcu7QCbl2pkdWbt0gT33tc7J13y4thvr03oC8xm3ZmpbzMVanYaRVN9LryGsanAi0F0uZ4GpghmJI7xXcP7hz4CA0435SjXGGHvQN1WAGDHVY0LI+Z+X9QFr03Z0QtL8gqhEvlz2GvOchB3X5lTkkXjxfFvyTdGtXIY5yMPw91cYPLcKYaIPCgcAIoV70F2m4xsyMOT6m2+8oHMHhwtHT8saf/EBuX76W1MQTCZAACdQeAToOtTdmbDEJVEzg8uEz8r1//u9knRqIuz6JR7TaohI1gmDgadClFjAAzTJT42eeRodg26mTEEtKYCyKLU/xZUpwGiAP489NI42rQhinsO/cUAqTzA04mGIwnqwujYch6OXREA9xXexQRP7oM+pxqxKmG0LosAu7Rnq0B21I41nZKO/lvAyOSMfMS8hG8ZAPAxLlkGZ/Jq8xPbvBiRbony718V/Uk1JaAeowNy0pAz3RRpQJnZZu0oildflV/og2Dugv3OEs9Jy6KOd0+dq5/Sfk/IETNlYo0Tq/TdOOymf+6Fvy6PNPyLz2+a5Iy6O/IGttwH2ROJkFB0cdBfzqjr0NuBfQM8g027XeC+YI4azKNA0OBMKgavV9AO5AwMmwewogEhnI4W5CEkKWh6d4yzzuDKMoqoux8fzQAj2R4vyjPPpq4wMlOkY2bpbmM0P2nhMbOzgJWlb7jXEMpwFncwShRfPxlw03zl6Wv/nj/yTH3/xQ/ylFS7MSjJMACZBAbRDAtxu/xWpjrNhKEpg0gV0v7ZPf/d//F1mzYyPWciR61GBLjDwYflibPqR/tikWMXMekIbHs3o+TDw4CDD+8MWBOMriaySM/XAgPC2a7F8zkISRhnP2q0fVZELuIpM+XjTtFyTD2ITuiCM9HADEYS6m1yjvJh/kIz1fFvmeE8ZpGPZeRvNhOGqdWUPSDEtoT4xK/63a2wtDFCHq8RpwTNKTc9QX6VYoOSQq9Ck9d2xWoefsRcGjeS98eELO6qfn+Lms+Kj4gsUL5Sv/9B/Kk7/5sixasRQYCsFGF/dCMsZxz8S9gvGO+wP30Ig6Dyar8SiDuwXjgLIYdxwRIAmafj9k7wjkQsobgk3ZLpVKx0wC6gg2KJUNVjrpi5/S0YNcYYy1nhg/pPk4qXOgTcCMG+oqOAcW12tb3gUHAmONFsCpQItRk9c2ok+gOn/0lPzFP/9Xsv97r2s6AwmQAAnUNgF8u8V3eG33hK0nARIoS6C1rVWe+K2X7a3S3Xt3FAw1/PMPQxAGGJwFmHt4DCcMQxiC4Ui4nBuFMP3wiE4YjQgoE84ANHiaG4t2kaSFjKf5MYzGkIPRjZBP9zQcYSQn1Vocabh2wzspnBhuyEMIA9Gv3KjzdI/D2IPeMEDDiA+Z1NxELFvGr83Q1KrDWfClK8hTafvlPYlr2UJ5rRB1IqB+pOMvrnEuyCbplpkcouyty9fNWcDswsWPT8v5D4+bs4A9LhMJHSuXyCe+8op88ve+KJt3b5fm1vS5RhhvuzMUdDYOh6HgOFgcT2WCk6np2m+MC2TinsAZaaYDEQ1+zMcsQw/xCNeCkOJBMaOUsLM8gxGagqJrwRikd5PGVUwnDzS4XMFRMB1wEJKx0GvMNPjSpMQp0DTsBik4EpC1NJWFvNWFcfMae/Tlbt/7P/+9vPtnP7EZINTKQAIkQAK1TABfn/FtW8v9YNtJgATGITBf9zrs/vzT8o1/9oeycu2qjHRqFMKwC+fBDEA1+bC/AU/SsRkJXZ5ihqL+qgzjz2Ye1JIrdiCQG/sNkJd+ySDmXzulnAg0arTDEGUyTU6iYaDhEvFSIYxv5EF3XJvZqE2xczZdDUAzJvUYsjij1TAOLW6L7zUNRqPGLc0MR8T1qoSzoNnQoHlep+u0RGTk2hFtsozMwXWILUG6qvsVrpy+KOcPndRlSL4Eqe/23Yz0xKPzF3XIxsd2yIv/4Kuy98WnZcGSzkSJjyBG0h0Fi9k9gbvH98AgDXH96HIcv0ruraRcNg0OgN03BQSQLRU81cfO8yOelU/HP41BGlchH5TBHkMYsz0+Fu5imAOgoG0/g8rZbIJe29IkOyPmDgXKQadvhEZt3hnUOdDfL3/xf/xb+fm/+XO5d+MOMhlIgARIoOYJ4FvO/49Q811hB0iABCoh8Kn/9evyzX/yP0hba5saVGF6qdGmlhyucDRHwWM6+4C5B+SrO6Ay5lDAcUBc03GGo4CPGYKhwxrjXy/IQ0B++oWDmH8FhWHnrUklrFDFBzfaIJ41HWHkhUZIwDDMGnguH/sY3BTEETpwhDiubZ27XsSsgqXpNf7cWXCt7m5YSSuLVOhwOZdHnYhFMF2Z60jHGWUHHvTL1WRzc88p3dz84VFfhqT7FbAJfrpDc0uzfPGf/IG88ge/JYuWLs6ox32QjLWm+j1gI5/cCz5LFfcFzrijhmz2Ib1XcBfYvaa6POC+ijhKRByMXDYRHPeUHXsIB2cwNn9Pz5CJfSuFccFYarW+7MjHD0+/An/MMthMhF5Aj4+3OwxeR6ZWfUne1QtX5Ef/+k/ll//hr+U+n6AERAwkQAJ1QsC/leukM+wGCZDA+AQ6VnXKi//tl+X5335V1mxen7OyYbD5jANieBEYXAv/FTkchwHkqJGHp+jYGUZhkpZ1IML0Q3kYfwjhQCBuKaon5JAWcjD3EA+TGGZZNg5JXMOIy5dBjpf2GAxvyHhw+TQeeS6Bh5HCjMRV8iuyGZNqKOKMv8RwtN+ckzT/nRol3KjU5EKdhTTNQ8A1QrQjri0xc4COvlt3BXsV8CSky8fO66bm4+owHJfLR8fer5BRM6XofN33sO8rL8kX/uh3ZPWGdTJPN1J78DHD2LvL4ONv+xt0zGKJG8a1cC/hfsF4YrwTJ8LH08siDn2hP8Ya12l65Iac04OG8hx9TFCy2FnwNC2p3oSNazKePnvgaaNmGbQmOBZRNuJ+rRu/B4fk5AcfyQ//+Nvy/vd+PiNOnVXOAwmQAAnMEQH8Xyy+heeoCayWBEhgtgm0L10k+770nHzmD78mWx7ZrtX705bwdYAvhDAKY+YBJqItVTKzUK/0V1VIujGocRiGiQOBHMuFkZgYg/4l4y5EfOWE4Rh9h4x9IeXKJGmJUPYLC/FcMMNP5VEvLG8LMBzT4Aa7H7GcKAz4mCVAbWY4Jsak7VVQXZDDH3ThmO5h8HpQXeqEpPKoGeUQoq64tsTkEM291XNDribOwsWPz9gSJCxDuqm/YM9FaNP3f6z/hC5d+r0vy97PPCed2DhdCD6+GDfb64A7Qi/c0XQnAXHLx2yVyo1gyRtiKoj7RbPNkfBc3Bm4dyKghIkmCbh2lpD3cfXH/0bc5FUkHXMfM6QHdxtLBQ6HIRxCT8PMgqYjT/9wT8T+BR9/v/YyoS/Vj38fJ359SH7wx/9ZDv/oHem/24dqGUiABEigrgjgW9i/neuqW+wMCZDAeARa5rXK1ucfkW/9iz+SDds358RhwJkRByNc/+BAwFizja4w+vQKz/BHzH9p1nzIIi/jQMCIhyGIsqWcCBh4eQcC8pP5WkoNuLQjbmTCAESwKzMKYVjC8EQ6TEQ9Ih1Pz9Er7Fkw56FgQIYZCRnEPd/KulJLc+MSNYVWdxYgXyqoKgtX9VGdmFW4iv0Kh0/a41Lx2NR7t6pnXfzirhXy9Ldelc//j9+UxSuXWX+99f6/Dxt3jHH82T2CsUzuCRXGVXrt6ZCHE4F7wO8PTUm4QBYhe8R16ljgykPqKOA65Q32kWdjl3EWIOljplI6GLFPAU9PwrXfDb4PAnHTY+nQ73UgDe2+cfGKvP2XP5W/1bdC9+pmdQYSIAESqFcC+Pbz7+V67SH7RQIkMCaBLZ96RL7+v/1DnXnYIW3z28288wJm1qXLTfSrwmcdzPzTOH47huugXyKFGYjUgcCSFJdUKf2WCUPQ0uxbJ0zC1BSMmG+szn495eMw1tzwdgMO7Q0D0dvuV5argjhDJ45h4Jshac6CmoEFgxK/OsNwdFMRJWPpipVTRVbONMK4dN0wJKMlnhZX3po4os2D/QOFzc09py8UHAXMLAwNDoZo1Z3nLZgv2z/9hHz9n/6hrN/eXViy4/8LwT4SHdnCOCdjrwkYb79TkO/3i90DGA/IJzJ+tyVpyNBgToTdFJqbQer3STpjFLAwjjooHlQIY4UQMwsWx1gl90rq9asAACprSURBVATOELcdDEkaZh0wnhjHKBdn1+ZH1yVyo+ea/OT//a/yzp//WK6ePI9kBhIgARKoWwL4BvRv6LrtIjtGAiQwFgG8lKz7uUfkxd//ojz+Gy/Igo6OjHhizmWMO1++hF+P8eUBZyJxIFQGhqGl2dcKjEQ3FkMWJSyucggwICMUYkle4ToEis7ZLy/Ew0jECpgwMgvGvqaZaW/GYWIUZgxDNyAhoY4CTEZVGC4G8mBMQpdvqDVNqFH/IIdjXFk0d4Cu+7fvFfYr9Bw/L+d0U/O5/cfl0pEzOdlqv2huaZENT+yQp//+q3qvvCjLV63Ql4znH9uKMcZslN8dfj/gvoh7AGPuzoKPPo7ItxJ6Riy9L/zaMlEOqKEoCXisarxPDcY9Ao7QEVeF8dF8pKVj7U4iJFPnEFf6Z7IYc5dPStq1Jlm4e+u2fPTmfvn5v/9LOfrz96X/3v3I4pkESIAE6pZAfMfWbQfZMRIggfEJ4Ck6yzZ3yWNff0k++999VVZ2rdRCse8hTEAYaTDJ3BhMHYjUQUCOL11SqWR5E9JsGVMyAwHDHq4GfqPGEUaipekBZwS3DZMLTyp7jJmEEIChCMMPwY8eMwdAPYr49TjkIGNxPeJs+Vre06AL6W5QJposL+I4Z0NStdy+clOu6H4FPDb1ojoI9shUXYJ0/XxPVrwm451dy2XHC/vkxf/+q7Jl764iZzPuEB2/xGFASjiM5ijYtd0ZKoJ7IFwFlwMUd0LBHfePXutAxf1RDpqNN4x+jeBN1Vj2hrFDWYwnXBykIJ51AlMHATkqCx2oRAv6eNqV6ULylTMX5Jff/r689Sc/kCv6Vm4GEiABEmgUAvg2rOz/zo1ChP0kgQYmAAdi95eeli/+T9+SbU8+YiaWzy0ACgw9P5ojYNeapsah7X3Q65hhcJNQZeE8mAEXJcMITFwDc0RGOwpeE8rrR7+lYNjFD82II+DazTy4H2hXYuzpOWTsl2NVEM6Cm42Q05JqhWJ2AYVjXbttjoUetRahO/5Qn9cFcdRWFDQJqdfP9UgP3q+gnwuHT+nL2PDm5mN1+Rx/zFQt6Fwon/7H35SX/9E3ZFHHwlFsCuOoo5M6nRhX5LiTEDLmUGDAdVyQH+ONOweja8fM/RD3BtJ9vDECLhdj5C4CJHz88s6CS8ExQAz3SDq6SMF16Pb7bUjfzXD8vUPyk3/1Z3Lwb9+UB9wAbYx4IAESaBwC6Tdt4/SZPSUBEhiHwNpdm+Tl3/9N2ffF52WpviyuqdWNKC/mpp4bd4i7oWdOg8bd4NMrNdj9l2Q4FG4swhPAn8t4HDrdqFSZ5Cdl6M4HXKdtgNgwbH49x7p2O8MARMFE1AzC5MJMQU03h0BnESDiS1TcvERJlDVnQ3OjLM6lAuzMoYHBwn6FK6f1/QoHjukSJF2GpEuRsJehEQJ4bXrsIfnGv/jHsnbzBulcpk9e8lcz57rvo61jr2OGWSLMOiHEWOMeccMfkh4vOA+WoAcMuN5XuITjl42bq6dJKGM+gJ6LnT0be+RjTO0/v19izDUrCT7m7pC4zrMHjsrb3/mhvPX//Z3cunQ1BHkmARIggYYigG9HfAczkAAJkECOQMeyRbL3s8/IM9/6rDz8yU9Ii65lD0POBd3AyzsQ+EKBY+ALUiAPExHLlxA8T892jSs1AnVWAiEWqyAe0hZxG84TS8XdDNRSidOAWGI5uvEP888XrcQjWJuafG4BhiRi2V+iw1FwIzMqVBUaoLev917yyNQL0nP8gjkJeMfChcOnXagBj+DS3Nysj/h9Ufa9+rw8+tlnZYG+hRrvfsjfM34POCK9M3SgfSM8UnA/+Mj7vgWPB07XgzQ4DsWzTJ4esmHwpw4Ccnws/Z7Qo17GWHu5/Fgjrf9en/To064Ov/6u7P/rX8iZ947I/d6pvZ3b6+KRBEiABGqTAL4p89/OtdkPtpoESGAGCLS0tsjKHevk8a+9Ii/99hdk+bpVauilex+8Sjf33IEIw9B/UU4dBDgTWbkwA/XrBzMT+utxPLrVv5LgUCRfTfothTiMPGyOtVmGgo3nX2FuDCatgRGbsEB6OBHNWo8ZuKYpH3cTMp7SY6VMQ5QdUQv37rWbcmL/ETn1/kf+fgXd3HxNH6XKkBIAr0XLl8i6Xd3yks5YbXt2jyzbsCYVGBXzMcadYTE9ZB3IuJvsnsBMA+4T1YF9EbgRPK5ReAEWVEEyzkkChja5HzCuPtKeF2X8Ku6ZcHQwm/TL//J9ee+vfipHXn9fBu73F1QyQgIkQAKNSgDfnP7N3agE2G8SIIFxCWDvw45XHpNnfvuz8sTnX5T2Be32C3N2/wOU4MskDH53FPzrBWahzzqk12EgeopeqcEX+hIzclS7YNSFgReZbg76lS06gmehUm4WjnYi0pkEdxBcX6olNUKh01t34o0D8saf/FDe13Xtt/mcfoc9zrFV3xOyR2ceXvhvvqxLmXbJoqWLpaVtno1fjGMY6amqGPm4T5Icu9SDOghY1mZjpgPsy55UJus46MjH/9hiVP1egK40VnwfIbdPZxNOqXN49K0PfOPziQv6qGFvC/IZSIAESKDRCcT3a6NzYP9JgAQqILB03UrZ8vxuefprn5bufQ/Jcn0xWD6kRlbsW3DjEAah59lZo5hlwKRCpIeRnnMoIBBGocWhQ00+jdsadzMh/WvMXQU3DGEwwjDED9OpC4FUz0ebc+lRBzIsjMjtS9fl7HvHZf93fyEf/vgduX71WsEpCimexyeADdTbnn1UN9vvkV2ffFzW7twkCxbrRmpd+pY13kc7EVndfpeko+d3S1zjroi4l8pfhaZsfZHWe/2WXDqmT706eExOfXhULn18Sq7p8qRbl66FCM8kQAIkQAIJAXy74juXgQRIgAQqIoBf5BevXSHbP7VHPvHVl2T7Iw/J0jX6PH/9K7eMCYZ+fNHkHAO4DWb1JWdtgS1H0bTUkIyS0bz0ayuM/4KDoKI+YxAyqbOQNRotdZSz4PoH7z3QF3ldlLf+64/k0E/elTMHj8vwUNqaaAXPEyPQ3tkhHYsWycbHd8pDLz8lWz7xsKzbsdmUtHe0J+OW6pwK8RjrrI5IQw3Xzl3SR+VekqvnLsuFj/XpVzrLgKdg3dQ3QDOQAAmQAAmUJxD/dy0vwRwSIAESKEMAbxPe9NRO2fOpp+S53/6cLmFaIO1LFpZwIKAgdQAQS5c0jc7zL6ZUHhIRkIp8BDgA8Vt0pIUzYfnqHCAdsx9wKPwKOaPD3eu9cvDv3lKH4cdy4EfvjBZgyrQRaF+ySJZvXC1L1AHd8exj0qn7IrY/vVfaO9r0Ea+LZKEuaxrWPQbNutwJwfa4FDl6cAqyzkCxkzA0hOd86ZOz8II6fbP5aX0q0kV1EnpOnZcb6jD0nLwgl4+ckt6rt1AFAwmQAAmQQAUE/P/PFQhShARIgATKEZivex7a1Il48u+9JFt1Q+zezz0trW1t+lSdVjXY8TSmrFkHLWH+pzMRlmoGPmKZzdG4HCfk9yWkjkU2VkrF7Z4bckEfn4o9DId1A+zlk+el9+YtzjCUgjVDaXgfxKLli2VIN6Bv3LtNVm9cLyu618m67ZukX9+bsHDlUl0St1L69AlHC5d0yrK1K+X6hR7BHorOlcvlVs919QsGZbG+xfru9ds6hudkQMthY3/PkbNy/vBxuXnluj0hqVf3p1zVDe2D3Og8Q6NJtSRAAvVOgI5DvY8w+0cCs0xgqRp2Szeukkc//aRs2NEtW554WLBMpVUfzdnWPt9+PY73NYxuWjgUyMnH/Sr7lYU4QlbOU8Y6Xr9wRa6og3Dx0Ck5q09GwmNUL504K/du3xmrGPNmkcD8hQvs5WqLVy2VeXrP4OlVW5562IYa47dp304ZUuP/wken9alf62VB+wK5dPSs9N9/IItXLNGxvCvX9CV8CHAwBnX2goEESIAESGDqBLL/F566NmogARIgASVgy4L0l+TFq5bLQv01uXvvDlm1db1sfHS7rNm+Xto6F2jeMsFjTvH8//KOxMRxYp/FyLAuU9HlKXgaFPyKI299KGcPn5Sb+kv17as3pefoOX3/wkm++XfieFmCBEiABEiggQnQcWjgwWfXSWA2CcBBWLhMH8mp69h3vbBHOpZ16pN2dsu8eW2yfMNqWb1prf5i3K/LVpZK07wmGeofkjZd6oSV7IODut69FS5Bsy5pGdIn8vhsw0BfvzopI7osar7cuXHLlrAgH8/gP/2rj+Wj196zF7S1tLfpc/gfyK3L+mQkPl5zNoeddZEACZAACdQRAToOdTSY7AoJ1BKBVjXmsdZ8cddymd+xQDfCNsnWx3fbTMHax7ZJq77tDUtPlm1eLc39I77efc1SEX3CEWYNBnVWoWWwSa7oEpVzB05IkzkZTXL99GVbigQWmPmITdi1xIZtJQESIAESIIFqJEDHoRpHhW0igQYm0Nqma9L7fU06nvffp+vVETq7lsq9a70yNDgkCzXef7tPBvoeWB4dBMPAAwmQAAmQAAnMKAE6DjOKl8pJgARIgARIgARIgARIoD4I+EOy66Mv7AUJkAAJkAAJkAAJkAAJkMA0EFi4ZrmseGSzLN+tn0e6ZYWe6ThMA1iqIAESIAESIAESIAESIIFaJNCij61OHQR3FJY9ukXal3eO6g4dh1FImEACJEACJEACJEACJEAC9UegU9+ztGJ3dzKLgJmEzbJk54aKO0rHoWJUFCQBEiABEiABEiABEiCB6ifQumC+zSKstGVGm2WZLjXCcqN5izum1Hg6DlPCx8IkQAIkQAIkQAIkQAIkMHcElnSvtZkD24vw6GZzGDq3rJ2RBtFxmBGsVEoCJEACJEACJEACJEAC00dgfmeHOwjYsIwZhGTTcmvH/OmrZBxNdBzGAcRsEiABEiABEiABEiABEphNAsu3r5dlOnsQTzPCeaHuT5jrQMdhrkeA9ZMACZAACZAACZAACTQsgZV7tsrqx7bKik9sl1V7t9qsQlPbvKrkQcehKoeFjSIBEiABEiABEiABEqg3Aise3iQrH9umjsI2WfHYdln5iW3S1NJSM92k41AzQ8WGkgAJkAAJkAAJkAAJ1AqBpdvXqYPgzsEKcxZ2SHN7dc4kVMqUjkOlpChHAiRAAiRAAiRAAiRAAiUILNncZbMHKz+xQ1bv09kEXXY0b1F7CcnaTqLjUNvjx9aTAAmQAAmQAAmQAAnMIoHO9atklS4xWpUsN0K8bemiWWzB3FVFx2Hu2LNmEiABEiABEiABEiCBKiawsGupOgg7bDZhFZYdqbPQvmpJFbd4ZptGx2Fm+VI7CZAACZAACZAACZBADRDoWL445yCs0uVGC9Yur4GWz14T6TjMHmvWRAIkQAIkQAIkQAIkUAUE2hYvlC5dYrRynz4CFWf9LNy4ugpaVt1NoONQ3ePD1pEACZAACZAACZAACUyBwDx9szKWGdkjUHUWAcuNFm9dOwWNjVuUjkPjjj17TgIkQAIkQAIkQAJ1RaBlXqusTpwDOAhwGJbs2lBXfZzLztBxmEv6rJsESIAESIAESIAESGBSBJqamvzpRslyI7wrYfkj3ZPSxUKVEaDjUBknSpEACZAACZAACZAACcwhgSWbumT10zul6+mHpOuJnbJcHQWG2SVAx2F2ebM2EiABEiABEiABEiCBCgh0Pb1L1j75kKzS8xr9tHctq6AURWaSAB2HmaRL3SRAAiRAAiRAAiRAAuMS6ND3Jax56iGdUXhIzzvNWRBpGrccBWaXAB2H2eXN2kiABEiABEiABEig4Qms2rtFVqujsOapXeos7JJFm7sankktAKDjUAujxDaSAAmQAAmQAAmQQI0SmK/vTMBSoy6bUcAehV3S3D6/RnvT2M2m49DY48/ekwAJkAAJkAAJkMC0Eli2c73PJqiDsPrJXbL0oY3Tqp/K5o4AHYe5Y8+aSYAESIAESIAESKCmCbS2zbMZBJ9N0FkFdRbali6q6T6x8eUJ0HEoz4Y5JEACJEACJEACJEACGQKdG1frsqOdtom5S/cnrNjHR6Jm8NR9lI5D3Q8xO0gCJEACJEACJEACkyOw5kl1ErCJGcuO9LNgzfLJKWKpuiBAx6EuhpGdIAESIAESIAESIIGpEehYvcQ2MK/RR6Ku1kei4kVrI/p2ZgYSCAK4G0bigmcSIAESIAESIAESIIHGILByT7d06QvWsC8Bswmd3Wsao+Ps5aQJcMZh0uhYkARIgARIgARIgARqg8D8zg7fxGyzCdjE/JC0LGirjcazlVVDgI5D1QwFG0ICJEACJEACJEAC00OgZV6rrH9pj372ytoX9+gm5q3To5haGpoAHYeGHn52ngRIgARIgARIoF4IrH3uYXMU1qmj0PXc7nrpFvtRRQToOFTRYLApJEACJEACJEACJFApgVV7twqcBMwqrHnhES49qhQc5SZNgI7DpNGxIAmQAAmQAAmQAAnMHoGl29fJ+sRR6Hp+t7SvXDJ7lbMmElACdBx4G5AACZAACZAACZBAFRLoXLNC1n7qUVmnMwrrnt0tC7u7qrCVbFIjEaDj0Eijzb6SAAmQAAmQAAlULYG2xQtlg25oXqefNc88LMse7a7atrJhjUmAjkNjjjt7TQIkQAIkQAIkMMcEmlpbZCNmE7CZ+Rl9l4I6CwwkUM0E6DhU8+iwbSRAAiRAAiRAAnVFADMJ6z/5qDoKD8uaZ/VdCgvb66p/7Ex9E6DjUN/jy96RAAmQAAmQAAnMIYGVe7bK2hd2y1p1FFY/+7AsWL10DlvDqklgagToOEyNH0uTAAmQAAmQAAmQQIHA0m1rZc1zj9hsAmYVFm9dW8hjhARqnQAdh1ofQbafBEiABEiABEhgzggs7Foua5/XZUdYevTMQ7JM363AQAL1RmDgzn25ceAUH8dabwPL/pAACZAACZAACcwcgfmdHTqj8LDvUVBHoUs/0tw8cxVSMwnMMoE7py/LNXUSrh88pefTcv3ASbmlaQiccZjlwWB1JEACJEACJEACtUOguaW5MJvgG5ofltbOBbXTAbaUBMoQGH7Qn3cQzFE4Jf13+sqUoONQFgwzSIAESIAESIAEGpMA3tC8Tp98tPYF/egbmhesWd6YINjruiFw9/xVW2p09eBpPZ+Uq+ok3Dx2YcL944zDhJGxAAmQAAmQAAmQQD0RaG5rlfVwEsxZeERWP7WrnrrHvjQQgZGhIV1apEuMzEHAGcuNTsn9m3emhQIdh2nBSCUkQAIkQAIkQAK1RABPP8KMwjpzGB7hrEItDR7bagTuX76hMwc6g3DwZLrk6PDZGaVDx2FG8VI5CZAACZAACZBANRBobmnRF6/pY1J1VmHdCzqroE9BYiCBWiFw+8RFufr+cfvYpmWdSbh35dasN5+Ow6wjZ4UkQAIkQAIkQAKzQWBJd5ctP/JZhUelY92K2aiWdZDAlAjgqUbmJLx3XHo+OC5X3j8m/bfvTUnndBWm4zBdJKmHBEiABEiABEhgTgk0NTXprEK6V6Hrud1z2h5WTgLjEcCm5WvqIMA5uKIzCvjcv9E7XrE5y6fjMGfoWTEJkAAJkAAJkMBUCSzZ1GVLj9bqMiRsbu7YsGqqKlmeBGaEQN+l67mZhKvqLMzFcqOpdI6Ow1TosSwJkAAJkAAJkMCsE1ivexTgJGCvQpdubmYggWojcF/3H2C50bX3jvlyI51VuHv5erU1c8LtoeMwYWQsQAIkQAIkQAIkMJsEFm1cJeued2cBDkPnptWzWT3rIoExCTzQpUVYboT9CFf1jJmEXl2CVI+BjkM9jir7RAIkQAIkQAI1TmCt7k/wx6XqWZ0FaW6u8R6x+fVAYEA3KbuTgD0JxzR+Qm6duVwPXauoD3QcKsJEIRIgARIgARIggZkk0Ll2hToImVmF7jUzWR11k8C4BIbu3rfZg573T9j5qi47unny0rjl6lmAjkM9jy77RgIkQAIkQAJVTGDNMw/5C9iSl7A1tbZUcWvZtHomMPygX5cZndDlRphF0NkEXXZ048j5eu7ypPpGx2FS2FiIBEiABEiABEhgogQWdi2XdYVZhUdk8dZ1E1VBeRKYMoGRwSFzDgp7EtRJuHb4zJT1NoICOg6NMMrsIwmQAAmQAAnMEYE1T+3Ujc3JuxXUaWhqmzdHLWG1jUigaWTEnm7k70g4ZvGrB041Iopp6TMdh2nBSCUkQAIkQAIkQAIg0NreJhtfeUzWv7JX1n9qnyzevp5gSGDWCNw7d0Uuv/WRXHr7I+n51RHp0UeiMkwfAToO08eSmkiABEiABEigIQl0LF+kjgKchcdkg34WrFnekBzY6dkngHclXFYnAc7C5bc/ljsX6vMxqLNPtnSNdBxKc2EqCZAACZAACZDAGAQ69d0KG1/eV3AY5i3uGEOaWSQwdQKDvX2JgwAnQWcV1FkY7B+YumJqqJgAHYeKUVGQBEiABEiABBqbwPKdG2xGwWcX9kpTK82Ixr4jZrb3vfro05hNuPTOR3L9EDcwzyzx8bXzX/z4jChBAiRAAiRAAg1LoOsT22W9zixseGWfdOljUxlIYKYI9LzzsS036sFswtuH5V7PrZmqinonSYCOwyTBsRgJkAAJkAAJ1CuB9S884jML6jCsUMeBgQSmm0D/9d50NsEchY9kZHhkuquhvmkmQMdhmoFSHQmQAAmQAAnUGoEWffGaPwlJ9yy8/Jgs2bWh1rrA9lY5gVtHzvm+hGQj881jF6q8xWxeKQJ0HEpRYRoJkAAJkAAJ1DmB+YsXqrPgm5uxDKljw6o67zG7N1sEmoaGdKmRLzuKR6Pev9E7W9WznhkkQMdhBuFSNQmQAAmQAAlUE4HONSt0CZK+XyF5dGrb8s5qah7bUqME+npu+tOO8EhU3cR8Wd+fwFCfBOg41Oe4slckQAIkQAIkYASWbl8rGz/l71iAw9Dczjc389aYGoGbB0+7g4AXrenn1unLU1PI0jVDgI5DzQwVG0oCJEACJEAClRFYtXeLbNC9Cut1CdLal/ZWVohSJFCCwPCD/sLL1eLdCf13+kpIMqkRCNBxaIRRZh9JgARIgATqnsDaZx9OnoS0V1Y9uavu+8sOzgyBu+evFp52dAUbmT84MTMVUWtNEqDjUJPDxkaTAAmQAAk0OoGmpqZkc7O+Y0FnF5bu3tzoSNj/SRDA/oSLr30o53++X88H5NYZLjuaBMaGKULHoWGGmh0lARIgARKodQJtC9ttVgFPQcJ+hUWbu2q9S2z/LBPov3lHLr5+UC6os3BBnYXrH5+b5RawulomQMehlkePbScBEiABEqh7Am2LFsjmV5+UjZ993JyF9lVL6r7P7OD0ERi6e18uvXlYnQQ4Ch9Kz/vHp085NTUcAToODTfk7DAJkAAJkEAtEOh+9SnZ9IUn1Gl4Stq7ltVCk9nGKiAw0j+gexSOyIVfuKNwUZ0GBhKYLgJ0HKaLJPWQAAmQAAmQwBQJrP/ko7JJHYXNrz4hndvWTVEbizcGgRHpeevjwqzC+df2y/DQcGN0nb2cdQJ0HGYdOSskARIgARIggZTA6se26cyCzi58/glZsW9bmsEYCZQhcO29Y/bkows/PyDnda9C/10+HrUMKiZPMwE6DtMMlOpIgARIgARIYDwCS7evsyVIWIbU9cLu8cSZ3+AEbhw4ZS9cs03Nvzgg967canAi7P5cEaDjMFfkWS8JkAAJkEBDEehcs0I26p4FLEXaqLMLDCRQjsAtfdLR5Xf0HQr6VubzuqG59+yVcqJMJ4FZJUDHYVZxszISIAESIIFGIjC/s0MdBXcWMLvQsnB+I3Wffa2QQO/JS/7SNX3h2qVfHJTrx85XWJJiJDC7BOg4zC5v1kYCJEACJFDnBPBitm7ds7AxcRgWrF5a5z1m9yZK4N65q3JJnYQeOApvHZYr+09OVAXlSWBOCNBxmBPsrJQESIAESKDeCGx4cY89DWmDziws3rq23rrH/kyBAN7OjGVHV+AovKNPQNIPAwnUIgE6DrU4amwzCZAACZBAVRBY/fh22+SMPQsr9m6tijaxEXNP4MGNO7b06Io6C3ASLrxxUGRk7tvFFpDAVAnQcZgqQZYnARIgARJoKALLdq6XzZ/3dy2sfv6Rhuo7O1uawPCDfrn0+iFbfnQZMwrqMAz2PSgtzFQSqGECdBxqePDYdBIgARIggdkhsGjdSluGhCcibfjc47NTKWupagK3dQPzRX006oXXD+pHH5F6+WZVt5eNI4HpIEDHYTooUgcJkAAJkEDdEWhbvFC6kw3Om/Qxqi0L2uuuj+xQ5QRG+gfUUXAnAe9T4D6FytlRsn4I0HGon7FkT0iABEiABKZIoLml2d6zsDlxGNpXLZmiRhavZQK9xy8kswo6s/CLQ3L38vVa7g7bTgJTJkDHYcoIqYAESIAESKDWCax/aa8vRdLHqHZ2r6n17rD9kyQwPDBoswqXdOnRRXze5tOPJomSxeqUAB2HOh1YdosESIAESGBsAngi0qZXnzaHYfmeLWMLM7duCdw+cdGdBOxXwKzCpWt121d2jASmSoCOw1QJsjwJkAAJkEDNEGhf1ilbfvNZ2fqbz8m6Tz9WM+1mQ6ePwMjgkM0qYEYBm5rxBCQGEiCBygjQcaiME6VIgARIgARqmMD6l/aYs9CtDgP3LdTwQE6y6b0nLxVmFbDBufciZxUmiZLFGpwAHYcGvwHYfRIgARKoVwKdG1cnswvPyqqnH6rXbrJfJQg0DWFW4ZDNKGBW4eKbh0tIMYkESGCiBOg4TJQY5UmABEiABKqaQPcXn9HZhWcFswstC9qquq1s3PQR6D11SV/CdtCfgoRZhQtXp085NZEACRgBOg68EUiABEiABGqewPLdm2wp0pYvPytLd2+u+f6wAxUQGB62GQXMLNgTkN44VEEhipAACUyFAB2HqdBjWRIgARIggTkj0LpgfmGj86YvPj1n7WDFs0fgzunL6iz4rILtVTh/ZfYqZ00kQAJCx4E3AQmQAAmQQE0R6Hp6ly1F2qJLkRbqPgaG+iXQNDJiswl4TKo9BemXB+u3s+wZCdQAAToONTBIbCIJkAAJNDqBDn2DM/YsYO/CWn1ZG0P9Erh7pidZgnTQZhd6z/bUb2fZMxKoMQJ0HGpswNhcEiABEmgkAhtfecychc1feU7m6zsYGOqTwJW3P5JzP/3A3q9wXp+CxEACJFCdBOg4VOe4sFUkQAIk0LAElnSvNWehW2cXVj6xo2E51HvHL/7kAznz0/flvDoM1w6cqvfusn8kUBcE6DjUxTCyEyRAAiRQ+wTwNmd/jOqz0tQ2r/Y7xB7kCAzeeyDnf6KOgn7O/WS/3Dp1MZfPCxIggeonQMeh+seILSQBEiCBuiWwcs9W2aqPUMXswpJdG+q2n43asftXbumMAhwF/ejMwr3LNxsVBftNAnVBgI5DXQwjO0ECJEACtUOgbdEC2aaOAjY7b3j1ydppOFtaEQE8MtVnFT5Qh+ED6b/bV1E5CpEACVQ/AToO1T9GbCEJkAAJ1AWBtc/tTpYiPScd61bURZ/YCSdw89BpnVHAMqQP5Kx+RvQxqgwkQAL1R4COQ/2NKXtEAiRAAlVDYOGa5eYsbNEZhq4XHq2adrEhUyfQ887HtrEZy5AuvfXR1BVSAwmQQNUToONQ9UPEBpIACZBA7RHo/twTtm8By5HmLe6ovQ6wxSUJXPjZfl+GpLMLVz88VVKGiSRAAvVLgI5D/Y4te0YCJEACs0qgbfFC2fmNF2Xb11+S1c8+NKt1s7KZITDU12+Ogu9ZeF9unrw0MxVRKwmQQE0QoONQE8PERpIACZBA9RJY+chm2faNl9RheFEWrl9ZvQ1lyyoi8ODa7WRzsz829e7l6xWVoxAJkED9E6DjUP9jzB6SAAmQwIwQ6NYnIm1XZ2GLfhhqm8DdMz3mLGBjsz0J6c692u4QW08CJDAjBOg4zAhWKiUBEiCB+iQwf8ki2a7LkeAwrH6Gy5FqeZRvHD5j71goPAlpeLiWu8O2kwAJzAIBOg6zAJlVkAAJkECtE1j5aLc5DNi/wEep1u5oXvnVkcKTkC6+ebh2O8KWkwAJzAkBOg5zgp2VkgAJkEBtEOj+wlPmMGz5rU/WRoPZylEELr6GJyHpEiR9EtKV/SdH5TOBBEiABColQMehUlKUIwESIIEGIdC+rNOWIm3TJUmrn9rVIL2ur27CWTj9g1/J2R++KzePXayvzrE3JEACc0aAjsOcoWfFJEACJFBdBFbt3aIOgz8dacHa5dXVOLZmXALX3jtmzsIZdRiu7D8xrjwFSIAESGCiBOg4TJQY5UmABEigzghs+Y2n9XGq+nSkr75QZz2r/+7cPnFBznz/Hf28K+dfP1D/HWYPSYAE5pQAHYc5xc/KSYAESGBuCHQsX2zvXYDDsOrJnXPTCNY6KQL3r9xUR+FXgpmFU+o0jIyMTEoPC5EACZDARAnQcZgoMcqTAAmQQA0TWLVvq73ZGQ5DR9eyGu5JYzV9+P6AzSyc+sE7clqdhv7bdxsLAHtLAiRQFQToOFTFMLARJEACJDCzBLZ86Rnb8Nz9956f2YqofVoJnP/R+7pvAUuRfiW9569Mq24qIwESIIGJEqDjMFFilCcBEiCBGiGwYOUSW4604+uflJVPcDlSjQyb9LzzcbIU6R25pi9pYyABEiCBaiFAx6FaRoLtIAESIIFpIrD6sW2F5UgLVi+dJq1UM5MEbn501vYsYHbh0lsfzWRV1E0CJEACkyZAx2HS6FiQBEiABKqLwNYvP2vLkTZ/5bnqahhbU5LAvQvXbN8CNjmf/uGvS8owkQRIgASqiQAdh2oaDbaFBEiABCZIoGOVL0fa/vUXZeXjOyZYmuKzTWCwt09nFrDB2Tc5D/Q9mO0msD4SIAESmDQBOg6TRseCJEACJDB3BLAcafvfx8vaXpJ2dR4YqpsAZhXwvgUsRbp3+WZ1N5atIwESIIEyBOg4lAHDZBIgARKoRgIbXtwj23/3FdnxzZersXlsU4bApV8etE3OcBZuHruQyWGUBEiABGqTAB2H2hw3tpoESKDBCODtzjt/99Oy6YtPN1jPa6u71z88Wdjk3PPrY7XVeLaWBEiABMYhQMdhHEDMJgESIIG5JLDrm5+SHb/ziqx9ae9cNoN1j0HgzunLtgTprL5r4ezP9o8hySwSIAESqG0CdBxqe/zYehIggTok0LpgvjykzgJmGFZ8Ynsd9rD2u9R/vbfwYjZsdB4aHKr9TrEHJEACJDAOAToO4wBiNgmQAAnMFoGO1UvUWfiM7PqdT8vi7etmq1rWMwECF376gZz6qzfkxHffkL6rvRMoSVESIAESqH0CdBxqfwzZAxIggRonsHTbWnMWMMPQ3rWsxntTf83HUqRTf/WmnFCH4fKvjtRfB9kjEiABEqiQAB2HCkFRjARIgASmm0DXvq36hKRPq9PwGWlZOH+61VPfFAmc+a47CyfUaRh6MDBFbSxOAiRAArVPgI5D7Y8he0ACJFBjBNZ/8lF1Fl6Rbd96pcZaXv/NvXbgpM0uYDnS9Y/P1X+H2UMSIAESmAABOg4TgEVREiABEpgKge4vPGUbnjd/6ZmpqGHZaSYwcOe+7VvAcqRT+s4FBhIgARIggdIE6DiU5sJUEiABEpg2Ajv1Dc9YjrTmU3umTScVTZ3A5TcO2ezCSXUYei9cnbpCaiABEiCBOidAx6HOB5jdIwESmBsCLfPb5CF9wzM2PK98fMfcNIK1jiLQd+m6zS7AWTj/+sFR+UwgARIgARIoT4COQ3k2zCEBEiCBCRPoWLXEnpC0Qx+pumTn+gmXZ4GZIXDu735tDsNxdRj6b9+dmUqolQRIgATqnAAdhzofYHaPBEhgdggs6V4rO3/vFdmlMwwL1iyfnUpZy5gEbh87b0uR8BjVKx+cGFOWmSRAAiRAAuMToOMwPiNKkAAJkEBZAqv2bjFnYbvuYZi3qL2sHDNmh8DI4GDBWcBypJHhkdmpmLWQAAmQQAMQoOPQAIPMLpIACUw/gXXPP6L7F14RLElimHsC1947pm9z1qci6ezCzeMX575BbAEJkAAJ1CEBOg51OKjsEgmQwMwR6H71Sdmhy5G6v/zszFVCzRURGLhxR52FN2yG4cyP3quoDIVIgARIgAQmT4COw+TZsSQJkEADEdjx9Rd1huEzsu7lvQ3U6+rs6sXX9vtyJHUa7vXcqs5GslUkQAIkUIcE6DjU4aCySyRAAtNH4OHf/5zs+r3PyKond06fUmqaMIG7Z68I9ixgKdLFtz+acHkWIAESIAESmDoBOg5TZ0gNJEACdUhg17delof/4At0GOZ4bM/89dvmLOAxqoN9D+a4NayeBEiABBqbAB2Hxh5/9p4ESKCIwPbfekF2/8FvSNcLu4tyeDlbBHqPX5Bj3/m54DGq1w+dma1qWQ8JkAAJkMA4BOg4jAOI2SRAAo1BYMuXnrEZhvWv7GuMDldhL8//5AM5/p3X9PMLGewfqMIWskkkQAIk0NgE/n8p9m1/fkLvJgAAAABJRU5ErkJggg==","w":782,"h":572,"e":1},{"id":"1","layers":[{"ddd":0,"ind":1,"ty":3,"nm":"小绿","sr":1,"ks":{"p":{"a":0,"k":[182.5,153],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[87,87],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":3,"nm":"三角形1（1）.png合成1","sr":1,"ks":{"p":{"a":0,"k":[-7.471,2.299],"ix":2},"a":{"a":0,"k":[353.5,351.5],"ix":2},"s":{"a":0,"k":[114.943,114.943],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":1},{"ddd":0,"ind":3,"ty":3,"nm":"三角形1（1）.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":655,"s":[353.11,336.815],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":665,"s":[353.11,355.085],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":677,"s":[353.11,336.815],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":687,"s":[353.11,355.085],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":700,"s":[353.11,336.815],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":730,"s":[353.11,336.815],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":737,"s":[353.11,355.085],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":745,"s":[353.11,336.815],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":752,"s":[353.11,355.085],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":761,"s":[353.11,336.815],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[353.1111145019531,336.82257080078125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[201,160.5],"ix":2},"s":{"a":1,"k":[{"t":634,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":738,"s":[87,85],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":761,"s":[87,85],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[87,86.38392450915352],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":2},{"ddd":0,"ind":4,"ty":3,"nm":"表情","sr":1,"ks":{"p":{"a":1,"k":[{"t":632,"s":[201.448,177.379],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":736,"s":[201.448,199.379],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":1000,"s":[200.9456787109375,176.19712829589844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[353.5,351.5],"ix":2},"s":{"a":0,"k":[106.94300000000001,106.94300000000001],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":3},{"ddd":0,"ind":5,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":4},{"ddd":0,"refId":"2","w":200,"h":97,"ind":6,"ty":0,"nm":"圆形1（1）.png合成1","sr":1,"ks":{"p":{"a":0,"k":[257,265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":5},{"ddd":0,"ind":7,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":4},{"ddd":0,"refId":"3","w":200,"h":97,"ind":8,"ty":0,"nm":"圆形1.png合成1","sr":1,"ks":{"p":{"a":0,"k":[257,265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":7},{"ddd":0,"ind":9,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":4},{"ddd":0,"refId":"4","w":200,"h":94,"ind":10,"ty":0,"nm":"拼合图形.png","sr":1,"ks":{"p":{"a":0,"k":[257,268],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":9},{"ddd":0,"refId":"5","ind":11,"ty":2,"nm":"三角形1（1）.png","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":3},{"ddd":0,"ind":12,"ty":3,"nm":"三角形1.png合成1","sr":1,"ks":{"p":{"a":1,"k":[{"t":0,"s":[-7.471,2.299],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[-8.185229301452637,-11.78786563873291],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[353.5,351.5],"ix":2},"s":{"a":1,"k":[{"t":0,"s":[114.943,114.943],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[114.53222430705435,112.17635176725294],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":1},{"ddd":0,"refId":"6","ind":13,"ty":2,"nm":"三角形1.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":653,"s":[356.59,382.055],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":662,"s":[356.59,424.685],"i":{"x":[0.833],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":674,"s":[356.59,382.055],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":683,"s":[356.59,424.685],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":695,"s":[356.59,382.055],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":729,"s":[356.59,382.055],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":736,"s":[356.59,424.685],"i":{"x":[0.833],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":745,"s":[356.59,382.055],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":751,"s":[356.59,424.685],"i":{"x":[0.25],"y":[1]},"o":{"x":[0.8],"y":[0]}},{"t":760,"s":[356.59,382.055],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":762,"s":[356.5899963378906,394.52093505859375],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[186,144],"ix":2},"s":{"a":1,"k":[{"t":634,"s":[87,90],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":653,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":662,"s":[82.65,93.96],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":674,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":683,"s":[82.65,93.96],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":695,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":729,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":736,"s":[82.65,93.96],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":744,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":751,"s":[82.65,93.96],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]}},{"t":760,"s":[87,87],"i":{"x":[0.667],"y":[1]},"o":{"x":[0.167],"y":[0]}},{"t":762,"s":[87,92],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":12}]},{"id":"7","layers":[{"ddd":0,"ind":14,"ty":3,"nm":"圆形1（1）.png合成1","sr":1,"ks":{"p":{"a":1,"k":[{"t":55,"s":[57.4432373046875,24.31439208984375],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":131,"s":[22.851318359375,50.105255126953125],"i":{"x":[0.09195402298850575],"y":[1]},"o":{"x":[1],"y":[0]}},{"t":212,"s":[47.202667236328125,49.7547607421875],"i":{"x":[0.13793103448275862],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":341,"s":[45.359527587890625,46.235992431640625],"i":{"x":[0.11494252873563218],"y":[1]},"o":{"x":[0.8045977011494253],"y":[0]}},{"t":412,"s":[66.38302612304688,58.299530029296875],"i":{"x":[0],"y":[1]},"o":{"x":[0.8103448275862069],"y":[0]}},{"t":511,"s":[53.060791015625,46.706268310546875],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":577,"s":[57.920000000000016,45.49400000000003],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":653,"s":[52.920000000000016,60.49400000000003],"i":{"x":[0.09195402298850575],"y":[1]},"o":{"x":[0.8218390804597702],"y":[0]}},{"t":760,"s":[56.4202880859375,63.31341552734375],"i":{"x":[0.3563218390804598],"y":[1]},"o":{"x":[0.764367816091954],"y":[0]}},{"t":802,"s":[50.469085693359375,45.368072509765625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[48.493804931640625,51.920074462890625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[43,43],"ix":2},"s":{"a":0,"k":[102,102],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"8","ind":15,"ty":2,"nm":"圆形1（1）.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":632,"s":[43.688,42.938],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":671,"s":[44.812,40.688],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":708,"s":[46.25,43.062],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":760,"s":[43.688,42.938],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[30,30],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":14},{"ddd":0,"ind":16,"ty":4,"nm":"形状图层5-box","sr":1,"ks":{"p":{"a":0,"k":[-257,-265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[200,97],"ix":2},"p":{"a":0,"k":[357,313.5],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"2","layers":[{"ddd":0,"ind":17,"ty":4,"nm":"形状图层5","sr":1,"ks":{"p":{"a":0,"k":[-257,-265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"gr","nm":"形状1","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[-63.25,-84],[-109.5,-32.25],[-65.875,18],[4.5,-2.5],[88.875,15.25],[115.5,-38.5],[71.625,-83.25],[3.963,-73.842],[-63.25,-84]],"i":[[0,0],[0.853,-47.795],[-19.25,-1.25],[-19.074,0],[-30.5,10.25],[1.25,27],[25,-0.5],[22.75,0.25],[24.25,2.25]],"o":[[-10.911,-1.012],[-0.75,42],[19.25,1.25],[19.25,0],[30.5,-10.25],[-1.25,-27],[-25,0.5],[-22.75,-0.25],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":0,"k":[353.11,339.159],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[87,87],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"7","w":200,"h":97,"ind":6,"ty":0,"nm":"圆形1（1）.png合成1","sr":1,"ks":{"p":{"a":0,"k":[357,313.5],"ix":2},"a":{"a":0,"k":[357,313.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"tt":1}]},{"id":"8","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAABAAAAAQBPJcTWAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAHjUlEQVRogdWbTYgcRRTH//XRTU4yAWGRiKsruqOEXROJWSGHxSQruvEjBiHkYCDg10ECgkrw4DEaLxJPiUbYkA3ExQj5OMQYr/mAkI/DZnOIkoOHQMAgQtaZ7ioPvdVT/aaqumdnZrMWPHp6pqf7/er/6vWr6hmGPrXh4eEnpJRjUsrnhBB1KeVgHMcDjLGalHKFEAKcs3kh5D3O+R0wdluAzzHBrsVxfH5mZuaPfvjFenmyVatWjcVxvC2Kokkp5TNRFEFKWTAhBIQQkFKCc44MnLeMcTDOAOAGY+y0FvqnY9PHLvTKx54ADwwM7JKRfC+S0fooimCDhqBtM8CMsdwsNy8plR6Ynp7+oVtfuwKu1WrvCCH3xHFUN6C2+YBd0LbKFFhrbeymUmrv4cOHp5YUOI7jkTiO98Vx/LILtBtoxhg455lzC9AGWCkFpRTSJPklSdNPjxw5cq3vwFEUfRRF0X4DFMdxELgTaFdYa60BAEqpHDpNU6RpiiRJdk9NTe3vxH/RycFc8O+lkJ+3xmcMKUUQyP7M3ro6IoqiPKHZnUGTm9Uhr4yMjDx29erVE1UZqipcAzAjhNhkq0q3ZapT2DKVTbPD2SicJEm+bTYa5xrN5ttHjx79qwykisIDAM4A2OBT0KWmS/WQsq5Qpyr7sziGGGebV69effL69ev/hGB4CWwNwGkAzwPIE4pvaxvNvLaKNhDtjDiOC+aLlLaO4WKtEOLUjh07VoaAZAnwjwbW7t0yWC7aQem+C9q8Z441zU5WntuVCfe1jLEZAJsWo/ABAJvNjh1Ktjk7grk7xKc6VdrODbbKoSxvnXPj9u3bD/mgfGP4fQBfFA4kzlFHXZ+5FPSNWd/4DhUj5lbleL2mXq/fm52dvVhF4acAfOvqBfuiNHkUlOcB9R2q20azva2wa3jQ4WT58c3WrVtHqwB/CSBywbrAnfvwdARjYHCPfZrUaMLy3bpo5iZC7CsDfgPAWy51KXQlcNc+93QEUd2GdpWeHkDrNQOAicnJyZ0h4M98sD7oKs3VUb59G8CM4XaYKr5oc8we+10b+DUAL5Y5b2pb377rePuY0D6dJDQaDaRpWkhIruNL/BuemJjY5QJ+txvYMmdcnznuo61ysdlEo/EvGo1GXkba8K5O8F47u+sUgAeRKVwJ1ndy34UpmKs2tmZAOXCzmW3Ne/Zx5ruh21NuSr0wPj4+BrQqrW0hWJ/zIaNgFNKA0luKuZapqsz57AmDDWy/ph1Q6IhUbQNwwQC/2ktg14VDoBRWKVVIUL5ZEoUNQadabQHwiQSwAsDGxQC7QikEKYRwQlNY85l9bTLxb1O8AO/oCK1Ufd26DUMSFTKzDVwGFgI1ILT6sqGUUoVjfEmNwueWpEjzpSA61u+PSQBrqgCb0OqFmnQJh56DFhMUmKpcgFaW4pomxmRUAni2E+BO1fTUuc7IoVHgOsaV0W0rqG3A8xDXdQlgqBvgkJplsFQ9Gs6hTnFBO0M8TZG0xvigBPBoVWAbukzNlgkwlnhhferaIW+u61K5KvQC8IAE8PBigMtBbaW0F1ZrDc55Qd2ydekyaF94J81mTQJ4qFPgMtDQbIbCGlBXYvMd7wN2JbNiQlMryta0SlX2VUz2NI0qRZNQhVXJYhGxkITMtgzWhpYA/gYQXOkrU9mey7od9k0WUnAu2sLZNe3zhbWrAnOFdpIkUGk6LwHc7RQYQF7r0iLCpQ51uuW4AOf++7TrezSsQ/dmCt1IknsSwJ/I1rE6aia0OOf5Ghbgn5T7HPaFMwUGipnal8DC0MkdCeAWgPFOgY0DSZLka1U+dV2wvmRFMzQ9B4WmKgehm8ltCWB2MbCmmdB2ORmCNcBVihPXeezkFQIm4HMSwJVugAG0VK4w7lzh7MsBNLsD7rAuU9mCvsaQTQ/vdwsNwPm4s+wnDq4lVxvWANvg/rBWSNP2mZRRWGv9pAQwD+A3AC91C9xsNtucK1M3pLDdyiLGVYwU7sFJMtdoNn83hcfpXgADMD0ZdIwmq1CG9gFXCWtSdp4CWg/EHwfQ099F2Qvq9lP80OMRmqHtyQOFDk1RXYZsoeOC3ZUnAWzpJTRjzPuzBSFEsEILjWHf4oNL5YXvXgKwHig+H/6u18Ba63wMmamkAfRVV52GtO+erJSyv37AvKBnPg9grJfQdjOKF5OVAGOtB+5g2cM42rTWYABUQGFjpN0EUDc7dLb0FYCfe8xZcDpJEgCwoBNvhg6NYdfamqftLfPrOLInUUtmjDHNOddCCC2l1FJKHUVRbuY9IYTmnGvGWNVznymDBYCnATSXGrpP1vZA3Nc+XAbOdmu7q8KadnAZOL1Y8/6opaydXQbOd2q/LhYWyFZCLi8DiKp2GYtYvaHtkf8J9OUFX3vSViILlQcN5bOz6IGyrnZoGcBRO9gPULvtXgaQGkADwAd9Zs3bKLIq5kHBHkdWIC152wlgrkNnu7HzAN5cErKStgvARfQP9ASA15eMpoM2BuBrADfQPeQ5AB8jW43pWevpP9NIG0LWAaPI5qODyP5OUEO2Upoie651F9nTj1vI1sivIAvd+X449R8fu1B1ZacoDQAAAABJRU5ErkJggg==","w":60,"h":60,"e":1},{"id":"9","layers":[{"ddd":0,"ind":18,"ty":3,"nm":"圆形1.png合成1","sr":1,"ks":{"p":{"a":1,"k":[{"t":55,"s":[142.47817993164062,25.1844482421875],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":131,"s":[116.26315307617188,46.548828125],"i":{"x":[0.09195402298850575],"y":[1]},"o":{"x":[1],"y":[0]}},{"t":212,"s":[141.06576538085938,46.680084228515625],"i":{"x":[0.13793103448275862],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":341,"s":[140.78323364257812,44.8267822265625],"i":{"x":[0.11494252873563218],"y":[1]},"o":{"x":[0.8045977011494253],"y":[0]}},{"t":412,"s":[157.81939697265625,61.144775390625],"i":{"x":[0],"y":[1]},"o":{"x":[0.8103448275862069],"y":[0]}},{"t":511,"s":[138.09579467773438,47.576202392578125],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":577,"s":[142.954833984375,46.36395263671875],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":653,"s":[145.954833984375,61.36395263671875],"i":{"x":[0.09195402298850575],"y":[1]},"o":{"x":[0.8218390804597702],"y":[0]}},{"t":760,"s":[149.45489501953125,64.183349609375],"i":{"x":[0.3563218390804598],"y":[1]},"o":{"x":[0.764367816091954],"y":[0]}},{"t":802,"s":[143.50405883789062,46.23809814453125],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":1000,"s":[140.53286743164062,47.12225341796875],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[37,37],"ix":2},"s":{"a":0,"k":[102,102],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"10","ind":19,"ty":2,"nm":"圆形1.png","sr":1,"ks":{"p":{"a":1,"k":[{"t":632,"s":[34.062,37.562],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":671,"s":[35.188,35.312],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":708,"s":[36.625,37.688],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.5689655172413793],"y":[0]}},{"t":760,"s":[34.062,37.562],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[30,30],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":18},{"ddd":0,"ind":20,"ty":4,"nm":"形状图层4-box","sr":1,"ks":{"p":{"a":0,"k":[-257,-265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[200,97],"ix":2},"p":{"a":0,"k":[357,313.5],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"3","layers":[{"ddd":0,"ind":21,"ty":4,"nm":"形状图层4","sr":1,"ks":{"p":{"a":0,"k":[-257,-265],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"gr","nm":"形状1","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[-63.25,-84],[-109.5,-32.25],[-65.875,18],[4.5,-2.5],[88.875,15.25],[115.5,-38.5],[71.625,-83.25],[3.963,-73.842],[-63.25,-84]],"i":[[0,0],[0.853,-47.795],[-19.25,-1.25],[-19.074,0],[-30.5,10.25],[1.25,27],[25,-0.5],[22.75,0.25],[24.25,2.25]],"o":[[-10.911,-1.012],[-0.75,42],[19.25,1.25],[19.25,0],[30.5,-10.25],[-1.25,-27],[-25,0.5],[-22.75,-0.25],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":0,"k":[353.11,339.159],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[87,87],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"9","w":200,"h":97,"ind":8,"ty":0,"nm":"圆形1.png合成1","sr":1,"ks":{"p":{"a":0,"k":[357,313.5],"ix":2},"a":{"a":0,"k":[357,313.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"tt":1}]},{"id":"10","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAABAAAAAQBPJcTWAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAHgklEQVRogdWbTahdVxWAv/1zTjKSV1AeEiEa0bxKMLYl9gkdBNvGwas/sQg1AwspWh2UgKDSkcP+OJF2lGobEpJAfVjBNoNa6zRpIZRkkEaolg46KBQMIhjuOWdvB+fu+/bZb+99zv17fS5Y3HvuO3ef9a219jpr73OfYEly8ODBL2it17UuvqaUWNO62F8UxaqUckVrvVcphZDytlbqlpTyIwQfCCluKqGulWV5eXNz8/1l2CUWOdi+ffvWy7J8uCj0htbFnUVRoLXuqFIKpVT7XkqkUkgpOyqEAHhXCHHJWvXHl1++cGVRNi4EeHX1Myd1secnhdb3FkWBD5qD9tWHdepZ+bZpzOkLFy68NK+tcwGvrKz8SGv9ZFGUa0XRwvmaAo5BhxH2ga21Tv9ujHnq3LlzZ3cUuCzLr5Zl8WxZ7vlWCDkvtBACKWVr3BjaARtjMMZQN81fmrr+5fnz568tHbjYUzxRqOI5B1SWZRZ4GujOHBYCKQTWWgCMMRPopmlomoa6rk+dPXv2uaUBSyl/XxTFYzHYPnAf2r1OipcH7SIcS2kXYQ+YpmleOnPmzGOLBl4BNpVSD/hw4WsfvIMNo52MsgfsYB3wGJa6rhmNqjeravSDixcv/qsPRA2AXQVeB+6LpWSouQqdSvFUJfedka3icEAI8eChQ4devX79+n9yMLIHdgW4BNwDdNIt9uprWHn9KPpAoTPKsuxoKlM6jlEapdTdSqvXTpw4cUcOSPcA/8HB+t7tg42BhscxaPeZO9eJX6wStyuMNRhj7pZCbAIPzBLh08CD7sBPJV/7HOE7JBX1MNJ+bfCjnKvyk3GVuv+RR374YgoqNYcfB37dOTEwLjQ09rdYBFNzNjW/c82Iu1VF3t+1trZ268aNG28NifCXgOdjXvAvGhaPWaIfzm2l1LZq70c4Nj1iffhYf3v8+PHDQ4CfBooYbAy87zjniFxRCwtW6tYVVm5fLTzbB/xd4Pux6IbQ04IPdYSD96FjrWfs+9uuAcc2NjYezQH/KgWbgh4iMUeljn0AN4djMENtEUI86R/7wN8GvtE3gOttU8fbz++e4wpL7DhsIUejEU3TdApS7Pwe+w4eO3bsZAz4x/PApo3ZblxovHcfnbSLVVUxGo0YjUaTNtKHjzkh5Qhr7eMh8H7aCA+CTQ2eunAHzDO4sxiotxYEDtip+8xBO/AYfMIRXz969Og6bHVayUIVi+AQDcFCSAca2drBWjvpqtx4/oLBB/bfhw7w4RtjHgauOOCNRQLHLpwDDWGNMeMCJYHustBfJYWwOWhjzEPALzSwF7h/FuBYKuUglVJR6BDW/W1ybdPO8WAdnEzzmCOsMWtHjhw5oBlQmX3gPrAcqAMJGxAf1hjTOSe2+PdBQ+gU+HiMdQ3cNQQYiMLOEs1ONxQAbaWziDojFuUYdBjl8WeHNfCVaYCnjWaiz41mTpgFsXN8IAfrawzcg1/TwIF5gHPR7IMNoxemc84pMej2uEpCN43Zr4HPDQX2ofuiORQ2FV0/5d11Y1HeDm2SkbaYVQ18ehbg9sIGKdOwYVMfg7XWIqXsRLdvX7oPOpXe9ahe0cCnpgXeimiNlK2BSkqaRFRTKeogpJTRwpY6PwUcK2YdcNPs7dvT6o3y5FYhJSKRwmGkwiI0YFeyc1dwRci99sH60Br4N5Dd6ctHubuY75uvYaRi6Rxb9qXSOtaBxVJ7/HpbAx9PCwxMet3Ydk5qnZoCTt2n+5zlAw+CrupbGviQdh9rKnGp1VeccrC5dA6BoVupUwUsC22ajzTwD+DotMDOgLquk4bmYFPRDSv0ZAxs21O7/t0YmkiUc9BVVX2ggRuzwDpxqR0zMgfrgIfcr2Pj+MUrBxyA39TAO/MAA50oxwzM9dupjTnfgW4MiKd1X5Qn0MZcE7TLw//OCw1Mdhj9DflCa2TmJw6xLVcf1gH74CF0DDgWYWvtFzVwG/gb8M15gauq2mactRaViW48wu3C35e+jIkBd+7BdX1zVFX/dI3HpUUAA86TWcPCYpWr0CngIWkdtJ2vwdYD8c8DC/1dlL+h7qKZS+dYhfYXDyF0bokaU9qNjiu+K18FHloktBCiAxk+F8p1aLk5nNp8iEV5/N23gXuh+3z4d4sGttZO5pBbSjrAVHc1bUqnipcxxv/6afcmHPkysL5IaF9cxGPFKlWhnVgs2HSl9jWQm8Cd7iBcLT0D/GmhlL7R44gD2SeATnJzOLa3lpCn++x6hfaesGMqhLBSSquUslprq7W2RVFM1H2mlLJSSiuEGDr2632wAF8Gqp2GXpJueyCekp/tAmPn1VNDYZ28sAuMnlWTP2rpkzd2gfHT6l9nhYV2J+TqLoAYqleZYfcmlM/+n0BfHdu6ELmDNlU+aaiUvsECIhuTF3cBXKgvLAPUl1O7ANICI+CnS2adyGHaLuaTgn2FtkHacXmUtjnfKdDLwPd2hKxHTgJvsTzQPwPf2TGaKWQd+A3wLvNDvgn8nHY3ZmGy0P9MC+QArQMOA2u0vwVbpf2V/V6goX2u9THt04/3aB31Dm3q3l6GUf8DD/Zns77dTpEAAAAASUVORK5CYII=","w":60,"h":60,"e":1},{"id":"11","layers":[{"ddd":0,"refId":"12","ind":22,"ty":2,"nm":"拼合图形.png","sr":1,"ks":{"p":{"a":0,"k":[74,11],"ix":2},"a":{"a":0,"k":[168,148.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":23,"ty":4,"nm":"形状图层1-box","sr":1,"ks":{"p":{"a":0,"k":[-257,-268],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[200,94],"ix":2},"p":{"a":0,"k":[357,315],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"4","layers":[{"ddd":0,"ind":24,"ty":4,"nm":"形状图层1","sr":1,"ks":{"p":{"a":0,"k":[-257,-268],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"gr","nm":"形状1","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[-63.825,-79.977],[-109.5,-32.25],[-65.875,18],[4.5,-2.5],[88.875,15.25],[115.5,-38.5],[71.912,-79.658],[3.532,-77.003],[-63.825,-79.977]],"i":[[0,0],[0.853,-47.795],[-19.25,-1.25],[-19.074,0],[-30.5,10.25],[1.25,27],[25,-0.5],[22.75,0.25],[24.25,2.25]],"o":[[-10.911,-1.012],[-0.75,42],[19.25,1.25],[19.25,0],[30.5,-10.25],[-1.25,-27],[-25,0.5],[-22.75,-0.25],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":0,"k":[353.11,339.159],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[87,87],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"11","w":200,"h":94,"ind":10,"ty":0,"nm":"拼合图形.png","sr":1,"ks":{"p":{"a":0,"k":[357,315],"ix":2},"a":{"a":0,"k":[357,315],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"tt":1}]},{"id":"12","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVAAAAEpCAYAAADFxXrQAAAACXBIWXMAAAABAAAAAQBPJcTWAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAgAElEQVR4nO3deZwdV3Un8HNuva3f69fd2vfNWlqSV9nCwmAb7GCDcdgNAWN2zOL5GHAghGQcMoEhhN3jSQgwM2EyEz6ECQmfEMhnPoZhMSQGs9jYsixbSLK8S7Il9/L6LbWc+cNqqdX9Xr+tqu69Vb/vH7a636uq07dOnbq33rtVTACaiFt7CanMW4h5lIiWEtEIEQ8Qk9IdW2tMRKI7COjYif0ldBsr9eIo1g4QC6lW11Eu925ifgkRbSWmAfMKkmnxQGj84BrOZP4xzFWigEKkRCRPFNxMAb2amEeJydEdE6SUBD9jlbkozFWigEIkxPffR0quJVLnElFBdzwAROQS8XZm/m1YK0QBhdCI5/0eKeftRPJcYhrSHU/n4hi249KAEQL5GjvOdWGtDgUU+iKu+wJSfAOxuoyYluiOB/qV8EIvdJyVWhjW6gz+tBNMJSKbxPe/JIH/EDnOj0ip18VXPHHOj1aCiycREdMCcd0/DG91AB0Sr/56Us77idROYsrojicaCe+BxcbgdpTgdlaZF4SxKhRQaEtc98/IUdcR8xm6YwHom8gzrJwFYawKBRSaEpG1FPifIFZXE1MoyQa9Mrg3ZyvX28W53J39rgbXQOE04nmvkMD9MZHsI6WuQ/E0QbPiib5PX5R6RxirSeh1LOiW+P5HiPltRLQFx6YN0COdX5teO/PlYW0FUkpEFpHvf5oUv5yYF+uOB0yVwEsIQh4rle13NRjCp5CI+yIJ3O+R0KPkqLejeMbNtH5Lu3gSVjyJiJgy4tVf3e9qUEBTRETeIxLcS+TcRuy8iFgimGJpWnFoR0e8phUk0+KJi/OyfteAa6ApIK77CVLqTUSyJoatRb+JUNkWL4RGqQv6XYVt3QXokIgMU+B/gZhfQcyhTV2DpMD8fxKZZOWU+1kFCmjCSKNxPin+GDnO5UQ0oDueaBh+YIJFuMjM1V6XxjXQhBCv/hoJ3Dsok7mTHOdqSmzxJEpf8UQ/J0Kv72dhFFDLiS83SeDuJSf7TWLnubhhcRLFMdROKd+9sp/F8SGSpcR3P0us3kAsKwk1swUM9TuT4jZSvKOfxVN86rGPVCorqFD4DCn6XSIe1h0PQHRiOvkJTbFSpV4XRwG1gIhcQiQ3k9ALiCmvOx4APaIqqryUmY/2siSugRpMxHubSPBrIvkREV2J4gnpFlWPNHhdr0viGqiBxHf/jNh5MxGt1x2LXriGCTEIqOcv1KOAGkJEFlDgfw5ffJ8JxTM5TDsZzohHgq29rgUFVDNx3YuI6aMkwQtJKQse/2vagWAC29pER7ymtc+MeJTqeYozCqgm4nlvIub3E/MOYpuuRZt2IJjAtjaxLd6o8aKelwwzDGhPXPej5Ki32Pl8Idt6WgAztc5fZtVTLUQBjYGIDFIQfJ6YX0VMuPcm9AAnr0h5/hWczX6/28UsGjraRxqNC8XzvkMSHCHF16N4dgLn9ObSVjxjzgOlLuplMVwDjYA0Gu+grHMDCZ9n/vVN03o2JsUC+sR8qz2Rc3tZCwpoiMR1P02Oej0xP/upnhWdKRSsZDHthGiqWW2keHMva0EB7ZOIbCff/xgp5wpiGdIdD6QdimdPhFb2spgVfSQTiXhvIKH3EamdxDgRAVjOZVa5bhdCAe2S+P7HiOk6Yt6gOxYACNHRqRW8dPDJbhYx/AMOM4jIevH9v5PAP06K/yTc4olzGMyEfNBmYeGF3S6CAjoP8bxXiOfdThI8SIrfSMwjEWwl/FVaA8VirjTng2YiF3a7CK7dzSK12mbKZj5EzFed/DQdImJLscAn23PZ1iYdxOs4Z3a7VhTQE0T8PyXh1xLRVjxXCE5nU6GIi21t0kG8Ql1Pr051AZVG43rK8ptJnAuIaAAjSpjLtp4W9IxpafeLpIyIXEHk30CiLiWmE/fdxEECYJ7Yj8uAWXU1+kxFAZVabTNlMh8ih68isvm6Jgp9MmG/moPPZeZ7On13Yofw4tVfQ0SvI5V5LhGvNn9OeidwkIXDtIJlUixpF1xCROkpoCJTa8h3LiRW55AEW0llziHijcSU1R2buUwrIHFL89+eRCHmcyBdPR/JugIqUl1HQe69xHQVEY8SUf7UZ+b48LwzKCCQJCHms1BXz0eyqoCK53+RiN9OyqTH+6a9NweQIKq7z0isKKDiykWkgv9BirfpjmWuZsUTRRXATt09H8n4D1ZE/D+njPzQzOLZCorn/FLx5Q/omEH5wDTQzduNLqDi+x8hUh8hMmnIbhqDkq9jaT7B2Li/omZWPog0dnX6XmMLqPj+e0nxfyaSmDPOtARvF49ZyQft2LK/TDsOYhQ4HT/ew8hroCLyBiK5hYid+BPOtAQ3LR5IhzTnXbC903ca1wMV172ERP47EeXSvRMBdElx75OISPHGjt8aZRw9UepviamoOwy94kjglB8kMI+Ud1yEV3f6VqMKqHjeP5PCozLiSWBbDhIU+mQyer92fFcmY66Bivg3EfHLdcfRPXznM1po23CYlqcmxTJHx0+eMOI0IFJdR5K/h5jwWOA5TEt8W6EdoWMd39bOjCF8kPs2imcrOOjDgXaEjikRWd/RGyMOpC3xG18gxefojgO6YcTABSA6fqOjuzJpLaAisprYuV5nDNCLVvP/ARKCM2d18ja9PVDP/xoxl7TGACHBEHl+OMFYZnMnb9JWQMVvvIsy6lJd2web2ViM0nyCsXB/cWfXQLX9ZRL4jxLzKl3bh5lM+4TatHggHWbkXSAH2HHazkjS0gMV3//b+IqnbWc/HfGaVqxMiwfSYUbenXxi7/xiP1pF5DwS+Tkx5eLeNgBAc7NGPUIuK9W2RsXfAxX/FhRPmAvz/0GnWaMepqyIFNotFWsBFdd9MbG6JM5txgMHZv8w//8U5JMRPO/Cdm+JtweaUZ+IfZuxsOXADAsO8GilLZ+i0meeKml7Y+XYipl43puIuKtnLoOpoj7AUaDDkfZ27DNPxWn7iOP4eoOK/zi2bRkr7QndKfTAwoF27IuSM9q+JY44xK99gJi7emB9MiGh7YWTX+pw+xsrx5IV4vuHSPHaOLYFEB984T/RAjnMjrN8vrdE3gMV3/8wiickE4rn/CzvtTO3vcVm5H+h+P4+Urwp6u3EAz0O0AW5FzshYaXm7WRG2gMVr/7G5BRPIiRwkpjWO2oXD3Ivdkws9fq8n91EO4Tn7E2Rrv/ZjUS/CevY1iaY/29ePEBERDlnx3wvR/ZQORH3EiKad+MhbSn6TVjHtjaxLV5IDU/mvbFydD1Qnz8a6fqJyL6eFsBMmP9vPJ7/EmQkPVARWUtCl0bfs0DPRR98qNE/zP8/xdB8UjTvd0Gj6SH6/qeJJSF3XMIZvDkDkz1SyINomZpPvGTeV6PYpAT+ODGXe1va0DMRQKSQ9+EIuR0DOcqOs7TVy6H3QMX3bu29eBIhiZIGPbfOIO/DEXI7tnnoZejZLUHwJDEtC3u9ABA39IpJKGClnFYvh9oDFXH/GMUTICmaFc+UjSiYlIgMt3o53CG8OO8IdX0AYJgU9kg9r+V3QUMroOI13kpMbe+fB7ZJWY8DDGJI7jGPtnopvB6oyr4vtHVpY8gOM0oKexyJZVp+WzL/n/2Wz4cPpYCKuJcTyXlhrEsvQ3ZYW6YdCCawrU0w/9+8eFpxWt6OM5weqMc3E1uXwRazJfHiZFub2BZviomsavVS3wVURArk8PP6XQ90CucpsJmF8/+Vajkbqf8eaMP7E2LO970e6BB6Lvrg5NU/C+f/Cy1s9VL/BTTrvKrvdYBhUCiaS9vJC3lARERMLWdW9lVApV7fSkxb+lkHEJmXqGkrFNBc1HlgWt63wgOtXumvB5rJ/D4RtZzm1DlbGjIqKFjJkvZ87pQlec+tb/vZXwFleklfy59kSUMCdAT5bK/mJz+p189u9vueC6i47hXEvKbX5QEAzNNi/n8u1/Thcr3fkd7h9/a8LACANYQo8Dc3e6X3ITyrS3te1ji4ZgUzIR9gNl7f7Lc9FVDxvLcS0aIWG+pllZql+ZqVjfsramnOh6QJKb8VNZ2N1GsP9K2tX0Ly2cWW/YVCP5dtbWLx/H/h5c1+3VsBVfycvoIB6JothT5OtrWJbfHOxE1nI3VdQMV3/4iYi/0HBNAp23pakEBN70rffQ+Undf1HUrzFUezWkgAm3sutsNxeULTTmNXrSMiy0nkYWLKhhOTjfCgrWTCfgWilnkgJKzUnA5ndz3QwPtIuosnEQ6ysJjWs8F+BaKWecDEIjLnxsrdFVBWLzMv8W2V9nZEwUqWFOSz522f/auOC6hIYxcRb0DihwXtCEmSgnxWas6d5zrvgQbqRnMf22FoWACQJBtm/6LzAmr01M0WNwAAAAhLr9dARWQLcfOpTOZKwZCiLzjBwEzIh7YULZ37q04EwfUdvzeVbEy+NJ9gbNxfUUtzPnSKF8z+TWdFkenK0GNps0GztIsHyWcXW/aXaceBCbS2ydDsX3TYq+SYn3tkWoKbFg+kA/JuLp1twqXZv2lbQMVv3EBMhWgCAoDm0Ps00JyHy7XvgYpK6WOL40hgHCTQCnqf+rQ8LnMdv3Oa+P7TpJrfygnSAvPEkwn7tVvM6rSaOW8PVFz3CjuKJ3py0cJBFg7T8hT7tVtSq532bKT5h/BKXRdpNKGJOhFMS3xbpb0dUbCsl8+vn/nj/AWU6ZIoY7EHEj8caEewnOuun/ljywIqIquJeM7UJTBF2ntzABpknZUzf2zdAw2CdxOTE3lA0CPM/weInS8dFlCiqyIOBUKHIfL8cIKBmXrIB+f0+fCtCyjztu7XDulhYzFK8wnGxv0VtR7yQWTxzB+bFlAR723EzR+iBFExLcEx/z9ZbNlfph0Hs6nTbijSvAcqdE24GzW9UWbTEa9pCW5aPJAOxufdaTcUaVFA+TnhbtP4RpnFtngBksCGjtbpNxSZU0BF5BxSvCS+gMAcmP8POlnRcTnthiJNeqDBK+KKJFw4MPsXRwJbcZAQ8imp+t6vp91QZG4BFb643y3oYcuBGRYc4NFKWz5FxbQ87XO/zvpufJMeqJzZ3xYgHpj/b4e0t2PyTkQzbyjSpIDyijiDiV/aE7pTyUt8PdCOiTPjhiKnFVDxvNcTJ/3hcUhoe+HkBwbwT91QZFaxZEzfBINh/j8YwDl1Q5HTC6iii2IPBqAvGFHMDyeY0AXSooASr4s7lu4hIUAXG3MvzSeYiPYXn7qhyMkCKo3GDuK5D00yT5oTImlMK0iY/58sEe0vPnVDkVM90Kzz6j7W2Fc8yWRbm2D+v3nxgJHEOXlDkRlDeLm0jzX2E05C2dYmtsULoAmfuqHIqQIqvd7/07aeFsBMmP8PXRI5eUORUwWU1aIe19Z3PNArHJj9w/z/U5BPneHC9L8UEZGIXE0kBn+BHju2OVsOzLAgD6KVtnzq2ckP258tmr7/stNfNy1RsWOBCPP/bZHwdmQ+eUORZwuoUrtOfwcKVrIkPKFDg7wPR9LbUVhElhOduga6Xl8wEL2kJ3SS4eRnJPfZ+fAnCqiUNYYCAC1h/r+Rstk1RERKJieXzxzTA4DpMKKYXwwnmMBdRUSkqJB9XvRbg/6gxwG62Jh7cZxgnBPXQEXtiGFrXbBxh0UNPY7kMC2/Mf+/N7KMiEgR9zoDKSq27DDTDgQT2NYmmP9vXjyWYFpMRKRI8QbdsdgJiTeXbW1iW7xgDJ8WEhEpEkr4M5CiYFtPC2AmzP/vm8PDRERKmAfavRdmQ89Fn4QfmLHA/P9Tes6nMhFRhkgyMmMlTPb86clmxp4wI4qZzIomeubtgbjE85f3uoVn78iUEaIMSdD36iCZkA8Qmi4rotG5J8/ekSlDRI5gVBQpIQw8QSeDMtCQMPonOSKiTCCBQ5yYvypm7RLz1OtGn00h4XB8h44pQ0SUESaeOYSHbp0ojS2HJ3Lyv8lJ45l/TbL+MmjBtEux2uMRFpFFGZPaxGodNKQRbR1K4nGLf1tK+8HYJR3xyuwfNO937fuLySVar0jE1R0KxEh74hnItjbRHm8CTpohkIa/NkNEU4EEFjwPHuxkQG+lbyb8DSbEADM5GVqVYeZfiNAV8W0WiRAfE9pa9/bDYMLfYEIM3TMhA6Migb8yQyL/RBxnAeVT/9M+FIlbeOnU2ef/GlI3lfsV5jiRB0ktnkRELLSMiYiqfnXSJyq1WwBAN3z+D6bICn87Q0TEwt8TDl6pOyCATkiLfwPESYjKioiIHe9PWcjXHRDYACWrObRL2ghR/uQIqNKo/sxTsmu+BQCshvE/hCgTyK8y0z+wyC1E8nWdAXUEiQ+9Stj3/6FLIdcOIcmftroJr7LfJzojvE2AKXDeAQiXI/xAZuYvFGe+6pH3cV0BQbRwlQ4gPEFAuTmdkgl3crfLcqaOgIyGLlx80NZggRzxo3PStOpOXF4jui1gcnQEBQZCQYOU6GYeSEbocNPDYtwb/2aD+DXhhQXQJRRtMFyG5OmWKXrcmzjqSbA4zoAAAGyRIR7LtHrREf6cS/TJOAMCmE/n9/8HiJ5P5Mybb8+4k79ukL8jroAAYC58/99MLFKdd1+MTY3tcrN0u0e4XygAwEyOqEbbk9mYO/75KfJviiMgAABbOMJeR6OBZxpjd1Y5eM7878KNIAEgPVgk6KiAjo2NLawXZb8r/kjUQUETuPCVSuiSmI1JSceH5Vht7MZJdm+VuJ8hj+IBAAZi6rI0HXWPf7suwcsiigfAelaf760O/oQY/wZF1HkPdNqT9WMPuxysiSIgMEwSDihboK2t4xDVWn6RvpVCTr3TbwTf9Vi6XhYsk+YDOu6Chuf/WSfDmUnV7UIjPHJbnp0vRRFQr9J8nENEdCRVzNUMxbM/TsDHek6To97x/1cJ3MvnvoKxCBAhD+KEttahSM5P+2r1J+rH9lfJTcQd7JGCYCLM/zfXIGX/oush/EylXPGlOebJsALSCUkIJmqXl0nNWxseXV3IFb/ad/sfbRx710TQ+JJwYvclAMBpcsyVNbllg31/kr4kt/ArhxtP7xwPGteHEZiVMI4CE2H8Hxklzj4iolC+irQst+hdjzee3laRxsVhrM8eJ74IgiQEE6V1/B+DLGd+RBRyEz5SPfJwVXn4kj1ohY5VfNLa1gu5tGtxbvjOUL8MXwj4la5SP2mIXwxzvamT1qwMkakfPCRR2tq6SNnHFueH7yQKaQg/bUlpya+frB59v0/+l32Wvj7hTzUUT7CI1ef7OcG3v/9/hvi70/+O5O9+ovbUp56h2oc7XsCEPWBCDKAf8iA+FrZ1lpS/MF84YyEvfJgowvAfqx/9+2eC2u9FtX4AgG71O/9/kLO71xWWnz39c2Q3BFmVX/L6h6uHV41T/eQn8xaecAAgQfq9XpsV9fWZP0dezw7WnnigIu6W6LaAsgymQC7GJ/62zrOa2lxYXZr5u8hvSbehsGJ0X/WJIzV2l0SzBSQsmAK5GJ8WbR1hXc1S5mezfxfLPT03D6xYurf6yFSd/IE4tgcAadCiWkbwvSomonygPtvs97HZXT3k+4SvNwGAXUqcO7CpsHLj7N/Helf5swbWOXdXH0rb925TA1cAIanynP3fzX4fe74/OfHk0sedqcPxbhWHNgD0ZoBzE9sGVg81ey324fTy8vIjSzODO+a8EOkNAFE8wQJ95D2GddEpcOb7rV7TVlkeqR256kgw8a+6tg+GwSABDOSQChZnSheszi29u9nrWlP24eoTbzscVP5GZwwAAK0MUf7e0dKac1q9rvXRxGsHVnz14NRjS49S9S+6WrCHGwAYx4QwTYgB9EMetJTn3Kfme92IZjtQe+QzTwW1D+mOAwBSZp6TR5nze7YNrD1zvsW19kCnnVFY8wf7G08sPOpOvF13LGHDyR3AcC0+gRvg/J+3W9SoY3vf1CPfekqqr4x2KyhpAOFJ5vE0ovJ7tg2sm7f3SWTgX763+ugPjgWVyzp7d783p4K0SebhDmFbqcrXrR9Y+bV27zMyl/ZMHfrl8aB6ge44tMPRDhC7Bc7Anu0d9D6JDLkGOtv24rqd91Uf2nvcr462fpcZvc9IP/9H8QSIXZ4Kba99TjP6EP1N5cAj41JfrTsOACLCiCAFFnBxz1mlznqfRIb2QKedWzpjzV2T+56aZG+RngjM6OWCbifyAMUz8QZUtuPeJ5ElKfGrqQcnJgN3UHccobPw+/8AoTIo7xfS4J6zBzvvfRIZ3gOddkFxS/nn1QdrVd/N97oOg/bTKdzi35AORiZlzAz6+4tOd71PIqPCb+/fKvd7DfGd03/bLguRpQAwv8XO4J6zB9Z31fsksqQHOu35pW2Z2yf3BJ74sypiu+uUcvK/KKUAMFuBcl33PoksrSc/mNwtIvhwBwD6w0S0gAfu3zG4aXsvy1vVA512+eBZfPvEbr9BAZ6vZCD09MEWQkQD1H7OeytW5/lPJvbUqtL7B0tdQVUASJzFTvH+80ube+p9ElnaA512SXl74d8n9o5NUq3p80pC1XPxROUFvZCBzeU5F5S9zE39rCMR7Xpn5YEnjgfV5brjADAK5oHMa5kqf+e80saX9bOORBRQIqJfTux78KhMbtYdR7RwRACEYUQVxi4a3DbS73qsHsLPtLO8ecuvKr/9xWF/fKfuWKKD4gkxazL+T8IlgSEufCGM9djeDnPcVdl/2xP+2BW642gL3/+PABoN2lvKg3t2lrd0/aX5ZhL3NaAdpY1XruLhr+uOo612x3lS64C0+HcoktpoEJa8cvwhyrw3rPUlroASEZ1b3njt2syCULroNjNywI/5/ynSJAM1J+UiGfznLeUzbg9rfYlO4XtrBz70SOOZz+iOI3wY/wN0a5gHjj2/vC3UW2Mmsgc67ezCGZ/doIav1R1H+Dof/xvZC+3UnOAjHf9Hw4QwTYjBAAuc4rzPeO9FKrop+xqPPndf7cgduuOwCjqxYJzek3K5GvzN+YNbzgs3noT3QKdtzq3+2Rq1yu4v2sfdi0Dx7Ao6eXHoLSkHOOMNePl3hBwMEaXwMPnexG8Cd87t8KAp9EIhAVbz8NfPKW+M5FJeKg+PH1bubVR9N6s7juRC5QW9pjNwhItHn1feujSq7aRiCD/bZaWzcyUnX9Edh406u3V1i+KJcW5zaJfQTWfgsDPw8Ti2k0p3TO597HgwtVJ3HMmUrF4onv9nn2XO8C8uKG28MMptpLIHOu2iwa2rVnD5h7rjSKZklRh8/98uRc41Bn315qi3k+oCSkS0o7z58jU88gndcaRCZ+N/6AoarZlFVPxfo0Mb9ka9HZxMT7i/cuj6g/7TX9EdByQQxv+xWqSKD+4a3Doax7ZS3wOdtq207r+tV4uuLKpcvekb+jjRo48QHyPbGuP/2JRU1h3xs9fFtT0U0Bm2D6773trSwtEFqvj4nBf7SHwcM2Ho6/N/SIlFavjLo8MbfxHX9pBvLfxi4sE9R2Vym+44oHtWj5LnBG/h+F9TmIt5cM+FId3ns1PogbbwnPKW7St46N91x2HmmNRsfT3/T7c5wVs4/tcQ5oDK1Ydzg6+Je7sooPPYUd70/NXOgq9m2NF3aFlyzEQC8/+NZsL5ZtpiNfhfR/MrI//UfTakTAf2TOy/4SmufWYyqBd1xwIRs2SUDKcsdcp37yxt3qFj2+iBdmB7eeMXlwXFCxap4kO6Y+mOSX0ES1g9/k+fMmerI8Xiy3VtHwW0Q6NDG/buGty6YWVmyKKZS+hKhQHz/yMQUrssoNLnNvGqR8JZW/dwhPXg3trBW550J250xcMJCGZI1vjf9M//lzvlO88vbd6lMwYUgB6cXdjwgbW5RdcOUmFMdyxgEtNKTH9M/vy/zPnJJcXCVbrjQAHt0Wh+1TeWTTqblqqhe3THAgbD/P8ICI2o0ifX8JpjuiMx7cRipXsq+790VCrvrAeeozsWACNEOP5fzkP/dn5508XhrbF36IGG4JzSxvespJGXLlDFx3THEirM/7eCkW0d0fh/iApj+cH65eGtsT/ogYbsrsr+7xwOxq8OxMi0Bqu067qZ+NFOtNZnFt20vbjuFt1xTEMPNGQ7Sht/d42z8H1DNDCuOxawXbvieOp1q0/Xc4KXpv9enRn5PyYVT6K0nb5idNfBu0aCpYPfP+xPXKA7Fuukr2OljyVtvcwp/+qC0uaduuOYzYKms9t94/v/6Bmu/cGY1BfojgUsYElBi9MCp/T4RaXRVbrjaAa7KiZ3V377raf8yssb5OOyCZjF4KJdUoXqUq90ybaRdb/SHUszOJhjcl5p06tW8/CLlnAx9jvGpIvVVwP1MHT+f4aULOHBD5laPImMPe8k2+6JAx8fo9r7xqQ2ZPDJH1Ksr8//Q0rq1c7IV84pnfHu/tcUHRy7Gt07cfCLE9y45pmgskR3LAC9iaYLsCIz9KMdxU2Xhb7ikKGAGmD32P4PTCn3PcekOhpgCAopt9Qp/3pnabMV315BATXIA+6h35nyGjdPeO7OSakNtl2gyckflwRAuz7G/3E+kjgMONYM9eDYwV1uNnil68tWn2mty/6yBvkjdfIGXB+30YPkGeLCxMXl7UO64+gGCqiFDsjhZVP16jV+ELyw5nvn1tlbPRnUBnTHlQh9dOHR++9dlh3ZQMuWbyovP6I7lm5gfyfE/ZMPX+kq74Zxr37pOFU7+NI+xv9gjk2F1Tu25JberTuObuFwSaC99UdfO+XW3jUljV3jUivrjgdgPuucBe85s7Thy7rj6AUKaMLtrhy6vkHuWyakcX4Fw3xzpbT3v1aGbzpreKNRNwjpRgp3WXrdN3Xgg9XAu7ZC9bMqgZsLd+0prQDQM9uLJxEyPrXumThwa1U1rnnan1qhOxZInyQUTyIU0NTbUz30plrg3Xg8mDi/LgEeSWIlu3r/SSmeRDa1OkRqT/XAOteXT45L/aoJqY1EuS27DncIU5KKJxHyGBGrlXQAAARzSURBVJrYPX7ww1Xlvv24TG3xJECOQN9y7Pgb8yt2brDwq0rzwcEBLT0wvv/iCgc3T6rGpZN+HZ/gQ08WqNLhiwZHl+uOIwoooNCReyd/+9lJ8t9wPKis1BoIvv9vleU8/JPzyxsv1R1HVJB30JX7KgffUxH3xuN+ZbvPuHMUNDdMA2MjzsBfnllaf7PuWKKEAgo9eaB66HcmpfHRcb/2vKq4Gd3xQB9CnP+f44y/RBW/c25p0ytDiMx4KKDQlwemHllVpfrnJ7zGSyeog1vwaYXxf1QGKOMOqvzeoaBww+jQup/qjicuSB0IzT3j+z9fUY1rjwfVZbpjgfBlOBvkSdVz7ExkiI9lHOfJLGV+kHOc27bk1vxcd3w6oIBC6O6bOnTjVFD7D09LdTSQYO4b0OszWk5lgkHKHS5I5ud5lf1Xz5f7Bsvrfr2BuaY7NtMgjSEyD1QeemnFd//jcTW1qx74CZzllIwzwYCTcYucezzvZe7KsfP328sbvqE7JlvYv/fBePvk8MZKdfKz40H9xbjxs345zgRDlH9oQOV+ms1k/2VrfvU3dcdkKxRQiNW9tUN/PelXX3vcn1qkO5Y0KXKuUXZy9xck952h4oLPr+HhY7pjSgIUUNBiT/WhmyeC+juf9ivrdMcSBx2D/UHOT5ad/N0Zlf2Hswvrbo1586mAAgpa7fEef1O1UfngcX/qnIb4yMc+MBENc+HpoirckQuCv9te3oRrmRFDwoIRHnAfv3jKnfrYM1K9uOq7Wd3x2CKrlAyp4qMF4h8Vsuoro9mNqfkOpglQQMEoB+TwsvHq1H+Z8KtXT4jpX8yPyazxf4Ecr8wDv82z839zTunWrQPLD2qLLeVQQMFYu6cOfWEiqF17PKgs1R2LbmVnoFoitTufyX3rSO6hz1zGl3m6YwIUULDAfVMPf3DKr733KalsFErPDUyGKD8+oPK/LHDua2eW1v6N7nhgLhRQsMbe+qPXVLzaHz4tU+d7gad0xxM2JqIFXHxqgLN35IT+57byxn/SHRPMDwUUrLOv8diOSqP6yeNcf2HVr+d1x9MPh5iGVPHxImV+nHOKX942sOLHumOCzqGAgrWOyJHBI5XKX41z7RXP+NXhlm80YcbljBiynAnKQe7hYiZ3W07or7YOnnGP1tigZ7rTCiAUu6cOfbIS1N54LJhaY+J10oJyvDIX9xU5+93MVP2W0cWjj+mOCfqHAgqJsnfy8ZdUqfr7EzJ18aS4WufdFzlfL3F2zwDnvsXFdZ86k7mhMx4IHwooJNZ91YP/aULcN477UxvjerrooMpXBiX/m3w2+40zMX0y8VBAIfHuGzu4y834H5kM3MvHpToU5rqLnHWLlDtY4Nwd2Yz6x22Fdf8S5vrBbCigkCq7aw/fVPcb11WoPjrp10snX+jwg6YMZ4IRlX20IPkfZjMOCmbKoYBCau2rP7Hd9etvrYp/qUeNdbXAW1gRN5cnx89zdirDzliG+EhWZR5xAj7AKnvHmcXV/6A7bjDH/wezXuz+ybTm3AAAAABJRU5ErkJggg==","w":336,"h":297,"e":1},{"id":"5","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZIAAAFBCAYAAABdKCl7AAAACXBIWXMAAAABAAAAAQBPJcTWAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAgAElEQVR4nOy9efxlR1Uvumqf36+nDJ2hu5MwBMfrgPp5z6eiqDgAAQkGRHC4H0ERwYiE0YBhiBAGgUQCyBDGICBgZCZMIWG4cuXpe3LvVdF75aKXi2ToTjchJOnpt/e6f+y9ag21qvbe53d+Q3fvdT7nnL1rrtpV61trraraASaa6ASmN9xyw3ceXDl479mW2XdCwO+ocHavKsDdKsBTIFTboIGtIcA2wLA1VLgFIdQN4mFo4DAGPAwIh1ZCcwgAb24Qv4rQ/GsD1b9UePC/P/WsR/79RtdvoonWg8JGF2CiidaLELF69b5rH1zNqvOWcOknlkL1A4iwIx0E8w4LVHc1NNAg/re6wf98Bxz99H687RNXnP2YO+dMfKKJNi1NQDLRcU0vuvk9P37a7JRHLOHyfZdms3sjNqe1PuO6PgqQCKOHDXa/4XANzT8cqo/83S1H9r3npfd87GdHJjTRRJuSJiCZ6Lijl9/4gV/esWXL+dtg630R8HtaV7+ro5Ei+tw9ygFLHnDatFdw5Z8OQ/3J/UcOveOFd3/kfxmc4UQTbTKagGSi44L++Ovv/r93Lp3+1K1LWx7YYH1O66q7twUHDyyGw0dK3mCyYJKCS5tjDfUXD9ZHP3rd7f92xce/+8m3r6IYE0207jQByUTHNF1+80d+ceeWbU+oEM5DhC0l8NDXOgwiJu5jKXS/IWjACCpMcK9jqTDculLVH73j6MHXX3z2w/9mFcWZaKJ1owlIJjom6bX7PvH4bdXybzXY3Ld14a7sgQeKewQAQFRuMTzSfT+waEhoAUS6xDChvQsOdHA46YMQKqhnOPtsXYV3/M7pP/dnhWJMNNGG0wQkEx1T9IqbP/yw07ecfPFKU/9k69J24RJ4NIjA8ND5IQBCI8AkjQcCUPJUiVKQC4NIgCoCDIFFFYIGGmB/CygAAMvV0he+cfj2Fz/tnId9tKcwE020ITQByUTHBF1+6wfvc1p18nOxwYcCMFNm5p+Ch/TTYCIkEwEmDXqqL50+EckYAAYMgvSpol8loMMCSRU0GKVSSpt70+Bf3n7qyiXP3PaQr+RbaqKJ1p8mIJloU9Mrb/nQWdtnOy5fguqRNTTbSwBCtg66JvBoyE/IHU0MJ6WSPJAAtFJMUCPGlyoACEJCBxQMDPQh6CBQCUAgFIqAEgIcuKM58pan7j7/mYMbcaKJ1pgmIJlo09LLb7z2CWdu3fHsBut7WRWWBJBU+mjBoYnwgQlw6PAQ8YJjSPLUWymIVB08QCD1Fd2SlFJFYOH7FlRYKumAJpQBBQG/9JVDtz3rZff4lUndNdGG0wQkE206uvzm9+85bfmk1yJWjwRoGWgJQFpJBKCBpgOPFjAIPNiVgQNRAob9z6/2IvKW9Wp2zyquECqogvapFKiQlCJBhKQZVo/J+NhB4p145PXP2P3QJ87RzBNNtDCagGSiTUUvv/mDv3PG8snPRcR7wQAAoesm/rb+BCpA4RGii1VqIaCQSOZZtQVCWdX+MDy0DhEYoFISS4AAM6gghDYFllKCBpmMhNLWuvnSl4/uu/hPzvmNj8/T5hNNtFqagGSiTUOvufVjb90Cy48FSKUQD0BYddVAbaQPDR7sBwCADQIGsp504BRLMX4/id0xUsUrbf9o/aQEUkFVgboPADALfKcllKAASLZTAwi3NXe99g/3PPxJI4o+0UQLoQlIJtpwQsTZ1Qc+/Z4VbB7pAQgACLsHgYYPIDWyjaSbrUeJQ8ohTcwhlsGos4ZTsoQ3GtfJBaI0IiWWSkgfIbQgEcEDggKU1o/UYSz9WEA5iIevf/Ku8x8UQmhgoonWiSYgmWhDCRG3/Nn+z3z0CNQP6JdCGqgjhCDUyAqtJgKIUHUJkLHA0SBLI105dLlGQIk1u2sgsct7O+M6resS4NFKHFUElArMNZDNJCOdYAAMCEdw5SunHF6+z2/e4wH7B1dioolWQROQTLRhhIinvHnfp76IVfiu6CbtGkIl1UoeLZA0yAqrOgMgBB6eVNPlrfJLV2rNR1ZKANDAQhILXUe7SBD2kg5QZp1Ki2wosy7GLEjFl97gSLRSN4eaGfzsk3Y9aDpmZaI1pwlIJtoQugXvOOv9t37+q7Mw20pucadHByLd+zyiIb0WRvQGWSKhsLRbvY6pMXj0AQfZS0C59VN65EmVhKkEsIRAV3JFlpBSMoBCUgmDSLsSjMOlYAIAsAIrj37irl9454CqTDTR3DQByUTrTtd/64vf/+XD+740E0zXqrKsFEKgQRJIE0PRyq0WQDCqtDQoAcg97NrQ7pEEnxJZNZbyi/9czwoCYPevDPCBNyqSSisa5C2ghApmSvWVl07alpld9Hu77v+a3spMNNGcNAHJROtK77v9Cz+578i3Pl9ZZid3pAvpo8YmSiESRBpoogpLAkhc0iv3mMR8UvDgnfA5GroAOHWhHe3Sz4KKVH9JQJkBSSgMJq16qwWUWZg5Ukpe1VVjfenv7X7wCwuVmWiiuWkCkonWjd5+4LO/eLA58mFicqRkkntBWAohEJEA0rqz4Z3jx3VaCDGtzlfk1VIT1VxEQ5b8Sl9/2KSwIaQStQ+E/ltQkcephCh1tG4zsWKLAGXWGeRbv5ljO4EYX5apCeEVF575gGcUqznRRHPQBCQTrQv92Tc+95uH6sNvkyAipQZahdUIg3qNCDXUrT1EAYjeS5IDkDx4+EDi3w0jD0TsVQ5U5GZGsn3Q1sQqSijdiq4ohVRRGqFrvcorKMN+Wy+EAOGtT9j1wMfNUcWJJsrSBCQTrTm9c//nnnEnHr7CAxFpPG+iJNKCSt2pr+ouVAsovBRYp5MCiFZblaWQFDzm3UkCYCUPZ4FwvK6EjSUFFKvuakGDjPGtVDJr/zu1VwsmlVhinIIJAr73d88871envSYTLYomIJloTeldt/3Vi761cvA5fSBSdyDSYAMr2CgppMa6s4uIHe3GBmIBRCq0PPDwpBFrWx+yINjaItgsYlRbbiz+tYAiTwdm6YT3ktBqrVl3PeuM8bNEMvHBJITqk48/4/7nhxDq3kpONFEPTUAy0ZrROw781Wvvag4+MXQrleQSXDagd//QQN00cclv3cEIqbJaGwkdxsjAIc3pPoB4kgeF57IuZhdJS2xA1670m0omHqCI41WADn2US4EJWCohnVQwqzo7CszUsmFp1A9U3yZ84Qm7H3C/EMLKwio/0QlJE5BMtHBCxNnbv/G5qw81Rx4tQUTaQ1hV1Qh7CIMIqbhQgE1rWO/ARAAIAL9fRO8U6crDJYvg4QGH75Ynf8mvt5LLAksoAkoF8myuKgETkkrIhjKDilVcDpjQkStRzlFggn//hN3n/VgI4XChqhNNVKQJSCZaKCHi0jtv+/xf3lUffPhYEFmJKqwmrtSqSX7JSCE5AEnUWZgCBSahFkNBXadKLQsoHEfvifekE9rEGKCCJbKXCJVWVHVFMKmiXSULJhi+8oRdD/jBEMLBBTbDRCcQTUAy0cIIEbd252bdH8DaQ/RGQ9ojQtIGgUjcze6AiJRCpBrLl0CE9IEYezqHztRhFZDiSSOte+qvpZQ8oLB00gFJBwlR1QW8WZHsJkvdHpNZmDHIiP0oHpg0gDddeOZ53x1CuHPuBpjohKUJSCZaCCHi9rcd+Mynj2L94wB5EFmJO9Q7ozoBSrfsF4WhnYzrINLo8nJBJAEQrdQCgBRAilLJgJ3txhBSlEbIfxiglMGEDPGVABMysM+gEmDCUkofmKxgc/sTdz3o3BDCN/srPtFETBOQTLRqQsSTrj5wwxdWEH9Qr5yKlg22gQBGo7rcI1IDQtPU0AC/6ZBApCaFVg+AtPmmADIYPJITgPspGUAhuH6piqsfUErSCR32KFdnzXrARB6vIvfCy2NejmC98uhdDzprZwgHBlR/ookAYAKSiVZJiHjqm2694YsQ8DvlyiwCEWUP6QER2iMiD2CMwKFAxFdjlQDEBQ8sSCMmTok8kOAbuwy4H1DGgkkIwMt+AaCq2t3uJIUswSyCCS8ZJqsJJNLJEVyBc5fP+I4LTrvPvw1qgIlOeJqAZKK5CRHPeMv+67/UAJw9BERWGrKDtCCyQpJHByJ8hpZ4LS5KAzuAp8YaAiAl8Fjk0l+AArAUQGUMoMRlwd2+EgKTuBQYUjCZteu62AjfAyYrWMOO5ZN+5LdO++m/W2DTTHSc0gQkE81FiHjmVfuv+9cZVKf2gQgb1cXO9W7FVtPZRxoRJ24yzIJIagcZCiA5KSWp35zSSCnMWECxYMJx6AiUFkwoDttAOgmlalVbS3IXPAgjfC+YNFAthwdceNp5NwxqjIlOWJqAZKLRdAfecdY7D3zhaxXCsgWRaFjPgMgKnd6LZHiXIEKqLAIRbRMZI4XkACQHEIuSSkrAMhRQ0ntfOqminw8mFVQw68CEjldJwEQY4T0waQDhzvrQI59x1gXvW3XjTHTc0gQkE42iv779f3zv3x/56j/TezU8EEmX9zKI1NBA0/DSXnl2VgO80gsGgMhaA8hcxvbE31u5lQeUodKJBJN2Bdfagsk3m7t++1l7Hn71gCaZ6ASkCUgmGkzvv/2LP7H3yK1/XQIRWtJLbzBcUUZ1DSIrHVT0g0gKIO0/pPc9AJIHlDLJeH3qrJxvDlRKgDIGTAhE5D+/AItXbi2Jo1XGgMkdeOjpf7D7giuLlZ/ohKQJSCYaRO8+8J/Ov705dK09N8sDET69txZHnmAEEZJQAKB78yHbQ3jPyEgpZA4AWc1KLY9y+0b6wnkSipVOKhHCAxSWR0L3ThPaBS+WB0OI0okGEwYZOpLeAxMEhH1H77jsuec84o/maqCJjluagGSiXvqzA5/5jUPN0XfkQES9S6QHROhIeIAURNi03g8iOSmkD0BGgccqdVvFZcGuvwAU9c6SYdJJkJ8u/iy0YBCPUBkAJny6sA8m32jueNUf7nnEUwe0zkQnCE1AMlGR3rT3hsc2Vf3WeUBkpTvBt27EC6vc5b3j7CHWFuJJISUAWRVwqMCZ4eM4W9uH5y7vCUzoehyY0JLgbid8VHPx+VtVVXWbFktg0qnJBJhQ3Q80h159yZ4LnjKkpSY6/mkCkomy9MZbrrsQZ/D6ISDC7xApg4hc3tsgHQwPIEGEbSXDVFklKaQIIAXgGKviytpNEEgvpcINkU5yqq7cqi4GEfKpOhAZDya0cTEeWS8q0QIKwjeag6/8wz0Pe9qIZproOKUJSCZy6Q23fupJAPinZRBpwUKCSI28uXAoiCjYWIUqaxCAOPiw6A2JRAocgu8+RjoZuqorLgsGALKeVEEY4knFJcCktAu+BCYHVu648pKzH/H0OZtoouOEJiCZKKGr9l/39IDwJ9Q9+kGENhrWsNKx/5WmDTlEEuFjUBajynIN7okwUgYP+YIsn+wmwSEhYTSgrMZuUmkftaIrHvYod7uTRNK92yRKKoHP5aL/tjgtmNyOh664ePcFF/c0w0THMU1AMpGi1936iWfNoHopQIgAAgD0vkLxtsLxINJEldU4SWQRIKKWDi/CRJKhZEAF+lPKKhdQ+qSTkqorDyZsQcmBSYAKllYNJnddfvHuhz9zfItNdDzQBCQTRXrTN657XlPDZWsLIsLQDgCDQGSAPUTHScFC1kfH92koqJQGUM6PjdYUiA4pSeP1SScahARkFJYHDwWTJZhByIDJzFFz3bly6KVPP/uCSwpNMtFxShOQTAQAAK/b+/EXzqrZc61NpB9Emnj4Yt20Ww1Xup0gviQyZmUWgsQEK4XEeJj6S0LUPhp63BjDGk1RFjbirwKI4IcPEAACGGDJSCc9qq5KvMPELg/WYEIvxarEGVxlySRnM7lz5a6XPP3shz+nv70mOp5oApKJ4A23XveyAPBMAP1qXFqY2yeJzA0iDQCG4SCi3VJJRN5H/9JR8RmHMTASklXAvvrKd+L9HsZVhw2JYkyBCYVdbzDJqbnuwiMvfNruh17a23gTHTc0AckJTlfdev0rAzRPkYb1PhBZgbrbL9It/0VeneWBCH9SSUTZQECrs2ivu7aN8G884DFeiXRQq7fSEJLKvuPJyh/sGv8l3oTEN6Pq6gAhqq2GgUkQgMVg0irU+sGkO5OrAxO73yQHJnfg4Rc8Y/cvPn+OxpvoGKQJSE5gumrvp14bKnziUJsIbTZcLYg00eaRGs8bwBY4WjQB+pX2EfsPHDSmLT3yEsY4u4lH/QPIC6EljhYcghucWb51oVthX+k1wg+TTOgVWasFk4O48kdP3f2Qy3qbaKJjniYgOUHpqn2ffGMI4fFDbCJHxQupLIjQS6sQ2lN/EbCTavS7RFBIIQAaRGi3O5CPABFa3aVkEdTxIZY/r8ZKfESAUIw5hDLDyKi8ylaULow5Wh5CalCXwKJ8Aqgj5Tm0XtHFEomWTAACzNTGxRZMqlDB0gAwSQ3wDRyB+rkX7XrIi/NtN9HxQBOQnID0+r2fuLqqqt+SIKLer94BBa4hiLSShwSEDjgQIHVtw7IqS4MGAAOh8lFB0jg5GgslwweRkCWC69reR0M8u5LUEQTCEDyoAx1J7RXEOVmwlmDSupUkkyMrK8+96OwJTI5nmoDkBKPX7fv422dh9uiSTaTudqqv4FAQoXOz+kFESh8yDJUl3uEAdRYAS1PFlVsl9VaZpC09sauPJGtot9fSVFI5q7qkgqsCAL1qq3XVNpTuN/Bud/JZdzCB5lkX7Xrwy+druYk2O01AcgLRa/Z97N3LYenXpE1kPUAk2j0EQ1druaIjyxrCYhLDQ3TnC0Q2lDtyitMKqWqLL8NckJO1goRSCPZLIaVzb7l9koK2hEhgoJApUACAkVIWASZVPCl4EJjUKxdfdNZDrig0xkTHKE1AcoLQK/dee832asujpDprUSDSGrhTEGkQFWAxSPAxjS0OSD9tD4luBkGkKkv+MzUZsACYFzBWQ1Z9pUEmlVVSVRcjirWBSBeSVOiPTPHKZhKXE/tgAh0wjAeTfgP8oeboU5+y5/xXzd+SE21GmoDkBKBX3PKR95802/pLfTaR9hj41YEInaKFCEbqoSsGArKHWPiI18igQxRVWcoNDWjkQaLPqL5AU3viUza2BxGgAgBUaiu9gZGZswadoEABACBULMFUYGCnk1AWCyb9ksnB5uBFT93zsNdkm22iY44mIDnO6WW3fOhDp822XyBtIh6ILEISqaMKi5k9xQHrZkAkHpJojPKWscfVWdGGYgnd6yTsegkkWaN6ViHmSCP62lVzCdUW59Oqsaog4xKogGLwVdAgtNZgchTwiU/a9aDXD2vEiTY7TUByHNOLb37ftbuWTjlf2kTWQhKpo52DQYTVXNituCJwaASIdMt7ka6MOisSAjZ9qiytErOByrjRJ6eUyTOL94Y3AMNXJi62QEDeSs0FKGQQljIYKIiqzj4SOsGHw1eCwbeSTwX2GPq1ApO78PDjn7b7F99cbKyJjgmagOQ4pRfd/N5P7l469bw+m8hqQKQB2ngIECULsfJKAkqEFZI4EJQfgLO8t+PqcpOhvWLQKKmzTNgNImvVyASwCihAE74KIUEjliZiqA48RAgpdQgJRbq1ydLGxMWCid1ngoBwEA499mm7LnjbmHacaPPRBCTHIV120zU3nLV82s+vFYi0UkWnygIAsmTQCio+/kQb1huEyPCTpb/kao3oCkSEnOKJHTGUvHOogCjzrdoqDKMer6Kqy6iyZD5KzRXIVyq0hFtgWCJ7SLSZBBmTVFxd3ADx3e2LMMB7Bz0iIByeHX3MU04//x35lppos9MEJMcZXbb3ms+eVZ32M302kblBBFv4aEDJGXEvhzSq894RXp1FvvLFUdJ2IikCE4VMeLyNockKKeu9UsuSAhwlfdhw0kfHsRKGSS6qviT4KJcQWpsJQ4eWRrprudarivdjwKT/OBUqPwLCwSMHf+Npd3vYnw9syok2GU1AchzR82/6i78+Z/n0n5AgsjhJpAGk6wgEHUA1WkHFANOVwbxPJCqy0KqzIN41apMhKD9XUYU6xLyQMW+8eQdSEEw/l4hVWgGAMK63dg1J1hZijesAAUIldsvLT+A0ecdJG7bdX7JYMGnzCtBgAwfx8K8+fc8F14xuxIk2nCYgOU7o0hv/4m/vvuX0H5XqLAB9dtbcq7MaesEuxMMZWzVUagchSQWQDeusACPjOzoAIq4abQlx1m4lwGF8XRpiT1k4CVtGabAFde2JK6mFJVpQAh8XL9OILkJKUacKh8BGdqXg6lRgcr9JF7cFsNlCwMTaTGps4I5Ddz3ymff8pff1N+xEm4kmIDkO6Dk3vvOT527Zc14JRJpOEhkDIq1KimSaHIiwhFADRgABoHOzoPNtlO2kdRMwQdIHb3OH5HB3pFglw/piAGNozLkHULRrlNPSoGKkEh0CQqWsKAIYKDrDiF6tZewoQDYUmWYroZABPoTVg4m0mZCaq8YG6lDf/6JdD/n04LacaMNpApJjnJ7z9Xe/69ytZ/66VGcB+CBCbzQcBCKdSqq1sPCy4ShN0NEo0LF2CSCAzMOjeg1AqqXQAEgbVB6Joi9QQ4QiKtcQ5j9MdlkUFU3pTnB5mlYuxSpJTNpA5HH0DAfaYK9XbJGarDJgAkDgkQeTFhRWCyasViMwqWFW1z/0u2ef/w9Dmm2ijacJSI5het6N73zVPbbsefJiQaSGJkobGkTiK2ujrQQiUMhVWHGfCLJRXoKHtzNdrc5S4MGh9JVVb2myoTOeLo2Blz51FboByqoutpnk1oMJy4rRghGDl4kRoLT75QGitCHCsQE+dEZ9rfJq1WCc90zILbMqDyZD3mciwaStdoCjuALfvv3cc84/+d43Z5ppok1ESxtdgInmo+d9/V2X3n3Lrif3qbNaNdZAEGnqbhkvRleSLqR9Q4JIozYS8uota1inRVuuTYSRI7MOiwAsDw99BviCU9Z1CKUxg/ZD69o5BhuXwQXpTkpZClT0MmjqA6FLE7Fhmwk9i9AAAxBCAwECNp1hPkCDACFgK79g+3zb1VttXhW2pQuhva8BYAYBABqoG4CqClBjBbPQ9sG2bBUANAChAsCmq9wMIIhz0Dow04sBALaEJfjXg1+9CRFPCSHckTTzRJuKJonkGKRL//1dv3u3bbuuqgaASOn1uAQiDTTQNI0LIur9IEj7RQAghhK2DtTSBC8NZrdEzog71l2TOgAmlhLQSi5fLEkZ/HCwWJRE0hcjiWuM61k1l9jrYYlWbHFQtS6sAweKywb5uGw4SIN8UOHbAyE7q0YgAzzthK+gqrq3K2YlE34H/CwEllCyNhOEo4h3/P6u8/aEEA7mmmOijacJSI4xetGN1/zSGcs7378UqoWDSNxsCO3yW7nEF7pDFnl1lrB4IEsc0Pmy2ovdFING3gUvonbXApF0FFBAlAWOPBRYu0wmxEgqDCNvAVYmkLNIK/pk44fK9ZOAos/ZIjsJeRsDvFqtRWXggx17wSSEznYyHkxmQEuDNZisYHPTE3c96NtCCEeKzTjRhtEEJMcQvXT/B+97arPtPy+FmQMiLaum/SGDQCS+c70MIu1eEIIP/fpbjMb3towIjZBiyEVz/MQmQtHFii1QV579RFIGdBLnYSCxNhJJaiHPx9XAohdseaASEnuKNK4TOMgUIlAEeU82Ci3JkC2EpJXQBWL7iQcmLTiUwGSpA5Gl7hiVqgAmR7H5l9/f9aB7hxBWCo080QbRBCTHCF2997rvvjPU/7IlLCkQaaJkkYJIaxupYWUoiHTHnkgVFL9TREshrZpLrrxie4qwqIjwUoJhVk2SC5NUcWnUaKy7imWdF2gNsZHmGDU5o7m8LIWpUifQoCJXa6USThUqmx0EIY3IPSPtPfBqrhieDe8skUgwYRCQYEIqq9WCSQP4/1945nk/MYHJ5qMJSI4B+sqBr+z8WP0vt21dAIjUHWAwiDRRQpAg0gB0e0gMiKjj4SGqr+KKLiGBtOENNMiztgyDVkt8h4BHD3BQakkn79lfMhZsioMo5H1dyUJcWv8EIBJAsVJPamexgCJ3mHN43luSrO6KfgFmXZzVgMlSPJtrGJgg4qd/d9d5DwwhpMaziTaM+patT7TBhIgnfaz+H/uGgEg9AkRqKIOIXNYrQQShBCINgwj6IEL5SV4uoYq4f5sP+3Ia/GU/FFdSVQYQZIS4NyYNi0lOI55R6WvylysS0nzFHakTkcskFlh3acdM4pNSSxZQns7cUnvUDSfKZxZQeIhpAdIx/00sYXy/DDZQm7wbZP8GeC9S3Qh7HNARPdQn61ZKRt4ES/2V0gFqx1Ya+vm3HPj0X87xmCZaQ5okkk1MiLjtqn2f/Nqsmu3yQAShk0Di4KwHgEgHGsj2EARaoCtARKiuiKlINkZMTK3O4nJrhgadYV0wUP5n5BBwoWLnJI+E6Sf7U3pbuOxaSiC4l36A/iQSySUrrQQ7+8tJKdoIzyuzKDtetUXqMKXEiqu3QpSOaKkwyTDSdsKHPnbSRExTrOKqWsmkkztg1kkhZHRv1V3tfQUsyXiSyTJUb/3tXQ94XLGBJ1o3moBkkxIibrnqwHX/PMPqO4aBCO0TGQgiEShoRiqW+koQUbvNUxDhIxqhm8E6r8ZttIIqAgjlp3y1RCHd9VVsqLyf44PlgGtCGiMGqrqck31tSHlwow8oAiyiE3bMXxvfCUw4Rojgw8Z1BhMAVmPFVWACTCqACCCVPF9LgEklVFoumAQKlwGTavmK3z7j5y7ONuhE60YTkGxCQsSlN+2//m8A4IcB+MVOpDhqoMmASAMrHQSsNGQzqaPkkQMRtlfwKiyMUktXJgIN2mvGSofIyxMQiYZ68m/DR02KkU1E8jAEPPqAYzhojJVkNPXJEm6cHnAZBipBeRtoMHFZiiD3KpGCgjjEESBKNUFKI/J0YT5sPoLOCDCpoDO6V2QvqdgtAROOD8Bgsph9nHcAACAASURBVKVavuSxZ/zcS5MGnGhdaQKSTUaIWL1h/6c+FQB+HiB9Re5QEEFAODoSRFif3h6wGPXhAApEhCVE73qnOpCqStkCGCyM3NHVW7F/cwU94IEySKl13fjBS3cImgwcPRoG0I3IPL0EKtoCn8CLo/aKckqQ93lAkWDS3ot9JoHBhMGjDCZKzVWQTPrAZClCjwMmYelxjz3z59+aNNxE60YTkGwyesv+T713BfGXcyBCBskaW0CpoW6Phu/Mkyvdke8SRMjQic0wEOGNhxDTIMZaApE2KWLqMgUwNhAhdxjpxAOPxF245MHDB41MYkNiZSn0DSPHO+Q8OueyDAIZKcVTeVEJpdhiVnOFbjWXoKqzfXBsXslFwDAETCLzD3QMfR5MlqrWeiLBhNReoQAmCAg7Z1sf9uun/8yH/QadaK1pApJNRG898Ok3HG1WnjAEROpus+HqQKTLg5h+t3GRqKEwBDYRFMwSXwClwlIgwoIIKAuJsH9o2YQ9x4FHBgKMIyKue693gSZ4t344z68MKNLuIX3ZuE5hVJxKG+glmJBsMi+YtBIJqcV4eW8fmNDyYAaTNqYHJmcsn3yfX9l5379NG3GitaYJSDYJvfXWG154FOrnBgiuTaRVTzUjQIQM8xpEIpAUQYTO1OoHESmFUHqS4WtIQAUgbR0FFQBkMHhg0beXfLuKddD6pXkGUQIuicpqmPqrBCjMaGUqAiyCBpMQQnTj0Gwn6QeTkNzT3pQcmFShitIGyRsSTKKKK+4/mQnjuwaTGhv4vpPP/faf2/59/8tp8onWkKbTfzcBvfnA9U882rQgQixLvmedQYTX33sgEtfezwEi8o2FCAwiamkvogmn9FXQYLTEJ0ZzDutYSFwAyUkfBh6w4OcQ6p85SaFVT0rB3ZNoSxrEefPtJXax+Te2RcDoLtuw5fXCDVo3RAkoTecaICAAhpgoI38g+0PbjwIEqDAAhPb5V4BtITHQscAcP3DOVVemJgSooD19uMEKICBU2EDTnQpcQQV1aFMO0K5GXAoVrMQTg7smwAoAaoDQvluxATqBuKWlUME/3fHVf0PEM0II3/CexkRrQ5NEssF09d7PPupIdeQaAhE+fReADmGU71mvO4BYIUBpeIlvu+Q3AB2EAg1vNOwDEYw5OiCCJJO0JNVi7T10m9ZAgIhWdYFwiyCSARCPzycQgRl3Q+glBsyfkvDF1HwaPYhCIo+Y9BLxRFwaFVfQbp6EUklfpSoLsR2qoHMmaUJKN3wQJEsZAADtZnmWDmilVgyXlUyq7riVbjd7EGquUMWDHGnHO0sm/vvfSZW20tR3/d7uB+0JIdxZaOaJFkgTkGwgve9bf3u/Ww/f9jkJIgDpe9ZrbN8VUoc+EGFJZC4QQZYcciDSACoxIYIIkj+5SrAwCq7BAOJLHyXwyAGHCpOgiA9SgykZRRl7RjZ+Hli0kVxejgOUyvgEJSaRKkrnaVVdJTCBSh+30gcmsy4dApN2dZcPJvSWxRyY2OPnAwAcQbzl93c98NzpxOD1oQlINoj+7tD//K7/745//bJ9p0g8RmK0JEISzGpBhFyGgAgK6UUz+DaYlU1AGOJlKrAqALFvXHSi2oQGhh9G/UCRhszGyYCKAo/guHF0Nx8+Sl74qLyI7fOPWhYcfDAJAJGJrx5Mqng2F21EnIWq95W9+UMemy9feOaDvn865HHtaTprawMIEXf9zbe+UgSRBun8IZJPeNUWgwiuI4g0ShWFgO1LqQyItPVpY9B9V2kfRFAFArbH8FcuMRbJJRsedTSy4cgviPJ637xPOVY5Jt8QEOs4tmLotJWuk6yHToWWZEcpkMKpZ9ddoV78gECnMbc/jWhfedgmr+ajON1SjEbuPQpdf+v6GKWB7FJ3lWig3bdEJzDQBEmeH9ee1lDH5e5sD2y6/s4bYulcrgqq737dvk/+DSJOfG6NaZJI1pkQcedV+6//9xnAySmIpCf5Jq/IbeoWaKDpdq1DPAoFkA3tNITJAL4qEEHHdN4wo4sgIrgmqghspI8x0NzrDBLg4KQy7nSFOb+8i/Ite7vkGdNNiMIdSDEgMyCFwR45UMBApg4RV0oROsfKeChpxKi6KhEgSP/AWxSjlSWMl0zkCq9ZtG9UbDupOqkDyi/G0icGV6ocJJkcwfrTF+3+hfu7TTvRQmgCknUkRDzpTfs/9S8A4W5DQKT0YioCEex2tC8SRORRJ2UQEWDigkg6C0ZOyKQAUfpI281EUndo0ktiZ9LroyGBBgyfkAcHN5UeUAkOalk7ig8okvmDAyaVKevagEm6zyQFE3q7Ir261wOTJcdWMgt0kEoKJoeb+r1P3vMLj3KadKIF0AQk60SIuPVN+6//LwDwfXkQYTtI33HwrdqBQSSqBggmOrXC2kkiQoGSARGjdBktheQBBMH5A/cuiwe+xxwCSc8gchh/wTg/FFSGAUqQniolXzrpYEFIMpWIr3a/94FJh1h8sCMo4KD71g6TBxN5LpcEkyWSSmifiTlKxQOTu+ojb3zaWQ/93aThJlo1TUCyDoSI1dW33vC5o6H5KYDM+VlNA00YdpIvgwgCIOmXSXu9FiDSsW8LIihDEFfvk0JWCSCu9NEHHiWo0RRS7dgwyowkj90nLil66Kt5AGVu6aQMJrSDnRIbDyZmB3wV2X0LHCSNQP74+aWR53JxGyEcgSNPvmjXQ/80abSJVkUTkKwDvXn/De+rsX5EDkTIiK5tIi2INNhESUUZ4aEFE34p1UAQAZKGCDxWAyJGwSUMxNFnhBprCIBkFVzou6d30mGIIqyfiqorxzOU7hxQmQdQStIJgUkAEcRRdckko5JqAJhQWQhMqph2CiZ0EGTFMdITg0PQy4LBP+RxKYIJ2Uva8LFGIUADCBXCzz5h93mfg4kWRtNqhjWm1+z9+KtrrB8hB7I9+kS/3ZBtIggIdQcMEkQaAhGgXev8VpAWGIhF50AEEhCJZVtrEOlElRRErCKMpSbCES3roFqQpdzVHV1wYP5AGnYOStMJnEPPqrHkLtZHtYKuB7kJRp++dZLy53udB0uRKDKWTwA5emyvtko86QCUR+ZQn8LYvwH5NQisdm1U2DYNgNhfu/7RdBMsxHYcNIBxGTy9dTGehE1fFPG68LI1KwhwFOrPvueWG76z57FONIImIFlDuvKWa/9guZpdJDcc+kefkCTCbvLok5Vu8NBySnpFbqPSw7hsNA5KwbDVjnVipgJEEBYFImiYmlR7CQZHvmKJKaWcAshwZqsxRQKHTMHO54nDcxuO/WoosvURTFaBSx5UPJD0gBFNbulyaAtgsu0FcxeOKrc5wYR/GUwUgCNNpqhfck+tY9+UYMKTKFoOz+/codcq1BFMaNEKgn5dLwLAcliC/dWRL9544407YKKF0AQka0Sv3PuRX90x23K53bVOg6sG5/wsaJLzs1bIGN90M6wIApI5EuNhWKCBCKBP8Y2D2YCIZuarARFQ6UjGnjCxXgDh/DiOSNAy14bKo8FDE0aVIH9jtnMTM/4SwMi6yvqWQGUAoKiWBUjBmQCM72Xa0gXJMawOTOgnvsDZtG8CO9RmABDBhPKj/VMdNNQgJA5xInYDGG2Jyg1SMFkKs1M/tPUfpj0mC6LJRrIG9IpbP/Jj23D5C0thVsVBAtB15/5d663Y3sT9InXTzqv0y6nEe9a7QVsTU1GDGlm1kJFEtJpjIIgIYCQ3CyIUQLM5DSAyVc1sNICYkCay4y5LMhghbEmHU/6QExNOGzxMGsI9MbFYG0cSI9pQPNuHKqdniA/6Le/abtJZzTnqIJsJv0lRrNWq+ldySbdocIfOlhKq7p3u+aNUaPd7tJ8U9pggwkcu3H3eBcnDmGgUTUCyYLp672fOPjxb+ccK4Uw507d7RWpsX4Pb6n1r5+gT2s0uZmRRpSVABKCdDQpJxQMRmjGWQaSLtSoQEcy4B0QkgMj09GxZhQR7MQ949MLFGDTpGUF9AGOPNNF3lumbKw9QDJjEUhjDuUxK3lfCYyiYhCqoHAkIAPQrevNgUin/qnVsr4GBZdYZ79tjU/rBJG5YxABVVQCTCv/0wjMe9GSYaG6axLoFEiIuHamO/FUfiLDREKNx3R59QjYREAZHliZIvgGIen0gfbBk77Fg0OhYoNQrsGAQiRoRLVXkQATlPdVRJMQqFyoQq65E6ytVlfFRH9MAyRedOP6nnE42b1k2apdEzSfa22kjimtaM7aRzs2mLyoa72UwmR4mcWwPw8bkJiYndD6b7GutpovLqIzv0EnYyP1ZyvOAYA4o7caSOkqFFq10k7VAkzBe5ELlBAgQmnDRlXs/cknycCYaTJNEsiBCxOqq/dd9oYLwY3aZLw0GNgryy6n00SdyYLSSSA0kZbT7RdQqLSQ/Yuj6gEXsBqTWDzNjpqPfFw4iIJgG5AFE3dOvTc94WFacO7AxYdrurR93UZRII8mtljOoNHkpJS+hDJVO3GXCQjKJ0oYoQ0ky0Squfskknhjc3rJaK7TucU8JLQkOLJXIXeuhU3PRkSrl3e/D3v1+29E7futZ5zziz2Ci0TRJJAui1+z7xIc9EKGZVo2squIVWuLoE+DljTQXq+NsDruZlJzFMYhADAfdHcZZLoMIxLjt/caCiJ5hAwkaIObiIpKQSigHY1COZZK1FNJBKhnkQYQN5/3fEhYleYrypGWy+dsai+eQaz95HyPZtM29AnXZP2xaqnekcdBLm58k9ba4HJ2rwvdgF4tA14ehm0TxikdqH1qZGF+9gDyOuiMeoyo57r8SkzuiAAFOWTrpbS/4+vsfCBONpkkiWQD9yS0feuPJs+2PD1B+Ta49hHEF6Ah4XmkS95ZI2whIyUOsOAJmRnKtfhOZDUkufA3gLPNFNtj7IMJ+dOWDSMq0OFT3yzyIXW1amfRsmk4s0JdlsEgiLIyslOCHCfpWxtQhjYQyRjrJGeJdu8lAyYTvOI2S8V3aPyi9St7H3fBkTxEbFEny6V7JGwCirYPeXwIQOgN8efc7bViUr+ulDYvx/fIBv7b3zjse8pxzH/GPMNFgmiSSVdJLbnrvpQQikVGLmZPcK0IbDtvX5PIx2FL95W84lMsoUc3kWsYvQCQyayoDzQO5bEQInSTizvotdIg4Doiks2oDF2ImHUtPs3o5d42zaGcmnZFAREWjmwURliIQeLbvgwiO+PpE9ZPfNIwnPcnJgS4758izeBRxgH/N8/GBHs0zYoTvk0zsM1RxEMAuC5a1pUBRukZOU1tKAHhJic47unV7SwB43MSXLjRyCbDesFjaY4IY7rn7pJPfc8m/v/9M+8QmytMEJKugF+z94GPPXD71BaP2imD7rnUE2ivC7w+pqTPTnhGQjLs74ReYPdBgUsOv4UFNzIYGIoFMLKMqr2U4FHAYiLCrBZGIFnMwu+6+D0CkmwzXAxwaFIixRcQZ9JULHVDUJQWZPKgoSCnUiQGFyw9u++rnJJo2ad9BYJJUZRiY2Dxaxs1xbb1l34nhKC+MLF9M1NodJ7xRl8CkG3fdKxcITPggVFYnt2lYMIF733PL9g/aak+UpwlI5qSLb3zHT58ddlxpQYSUUdm9It2cqW44HIOIXl2CnYGdGBzpilsfEOG6j1kNA0izvJSh0+txGZJgLhCRbIYGfswD+BW85Bo4iMwZUikkZbqDACQBD+XF7ZWAAqiyDv2mEQTIQA5YcqAinp6po2rnRDqBWAfdftxf4u9gMAmx/IAcQ8VLfrV/o9K16XNPi/VB2lPaCH/ZnxvR/yPTBwIRBhO5SpLPqNMnR/AZdhZMAALMqtlPvWrfx/4cJhpEE5DMQRd/6eqzv2v5rLdAgJ0WRNoODOJcLLZ9rNAuXLPhkMTzlrG0HVvt7BWDRp2fhWD8WqKhLUFEz+qZ6UQGYUBhGIgYBmJnxhgEC+zaKEaWM3DN2EDlZ8AiAyBR+khSkgAkQCP62e8YGNGMLgGZArDoulpAkWWG5FnJ+sp66ucqXGWbi8KVwUT0HQBRIe9ZN6JStCy9u47iCqdPKxApNALEMcAllUf/SHVWB5DCXE6yhTyGRS4LrjF9wyKFLYHJtrD0H1++930vhIl6aQKSOeg79tztLyDAd3vLfOXRDPEcLbNXxIJInEnRGw+BBzMNWp6j8W8joAI6UIlCv2K4TDQYOTUNIipf4IEs48u02cOCiGSYw2bHklGImMIzDyA6N8F4hbQxCDCY7w/6SgZaykFUUIGKqmkGUETDOvW3DFiCgPilKEEDQxlMdCnS56fBRE42JJjE/mbS10+MVa+UDYeR7YlRBcXL3jlFAgm9x4QkElTjUa6WlMDFZQ1wanXKcy+75f2PgYmKNAHJSLpy30ffXoVwP+80XznD4VNImyheRzEbUhCRxnG9a72Jg5ZDdQy3K0NUfwlmqJY3ZlRa5Abx2nCxgn/KzMogImP5jIwZIPnoGflQAJGcXrP25M4DB5Na+auwwQEYCSqSGXPEVEpJAcW2Rdr+lklzRi6YUGwXTHS+/CzLYNJSk+ZB5Vfl0WlLqYfUoWZxuujjXZxGM/+anz4gQFwWTCAhlwUjyMNSeVx6y4IrCHDW7OQrn/P1d9wXJsrSBCQj6GW3fOCPdoTlR0u7iBSvWVxm43orTnfgIVaQRBFcgYlYuRIZjZh5RS4iujryDC2dv1mGM94ukjAu9EFEeBqmGMCkoBgoh5OpyLIZVtcLIHnwSJi98U+Yfu+3x8fLKxjwEAFHAYrKn5rVARMBBOSkWjUBE51nbHPZWtbfltsJS+PFqrg4bbnKsCu3Ag+2jzAoS1uJGIld/+BXMOiVXOroeayjxELjTE/WAADgjHtsPeetz7/9XbvSmk8EMAHJYLrsxmv+487ZSc+3IEIznvwy364zN2Ti64aNYv78q3atx8EuWQEod7mXnYJKQCFvbfiUTEUwIwlQiqH0gwhGfxuf65fmAUVVVgI3Nn8KbwAkBx5g/QQrjt9hCBK/iL5XAiyZcigoKACKbLQIJihT4faUOVAg2YOGgIkJoa6T30QiRRVDSTGIbppyI2J8NmjDaxVvmxWvY6xFaumyYIxn2cllwQQ0eiWXXhbc7ntpvmfPod1/CRO5NAHJALrspnf+6J6lna+ukmW+bZebd5lv0w2COqbUMYZGMjj+ALQDh/TPceYGkITvAnd/zHV4USaRZuzRzWE2ZRBR8OCqODwQkaE0gzQAIqSQfgApgYcIJdFD6KTGfBhNNKpYgPFARRYiARTzXIixJq2K5j62q2Xu48CktCwYQC6ayD1/Zv6y9rLMXC8eTwwWon+jONUh9iHeEWVfnUCpeCu57LJgPmFCruTqxqcBk1mFP/uqWz72NpgooQlIeuj5/3b1aXuW97wtVME9iFG9/hapO4p3IphlvrJz06DhwcEDJf6qwSGZOoviUS4RDFgyBBqQSu+MbS1yTD46e25o/O2MVPgOBREZFQGjBUrOZlV+vQDigIcBDgMHmtkNJBs3BRhQZZXlFUVJykqecj6uGbTIywUTbrd+MBF5yrplwIQuGieSd4f6p1VJNfrNhfI5UL1lClIalXtR2mbmRSc0zihNuZKLT49AYbeseeIXT9curOSaLf3my/Z+8DkwkaIJSHpo1467XRMAvj93ECO9wU0euCiPhPdWaLXpcEfl+Zge7MLkHuMp9Y5ReTXQgOTA8uwjzd7b0OxgmZVka6AASqaQ/UUAFWMkiNDtsBVJPoAoxi1QRDEsQ6FLH0d8jXihWkiVxAGVIeWnstv2S6STVYGJTMzmZRoJVWghPXBgyfxlqWwrsbqVyiXrLu6QwuvxIGtLqmJWDfJHLveVy4LptOBWLV0DCvWWXgDDpQ4Q4NRqx2Uv+Pp7fx0mijQBSYGu2PuRNy3PwgNzK7TivhDEaBfRR8Kju8zXrpGPoCHEdmak0HVsEKOQxX9pGOy8EpaGyIO7CyzvdOgkrGVOBlB6GZMBsQyIoL1X4bhgmgn3MWAAOaunFANnokChSdqun0Q2GmAA0zB01SNRiVqLR+5JJ7IcnGAvmKSpA9i0VekLIUR+Eky8OBRW1UmptYSMjHzHZnhdJAk4bXtgDO+DSetGk0Ayxq909ky1kgv0Sq62uG26MwjV2Vt2vvL5N77jh2EiAJiAJEt/vPf9zzql2vo7Y1Zopaf5Ng6IcCdXSxbVUSd6Rzoi7TMWA0dJG5rFWGlEUrLj20oj8cqLK667H+zxV4woCyKakSZszJNCEBTT1QAi2YiqQQcYElyTWo76ZFMRwAKo6xOfeueXAEqMwv1DNmoRTFSbcll0Ero9bTvafPpUXF5bxhxsPbznm9zoNqHxB8BSiRwLKNoQRd8XowsIphg82hG60kiNQmkllz5GBQLuOWfr2W97/pffeSpMNAGJR8+58ZpfOm128os0iFDH1ZsN7QotucxXgoHU1Vow0K/ClTM8acMQA0f961EsBx0xCck2ZDgwLo1hEHbQq5SMZDKaGTnp29lzZLY6Z1MnkZ/IUzMoTNRBXBLzQZHWgG8EDPVk07YuSSpWQonP32OsLpg4bWuvEwnPtEMCNqal0sZLaqnqE7S7DR0Vq4hJ2o2qv4QDsTIx9ov0qEdqZ/moWhBpY/Cy4G480wvlkCd+8r3vCLz3iykAIP7gOWfsmVZywQQkCV1y67u+957LO19XISxJpswAInaui45HK7TqZIWW1LNKViNnWmI9PHVW4rUIyl8eR8FDVABRo9+AKKkkjcghQuPXY0S5X12i9Dpx7QER4qxoXYvM1cCeK5n1gEa8HPIxjSbBxQ8lmKBtnRhR1BcT1V3cMY5pXVXLmD5iw8j2lWXL9Q/bguyhmb50NkEgQoQJS+NAl7vpYug8ZV/X58jpHlCLZcFy7OhlwbziMqqisYEm0NEqXRijSaB2DBAAEM579S0fe6PTTCcUTUBi6J7NrjeFEM4OBeM6AsJKw6/MLa/QkmDB/KZR+mHQ47cLTeNereqKQQXXg+RSDC5OUYUTAz3HeGL4BJHGMCBUzL8vvgURmUai7okM1QcQXWQHPERqmvF77NOjArxIYHHStYCirtDcxzZiFSc5zgsmaTsnvSe59tL3WopeAZ1LT16hCGvtfAl4mBTokFJqYco7xhOAxU/AXxbsreSq5Xl5iCB3vtOYDBBg62zp8S+5+X2Pc5rihKEJSAS96taPvnJWwU/57xahtxyyuDvkDC2MHRBADglaTiiPZGDRHaP6xszb4vgUSq8YhzzTvSIOs08YmPBHma8OC5nyRB8XJLS/SnMgiCTlEExCZpYDEFnRImggRNAa8vWT8EGFJBUfUEwNMyo9zkHUWTeBKoess6pk5tdXUfrp29KkzzJ53BBZuu0XHcmXronQcSzoaQMb0HmsSF+MZdJgolXNciUXAqqVXHQmlzS+c30ZTHbPdr74sps+fO+0dU4MmoCkoxff9N5f2QbLTykZ10nMjas6zBla/gqtBCZY0lBCdxzKwh9FPCPmtxcgZ0edE3nElBOoUHxVMpuU+tQhqkSG8wyZIedBxAKVYMEJiOg2IN8cgOj6ya9mW0O+8UPgb4DFsj7IAooGD4yFGwsmPrjbOg/1T/LSOfmdhuqQlUpiiHjX2LYQMVRbIY1JF9FUbvxs9BOTPUEuC0bgzcMrbEERS4LbCaG0l8SVYqE5a/ds25v91jj+aQISALhy3yfOOWtp50sB9ADA2JXk0kBxeihY43oDdmWWZl9tp2YBuSWZn3zlbevHJQGTmibPFZNfGzZhEFhIyWU4OWaBGVePYcSMdWpZpmnuHQZCnMM+AUpXq5YMUx/xNS3CuSWgYiBFlE3FdqUT+QxTcOV2Ee6oU7HPtW8Zt0q/F2gE0zdIaprAXBiAFa6YoJ1MS4yvKL2blVyijnKyxSCEcZFLXIEJ7XivxZlc0uje/rNcIo3vAQJUFfz4a/d/8oS0l0xAAgCn4Na31gG/3dt0aI3rpGON5/SYM7R4psOvnuKOTZ0furBiAJJNJPqh8gewg18POKFeBr7Sji54JPFE+pbZiN/hKq2xjMymL5hZosZJpRBdbcPUEvDgEirmM+Krl5qmqRKoyIKiqhNDjG4b3d697eNc94VI8pA+tkNgLm39LhL5BnlM4pk+iABSEWtBR7ZDI0uJPDJiK4v+xbK/dLNx2lStvSRqFcSZXO2qTHGCsJksShXXEobHv/yWDz8BTjA64YHk9bde/+K6Ovrg0s51BPOOEVrtkXtVrlgxIlkCOlf8q8O1A4YHRGNC8UBLWIBiOik/8OUZjpr6ekBBPi5zsbNqE7GsWnGYZGPzsnkIKQRUC8b81Ew5FIADhN+Ar8iAwcX6U4kMp5TSia2hlPZ8MIG0nVCnMmT/h3JBnaNTKnN0DYAEDq/sRLEnO52P2yHT9+J1o9z0VAvFc2ZXZYNEHYv+PTBRr31AHGV8P2O247IX3/z+H0hrevzSCQ0kr93/iQcvITw1/24RnoE0SqWljz+hTgixQ+nOKpljoyCBmAOKTq6HS5uOnrUBGCZhVURy+KnBI4nL5IKHI43YeNLbBRTv2jJIU3Z3ph10CXN7UpI8LYB0V9hET3YTX3Bd/W8fsPQBiiedyGTyYJIHA0nlZ+U/5/RZsHfaE2U/Til9xiqWbDQVh5l/+nwNfIioTZRMENJy6XEWnwZ4YIKd8b2BdvOifiGW3Pkugaq9qqE5a/fyKW9ymuO4pRMWSBBx60lh28ub0OxAsMxJzzzkib48Qykb1yUgcOeWgMIDIW6gMoOK5RpQo1CDlapVwmhUiusijZTT9WSxtLwihqPOUqEiA9ZtZWfF8RknahEQVx3zR5RYUPwyKnjpQgIodDyL7AsCTnwwsRMFF0xUB9EtLpiw08KqFfwOMvBZJ2XyU8r0MpWPBzIyVFAAkYKFPSdL/iN3GzFaNUBJFRfJHrzgprOTZDYrdlsHfvy1+z9xwthLTlgguXr/Z99xuDnymvKa9AAAIABJREFUg1m7iDKy0aZDuXojd/yJmqNoEOnylp06Ma7LDm8GUJueZCQJq1R19AAl+plB6vtZ/7I0kjAqEzYfdwhDzIBIzJfTUPeUrpE+QNwpcABL6HyNbwZYPEBJFreiuhPtIkoZRBtxAP18TT/KMv/e56Lz8QDBS9d38e+8vsdO6eL1RhWCxiqqO7U2kZ6FAIcUVPj50ISv6TYPkw2k6VKu47l5nvGdR2oDjbGXVI9/+S3XnhD2khMSSF6//5NPOwpHH2VVWrlNh60Kq5uFNDwLaXXtultKSYGZmpkxQTdjUkzEhHUGcOOOahlTpsZ/3jtI0qvUP1eOHJNSI9kJqdM1JbbJJMyuBCIyDQMYRgKJOQipQ+csn6OWMPp9NbDkAEUDFiaqrlhEeW3qljB83TpJI/qAkHs2aVidbsYXU3sJp5kBlUKmyZJgZ7zYettJhCi5HmMGaFh70I1Okj6gkzjMC7HqaHyXi2+6MgkwOWO27bJXnAD7S044ILly7wf+r60w+0NvvwgCJiszaqi7ZYDYLQsUdpHuBVTNAON64sKcTsVJ9oq0HEUxUr2GXo8u66MYWK5RJNPyvXU+bn7mqgAECSsUACQZCzpxh4IIYHTUJXMYOUODAIGBX09NEsuRBRQ0z0Mz6axkYhhp2sZgHHLPB3viYsFPlTDzXCWz9sgCey51mQYzaJ1fSPpM8rZF0Y7yaUsw4TJ5K7kYUOQLseRmRZ5eUt3bqxqas07auvV1uZY4XuiEAhJErHbOTn3dUWz2EIgAUMfK20WarhNTR7I717kDc6dsVNox/84tloj9xSBBAxW6DuJahdIxGsctTcNyJltGA1KGwauaOGlKhqh8DR/T7MdczwUiGcaNtnQMHhxYsZreT6yMuQTJ0tApY+dhy5PULwET03JoUh30jGQK3pOANF0ZOtM5PYBKQMlcuCV1pBcXuLAdKzqMjNuoPosmhAUTOaHUO9+7o48a3qRIq7bkZkXiAdZeAk2436v3XXtF2mLHD51QQHLVrde95ijWP+GptHJ2EX0KaM4uIgED4zhQIJL489lbYMKBHisRrFLKAIXwSkNgEg4RvVWcmplYf0xSSvJmtww4ibbKpevn0QciJnQGQJj7JNAwmCTsSCRp8wwyk0Q6IceEVfeASWJ8F78eH8+2oX1O6h4LfjYtjxwAyYgo3pE+tkYSgNDYUbRZncaMSKnr4xpM+N+TKumJ0oQwLvF37CWNYy+hSSZCCyZbqq1PeemBD53vVvU4oBMGSF699yOPrEL4PanSknpNAgVrFyH9KAK9P0TPXBRjip1SunkgorS/dqgokhJCMjRdsHDSKam1ACJIlNIpMhIvy0yOvNomYZ8JCnmqHBVrIIhwCjkAMdXCjgn0fA1Cmd6AElf4V+XNFdGtkbSMuk5+XUCYVyrRBSn2zVKivV6mzvbZO/napLx2kjCh00jv0IROwISkjKjmHm4v4aPwOzBBXDqz2XHF5Td/8qRcixzLdEIACSJu2bl08h8BEJ8QMw7x8PN2Ed50GEXY0s51kB2280dtXJdMkf7TgxjlkfGcnlNDALSnauXaQsTJeBbYgsu4jK+bHzohSrr3nEpLMWTFTMsgQs+HmbgFEFT9YghF4IjAkvpR5/CZfw5MULVNHixEiBLTR90uIhcn+AL6QJJs5s7WKZOijBDHQWwACZIaJgCMvUSomzmU7k8IPI5YqhhmLyH/uGgnqjYb6A5o/d6TZvgWt5rHOJ0QQPLWA59+zaHm6A/Ipb4YHzZGW4i1izTm7Wn2WHiewXCKALK7MyXAIl1Rx+E8dFxvQCVeoJlsLlQvsywxplJKsi62HG6aPmPKMj6TrgsimIIIR5XMG1jCcOtY/rjhE0BhJJkfTPx+4rWBSEqnrRiuU1nFUNM4frwR/QlknfPpyBdeZcsRg6RAKMeXjUXtpAAkxkHVZuj9I20o9u0ldOBjBB8gMGlF/gABZqH61cv3fuhJPU11zNFxDyRv3Hf9QxGa3+xb6ivP0Yr7RbirRGljjF1Edt6EaajuLMmG0G4SktIYuZTyAYbMv4eptUo1ce6cNNHxJOaTZytJiZz2p2vJ4VMwYIYiAKHwZRBy0hFMLj7DmKR49j1gwmk4ACKdggzutJCojsN9872glKZ0ddHJi9mTTiFE2vMhWXygw2jIj9cOmER/AyYArIUgw358/W5mf0kttBsMQu11gACnVSc974qbPvb9bjWPUTqugQQRt26fLb+gRtyCAEp10YIHAus6uUNQJ8HYdfTRKbqDYlalRS/44U4NMQyasFxoHhzoWbjNZe8gdWfbjguW/fsgp8QeMBsAXT/VLgaoPJWWAg4R3mfUAFYCUYzfNHFOFrHNlQMUKS3p+oha2WeZPmadl7ovsHlbd/DWTAwFACdWqUOAX59i7vbZJqG4odRTd55n6853/WAioEd0BR7j3QbFqOLqbCYNGdxZPa7P4xKcosuzgWbPKVtmr8+1yrFIxzWQvPubn3/FXc3hH2aVFj1Wu9SXOkEjVFr2JVUAGO0iPhCozgiQdFYOwy7uC6pEaPsLxtcMsSIVbKKFXNJgsjapX5pCUKFTZqoZfR/saRBRaQwBEfMsUDYiucUnmGsNCzEifQMotpwEJumT1b8eOLpSSVIulZNT7u4qjzwj1VteKv4zdu8K6fmrufwUvZOx7V1pKpSCipwyUl/puAeK87hAq8clH4kqcXCWBGO435X7PnZ5TxWPGTpugeS9Bz7/kLtWDj9GvzKX9JYQZw96qW/+JVXyuHDV5cQg92aK8VbEZTcNA72ntboDQQ/aIXAwHCwy+dFVIaHoF9Jyl8qoWLCtvxMlZUjDQUQE1JCA3eqywlc8UBvbycsW3gETURZyyDZvwqcluBaer/IrwYwbtddnAMbMTxnkUQecKpuJnQ7oZ0/PRAOIuO4asxEpSVAB0OdxtcDBr5RglbmOJ1VcO6rlp7zgpmuOiyXBxyWQIOKOI4CX1tCcTN1Hqqai5CFmC/EIFLFfBLrwY8/RkvDgdWapCgMR1rvODfgSsxjk4ZTBjTWAO2QBjuJn0kgZX3qVZ5i6xTANVmDsqMJIAIm2sNjK/jd+HEDhtHwwib8GTJJyyxJHP8fXq7zyKz/pkgSh8a2nM7jezhMs2FPsVa7358aL+84eJ7U+MInP1vjIVZttP4GoxeCJKJ8SzPxD73rvLpbPXj7tZU5jHHN0XALJe2//f1/0rebgfeQqLYB2fhHXhAtdZnzvgLGL1OjbRRA0GCQgkqi0vHmRJv/dIjKAe5mlIWH8sP4g701vEI/JMyyAHGhh1i9NM8801LViyqgAxDK03BdUihpQVH7OwgFV6+S5Soc+qSTjawHKenLyeRragdC22OqSGx5JN1y5ptz27gSux/iOIJfWs1RhlwQjgHp/SWPe9y5VXAidigvg3q/a97E39LbFJqfjDkj+8sDf/PS3Vg7+plZpkeQhru0rc0m1BazSAgAY8pIq5eLaRaArB4g4zFHk+ve0m6eMrX/YsNOgAbwgplGSTMZk5c+QRXxHbch+JpeMulBJDqZkSNEaQhjU19gxE9MebvpgwSRhbzp/CzQybNYvSSVPvX3CS8d/rsOeZSGJXNjBYTItkbGX2FFWqoEOI6eS7T+rvP0lwfRfk+SCjYovVVzbwtITXrDvvb84oPqblo4rIEHELSth5YVHceUMNavo/uW5OHLTED9o7wgUANmJALSaoa/zp7LJsFnbkMmYFyZ4ATNXNtxQPOkL3K8OI9AtJ6iZUIaFOJxKOql27wGRFkA6sADUb1KU1zInRFVfVokYMJHlt9Knih+PIXT9EkedZNbf73m6NrmY5bxWS6ZcmWedn6TYVkF+jiqPPJi0Wfoqrs6L0xXcAAGihEHTTTpChd73HrUfIFZzxXS5VmeFU1+CiMcsPz5mC+7Rew789fNur+/8mZBsPNQqLblKy1NpYabTEIigcit1Rs3xbWduo+SY+PgBPiZcKYE8rAwFJuHTUyCPmVrfUg4lJqSZd5qfBRG9VFfBC1gru2VhVjqxzxzQf/5OKRL/bP2x6MvBikHE1GOBAOFLlQvNoNe5vJJLu+fAJPpj2i9SFZfeyGxf0evtegdopZIA8ANX3nrta0e2wqah4wZIPnTg737oEBz5nSDmczmVFusu246QrtICd6mvbyTvAZEY35tFGjennw+aIQ4IkzDSBVFuaKZ3iwImPx2UYcRFANv2GcadSAktcERtFog+QBcKUDTjlJjmYyTKP6+iXo9Zw+dYfj4WeLPhRuXZHz15roVQbljz6O0EMAmaGceuiisQmPhLguWu9yEqrh1h64XP+vd3H5OruI4LIEHE6iAevPwIHj27HeNyLpmqtJrAe9ubJkIISxuoGYQdQJ5KK9fRs+7WCDso1ogMFkCLVWGAW1Z3y2VPvkMYkMf2dLwciKBgJjJC6pKkA1LNZacSujDxkt5+6PkVaTGMf9iqvOG0ht1xEJgkrrKCjvCVm/jJ66yKK67m5DD8riK9691TcXG67VUFAe617YyXFqu5Sem4AJL3fPPzF38T7zrPvjaXHxcmGw/VrtQunSG713MqLYC0U2ZnPkaFomn+oThuxrjAIT8wqTGl8Ji+DdG6BjecPyt1WgiND+pUePYpmYq4SspnWJLBEE/dlrkVHqVJR64uG0RrjCRDwUQ9kZEqrjBQxcUHQpZPCW7kwY5CxWU3KgIAzCD8wBW3fPCYU3Ed80DyxTv/992O1PUTvbO02iMN5Bk4dVydhZCqtABg1Sot9udwyj3LFCSseD4LBIPigJwP2kbPWhfGcMpWgsRXZJ7MRRMQAc01umu2h0jOrdNJL/PPD0FOlnNMbrE0KL0RmY5+/qsgG98feZkWd57NvCouNa0wKq5GgMUKYKLisieQ642K25/45BuvfvDgBtkEdMwDyT8d/eoVh/DIufQwAQSDQH2WVjtbyKu05Cot3VnsVWkmnbAivhcv5OmdY27YtLJwvtcGuGFfMI+ccG5Uk7gLIoDJh+KqvpBNK58n+s7KYU0Y9MCAfcEKb2jvd1tl/x4b3R47n9Ma5KUVEUZMHGzPoDBRExLfZaRVXHSkCgqJhMBkFgL8h6Wzj6mNisc0kLz7G5+/4FB96JetSku98RD1xkMWOeW+jrJKC6IrX7cXuVlLSvPaRNYXTwq5rYKJL47KTGro7N9Nz15aKUPFykNAP2AtmFIUW4dMF5HDmjdKkgvvKKc/f7zmtA1y/OtVXO2v3fU+ZBVXslEREQIEWK5mP/SSmz/wp4tqkbWmYxZIEHFppVm5pEHYQm5ihbZY7svHw8sX0kTx06zS4s4BI3evm/KB7rRz1XH+qBMRjW5Ehwlhp4owexPStDf7E9sE5SsWYVz5aJyOydKOy5wGIQ8m8l/zi3bi2amrXBWXt4pLq7ioaAECnDbb/qSnff2tDxjTJhtFxyyQvO3AZy65C4/8eMvwZQfQe0asWNk0/GbDNnxh46HpPAA0AUxBxJ3dRMFlvDSyCYb8RHNSblPo5qRVlm9sdF8ftgZFyEuK3iQv0TaoyHr85lVckp+0YfpUXBzeU3FVcK/Znhf11X8z0DEJJDfc9V/vHqB6fNbADvRegNwbD+kBzqnSMoTdHKI/3DDa7KznmKLRjCukV6HdMhZC0OGStFsHdNw2B3llWWX5Flq94YkNseQNBZOSvQRFXBkuGssNmEg+kl/FlZ7F5a3iChBg+9KW+1x6819cMrhhNoiOSSC58dBtVxzGI/eU0oicDciTfRHk2TcYfUqvzR2j0sr9858jqYgSe66bkoaO8TXlm2VG6F3ZcMFxcy+7n+D6G0DpKeGatgkXdh0zXQStrnzzjpNcvNIk0dVCBOGPgneQa2EVVxMnt1LFpaUaeXzK2eG0Z/zO/3rTt89Z5XWhYw5I3rLvugsONUcfle4ZMQ/J7BmpC8egWJUWiDB8Da5KS1J0b2x8+g/mXrqZTr4hfGAoQ1q0W74sIXUaGrU/V5N4sNcRTNp7vgIlkKS8PAwqajFMGBBmTHqFgLl483XBgc98TOIDUWPs1Mwbx31aBZ2XnDwOV3H5GxXZfsKqs1bTMZuFM79nx56Xl2u/sXRMAQkiVkvV8rMRYBbd1IOjB8NSB53sq4zs0SAmX1vTpYbsMkyllXbVEGy4oO78tFQKib/PmuZEG08rUw6+kDAq7FwIMT7vpN1E5goIugsXTAK0D7W7DsGkUJRezFVvvf3aLHpe0d8jx2W6JoA3MEJ/elxDeYSS9e5VcTmruHL2EslX6oyKC4WKS74FyVNxnVJtf+Qf/O+3/1pvVTeIjikgedO+6599CI/eR6u0OnUV6ofWSAM7WpUW9qq0iEoqrQDODAZNBzOpSfLkk9WQp7yBUW6rynhRwXTYbKTg8OSycsuXcoL2ScCEpBH+2iudopZsLH6oUg+VOuzMJBvOT69XPlpkB1xzNV4/DZmqsauvivbClcCkpOICSFVcLbAITUo8xslMYuNGRYBv377r0ufj8zclz96UhfLoDfs+cc5SVV3oGdgRPAM77xmR+D5UpaW6E/rdywMRdb8etIYDdyj/Gp7gwCBJuODfDdENiUsdLwUCBpNgeGIGSuKPBqK0BCmHT2okopYlLD+FTKoAEIr9MQxg/oO7Aa4tjqye0Lkqh3TbDkugNEzFVYs3KjLvSm27bXbt3pKlsPR9s5vvvSlVXMcMkDRhdvlRqO+upZH2QcXD0BTa08PQthOI8VkaKam0ZJfROlHTGb3+VrhzyRmFC1MrDZ39jqQhipghklKfLNGXTsKEg+drU+l+E2DpHEOQGq0IHgwgEnAsGAyTjvJenhyRSjjlNIZ79qpOQ9JCQzPrL0VfU4xNr+iYgkluIphVcUGqdRii4kpWcQnVe+6EYLm3BADgzNkpv/+0G9/+I0PbZL3omACSl+79wC9UgL9upREGCn8HOxvYuSNo0TFvB0lF2cb45+NJfwBIOvOmnrWNZhg9jH/obLfABULq5N+aDItqJFNPK10oGAjiCxZAupyCjUN/QTiJHE15hoCk41Xy5WBDO9wCO2aAkKS30H6/4EE0GkyyZ+zlVVzEf3gztN5b0shJsbO3BCDArKq23aM6fdOdEHxMAMkZ1cl/BAAVSSPylF6SJJId7MLATlKLN0sgaQRAdBKXQgxDtJYqrSETygEsJP4PUYmMmv2tahYZFDPNxdIgk5FyHCTKsuMgrlV0yeADWEDxvpxAMG0h73OgFlT4FO9SAMzVy01yMCANcfHymo+L45ByZWYfwxebtCF9aySXJL1KvX07pwYTGUVPT30VulVxxb1tUcWVPz6Fanfy0tb7X3LTn/+eV/SNok0PJJfvvfZZCHgfAF7uCwARNEi/KJGdxUM2sEvDl5wtzLdnRJADImnnbF08VogDGMBwt3QKSPBXpBEz1hK7lgw6l/ggRuXMZlX8DCML+qfj84aZDwCTAF08I4UQcLTgkUohwYBIhHFVBlNP0PnnJwlO2dPa97dvvmkL6XiMeOQS5wGB54OnPA2d1hXtISqcP7IHq7g6UUWquNSxTYXjUxAQ5N6Su28585LH/PNrzhxYxTWnTQ0kf3Dz2/ecVm17cqrSah9a3OTj7GCXgqE3K7CQMFR0teFTd8/FHyJeCjbkmIE4fOiU8hw6my0mkvH2uJhgsm4aIetHabrMOyMNZMEk0L1m+gFAabZSuBa7S4J0SaqnQDDrrxzmVGsFJy2TiyhKNo1B1DO5GJvcgOwGJx6gNCJ6xvUIqSSn4qJ4/GUbroSIIcenMEC1/GQZq3t+zxnnvCRbvXWmTQ0k96zOfHEDzd1IpUWEEjTEEfHabpIzsAu7CIJ6pCUaKo3YWAA+7xw7WzLR81Sa0ZrbRenXe2fIg0DGD+iBnCeVBOdGMutEElBgkgJKuug3/UYJJCahIKSVWgwwqFpYhl94dp66zCTr+g9+fhmA189v8IPMlydbKKcXFMKNAaY4hgqRUF3nVdb9UkteKpH/tJM97m1zj08p7y05Y7bjt5667x0/3Ff/9aBNCyQvufEj37t9tvVXc+dpkQQi33rYAAwwsAsDmAGHoSqtYdLIuLmQy0IT3p8ZWKVZ7aC8cmHmn9EWmVv364FMe4uGufWVRofldKVkYJi8ApMUUCKoRHAx9yK4hJ5YHKPO8s7pUrBiGyMjjVCwLMC6FJx4faA91K+U4gKp1NfSAQC2XHOPWEwv+7QXcsqaVXGBXu7r7i0RGhc9AW6vK5htORdPuyzfMutHmxZIzlhevhSxOUVKI/QwCBji2VkoltSBPJTRPEDZBQrSRGnOMUz0LYHIOBbQ7zsiTDGQNwPty8udO/fn4DBCPQv12kgXLp3ZOiquBEx0+eJBjAZQtDRiC6FiuwCSLG2wdhqTaOpi8nGYY7bnCIAqQUVRjZiJk49nU0kecD7VIkAMyaukPHbK1UO5yWJJxZ0Dk+iPVsWV31siDe+8EpWBRkklGGBHtfX8Z37tzx8xoPprSpsSSF5y83vvE0L1iCHLfe0R8RFeBu5g96QRAOk/j0rLJxk626WHTuuC+stHdme2jkso+2vmnClOhnl4fqT0K6cZEo6TzNwtNAwBk2DZuQAUBSoaLvRHVzNRY8XyOyAiquWXMWh/E1bnLZm/aUibrkOur9u3nFhDJxyFzp52uwGTkyGZO0HKUklIXOyk0fUrkA4j+QlPakt7S/ShjiIOdK/m7frCudvO/MPewqwxbUogOXNp57MBYCtJI1K/6L2wSh3RDNruYf/tlXJZiIE9E2YoQNjZrLnywvWnlA8wn53Em9mOAycvzcg8radhnikTzs3qM2DSFcCy/ggSyS5E/xto9VYCIOBKOjGeLGUBRGTF+yQZHdwHh2x/suAk70ppStdV2jOG9Ob5wmiXcQpn3z4yRsUV/YVUQlsM5d6SKG+IFag0eS69twQgwHKofvSym9/31GzV1oE2HZC8cv9HH4gBHwoQIDlPC1A1bC3c7BHxAJBII1al1TenGCKNDJFJ8pKIP/UrTOD6wwA4s/Y01jCQyYcsM6VM6m6aJVuJTiuo9hIp9Z6XxXGSFVUOoMiQpY9TPV42rHLnMklbTNku4qi0bNsWpJFh4J/6jwV/P6RP8llFwkw6SWaZkZbvalkaosxOXHq0EHkwsZKIvpPqd3rlHhvezXFPGcM7AMCepZOf8nx8w45CtdeUNh2QnAbbnxWQy8USBYiDzcYt95WPv6TS8jsAmBRKYm2+Q/rieZ9TMlXMMGnLPPNUkiCSpalOPlmMypQtKDbXz5gYDAwzNuVOjjXxwCSoFIiTA8GEyABASBdD2pGTC1Ey0WXWwGdbwSu/A5kilsnbMvwekPZYfsmWsao+UAAcdRcSr1yihbKFbLhCERzi6aZ0af/nV3EpnoIcw3Ib3/DOk+S4OhV1OUkqCRC+beet57y4r5ZrRZsKSN68/4ZHHcaV+wM40giyTnG+5b7oGthHqbTQuufvyuQNhXJPL0wi8wMrOg1jjqV0xs5wg1+4XobX/qCfruFRvWAC1maiAUXLFqK8gcGh9DU7EmWusbDB1FfWk3HNaflYHAlGKSh7TN2zI2k/W+YsKhT7pgdO1iVvnC/bR8b3174wQ6cHY20f41RcdC+1JKzaEiDStOtO7aGO3o53OtTxpGrbYy/Z957/MLCiC6VNBSRLITxFdq/c6b7zLfcN2QdraYhKaxFUGGPmEjOhC4Mjw8c9zjcXI8nOcr3gKQOMPkWwkEZnz7UPTLrQKs1KMHC+IAAYym5EcUXcHIAELmtgqCFHDtH5FEBEVNqFlQQ+ss/J6RkpZ8/4mbTcRvPAsQ+QPD8Hqb203XDD8ihRTiopqcYJTLRbSSqhSTJESYRWbw0xvFOeiLDzHmHnhrzjfdMAyVtu+8zjDjcrPwkAgOohoJBCtE0kEQGLy31TneUoaSRxz99lyWXunqNnvi1eZu4yA9cyKsczPziNMdik6TGrPFjkmKBmtMrVKXsJTOJVIOkEo4+VULh+wz8xYojZuACSlLHz0Iy/H0T62nLYM5JxE+jxeLUsYZYrj1JreeXLFjRbnMFpA+hR2q+QSu+GqListsNVpYtkpOFdSifyWhre7daHmFen4lqC2aNe8PX3P7BYvTWgTQEkiLi0pW7fNUINLqURf/Mh20bUhx4ICBESM1KGVxZXGnHsJnMIJkPmu+5gSAZMdiTnc+hRbwXzn/plrTP+lS1zYRYtOIiIG5K4McRQMMlJJwloC0iQoDLgKzVcClhkesaXCqxrlQMR2Ya2jqCoT7qTuZXj6udTWmFXYvpFtVahMzpFMWVyQ+ZdQ8Z9lVSafJbtrqmrnQjXNHE2hnc61LHdpEhgpA3vd9u+87kLrmovbQogeftt/+n378LDP9IyfYnoYukbNWzmdN9WLJQP1/4P0WXmVF9OF4xOeUQpY40ezMkwKWWpHAsDLDuAPKa/+plpSSrpSzfYqidMdDyYBHa07F0BAKgQrrzhfL0QDB5WjaUYr7c6KwsiuV8ZWrex90z7bSMDn3nimk9L3ZXUWplMfbWWl4N08KDTpzFSCbv2SyWlFMsqrtbNM7zTtoYGaPc77UFpOP9OKmma+n6vuOUjFxYLs2DacCBBxC0VwuM820j6rhFhYEdSdaWn+3rSSEmn6ZbLdJixtpGhofOd3Z9L2kilGZoHMdHPGXgAAIB2zBsm5Yxgv6QhSbpvpVEKpoY9qXrnwUSy7sjEMoBCKi/fdl6CEhPCgEcJQBIQkXXipknrIF2CBhEC0RRkOIxtN1k0MGGzfSeAm27ql/qnXc5JqVetNaCPJ7f5UTZ0nGq1mDc5tfdl1bmMhzG+v+NdSiW0GVGew0WcsM2uNbyftrzjIkRcN/6+4UDyjm989uK7msM/KKWRaOEg45PzrhG5kpq1ip4QmT7AIdJIjobYRopppFiQcwRnfIvbzOBI+YTwKwwpYsBeGZw0EQbOfIPdoMQZAAAgAElEQVQtaw46ZCZ5hlgGE8GIRbmijwMoyZ0Flp6vuEjzE3kmAFIEEZ1WCiKm5dw2T9ss16o6L5OUA1Daz1KmTJmc/dj2xoGLzFjJglyBhuoUknA9k0zLayiKlUo4DeZXvFeOl//qt77653BRikeb+vtfv+/jLyxWfIG0oUCCiNsB4dFWGlGNJQxONViD0/DlvtbmUWL2q5FG+kKWxPVMCOgdHvOqt7J+AMkhg7J8FliCX0KPceUM4zJtFcNhZK6aK/5pRmeZcqC6ZUDFdyl9PZcqCyCxjoK5Fw3rWRARYZz2Sv1FEVR8+5wx5sUAxN7Z55zh2+kztn5OoUC3gxtP+ofkwnMq0ljJZB4Vl5ZCOi4XVfJseG8ULyPVPa/k6juHi6SSbWHrb7943/vOGVi1VdGGAsmff+NzzzuIR7/Hk0b0USgtKLCBXUsj+gUwnpjJ956I6kojTl/ok0bGKb8AMqxfOPjDFgDUkStJKomfdOAhmqQe/AEcol/q45bQMo6EeZXSHgImkIBJn3Tis3RgQBHcfQyMcFE5nRAwCyA5KcQFEfX0LIg47WSuE9eg3f3nUEKeAkAl6Xp9W1bAY/qZvicL6KWZKy549cnTHPoFESqnuiqpuAJoV75rgQKEVGLtw/kXYFGpj4b67F3hlHXZpLhhQIKIO2uE7HvYFZhAA3XIbz7sUhQPSUsjHAKyOkuZSuk+W59BoToyM73gOYJzawZ+SXbxBpkb2s+2dXOkEvrtN46Tnw9S+WPVdfw+MNGpBMGUM4CSUUMFEP4jv1QODR5UIh9AbLukbdMHIg5cGCO+BQ6nBZNfTh80mfxVet2tHQOhK1PiFv1sWk5AryeXscN1GUpDxvEQqaQvXU/FheaXpBNWYzE/9JcDC31MJ5VUMPu1y2/+4H0GVGtVtGFA8s7b/urSQ3jk20gakYgqpRFqwAblct+WdEMKwxX60ohHVtyUkRIQytyNpbVUb+W9fP8k1VDI3RY7cSwYeJ3rPLMMIn0Rq+P2imGH1NZQBBQQGJBl/+O+NmboGH0wASyA2LZuq2db0AMRgLYP5kGkDAS2u6RtzyUmJwFuTlcKSViVeu7CcyqOj6SMto9k4o2h1BYyTipJNSLEUPxJLGlctEZFG96j8qq4HLgNLTcpNlBvP235lEsHV35O2hAg+Rp+84ymaR4pH33UBQKBiLCDCL+cNOIpsPrEy5JKKw8iKY2GFRVBD410MPismf5COrTII+eTMB1OzgGQglQi3T0m0rdkN6e+qaSLxyhC0PfEuE2JJP8TLF5VhwWLIPzHfSVwWPDgXFMAydlDuCntc8yos2zdLVM23Dq1U4GiRDUZ80IV2LONqH5s7V9QIqfv9d75mXMZ5kSSckEUDbWnWh5EUaxSS15TOGkLscuBSUJB4OXAMU9aDoz1Q/5k77WPGlvtMbQhQPKZA//teYfxyLklaSQ5+bJwFIqVRsh/DIMfHnoOacRinmA27mBJBoTwd+ORtzu8hJc/IryZXFZysKqKlOdkmZrOLA8mGKRLyjwlaGmeHRLgsxKKdnUYkQKXYV+vASuZg8AdD0CsKitQIWzLDAIRn9FXuedpfhNpJwEZW1cuTd424oQ2YRXzt31E3pVUZZkcF0N5nYTHO+bRhKRSSSPsHwJEjFRilwN7r+U9bXbSM+eo9GBadyD54re+vBsD/rJ84DlpRCKvQmPUj8GTRsC6rJE0MojSMewzMXWZOJjLFFHsEAvBH1Y0IH2AcoZ+Fiw0AzEsrGs8dtd2AZu+YWtB1zWoPK2qK2Wmqb3fAIoDKjlVV5lsCm0q6ICHr8aStdJ1XxSIBOATI/pe+ZvkIZ+fk36pf6n0XADieuT9bNkSnFH+qdN8IzjH/othMlJJn2ZEh+Nf+U+G9yiZFJYDy5TptbwrePRHXn3Lxy8e0QSjaN2B5B9Xvv68Q83he84rjcQPnQbcpbtR0shCgMYZyvYm72d8xUwWTYSSTSMZysGwE2+GnMTUs022BztsKUnfSdcy1JAyVJWfKk0oAkqg8iXAwlA17AM2YhY8qJ7ekfOxcg5gctuMABHvOlGdmadnO0GwpU/TlH0rqWsupumHft8eOCbQ8yNfTD1WTWUJQ3rneAOBSbxHLZVQmAg/YjmwnUzr5cAkjRDo6OXAJy9tufDqf/vMtnlq3UfrCiSfueNLZzeI6hW6bAkZJo2w+MfSiCNbiLRhY6WREgX1B+ldsONKuUmmTIVN0nJnnN5Ej5lujhHpuLkZZ4ZZrAJMElfDvZnPCuaryuaDSgIXJPaM/BITzYJHV38pgajSV/ycknraNunq2QsibtuKthz0/Pw8OH3tENn2nNJIULWHtO5gKwHGNpYgYZrxQqifR1geY3kP+SEgQLDhrOXEWw5sFiMJazItC7YlPor1dxw+9ehLV1X1DK0rkHztyN7nHm6O3j2VRiCuOhgqjUAEGkJ4ECEELeR036Eu4yiZ2aXjJBu6ONDH2Eqys86ePNIiO8zKMrPxYBKIU1vXAAnzKwNKFy4LKpzS2I//tAR4GElA1SsABExqPNAuFOZqU8/+YlLQ1xmVmQI8p/72QtYh8XYieX3L+qC4TfNcHZXHdwomViop8Rw5wZXunTNoSNGqe3Lzjo2Sy4G9d5Ys4dJjXn3LDd85qAFG0LoByXV3/ve7YRMcaYRAAow0ohsklUbaFDglTTn11lBpxIlYup2fzCAIjqPPpugqDWSZJ4/9/nSDHY0ZMAjsqdJOgcoyhBLj4zRSNQznZfNLmHC8Jbc+UAlZe9IQoqySl17ZMLGyXl1E+3EFFDPXso4Gw1FSnv21AGUlHpuHyc8DqTRGml6/NMKXaFIKSTAXAldNQ6eZpSB5LqXdU+mF46dSiT42qhbvaZJmAquzqWHl9G3LzcKXA68bkNx48KbnHYIj5/i2EU8aAXel1tCDGT2VlqVR0sji+qaifqlEOgRnAOm07CDND2Q/XVmGvIqrzJiSGINVMR5oWeCy+QXJm0GmIrCkB1Q47SFvRnTflOgwOv5SAcsAYm0hEhBt+yUgEpuiB0SCcRFh5HPQzwDy/uo/zUuUMC2fSTeXkv4LSVgn+kIp5Qch8cmBxVCpJFG7O1IJhVDLgZUEQqotPRnnNFupJNThka/ad+3/M7ohCrQuQHLNXf/17gjNqqSRJgEF2fTDH177rxyLcfx01pbyg8iEsgy/4rIlbC146fpQkTAKy0ss2BnmnujbuzA5BlUldc0zw5ifx5AdQEmZMiWaKqfm5UEh+VJ5UvAYDCCdZyqF6KcjVU3zgQjXwT7s3CqwwSBUSHuMNOL0Zq/gKq1F05gxn6q4+qUSm4/WwJC7Xg5MXFKfDtz9o5ZK1CbF0Ow4KWx99ogq9dK6AMm37tr/3CNQ7yFpBECKa1YawV5pRD0YAQQo/nNITzQcONYaNnjADhpIViqR4wbNQMqqofrAYriKa0j8PjBBiCwxyxRtfsrGIOsoASXYGJ6kAiKwtX5okAkmJRUiyC+ocmnwCDrLDICktqtUCim113AQkemkEm10tfnYPCzAOZ3ZBxkHoGSIYHycfuWNm7WgPv0FikJY64eOYabARV6l+Rr58AotFCDiHDPV/cbUaJNiCBdcue/jPzui+kVacyB57f5P3jNU4ZdlR2+UIGalEX2mlpVGFFg40kgf9Ukjaw8bfdQ3mHTYYK8SJuLFlczEBynJDPL6d5ODHOeGmZTARLMsyYiDk98IQAHN30H5OSDhooYFiZCEcZyS1BV4ZAGE20e3o6PKAg7Urw4cCSJev1JlkkDg/GbS12XUpMHAGQNOGZJ01xpJBlDCj8xE148DoJYDx/ColgO3JN6/ZHik3KTYYNNuUkR6Z4l+kyJis3T6bNvCNimuOZAsh9lzjjYru1NpJLdSqyyNAHCjevtGViON2FAZa8nakCOVeIOVwqYDyoanoDlmr4HHZ/RBBCuDScq0ulhZMMnXp8wohwOKVVpZLPDZf04KyX1zPjo/CR4pgITYJvbZpVIIV9AHWtl0c4KI5cduGsHxl3knSXBdZQk0ghT6tQ6b9PUNxZDhNlhPMS/9fF6VTqSl4b20SZH5bPomxcPN0V94y+3XXbCKikdaUyB5zcEb7lVhUGdqadFLSyO6EcZLI33SiXqzcdE2sv5ySX7eZZmqDeLMGQ2z7wcprwxl/6EqtDyYECPkNLJHw7tMsx9Q2M1h+BJUdBQdrvfbXTnppZAjjpcXkXQturp6thBu5ExbiCACVLMgklxDAlwJoxcgEmwE71kHm5sKrt1s2oVRIcOmtdhYSrhHjx1WqrhklMjpUMa2FheCCOaV9k2KUrkllwMDACytLD193npKWlMgWb5r5dk11mf6thECCpZGEKC4bwRANGFOZMQ8nAQYKo1sEI2xldjhmQWaAgAUmEMRCExe6dDvBxNOJ52FS/IZ6BhA8UDF3hXAZcBXIIP6WhcZKSQ1AeBVYLr+MvmSuk/VW7k6IBLAPGfd9p5dJAci8pkneSRl1WnSnQ4JIu9M2qCcNgGl+oz2P9FNpX4mXm6CjOqbblJkfqqlEj4duDHpBzjUHP2Zqw5c/xvz17ulNQOSP77pA99WwdKjgngDkzUEjdvF3i+NpCYq/RCEZ96vAClrDTaWhdrfhPG6YOEP1qpHxTXUXpJnEk6ZHTBJmZHNixiqLK2VTsYAigWVINLoY/3Dvjl1GN/kwaNtFyuBpHUWLW/qy3WVbd4LIpaV94CIfN5Oz1TXsmtw1uX0vf4j+3matt/P15rKPKCfQ/g8Z5xUkiruGThqlLveG6XRkScGEwWoYDvOnrTa97uvGZCcurT92Q3Wp2MYJo3kTvgdslIrUvYwNA4/D/nWkrUhz+YQ/dgjunjM3rNnYJt4krZiB5bBFMDEps/J+3mkjI1ZN+dl87PzVh9QPAabBxUfWHSa4746A043iNK5MGEA06ujcot11ClWseK2xk5bzwMiSfkhySvpG6X4CciI8nKh/VTcuOtLY3mBJ5UkfiZ9CzjpfftrbSVykyIdK18DLwuWOdJ5hYfw6H3etv8zF46slqI1AZLnf+2aM7ZXyw+TXWCsNGL3jYyRRqR7cj1SGtkQlZcZLMH5zTH70kDTwzObrYmv5JoiWAF2PEAA1lBVS47JWdsJhRD8UbiZcBlQkVElGKUAM+wr32WSAIwsNYU1AXT++Tp5UkiAAJi0b0H6mwdEHEafAxGZTzYPVYMhIJOUKJPe+tEQvUUuTB4kWCqxvK9zjnc2BJ231dpIiK+aFwMqXittJQGqEJ6AiEvjWoFpTYDkrK3/p71vD7clqer7re59zp0ZmPeTYSYxqJHPx6fEV9Aob4MgIoIjiFFQVFRAwwTRD+ZzBPFTPwxRIL5ACETAQYfwSSBxBAnECEZjfCWoQRHwDjNz78zcmTv33HvO3l35o7uq1lr16Oq99zln7336d+85p7u6ul5dvX611qqqvvgle2Z2FZDXRvyGY/NrI72Nz47zOAwSiecQvGykXrkFXrb0VuBcwIcvOLnyRoQN+bRs3KjzV6QcjmI9OYS0EI7eI8KXlFAW93tSqYjdoEBz/MTBtY5Q8+A1EBnrcFZ22Xr2Ar+VP0ObUopE2nIZHrOQREQNEiRCMoF0HkF/U+lDnMoYh8MhDkPkQ2ogOyQfae6XWomNk9JK/ABefmXW4qzZ++K33PPBGwdUSWDpRGKMqc6fbD+DQKxyvvBc24h9/VBrI4IskrpHAQg92shhIPMmZF6a9AvXCvqs1gAEwqCXTEjmmBIIMeEvyhwxv8iRsxJ8pM1CPeYgn4wI16RibFEYuUjNJUcV4XVJGHGtIyxRPwGm/D7tDVr4Eg92bWkTUimzPjKcRHwZVF4BiagmiPRpGpK+vDt4roeBuAzp10r09ZRWAnXd38WlYxvmtRI/YJ+BLfRWW6foDR2NoecYY44VVl1g6UTyq3ff9sPnmr3P0eGicm56Gnq1EYA1dsQ30qeNsAJkcPiUopE2AciRnBQWLH6GTFIv7SJkIgUJF0YxIchFNM/PnusR7TBC0UJaC+qcAIpbryRB6J90cpFcFT/ltCdNIGSZItF+JGN2h3pUL9ttERLxfYGnp9JWx5GeLG6MkVCcpA6fRCxKpcc8WknMDNZqJRTRStqz1nzlt05p48c3dOR1OGd2H/6mu39vrq1TlkokxpjqvOrYs602Ytw++UwDYdrILLGKHSjTRoY8iCEPL5LI4aDv5Y28fJj7+nxkEjdtaKGUEIgida6d+BS4QEwTSg+p+CySxOLjDhVQqZQixEG+/sshkJ42UznEJi/En5dLIPLcZT/kncinQUnfS7JvhSXz8TMks3ws/2WPahYmvF7qK+GxZQxIrQRSKxGuBaWVAG2rV1R9+zxayVKJ5M0nP/Dsndm5fxZeMW7HX1fFiDZi/zWF2oi9MM+jH3TPIQ1+0mRQ9gIGL3tJjIFkYoWZSJEJa3dFSjyfViAcwYSjIo8kodhyhIRiS9VHLClB3/8vnVYsvaDUHXnMu/2Liu0S1TSVXOwp7+wnEVVKTloyDRZD51NAVJGS6Vz3CfOl3edhTZmphvpKnJQ0PKw9CrUSwzZ0lD4Svc289WWfa3Yf9oa7f/eVxYXqsFQi2aomzwXgtBGvbUDY6RoYpo3Ak4hqnLQ2QkFIiVkr7htZPbMWhx5DBr9JxVImrj5/SW5L94XIpItQKVEQN3XperF8c4QSEZieUMqJpYRgsj+shCUaTp48ygikz6/EMyvatl+kKZ9zBRaun3Ok/4kY0f7Hyyf+iOvx9LE5iGgl/jyulfDrQ7QSLnOT28yjbekJ6m+75dT/uGxIVZZGJO+497993Zlm91G8G7sKKm3EbzDmQ238VhvxWx4DMW3EuAuxRtb5z4OVohfxshF72eQIL0Um8Ze5h0wg8xhOJu2JIS9gZX5KPKZMNz4rGSaCsmI78G+kMEwT6ScMX18IcsuTxyIEEmoh4pwlrJ8tqRz58zUsHkupp9/5aoYkIftUf7/lQevEJMO1kj4NRZi6irQSCK3ErifJaSW7ZvrQU7MHbh5S06URSTPD8wFTcW3EVrD1jcBXhNnr+AdaAOVUUkcIriEI52kAppVk0WvhWT50H9GTISVeKnFYfL2QTDR5IUEmCQ3IphPN292qBWpakArntoud11JipCKJRRLMIiKKZR+kr1PuI49iArEXtXiNaCGhdhB/pmRcoA91+fu7+0iEoNLI/JZ3hMex0FXEYLmhxrmlvhKIeMwSQz6W10q83lH08Su07Vw11TN/5uR7ryutylKI5D33/88v3KHZY/hDd66cCHnw+c0xbYS3b+m6EQ3TNUkaK0IiQJEE069p7nd4hxboPpmFyaQLDMgkJniIkQvPM2XuihCKLUNKS4mTiroewBYuRjJlP77SKfriAl0yV1jHFHHKZ2fbXbdn0Atc2+vnLVq8RRUhEZlaGYmIgkbyipBVXx7riczQlXh4WvKEZi+plThXgAnJqLE/Ca1Ef63WaiVTzK68qKl+vLSWSyGS+/fOvnDaTC9pKxbXRvwMrvm0kb5uNNw3EktjtZHesl2+rEkBHztWZBK1cSfy8b9jeXHthNEHqXNYmRiljCJC4cI2TioycoxcFhVTNo1KpBshDoLKV5YgR5KssULC6NVC/G+4PJRgF8S0OInoZy7ySuTDoqo+ujnQwr5PK2kPcgNnHtfA2A1wo1pJI7QS7ojnqREIW1Tf8O/uet/nldRpYSI5aU5etIvZ1xMIkgj4wkK18NBpI77g/mMtcW2kYXHn/RY7j7EYDpFytGBQQj7/omvh7tPkpoi5HPAsr3h+jD6cQFWEQjrvEkJRAjgglQhhRMhFEszwfzYNI9KFKHNf2VOEyMvqWszYNpME4p4ZexCk81IlkYLdP7dlkQiJvAD2JyCr4H51fBgY8rbHvbJlKfTLLZ1P949rJSw3rZW0g3kIrUTMlnXptffNYC7aRv3ykvIsTCT/9b7/8yNnm93rrW+EV1Ls9eIWxPB4cqqv9H7EHkeeOHLayHJxeB07HGVCFKf/he8nk/aWQjJhNnonlIL8MtoJhYIiHF0z0ZryJxhWDiGYZQq8rGmCGf6TvhQJYeXr16ZU+/pGihKI7h+aqPkTzJGISnFhEvGZZPqljNhFOVwSAfbnbR+qlfQPoPNaSWsZctOdlGzOaSX0jFfc+fZH9NVnISIxxpw/m5qn8S6gP1xlC6pZb+ZCoGYPWFsdY1yZ6VzayGGarUzieF7EXr/QVAGwP0siEy/Ew7yUQFKCRuYpRJTLt49QbPpcA3BCXJSLUUwgtHUcLsTjGkz/T+5qfxlC8rDtFxKI88vIlvWCnHSqNl92zgolQyP9wqU5D4nwcour8eMI0awrFtVKSmKHhOPDjYrVuhmkVmK1j5h8tmhgzrusuvRlfWVZiEhuufe/f88Zc/bzo9qI2Jwx/IxuXhsJkbo63Ddy8JRCieOF0qQw1VDA54T7PGTiIgR5hSXw+ck8Y4TiE8kTiixLklT4NR2ihHoo4BHc0/+TTrNEK+LkEbaATb9HAxGCnAlzYmm4/NRzss80RiL+zD6MASTi20a/BfG8dD9cAlbWMeprp7USqRnktRLudJeugVYrabprXCtxH7zSu4swrcTKcwJhC/XTbjr+9q/J1WZuIjHGTGameiYPy28V74+5NuJtfbbhfAPGyCP33BcxYx2mxjI3kk7LgyMToakwqSiEVko7EXmXEEpKoMZJJSQWIAwpI4O+H10SWaqQ0hxxUBhHt1MpgWgzFrn85bMAeD7EtDm4+F6wL0gisd9REhHBwbMvhlb/+5JZCluVQhYufTY8RTloNm4NiT+TWgm3BDVNXCthdFZdtXVx9nslcxPJb53+yDff3zzwSAI59rIVCj9cZQJtxMUOnOyGfyTMpWnZGOCNthzfyFqSCBB5CRNkIn5DvstDyITlpU0pWhiHeYYjbRpAKEktJUcq6CeWIP6cPzmTmD/x5eHx5UtIrm7aslNMINqMZS/wMnVtU+QPse2tznkZXJIsV1L56v4p+6/sGXODEseHgLnkyhy+EoPW2861EndnRCsx6nO8M0grkR7WEwjnme2v++mP33JxqthzE8l0NnsOr6xz3qgCcYbLfbgqdjTkQZQRx7yWy9WFHBV2vyPCPXjF5yETK5hFTJ2fzpOPiIGoucvmnyEUW5ZQtwETvClS4UJY/7D0s0ST/5EBMg9OhbLuLQz6yUMTdwmBkL/gwlyq+vmzm0TKLl1WnqAP+PvKSMSnLdIAgme4eSgztA8eCNNwrUSscm+kJuI1lhZN1Vxx4YWXviBVhrmI5LfP/K9Hnp7uPEq/1LDMCPYBFSM3ZxSmq04b8RX22kixbVBlz68F18PSbgR6ycRoMul0/qyZSwsIn/6QreGTNvpBhMIqRzw0FDrhIkHdVnGCCTWYYT8UphQlDd/Ww8iDE4hoNUUgrrUVgfjnJJ+zIBHdpqTISvWzZB8hiLxDEvFlWEsSWbLgCIbS82olAJOfPgWulbiBPZv6q//aM53S+VX19FQd5iKS+8+e/oEZzAUGltkax3Ruq/iOQPRW8fqD9LKZMtpIpo+l2HtTiKIEWtjbAy74tZZgA4MXXL/kSlDApqmFChN4Qnw5wcKFCwYQiqIUIVwzpAIogZ0W7SrZwT9paNIIiUPWj4KEJT11YQkCcSQikuiekBbmLr4/9+mrc8YEehPHgETEc06TiKzPmpAI0PfABRaRTPOY5+P0Yq814jrXSmZo3Iwu4+SzJZ/2Ge9h9ohfvvu2J8fyH0wkf3TXJx6y28wer19c4wrSFZfCOcqhNgJXYAB5bcQs6hvZfFpJmRz4Qdp/oe6MkUl0hBoRTUwWClGmiKyUUKSMUdSRIJUYsfisYsLdZtRPDbwsXcMk00zJx6CsAXkgrAcVEEisHUUbhm0ncnHpy7Ly/iA3cYw93zISsYcBiWzYqzqf0T0WJ66VBNeZVsJ9z95XorWPTlPpForb6ywnhxr0r2JlG0wkH5t8/MZz2LvGMpqwqSG9HYototwOhRMMPypHmTayYT0zg2ELCcvJRAgaLcSUqasVPIYRCqMVJ9TKCaUVQKGWkiOVGLGkyEXWJU828272mCUO1k5p7UO1I2/7ruBBu+XMWORLxTPSvSDpVNekQT7GEBJJqGcbh1LvbM68lU47FkMYt9iEKGa8MmyQb/iHB41TCnhaBEJl6sf9+79/z6U6t0FEYow5hln9jboS3r7GbHCQ2kjD4vdthyKaYg7fyFElEYsiMmkjshBEyES//DwtJXSU6kCofKYi73kJhZepj1TixJIilxKS6UMuXS/sRRO4mkdryghNtJs9Ej4QRe2W5ETp0O3sy0vLb5EtILWQkn6k+o565nES2UjOWCpSg2uulfiw2D3yt//0rh/E+/Uk4QJyG2bTnprpFXTBJHC6DyKSXz/xoRc8gN3PBQglCxCt1mKL3RjeHIGxK2go3jgxDLEhhveuO/I1KF+VXkG+3BEhJISfkC5ahMW1E5Z3KaFwYUkFpBIObEOaSJGLK6LLa+C/GFFkSCNKHoRe8ggJRD6nOIEwUq006bTpBcOHQAthz0qVKxiM2P7C746SyOLkvf4o10qCayqVnNPdD9ZlLPsVRUEykCTD6cliQpOn6jIUE4kxpsKEbuBhiy5A5A4dQFOLv7CYbyRSl+KYq4z+l7BsVbpho1QWOzKi5cJFjiqVSAu0ky4OlROKPPIRSIfzHLi5KUIsoShP6AM5UsgSRTqX4Hkp4tA1i5JHUH/HgHkCIR/mo3iC5neJKKxy3JRlixTVaDVpRPvM0aSQfhNVKryHcHpTDAfqbuNc0079Fa4K5nRvInkYmC996fE3fy0PKyaSXz/1oW95YHb2KwjhAkQ3rcwuv48sQHRcZziV8MqKgvaWp8w3Mg82g2YsSrc44WTi4wVj1bSpiwAZO0corhhpQmGj8rRQjWsqklhy5KJLNv+/gAEcdHIAACAASURBVFlU8iR+QuKATkEVOhYz9NGkCUQQRoRAorPwbNldqH2u8jzeV8DS4wR0NEkkjXKS0KYrF2ZCaerlsg93mgeT3w0MQGyD3ehkYChrEnDl1uXfwM8n/RVtMZuZ79IFdRszsim9jSoK/x57jELkbCyGOdeN9KE/5uZ1c6L2G/dW+TAggNq5N8ZYUdBebM+7a+3NoO75damByNpnrZDozi2ZsGdqhaLNv0sBAGCoi+Oeo217IwSRLSOP0d7vI1Eb0V+TLcDaIh5DhA4ZS5D4E7+Yv1UXLHG3FuwynFQ0Kb59HjosqYW4Ikn6ipmyZBJdj3ADBUkiI/IwUM83CMjda9C9raLdbRLO1UDkYlsTV2UMDJnO6Q5U6M5ZCrwoD67PeyTPu4hI3nLiw1951px9NEF+cwTw6pAzchm+AFEzpKcGTQvSUpdvuXLi2CztYhEQqBXcnExgbJ8S56YjA2J00MZj5wBAlmAEnbSCxZB4TlZgxQkFrkSWkXj/sPLHloudwZ+xiAiJxacmYkTaKXlpIcSEem+cJHn4a/tBIDEthDeMIA3Jhi5aTAsakeKFfrbQ5FCWl2FPzPZ+RiIGMNTJbKpRww702+uWYBoyqF0abYoTU32RMWZCRFOg0LS1i50fNDDbALOjwWol0tvv9RHATQI2KdqIaRoUiZVvLH88IgcuPMRoMSM4COyJBAKJAke8NHdpcdLFkfYYVpZudEsqjJUrZvrSMXl5hSlMmcPEj4Eq6TBE03RlpqAssXtEStwkF7QUubbwN4cmrJQfJGvGIvnUCTwj9lv5Q2RfGEkkh/JhcL95y1l4lHkrJRfFwJ5tm+JDvAzntKJL0pjm4l+4471ucWIvkbzqjrddTTTJfgHR7ddiuLlr8Sm/gLweM2ulkX4IK4NDKBBZacHP24OATEJbOLyAEynECMVdHkwoxhamkFRKiEXKvIhgrxjZ5AiH/7D40TQzpBEQB2xaPeTBb3HhhQQCkbAgjOjzB4Ly24i6BwVOdht1JJEoctIpuDbAhK/jxBcnyqTtT7DXlqAQPesWqLbrx9vjXtPWJdVlL56a6RXa5sa5yn8b2DCzltRGfDU5b+YbIQZJOuXaCBXEOXAUvmMDzKTl2ZKfNOEGCcpvEjN1daGtkBCE31lnXUM7w5U9hfafuFjkBxCufO7utlzsD3xJXAwvYH3Jgwdu12Tn+gHLAkNavSymZM30PYq8xUnkmksvTJEPFIIwUQ5JXYGZsAuTOaSd6qnyjCjFMiUWlyCdObp7r1vzlnEztGqCP25fejSmG2eplI6ZyVfYHHqJZJu2nt5uOszNWl4NklN+7Z5bcssvTzwsjAkUqWmUO9kTp9GQJghZH+zX6xh1wiPiN0Hnx4g64oGo7wQuUiGhtOlxQnHhNgVyicIfMsKBuq4azr44afR55/qQuDtLGvK+CprM/EE0jcQsqPkJJJZfqIV0WcdSXlEtZNnDscWRL1FEyJE85M51gEDOkR7GieXIjVbclGVj2m+9Vy5cUkkF+nybVta09Zo73/PCBrPPpkjmTScI/MZf3dzjRi5zAbyTPUYLga0vg3Inu75vMaycJrNElPlNuE2enbtE+s1dLsyfMhOSFFH5b40wIw+5QHYYM0rxtHM/KiBIh2fof2LTjMVPpBbR0hLsp+dZO6u25m2XcKKLBZK65V2ZwrYJfSFIPNt1IxGgmEQO9WUPLSxDZV7UJWB4enpQ7SWyjdM4VUD6w3VJGtM8+NV33PoEoIdIjtHEbdDFZ2f5zNiOvi5TafLiheCFjWoaCRSZIopiz4dVfTWWBSd82LkbhaqRqxcinGa6ozkJBRSEsrxKSUURSy+5BOJZ1EeSToQkkikEqbASUJC+PtHxeJLcfyMv2XaWrFVKILx9g+cZtLiNEB8YrD1WvArz+El8eCq+/3E7kqCM1gxVjwMypq2b7rrlUTVVX+7s5wx+O5SOSoR2AnAnu9dG/O+h+2oFtU5di2CTtYllQ5u6gO6cAHKmLsCav7wfgvseOgISM/XKTF4uNPKM/YjZ9xVxTR35NCPxRKeQkiPdX9ISplf2RCNQ+pK9Qvm0tfM8mirFcyL5S7ZhkKz0hfhn150tk0BWzwK1tkg3ZdxPom9ufScNDLGJVsx8BgDVtPpqIEMkD6GLn6eyDjbzmrENvvwGjdrJHpqugpkFmdd3mIqXIJ5cxxw7rgDBrzdx5wCsIx5MTbbCJXTGw49wiwmlDRhKKi4Z5fxIkosLivenZFeYq5/EShGLY1ikvIs65vuI3nUABALqK+0cOGLvYtityjqa91goP0k0rvd2UjZ9gwbkfCItwXRX2G02TwLh2PbkeiBBJL9s/uiCyd2nvm4mNl5k/hFHGmknu331A5MWEwziVV6WNsLbqeSZHLGOWwI70k1qJ52At09qEUJxYYpU3DPuIRWgc1BrYuGM5+qVPpP3RpDpJ3N3IWdOyqeQJo944DAC8Tdp2suTyNIp5MihdIzrHOY9N7TjI6kxSGd7PG3TudQbY1Cxd9L+WId7O5NLpjUxk8uBBJE0J0+8YIb6KhHWvb7cyW7NW3ZfLVfI7h0u3VerT9cos/lJwQN4Nt08RHrUPmhWSe3EEoo2d7WR8oTSCXhLKO630FKilJIkFd07XKq8L/CjTIfbly7D/A9F0RPE4YNS5BFe09pbnkBY7nNpIaN6PwTLbilPDu2Z0PUlvyRfATmYb1yKKQleET343eZjF0aJ5Bhtf/OembqCeF3BG7ca5WJHECYJwADpKb9BBeJx+LWjjaSE2YecUtoJIM1dklDcPliaUJzw4oTicspqKW1QRFPxics4oh7sKNFWsWFOGmEi8z6CHHH4YCXutXSPnS1EICFhhAQyVP1fAaxJMXNIaRll97aI3c3Jgq0kYVJZD93bd/3kqX/43IBI3nDifY+bmtlXOhLh3x0x3UdQGq6NeCe7YRnEPqXLCyAKn5/cL2sZPT1gctmAzjgUjlDUosEUoTj3XEpD4cJMmb3c704b8osck7QSF4A95BLWsT9kEcT8GOlypAcLqeskf0VilRFIuRZCieMVxlKKud8CYL70+wkmTNf6VhqDdjEiABjj3zkK350glVn1sIBIKmw/Z4YZrBkj5mTn03ntx+NdLDfKDM1aQ5zsQ+LE79tHrMk7sx/gM7sAq/h2vc4RQ5nJq4sKbfZy4VzwcU3F3xh9LXxh+WG/Xr+otpt8iXv6S5I4uuAULbiQkAnCe1IEIiL7ycHG3XOEO3sSB98mMZJYlM6MMd37bJ956sUwbFaXnfFFrgx7mP3jSsY356PCN3D7tK2E/5Zv061o5yYsTht+I7CUXU2sHy5Zye6rkGgSHW/EfkKvWSBwEdT+ketP2JH/pa7yG/16FCkQ2ToLYskIQaj/RV42iv+Ufac9/ZNKN8w2U0LfBGrdh24JsPUfpNL3CYWLItn6DxdZrgkxXdqrQSJH+20Oah9pjsDCE4kuZWfMTuTD+T18i6vUkyCYa4RG8tZTv/fCadNc4vjJyCxnYCva0c3Wcrv+am1EkYkbaaYsbrFqieFpokKHauQ60sj6T0o1FBdVd1hOVFpT6a6DCUitsbiT7Hhf3LFo30npBH035DQOEZrVPGSCsfDw9pAqVm9R4aqVZw2gPev8EnItSixe+F6YxM0zg4cIImlm9Cw7J5lrGH6KLw+JTdTt7mNbosiijNhE5AkFyDnlu6jgmyzmSQVAdJQUIQxKkETC/rUvIouih705Lk4e/loJgWzKdF4u6xY1/awyFnG4l6SeCvFmMN+2BHOVI5K33vXhR++Ys1+ib7XEYP9aLcSdd6RhTV+xjNu/nHxsYIFZS2kyw6o/4iARJ5T2SqscMPIwki64sEuRSnsNYrRFNjSqvCZIQq/i5WnPiZJRXlGMCHGEIRT7I66RimpPNpVALChxfNQQI9GMooLWJVG7e2PpxUAgoDFXOCLZq/e+h+/mJf0eagW70lAkAUi/ia2ALNQAs1a2QiN1LAV9Q7eBQztNKIAXbzGzl9ZBvCxl4YZd40E2dSFUTdA1UgTTH7pclJBGPDSnefjrRdoHVtGENeKg4bULq92YblEiiTh9xt+6JqoAwBizbZrmqXIBi53i2wl+t8rdE4EB2LRfbtbSxR2xUjDquE+mzClztFPeJiWczPYPcVFof4w/s7+Yh51UbKF/qF0W9Uej0vfOW9fEjysCeed4xkkehPLJBwGJsNaUSYpWtjHByzFi4xFzPiwzdX9YzSYA8IYTv/tDIDzIj+ekpLEbMYptUfi3SeSwMTBjxU1W0qwVKd4gs9aIAThg/d9qKEBOSwGk6Utdg/SpiBDWPfh3PHnlDL8xUed4cKzvzd9o6Tsp9id5d1yZSZipKHNtxAFjfTw3pVJ3C2iJhKj6Dv+RXK/O2D20jPpns/Gfz7UxPcimEyGDuA1uqA9kNHKtI9Jmr/aIk4q7FpBKG6iJRYSK/XHKPlgV70NlL325aKC+w2j8WF1tQIo8Ruo4BAQ8sYbu/4HFrKvJdPIrd7z/qxo0X0hO9PvUWjNWA76vlne6d7HU22dNXSnBPnQR4qiNrCl6OmNeS2mPoqRi044Qi4gj8lZxE10q/GDCUEQqTL0xolfTxNEGjprHiiJC9JmLq4m84h6LvzcxW+YRlXCytxt1ace5PWuYntKw662Ja5h/ZCSJDcaAd6aEVNpr9jROLCIOxEXNK1Es8qHd4XeG3o50QtRzqYw81mQ8PGJJINdv8obSRYceZtbsTSbAtfLTi+RWM3oy8avY4cL8sUpWhKVWqivdJ4yTnXUzYlOlQopU2mvySBOLiGMScQNE7l0K+rwcuQwzxNFdmOfl38DuMiKB2Kdvc3Ms7NSVSk0HF/M3UtpVRbsTMhDbxVvwmVkGECva02ar+HEYMfdal1DGPLSyYZJ3g6qSAicVoJ9Y2jg2KPTZCZj4lXkHLD2ckEg7/oqmoo1GqxGlGCLtIjp7AE1MInZjdidVVV8xm81UokwXsQsNTRduOj+IMc53wvfXcrmYckd7Css1fRU264bxzSahj1jaOOFRG1edJZ7x8h+9LFFR+iNxrBhWTyhk+0ZG9bCecO7+D7WX8roaGOyR2ZnA4PLwYqg0cA3FnyVMVgn5vxY+kdXqLyMyCIml+x3pZgmPRIClaySFN46ksco4vGeT9d27oBxxhH4SQmq4FU/T+VIoHn+K2c6kMc0lqUIsZ5ruHBj9IyPmgPMsRHq767c9nWlfRAbxw5EwPFZvpL9OiLVcGJZq434Koc5nor/wyRe0EoBJU396YkAXcT3DZy+3g9ffPTRB/FgFRoxYDbjXo0duCa2G6/+9jsoRwzG2Ww7Std3fVv1xlF5O8iMG6dldwR4JAlvbWx+fGGou4jI/nJvfX4FlUMZRpJ1xPLZ6iGo1G/uQIj1w7JQrAD/TcNmPIkyvDanI+/AswZT6ES/E+X9Vmaa5KJ9RSC0x+K3jedx4bK7NDPebbA7ljO/riMNF1OA+YsUxj3bC/e8lYyQCoQLXWMIPnXXnzVMv+tK/roBqFqTiwCcAp67HjtOxir7Pvp/YHB4ase4Y++LBYQ3busTRHt6k14GkzFUtdLOQu0f+2N86tS1snSCieyoiOlNQvFSpE8crjKUUcw175YjVw5q8MhuBAbP/DxJF3FA4K6vPfR6T1tTpHoBdjOjj2p8qU9KGpncAQAXTBEQSTpUce7zE2B5rgZHvRwzEQb7ZeV1hnntzcbizPE85jkzIHzsfCiMbA4PprPkUAFTGmIBIcu/fPA0t7lnCF9lGMb5f2DDJO3aUtcOG9cAk5u2afdKTMnGERkJ+LlZFTKOxU33tdcrpOsAuZn8HABVqOp0v1vwYslCmPKfF92gdkcKK6v8jjgyOAvcP1yb64koSsPdzzUKGp/OrOid7JaR3eoLwTrPz1wBQmZl5oKyw8eNVQ/F+XyPmxyp3gBEjVhj9+oQOoeBS37qP2P3hb+5UlwTDne1+5lY8t5PN9PcBoCKC00hi/v6QwXjG7Jh0zOVJm2HsvB8lWDGMDDliFdHXL8d+WwQpt/ju1MOn/Yah/lPLYj4WVeALD6Xs5+H+73TWnPzpa2/4YwCoZo25P10RWagKKV5asgAPEthYSpgPY3OMWAVo9b+vX479NoG4wckN5TPaCDdrhWpAaNbS1yuC1zqYf6QiQkWVi8OvA91ui5X5iD2vztL0ZHSDa1WvSkwCW7xHlNkJbaxxKHNUMT75FcZRVf/n7JT9Q/C++VTD8omZtSp1jd/T+kYq4R+h5B3AhLb+iz2uaIo/jxc75rUXCpIK0TE8GcUa4egKiKNb83mwsfJpxJog0gP3qVPGNIYibUTfo1JNm7VS60f4v1Q+dO6f1g/7jzasmlxw7A9TldG1JP4XnCjCJSupKlk1LFPVVPbZ1FdG4AQ8MVT/XwGMXDdiVbAhfbFEqvlQSSK92gjJob5cB8LDZXrerMUJw38lsULrRK8YcVlUwJ8/5tJ/cq87/4GLHvcnRNWerp7LTBSCrYOkkKviR2nNJaZe6ZPFV50cMLL+nTWpy1KKuSESYMThYk1emRgIUoDra7nzVPyUbySUpZI6eAzuVLdXK2qNWpZEWuc7M2uxwX8Dg6lpPsTzq4hoisZ8ShSCuD2NXEJxkZg1bmEelJHHGvewI4Hx+awFRr5fOlLkwWESEnSwNhLk7bURXRa+CNEZt1yY0kpgtZIq0GYIAJrqN3m+FQBQRf8vqAg7k84Xrp+oHwobRzvtBzWMasxS1j56GKXBwWHD2vrovjT7grLmHGbSKtVGwnj+t3aZC7OW00I6YrGmLRbO5XaN6q+ef/Xj/4CXvSUSQx9rOVISQUsC3uFu/fmVK36ofWiFKmgkG04kwkvJQmJ8C1qM7XBwKGzrDeObEf3o7xmhrrLMwbHURuSQn3/ESjrZ4aS61T7suUy1hYHBTrP7YZ13BQA7s72Iw50rPJ5YujI6PwlRGE83QckMr1SjzKOVlKiWw7BZUmFc/X8AGLn9SKGMRNIhfSatYdpITCfxR1YbAchpJXwFuw+roMtIAHYePP01XZcKAI7Xpz6Y2pfeMhQP8fa0sElKVriHuswwraSU05dHKJslFfJPZ0MwMuSIfUJg0h9ys/Fp+PTKTFr+hpAuYr4Re1Sx+FwbaWdldZoIwS1CJFB0t18AqFB99CUXPEWYtdpwAK+64oZ/OGemn+YVI2Z6smRSsYpWtkCMVALTmK93okHm00piMXPYWGE5Io3xoY/YBwzuVobd1c3+H6KJQMWNWXXkQFyfyZxi2kgr3yu2WSOptGzxDXZw7l2xsllDGGamuU1/9tabsyrvJ6FO4SFJFNy8VbEUNKtqFSzWWIhe0fH6Q8qvjhixvhiVr4PBcBlCELONekgkllefSYunZV0PLTG0oTFtxF63spxvidKSjTR12fRr1Hc1hF+M1dTJ/GOEWwkAGWlds1uj+PUksliVM2UxNYvkObpKigax1xINwxuIt2zgtFexcxjJZF0wisYhGPv1/mEu81VykMyPQxLRLgNt8vcpp0xa/ooBd5dbgugc6ZZAun+1OPMUUqm9tXar6e++6PIn3Rer8cQePP+KJ733Tfd88K5ZM7vShlVEmBmDyhWsQkUzkEEXVmGGpjtuZ0bz320B0IW01eRaD3VXDBHI+Csk0mP3dQE8HRuHP46cIJr3pVtUtK3qy55vrX1CsMCfB6zR6v81KOam41D6bxI5sxQ/TpNIEIffn/reiCE3IPfXINaNxH0jXhupqVUZarHWROL2M6femKqf00iIqDEGbrWiYD3Ldsy8RWj1qPzsLc2f8UaLNV6fw2mwZrJgb1tEZqyyvDmMl1CvLdKv2VpgKcVcHRG4rlgNPk/rLPpKikQQi4NCk1YV2IScNuHcDVYbAfVqIwS5/xYATM3sT15x3be8P9UCFT+5b++B90qNof3t149AZCKpw1faMh1vL0tI0YbINBRPQ5/0kwkhE2Ew5kni8Dv54SFV91F8Whzl3rE87Ht/SmaQN3ppAsmRSGzAnJKNBJ+eNmm18lferzdn5NuhaG1EfhnRp3xy7/53JisKRSSf3DvzdgLu5UlZZvOLVuynGPneLF0BHFEQS1w2QcxXotFnG+TPL08mPPJyXloa+HOUsVqEEflUwiGU4mhgtZ78wqDyt1tfDQxFJMN1XIj7kCQRV6xAWkrrEKGS2giT137LeK8scMIBOt9Is3fizx64/Q25JhJE8prrb9jZaaYf9f4HX0TPZl12BFZU73T3jWMrBAQVTYWENo+AblIPRQUlMIr4o4vwmW+YuFshFL5fK/8AymRFSqoEskrJq9jI3x73kogI86RS62Ub1E3tJa8E1N153c3UqkFippYu0ymz8/p3fu6L7sq1QaUDTu3d/86w8PCEYZmMpGaitRLPmpxKugJS2JiOgCImrpz6p+PIMucwkspysfJSYcSqYV9evaE2g/nsCblYgRmLwvChJMLjxUxaMHJTk063gNUwWtNV1fpEiJwZq3alkhoLgG5CE/3ly65++s3ZxkCESG566A1vJEMfFxUTm3e1BalYpkQZrUS0ZaGJawiZCNKPEcxIKgeDse3WDhvF/fv//vZJiT4zFk+D3yPvR0L+sTiKRLxW4s1WoUnLO9Ktg73qtop32giRSJUA7DTnfq6kbSaxwGk1e1dtqn9D8NNwu6LBYOam/lZkUBlC0xWqadqpwA0BZDyvtdOIAWI9124RadgR3F+4KcEAn+qbmRbcJioan08olhs378cE4RGrD9+/RmDs6j3oa57YwFUHxTQQfa+I02POkhsy+ivxWVqhSaumijnYLfFULK0WnVy+7YeuevKbepqhzS8WeKo5+xpC7b5+pbWSSmklzrRlV0gyDrYKl3a8t2lpXs03qr4u9R8WyMsdf9zs/hHrjGHPb9VJZOyNh4Ehhi1nAgoZIyl7tAYS00KGk4i38li/iN1ksRaahjZpdT6RjkBqZlXieVWGzty7de6m0jaMEslLr3zq8R1z7j18a3mulRASvhJemM4M5huBROW5iStptoo0rr4uVD5NKJEHG8NgUll1eXSEsFmPYrNqswhSwn0/fvLlkP8s3BZaGTmTIxAfZk9yg+YYifBhOiekyv2uQB2pdKTBTFpeCQjzNTCYVc1bX3Lxkz/a0zwOUdMWAHzm7N2vvf78K7+9VpUh05qqjKnQdKatiioYY2BQoYaBoQowDUAGMISmKxw3cbUU1f0lA+PMUsaZrZxxKmPmAvwD8/cxsxa/GGkwjSIyGQeOI/Ybq7HSbjGsYR1Sg00WofceHSVGIC4eW2+XJKAMiaT8It6kVYlZWrUjETZJSqyKJ5AxfzvbPffifENIRDUSAHjV9c/+wweas7fpBYqW3azH36lHztRVoUboeLd7dtXEm8JrKNzGJysVV/sgUvflS11jmQVxYiOOI4lxQLw62ISuuEAdpGno4P4F5U+oL/qemIYTyideJziZVgXpsH+CRPzdaRKp2JRev9aPz9IS60eUScvA4NPnTv7M9137lDNDnldSIwGAT0xP/tIXbD/0CTUqp0NwraQxFWoyaEzryLFxKqrQGO54r2DQuIK2uoYtfOdc76pjxFHbWO4eppkAgF7vYhA61PmDFI55HonhoMiEwqwPH5sgvNYMK9kPVgr72CkLk07JhFhoLC4nifYg1EL0OSeRSqVSSiI1alREmFDdDfI7GhFrRqR8PGt2333zdc/8lZJ24UhqJADw2mufe+uO2fttL9wlY9pK8JkAzg4HitjiOgYW2oVn6Nj0M7D8pGaSVhn9eY+WwiPFhhT7iFF4jABWrR+syOr/2Du5Hz/J7ONaSur2lEYT00C8/JIyVWolaRKx1p+QRGpHIrWaqUXwsrkmPv1XyVhTffzv9049L/NkkshqJADwsTN3/OgjHnTd19agi3klybSzAYzzXbQ7hxkAtbE79c7axjNwfxtUAJpOo7H3es2kvY8CzcQ3Z7tbMIzXaYC4dgKAxYBKR0L4S8aR+Ygjidh7sV6Iag9zqn19YiCtqaQ1EH891EpCU5ZMja9aDzURQg0453qNuiUPksQi/SI+vYaa5tTs7Et/7tpvO1HcQKLOBfiJ29/5imu3LrmpFfftE2lg0JgGMzSYGYMGM+yZBg0aTJsuHDPMTIMGBlPTwBiD9gww3d/GGBiXqumutcct0cBdMewYNp5hx1CEkAnz14YhlxZwcKaxEUcZq2EQW8PN/x2GlrXvvQ4NRUgQiM9fnqdJxAp+GxInEe8TaTWPGhMi1FR3fpEaE/IkUrEcTDvCf933XvWEFw5sFlGfIvz8nf/5f19QHftiLvIb09JBgwZTRyozTI3BzMwwQ4PGNJh29DFTZNKgAZAnE2MgrvDXR5wXEEouPIdlvbLr9KKNGCGxGuR1UCgZEGpiaA9CQonFK9VCrD/EhsZ8InatCCcRq4lMOtd6zRzvFSSBbdX0oe+85LGPIaKmrHVCZH0kHH9z9tM3zzATDeB3kuxscyBRCbtw0S6AqckuZLRrUbrFinZRDGtEd0yq0SEfhnMaCftjid0yfj2GfTbJrghWv4QjDgKpfrA5JBKTAX0yIRWL0An6Hvmjw12aBSRiZWXcsY7OmR6SSA1JHjESqYHjp/Zmz1uERGz9ivGTn7n1bVdPLnxWzMRlzVcNGsw67WRq7PGs++vjpjUTr5NozQRIaydBmNJQeJwhmEeDyWE0fY0YsfqIkwk/SWsZsXv6zVjckAXI5RD2CicF71hvCYGRCNoZWnHnujRp3dM88F0vveqbirZByaFYIwGAP33gUz96xpw7zsPaSnfrSkguu/dzlyu/NJ9/4pFpJrbxNJvbj2m1X2GU2kls22O3UtOOEMQoYbhGUjJ6GfJvM7E5o9URm4Tcjnr9b6r4YVoHEjLFp93JRfXeO2Ee1UIsVSDwhzjTFHnLzjJI5M7pqdctg0RsnQfhRZ/8pac+fXUwtAAADN1JREFU/EGfdeuWmVQpf8nMGEydo711vjewPpS0ZiId8DZl/5frGNx3YmPktA9xzRgVrx+jk33EiDRWxYOy8FtIYQo6pFTz4OeWPOxvbcaSWghgjVDWlEWdI0CuE/H+D/9tkcoN5nMkcna696svuuZJ3zuscdKYq91fcfw3Xv6Q7cteyU1cBgazzmnuzFlone4NTJRMbFzT3dfAuH9AP6Foc5eMGSJJLC6w7FXw04hHjFgQqyKBNwEREii6LRneZ62Ix5Pk4WOGBNIea4d63JRltRO22NBqJ2x2FhWQSE3Vm7/78sc9t6BpijG3LHztXe972zGaPMsWDrD+EksQs24K8P6QSXvU/W7/RwnFxwuRntk1YsRiWLfpsOuMedp5qAWhTyvJkQc/KycQG4cgv2LoHegTYhoJ/Ma5KRIBDLarrbd+52WP/o5BlS/AQn391068/w+naL7cnlvxnyOTWWM6baVBY0z7tzN1tSYyb+Kyf4E+7aQ7j2govGxAiiTiw0KXziFIhdFUNmLEwSP21sl30QuDMvLQKWgC4Was7h/TQlofCLkPUzl/sz0vJBEDg2M0+c3vvPwx37JI+6QwyNmucWbvgefWVH+aF7i19XEnvHUMdapY1a26tKwK7zjyU9Uq1sDdEclc7L/WGS8d8n46sZopAa8eSmdZil78gz3ofyMWw6hVHk0ETvLMj1/tzeVC/F3kEscJarKE4GNyeRTqGXyLEzull/tC+LZSdgJT5XwfE9SdU729NnEkUsvtqUjKEAODCnTbd1z26GftZ7svhJ888Y6nXoVLbyHU23pqrnWoW6d7qJk0/p9pMGP3INBO2JJFY7oJwyb6O+ZK5+6Pkim9y572Ow9GQhlx9HB4RsHY+xa6XaTWIY/l0BXwI/V281k+k8vGCs1YBARaCBG5mVhigSH87C3rsI/U4yPfc/njv4aIpgOaYxCW8sReeedv/uA11cWv0873NJnY9SZ+m5WmM3U11k9ij42kEW7u8oRic/TH/jeC8PZesNDDJ40RI0YsByUDsH6/vPaBxI41qYTkwcuUJxBmMXG+kDYsZsoiRipeCwnrPmtmf/r8K//ll+0nifiaLwGvOP4bL79m+7JXUoZM3N5c1sHe/bX7cVnNpD1Oaydt2pJQgunBrmShb6Rv8m/h5K0MDm4qzpwTVUbMhXGK1XqigFiKwvk8LTl3M0Ue7TVLOHYnD3tGzAwPppFILUTupRX6Q6xPhedrYECg9zzv8sd9ExHNehtgQSxVDL3y9ne++uqtS25MkYkBGGnMMOuc7VYzcWTCtBO+RqWPUIBQSyk7ip+vC0YuGTGiH/PQSYxIiIUT6RiSPNowq314x7rXQNBpFP6TuG6mFnmNpBLXvD/Hf0DQ528AbAGvf+4Vj39Bb5WXhKXLoJ/6zG/9whWTi14YJxM7xdfuGGzNXp3fRBOK1VpsGhFCadOX26pYSE3FhWaPUtAxSsam4ZTBEauEg9UvxgnB+4dh7ZqPnTZpAWni8H9tuCcPMW2I7G4eXpOQBGLJw/tMuBbiDV6hP6QlFuxOjfnh77viCb9Y3CBLwL707Jcf//V/e932lf/afjURSJOJgVzprsnEwAhzV4xQpCs+TioAum+npB3yMcSuLNpoozgZMWI/sDihaKLIGbek34SbrXwMK/DdtF9hzvIzVPkWKFZDqVkM8XFA5Q+xg3YDfPI07X3rjZc/6SODGmIJ2DeZ9iOffsurH3bs6htrqgMysYsP7VoSAzhTl9VSGuP9KN7E5TUUCJOX1z4CUrEf2YoQi7seCx9U2+HNOJLJiBGFGKA6hkQwX3byb5xcWqEutRB71Wofbq9AwJmv7NRfSyrS0e4/QsV3+k051KlrnHPN9Pevuuu8J97wBY85vXADzIF9lWc/ceKWp11hLrp1i2rHmgCc38NpKQntxM3iYoRi/SdQhAIgSSrtkYfWXcoQb6ohavJhYnQTbybG5xpH6ZtXMsOrEg50fm9IHN5/Yjdg9B/LdWtG7KwsgtBA+FqWmBlLl5dAmKHByb3Tv/ayh3zzdxdWeV+w75LuTff8wWftmtPvpwYP6/ObeO2EfQgrQSheQ0F3blMFM311YUatgO8xbOnrfRSy7JlT4/qRESMODvp9C6fRkrrWHUeIA8wEBfidzblJSzjanQlLX2NpRHwhBgYw+Ovju3f++M0PffY7ltgcc+FAJJYxZvtN93zgzdOmeZYmEwCBdtIY5h8BEoQCF8f6TWx8TSoAGLHAxzD9JGKRIotwCdJyMJLJiBGLoewNCp3nKQe7ftM5cfB7xZYn5D+H6wmFOdzZLC5OOkB8cSGB0KBpQPTm2y+75/tvpht2i6q5zzhQafX6k79z07ahV9hsU74Tae6y+ookFGkeU5s9GkscklgAiO/A21A11ysod0yop+ynyyOAkUiWjtEOdKRQ8gaFs7CCCOxdt3+9gOfEYdOzPhC+rZPVPtimTx2pSK1FO9LB8jQwOK/e/pMz2PmJ51/6xHcXVO/AcODS6qc+c8s3XrF9yc+joc/i2gkQmru4FmKYhuK+ZYJ21laDhs3I8kTkztWGj97oxeH9KxYpUqDgN0SHS2EIySzDaThixIh+hK70lJUhnC3V/Yf8bDgnBWbGUmtI/D+we+MEUqO6H4Q3ftdlj/0RItpbVt2XhUORVm+65/cuqQy99pyZPpMMJppMAPnZ3ZYowAilOzaNnxIMu7bECM2GL1kMSMvwc/nXguz0/0C9DTtcTnNZBjaLWkb1YDOxis+11MilHNrEr4WObjlri5Spy0/31ZoGN2DlNBCglVOTavLB07s7P/aiaw5+Wm8pDlU2/dLdH3jSeaa6adfs/fOUdmIYoXAtxRquGhfPk4q9XxNLG+5zaAZ0eNtQfFmZU1FFh4uRyWZRwKpgFUXWvoF3vHFt42AM9Zf0+UqoDWDxPHE4+iBPQNL74deWxMplZeGE6A/un+398g9d9fX/obCah4aV6I6vv/O2l51f198/M81DgYjmAD2lF05LMepf4+JyrcQSiveXOBJhkojnKx5xOEBxcaS1NN6gR9VMdaQE/YglYH8ZMpeyJYZ0fKmvSB9pqF2Qig/Ep/Dq1A0MjtH2B/aa3Tc+78onvK20boeNlZFwr7rj3VdfUm+/eoL62yu2It6CaxQxLcWTCqeJBo19QMrcFczWMrFpv5IcdDe3BFGpbqWxXxrJEeWnESP2BTHPSNyUzU1aaeIA+BqUiIbDyIOA3alp3ndmtvvaG695yvsXrctBY+VE0U13vv1rrq0uvZGofnJtaBKKfKmliHNGFY1hxMO2cfQueKgjINj2NzHtL9Y1klrJyrXwiBGbh3kGa+WDvvC9litIWHiGOEQeBjBk0BBO7Zhz7zq1c/Y1N1//jD8bVIEVwsqKuZ+8/ZavuLy++CXH6smTZ8acD8TXeISkImM2nESMTiV08ofIkAnFnGTps3TqI0aMOEykDNPaKqFRQhz8qoFBBZqda6Yfvc/s/M7/3f27N7zl+hf/w5zFXhmsvBz72Tvf9SUX04NfMqHJU2aYXsgfiIY2f9ljRO6QHpS0LT9GDHF1N3ffiBEjVgF9mkvuOtnRI/rfb55ORx7nGjIffqA5+77bcfodP3vls44XFnktsDby7mfPvvez69PNjedj6wlbqD4HGUKx0DO1YtN9kQkJm8euQpHhdg75iGVjnJ40Yn9RMhGmpAdq4uic96eJ6EOzGd517RUXv+0p9GVn5i7oimMt39Kbj9/6xEu2z//WC2jyWBj8o5yWohGLo1e7ayzTWT6KxhErjTWcarfIrMh579TLFSpDZ6ZkPjE107/ZM7O/ODs998c/du3T3zV3wdYMay/TfubO//SMiamfdqyuH7WNrYcC0h45FMt/h9bsrRwxYkQAK1P2mtk5gD5JwMcrwscqU/35dl1/9DmXP/YvD7mIh4q1JxKO7zv+hideX1341Q+qHvSIB9PW54Hq6w3MMSDUKuYhmb77t+qtE7PZ3t+fm80+NqvMA+WplQwDhwwVbVz+F+x+nZae4DykbaidxVDJ+xrY71gPrZsua+z6wPIF6S0L+z18X2bZ+8qauh7rK0P7YSps0frF+jVDY5C1OvtOiorMzvZ0ewcTc3/TNPdNK3MvprjPVHTPOXP61Lnp5J4/bXZPvPP6G3bmLOxGY6OIRMMYs/26z7znq2aT+kvJNF8EQw/fruurJzS5FDAXwqAa2oUNDGpTnyDCp2qiv92m7b+5cPv8v3jY5KqPfv6x6z5BRNN9qcyIESNGrCg2mkhyMMZsv/nej1x73969182wd+0E9TW7zd5Dtqqti45RdWar2j69hcnp8+sLTp8Hcy/qrTsmZ6e3X4gLj/+LKx9+/2GXf8SIESNGjBgxYsSIESNGjBgxYsT/BxZFwH9KYh4RAAAAAElFTkSuQmCC","w":402,"h":321,"e":1},{"id":"6","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXQAAAEgCAYAAACkfIiyAAAACXBIWXMAAAABAAAAAQBPJcTWAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAgAElEQVR4nOy9ebwmSVUm/JzI29VAswndXb3QLOqM89PffN83o6Lzw09FtoamYQBFZwSUTRSVRZRVpAXZN3FAQUFHBPTD0VERcMQVN1R0xlEYXADtpvfqrl6q61bde9+M74/MiDjnxInIzPe+d608VXnfzIgTa0Y8cfKJyEjCIZP33PjHd7upPfHw89bOud/Za0cuxgJHW+AeLbbusfD+HguPu3ss7kZo7tZiccSKw+92pndQCIerPLPsreyH9kQ1P3K3E3C783R7Q+5WAt225ppbyePmU4vNa+5wW1ee3rrtr15w9PK/2bUM76LU6uZAyM/f9Cf/YcO33+TRPpCI/q33eMBQGI9DUPBZZpllsoQByQG3ELm/Q9t+Et792Refd/FvP5gecMte52+7cqBwzXu/9q5jf/hIAh68Bvfvya39m4XfOlrUXyaNFdgffq9NmFlm2cdCK0AdWgK6dAhp2NHGGjWfWbQbf3fa01986V0v/tVH3OVLr9peLndf9j2ge+/dr57426/b2Nz4T61vH3zSn/qyzkc+/FkYmrsZLn41ID7LLLPsnbjiKEGVK+2WMKUh3Ho2zvpL79xvfPs9H/izRHTHanK6s7JvAf1j65+977Wnbnx6A3/pSb/5lWjR1ECcu2qA5hazz0Jaccwyy2GQ/cB475zUwUva8BrvCc6Mw4rzCK1d7Yj+iFr3wW+/9wN/nYjayZndJdl3gP7W6z72tHuddZdvXcB/zcK39xgD4h6pfluffDNgN+KwZXud4PB2oVlm2b5sH3SGYyD1251LV0fcnQx9ftb16iO09plT7eZvXbt5/VuvuOiJV07O+g7LvgH099zyJ0/wm/75LbUPSlUrgVzDeoBs772wvNvg67m2plZssB+Sst7htoZ2XIZmqvdsJnu+r/tBxhEquQsxoCYG4MR9KblZ4G4BuyMc2wLe95X3+tKXfRVddHJygXZI9hzQf+3YXz70dte+YL09fakGcmlRJ9BuBVh3UB8s81aE9fAqLh4ThNt4mSc9Z5ll92RoEtUCdW1pKwiPbh3QkwJ+G9xNOqY56/N+a/EL33Hug15DRKfHl2pnZM8A/YPrn7pvu37y9Sfa04/xaO+igVxz4hrEg1XeMnj2PZx7rRtjhTwzgLmdBO37S+blmLPsrRgtcIcaJaGyzoW0Vc0AnGRYgotgTaCehiEF9gncLSoHAO7sjvzt+uL025953jf89AqKt7TsSf9/2w2/+9q7NWc/beHb87l7AnLPgDk/b6O/BPB0BRZLzqvXINvP5vcss+xrocCT1HTir8voluDv+olRF0G+v0YC9wjkBDhFzFi58A39wT+euOqKN17yn/9wO2VcVnYV0F9+9a886OIj93p7Q83/Y1vkCbxbnwiWtl9a2AJo0SJQLD5CusGn+6BboltsYJ8K59tb8sjNl9m+nuXMlanrysucOmXnXNfBAQQG1j14B0hnFrrrNRwo0jIWsGuOfQstbvUn3/Di8x71okmFWoHsGoK89djvvORudPZLvPd3CwXXHHnbA3kHzG20xNtgWfteh1na3gfrvM2gus1SUIC9gjXos0E/yyzbl+2+bBSBnMXjmG/4m8gUZqUTt9IluIcrh7HAngy0Bdrf/8LJ48/8sfs+7rPbK9142XFAf/5VH7zzvzr7/Ped5dzjS1Z5y8A6gXZizxeRamkjiHfAnyx6MP+A0ZwP19x4C98VXgHy/JLRdJnXgcyy25JZ9GT7kbp2PcEewNdZVrqT4B6A3PUkDQd2Fzn2xMWnlD1a8ldffermH3rlxY/7xdXWgC07CugvvuoXv/H+d77oHQ3oy3m3j8sKkSY7A3BrIE/WuEfbJpolgHmLNlraYZAIVEuQbhBIadZkKqDPQDZLJzllNg9002Q8GPnId5fjSiw3kYybBJCnic/AqUcgJ4p+DVwB2LuYHCVI18C+QIub29t//KXnP/r5o4u4pOwYoL/qht940fnuHq9woDsHN22VRyu7B+6FAeRtb41bIJ4mR+VkJ59I1RLS43najowdAGaGfJb9KPulXS6zN4sMz87ZMkSdBgmdTpxa6dLRKU4Be+eXgN311jvQUK8ZaBjv1CDSDe0n/Ok/+KtT1z3zfZc8+Z+2VdiK7Mi9fNP1H33H3Ztznk0GxdJBdtvx3j1PHiY7W++x6GE6B3J+rUE8TZKCAN/KletAGbi3uyZ9tsFm2d9yUJ4TtjcpWhoQtGUOdGDOr9NEqAL33hoP7o1hsbse2BtFw+TWencf1rFx5T+eOvaY/3Kfb9uR7XtXDuhvvP6j77hnc86z+cQnX4eyYJOei2ipt72F3mZAvkCrlivmIC4tbp4mhHs6lz6ZyxLt/yB0mVlm2W+yDADlE6hyEaEF4pYmB3gN7pE7RxnYg05DLtIwwVqvgfoG2qs+u7j58rccffzKQX2lgP7mY//jJ++OO3+PBeaJYklceYtFpFdaeLQts9B7cA9AHtaYxzdCfWLigcDLJwn7u1gwrgG7DMZTYdq2hmawP+hyUKzcgyHLg86wFQ5owKfsTPPvYd15F1YuX4wTpZDA3gTQJhLWehNpGkbBiAnTuLTxqn9e3H7561f8oY2VAfo7bvzdnz5CZz1Tg7lFsSwKVrmgW+AzIOfWuI+Qjf7aBnC+n0vNRq/LajrzfoaEGbJm2Q1ZDnDqoSy2PEiAbgvkNcBzHh1ABGUygL3pXRo4ONdb6tEy74GdGAdvgPoC/qqrT9/y2Fdd/Nj/OaU2arISQH/7Db//M2e75hklMF94AIJi6cB7gTZa5S2zyiVvnoBcW+MSxHs/BuDls6ErWw4C4O2XSa5ZzlRZXQscE0sNzG2yhQE3JXdNjnCrXQN7PHprvoFD49g5ERwaQcE0lAgYDeqfX9y2Mkt92zX/mus/+vbzmnO+NwfzHqR7y3wRwb2NlviiLVnlYb15olbSni369X1fBPEhUF8V1TK/XDTLLMvL9JeKxkyA2j76LAA7nyatATunYsJEaLDW18iZFIzFq6dnAo/TfnHV/1y/6lHvue9T/m5qTdTqYLK89oaPvuTe7pzXkAXmnlvjPvLlgWLpuPM2US5glvkgkIeJVQnVZUAfsM4rgLzyF40yA4Y7HBD7+oBkc5bDI8VljX1bHOLN9bmMkS9nTFa0BeycY+fLGF1cxkhoXGefNxNA/Q5sfOrTG5994E9f9KxtbcW7tmzA113z0Ufcy9315V1xbTBftC1aggDzBadY4rLFQLfIyU7+ApJc2RKkDOJDk6HbAeptQXxxht70XJmslCM/0GA+j0arkJ2cc7HuTrG/9sqhb/Ol0kQ8jxTPA2alq3TufacZrHaCB4HQgkDwcD7kxYEoLNlw8H4BkIMHdZyw8wAawLcAOcADrvMAqBsgfB8nQDgHR77iy9e+5L0AvnlabZnVMU1+/7a/P/fKzZv+aMMv/g0hvN2ZOPPOAu/e11z4BRbwOV/OaJjAlbc+rHDphG+9lYDc/luaDAXKjaHUIOfX/2eZZf/KmDXnJf1kyXPu3NRkdIy02HNrPadgAq/u4LAGl62AKXHqJxenr3ju0Yf96PRaqddBUbz37gPH//xDJ9uNRwEJTIfAfNEy7pxNkAb+PEx6aqs8UDCcauGQK4A9cunDSwdXAdoz8M8iJbf+59VD42W7b4tacVgxpiWKeShS1+Gcv3wUyJJGcesu0i91UG8oUDR8e68+fo+TN2/e/rgXXvSo316u/BPlvTd94lWn/cYPh+sAwAtGmQTOfMtLME9vgyZ+XXPleo/zsUCuwVXy5/UuNQaYV9Ep54f9WWaZJuNWutS19GZdlh+R1JTAPmytB1CPvLrvuHQHhzUT1NMSx7AcMshZ5D51v3td/FUPpgecGlF8IZM49Lcf+72HbGHruXxFS4Bg78He/uScuQXmki9fJAgfBPMakCewL1EstanRTHnlMoP5LNPkcJkAy0z/Z93QCBT6dQmsNUZIkiM81vfPUsRj0osnSPDrDkALgkMwTB0cdbjX8eYtQMCidYBrsQBFTp18C6ABqIWD6+Pp0t707Vd85ti//DyAbx1RRUPVY4v3/sgv3PxnnzztF/+Wg2tcO96D+YItTdxiYJ7eCG0NvlyvOw9u6TeeG7RKCcire7kYgD1TKLPMcnDEtMypfFnasMvS4xY7CV3LWg/bAsg3RMMKmIYS/dKgQQPCGjU9595Z9k1v6/OVLze0tz7vZedf/rZpdTJS3nvzn/7U6Xbru8N12OZ24TuYXvTW95ZfqNUsLePMbTDnyxWHwHwIyFNIJgqnx3Dsy8vMmh5Ome/rfpQaR24pUUFHA7tFxYQFjGFlihsA9bSkkXPq3e8aqaWNlMKHHDjgmpva277yhedfdt3Y+qhvKtzLB2768/+waPGfQ5ESEHd8dwDz1qd15WE1Sw3M0xqXBOae/Yt7o3sJ5nwiVq9SjwNAUhJxch1+rE7mTn84Zb6v+1Gsvpz1doEFuQ6Q40e89sE3tAC58i5+Ya13Dyv4vAdb0Re2B2/7pdotYzTicpI+fJIW/qJ70t3eNKU+Bi107717/81/8dF1v/HwVDA5qbkFz1a0LLDVpsxv8UIJMJc0yxirfJRFXqFkBss6d1pTZtv04Mvu3sPd4f7Hroop0i4k/fXaljoNIydM05eLwp4vlK1+WetXtoQ3Stfg0FCDNRAcNQXqBVu3LO545A8dvfR3xpR1cFL0F4796dNP0+LhodgR0MPOiWx8CVQLH4FsMG9ZPMBYMC8C+QQQnwbaww3zTBgEDn8JD7/s/j2cluIySxZrfY/Hp2fWoo5PmNaph8lV6uNWk6eeQOTh2fDYnRFa7+EoubdANwEKB1D3u/AtQIRFPxHYEkC+RUsNyHcvKLXkOZgD8Gv3cue8AsAoQK/Wovf+yPuOf+KTp9otNhGaligGq5zz5ltY5LRLOw7M4wRpxSqvAfkyIE7Ivze6jMygN8ss02UVdvyUZYultAkkLPaStW5NmEYWvcCpNy5tudv0G3UFPj1Y6Q26F5PCUse0lLEbJO5oN7//eec/5O1DdVHl0H/+pj991al2U6xqiXx3//JQfH3f2P42nAP8O6LTwDznuRKYZ7w5E82RWe6BOtJi83L14yDI4VkAN8t+kFW0p2X6Wq2vD/V5K+2gExxKuBPPGXZxRiHuDJtiBIDeoEViLJAo6e53wfAyfBM5pQgQ7k53et4H/aeODNVnkXJ5//pf32/jjtPfASxitECiWuISRDBahf/2Vnz4Xqio1glgLjVTOfPbA6Fbc1sJAB8UFGey01meufYzS3bkXo8cJWppi/Xl0PSLN9zkGXmCp+TGKZgy/dJptZ7gqMM0hw49GxDa1sO5ng3wLYgcWu+7MIp66faEQYwDABa0+JKrb7z2DQCeV6uXooV+x4kTL97C5lFe4PA2Z+u70cZ7vUcL583TihYB52oUGwPmHugGAWWVc9GuelQeZU0fNpN8l2WuFlvmJ6MJsgKTXTtbFrptsVPCHmWtpzAsvDJM46/n8atdZNXKF85sCOyMBHUoEeGubu1Jz/v8z92zVn2NWafen/13p77wEy38PVLlhG97sr3N+98t3y+5YXudW5OgrecVnVdAuhmqApW/vAn6pujxNguwtNjPBFPjmOVMk/meLyfb2ttl4J2j0jp0Mw+kdRTDTsGO56nk69i767Q2Jpw7EEAdZ+7Cpl0U1svweOkud7/T3U599A3v/cNSsU0L/b3H//R5m769L3cLQBzf+OxHkUUbuJ8wpvj4NqfmzTVkB8t7GTCvjbgeYI9MLPMDPcsP/FuFzNbaLNPkcA0HvnBu6077lyWk+rxlteu0dN6CtT7VUpfJpx1k24CXCEYvxHeV46aF/fciMiud7vQttTrLAN1779bc2hPkMsVknYfrSOKzX/3ykLgprNDSSl8OzK0bIe6feUNXA9jLPBHOx3wsd9Aep7/aA4VzrbOMFPuzilymnwM7DxbdfAjnWTgWh+fxJs0Uv6ZeOtc2kDCBeukXmfj4wpKUrXbxFe8+/sffUaqDDNB/6dZPPv7k1umvhshwd7QeBeucZbYPJZYoqsLGX1HBqqJ8Op9S+fnNGw/YUxrlLDsoQ5U834Ql5OBU2tQBohxPBdyzuLhhmBuJY0A9/WVY59M2KUE30dEJuBdx+/DOIm9j2JalCACEs9vmyaUyZ4De+vbbs2qJ1nlulYtfD/YxZz5CyQKHgvrcFRrM+c3h50Wr3NDh3jNQ12VfUEJDmVhVJn3h/FDKvrizK5ex/bkG7GCnNYNxENQ9lE9uxMaNA7xlpSNa6Z0h3BqWP3DaL/7fd93y8X9v1YdYtvih9U/d99j6Ld8gK6rPmO/XUYZvgQ5a533ogNA8Ti8ra0hGWeWGv+E9OsUzVUolP5RLEqlwfkhlz++hx4rqeVwkvKzxvcveNU5T+qQQsueRpjjlefc3LWuUSxo7tKf46bsYgyeAUspAZ6UTObTwoC5Yt4yRKPLpDgmD+YSrR3ukbdtnAHi2LrOw0K+949izt9rFF/EqCRFy0K5Z52nNeXlVC6/wIevcAvOaVa5lXAOebfUhmWvl4Mue38OVDZrT+6tlsVsKQ5Z6vFaWutTNrXS+k2zZSveMO28hP/3DzWLCWW3zaKucAtDvREcerGs9fB6uRQLstu1B3vusUOnaMxcG6gywx1AtsqLUjamAef1WywaxJ8bZnveuFchhKMMhkDPg4WJAPOKLKiN6fbo2aBhw5LKNSTvuMvXCTVqul3PpiQGJzIeHol1iepe87uoPP1bnIwL6p9avue+G3/xyMaqILKWlNRyQ47aPvoUuQm6d2yNaCcy9Ci2scs/D6wGlJLbvnuDSHvXClSY7I8m+kL0cV/dNExAZ0QiUG3vyehyoy9iHrHRp0mrz1rLSJa52utxP5/zuR+6SWekR0P9h44bHeOCuOluSaGFWepx/7TLVbXIFxFWTAaXZX2tVS0mqYK50DK8sttmc7GSna2HfdPBZdkUOTq/aPqibTITCo5qVLr/5IFNPb4+2CSf55Ggfgq9JP7s58rW6lBHQN/zmg4bpljZNaIZfhJeK5OPJdq1zqWe5jbHKZyDfbZlr25Z5oNsPkoN6zghQpoNMJ491vJWeXPjLRSFMx3akN324Ja9TXnh8+Xuu/OOLuJvrlP1Zm+3iq7hhb9Et+rGg43x4wYMVz10QM2QW3tcqQxXBI3PfDpD7PTraPUx7PuZ7fpiPYcm1vDhvTbUx1EvQi+deR+VNYOa0S0iJG8WtmTpAfuFuO+vU47ibA4C/vOXTX7HebnyplVnJUed0S1Y4WHBrVYbmy5O7/JUKdTAfvq3Tbv7OyGytzbI3sj9antXvVxn3eBQo5UkicQmb8lg1dnloJJO4KkNr2qXzb+Nv/pIR0JxFD+WxOAD4zOL2R2ZR97PG/EPOYXVL97/3NyZD+Xm1MnwO7DIf+sTwq7ho370E8Vlm2XvZHz1gd5b/04jSlkFdO2ZWtQJorWBZ6flAZtMuADJgt6x9gND45oE8XQcAC2yJ5YoRjPvQaeP2BMrSbmd/vS6+NzJjV97YEdDyqcneNOP9YQ0dWBm6aXuGTfN9PRiinvAH9HLXqRjEWYpSGr2GZaB6vqIlaacNyG2+4yxyFz3/qg9GdsUBABF9WUqOv1VlgbfNEeXLamrwO6GaB6mWoQreK9kf1tCBlX37+v98Xw+ajKNg9FmZerHj16ik6ZdcP2CpbsppMlTOaVpv2BOAo83dHhKunff+Hltte65VKD1eyDXotcLlGeS/3L36Ws8gmJfTn7vdXAej5Ax7/X/PZQ8b5VhsqIE6d7MWbXjh3zv7pG3ZD4F2iRjbv2SULPmajQ6ctdZ8eTh3nz5x5cWe/F3yQqUo4htLClo1f96KQvPCGAVRJvgQ3WLLDFk1mfFpln0n+7ZRjsOS1SCOBda2IRy21vVKm+uuESXK5Wp/25fliXVjScuCepZqiT9PLqUsTqRblP6UkfVAyIHLsCGHoQyzHA6Z0BaXstIrbmNol6GU+afrPJBx7Tn33hE2RM0XBxd3ot1SyxVlqOKEKLO88+WKmraplmNJOQRIsm+tlQlyGMowy+GQbbfFAUwxvC3aZUrs1vJtbiRzvl26JWk8LgnnboH2/lbC5kxsPb/Z9pw8Dk+Sj7GWK+oljbsph2B4mGWWWVYpS4KCadgauD/EVnD7PgK7EeQsWjvnGdd/4CgAOPj24lJGhPkvrPR6QXKgDr+lRT3DtEr+gLNamQ3NWWY5s8RGEYZFBVAYgz5DyxuHQrYKLYcM6Xut3en/AgC37hfnj8jfAJSPK+QMmknmJ4JZZjlDZJB4KC8I0VsFlCx7Ot1+OQC4Ld/ecyghy0Vb7NajwHBsQ/qHF/bmwW2WvZH90fLGTRPulUxbzDGIU7HK63F4z4Ddj59M7ZJoLgEA15gPFhZVLx5Gitkam4Gq7L87PMssh0T2R+fardf/tyvmwpJ4Op4INmcMPTeQp+ZIhrhbc/YWADigGZiZ3fsGsPc5WFb2hzV0YGXoxu9Zw5jv68GQnW4geTsoLV3UWiWp5bitxHlk0bQA4NaIaG6fOyUHdyjaFzK//j/LvpbVtQPr9X9+PkRpn3P2nRaA+qbowZC5M02RubZGyPz6/+7K3Cgz2W6VnNWiA/RFu5ir9xDLjE+z7DuZG+XKhcitA4BrC9sGWzwMGWezbFMOw3B6GMowy+GQQ9IWSaAtgQYgd4FFB+gL1C30LuKxAD6gd0gqe6VyGMbGw1CGWQ6H7HFb1IawPUFZM5ZrcYcYc+0jHj2gez9mCXk1YQLgMg9Dc0Xjwk7JPN7MMsssQjQoED/V4F2WHIRtq7seR/lqvfHrALDWeDq2IK/2YQlXFMcDEu48kzsHgwRC2DE9z9tOpDfLQRFfvNglIfN0lkMhjO4YcXPHLxMsWeaGO2lLvJ7G3XGnzwOA80T/XApS4tGp4Dcu6VmCzE8EZYkbEnn7AD/2NIPlPO5l9mZZrWx7bbcP8ZTjd9QtOnQM5onyRVg6Lx7At3/R1/5vAFg7Qu5zp3wrFAKFwtl1AsGBIDV1pkTezUwPvag0zv7e2SeD3ZJ54GN3ccLt3A8vu2kxO7wXPzrAHt7//dF/Og4gP98tsdMbzsU4vpu0w8jwZP6thTkbazcAuAMA1s5uz/rH07RVjp4A8sn81xl1AFqEpTKSGAF1lgpvPgTA93GGjrk6oJ9lP4uPf4b0lrjTK9pLaBSoFDbLqAdRgbyRn10D+f3Rk3bv9f/lyrtsnqxyaeqmNsGpdcLf0moXcv5aIureFL3/ne/+aQDskSCRKukafWPrWpyDg6OO58mLIK9LA4EdagoxeVDs24OSz9WKRZnofuUL/8qRIac4Wklv1I5J+a4dQxSQWYQRZZ0pmx2Q7S75qHuTfjfTmDRNv1JBoydRR7eYQC4wWQ8aa18I5+6B5/zrzzvgjqRBkbdxLHBYxZJnh0VMtvt2ZAp3tT+h88zokhrsLDQaArMiJ40KVo646aNBmp1PlSHQLxVgTJ3MAL96mYIVtjGaE8xTJkdJAH8nLvn2mCvjy63z7umjbbc+F1wcEd3WuLXrtBp/HAijg7ziI4c1agAm6G8Ddodt/Fks2SkQqAF41Rq1gDuPopymPqxBoGY9lyxqdj4U5wijvJxvK2/L1NtAmvta9l3mqXI1NbStYfMYHYY6cvBBiyk6OKTttiTeBmm9/3Q4XwOAjXZxJQFfYmfDgeAjgFsTo5ojB78e4NHRN1nOo0fd/mQMxz5LWVY17PnshPsV7o83T8elMyXQUDyTIqo9h5ajqz09lOLRdSr0KHjJmCl5JJ/sCXqfywHJ6JS15sFfg662xmuseceMUA/k3HDmccsYNo/QX4VzBwCbfuOfdGKCZiFtjXe/gUfvwjnIhIjFVebR7SItLweknUjZx2OVoCEq1qQONMbyHrRaC6BZ4qNzy3as/VzO2fh/9QKOfRqx6mRUveu0Jpb4UMlA4ZfCiAo3PkbHmi+0VpprToRjqDUh6gF81z0e9Jfh2gHAXZu7/oZMzPUTnjLiCOzUPQpYVeMyHl3peGQFscSqAMt9TNh9L/sww5NAfCQVUASqbDwYAmkdYX4MUiYTjlo643KdD3hWnY2pt6H7wS3+MxbYK/1pO/hRc68jGklNSu6RPycJ8kEnsCIyrSTe4695Sg4AnvJFD/ztNdcczzMpZ10dyXHH4tF5WP3IYWG9HoVkMTHuDhiyLEaekR2glwxso7sN4kNgVLS8uX8N/IZAOlepAuOyUsX0IfCPcQzAvFVGoyzmoGikwQMcCs59BTKdF5/GY9XoFtsS7wGbHCISMmDn/DmRtf7Fwzv/ezwPrkuUNpynT3iWYEiss8pdHCVcfy7fZirRLjIuUUkjK2jYfbXm7T40lndUVgkONbDRcdas7VGrW4bKtOJj6bQNoCemPcaSHztocqUZ3KcIGWf5VeeSUyl6IrNEt0hKJU+pM6Bdj7uKHYnxyXBn4+xf4ddr4aTF4ncIeCTQ3Ww5r+o769wTiHz/Czjv4KlbCExIjaR7yzQk7AHhywvti5OjYiK0D25OnBpXB0lC7exFuhbgWoqlmvXZyYj4mP7UO5ZZtLso1eRGPFDy8HxZJKkTXWd8AlTEY1h+/H7wp2EvekqKz/c6Z5oRI8UuPSXQqWhZYUrx53RLWKYY6JZgg0t2hKJhraVx7sqn3utrP8Hd4qr4S5qjvwZybAEL9QmBJWTTLuGKP3KkIvTnxN3O7CbEZbdromaNM4eiJcctz9zIrlMnk/hiltcxk6Vm+JX8G2GlW08XxlNGNWihjMWnmgHrPYsTMj6G9klvD8QXzvdChvpizTrXOAhMo1scKM5ROkqrXBw0dgbx2Nryf6HzGAH9off81587G2t/rRU07RK4HRfBPWRGwrwTMeizvPAl0RaMHjAMzVmUiM4d3RTwKoDIwmMYxHWAURw7y9sqVrgUI9BetaMQcPpDwU0AACAASURBVCz4l9Id4sezbJr1zUFZBhoCdzketFk8e0HHaLDb+VRsd5kPicTLWOea75Z0ixPvlyarvCOyOYXNEDaL9RQ2P6rzId5bvWPr1B+FsTsRJmnas4kEPaJrAHaZsfCIoApVstJjfLoyePhy5ZVk/0D83uREdOToVrDGMQ4IeBzmYDABwOu4W4FLDcCtSt86jGDFoxJPfRAYzHlW0O3U2eBgWomLj+61NnE4xI/ugRa3zd2nWefS/HQkkYCIW+OdLp+j1Jgo6DWi499/3oP/q86/APTr6fZflSOVQyNol946p3zM6IDdqdByhLIrrMQ86ZAwcXHISt8foL67XWMqkGdhK+FLFv0yAG7BX4oY4qiCM62ohn3h3CqTPmqgXwF6HfEUgB8D7mXqjJZuIwdNbAwoPennjkMLOqZY5+FvYsfltXPJSO7olkRzc7rl9GLzL8KGXFwEoF9x/uV/3CKtaxSjQ7CiA81CAdyRWekuZHHASle1UAR3S3+85n4B9Z2XOhBDgkYtbAkkxoL4SACHitcCtFI6Zrr60APB0AHj3Ih3cl4soO81twPwS4E7C08D4WthVyK7MFIMgbl0HUfiWtY51y9Z5/0ZAq3CJ0MdCE1CTmGjS56i+z2BzQ9aeXPa4bRffMCL4CQSdYB4HAhWe6JfnEjeQWfFenypV/CQlW6FHHY5PFID8qBABihkgGCF7RXHgEoeTx3Ax04cinRYWoNUyCrEiHeI1plShqUA3khnmXvZDoTfcWDf4U45BcxLKlMxyoJfTZsQ+xfmH4PRnOYmESkabeiuUfP3Lzn/ET9r5ScD9O8/9xvfdoTc53mG9Ruirn8MaMilrXRVYVz4G610VmRmpYsKGGulx/Cy8oZkX4P6kr1kCMgtALCtsjxsqQOXLMM8njqAm+VhcY+dLM3Csjys5t/IMaIE+BPKWwb4QjpG3Pb9rT9tFcOzsFxhv1MxNDJzZSq4rD/eOu+0XXQLc5AM0ClZ55FPB6KJ7EgOCd3dwC+XypMBOhFtnWzbX+H1EcYVPucq5187yzzRMNxKJ8NKz2E7uihQH5og1RVac6mF33OZmLHY6eK1DeRmGIUOGny3N0maAk+d8LPizvVHwO7kWdChY+wwUci6BfQj6yQpFmz3IWDm2Y/u4wB6LLDvN2FMr+VTuModh7BnjHWeb4nrovUtMJQ4d+7yCdT+90hz1hcesLjn662sAwagA8DWFt6wBnej5oCo/w3UShMs9Ui6JIqlIcYCURoU+EhGmastNepFMlXjZEhvH7bRKKM62UAYHs5HhXqnXnaSlHRcOj6jskvQyQcLfVQnTVdxsPiLSpWcFwq5i5Og5Tiy8EbYWrj9ZK0vgwGUwKTsx6+Jg7bENIlWaR7RcT227LsJtjjlK1w66oXv5OJxavPUrz/4/K84USqXCejPufDrb9ykxYd4pxScDxwaljDnz8MIk2zxLhliLnq8yypnSeqlojnBZ39a8SVQ5gq6Yw1aZwojh9MrhK8AUos6gFsQaAH3EFjvpgyBvgX0gxBvlLOYbhHcpfJYq30MsIsxC0a4Sr53S4bMQtvVBnMOv+EvB3MT6EX4PC5i3LjjRjCp93pIol9kOsjdekN7+5trpTQBHQBu37jjzQRaF2AbrfSUkYYc44FkhlzkirRFDuEmK8SG5+LjD2n/gydDnWBqRxoD5DVuXXZ2HjYFWmaSVMdXBW/pNCg63R05puaF5Skr4xDEG2mXymsPHEY8VhzLALvRtkSYau3svYy34jvOuuY/bJ0n4O5Z8R6808crGiJlncO0zk+2pz/08gse8/lanouA/oMXPurTp7H5EV6cZI/njw0JxLtMRAueQrbSkhxRcDYyakpFg/tyfDplLrbe3kkpH9UOt0Iryu6koaPWBwEefmiS1ALwseA9BNaj0XY7wvNcAf1K0DLITwF45ZvFCR6fEUd0oBR+m8C+HWtdx7uM1J/Fl7XOeQy5dS71k2viJ9IboY4CtULpHImubuJKF0J4zz7E7wEsqF18oT35poFqKAM6AFy/fv0bCe6kLqh+7Z/P1DYx0wn8Q0LpbaihChymXqbz6fsFvsfJVCsoAvmEDlaytkrWeJZHI3zKxjgAL5XdBOySfnbsxL/hfIfMmPkfyncV4HVAGhxcrXiyPKrQo4DdSK/aTkcgNBXOty9lFBgCc4sJINM/MBd86OBuidFoGJMRjOCGAXxDaTDgoE4Abttc/6XXH738b4ZKXAX0V13yn/58fbHxTr5e1QLyNDMb/FxvmTvhHkagZOunwqfMK+pFgbo1evKT/Qvq49KOnSpeT6NXtH6pE26XW6/z6wrEYcel4xsHfgWobXkk2IFDji410Dfzr0G+WsYyKHsjQI2S4ZkaY3nHIJU2NakNolzenZXxvb+ELSi4D1ItACLVQtISD+BNimbhO2WFwQDo6q0Frvyn9vjzliu1Eu99895jf/aXp2nr33UJ+P4GtVjAY+FbtPDYQotF22ILCyx8iy14tL7Fll+ghceiv+4myTw8+vPQEXxqBG3/G108oBuz1zrJQ/gzpxFXeyuxA8Zr1fkqukP6y4YphUtOXjtU67QUVzVeFf9I5+XEQ/amQg8pdhzTY8T8DtX9teESLkrJ2U+1MnwW2ginw2ShrDClNAbKuB0Zgm+LuuU/0hAk6W5Y59EsZfuWO+bGV6o0cFijbjn3GlzHZFDn1lC61nOQhK5/nsCp7/2Bcx/xk2PqoWqhAwARLRpqXuXIbcTC9Hc5rmzpzxtmqTe9XhqFwmwuWHj2qEKFx5m+ZkvUC7svym2c9n4hYqZaRBr4p1hQY8KUwvGwFEYAFt4cEKRxm6fB4vQ6MiN+faxURj7/l/JiTYDmVr2Rb1ZH1lOKGb+I0YjLiqNiSY9rOyNomIG2nGVqm7JdMIfhPw7ME34FgiR/aSitZ+GAnZZ8871a5AoXD+Ast/aRsWAOjAB0AHjSuV/z34+4tffxQodk+WMFxTXpAcRdv9mMi9MDJEJvn3qxuC4t+wW0LYkdJl7XrXLZWZB1lp0Ccl8JOwjiOm4RV47WU0A75HXXj6E86WMiwI8Bd1lnNiWzU8C+jNEhyhYudrhzmmCu/DSWlOMqUy38b2egsq1SCIIn7/jzBPTyC3ApD0fgrt3YxHOmlHcUoAPAk+/5Nc++k1v721g4AsKKc765TOOCtd4/SvSgTr1/WoupYR3qbFwFy9/oIdyFX+FqL0C/2OhjB/HSL9Nl+iPi3g6Qc6QtTshVQdwGcMvytqQErFVkrciYwWIogmKeRqQ5BPAiXLVeFbhbMWwH2I0wJaDW+lb8tbinit1vWZ/33JUsFRPMy9Y5D5NCcOtcMBGQjAVnMCJ3Tow9J1mak4uttz7r6IM+O7pCMAHQiej0Te3JH4Hrtmzk1AuBkf0gNNSwJY0JzCP4kwP5MMqll4409RLTLljpKn92vvepfV61dqIWMd30GDZtgqqub4WReWLgi3LYYRBHFs8U8C6JHgz8yH/TQ+hQlTyNzL8JyAyUq+BeiCvVsRHDJGAvh6kOBAX9mu6Oic3FFr2Ce4lqCb9yVQtnGhI6OWbMcsai4YDOtiHXLxM50MeeffQb3zi1yKMBHQCef+5Df21rsfhZfg/4I0N4nAgjUVyaAwfnQiH7Arj0yqtFvXDrPWmgSL3AK7AfpF7ssT247lQ7i50hXo+wcISuBfy9kwHKGpDNvJhADqjgWVp1WmYciPMBYZA/ZvHHdCwupHCMoVJq4bVyDfCzMhjZLJZxDLgX6ksDO48hC2vkIU+3HIYDdQgh0tD5KugOUViWlMw3y7/Em1tP+PZ5f+Yl1cJBPPLg4nV+iixF01vijWMrXhDmESUMk6cbT5ze/P6JVZKVe7S868aP/y8Q/m9Cf9s90K16AVq02PJt99u28XoTC3j43q1bFdP6bj1L6z18v7aljbfao/XhLDWAlrUU3uBSqBSGn4gGJEqTN6WpjWusFDtArXPFn3G6It6R+mPClMJZ+SuoJf2BCjbvVDHdvRWzA1F+QfAl7c6/0hMtI8V88qSKUVoLa4SrhhnUl4ZVTXcoXkuGwBzwGVhzFcvyFu7MOtfGY21VS6Bawjxi4/pVLWF1CzVoiLAWOfRkqfN83EGnXvD8ez/8LSOqIpNJFnqQ6xc3P8sRjqdCdqNMoFTCaLTm0ki11tvm/C0pvvNYmBZIVrLNp+uGFmQKn65DWi6rJmomgbmyrqpgLr1lvCUrSeVjOUqGheWcOPLwIZ91C9yyumWe9DFWYhg/4lg2bpWOTlSW0YhnsH5kIlWr3Qqv2tSQxW6HqetzhaUpmLz4Ucb2y9Jgx34yvRLVwnVrq1pyME9sRXRjb9XzTbiCeABb3n9gWTDX5Zskb7rmt557tyN3+XFppXd2dosWC++xCL9+0a1T921nmbceCyyw6NeiL3xnl7fiMVbGy8EqNgEvG9qQlW76wVAquiwnugFzj3KnUOBciXMoXltfZArKu7sugMtQuFp4qW9HMLbedZl2XUZalL1qwYFs/+Bb8IgWv2UVD4QvWtOFMNux1mu6XM8jzKbZcaosFH1MwFZgXqRaFJhzuA37kjvmTgycKVjeIDSuo1mCdd7AYc11oL7Wr25p+vBqufZfP+PeX/fV1qflxspSFjoA/OBFl75tgcXP+1BACo8hJEYjvsVuw/j0MFFKABo2oSofc5bj00tWOhfbLh9ymS5jZ/mXBXOvdQctraCfzFFtldYmOWvheNjhSdI8His+XgaT7x4QHfeUY0zkJSt/KB/pogtUst7L9UlZPFYMpXvBM6JDLWOtm/FjfJsnrmvEObUv5hZ2cC1ghBFe4grnzQOY9wMAe5EocuUM7JOb5M05mDvCTddv3Pys7YB5rTyjxHvv3n3TH33CA18N9DfaBysdnQXuOw594dveYu/49IXv3hxd9G+cttFKB6by6VmDjKFSGH4yhU8vuw5LbRIoi58BLr8odQAdp9a10xGJ5PqG41CYUrjklAccqs+xKx9ytWImlhOzd9hAMZRQjSPPYh2wugct2BLNWLKmK2G2Y60Xda18FOKkQllVKuJsu7x50IkAHo3VBOuB924Y1dJgDc6hwpunFS+Biga6lnN8sf7sFx99xE9VizpClrbQAYCI2hvWb3gGWtwIXti+8N1bUL1lzvb8XUMTN6VJ20mmVS9DfHpMv/8jmahhS30Knx5cp458y4G5MIPGgblhFUaLil+reGsWmAgjs5SV0Q7HyiJ/7AHBo2iJyjiTPSm5dlYJ7BhY9FI+fPrt96dQnuno/rXRqFhFGXlaPF6uPGaFy2iuPJzE+lX51vpe6ov4lW6tzYq8F/pLfZy0qRbtyIFae48B85ycSWBOQFrV4rxgIprwESBQBuZhAPMANtv2Z1cB5sV6mCqvue43n37vtbu/Ozw2aT699f1eL4pPX8SVMB5bWMAj8OlA67ueFKz0Zfl0odPrQenINlNtQQO+vU6pES+rxxIWOR6IU8cLdPhEVX0ZcQmcMjeVr1LYWhwyruGIxtyLnZZiB1JWRK2jTVvhMpErjycjuXJ2Ms1aJxHefBIw4qXwcEO5ntN6dm7F1c7y5smyjhY6OHjnvHlassj2OydeB/4Tz7z31z9ou1RLkG1Z6EFeesGj37NFW+/q7gufDeY7L6b9C9K+L90EQjfKdUXk+xqkakR3Xnh8six1m0ODbgeGbG+MWzmYC2sI4sK0nPi10mX9JrPwkr4X+jovy3LrPHzJsswtbxmfPmoS6mPbx5h0rLzFiy4iOdk/rl54NDy+GtdeDIs8nN0GUgbHWOvcUqpa4CpeESflemToJSn0bSUlMC/JMG9OiTdHmi8MX2rLeXO+PFF+X7Qv1PXHNzaetiow52Veibzrxj/4I5D7OsD3N6Dj0rvV6N3OjJxP32K8+mIkn853ZeQgEBrCKvl0ytwsPeYuOkcZeFHT61HX1utaf9aZK3Hq/Oa6uaIFFlpiuCyu4bBSN0fNIRCNOmMUd0GG+HHA6GjMFC0CUsFjyPIOYXn7HbT0lVVdtdYnWOBmvCP0XEGPeATQcefW+RTenO+nwhdjBAJY8ubspSGXdlRsCrx5E+PoUvAAbt68/akvufCy/4oVykos9CDXHjn1VAe6mnNPaU+DwKc7MesbRzXFp6fC660Bcj69ZKUHP/kbPYS78OuvfKGrWa4rAfM+8rKeAea+pMssrqKuVLT0ixZ5b65Fw1HrVCxGbYV72PHofAhLdgDMdZzjDz+Yn1H5G8gPr6SplruOo2Sxt74UBoAOo9IR+oBMo5Anrktct6IHQ48qet7b/bUG5hB6Zaol/Oq3QTnhknjzHuwdZxzYRyuQePMYBwPzU4uNn1w1mLPir05ee/1Hvv1ezTnvIxAsPr2zxH33Nqmy1AOfvmAWfbc2HZATT9P4dFg6vV7ur6XcpT3/1Y2v0pB3Rk8qWR080zXiteIeE79OQ4bLE6oB5ZhVLrZKJXPblQpnN6YTjeLJ40XZcl+GK9fWr0omD1O11kfobtNSd0W95MNXv5TSKRlzAdCFRR5+lSHa29Vxx0SxEaHBm/N9zvnW4dwQhccfftd5X/+N2AFZqYUOAC85+qj3b7Rbb/OQFRn4dMceV9IjjOTTwz7pafKBj5FdjFPWp3MR7iTdlVOuZPgULQmmtwxI+5F6KT4f9YSuYXlxRRP4M0stmIp5/FYaMv952NJgMNa6tVe4yDKt+kgXebpjrPpO1WflIx0upIEluXLLYi+E4QEzazlrAxVdK16tOaA3HB8ZtaGE8tN8Li1Z5+E6nivLPBAxjhL+JOySvDkH+Jw3T3lwhKuuOXnb0+oFWV5WbqEHeeexP/xdAn0TsDyf3ln1/ZeOPDBmfTq30gHZqLbDp1sS+54OqzuPaK8xQKWBy4uSXi2+PN1ynGaelWIJpDI3I4FSNxzm1wuZrcS5F2J2ImkClzuaYT1n+iXLG8tZ7KNXqwzojrXAheaApW7rkcgHf6OUn4ef5XnzAObB3aHpMzjEmztyOCtseUJNBP8wkRoGpFvbU9/2wvMf8f9hh2TlFnqQY6ePf+caNf88hk8Xb5EqPp1EpUgLnjeBbMQ1G3qvS8oaNxqoHte1lCyM/QDmfKARcfpc18yzUhyyEpOF2Xt47maHHcev53FZceqIVrK6RR21RM38hZswwJPz/JbiDHFZcZTCphN7dUum77m+it/SjTHLclh60HqV+PJCkMgzMb2O1sXSYK55cxJxJN/4kWdw3pzRKkRYi+/RcNRKOOUBnKatN+8kmLOq2Bl57TUffsK9jtztgwQ4zad7+Pi90U2DT1+0/V4wzKIHPBYe8Ahr1PtG5VPjGuLTpRXO4NMAStnu1RUDuyKwGnHWG7S8KMclFUrx1dLVcQ7FW9avh7HC1cKX4hgb517I5FUuzOIoBR1jeVvh62vLp1nrGV1hUBpWvOU465Y6Geny7xzwlS/dwokUWC8J1HRvAnMHwDNTsLZPyzjefK1f1aJ58/Bk0cXpP/bMc7/h4dhh2TELHQBectFlv3Ky3Xijhx4Fg9UdvrXH+fS+QpwaFUmPncvx6XLktlpoySldjQZqU4ekzirBnJlvtYHGirPKwyt9mQ87TEhjmZUuWsasIsnjX/1RTNMD3tPoeYBYoSNWuFhxpBsyzLGLMChZ62JojYFqlr1XAUp6Ik6uZ7TJ1FyDD7GzFA+R5NPDl4mKYG4kIvFge7x5YhXIBnOPz93g179DF3cnZEct9CA/feMffsQTPRIo8+kL31nsi95102+fTwfkfi/BD+DX0j1vVBo0uXsfVjVO3kd2yjK3OrKll+VfOdR0dbyE7k3Tmr4OI9ORnkMgWRPbu5KpqeKReocHM33yLjPUiUoUYOasqcDcyw47xfou6RsWc0l3lAVu6bFIefz2qhZmhnELnCSlyg05+QamZZ1TMQyhzpuH7cD1evO1fkGH5s1DvB7YvG7r1ie84oLLP4RdkB210IPcdnb7FAL+scanE6XvkHZWexNHvlCh8WGIuqwTyny64NbVjQbkzY167CTvHnJs9wXw2NdgrkzBqatjusEx16dKmDi4Mk+dFg87xsKVq2f4AZG3bR0kz9NFnu7QKhcdzCoXr4QpXHlsS962voesde5Z15Xx6nxYcWZ68bpNbcfz8Hb/iTpZet0Jf/4GOxsD5qWn/sCbB3xpXA/ujDdvSDINnAkIWVyn06/fLTAP5d4VueKaD1964ZFzfo3gzu54bx9BgvPp5sqXHeLToXR6FQP0estUNLQ+Bfaig9Rhf1VHseKHbrQjdMy4e6Wxeio7me7y+vUwytvyGlQshd1tyTqRMslLnaxkuWvr2FJbCVde0B/Lqy+jZ1nXwYPXGDG3CLNO5tOJeLhlXAfzLmxvHDL3Qd6cffhe8uZh460+lT7zHu2Hvvvcb3wMdlF2xUIHgCsuuuy3Tiw2X5s6IeetGJ9Oip8Cxbex+Pr00si6nfXp7CL3z9CDIDahyHRK6MdPx4A5TJ1cz0elZcHctuiCaamsyaJ+iN8Ow8NZVSPTzOPhhyVDq1W2c5Qky5eXGSny5EYdworHCF+1vlmataendDLWApeay+gFHQJTVqeWEJHQoRiP6uNWPF72e4s3T/ubV3hz2Lw5weDNyX3mlltveHK9VKuXXbPQg/zUDX/wq865xwHL8elt2O8FBT6dAHibT+cWfPADVOPjV/0J/45pfFiMTuxvUae/FO13jE5SsEBxMC5eyBHxEXidjEvbilslOyKckflCHBX1FQqHwmEZ/RZodLCt7lJcS1vsU6x1S5dkOlMt9YzmpORfjiudh1Ut4i3LPh4BxmJDv/5aWef1fVqm8Obhq0OaN08lIXInrzl962OvuPjRv4Ndll2z0IOcaE8/GfCftjis+KHVjE+fsD7dhzhTw9fWt+bNc349nbTM38NHK6AEnFUdJB0M6iSF1YC5H4zPx6M350aAuaVvhQkDhgwXMi4HglocJetex1s/rH/cn8xwJalZ8lkcvg/A0rTi0gOxFVaH0+kG/dpqFaGrNVV5dDsfii+nN9kTgxmXvapFp9f5Mxuf9z02IOTzZON487CyTvLmbG8Wb/HmfdxEOL514sf2Asy7XOyBXHH8w19/4eKuHybQXcfy6Qvf7Zle49NDDJpPDz4Aa2Rmg/PqVzbWbo92CSgeSUmDq9Rh58jBsqTDnGPaOr9ZXFkHG45rSrrCjz0JaRnDrZfCWuEz/6kBViGGCV3rRLl6B2vaEi5a3oZjMjhWa61zQ6ZkXes8jePUA3SGuEs6yYQvrWqJlrbYEqS32ikBrLbEOZiX9jdPn4lbnjffajf/2/ee/5BvwR7JrlvoAHDFF1328VsX669Ko7Hk0xvBpzux7jPubtaH4Xy6tMfTDYV0ZQ1LNlutyyWO/j7oRg9DN+nsJZhHW24sQFe48rx8yXyzrMWx3Hop7JCl6wskd6a3wiPLYOTIp5QnWZZR3/eKMLhyYGAwnWqtl3U9O6lZ9bK9elNHK/P+krd9Zm0D9qoWqCdqz0FaZT4K482VZR5ZAUbNmPubQ/Lm/PuhGc54/O8HnHffJxm1sGuyJ4AOAC88eukbNmjrF9OQLZcyci4rufVb7roe+MNNIGITGiGOLs5lJ0kByhuthzBDPNMtLWM0J0q1FHS2C+ZcYRj0c3DWYJIASIIyj3cskMMIVwPxseA9SqqIvUSwCsBPKWcV2Et1G4F6eMli8LDBmpQeYj6knvCG1rLSJB2TKL8k4jjwC/pE96ugGROhSLcG/zAwSIIlaLi4x4oTFrfr9zJvxHYk3QaC3fdCJW/exeyB265tb/6eR9G/Oo09lD2hXIJ47927jn38k47o3wG+37/ZY9E3uQV8ermILWXcWtFHpkv0S5Gu8THfLBwH2JwzDA47PVG6LJiP0ZuqO6Q/HM5WGMRcP0JnG2LRH6aOcKCyn/TO9WpUzApoFa27tN6ATvljFbJu+Kv/1M9qEvN3CG7MQqb0lTMgzKmht627NLSxx6mWsL/5WgBz132MYo2aznikJk6C8nk9TbUc27rjB152wSPfij2WPbPQAYCI2qvXjz3LA8fTzUiPNE2sdGaxU/kj0ymO4U28BnIWQ1mWt0m9QNgXyoLp9TQIW+fLgHl2vjowT5ZgSncI+Gv60asazsfBkR9aeexEqRYd76RwKk1tbWbxGuURcVbrAjERK5wOE/Rr90jEjQELfKzeaB2ulX+shXnFay8vo3DrWBClPpz5yLOHV48s3pwQJkETj77GLPZIuxSWKAKELb94334Ac2CPLfQgr7vht773i9xd3p7AKk1shi11wyRp69v4kekttGhbjwW6D097QHwUA/3EaegSwermXcSy0pNe0sm+/tJa4ZOGZXnnk6nsvATUE3RiWiNA2oqrpleLT/gxj1EgpNKwwpXCZ/6DnmOgm6q9YqjDlKx4KigNWd5CZ8Qk6FjLWmZjCUtdVZMZF3GKg+s4oaNf/SenKBJKsYaPLIeUwhJFvnQwGIade/+FoTiJmtabd/Nzab15MBb5EsW0I2wyMkPc/SDwyaff6+u+ZpXfBd2O7KmFHuTF51/6jk1s/VxqJYlP5y8YyY+w9ha8Q6xogvwoRhqT+/PYEACpgfgop/0B9KM+5DUl6z2fxOGWukRDSh4yQgtrJursFJjXLD6pG88y/aUmST24gZuJV4c1YclNaa1vHVmiEyZAY55SkmZeoxJsa3o7k6AiDZStZhh6ZOj5XFl5mBHG62x8ivsodCK4cc9pGN6L+BMzCx7gwsvljvABcANVE0SCOZ8EFU/+IMGbRws+5KOPw5O/6ZpT13/XfgFzYJ9Y6EHedezjnyDga4I1DaSXjgJPvt2PTAN1Pr3rUGxtcuzEnZ7eAsD7NjYouzPl4Cmt/YTAZRD2LM3t6Nj52Z5ecqzpWnFbYUrhMl1DqRBspWJ2mAGeXKnkuhMs9pq1XtPVTwiD1rWKT1rdNFqH+0ZZHgAAIABJREFUMp2UuFPxiO8UUADjnuCIFnb3xzGLm1vx1Ou6PtK0A6JLxh/7prHmzdd6gF/rrXJX5M2BWxbr3/Oio5e+E/tI9oWFHuTY1m3PQEs3hOVE6bGLUuUqPn3sR6aHNvECckDQlrxHsiiidQ6XWZUpdA505nkVzNOZOC8YSysBc2/o+UK+RoJ5HBSX5NY9V1BPAlZcOpKa8V7nxcv5EXVgWPBm2VQdRgNgClcOW996EgIA8ipeS6//M9wOx7TVLqbc4pcWtsiTWj1WfEoOwO37i5COz3t3+jxzH87rTbeo//IQ483ZcsXSq/0A4XS79e79BubAPgP0l13w6L+7vr31pcE6jhwaq1QO4HJfYr7/Qgf6inlL8SkrA+CNBOzZMzSuvomovVt6FVNiCbIeyq2jHF3zjhMAkIXyehDKAXhZMCcDoPWEY4qvoGuCVgHIfR4mD5eDZVbvNZDWugPS4asfBfZZnoz85nFLDw3sOlwJqC0QDvp53CPWoI8B9ZE6kljJz4khe2mflpBS6Luh2QcYj2DNDL+I3n0aCdxT7GK9OfvXsGWLtUnQBu2fPef8hzwT+1D2FaADwMsvePR7Tvmtd4LdnLQ+3cmZaMani49M9zdyiE/nS5k8+LV6/GNnYd4cSD+R99MNWQMxK6e0t4WHvBgN+Mx9STAvgUmevg3ONkdrA3/0UvoZMCJPJ2ZhAmhr4K0dndjkSQDkIYBPBfQxf1lZi8CeBgQR98AgUNMNjrV62haolyPrrwu0lDTCpYe3rHQdoId3RXulvVvUJKiXvDk3BoMhKC3zHiFCHN5fdwP8jn3kebuy7wAdAJ573kO+p6X2j/ioGCgTghMTGo0YY+VnoAJA5+tQuzjFJKmwvntrnYO6arHaApEEpm7ehUfNKhAvB/i52DomzYJafjjYGNko6fJrFm857gRmGV4OALgJ0BF49QhQPngaNtirNA1wl2HycunwOs5QUWPqrqZb0rN0pPJAw8oAu/vRwyCfbrUHBtkfujhI/PZIzq75GfoFCqkfc9IF8NFyT3y6pGvDKpeOdpGsgOzVHjdsrb/opec++DP1ytk72ZeADgDXL259GkBXkwD1roITn17/yHTQG+LTY2OoWGXJku8biFeN18uGlYOebBp5w0/SMsfBDqrPhzqNqTMM5qjo5XkpgNcQkHM3I1zmzo8SaINNcI8+fCyDCfalfBplzMpUAvaBurHqhOtyx+2AOgfXqToZvnsgGjOG8BUtnWYeB8UO1fdOL6mWNAikD11w3rxb5hgmQLs0Xdx0i1nmYeKTLVHMePOtjbe/7MJL31sozr6QfQvoV5z/2H+6ceu2H4ocmgD1rrId+vWl7NFJgDuz2iWoh9lwzaf3DcvHcd3g97htwEPJq5K9rq0RS4mynlICzaFON6aDbw/MszxaFnxJV8WrwaEGjmIgiMBtA/QyUo5LAXwhnZrVrsutw+l8BI+yrq/Guzyoj5kkVUseRd5D38kBOxg/ulCa/kwdSZc++DP+HJ2xBw9QsLbJwfVWe6RUAu1S5M3zTbcA//vPueBh3499LvsW0AHghy+47BfvWGy8ld/KcPMCD0bgfDrjwxyfzQ7LnBSfroEb/HGP/VWWRLIKgtWQnMMAwBt5aos9USPAuwD46jxHuxFAvRKd5FjT8xW9IcvTBHLkYTSIDwK3Z/FNPEqRZmkOgLsHi29kHUynVSjTg6mn4sN4wC7qeGWDi7ZeELWiJfwpLT4gH2auUn8Tfdbz3tqBOKdNAj1L4kUi+TWifNOtUAqCh7/qyo1jTy0XaP/IvgZ0APiBow/7gRaL37H4dLFXMdKvfF13gE/vO4SGc/FYBw746S+ggDtYItai4+Tbn7NJnMlgPSS7C+Zj9KKfoldElgtAHlGRg6auCAuYdRoThKeTAb2lF8uGWK9jgB0x3OpplUG9/o8A74JOSSx6UcdBLB39xBviCHSmcOdUS68R+x/rjx7pTdFomYPRJ3ECtOv5DREaH75jHJ72E/jLOTbvr9s88YOvvugJ/1KshH0k+x7QAeALOPGdjvB5m3rJ+fQ00ZHz6d2NDsNCaghdYwMCRxdh2odG48V1yZoIjVuvfOGevKuFxi/SKMhoIB6DYgYg5jqrAw+v9LRuFchhWPLhYccYCHSxlj2K8VXBPSB6uk8msOuy9hVh1U2my+qkpJc5Zp7WdcGqLrQ3+XTJ81Oyzpm2joP1K25MxV/P3Ejr9/6U7Hi+Br0D7N46D1tzO4qmHufNJZgTbqPNN11x4WUfLBRo38mBAPRXn3v51df4W57vyS84qPPJi6YfeZ2aJNV8epgkJQrDQqJlAl3GH7qExR7eJzZ984lO8/VAFo6LD64VsM48kYOF/JvHoYG1GM9ELnZZ0LcBK+hXKBkDxDNQriK2isg4LK8sPQPc02UF2I2y1+pJpxv+jL0/mXtNx4pHpWUPDAOATXKCNM1GMSPKezBbSOh2q1W81EfXfz0lcA/0anxKD9w4pc/JOTSDvLkn/z9+8N4PfSEOkBwIQAeAV5z7mF8/sTj1hg74KN70xKenx6nEp/dA3vPpfL8X+SDXNxafoLwDVwnt8e00SuDb/aSVL+VGb4CxoUyZS/3cSqPeOccA9TQwR03PJ71RIDUE5Do9dlhoXv7H1SsaCtVLVI4Ad5U3Dey1+vLB0bqPVt2OAfVV6DDA1uaIbJuagOwkUZYpDu+T8RQnUGPwYJXL+QExC+b5lroucu0IONDz5mu9IbfmA7Czl4sMy7zvy5+97rYT34kDJgcG0AHgBec/4qVt6z+SGkp66YgigBOafhFS9wJS/+vSxvTppgJpllw90inIj6N3n7InSb2kHPX+4ZrkxkE+0+QAqdr0ZLAeIWMAf0w6GswNMLOoAUtP6+q0S5SMtMA1NE+ok4JYgB8rpwbuA8BuDm7mfTCsaxNoB+7XGOA3dDIZaheFjbficl4VeTZz1VPjfLvb0B8itdKnJme00vrxJnLo6cVDYpSr61/1b8jizTtp4TevPn3bc694wGXX1apjP8qBAnQAWD99/ZPh8Q8cePkkafx8lJMfmU5cGR+Vw9pUPivexQlC3BAo2BXaSug12bVg35MOc5CAX6JkpIwDphFAbHGqyyRmxJMDj8/dDWBOYGyMXyoZL8J0J1UAD6C75FEqpwnuRvo2UKeKyAapgm4N1FNCRkaN6yHALkWb2n4J9KWBog0bnVBmCFHqPWJNuQ9UC0+p63WO9VHqjbTwBB62CQm8eXiKD/RrHASYVR/w5I7F+uteeZ9Hf9jM+j6XAwfoP3DJE2/+l43j3wf4U9YkacMOi0+Pb5X6wKf3HLoPfHrfQFILRqBXBJ/em+ip44H5ImvJwdqA0o92u+rgKT2Y/lMmQn32txTH7ujIPBescqVrA7kSDcraf6J4kAL4vAxDwG4BdawdI48r48ELOoNpoWzJZxFHf0aLeIiWztnu5M8MH7bVLW/HYVBIXy4KAB/msxD7IefN08ZaaW+nBg5rTvp1fd2lp/H+t8Xi119w9NIfwQGVAwfoAPCaix/7sVvb7iPTAdT5Y5nm0/me6q7/RlXg08OXwnmjSTElCdddw0tWQTdJI612aaHUYcX3sS8rY8A684TVmXcbzBMcco/yJClgAvkAgHvr0MDvbT0zLgPcRwG7ESZkfilQX1ZnImDbXuUVLXxCM98PSQuJp1fwfiUyIp+BU990SHu2qI/LI02IEkF88Dna56HPU8AR/382af0p5RrY/3IgAR0AXnj+pa/ZbBe/whtWiU8PPBn/NiDFETxNkiCO3JKzS+vKE6hDuMhz/aJD6ODDSxl7lwyxZNlXAdaZrATw86jKYJ7r+UwvnWggL4G4Bm4TzS34NlBdO2XpmANQDuw6jChjXxhzAMj0RuisHLDHtzdBLfbnlIWnjEvv4mN2u+cUStJ3kC/4Nz0YhxcLeZg1amJfb+Jy5YAOTnwAAwB8i5NfaG//3ufc+1G3lWto/8uBBXQAOHYenkRYfErz6eFFgcink+TT4wRJAG0fxvuOT4fvl0Khb2Ze8umhAWrhljqf0BE6+i05EVqKZz66D+hYhsC6DgSrAPzubFkwz/VCfDaQa/0cqz0LX1rdoo/6Kpdpk6AJ0ceBdb1eSvdpOvWGmDs7DirGIdtht7bLSiNNXerwcq4JgjeXfSe8fxTSFLx5sOEp7aroer8GDo1XtItPn5ELlKpjeSRPuKW948deed6jf98u+cGRAw3oV9CDT/3LyZufTcDtJT497PfC901vervdeumos8gTt97F2P+yR8jsEZA/aiboz4Q3cmtIqIIqC28Bi61b1hpt+VmTlllkFioPx1OkWBToBEDVcXp1MrjKpYboRdXtTIKmyh0L6lkmskQGZIh6MfKTJzi84qWeB9m+g3rqSxLM+RW37gEG2hHM02o1/hKh3pclGnJx24/egmdGFYGw6bc++KILHvnagRIdCDnQgA4Ar77vEz5+fHHyRwOQpiWHgUdnvBp79Er7H1OcFZegzq0GyadL6oXRMR2lLjWNN0lFg1Jgqndl1GCbo1wZKHJ9Cw9GAL4+HwH42fko/j2daD0dnwfQf0kcHHJ1AcZw5fFQutagtMwkqNYvlr93zOtuQMeKZ0iGJkjZNalrH137M061iCfTFIivJjEfOfvraJn71POCRc1dqLfI9ZYfa8SezHugX4uToY4NJH0vbuhvzrry7k8aUWMHQg48oAPAi45e+uaNrc0P8DbCP4rBPzIdJkXCNwPD6O0QQJ1t0kMEFxoab05x0EBcVhXti8zyCOGVkNWqk7b20eFHGEjqb1mxPiDYHV/nfqpFWNZhYOXz/Ajgp+mTpFOEgzwzXMcBO3NI+klX6PGy9Y7VwdE6N+7bGNCv11G5fVoa1pOpB+8J+XyTDMesdK5PqfcF3rwhDuzdqrUwN9btqMjWoRMHc5Z372+7cv26Zz/rq75qs1oNB0gOBaADwPcd/aYnk2//l6ReOkn7vaSljKEhrHnqN+/p2TXxtmjfeFRD69z5K8idhMatQV3b94h6sgPI7pNzmZOt74r/ENQPdXoOPtU0+j9jwZx7mJZvjE8CfwTyQl45OFcPpp/F4XV+bWC3yibKNwrUhwbAMfdu3BorKw0gf9rs/Flb9mD0CJntj0OzBwSoCt6cmc7B1/X66fsF3Ul4Sb9B4M279074fFncdRV8XxfZt49j/eWvvvhb/rRaRQdMDg2gE1F7zeaxZ3qP4yU+PWx0Hzbm6RpEE3dkI+oe2fiObdQvb+LLo+Jv1jiBHJ6ZfmZKKi3tr5zksDAEyRj2HxwQhsB6TB7GWop1MDcteKabgT8SSEsFXznkZXESVGU+AXs976jpZfVi1Kpxf0pxWPpTJlBtkZY55Y1WtP5+6rJo3HS0ik/0pueEijKgEObEHBoK3xYOHLmLfpFeQaJV+VYfIZcnNzd+4aXnP/InptbAfpdDA+gAcMVF3/zJG3H7S0Mz5yCbOPW+UbAXDeLLSMTBn789mh7XiMUr+ULK3jqLVgnLo374tLba9VxbW03C3+6RQzDrB7QyQKrIJCuymNh4MBd6hq4F4MusckmoPiItltJQGcoVYTiPpF6Gopoy4MLnhkPqTSXJqRbu46OBZSnI+ShuiXPGPCwrDjulBprFUdjeo0kvDoYnceITojwN/8nnX/jQ76wU6MDKoQJ0APjh8y5756l24+diiwChARJQI43mYpN78DfJEPl0Dt4Zw9ejtX6U42eCb1dNXoM6wegUvR/vdMkw4nygClexzsb400jr3IpvDAh59ocbz2WdOuhLcJXQLBXT4X3ulqu2yaMA7Dmo+4GBCWWdgfNB0Df8K5fTRgYWPlIt6p2LNMcieXBBr0D2mRSid6c0CRr/9dQKt775GvOwx3l8KxzhXRNl2LX+2NWnb38GEbU4hHLoAB0Annv+w57W0uITmk/nW+jGvZH7ZYzE3y6DXBFDrPm5CNA59VIxQjAE6ryjGU+y2TUZKlq24+8H/HX4THcZbl2fe8O9CqgVbj0Z26JsGaZroEfYx4eFKg0oohxjANvQGQLkwrklU/11+/UFH75E15KsjfeWT2jXsa+Q6EVIT7xykCCCeGJuiFnhcP0Ch/SyYLc0MVE48V57j+v9yZe+6j6X/025Vg62HEpAB4DrN9afDu+u56AOQI7uYfIkcOt8eRPYpl5A/9vv98Je948NkSxLOzVtDzBXZL1BUi8+Lt8CC8f9LdfkU+7Kq/Evy7KAM2aitLjiBQHKk0eJ/+ZhR/lLHEeJVjHLYOhJnTx12Qrsc2uwr9f1tMnRWni9RLH7tcvh2dJf/twawBxA/JpRNJj6swDfae4LccVaAPUGeh06JVDv+3nMCwjrfvNnXnHBo35moLAHWg4toF9x4aM+ff3WrS/xSKtRJAgjLWUkuV6dEJZF9bQL8c1z+cMgenfDqpA2vNANrl67FYnGJENWlaW0ajpm+DF+nHVeSi85l3X0iheuZxWHW9+aarFWuejwMokQsF53RfCPF5Ti4XmdYKVbLtPptZp/Po/TuSqqhblzwNZZ4Ja5NnrS6/isp0baJLze7+KW2C5Ohqbr9G0EqNjbP3nB0Yd9V16SwyWHFtAB4OUXXvZzp9rNd3gg0SIU+HS+kU9HscS9XsJ69dhwJJ8OgO3brB8Pe7c+UQHqxN2kRDf+0hGZGrkMGVhLyNTH9e34Z+cG4Nv6tlXO9YYnSdV7pX5EXPGH/9X5t0pXKG9FdtrfblUF14jess2naxJpWta5TKHMmzsQyCXePFCk/A3vuNkW+wSlE08F8fzaG+jk0waq4lDIoQZ0AHju+Q/9Pt/6j/Mm1FnC+vXh8OZok754FJdABc6OZKOj1HDgGXyThnL05+lPjU8nBerJYiqTl2X+05ZlxgAzjGl9D/nbljf3GgP4AsyVzqhJUh3GAPcaZx/hfFAnz2N2UfUfCl90qkp5HiZBcjwbeHiUhk2darHAXNCRAMjJt0D5vFd4IzSBeRgE5CDi0b1MfK2/44euOO+yfxhZLQdaDj2gA8AX/M1PI/gv8EZHlF71X4NLAE79W6RhCWOYHA2Pcr0lAc9BXfLpWpQ9oyZJnehUgV+37fgUj9URyz5gPhP9t/v4X0yt5j8B8CtgCnh4L4E/grQ6ciNdAXshjSJgi/s3VEu5TK7XwSWicjDLW5ce7HR79b2rplok9QjK+0FczktSt6NUEME4vjMSlh+i6x98EtT1/g2afulxesM7WvYhBQJObJ3+iVcefdT7s+IeUjkjAP3Hjj7us9dt3vqCFm283XzyhYBogXNOLoD5Wr/mNQB831bAH+x4B+HUTtIKZxCaskvYIq0jj9IjcdlnggzhApNSWqukCYYAvwrmQKKpvcBsM0Zt2SdgB9DW8pU/VniG8F6plUuznP+oMMyBTAXuW6f9NHHSnXkB2MHXs4sYc9+XAmeeZqgobp7VubtId4btOwIt6iLoU78CRlKdIKD17e+96KJHPLdU0sMoZwSgA8CPXPiYD57cPPUW7pZoFL4O3XVvj/INfhDWpnePoOnjsp1Qb/LnfHoJ1Cl2FE3XdAAfwLnUseqS4X9FKm+Ql8OMizoPIxG3YH1Ps87NjKFMxwQ1fdh5ZS4WP5Hj+LTnH32h8zqygqfch9TK6pF4L9ucbts8vq75k9AVVAuBheXzSWk1S4gjfpzGKwAH+3AFnOLTE90SRglq3ZVfWNzx1AlVcyjkjAF0AHjBRZe+YLNdfEzYEdEikHx6fKyLlgDn8yD3U4fk7wR8C36QkL56rhu6FN4hgpQf6csy1HFHhRmbThFgl0tnsnWuzw2qxHyZiFnwIg4B2DkgD5Agq7e8jcFpZLCRYrepZPlmrt3ZIJjnvDnXJR8s80C/9IaWS++GNHBY6wG8cQ1b1ZLmtWIJPPw17bHnv/6iy68cXfRDImcUoAPAP63f/B1o6HOJegmWQXjJqF+b7tNyRr6/8hoD9filowDq4s1S1nBJNnrx+Cv49JyQAZDexsv6m3w81nHvtawUfEZa5+Nevy+vcKmDei3degF2BIiXiHTsg571RGhTLdy/DObaPRhB3bYA/MW//tclC7yJRlTTL1mE2Hwr5qPP9O1bp974Yxc9/ldHFvVQyRkH6D9+/ydc+y/rx5/v4RehmXWTKuGlo/QCQ1y6SBQbEDHLvOkf7/KVL0BuqyO6WpSKDKVEPlAYkjtum0tXYmLHTg4eE+IeZQkzwLcpGBvUt5m1HaFNthNP2d+m93KqRZ4NvTvBjRtJtXS+jsLLev0vHJzjL/+Fp2X2kXdiM1d9/wv8/WLR/taLL770RQPVcGjljAN0AHjtxY/9jdsXm+oLJb2FzUZ+F2iXuALGgdMyoQFq6kSuhQU4R6gtcYt6kf6G20hQ34+yWw8Qg3SNT0ct1Mot621VwO4+fpXAvKc1RlEtMp5gQKXeEUCeAPA3PlMfbNiXxhio92k4RAsKHv6z19KxA/2R5+3KGQnoAPDCCx728i2/9Zu8kVJvMfAVLw26iZnwhlp4EYl6t4aAtCmA5s5lp+CPhZnVLrhGG9S5TJkknWVVshOAmse5U7e2HO+QsZBrbodqSX2N+k230hueYb152J8lfAC6obC1nty2K4j3i42rN04857UXPvHGUZVxSOWMBXQAuPrI+lO8xz/wxhc59WCR9+dr7HGvYROnFPl04003YXnn/LruOxrUAdnddSO2OfXS1f6Q3cqTnY6sO04BlEItU6NVrYF7BoyjRaZKKWSpPVnWOQdzcqlVl0E7uEnenLsFgA6TnGsItCb70hhR/E19S/aT44v1V7/2kss/snQFHRI5owH9dfd89PEvrN/yfWj9qewNtt5y4I95idNLQC/WrLMGykGdUy/dD2vYSA2/94p8oOwsSXhTdiMtqu3KrrM8E+IeUmVP/3K4NAAMNDK+VWVumTgnyhgwz93tZ8SuedrzQzxOUufowRw9YHfGE/sYRXhJiLqPVDRh3irjzdlg3Ke5icWv/cjFj37lyOo41HJGAzoAvOZ+j/3Yzf72V6Z9nMMn6yiuTklWAp8sZY0uNrScT+fDBLfQ9Rt1ugslasamXoL7mAf2vbLUl0m3GEbVq4EkmT9pbwbq+t9wmPHpVrI/SQbDGAqF7Bl66tlDDXh667jYdo12Ga55208GSnfV9D6u/xpY+DB7+IJY2jmRxN4sa1DGE4k7hhb06Q13pzOaN+dyxgM6ALzsgstfe8pv/jf+zibfgjN+q5DSpl5rCN8mDVt69q8qk+TTg0UBhEbuooVRAnXLKk/+uQjaYAXm5dLgMzHgclktDXCGqwHQxEdVdpChKzMwNFBa/vUSTq7nEU8PY9IpgXkpZKgLvaKFGy1xgpLFT9zYif0J/dNvd9W4tDQxvDAUtt7o5qrCZnk5mHvvT/7zqeu/70Xnfd3t02vlcMoM6L3cdsdVT4Zv/47voMhfMQ7gHjYGCn7hXOw/4eQmXo2yXhAbeS7CZjRWxQCyI0W3AvjoJ4YsvSUQYnQQUqcaJc3TIRgfYy2XQT2o6SOLRkRhW/BWVqWTL/qYIUfEP0VK7Uv4MetBGBaUeYs4NJjreDnH7bgbhY88pzko/n1QviVuMKDSskSZxs3t+hVvuf+3/v6kSjnkMgN6L1c84Kmnrjp1w3cD/nZtNScLvbMc1uKEDZs4jZ+x6wHc2ZOkFp/OO0SQCDTZI67WG4JCI84hpfLlKFnO8k4eHGxsgLPLzIFY8LvMAq/lLQIZy0eVjonnhVFzZHmWrq+C/+j7bAxavGYdVzXndXIw79ySbhPdGoTNtoLVHcE7LDJw1L8Nyuen+j6o8nfKt7/0iosve+NQMc80mQGdyWvv961/clN7xys4exit9b7hhg9edI+Gel8J/ojp0H8XQ3SA8CssRE29KIC3Oqd14/jaXyuUHhpK/oajTqSStyH/evSDrgMgScpTW+sR3I0jB7gKmI/JR6U80+tlXIzx7hv3LauLeCqGrujpkdpn+Z7wNq2APfiHRQD97xoIzoUX+vq+45poIDXRYEr9jefAA3/zlRe4J5sZOsNlBnQlL7/gsreu+833A6lRRj6d0Sv8rbXYACnx6eGTWZpPdxEIiP0Fanw6OYrfR0T0TY/zAkhWZPWNDqMxomClSv8SsKTrYaCkqo60tCX3WhJ5p5DAX6cv8pgPg2PKkV1U/YfCG/6GUHZiwThvfwHMk250B7GnHgbmxC10AH1fCby5o/AmaNqfJUx+8j6lwTzmzOHWazZvetaD6cFbA8U9I2UGdENecPRhTwL8X4WeGRot3xCoe9Eo0Sz8m4ZxfToQX2Pmk6wBbJJtI0GdS+wqjls8QHrfru9EvGNaPTeLty676V+y/UoKvHxFwEQO7BzarX8chTWQd7uOCBV9UchvXrrhsi/nb+kmMLTyYRN50Y1IhBftlJjxEYCdggEkgV7w5khg3lB4kc/lc1F8mWL/2wK4buO2H37tJd/85wPVcsbKDOgFuXL9xmeB6ObuKjXmsJ/LWt8Y1yif0AlcewRyl0A3gjp4h5Idi1vpQkjATnKOvxbAULY6Qavlj+dZslWFOmTJ8CT/CJDU1/Ygpa8VqFeAXVAr6hD0ixmeIOuNgX+trIZOdqHjgJah+i6HJ33/CdW6DNeyTBLMA/0Y4g+BeJumvp/E74GC4lNsty1u9/ZnmJMi0W8CHSMNlXW/8fOvvuSxbzeKP0svM6AX5HX3e+Jf3bB528t4Jw5AnF5CRseng/PpiQsMhIvr+fSEHwT+9pzoGgz4hT5SPizID2eR4imYdla4HAzKdqEGYK0uAbkuhEQc2aBfBst43SuLrl8AZh6/Pop6TCHciwjCg2BeB+ti/eiyVweEBLjliEPbylyK7UGuN7fpKt5Gw4ty4Tfw5nG9eaQp+QfZ2ZpzuOjuiAByIlUP/xcvuugR32lkYxYmM6BX5IqLLn/nHVsb7+a9IVjYoYGmFyMa0WDMaUjTAAAgAElEQVQdERrn+q290sZDoQvET271oJ4+ZQdkj7RgoE45uJfE1Xv5KMAd6z9oVZqATcU4ijoazETAArCzui1ViQB4kkCecpGQNhvTxoI5DegYYFy6qg1GQFoZkseYtxxhNJD0F+2ShQ9rygP4Rj8KNGQA9Cbx4v22uF3fSKvFxOv9mjcHjn3+5G3PqBR1ll5mQB+QF1708Ge2Lf4s9PQEruGRkk+OUuTVI91CiJZ6mDBqGKgDYOAtH2258MnOZN1HX3FNBuJkXVj5Z1sIFNKPQQs0TvLPk7GxqpynGqhnwCbQTQF7VEIO8hy8MxBXMVElbVGEHKjz8pXukTrXasZ9sAaEjH4j6Z/Cy0ilv+LN0QF09OsL75he9yQaDBTH+gb7ngC5aADF1WHigzEp/x4e16zf+pK3fsl//FvMMigzoI+Qz5667ukArg8NODRevmezY/xgQ2mXuLPYV1WiRS4s9b6DxI5rAT1EIw+gHs7BzhIuuRiHVBTd1JQqCE/RHQJ9lqNqkAjqMoJsDArhSYbJKSwjXDy0Nkwgl3nj5bDBXAOliMO8QFYZy90XMtNOTnxyXQE2oFatSD9WYlZ3rm95YYvbsFspxfmlNUqTn+E6DBZygt9j3W+983Vf/B/fPVDcWXqZAX2E/Pj9v+3/XLe4/YV87+xAvYSVL+ExMr3pxtbSOvaxDLgI1GFdbuwupLuMnoDiYGABVN7NtQWpPS3rrhTdZCud5bMcR55UjVYZw5VzgIoXXvgUYJ5EBFSLP1Nn4K/1rXqp1D1lf3XgFMiKI7POe+Ev5+g0pPGQ7OOUtPRLFKGLbThMgnZ9AGxzrR7UKa0AW4PDmks0pOsrO6Xj0QJ//KKLHv49mGW0zIA+Ul514eXvPdGeekcAstCJE6ijX1MbZu/Vq8wB1BG+Zp4ApbsJPgfvHsnSACDBgxyHd96h+1+GEpFaSC7IerzyNUHF0NwOYBP7o3XEtciyYa2TXaII1Y4B9NBRi4cXJr4bkALpPI/i1pcCfFtkzUjr3CoUB3OdBvWVFpzjh1uiPrPcidBQ+PJX/81dl/qAI8JZ/ctD8cPPxNedOzHggOjaKxe3PL1S1FkMmQF9grz4wku/r/XtH3BQD52Cc4WOKIE7iFnqFJtt2G6XKK3P7aONnYRbUiVjOFvh0F85oRV0tZYEbA1ARhTjAFufZ/RQAawtoFZ6Ms1cvwbuUyWCOEdzVt44YBrpCeCHBP5qPQACREs6+r5zC1tkvhfLOtd8dXJlIM38U/tIYV0sP/XzMOkFOz6nlE1+ui6GMN/Ey9J6j+s3T/zQW+7z+H/ALJNkBvSJcvXp408nR1clMOcvDgUwT8sWnWvSZkOgCPrR0qHEYobPaTHCJXUaqI7Fuib/ODWiRn+mOr7Td7zIx9igr4OQdtDKKhAxnRIAWrSKjl5SHhm0S3BXIF89mL4GRWJpRXBW5YhFJRlmuMyynrICZwnk+ZKqipwj6RfTZb8JpLk+g/8+w7w9Uk+hdNvjMpoRwT3/Nuia68G97y/yJnvc0a6/7dWXXP7+vCJmGZIZ0CfK6+73hM9duXXTC7xPn3kOEzn8qyppP2e2NQACzx4AvokTUbwzCT6TWLckPmmlAKH/5atV4gcFFCJIakYCATH/6F4BfR5pFfSZYwmsY3ko5FvGVwX2GMYAdxFg4DCDSBAvArlZbhZG6ZbAvFqP2eDN20gKxPl0ntdQM4Em1Nx4BH9iE/YgOJZXYmHTG9GBTkT8hCPnzRvXiF0Vw2Qrr13Ao4X/vZfd57LnYZalZAb0JeR1Fz7+l2/3G28MnTKAerLSES2SwB/K3eV66x3hlWjExs1XuPDH5PS1F9kpqQzb4pSvSS4BNgf1LCYNSBZg6/MxoG7oJbDLwbkIpCEeE9wFJA8cRojo6U3cF2mzeELYHICl7th6EfVT0ikMTKFGujAEL67zdHiYNFCpzecovDzEeHP1tvRZ4SPPoPj5RgKiUcPBHB5X/vPJm55q536WMTID+pLykgsf8cJNv/gYgB4w02/DQLybJA1vkrLXmyOf3lvtSCDQEO9o4bE2WXzOccsqWWhxLw3WK1O86TfFHa+ynpx/2m4E4IwEpSG9FF86ybJLeRgeJOO9y47pMHgZ6SQTFNSMKGMKlAHkEvURwbzCm/O4EvhL65zH60T8Nes80HQMzCml3b08lHjztb49hyfUjnZMfUHuh5Tusye0/7w49ry3fckTr8QsS8sM6NuQq9dveooHfS5cB3tDvmzUxP3UHYVvHKkNvQBFvaQOFcEdEtRTmvKvXJ8uAZyDEgfE7iefRpWdHuOAZ7QFbuuJ66iLHqhyKiWBSy4lTC8ehr4ZpzGYJEAkjudZOH4dCtDpsiWC7L4UwTykx+NyZTAnps2pljT/QgKoeRzBJRyO7SgaJkF5u+82rEu8+RrYDovkWPohdx63bpx+/VsveeJ/N6p8lgkyA/o25I0PeOJ1/7J+63MWDluxEytQ7tbgNv1LRuGLR2mnuTT77+Kr0qkzxi4IUNpLBkDRSgfCCxrhStrnJhBE1RzUc50c5jL90RY4z03ysMEynEhCRIerAbwpA4p6EOD6EQgrQM6KqZKkCObC1ciPBeZZIo7HJOs/hibdrhSYAwimRKJakk7Y0zzunUiuW6oIiG0w0vd2m+48vObP0wu5II/TWHzkFfd95Evzks8yVWZA36a86f6P/fDxU3e8BuBWYFpjy/eoEGtu2WvQaUPesJSRUgdSFhW3tELnzDoJgiUFdgUBAunxWnkpRJFWXnLMwFReFkHdBCZBKTHdKrCHUuRhY55KB4ui22e+rKsjloNiiqwE5MWnE2PQGUOzxLJx0GYfUklPYB4Q191RmkvhaYU6DUYDB3PqXxrqjI9AL7L9Wch1vDlb2RK+PBQmS+PzJ3m0RP90/TmnvkMXcZblZAb0FcgVlzz6Fafbrd8AOKj3oMrAvCGK1nlY2hg3Meo7TsMsJBCfJCXBpUfriYG66OgKUGNX1aCagTplgG2DugKkkaDOBxFeX9xaHwvspE74oJaBoBkBz8CQKos5APJUIGd1q+tqLJhnev0fCeY8vyltDuYZ1YIQD7H89MAe89iDOyE9XVL6SEUC97QFhuTNZVv1rd/4/Inj3//mu19+zK79WabKDOgrkr8/efwpHvhMuO4afrBu0iTRGm/4lJZ3Bf/QmcIqgNAReacXmyGxThqt7v46UC8ZqKuwJqgDLGYL1GVazIlfxsgtoEammzzGADvXS+CeLrJ/Xg2I5iH/aeQugXgpjxzIs/ri+Vb6Jmce71ECxdrgG+MjgpgoN8Ccf+YtPCV27axb2eNcB+2BN09rurq/YffR8E3QNfZlogjmorAeNy5OvOonvvTxv2VU5SxLitUuZ1lSfuALv/yQ+6+d+5sOuJNHtxOG9x4L7+HhsekXaL3HFhbY8h5b7QJbvsXCL7AJj9Z37q1vsYUW3qML61u0AFp4eN8f4bpPw/tuZ7p4Lc7R+3fi4QHv0bJr3zn118GjlddZPP1fL3WCHoRechS6VlgjEq2j07BkwHuUDHUQMpTkIJcPjlY4Yvq1wa8E5tLS5nokqBYB4ujpPEoDWLoOsN1fU9NTLf3Lc5Q+HbfmHNZ6muUsarrPyTWdX/iYBcVBigDyOLXY+tUX3efhTxio3lkmymyhr1Decp9v+d2b25M/CnBjMVnqaTkjW+VCDtQ/tlK/CiZY9cFSR+hYCJ2rTL0AUOcGB9tnMAMDYaXDBKNRljpkXBGgRlAw0PoFi517a6tUx7Odw4yTpatBWdSdAc6xGgpg7pR+EcyR7qsF5iFwDcxDPvjzSAidqJdElwTePHytK70FyuhEUL9MMfHmAczRg7lH++kb1657ilG9s/z/7X15lCVXfd73u/V6hpEIIBSEpJHESA6JnZOT43PwRuwDGASSxSIYsQRjFgk4HPsQAgYUoYAMNggZCZBYbGyWGBsDYRFLABmBwCDi9STEcQxmERqQxGxoVs3S3a/uzR/3/pZ7q+q91z3TM90z9+tT3a+qbi2v+r2vvvru7/e7R4iq0FcAb91668fW09wzgKgSPSvqpLxb7zFGizYEjIPH2KflwWOMgDYpd4+ANngEAK2Petwn7R0C71cVeDYPVfJAVOq+VOmszGUe8F7fhyrwrrLuKnUMtrOYqNZ72ufb5FtMVODl08YyQJ0XE9rwXHlTtGuHlHxaMakqgzMk3VmX3fTMTZ2m++ZstUjtfrEJtZxttAwhHfgjp2Q+Rw0aR5jDSBOJXBpWzvQRIZF6CP7AnYf3XHLTBZd9vfeCVhwRqkJfAczdN36uR/uPgFHQiF+kJsXkjtCIb944zSDlCAJWOJmiggkqy5ZbpUpZe1FtxNEyad58/S0R2FovqsBnUeqY2k6uR9G2035AsZN9o9m59xAoC8IjmPp23D2mbjDkr5fvKWvTd82Qt5+dzG2z6WTuCjLPo6v4CkcyZwNGRh5CSpYzo3XxGAAukTmXAtBPJbBj4b43VDJfOVRCXwG87OGXzP/o8K6XBNA+QL8c9ssQRy7STFIJ80LyK1OH0oitF6cEraTefTzOSJ26pN55NKfZSL07oEaX1EuitjvpVacTLJUhK6WX3AcIvkPyS8Tg/sxxB0k8f3vd91hYMhkZD5B5h+g7106tjVk6QWGXFefC9clH6Sw4bZ9tlZFLcebgZZotKmGK8o8ngAIO+8WPXLvp0uunXfeK5aMS+grhhk3P/Out83uvAZi8+MtjM+Y48Ui9SCKHOVBUOKKYuACSeRw2X8S4+y6pA8he87l01HUPCZekHgwrD5F6tr8eohskuAnEzoctbwi2bS/BC8n3E/0sU3ZwS+J951m+xxmJPGtTbMNVD7l9RvQ9ZM47yPIWin3GZXnykJ6PfobA6flExjdnK0YrJY5SrRbnODzX1GmRJ4qAEPz/+S9nP/45PZes4iiiEvoK4tqHXXrT/vH8nwG2BC7kUVRL6XJFOo1PH8HE8ILk8ZhcfCDm30TdL3feSVZ0jJGl97QeemPIHtOXYL90ygQMtOX2+RnMQOxmdR+5221yki82XMJk1fcsJD74vkyjoffVvQFw+5zM7XFKMid0yTx7qiP9/1urThLYYH1zHrBCQw/ZFpwjYxuazymv107QeDw/Dnt/eHj7S8DZThUrhoGvRsXRxI3bvvr3I+DnAKSOyQAfAjx8ClsMaNPrxeBjp6isa9H6uH4RHghxHz54AAFj07k5rZMUIYY6At1OUukmTb2S3qyxHaXafdoNV+TjoliWDpjP54v7tykaTOsEXTZb0LSdF80nfGuyVabh0I3AriPTOHPAqWzPN19eaPtbJpO5k231CU/CE8Hx5g3mKLbS3IkoPuYcYeQaNGgwl5T6KCvGFft/QNwJGrBjvO+l15731HcPX7WKo4Wq0I8Bthza8+IQcC+A9GWlTPnYMgGcZDQChzI68dPnRJGLrlY/HUad83HMl5r4S53OqfTTZ1XqhjJkf6Vaz+Z5/YDynqRsc9U+2eqQ91tOfW1L9JD5JGHf21bOyyj8gfMdtJ7SymlkHkma15ls4g6Zh14yH/TNE5mzb86Zno0QdxpeEeqbc7o/3xSYzPnCHgwL/62S+bFDVejHCK/94Sdfcsb6B7/HISpsABKWyH/HoYVHwKKPoYyLaOFDVOZt69HCo0VMPPIAvIQyLiHpyIQzdpOOWJ1DlLEqepi/hdoOZjuDaWo9WzZhu962PY2O1fN850szRYnL8oEbl92H3rrS4sz2yju4s5scGSVulTkAOK0LJOuc3ugb8A2ek4eKDGZEVW6TiEZokjLXYRdjh77eVMI4/P3Lz33cL0y4lBVHGVWhHyO88WGX/dEhP/9eQP1m/tJxJ2fpp8+hkQ6optEaGX1+eh56ZlSjKHFV1tJG/vJZsjqHyFslEPu3UNum7ST13VXdsynYcvtsH+W+Qt6us/8ZWb9vH0PHnvTkoA8YOemX+9JlRmWbb6dU2uz9H3NUitleNuwjcz1Wf9EtToLTePMRnIYopqdJIkiCXN4JSgjB7bx7/tAVs13tiqOFqtCPMd6+9ba/miP3SFXG6qdzohH76THpqN9Pb2W7qNStn+69qmtW5d6b5KHYSnxnUerIFTgn/gfjf/cpdX5FiL59vkYbLDfFv2gyiMEms2xcYsAon+ULM+Sx5zc76i4zpG1XdkIXpXVEY3qkte5PvFHYAU6YhKMIUN/dUSxsOyJEYmeLhfLkoRFGGFFee2jIN79nvOuF15/39A/McLkqjiKqQj/GuCPsviIA26wik/h0ysvuNoWf7kx8egOOXtEHbxufDlgfnLL66aLrWVVbxWcYRYe966mTTkpKdh31qHVVlvm16FO8Q2p3mo9t99eZhszwgamjgAfOaZZz61XjGTFzO+KuAtlQt4MhZ+hvyqOLJpG51sgvbJoUlVIO8swVQjlcUQjexJtzmKL65gQgYL9f+MNK5scHVaEfB7zqB5/4jfNOOf3PSj/dh6i8+/z0MTx8aLGQSgfEIl8enot4+eimd/30kBQ5gAlKHYiFwIBcqdv0/pCKdflC8IZCAbPat7J8Vq880+qhb/kAjiTKZQnIFPSkNj0b9N6okN8YAXNToHTjhVVeTND5tpbMbWhibJtbbDpAtFZC5MShTEQ4jnJpMCIXwxSdTSTq+uYLvr391Rsf/6jJV6hipVAV+nHADRc8/UP7/MF3APrlJUC/XIgJG5T8y8bxF4e9TP0y8SDTMUKB4FJkg36xc2VXjnQkUhB5rLw9L/mb1LctIRAXU6ZMCaruh/x12d2gorWydwalPE14923Tv5uJ++nbUefczE40yqi8ZjwNkblGu5TbSR+MVfrE2+RQMod8tvhGYQd5ZjIvB6sYpeqJnBchBbh6fHMAP/7+4R0vnPFSV6wAqkI/jnjrti9/ZT2aX+3z08dBVXib4tPHvo3+eQhYDOMYvx7UTw+IRbyAgBZaEAy8b3CUS+51e9bUIcWno4hPD+qRtyK5g4mOAawU78Sm27klKvZi7539DLdZGQzdTOyavjaGp4vl+Z3QeutlB6dNCnPmtRbYgpA6J5tJZznfHggpI9kmD5l6/UlEjFwqh2vqtIycSfGHpvbHAMmAu+fvffYN5z/jo1MuYcUKoir044gfHNx+eQDdJYIO1kN34l1y1EHjGjPfmBhhjSnXcrvqrEO+0ABSW5tdyiV7QQRyVtFre0IkTI22KJW3SvpSrWdtJih2Z5VwgVwF90vwUikPTX2YedseCT+kwqe9L6FkVteZd092VU7m5lyyIlgFmUu8OdifJ/NZ4U5RZ3x07b/hvAdR5U6HSizJHBSwB/Nvq2R+/FEV+nHGq+/6xGXnzD34Ew2o8NNTNEuKdvHw0U/n+WJQjDZFx7D65lh1UeTwJkYdgCwPGu0inrmNlInz/JufJBieo10Kz53RGTQD/Yq9bFPiiKJc7NpJjajzYrjJpN0UN7TB7Y2Ho52bQW695ZiwUgVR7DVrubAvrmSuIYmxdQMmdwcZDxS26Bb75jELlOu0zDVOwmo5zd8OVjH24bZXbnzchTNcmooVRlXoxxnXn/v0T+5ePPQWoIhPJ418GbGCYtVOHDccI1+4nYxHmtSejkcKcIVH9lJFqRsFnseq67nY32RII1tDqistafV52P1Ke7KK7njZfW0mTumHBiapZjkc4TKo7gfOjczfrsJ32bHsVvl+uCOTydzGrpTvvSRzvrQ6nico2iwSoULmcyWDPJvqn87WaSnJHGhD+OH31t/7/IFLU3GMURX6KsH1W794ywZadzHQrffSIqRBMVSxL4ZWPPT4OrYLKZad/fOAINEr7LMHVvIA1CPPB7vQ+PRgVHYeYy4+fCl+g+aM9sWeT63f0uORz+KPLyfcfKkYuplkbVAqcWRLSjq2BJ5ZLXYJUe6b883AWCrsk/NyJFIGNLSwSYTOZSekTgtHsqRolpGzyURsAXIobPzdUuu33Ld78zse/ozPzHwBK1YUVaGvEtx5eO/lgXAHoF9SqfcCStXtjJ+ePPQyRTv647kqbaynivSwTl3iMQ6AKP1crVu9rrHNVs1H8nGysHMMfn8FMeYqOFfu5fpZlfJKTL3H7Tu37I12vXGG00sl62xUUh5Tru3ElzdkLsdIZM5fbpd+cflbSLgif8aa2BkKVeU8lJwbIHNQwJ7Fw2+uZL66UBX6KsLLt3zyiZs2nPbpUXCjYJRza/x0HWQ6xqe3iNEviymOnf322JZVeYpPL+q6cAw7EOSpIM6pmofNIo1hMAC0botsE7oKOYtiL1T8kNfeh26Ue88O7FoOyZm0w2V88gc3oW6LfqWUaJoJnOyaIgTRxJ/rzVXJXLYRooVYIXZACy2Jy/HmUYU7II2UFf1yR3H4uLnU8S4RLcZ2IUPm8+3i564856Inz3DZKo4hqkJfRbhx02Wf37Vw4I2xYyxX6vrYy4NMa5VG5ziT1Ek9GJswkn+xlTwkjpjIKLBIIC4tA1l1KSelRGNIimuEMKwnX/rkfeNnDqngXAGT2V+h5PkPldsU07T1A1O+A3vC0yNdpHOyIHP5P/AyUhXszLb2GpXXJV6OvJNUyN6QeSykleq1OJd9puao0aqJZAZ5Tirdkrn34XvfCXdV33wVoir0VYjrt33p0xswuhTI1bIMMh3USx/za6QKjaGV+PWQvPcAoA15fHrwGn/O0TAcWy4VFsFePoxSt5Es6q/b+ul5vZfYjmR/usxa5Uca4TJtH7O1mv51mOULI7w8sFU2GEhhyeS/OeRR1XlG2A5gE4W9ciF2Ut9c4s2hY9iO+HWKL5d4czQYZVYL3yjiXdB7v7AFe59008bNX5rhUlQcY1SFvgrxo/3bn9eG8M+AqmX+Ejf2i5gmMsqKB+odcdRw8mg555BVnKpprdaYGKKjMh0hRYEU1oAofBOfbmAVJdNoRlxGXU9Wt5MVvLSbaZr0M4NKHzr2lHPs7CMpZ77+JZlLX4i1WmSdknmp5Nlb53rpWoTL1GBJPTNc13wE8xToqKjVYs864N72wO9WMl+9qAp9leK3t/z3X920/ozPO8IG8bADR74ELCavfJyiXRZTVcaW49O9l1rr4xSD7j3Xdgmp3gvkryh1GeUoymdR7+YcOrHo8korM5b1Xqyaz5cenQgXYHVEuVDxV14lb4S3d90WAKw/rmSelc5NN1FrjxEoq28uQ8qx7Sb2ih2sIhL6nGskvZ/VOkFDZUnOOeBQO3/zVef82mVLvGQVxxBVoa9SvG3Ts766Y7z/Ddx/J8oseeIj9tLJRLpwKBrIZPZBfHUtzmQ8ViERkmNwBxjI1P9IkFh2w2yZwmTFTqVaoF4F26ege31xMw1hqREry5kGj22uA5OvSG3prOy+B21io4kg/yuyjcD9IZS3k/3mfSPqlevnxIGEzEcuanWJnnIaFVWSeUD4p8Nu/NwJl79iFaAq9FWO37/7ix89dbTuWUDy01lZp8zQlqNevPHVuRYMAsatxzhVYOEoGQ8PhIAWNv5cVbuNbmGfXdvoOhvhwucH3ieimrfyOo9iV3TVfI5pCn647dHFtJtJV5dTTxu9mfa1JpibJamtQtl2RVYomfrmiPYKkcOI+GbOw8e5TImP0KT65lyvRZPUbGirD/7AnYe3XXLTBc/5+vKuXMWxQlXoqxwf27bluS38/wVYBaqS5sfoWNaUO7GSJwqOUogp3kwUHBmDFPEgChG5imT24d+sIiWdHJZQkBGUKMVM3uYq0mIp/nOu4Ker+aM5lapb1LcoWqvA8zfC8eYaaaTvzqp75whx2CXOQTD/d6PkczIvlT6n+cc1UZ13bZeswqIlc/O0EELA1kN7r6lkvjZQFfoawKu2fPiR597voX/RwD0gqmYAyUv3KTM0+uqt1FLnDNIx++lJzbeI8ekhKXXOSM1iz9lP97kSl/rpSKo8hMxjj1taxd6n4DshMD0+eo6leONHpNBp8g76viz9XyDKbky5xRRn7JAhuXLPO595uXO6Na+XzFG5Odv65tFwGxGlsNbYgT5HTRamKB3rSL452SMHHPALH75648XPGb4qFasJldDXCK685zMvPXf0gHdSUAIMidQ5jDEOXRcwDinxKP3l0gEtWrSIdk2ngxRBQhl1QGlE0i6Tjkznp3SCFqQuy3oTjvh37tVMI/ZsH8egA3QahHCpb6lZkhZZ75t/ZQRfkjmpMrdkrvXu43KOEhf/m6B9Kinrc0Sj2LfSxA7QOdIEIh0ty8EZMh8H/81XnnXhI0Ar6mRVHEVUy2WN4C0bL33Xff7wBzNbgb1Tsmna2lnK6ksGLEAc1b0xSoyEDJwSiCEPFJ2gTChcprccck4tByUjV3zKlLTSkcS6yNyTbF8lltNxeSQoj9FfEpeyVwTtHJaBJUwnqRI0hMyzYxV7tgNU8FJOABLF7pAUt5PPxAiNfAaib+7ksyLDzZFSuQOAgD0/PLj/xZXM1xaqQl9juGnbl/+uoebnAQABUpArDnLBnaQerW+xyGGMwcOnQTK4LK9HiMPWBVXobOFoQa7YcVomFVlLJQt55ABGSTbSdoxuiYBOl2dX6w+EO04Ehwctd/0ElJv1eebkdC2ZFvF1yNdQkc5vtuQIJO0E1cShLETR5VYLq28usDVCSuunPKmoLIdL6eJsb/f/5pvOufQ9y7tCFccLVaGvMfwz7XlRCOFeAADFbEBipSbldblzNKpyTjaa45K7PDloJxhU7XOEA3o6QbXzzZ4Vd+wleknSs09ld9R0IalZiVoV3yfdSxXfOdY0sl4imVs1nR0voDg3mliKV8icn0ic+u25ajelF0jXdsg8eeTxaSD55hxnTlzUbSShipLaT5xQpk96fH73+cX3VzJfm6gKfQ3iNXfd/OKz1z34j4k9akBVOmwpgICWB8CA12HrrJ8OjzbFDbbBqxIPPNycV1VuOkFtiKL3+jr/aztGNf2/P0wx70DVJc0ncxwAABqASURBVP3orltmNtIsoOwP8q9Nf9ROuba8d1l1zgSulguv0ygXq8wBYJTummyV2Bo/jeOKnCPMgdC4RjpFbWXOPt+8pfC3rzjzcb+0nMtUcfxRFfoaxJvP3fzefe2hP2L1mgScqHUOTRxJGndKKKEmzjsHR00aSsxJed2G8vjmRjVhJBKnZQIyW0BC8nRZOiWJoiZywrF9CTZCW0aQs0/dh64yz38mmuxLnMxVKFT3MJlzv0Pf+9AnHXM9jcLn65WV0YWGPjakR0//FnlCi6n7qeMTGnvOceh24BTrmxOAFmHHd+6750X9V7xiLaAq9DWMG7ff9o05NL8s0SgpJDFGvkQF3ppoFxveyCUDfApn9N5Eu7Cf7q0aN4lGRRleq+rzdnquouiD1e99ETBTtbcuO0bddf1fEpXtqqztWrKt5LUsFyslam9ntrPKXePMrdWivrcja7U0qeOTsuHjOOKlSZ2hI75JGd/cA/jR4d0veOv5mz94hJer4jiiKvQ1jO8f3P4ij7CNCcClFG4eRNqxajOdYOy3c/0OiXZwqvCFNNhjByAqMalH6xvr8rKdCE5DetaPJ4n60H11fec+QmUxOzHa5UjlilHX+cTvLQySebwGxftI71MrLGrykN0OjokaHTJvYHxvQnrSMsll/D9ntW7/n2l7opzMAWCfP/juSuZrH1Whr3FcteXm52zccNqHHEjjxsHx6clDN3Ho4xQFM/atrOcCXjE+ParkFjyMnepzHhCai3gBGrcOsyxX77mMjklR2pYRir+25NdQlMvRFuizfRm6rRyVLSgjeGuPyM3R3LwAVeKizFM7O+arlsONYacj0lo9XBJX6rTYxCHkES3OjGcKAAtov/7Ksy589Exvv2JVoyr0NY7rNm3+871h/kYUCpGjJGJpAB5WrJE49ZHTiBhW7Y6aFFkBHeCAVJ/zOhKVCVF+qraRKW1b2Cu2T/6yK0mPz50nExHfF+VCPQq4Z5oVg08B2dR9euiQeXp6sT924ImMzPl99JC5KHzThpJlwoOPMJnH4mxafKvhvhJKA4fLOtch87H393x/YfvlS7hUFasYVaGfILhh6623bWjWPZajUdjHbpPyHoeQYtFbtIjZpD7EMrxt0KHrPCClAgI0Tp0jU3JFniv4zGsP3BopEidL/M88dYu+srtDyPc1g14faEKDM0MrbKdw+mvuTn0tybRhQpflfPOz9paQPskNV9rJwM0k6pxVuYPDOqf18mVQC2iHKBBvRC0C7hrvfNYN5zzrY0PvumJtoSr0EwR3hT2Xtx4/Eo8XkAQTHVDaZI4m5daYSYpBJcJwVt2RUY1QYtKBoguvnaLKdklOq39s95MTIdDnWQ9rjkzJTvjJZH0ZwdJrvJd7cMVc/gTQR+bdKBdV5HylOMJFYv3jBUn2i4lIse9VolVihJJLqfta59zkIxjS5yEG+XwAYPfi4RsqmZ9YqAr9BMLLt3x8809tOP2TDTktd5syPyWDVOq+tBj75KcH9tPToBmIBb1kAAykoes4Tj0rrdtV6Tw4hmaVqpPOke4MHa6uX8ErBpaseKQLDc9RXhe+/DKptaE+eKnYCRCLxt6YAFXs3IHJN+V4IzC+ebJXRlKfhQesIB1j1qn1AwAHsXjrlWc+4aKjcYUqVg+qQj+BcOOmZ9x87+KBNzPHCRkklc1DjkU116QEFJIOMx7YIA4k7ExYHfu5iRJEeeY+uepho0ZNlUAAmdYFjHJ3uYK3k55FjiRoh6dife+Oi2Xl08Gk/U8ic1XWZJ46+D2SXEsZPjC7gvG6OVIy1/T8ROZIg5xIdrAZdUh8do164v0GAGOELT/Yu+eKqR+oijWHqtBPQFy/7dbPn+LWXQKjjjnqxXMsevLJF0ObhrKLg0y36XWARxt4II1gomdYofN+UzldrzrcF366HSyaPfLSU2f4kGt0s6nBzK75MtH/tbBLtVO4p52xn+J8rrz1ppd3lnJSF7e3N7/GQccCJTK++Sip9NipzeVxR2Kh5cdp0fofHtz7tLddcNlnj/w6Vaw2VIV+AuJb++9+gQ/+jsg5xk9Pik68c8S62OzXimJPdMK1RBqoyhc/GKoWCZQGo44K1KpTq5KFtFjdUo+yFfJRZdqV7vqU0Kfolz91XHfw00nmYxtvvKvwRZcndZ7F68hxYK6LDO5ckDl77A3pExNHJnHfiGZ9NikbFGgIIEPmHC0DAna1h99YyfzERVXoJyhe8eObL/6pudM+2wSaYz+9Tbrap8GmYzw6q/I2KnYfo2BaU5mxDXlVRvbk++LNuR1gIl+kWmPXU++NfumJU7dtusuGnffZMF2RyzJy2bpMtYvWtso8LaGCzA15k5lnn5vLEzcgUMr+JGgtlpF0gubVE60yl6iWdJKH/OL/ePVZT3jKMi9SxRpAVegnKN5+9ua/2DG/5/cCIOoxq/XCnrrUe0kEQdqhxmq6MaoZMOqZVK0qidnsxNxzj0TFChSyLz5FOVWK0RwSq07I2ljkytotc+r+lEsdcQz3NDKPv5wrolvK62eugzztyFNHfC5o4EDJWmEyl0qJlA8ULgW3esicQPCt/+4PFnY+f5kfp4o1gqrQT3Bcv+3Wm091659mI8VZocuwdGm0o4Xg4UOLxRDg7WhHPMi0RL5EDd7GoHejyO0oRbkK13ov+YB15XB1Jj9UW01Q6/0e+/LRr8qp0ygndntTIqPMdW2pxAFV4eokOWTlFxwJSdvOa4lmSa9HpANYlIleBMAHP//9g9uefNMFv/6lo3OVKlYrRsf7BCpWFjubQ8+/X+t+unFzP0OIxMn+dfAOgTyAGOY4R8AYAYE8xt7FD0fwAJqYdERxD5EmAhoAPkSV6RHrmjgQAsU2PhE2t2eyY372IBB5XhPPDd2CXcyAltitSg52wTIxE5F3jp0TOZ8qFevIKGUh87RGskjJvIZm6TogjTJllbgZHJw0xtxOFtvHB95QyfzkQFXoJwFededHHrPplDO/0JDbwLVYAB7lSMckHQeNcuHY9Dj6kU8RLj5566zS2ZOHRMGIVy6x6HkMunjooszzei++s8SgiFkvFk9dVmLowz8tmQmwoZrmN/G9pyDz9NeWUchUO5M5cSczktrm8sYajjhK1s9cVtvcpSJs2vnKNteBduHjV571hGfOcDkqTgBUD/0kwA3nP/svt4/3XhOSFuZuPVaE1pPlx/uRVPHjGttMSiZLUR7tAc5wjKRkxtAUStNReOIoO4iRMYClIeO/5z629TnIkUwgJVKxLqCRKZMmKiaN2e5Zx9uQidBhw9+cA7Lzd/q6j8zTtWjkujlD8ErmI/bNnfXOnf5Q/r/g/8PY+//3rcP3PO9of54qVi+qQj+JcMP2Wz58qjvl2ayQWQuznz5OY4+yKl9Ei9YHjFNllzbFsMf66V7GEQ1J9fug8wBHtahSt2OM2ugUPRdV9txOWw3Drg+hz4WfjEmKHLAWi8uWZbbKoDKHJhQh7wQF7A1Ek4ckUoXUOx+lZLA56bxW5W4tF7a1Wu8PbJnfdvFbH/br31jyBalYs6gK/STC5771t89bDO0/SMedqO40qDB4JKNYI2SUamrPQQce5vYSO53irqPni0yZcsccUoy6jlSkTwm2E9GO3sNKWCM/JlgkZuJolKVMQ1EuOvHzCJ9n9txglDkyhWyjgMrYfCZzfWJInaCOr22MKeeooxGa7AlKo13yJxzG9oV9r6tkfvKhKvSTDFfe9bFf2LThjFsp0ANZ23L2Jyt0jkPXOi/JX5c6MEHGImXlLUo9wMSnFzVcTIapaG/zpGB9daDrpOfxMeh93bty0qe8WG+bUrEi7+hkIteWtr3MU14aQVL8mewBuQXGeitaPC2q8yZZLE0Rc25K49rjE7DPz3/oqjMveu6Ed11xgqIS+kmI1239zEvPbh74TqSoFSDaJT51ivpE7tJBioDWj1MIo4/D26VO0FasFyX1GNrYDVPsDlMHGKNFCTvkkS5+ArHrsiPDIJGjh6jJzqVlgW2V+Dr2D3AHZa7MWbGTqH/20vVJSKwWIfFGrBZbSdH2VQDAQhj/75c/9MJHHOHlqFijqJbLSYjfO+vSd+0Ph//ElsJle0DLADgptzsCYeSSFYPisd85HRaNaYuMjZBsARgrgo+qA07rfgku72Q0toVaM1aVRvR1ZC5l4rMaIvNSlUtoIW9nLZbGvNfMEmEytlaOIXO2srhErtQ9j2aXXHPpqKZs/wHYvaXd++Ij/oBUrFlUhX4S4907v/p3I7ifl85RpNR9M3h0ixaLyX7xIaD1rbwepyExvBT90sJdbWGnAKq0WbVLgYCgr/m3VetxW7t+sh4vt52EksDLZWTvGMgJHiXZpztR5q8Xylw8+JR16mATgiBKnCONRlknqBlhivhWGPcdEHDP4V2/+abzNr9n+ruuOFFRE4tOYtzp973o/PCArzSNOx2IajMwgwWHQC1CcBglZ6YlD7gG8MCYPJqQ3GHyQHAAAnzafIQ4Ig6FmIrkEeAS8SB5x5HYCUTJiiGCR6QnhLijQJGVncke0qGZ+yNhqPNiOkpbpZwpunHNa7OHjs/OHaW6zpm9USJzeVpJlguXxRUSlycdHYKOkN9a9uPQ+yqZV1SFfpLj6ntuvuK8dae/n0BaChfJT5cOUvXOo5/eGj89qPfutVSvBjVaRZ4nGwWzLlfnKH4bHz0gY+8hET5NxXetlU6DrF1G3FmTeEOKf5N9BbVBrIeex/+TSR6yQ8nxwBVNygaN9XXYahEyJz3+Qtv+zX8+87GPnPiGK04KVA/9JMe1Gzd/YG84/AeAlsKN3reNgyaNroDW4mYPmMMLnWOnWEMXm7Qv66/bgSNiZEc3FBDFvPjmhNjh6GB8ay6Epb47JT9aps5P10M3BzPb8j7ji/x4PM9EO5nMHdQ/b5xGukS/nK9tPtpQw2VzYTx2Q+Y+YMeW+W0vWvlPSsVaQFXoFQCAd23/yu1zbvQrgPW8vajzvuQjLr3LCUfcPoSAFnFPPiX6sFKPS21Yo4mCsWo95GJ8OGSxR4kvI+9/WLEP2Cv8inKLBdASuELmJnlI5pOV0iQlzuTNKf78WtelzuNE5gGEEDzuXtj9/GvP2fynM7zjipMAVaFXAAC+u7D1Cg+/ldUtwKnnqs4dtJZIQyQhdTzwNHH0S4p8IVH6mvIPICc30fK2RG3qXDTK24liTqoYJpLGTMTWRynBi2myYs9fOTMnA0/wUwm0dIKeJ0COpA1vK6GGTNqJzDnF37lE4o4yMneJzG24pAOwxx96VyXzCouq0CsEV237xLMfNvqXH27Sfd4OhmEVuE9D17UpuWicCuyG4DEOMV6mBUx5ANXkuafeTfW3ah3InXQ/oNL7JPkkkd790Pd3iE5S5LzexLDIq7weDN+22LWJZK6jRqUMXRerJzoi8c+ZzPtqwcyH9msvO+Oxj5nwNitOQlSFXiG47synf+Qni/vfymTI9oBO6rLH4l2cvdikYepiISkiF4dCS0q9yagNkt1oY9Wp8NbJpMAzPcrgDZ0pn8srm5TTLEus0cLlDvTpgTsx8x9jp9gtU60VStdjlOYlG1TIXBOGZP/m2gNK5uPg7/n2oa11kOeKDqpCr+jgpp1f+fL9aPQ4/nCwUuf4cp+yR+MgGDFWvfUp6gUm6kUUvldFHrxR6rkq52N1tLnEohchijOU0Z2Gyc75sCJHem0TjYi0UzQuc6KYYkSLLYnL6fxK7NxGi3OR3EB4ny087pzf9czrz9n88WW83YoTHDUOvaKDHyz+5IqfXnfG7Q7uPPGOKZYHaACAHJrgAXIYwQOhAVwL+DjUBcgBASAEOApoieB9InKKbRrEGHMPArwl8khdfAOguCMEpJooxp5hNtUnCsa0oMW8dTknpJ3+2FFEc5slveZ2IT1lwIEC5KmDM3BHiCTPNVrYT+cOUY5BZzLPywfHd7XTH/z9SuYVQ6gKvaIXV/74U0/dNPegTzXUJILlmi8hU982ymUcWl2GAO9NWwQEU8yLUhw7gDTAHbIYdUZZCyY1Q/4iXz+wuvfDXka3FFyetbBELvOFKndGlTunxbN48AlW5rZzdJQ6nJnUMzInvcEd9PO3vuKMx1/U8zYqKgBUD71iAG85+2mf3tbuuTrXzch8Xq5Louqy0SHSEGOtNWU9Rr+wjx6iVgUhRdEweQmZRYiPbiJdOGpGB2I2kTDmpzcCxhKliYYR717eq3r+tnZMVqPGISpq28eQVHnTaN0WjtmPpXBH6Zo0kjQkXjopmdsIGQDwIfyvvePDTzuGH4GKNYiq0Csm4vXbP/PHZzenZQWfYv0WpGiWkJXc5YEwytj0Njng7MUHiZxBUuacpaoDYXQVe16VcZIeH7JcJkW42LncKzfL9B6QeeXafUoxZBG285TjzjVs0Y4KJcXO+CYiHcERLcJdd8/v/uU3bXzqXQNvq6ICQCX0ihlw3bZbvvTg0akX8nwk1UjqgJYHsOTdhoA2tELqMfRRxyLlcr1xD0rRTOAemlzExG6PP/yqS+alFVN+6Du2C/Ia5rwRmeVxkUttE8HLEwgre5cyYTVqxdor08g8ABiHMe71e372modu/ofOSVZUFKiEXjET3rbz1m/dn+73MzxvST3ADE1ns0uNj97CiyrvU+vlwBdZTDomDH4RZtXmJWbrFC3VeFyciJysFRVDNTnqXJKPOAyRE6yWQOYBAbvbQ49/zUMv/vKMb6riJEcl9IqZEEJwN937lZ+cgrnTZBmGSb0cg7SVcMV+tc7EDnQVOx+Ll8TzQba8b673fZjXpTJX315jWnILhjs+cyIn0hjx0mIhQCNaoP0N08icELDHH37hlWdc9IGpb6qiIqESesXMCCGsu3HHl/ef2qxfZ5d7+DRKUYpiCUGHqUsx6QEBrWffnOunyxhHvcSe+em95G7nOmHpHXrvjXKhcn0/iZdK3RGrdO4szVU5QdP3CXaEIVbsScuTevB8nICAHYv73/Xas570n3pOuaJiEJXQK5aEEMK6P7j3L787h+Zh2XJD5t6QehiwYFit841gGrHbQl3WmMmXoNOixJAqz9f3kzjQVeR21CGbydo4jpIx438mIpdRmgoy5zPfMb/3utdufMprule/omIyKqFXLBkhhNF77/3a7YD7JY6RBqwFk7JKTQ0YG7du1fokYo+ZpTm5x+OUBA9zBsjalcgJvT/mpY/E41/dQ0nk3GHqelS5BGimYl5DZO4RsGt83+uuPvOJb+y/8hUVk1EJvWJZCCE0H9jzVze3bfuUflKH0HNrPHNL6rbwV0nsAeyxx70yuQMaHZOdT48mDyhmiqShzFqx642fbUlc0/C1jQxWYSJa1FIpLRaOgYdJP4poQX7neN8rrjnzie+Y7T9QUdFFJfSKZSOE4P5k1zc+uhjCM/pIHUBmwXAtGLZhmMi5hnpmuyBIlqguB6yZoh2juYJfCix5x/ncS9ckJQgZ27hzDk3kDlGC+uNNiMlHQu29fjnQAHu2hoWXvvYhF/75st5ERUVCJfSKI8Z7f3L7BwPC8wAlKaBU63mHaSrPhXFB5NaK4e1tES8O5+vSe6HOJ/A7FUo998z5J8KBUnq/M+vLUYps/RUn5C8qXaoldsl8DqPv/WR+32+9emMNTaw4clRCrzgquGnnba86leb+qwceVJI6DJkLcQemdA1dbA2Ve89RLpa8g0k4CshvHNP9cwvN8sw7QAFI/RQqSJxMZ6e1W1zHRzdtejs+4xk23t1CbXj+FWc9aufsV7qiYhiV0CuOGq7d9vlffEjzgHeDwiN4WanWo1VirBZYYtdko8x+MeQe95XrciZ5PeZ0+6WbPJR3hVrCllrtZrkSd0nkmKrKgTA/Jlz/W6c/+nUzX9yKihlQCb3iqCIlIL3vFIwutwRZZoGyDVPOl6o9J/d0MzClAEqSz86lmO+NQzdLmXplwA2eN0o9U9+dZRgkcjke0XfuWdj9it856ym3TL+aFRVLQyX0ihXBtTu/8OIH4/5vbAhn8LI+G8Yq9ti5aaNc4jJCQJv56F0PPYS8k3QSxGaRqBa7tFDn0I7TrHO0XC6CP7dXrP10eDz+zK5De1/w+vOftmfW61hRsRRUQq9YMVy19SObzp57yBvW+7lnOUfreXno/LVWjCp3q9qB7BYgxM/Ixxud3XKhgsgjUecxLlLfHGRIPG4xjcgJgA/h29sP737bNec+9X1TT6yi4ghQCb1ixfG7P/7UI06fO+135oiebC2OPmLn+SFyl/Ww87qHWaMXNeW/S+3OrLFKPC6ztkqZgpQTeevDtt3j/e99zdlPuma2s6qoODJUQq84Zrhu1xd+7SF4wFWt94+yH7xuMlCR8t8ZtUiJO1fm3f31odfbFv+c52ymaB7WaMMc7T6VyNv5/X7+T++4b8dr3/OvnrdjyulUVBw1VEKvOOa4aettl28YNVcQNf8BCFnKZJeUc3KX16G7DWwprwFWp+wTb0cLhb4mS+mU0XffzUCsFdCuQ37+tjsWD7z5nRsv/Wb/GVRUrBwqoVccN7zl7k/97IZTTrtiQ9s80VO4AOgSpf1r5/piW2RuRomeZYjydpSrcLu+/9zIj/34f+4dH7p564FdH3jnw39j35SjV1SsGCqhV6wKvH3nF5+zgdb/xxE1jw4h/AsmzOkEX65dDrpfgy6lqxKPR6JvH2rnb9ntF97/+rMu+dYRHLyi4qihEnrFqsJrtn7sIWc0D3rmOpq7aA7NL4Jwho1lB/pJHlOWleiPSc/3Yec9AgLhbw6NF75xiNrPXn3GxbfPcJiKimOKSugVqxrXbf/cRRtwv80jN/eYOaJ/zctLkrfLZsXQtsar378Qxt/wvv3sAT/+5NVnXVJT9CtWNSqhV6wZXLfrSw9cP49fGa1zP4dA/74h+jdNGJ1PCKfYdrN8qEsVPw7+xyHgjjEt/hNA32wPz//1b5/7xH88emdfUbHyqIResebxjq1f+LfjZu7fkff3b0ajUwLCKSOiDQtjf/8GtAHACESH4Ogg+XBwHMIhONznvT/YYn7HV/fd+bVbHv6y+eP9PioqKioqKioqAAD/H58Q1CJfdsHwAAAAAElFTkSuQmCC","w":372,"h":288,"e":1},{"id":"13","layers":[{"ddd":0,"ind":25,"ty":3,"nm":"Frame43","sr":1,"ks":{"p":{"a":0,"k":[751.765625,296],"ix":2},"a":{"a":0,"k":[654.765625,162],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"14","w":296,"h":72,"ind":26,"ty":0,"nm":"Frame","sr":1,"ks":{"p":{"a":0,"k":[796,32],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":25,"ef":[{"ty":25,"nm":"DropShadow","mn":"ADBEDropShadow","ef":[{"ty":2,"nm":"ShadowColor","mn":"ADBEDropShadow-0001","v":{"a":0,"k":[0,0,0],"ix":2}},{"ty":0,"nm":"Opacity","mn":"ADBEDropShadow-0002","v":{"a":0,"k":51.00000075995922,"ix":2}},{"ty":1,"nm":"Direction","mn":"ADBEDropShadow-0003","v":{"a":0,"k":180,"ix":2}},{"ty":0,"nm":"Distance","mn":"ADBEDropShadow-0004","v":{"a":0,"k":1.4185303449630737,"ix":2}},{"ty":0,"nm":"Softness","mn":"ADBEDropShadow-0005","v":{"a":0,"k":2.8370606899261475,"ix":2}}],"np":5,"ix":0,"en":1}]},{"ddd":0,"ind":27,"ty":4,"nm":"GetyourAIwebsiteteamnow","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":25,"shapes":[],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":28,"ty":4,"nm":"GetyourAIwebsiteteamnow","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":27,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[987,-1536],[987,-1216],[62,-1216],[62,-1536],[987,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[272,-1904],[698,-1904],[698,-472],[716,-380.5],[766.5,-335],[842,-322],[902,-327.5],[948,-336],[1015,-19],[925,4.5],[784,21],[514.5,-20],[335,-166],[272,-416],[272,-1904]],"i":[[0,0],[0,0],[0,0],[-12,-21.666666666666686],[-21.66666666666663,-8.666666666666686],[-28.66666666666663,0],[-20,3.6666666666666856],[-10.666666666666629,2],[0,0],[38.66666666666663,-9],[55.33333333333337,-2],[77,31.333333333333336],[42.666666666666686,66],[-0.6666666666666856,100.66666666666669],[0,0]],"o":[[0,0],[0,0],[0,39.333333333333314],[12,21.666666666666686],[21.66666666666663,8.666666666666686],[20,0],[20,-3.6666666666666856],[0,0],[-21.33333333333337,6.666666666666666],[-38.66666666666663,9],[-102.66666666666663,4],[-77,-31.333333333333336],[-42.666666666666686,-66],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-300,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-278.57045454545454,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[608,29],[346,-22.5],[164.5,-175.5],[98,-429],[145,-644],[273,-784],[457.5,-864],[675,-902],[891,-928.5],[1010,-966],[1047,-1040],[1047,-1046],[987.5,-1193],[819,-1245],[636,-1194.5],[546,-1068],[152,-1100],[270,-1342.5],[497.5,-1500.5],[821,-1556],[1066.5,-1526],[1275.5,-1433],[1420,-1271.5],[1473,-1036],[1473,0],[1069,0],[1069,-213],[1057,-213],[958,-86.5],[809,-1.5],[608,29]],"i":[[0,0],[76.66666666666669,34.333333333333336],[44.33333333333334,67.66666666666667],[0,101.33333333333331],[-31.33333333333333,58],[-54,35.33333333333337],[-69,18],[-76,7.333333333333371],[-54.66666666666663,8.333333333333371],[-24.66666666666663,16.66666666666663],[0,32.66666666666663],[0,0],[39.66666666666674,34.66666666666674],[72.66666666666663,0],[45.33333333333337,-33.66666666666674],[14.666666666666629,-50.66666666666674],[0,0],[-58.66666666666666,68.33333333333326],[-93,37],[-122.66666666666663,0],[-78.33333333333337,-20],[-61,-42],[-35.33333333333326,-65.66666666666674],[0,-91.33333333333326],[0,0],[0,0],[0,0],[0,0],[41.33333333333337,-36.33333333333333],[58,-20.333333333333332],[76,0]],"o":[[-98,0],[-76.66666666666669,-34.333333333333336],[-44.33333333333333,-67.66666666666666],[0,-85.33333333333337],[31.333333333333343,-58],[54,-35.33333333333337],[69,-18],[89.33333333333337,-9.333333333333371],[54.66666666666663,-8.333333333333371],[24.666666666666742,-16.66666666666663],[0,0],[0,-63.33333333333326],[-39.66666666666663,-34.66666666666674],[-76.66666666666663,0],[-45.33333333333337,33.66666666666674],[0,0],[20,-93.33333333333326],[58.666666666666686,-68.33333333333326],[93,-37],[85.33333333333337,0],[78.33333333333326,20],[61,42],[35.33333333333326,65.66666666666674],[0,0],[0,0],[0,0],[0,0],[-24.666666666666742,48],[-41.33333333333337,36.333333333333336],[-58,20.333333333333332],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[730,-265],[896,-302.5],[1009,-404],[1050,-549],[1050,-712],[995.5,-688.5],[918,-669.5],[832,-654.5],[754,-643],[623,-608],[536,-543.5],[505,-443],[568.5,-310.5],[730,-265]],"i":[[0,0],[-48,25],[-27.33333333333337,42.666666666666686],[0,54],[0,0],[23,-7],[28.66666666666663,-5.666666666666629],[28.66666666666663,-4.333333333333371],[23.33333333333337,-3.3333333333333712],[37.33333333333337,-16],[20.66666666666663,-27],[0,-40],[-42.33333333333337,-30.333333333333314],[-65.33333333333337,0]],"o":[[62.66666666666663,0],[48,-25],[27.333333333333258,-42.666666666666686],[0,0],[-13.333333333333258,8.666666666666629],[-23,7],[-28.66666666666663,5.666666666666629],[-28.66666666666663,4.333333333333371],[-50,7.333333333333371],[-37.33333333333337,16],[-20.66666666666663,27],[0,58],[42.33333333333337,30.333333333333314],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-245.09772727272727,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[170,0],[170,-1536],[576,-1536],[576,-1265],[594,-1265],[754,-1478],[1022,-1556],[1291,-1477.5],[1439,-1265],[1455,-1265],[1625.5,-1476.5],[1918,-1556],[2267.5,-1419.5],[2402,-1033],[2402,0],[1977,0],[1977,-949],[1909,-1141],[1739,-1205],[1558,-1131.5],[1493,-938],[1493,0],[1080,0],[1080,-958],[1015.5,-1138],[846,-1205],[718.5,-1169.5],[629,-1070.5],[596,-922],[596,0],[170,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[-74.66666666666663,52],[-104,0],[-74,-52.33333333333326],[-24.666666666666742,-89.33333333333326],[0,0],[-82.33333333333326,53],[-112.66666666666674,0],[-89.66666666666652,-91],[0,-166.66666666666674],[0,0],[0,0],[0,0],[45.33333333333326,42.66666666666674],[68,0],[43.33333333333326,-49],[0,-80],[0,0],[0,0],[0,0],[43,44.66666666666674],[70,0],[37.66666666666663,-23.666666666666742],[22,-42.33333333333326],[0,-56.66666666666663],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[32,-90],[74.66666666666663,-52],[105.33333333333326,0],[74,52.33333333333326],[0,0],[31.333333333333258,-88],[82.33333333333326,-53],[143.33333333333348,0],[89.66666666666652,91],[0,0],[0,0],[0,0],[0,-85.33333333333326],[-45.33333333333326,-42.66666666666674],[-77.33333333333326,0],[-43.33333333333326,49],[0,0],[0,0],[0,0],[0,-75.33333333333326],[-43,-44.66666666666674],[-47.33333333333337,0],[-37.66666666666663,23.666666666666742],[-22,42.33333333333326],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-212.61136363636365,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[-161.5431818181818,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[596,-888],[596,0],[170,0],[170,-1536],[576,-1536],[576,-1265],[594,-1265],[765,-1477.5],[1056,-1556],[1335,-1486],[1520,-1286.5],[1586,-978],[1586,0],[1160,0],[1160,-902],[1088,-1122.5],[887,-1202],[735.5,-1165],[633.5,-1057.5],[596,-888]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[-80,52.33333333333326],[-114,0],[-79.33333333333326,-46.66666666666674],[-44,-86.33333333333326],[0,-119.33333333333326],[0,0],[0,0],[0,0],[48.66666666666674,53],[85.33333333333337,0],[43.66666666666663,-24.666666666666742],[24.33333333333337,-47],[0.6666666666666288,-66]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[34,-89.33333333333326],[80,-52.33333333333326],[106.66666666666674,0],[79.33333333333326,46.66666666666674],[44,86.33333333333326],[0,0],[0,0],[0,0],[0.6666666666667425,-94],[-48.66666666666674,-53],[-57.33333333333337,0],[-43.66666666666663,24.666666666666742],[-24.33333333333337,47],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-148.56136363636364,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[864,30],[461.5,-69.5],[200,-347.5],[108,-762],[200,-1178.5],[461.5,-1456.5],[864,-1556],[1266.5,-1456.5],[1528,-1178.5],[1620,-762],[1528,-347.5],[1266.5,-69.5],[864,30]],"i":[[0,0],[113,66.33333333333333],[61.333333333333314,119],[0,157.33333333333337],[-61.33333333333334,119],[-113,66.33333333333326],[-155.33333333333337,0],[-113,-66.33333333333326],[-61.33333333333326,-119],[0,-158.66666666666663],[61.33333333333326,-119],[113,-66.33333333333334],[155.33333333333337,0]],"o":[[-155.33333333333337,0],[-113,-66.33333333333334],[-61.33333333333334,-119],[0,-158.66666666666663],[61.333333333333314,-119],[113,-66.33333333333326],[155.33333333333337,0],[113,66.33333333333326],[61.33333333333326,119],[0,157.33333333333337],[-61.33333333333326,119],[-113,66.33333333333333],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[866,-300],[1043,-360.5],[1150.5,-526],[1187,-765],[1150.5,-1004],[1043,-1170],[866,-1231],[686.5,-1170],[577.5,-1004],[541,-765],[577.5,-526],[686.5,-360.5],[866,-300]],"i":[[0,0],[-47.33333333333337,40.333333333333314],[-24.333333333333258,70],[0,89.33333333333337],[24.333333333333258,70],[47.33333333333326,40.66666666666674],[70.66666666666663,0],[48.33333333333337,-40.66666666666674],[24.33333333333337,-70],[0,-89.33333333333337],[-24.33333333333337,-70],[-48.33333333333337,-40.333333333333314],[-71.33333333333337,0]],"o":[[70.66666666666663,0],[47.33333333333326,-40.333333333333314],[24.333333333333258,-70],[0,-89.33333333333337],[-24.333333333333258,-70],[-47.33333333333337,-40.66666666666674],[-71.33333333333337,0],[-48.33333333333337,40.66666666666674],[-24.33333333333337,70],[0,89.33333333333337],[24.33333333333337,70],[48.33333333333337,40.333333333333314],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-113.73636363636365,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[473,0],[55,-1536],[486,-1536],[724,-504],[738,-504],[986,-1536],[1409,-1536],[1661,-510],[1674,-510],[1908,-1536],[2338,-1536],[1921,0],[1470,0],[1206,-966],[1187,-966],[923,0],[473,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-80.12045454545455,54.25],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[300,68],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":29,"ty":4,"nm":"GetyourAIwebsiteteamnow","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":27,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[1536,-1386],[1477,-1515.5],[1384.5,-1611.5],[1260.5,-1672],[1107,-1693],[831.5,-1615],[647,-1388.5],[581,-1026],[646,-662],[830,-433.5],[1111,-355],[1362.5,-407.5],[1522.5,-556],[1578,-783],[1666,-770],[1138,-770],[1138,-1096],[1995,-1096],[1995,-838],[1881,-374.5],[1567,-76.5],[1109,28],[603,-99.5],[263.5,-462.5],[142,-1022],[214.5,-1466.5],[418,-1798],[723,-2005],[1100,-2076],[1424,-2025.5],[1690.5,-1883],[1881,-1664.5],[1976,-1386],[1536,-1386]],"i":[[0,0],[25.333333333333258,37.66666666666674],[36.33333333333326,26.333333333333258],[46.33333333333326,14],[56,0],[79,-52],[44,-99],[0,-142.66666666666674],[-43.33333333333337,-100],[-79.33333333333337,-52.333333333333314],[-108,0],[-69.66666666666674,35],[-37,64],[0,87.33333333333337],[0,0],[0,0],[0,0],[0,0],[0,0],[76,-129],[133.33333333333326,-69.66666666666666],[172,0],[145.33333333333337,85],[81,157],[0,216],[-48.33333333333334,130.33333333333326],[-87.33333333333331,90.66666666666674],[-116,47.33333333333326],[-135.33333333333337,0],[-100,-33.666666666666515],[-77.66666666666674,-61.33333333333326],[-49.33333333333326,-84.33333333333326],[-14,-101.33333333333326],[0,0]],"o":[[-14,-48.66666666666674],[-25.333333333333258,-37.66666666666674],[-36.33333333333326,-26.333333333333258],[-46.33333333333326,-14],[-104.66666666666663,0],[-79,52],[-44,99],[0,142.66666666666663],[43.33333333333337,100],[79.33333333333337,52.333333333333314],[98,0],[69.66666666666674,-35],[37,-64],[0,0],[0,0],[0,0],[0,0],[0,0],[0,180],[-76,129],[-133.33333333333326,69.66666666666667],[-192,0],[-145.33333333333331,-85],[-81,-157],[0,-166],[48.333333333333314,-130.33333333333326],[87.33333333333331,-90.66666666666674],[116,-47.333333333333485],[116,0],[100,33.66666666666674],[77.66666666666674,61.33333333333326],[49.33333333333326,84.33333333333326],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-300,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-257.3954545454545,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[987,-1536],[987,-1216],[62,-1216],[62,-1536],[987,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[272,-1904],[698,-1904],[698,-472],[716,-380.5],[766.5,-335],[842,-322],[902,-327.5],[948,-336],[1015,-19],[925,4.5],[784,21],[514.5,-20],[335,-166],[272,-416],[272,-1904]],"i":[[0,0],[0,0],[0,0],[-12,-21.666666666666686],[-21.66666666666663,-8.666666666666686],[-28.66666666666663,0],[-20,3.6666666666666856],[-10.666666666666629,2],[0,0],[38.66666666666663,-9],[55.33333333333337,-2],[77,31.333333333333336],[42.666666666666686,66],[-0.6666666666666856,100.66666666666669],[0,0]],"o":[[0,0],[0,0],[0,39.333333333333314],[12,21.666666666666686],[21.66666666666663,8.666666666666686],[20,0],[20,-3.6666666666666856],[0,0],[-21.33333333333337,6.666666666666666],[-38.66666666666663,9],[-102.66666666666663,4],[-77,-31.333333333333336],[-42.666666666666686,-66],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-223.92272727272726,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[-202.17499999999998,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[433,576],[281.5,563.5],[165,532],[261,214],[396.5,239],[501.5,211],[574,109],[599,44],[48,-1536],[496,-1536],[814,-408],[830,-408],[1151,-1536],[1602,-1536],[1005,166],[888.5,382.5],[703,525.5],[433,576]],"i":[[0,0],[47,8.333333333333371],[30.666666666666657,12.666666666666629],[0,0],[-40.333333333333314,-1.3333333333333428],[-29.666666666666686,20],[-18.66666666666663,48],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[49,-61.666666666666686],[74.66666666666663,-33.666666666666686],[105.33333333333337,0]],"o":[[-54,0],[-47,-8.333333333333371],[0,0],[50,15.333333333333343],[40.333333333333314,1.3333333333333428],[29.66666666666663,-20],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[-28.66666666666663,82.66666666666666],[-49,61.666666666666686],[-74.66666666666663,33.66666666666663],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-189.1931818181818,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[864,30],[461.5,-69.5],[200,-347.5],[108,-762],[200,-1178.5],[461.5,-1456.5],[864,-1556],[1266.5,-1456.5],[1528,-1178.5],[1620,-762],[1528,-347.5],[1266.5,-69.5],[864,30]],"i":[[0,0],[113,66.33333333333333],[61.333333333333314,119],[0,157.33333333333337],[-61.33333333333334,119],[-113,66.33333333333326],[-155.33333333333337,0],[-113,-66.33333333333326],[-61.33333333333326,-119],[0,-158.66666666666663],[61.33333333333326,-119],[113,-66.33333333333334],[155.33333333333337,0]],"o":[[-155.33333333333337,0],[-113,-66.33333333333334],[-61.33333333333334,-119],[0,-158.66666666666663],[61.333333333333314,-119],[113,-66.33333333333326],[155.33333333333337,0],[113,66.33333333333326],[61.33333333333326,119],[0,157.33333333333337],[-61.33333333333326,119],[-113,66.33333333333333],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[866,-300],[1043,-360.5],[1150.5,-526],[1187,-765],[1150.5,-1004],[1043,-1170],[866,-1231],[686.5,-1170],[577.5,-1004],[541,-765],[577.5,-526],[686.5,-360.5],[866,-300]],"i":[[0,0],[-47.33333333333337,40.333333333333314],[-24.333333333333258,70],[0,89.33333333333337],[24.333333333333258,70],[47.33333333333326,40.66666666666674],[70.66666666666663,0],[48.33333333333337,-40.66666666666674],[24.33333333333337,-70],[0,-89.33333333333337],[-24.33333333333337,-70],[-48.33333333333337,-40.333333333333314],[-71.33333333333337,0]],"o":[[70.66666666666663,0],[47.33333333333326,-40.333333333333314],[24.333333333333258,-70],[0,-89.33333333333337],[-24.333333333333258,-70],[-47.33333333333337,-40.66666666666674],[-71.33333333333337,0],[-48.33333333333337,40.66666666666674],[-24.33333333333337,70],[0,89.33333333333337],[24.33333333333337,70],[48.33333333333337,40.333333333333314],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-157.40681818181818,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[1155,-654],[1155,-1536],[1581,-1536],[1581,0],[1172,0],[1172,-279],[1156,-279],[983.5,-62],[690,20],[419,-50],[236.5,-249],[170,-558],[170,-1536],[596,-1536],[596,-634],[669,-419],[862,-340],[1006,-375.5],[1114.5,-481],[1155,-654]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[80.33333333333326,-54.66666666666667],[115.33333333333337,0],[78,46.666666666666664],[43.666666666666686,86],[0.6666666666666572,120],[0,0],[0,0],[0,0],[-48,-52.666666666666686],[-80.66666666666663,0],[-44.66666666666663,23.666666666666686],[-27.666666666666742,46.666666666666686],[0.6666666666667425,68.66666666666663]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[-34.66666666666674,90],[-80.33333333333337,54.666666666666664],[-102.66666666666663,0],[-78,-46.66666666666667],[-43.66666666666666,-86],[0,0],[0,0],[0,0],[0.6666666666666288,90.66666666666663],[48,52.666666666666686],[51.33333333333337,0],[44.66666666666674,-23.666666666666686],[27.666666666666742,-46.66666666666663],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-123.04318181818184,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[170,0],[170,-1536],[583,-1536],[583,-1268],[599,-1268],[740,-1484.5],[968,-1558],[1037,-1554],[1102,-1543],[1102,-1165],[1019,-1181],[922,-1188],[754.5,-1147.5],[638.5,-1035],[596,-869],[596,0],[170,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[-66,49],[-86,0],[-24.66666666666663,-2.6666666666667425],[-18.666666666666742,-4.6666666666667425],[0,0],[35.33333333333326,4.6666666666667425],[29.33333333333337,0],[49,-27],[28.33333333333337,-48],[0,-62.66666666666663],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[28,-95.33333333333326],[66,-49],[21.33333333333337,0],[24.666666666666742,2.6666666666667425],[0,0],[-20,-6],[-35.33333333333337,-4.6666666666667425],[-62.66666666666663,0],[-49,27],[-28.33333333333337,48],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-88.21818181818185,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[-65.32500000000002,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[531,0],[67,0],[774,-2048],[1332,-2048],[2038,0],[1574,0],[1061,-1580],[1045,-1580],[531,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[502,-805],[1598,-805],[1598,-467],[502,-467],[502,-805]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-52.34318181818185,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[611,-2048],[611,0],[178,0],[178,-2048],[611,-2048]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-10.470454545454572,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[5.2318181818181415,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[473,0],[55,-1536],[486,-1536],[724,-504],[738,-504],[986,-1536],[1409,-1536],[1661,-510],[1674,-510],[1908,-1536],[2338,-1536],[1921,0],[1470,0],[1206,-966],[1187,-966],[923,0],[473,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[18.21363636363634,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[65.06590909090903,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[178,0],[178,-2048],[604,-2048],[604,-1278],[617,-1278],[698.5,-1404.5],[838.5,-1512.5],[1054,-1556],[1364,-1468.5],[1591,-1205.5],[1676,-766],[1593.5,-332.5],[1369.5,-65.5],[1053,25],[842.5,-16],[701,-119.5],[617,-246],[598,-246],[598,0],[178,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[-35.66666666666663,43],[-57.66666666666663,29],[-86,0],[-94.66666666666674,-58.33333333333326],[-56.66666666666674,-117],[0,-176],[55,-117.66666666666669],[94.33333333333326,-60.33333333333333],[116.66666666666674,0],[57.66666666666663,27.333333333333336],[36.66666666666663,41.66666666666667],[19.33333333333337,42.66666666666666],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[18.66666666666663,-41.33333333333326],[35.66666666666663,-43],[57.66666666666663,-29],[112,0],[94.66666666666674,58.33333333333326],[56.66666666666674,117],[0,171.33333333333337],[-55,117.66666666666666],[-94.33333333333326,60.333333333333336],[-82.66666666666663,0],[-57.66666666666663,-27.333333333333336],[-36.66666666666663,-41.66666666666666],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[595,-768],[633,-529],[743,-370.5],[918,-314],[1094,-371.5],[1203.5,-531.5],[1241,-768],[1204,-1002],[1095,-1160],[918,-1217],[742.5,-1162],[633,-1006],[595,-768]],"i":[[0,0],[-25.33333333333337,-68],[-48,-37.666666666666686],[-68.66666666666663,0],[-48,38.333333333333314],[-25,68.33333333333331],[0,89.33333333333337],[24.666666666666742,67.33333333333337],[48,38],[70,0],[47.66666666666663,-36.66666666666674],[25.33333333333337,-67.33333333333326],[0,-91.33333333333337]],"o":[[0,91.33333333333337],[25.33333333333337,68],[48,37.666666666666686],[69.33333333333337,0],[48,-38.333333333333314],[25,-68.33333333333337],[0,-88.66666666666663],[-24.666666666666742,-67.33333333333326],[-48,-38],[-69.33333333333337,0],[-47.66666666666663,36.66666666666674],[-25.33333333333337,67.33333333333337],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[98.53863636363633,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[1448,-1098],[1058,-1074],[1015,-1164.5],[928.5,-1229.5],[801,-1254],[634,-1212.5],[566,-1102],[610,-1009],[761,-948],[1039,-892],[1373,-744],[1483,-476],[1394.5,-211],[1152.5,-33.5],[799,30],[313.5,-97.5],[102,-445],[521,-467],[613,-325.5],[800,-277],[980.5,-320.5],[1050,-433],[1001,-528.5],[853,-586],[587,-639],[252.5,-795],[143,-1078],[223.5,-1333],[450.5,-1498],[794,-1556],[1252.5,-1433],[1448,-1098]],"i":[[0,0],[0,0],[22,27],[35.66666666666663,16.333333333333258],[49.33333333333337,0],[45.33333333333337,-27.666666666666742],[0,-46],[-29.33333333333337,-25.333333333333258],[-71.33333333333337,-15.333333333333371],[0,0],[-73.33333333333326,-68],[0,-110.66666666666663],[59,-76],[102.33333333333326,-42.33333333333333],[133.33333333333337,0],[120.33333333333331,85],[20.66666666666667,146.66666666666669],[0,0],[-48.66666666666663,-32.333333333333314],[-76,0],[-45.66666666666663,29],[-0.6666666666667425,46],[32,25],[66.66666666666663,13.333333333333371],[0,0],[73,74],[0,114.66666666666663],[-53.66666666666666,71.33333333333326],[-97.66666666666669,38.66666666666674],[-131.33333333333337,0],[-111.66666666666674,-82],[-18.666666666666742,-141.33333333333326]],"o":[[0,0],[-6.6666666666667425,-33.33333333333326],[-22,-27],[-35.66666666666663,-16.333333333333258],[-66,0],[-45.33333333333337,27.666666666666742],[0,36.66666666666674],[29.33333333333337,25.33333333333337],[0,0],[149.33333333333326,30.66666666666663],[73.33333333333326,68],[0,100.66666666666669],[-59,76],[-102.33333333333326,42.333333333333336],[-203.33333333333337,0],[-120.33333333333334,-85],[0,0],[12.666666666666629,62],[48.66666666666663,32.333333333333314],[74.66666666666663,0],[45.66666666666674,-29],[-0.6666666666667425,-38.666666666666686],[-32,-25],[0,0],[-150,-30],[-73,-74],[0,-98.66666666666674],[53.666666666666686,-71.33333333333326],[97.66666666666663,-38.66666666666674],[194,0],[111.66666666666674,82],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[134.1113636363636,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[170,0],[170,-1536],[596,-1536],[596,0],[170,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[384,-1734],[221.5,-1797.2212389380531],[154,-1949.2212389380531],[221.76785714285714,-2101.5],[384,-2165],[546.5,-2101.778761061947],[614,-1949.7787610619469],[546.5,-1797.5],[384,-1734]],"i":[[0,0],[45,42.14749262536884],[0,59.185840707964644],[-45.178571428571445,42.333333333333485],[-62.97619047619048,0],[-45,-42.14749262536861],[0,-59.185840707964644],[45,-42.33333333333326],[63.333333333333314,0]],"o":[[-63.333333333333314,0],[-45,-42.14749262536861],[0,-59.18584070796442],[45.178571428571416,-42.333333333333485],[63.333333333333314,0],[45,42.14749262536907],[0,59.18584070796442],[-45,42.33333333333326],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[165.57954545454538,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[987,-1536],[987,-1216],[62,-1216],[62,-1536],[987,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[272,-1904],[698,-1904],[698,-472],[716,-380.5],[766.5,-335],[842,-322],[902,-327.5],[948,-336],[1015,-19],[925,4.5],[784,21],[514.5,-20],[335,-166],[272,-416],[272,-1904]],"i":[[0,0],[0,0],[0,0],[-12,-21.666666666666686],[-21.66666666666663,-8.666666666666686],[-28.66666666666663,0],[-20,3.6666666666666856],[-10.666666666666629,2],[0,0],[38.66666666666663,-9],[55.33333333333337,-2],[77,31.333333333333336],[42.666666666666686,66],[-0.6666666666666856,100.66666666666669],[0,0]],"o":[[0,0],[0,0],[0,39.333333333333314],[12,21.666666666666686],[21.66666666666663,8.666666666666686],[20,0],[20,-3.6666666666666856],[0,0],[-21.33333333333337,6.666666666666666],[-38.66666666666663,9],[-102.66666666666663,4],[-77,-31.333333333333336],[-42.666666666666686,-66],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[180.82045454545448,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[202.24999999999994,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[235.72272727272718,-13.52272727272728],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.9886363636363635,1.9886363636363635],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[300,68],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":30,"ty":4,"nm":"Circle8","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":25,"shapes":[{"ty":"gr","nm":"Circle8","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":false,"v":[[283.4380456796637,5.776223714344603],[15.312712541165308,45.5222176171406],[254.10720850281666,104.2771228858472],[340,60.69904566554302],[174.4103596167265,18.520819934884294]],"i":[[0,0],[60.91333638970676,-53.91630664981179],[-86.83315924060112,10.424632446549033],[0,22.079647613280876],[106.65758973398913,-5.400270966685322]],"o":[[-63.99455384039348,-9.216462724481602],[-76.14166822676447,67.39538166423281],[51.95501493439079,-6.237385891933618],[0,-19.008953802732336],[0,0]]}}},{"ty":"st","c":{"a":0,"k":[0.4,0.9294117647058824,0.6823529411764706],"ix":2},"o":{"a":0,"k":100,"ix":2},"w":{"a":0,"k":6,"ix":2},"lc":2,"lj":1,"ml":4},{"ty":"tr","p":{"a":0,"k":[933.53125,60],"ix":2},"a":{"a":0,"k":[170,54.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":31,"ty":4,"nm":"Framebackground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"gr","nm":"Framebackground","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[1282,426],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[641,213],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"14","layers":[{"ddd":0,"ind":26,"ty":3,"nm":"Frame","sr":1,"ks":{"p":{"a":0,"k":[948,72],"ix":2},"a":{"a":0,"k":[944,68],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":32,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[144,32],"ix":2},"a":{"a":0,"k":[144,32],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":26},{"ddd":0,"refId":"15","w":289,"h":66,"ind":33,"ty":0,"nm":"Frameclippedcontent","sr":1,"ks":{"p":{"a":0,"k":[-1,-1],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":32},{"ddd":0,"ind":34,"ty":4,"nm":"FrameOverscan","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[296,72],"ix":2},"p":{"a":0,"k":[148,36],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"16","layers":[{"ddd":0,"ind":35,"ty":4,"nm":"Chatforfree!","sr":1,"ks":{"p":{"a":0,"k":[1,1],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":36,"ty":4,"nm":"Chatforfree!","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":35,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[1985,-1331],[1547,-1331],[1498,-1482.5],[1403,-1596],[1269.5,-1668],[1106,-1693],[829,-1614.5],[646,-1386.5],[581,-1024],[646.5,-656],[830,-431],[1103,-355],[1264.5,-378],[1397,-445.5],[1493.5,-554],[1547,-700],[1985,-698],[1900.5,-426.5],[1719.5,-193.5],[1449.5,-31.5],[1096,28],[606.5,-96],[266.5,-455],[142,-1024],[268,-1594],[610,-1952.5],[1096,-2076],[1426.5,-2026],[1697,-1880.5],[1889.5,-1647],[1985,-1331]],"i":[[0,0],[0,0],[24.666666666666742,44.33333333333326],[38.66666666666674,31.333333333333258],[50.33333333333326,16.666666666666742],[58.66666666666674,0],[78.66666666666663,-52.33333333333326],[43.33333333333337,-99.66666666666674],[0,-142],[-43.66666666666663,-99.33333333333337],[-78.66666666666663,-50.666666666666686],[-103.33333333333337,0],[-49.66666666666674,15.333333333333314],[-38.66666666666674,29.666666666666686],[-25.666666666666742,42.666666666666686],[-10,54.66666666666663],[0,0],[45,-87],[75.66666666666674,-68.33333333333331],[104.33333333333326,-39.66666666666667],[131.33333333333326,0],[143.66666666666663,82.66666666666667],[83,156.66666666666669],[0,222.66666666666663],[-84,156.66666666666674],[-144,82.33333333333326],[-180,0],[-101.66666666666674,-33.333333333333485],[-78.66666666666674,-63.66666666666674],[-49.66666666666674,-92],[-14,-118.66666666666674]],"o":[[0,0],[-8,-56.66666666666674],[-24.666666666666742,-44.33333333333326],[-38.66666666666674,-31.333333333333258],[-50.33333333333326,-16.666666666666742],[-106,0],[-78.66666666666663,52.33333333333326],[-43.33333333333337,99.66666666666674],[0,146],[43.66666666666663,99.33333333333337],[78.66666666666663,50.666666666666686],[58,0],[49.66666666666674,-15.333333333333314],[38.66666666666674,-29.666666666666686],[25.666666666666742,-42.66666666666663],[0,0],[-11.333333333333258,94],[-45,87],[-75.66666666666674,68.33333333333333],[-104.33333333333326,39.666666666666664],[-182.66666666666663,0],[-143.66666666666669,-82.66666666666666],[-83,-156.66666666666663],[0,-223.33333333333326],[84,-156.66666666666674],[144,-82.33333333333326],[118.66666666666674,0],[101.66666666666674,33.33333333333326],[78.66666666666674,63.66666666666674],[49.66666666666674,92],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-103.76818181818182,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[596,-888],[596,0],[170,0],[170,-2048],[584,-2048],[584,-1265],[602,-1265],[770,-1478.5],[1061,-1556],[1340.5,-1486.5],[1526.5,-1287.5],[1592,-978],[1592,0],[1166,0],[1166,-902],[1094.5,-1123],[892,-1202],[738.5,-1165],[634.5,-1057.5],[596,-888]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[-77.33333333333337,51.66666666666674],[-116.66666666666663,0],[-79.66666666666674,-46.33333333333326],[-44.33333333333326,-86.33333333333326],[0.6666666666667425,-120],[0,0],[0,0],[0,0],[48.33333333333326,52.66666666666674],[86.66666666666663,0],[44.33333333333337,-24.666666666666742],[25,-47],[0.6666666666666288,-66]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[34.66666666666663,-90.66666666666674],[77.33333333333337,-51.66666666666674],[106.66666666666674,0],[79.66666666666674,46.33333333333326],[44.33333333333326,86.33333333333326],[0,0],[0,0],[0,0],[0.6666666666667425,-94.66666666666663],[-48.33333333333326,-52.66666666666674],[-58,0],[-44.33333333333337,24.666666666666742],[-25,47],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-79.70454545454545,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[608,29],[346,-22.5],[164.5,-175.5],[98,-429],[145,-644],[273,-784],[457.5,-864],[675,-902],[891,-928.5],[1010,-966],[1047,-1040],[1047,-1046],[987.5,-1193],[819,-1245],[636,-1194.5],[546,-1068],[152,-1100],[270,-1342.5],[497.5,-1500.5],[821,-1556],[1066.5,-1526],[1275.5,-1433],[1420,-1271.5],[1473,-1036],[1473,0],[1069,0],[1069,-213],[1057,-213],[958,-86.5],[809,-1.5],[608,29]],"i":[[0,0],[76.66666666666669,34.333333333333336],[44.33333333333334,67.66666666666667],[0,101.33333333333331],[-31.33333333333333,58],[-54,35.33333333333337],[-69,18],[-76,7.333333333333371],[-54.66666666666663,8.333333333333371],[-24.66666666666663,16.66666666666663],[0,32.66666666666663],[0,0],[39.66666666666674,34.66666666666674],[72.66666666666663,0],[45.33333333333337,-33.66666666666674],[14.666666666666629,-50.66666666666674],[0,0],[-58.66666666666666,68.33333333333326],[-93,37],[-122.66666666666663,0],[-78.33333333333337,-20],[-61,-42],[-35.33333333333326,-65.66666666666674],[0,-91.33333333333326],[0,0],[0,0],[0,0],[0,0],[41.33333333333337,-36.33333333333333],[58,-20.333333333333332],[76,0]],"o":[[-98,0],[-76.66666666666669,-34.333333333333336],[-44.33333333333333,-67.66666666666666],[0,-85.33333333333337],[31.333333333333343,-58],[54,-35.33333333333337],[69,-18],[89.33333333333337,-9.333333333333371],[54.66666666666663,-8.333333333333371],[24.666666666666742,-16.66666666666663],[0,0],[0,-63.33333333333326],[-39.66666666666663,-34.66666666666674],[-76.66666666666663,0],[-45.33333333333337,33.66666666666674],[0,0],[20,-93.33333333333326],[58.666666666666686,-68.33333333333326],[93,-37],[85.33333333333337,0],[78.33333333333326,20],[61,42],[35.33333333333326,65.66666666666674],[0,0],[0,0],[0,0],[0,0],[-24.666666666666742,48],[-41.33333333333337,36.333333333333336],[-58,20.333333333333332],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[730,-265],[896,-302.5],[1009,-404],[1050,-549],[1050,-712],[995.5,-688.5],[918,-669.5],[832,-654.5],[754,-643],[623,-608],[536,-543.5],[505,-443],[568.5,-310.5],[730,-265]],"i":[[0,0],[-48,25],[-27.33333333333337,42.666666666666686],[0,54],[0,0],[23,-7],[28.66666666666663,-5.666666666666629],[28.66666666666663,-4.333333333333371],[23.33333333333337,-3.3333333333333712],[37.33333333333337,-16],[20.66666666666663,-27],[0,-40],[-42.33333333333337,-30.333333333333314],[-65.33333333333337,0]],"o":[[62.66666666666663,0],[48,-25],[27.333333333333258,-42.666666666666686],[0,0],[-13.333333333333258,8.666666666666629],[-23,7],[-28.66666666666663,5.666666666666629],[-28.66666666666663,4.333333333333371],[-50,7.333333333333371],[-37.33333333333337,16],[-20.66666666666663,27],[0,58],[42.33333333333337,30.333333333333314],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-59.731818181818184,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[987,-1536],[987,-1216],[62,-1216],[62,-1536],[987,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[272,-1904],[698,-1904],[698,-472],[716,-380.5],[766.5,-335],[842,-322],[902,-327.5],[948,-336],[1015,-19],[925,4.5],[784,21],[514.5,-20],[335,-166],[272,-416],[272,-1904]],"i":[[0,0],[0,0],[0,0],[-12,-21.666666666666686],[-21.66666666666663,-8.666666666666686],[-28.66666666666663,0],[-20,3.6666666666666856],[-10.666666666666629,2],[0,0],[38.66666666666663,-9],[55.33333333333337,-2],[77,31.333333333333336],[42.666666666666686,66],[-0.6666666666666856,100.66666666666669],[0,0]],"o":[[0,0],[0,0],[0,39.333333333333314],[12,21.666666666666686],[21.66666666666663,8.666666666666686],[20,0],[20,-3.6666666666666856],[0,0],[-21.33333333333337,6.666666666666666],[-38.66666666666663,9],[-102.66666666666663,4],[-77,-31.333333333333336],[-42.666666666666686,-66],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-41.16818181818182,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[-28.7409090909091,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[996,-1536],[996,-1216],[48,-1216],[48,-1536],[996,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[265,0],[265,-1647],[330.5,-1924],[510,-2089],[769,-2144],[948.5,-2129],[1070,-2102],[994,-1782],[932.5,-1797],[858,-1804],[727,-1760.5],[690,-1639],[690,0],[265,0]],"i":[[0,0],[0,0],[-43.666666666666686,73.33333333333326],[-76,36.666666666666515],[-96.66666666666663,0],[-54.33333333333337,-10],[-26.666666666666742,-8],[0,0],[24.33333333333337,4.6666666666667425],[25.33333333333337,0],[24.66666666666663,-29],[0,-52],[0,0],[0,0]],"o":[[0,0],[0,-111.33333333333326],[43.666666666666686,-73.33333333333326],[76,-36.666666666666515],[65.33333333333337,0],[54.33333333333337,10],[0,0],[-16.66666666666663,-5.3333333333332575],[-24.33333333333337,-4.6666666666667425],[-62.66666666666663,0],[-24.66666666666663,29],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-21.322727272727278,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[864,30],[461.5,-69.5],[200,-347.5],[108,-762],[200,-1178.5],[461.5,-1456.5],[864,-1556],[1266.5,-1456.5],[1528,-1178.5],[1620,-762],[1528,-347.5],[1266.5,-69.5],[864,30]],"i":[[0,0],[113,66.33333333333333],[61.333333333333314,119],[0,157.33333333333337],[-61.33333333333334,119],[-113,66.33333333333326],[-155.33333333333337,0],[-113,-66.33333333333326],[-61.33333333333326,-119],[0,-158.66666666666663],[61.33333333333326,-119],[113,-66.33333333333334],[155.33333333333337,0]],"o":[[-155.33333333333337,0],[-113,-66.33333333333334],[-61.33333333333334,-119],[0,-158.66666666666663],[61.333333333333314,-119],[113,-66.33333333333326],[155.33333333333337,0],[113,66.33333333333326],[61.33333333333326,119],[0,157.33333333333337],[-61.33333333333326,119],[-113,66.33333333333333],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[866,-300],[1043,-360.5],[1150.5,-526],[1187,-765],[1150.5,-1004],[1043,-1170],[866,-1231],[686.5,-1170],[577.5,-1004],[541,-765],[577.5,-526],[686.5,-360.5],[866,-300]],"i":[[0,0],[-47.33333333333337,40.333333333333314],[-24.333333333333258,70],[0,89.33333333333337],[24.333333333333258,70],[47.33333333333326,40.66666666666674],[70.66666666666663,0],[48.33333333333337,-40.66666666666674],[24.33333333333337,-70],[0,-89.33333333333337],[-24.33333333333337,-70],[-48.33333333333337,-40.333333333333314],[-71.33333333333337,0]],"o":[[70.66666666666663,0],[47.33333333333326,-40.333333333333314],[24.333333333333258,-70],[0,-89.33333333333337],[-24.333333333333258,-70],[-47.33333333333337,-40.66666666666674],[-71.33333333333337,0],[-48.33333333333337,40.66666666666674],[-24.33333333333337,70],[0,89.33333333333337],[24.33333333333337,70],[48.33333333333337,40.333333333333314],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[-9.604545454545459,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[170,0],[170,-1536],[583,-1536],[583,-1268],[599,-1268],[740,-1484.5],[968,-1558],[1037,-1554],[1102,-1543],[1102,-1165],[1019,-1181],[922,-1188],[754.5,-1147.5],[638.5,-1035],[596,-869],[596,0],[170,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[-66,49],[-86,0],[-24.66666666666663,-2.6666666666667425],[-18.666666666666742,-4.6666666666667425],[0,0],[35.33333333333326,4.6666666666667425],[29.33333333333337,0],[49,-27],[28.33333333333337,-48],[0,-62.66666666666663],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[28,-95.33333333333326],[66,-49],[21.33333333333337,0],[24.666666666666742,2.6666666666667425],[0,0],[-20,-6],[-35.33333333333337,-4.6666666666667425],[-62.66666666666663,0],[-49,27],[-28.33333333333337,48],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[10.031818181818181,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"tr","p":{"a":0,"k":[23.11363636363636,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[996,-1536],[996,-1216],[48,-1216],[48,-1536],[996,-1536]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[265,0],[265,-1647],[330.5,-1924],[510,-2089],[769,-2144],[948.5,-2129],[1070,-2102],[994,-1782],[932.5,-1797],[858,-1804],[727,-1760.5],[690,-1639],[690,0],[265,0]],"i":[[0,0],[0,0],[-43.666666666666686,73.33333333333326],[-76,36.666666666666515],[-96.66666666666663,0],[-54.33333333333337,-10],[-26.666666666666742,-8],[0,0],[24.33333333333337,4.6666666666667425],[25.33333333333337,0],[24.66666666666663,-29],[0,-52],[0,0],[0,0]],"o":[[0,0],[0,-111.33333333333326],[43.666666666666686,-73.33333333333326],[76,-36.666666666666515],[65.33333333333337,0],[54.33333333333337,10],[0,0],[-16.66666666666663,-5.3333333333332575],[-24.33333333333337,-4.6666666666667425],[-62.66666666666663,0],[-24.66666666666663,29],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[30.531818181818167,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[170,0],[170,-1536],[583,-1536],[583,-1268],[599,-1268],[740,-1484.5],[968,-1558],[1037,-1554],[1102,-1543],[1102,-1165],[1019,-1181],[922,-1188],[754.5,-1147.5],[638.5,-1035],[596,-869],[596,0],[170,0]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0],[-66,49],[-86,0],[-24.66666666666663,-2.6666666666667425],[-18.666666666666742,-4.6666666666667425],[0,0],[35.33333333333326,4.6666666666667425],[29.33333333333337,0],[49,-27],[28.33333333333337,-48],[0,-62.66666666666663],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[28,-95.33333333333326],[66,-49],[21.33333333333337,0],[24.666666666666742,2.6666666666667425],[0,0],[-20,-6],[-35.33333333333337,-4.6666666666667425],[-62.66666666666663,0],[-49,27],[-28.33333333333337,48],[0,0],[0,0],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[42.86818181818181,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[55.13181818181819,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[870,30],[462.5,-66.5],[200,-340.5],[108,-761],[200,-1177],[459.5,-1456],[853,-1556],[1136.5,-1507.5],[1366.5,-1362],[1520,-1118.5],[1575,-776],[1575,-659],[278,-659],[278,-923],[1174,-923],[1134,-1086],[1023.5,-1197.5],[860,-1238],[688.5,-1193.5],[572,-1074.5],[529,-909],[529,-658],[571.5,-461],[692,-333],[877,-288],[1007,-308],[1108,-368],[1172,-466],[1566,-440],[1443.5,-192.5],[1205.5,-28.5],[870,30]],"i":[[0,0],[113.66666666666663,64.33333333333333],[61.333333333333314,118.33333333333334],[0,162],[-61.33333333333334,119.33333333333326],[-111.66666666666669,66.66666666666674],[-150.66666666666663,0],[-87.66666666666674,-32.33333333333326],[-65.66666666666674,-64.66666666666674],[-36.66666666666674,-97.66666666666674],[0,-130.66666666666663],[0,0],[0,0],[0,0],[0,0],[26.666666666666742,47.33333333333326],[47,27],[62,0],[49.66666666666663,-29.666666666666742],[28,-49.66666666666674],[0.6666666666666288,-60.66666666666663],[0,0],[-28.33333333333337,-55.33333333333337],[-52,-30],[-71.33333333333337,0],[-39.33333333333337,13.333333333333314],[-28,26.666666666666686],[-14.666666666666742,38.666666666666686],[0,0],[61.66666666666674,-70.33333333333331],[97,-39],[126.66666666666663,0]],"o":[[-158,0],[-113.66666666666669,-64.33333333333334],[-61.33333333333334,-118.33333333333331],[0,-158],[61.333333333333314,-119.33333333333326],[111.66666666666663,-66.66666666666674],[101.33333333333337,0],[87.66666666666674,32.33333333333326],[65.66666666666674,64.66666666666674],[36.66666666666674,97.66666666666663],[0,0],[0,0],[0,0],[0,0],[0,-61.33333333333337],[-26.666666666666742,-47.33333333333326],[-47,-27],[-64.66666666666663,0],[-49.66666666666663,29.666666666666742],[-28,49.66666666666674],[0,0],[0,76],[28.33333333333337,55.333333333333314],[52,30],[47.33333333333337,0],[39.33333333333326,-13.333333333333314],[28,-26.666666666666686],[0,0],[-20,94.66666666666669],[-61.66666666666674,70.33333333333333],[-97,39],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[74.25909090909092,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[679,-2048],[640,-614],[274,-614],[234,-2048],[679,-2048]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[457,26],[287,-44.5],[217,-214],[287,-382],[457,-452],[624,-382],[697,-214],[662.5,-93.5],[575,-6.5],[457,26]],"i":[[0,0],[47.333333333333314,47],[-0.6666666666666572,66],[-47.33333333333334,46.666666666666686],[-66,0],[-48,-46.666666666666686],[-0.6666666666666288,-65.33333333333331],[22.33333333333337,-36.33333333333334],[36,-21.666666666666668],[42.666666666666686,0]],"o":[[-66,0],[-47.33333333333334,-47],[-0.6666666666666572,-65.33333333333331],[47.333333333333314,-46.666666666666686],[63.33333333333337,0],[48,46.666666666666686],[-0.6666666666666288,44],[-22.33333333333337,36.333333333333336],[-36,21.666666666666664],[0,0]]}}},{"ty":"tr","p":{"a":0,"k":[93.38636363636364,11.636363636363637],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[1.1363636363636365,1.1363636363636365],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[144,32],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":37,"ty":4,"nm":"Framebackground","sr":1,"ks":{"p":{"a":0,"k":[1,1],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"gr","nm":"Framebackground","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[288,64],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":12,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0.984313725490196,0.984313725490196,0.984313725490196],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[144,32],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"ind":38,"ty":4,"nm":"Frameregion-box","sr":1,"ks":{"p":{"a":0,"k":[1,1],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[289,66],"ix":2},"p":{"a":0,"k":[143.5,32],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":1001,"st":0,"bm":0}]},{"id":"15","layers":[{"ddd":0,"ind":39,"ty":4,"nm":"Frameregion","sr":1,"ks":{"p":{"a":0,"k":[1,1],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","nm":"Frameregion","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[288,64],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":12,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[144,32],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"16","w":289,"h":66,"ind":33,"ty":0,"nm":"Frameclippedcontent","sr":1,"ks":{"p":{"a":0,"k":[143.5,32],"ix":2},"a":{"a":0,"k":[143.5,32],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"tt":1}]}],"layers":[{"ddd":0,"refId":"0","ind":40,"ty":2,"nm":"image.png1","sr":1,"ks":{"p":{"a":0,"k":[911.76171875,121.62176513671875],"ix":2},"a":{"a":0,"k":[391,286],"ix":2},"s":{"a":0,"k":[14.995326469263794,14.995326469263794],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":1,"k":[{"t":0,"s":[30],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":232,"s":[50],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"hd":true},{"ddd":0,"ind":41,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":1,"k":[{"t":0,"s":[959.6658935546875,209.0797119140625],"i":{"x":[0.3103448275862069],"y":[1.2340233236151605]},"o":{"x":[0.7183908045977011],"y":[-0.14247813411078716]}},{"t":112,"s":[909.6658935546875,117.07970428466797],"i":{"x":[0.20689655172413793],"y":[1]},"o":{"x":[0.5747126436781609],"y":[0]},"ti":[-1.0761726231820603,0.09065348765017234],"to":[0.7808549268390834,0.9268218785459936]},{"t":232,"s":[912.6749737389355,118.29273524305671],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]},"ti":[-0.1305790710346173,1.5557536049660996],"to":[1.4187811672674115,-0.11951378269117185]},{"t":468,"s":[915.51123046875,115.68537902832031],"i":{"x":[0.3275862068965517],"y":[1]},"o":{"x":[0.29310344827586204],"y":[0]},"ti":[2.264897108078003,0.5765799283981323],"to":[-0.4602566659450531,5.042131423950195]},{"t":634,"s":[907.1356201171875,120.38156127929688],"i":{"x":[0.25287356321839083],"y":[1]},"o":{"x":[0.6954022988505747],"y":[0]}},{"t":802,"s":[907.1356201171875,120.38156127929688],"i":{"x":[0.367816091954023],"y":[1]},"o":{"x":[0.6781609195402298],"y":[0]},"ti":[-1.502036452293396,1.8851877450942993],"to":[1.9820387363433838,-0.10556070506572723]},{"t":960,"s":[912.6749877929688,118.29273223876953],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[16.043582558631897,16.043582558631897],"ix":2},"r":{"a":0,"k":-17.14939907605087,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0},{"ddd":0,"refId":"1","w":351,"h":364,"ind":42,"ty":0,"nm":"小绿","sr":1,"ks":{"p":{"a":0,"k":[-176,-155],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":1,"k":[{"t":0,"s":[0],"i":{"x":[0.28735632183908044],"y":[1.3242857142857145]},"o":{"x":[0.7126436781609196],"y":[0]}},{"t":112,"s":[100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"parent":41},{"ddd":0,"refId":"13","w":1282,"h":426,"ind":43,"ty":0,"nm":"CTA","sr":1,"ks":{"p":{"a":0,"k":[641,213],"ix":2},"a":{"a":0,"k":[641,213],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":1001,"st":0,"bm":0,"hd":true}],"markers":[]}'),
                loop: !1,
                autoplay: !1
            };
            var Ge = function(e) {
                const {
                    style: t,
                    AnchorRef: a
                } = e, i = {
                    pointerEvents: "none",
                    position: "absolute",
                    top: "-204px",
                    left: "8px",
                    transform: "translateX(-70%)",
                    zIndex: 1,
                    width: 1200,
                    height: 500,
                    ...t
                }, {
                    View: s,
                    playSegments: A
                } = (0, d.useLottie)(Se, i), o = (0, x.useRef)(), r = () => {
                    A([0, 1e3], !0), o.current = setInterval((() => {
                        A([232, 1e3], !0)
                    }), 7700)
                };
                return (0, x.useEffect)((() => {
                    const e = new IntersectionObserver((t => {
                        t.forEach((t => {
                            t.isIntersecting && (r(), e.disconnect())
                        }))
                    }));
                    return (null == a ? void 0 : a.current) && e.observe(a.current), () => {
                        (null == a ? void 0 : a.current) && e.unobserve(a.current), clearInterval(o.current)
                    }
                }), []), {
                    FeatureArtLottieView: s,
                    appear: r
                }
            };
            const Te = {
                animationData: JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":100,"w":564,"h":427,"nm":"Comp1","ddd":0,"metadata":{},"assets":[],"layers":[{"ddd":0,"ind":1,"ty":4,"nm":"Circle8.svg","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"gr","nm":"Path\'ssolidstroke","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":false,"v":[[283.43821443164484,5.776222155625115],[15.312714431644839,45.522202155625116],[254.10721443164482,104.27700215562511],[340.00021443164485,60.69900215562512],[174.41021443164485,18.520802155625116]],"i":[[0,0],[40.03011703491211,-58.903743743896484],[-86.83299999999997,10.424999999999997],[0,22.079699999999995],[106.65799999999999,-5.400300000000001]],"o":[[-63.995000000000005,-9.216459],[-40.030120849609375,58.90374755859375],[51.95500000000004,-6.236999999999995],[0,-19.008899999999997],[0,0]]}}},{"ty":"tm","s":{"a":1,"k":[{"t":20,"s":[0],"i":{"x":[0.6666666666666666],"y":[1.6193877551020412]},"o":{"x":[0.6724137931034483],"y":[0]}},{"t":71,"s":[100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"e":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"st","c":{"a":0,"k":[0.4,0.9294117647058824,0.6823529411764706],"ix":2},"o":{"a":0,"k":100,"ix":2},"w":{"a":0,"k":6,"ix":2},"lc":2,"lj":1,"ml":4,"d":[{"n":"o","nm":"offset","v":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":0,"k":[173.5308837890625,58.00006103515625],"ix":2},"a":{"a":0,"k":[170.00010721582242,54.50006058439392],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":0,"k":[265.9581298828125,186.2444610595703],"ix":2},"a":{"a":0,"k":[173.53089880943298,58.00006127357483],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":101,"st":0,"bm":0}],"markers":[]}'),
                loop: !1,
                autoplay: !1
            };
            var We = function(e) {
                const {
                    style: t,
                    AnchorRef: a
                } = e, i = {
                    pointerEvents: "none",
                    position: "absolute",
                    top: "-146px",
                    left: "57%",
                    transform: "translateX(-50%)",
                    zIndex: 2,
                    width: 800,
                    height: 400,
                    ...t
                }, {
                    View: s,
                    playSegments: A
                } = (0, d.useLottie)(Te, i), o = (0, x.useRef)(), r = () => {
                    A([], !1)
                };
                return (0, x.useEffect)((() => {
                    const e = new IntersectionObserver((t => {
                        t.forEach((t => {
                            t.isIntersecting && (r(), e.disconnect())
                        }))
                    }));
                    return (null == a ? void 0 : a.current) && e.observe(a.current), () => {
                        (null == a ? void 0 : a.current) && e.unobserve(a.current), clearInterval(o.current)
                    }
                }), []), {
                    FeaturePathLottieView: s,
                    appear: r
                }
            };
            const Re = window.innerHeight;
            var Fe = function() {
                    const e = (0, x.useRef)(null),
                        {
                            scrollYProgress: t
                        } = (0, A.v)({
                            target: e
                        }),
                        {
                            currentLanguage: a
                        } = (0, ge.Z)(),
                        i = a === ye.i.en || a === ye.i["zh-cn"] || a === ye.i["zh-hk"] || a === ye.i.es,
                        r = (0, p.useTranslations)(),
                        l = (0, x.useRef)(null),
                        d = (0, x.useRef)(null),
                        k = (0, x.useRef)(null),
                        g = (0, x.useRef)(null),
                        y = (0, x.useRef)(null),
                        u = (0, x.useRef)(null),
                        h = (0, x.useRef)(null),
                        m = (0, x.useRef)(null),
                        f = (0, x.useRef)(null),
                        v = (0, x.useRef)(null),
                        {
                            FeatureArtLottieView: w
                        } = Ge({
                            AnchorRef: l
                        }),
                        {
                            FeaturePathLottieView: b
                        } = We({
                            AnchorRef: l
                        }),
                        B = Re / 2 + 225,
                        [C, Q] = (0, x.useState)(B),
                        [E, I] = (0, x.useState)(B),
                        [H, P] = (0, x.useState)(B),
                        [j, M] = (0, x.useState)(!1),
                        [O, N] = (0, x.useState)(!1),
                        [Y, L] = (0, x.useState)({
                            textOpacity: 0,
                            imgOpacity: 0,
                            translateY: 0,
                            bgOpacity: 0
                        }),
                        [z, J] = (0, x.useState)("autoUpdate"),
                        [S, G] = (0, x.useState)(0),
                        [T, W] = (0, x.useState)({
                            cardCreate: !1,
                            cardEdit: !1,
                            cardPublic: !1
                        }),
                        R = (0, x.useRef)(null),
                        F = (0, x.useRef)(null),
                        X = (0, x.useRef)(null),
                        [U, Z] = (0, x.useState)(0),
                        K = (0, o.H)(t, he, me).get(),
                        q = (0, o.H)(t, fe, ve).get(),
                        _ = (0, o.H)(t, we, be).get(),
                        $ = (0, o.H)(t, Be, Ce).get(),
                        ee = (0, n.Z)((() => {
                            W({
                                cardCreate: !1,
                                cardEdit: !1,
                                cardPublic: !1
                            })
                        }), 300),
                        te = () => {
                            if (window.innerWidth > 1024) return void Z(0);
                            const e = window.innerWidth - 1024;
                            Z(e / 2)
                        };
                    (0, Ae.W)(t, "change", (e => {
                        var t;
                        (e => {
                            const t = window.innerHeight / 2 + 300 - q * e;
                            e > 0 && e < Qe ? (d.current = null, k.current = null, g.current = null, Q(t)) : e >= Qe && e <= Ee ? (null === d.current && (d.current = t), Q(d.current + q / 16 * (e - Qe))) : (e > Ee && e <= De && (null === k.current && (k.current = C), Q(k.current - q / 16 * (e - Ee))), e > De && (null === g.current && (g.current = C), Q(g.current - q * (e - De))))
                        })(e), (e => {
                            const t = window.innerHeight / 2 - _ * e,
                                a = Re < 900 ? .13 : .16;
                            e > 0 && e < a ? (y.current = null, u.current = null, h.current = null, I(t)) : e >= a && e <= .28 ? (null === y.current && (y.current = t), I(y.current + _ / 12 * (e - a))) : (e > .28 && e <= .32 && (null === u.current && (u.current = E), I(u.current - _ / 8 * (e - .28))), e > .32 && (null === h.current && (h.current = E), I(h.current - _ * (e - .32))))
                        })(e - .25), (e => {
                            const t = Re < 900 ? .115 : .13,
                                a = window.innerHeight / 2 - $ * e;
                            e > 0 && e < t ? (m.current = null, f.current = null, v.current = null, P(a)) : e >= t && e <= .28 ? (null === m.current && (m.current = a), P(m.current + $ / 16 * (e - t))) : (e > .28 && e <= .35 && (null === f.current && (f.current = H), P(f.current - $ / 8 * (e - .28))), e > .35 && (null === v.current && (v.current = H), P(v.current - $ * (e - .35))))
                        })(e - .28), (e => {
                            const t = K * e;
                            G(t > 4 ? 4 : t)
                        })(e - .25), (t = e) <= Ie ? L({
                            textOpacity: 0,
                            imgOpacity: 0,
                            translateY: 0,
                            bgOpacity: 0
                        }) : (t > Ie && L({
                            textOpacity: 0,
                            imgOpacity: 0,
                            translateY: 0,
                            bgOpacity: 1
                        }), t < He ? L({
                            textOpacity: 0,
                            imgOpacity: 0,
                            translateY: 0,
                            bgOpacity: 1
                        }) : (t >= He && L({
                            textOpacity: 1,
                            imgOpacity: 0,
                            translateY: 0,
                            bgOpacity: 1
                        }), t >= Pe && L({
                            textOpacity: 1,
                            imgOpacity: 1,
                            translateY: 1,
                            bgOpacity: 0
                        }))), (e => {
                            e <= .365 && M(!1), e > .365 && M(!0), e > .583 && M(!1)
                        })(e), (e => {
                            e <= .383 && N(!1), e > .383 && N(!0), e > .654 && N(!1)
                        })(e)
                    }));
                    const ae = () => {
                        window.scrollTo(0, 0)
                    };
                    return (0, x.useEffect)((() => (ae(), te(), window.addEventListener("resize", te), () => {
                        window.removeEventListener("resize", te), window.removeEventListener("load", ae)
                    })), []), (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsxs)("div", {
                            ref: e,
                            "data-follow-hidden": !0,
                            className: "w-full bg-black relative h-[6000px] mt-[-1500px]",
                            children: [(0, s.jsxs)("div", {
                                className: "text-white text-center mt-[1600px] transition-all duration-500",
                                children: [(0, s.jsx)("div", {
                                    style: {
                                        color: "rgba(130 130 130"
                                    },
                                    className: "font-Damion font-normal text-[40px] leading-[60px]",
                                    children: r("Home_Feature_Subtitle")
                                }), (0, s.jsx)("h1", {
                                    className: "text-[48px] font-bold leading-10 text-center",
                                    children: r("Home_Feature_Title")
                                })]
                            }), (0, s.jsx)("div", {
                                style: {
                                    opacity: Y.bgOpacity,
                                    display: Y.bgOpacity > 0 ? "flex" : "none"
                                },
                                className: "w-full flex justify-center items-center fixed transition-all duration-500 top-[50%] translate-y-[-50%]",
                                children: (0, s.jsx)(oe.default, {
                                    className: "w-[1018px] h-[680px]",
                                    src: de,
                                    alt: "Image"
                                })
                            }), (0, s.jsxs)("div", {
                                className: "h-screen w-full sticky top-0 flex justify-center items-center",
                                children: [(0, s.jsxs)("div", {
                                    "data-follow-hidden": !0,
                                    className: "w-full overflow-hidden flex z-20 relative justify-center items-center gap-4 h-screen",
                                    children: [(0, s.jsx)("div", {
                                        style: {
                                            transform: "translate(0, ".concat(C, "px) rotate(").concat(-S, "deg)"),
                                            zIndex: T.cardCreate ? 1 : 0
                                        },
                                        children: (0, s.jsx)(Je, {
                                            children: (0, s.jsxs)("div", {
                                                onMouseEnter: () => {
                                                    W({
                                                        cardCreate: !0,
                                                        cardEdit: !1,
                                                        cardPublic: !1
                                                    }), R.current && (R.current.currentTime = 0)
                                                },
                                                onMouseLeave: ee,
                                                className: c()(Me()["feature-card"]),
                                                children: [(0, s.jsx)("div", {
                                                    className: "p-5 leading-[100%]",
                                                    children: r("Home_Feature_Build")
                                                }), (0, s.jsxs)("div", {
                                                    className: "relative",
                                                    children: [(0, s.jsx)(oe.default, {
                                                        className: "absolute top-0",
                                                        src: ne,
                                                        alt: ""
                                                    }), (0, s.jsxs)(s.Fragment, {
                                                        children: [(0, s.jsx)(D, {
                                                            ref: R,
                                                            className: "w-full ".concat(T.cardCreate ? "block" : "hidden"),
                                                            muted: !0,
                                                            loop: !0,
                                                            src: "".concat(pe.QX, "/assets/video/FeartureCreate.mp4")
                                                        }), (0, s.jsx)(oe.default, {
                                                            "data-follow-hidden": !0,
                                                            className: "w-full ".concat(T.cardCreate ? "hidden" : "block"),
                                                            width: 380,
                                                            height: 380,
                                                            src: le,
                                                            alt: "create"
                                                        })]
                                                    })]
                                                })]
                                            })
                                        })
                                    }), 0 === U && (0, s.jsx)(oe.default, {
                                        className: "".concat(j ? "opacity-100" : "opacity-0", " transition-all translate-y-[-40px]"),
                                        width: 50,
                                        height: 50,
                                        src: re,
                                        alt: "arrow"
                                    }), (0, s.jsx)("div", {
                                        style: {
                                            transform: "translate(0, ".concat(E, "px) rotate(0deg)"),
                                            marginLeft: U,
                                            zIndex: T.cardEdit ? 1 : 0
                                        },
                                        children: (0, s.jsx)(Je, {
                                            children: (0, s.jsxs)("div", {
                                                onMouseEnter: () => {
                                                    W({
                                                        cardCreate: !1,
                                                        cardEdit: !0,
                                                        cardPublic: !1
                                                    }), X.current && (X.current.currentTime = 0)
                                                },
                                                onMouseLeave: ee,
                                                className: c()(Me()["feature-card"]),
                                                children: [(0, s.jsx)("div", {
                                                    className: "p-5 leading-[100%]",
                                                    children: r("Home_Feature_Edit")
                                                }), (0, s.jsxs)("div", {
                                                    className: "relative",
                                                    children: [(0, s.jsx)(oe.default, {
                                                        className: "absolute top-0",
                                                        src: ne,
                                                        alt: ""
                                                    }), (0, s.jsxs)(s.Fragment, {
                                                        children: [(0, s.jsx)(D, {
                                                            ref: X,
                                                            className: "".concat(T.cardEdit ? "block" : "hidden"),
                                                            muted: !0,
                                                            loop: !0,
                                                            src: "".concat(pe.QX, "/assets/video/FeatureEdit.mp4")
                                                        }, "edit"), (0, s.jsx)(oe.default, {
                                                            "data-follow-hidden": !0,
                                                            className: "w-full ".concat(T.cardEdit ? "hidden" : "block"),
                                                            width: 340,
                                                            height: 340,
                                                            src: ce,
                                                            alt: "Edit easily"
                                                        })]
                                                    })]
                                                })]
                                            })
                                        })
                                    }), 0 === U && (0, s.jsx)(oe.default, {
                                        className: "".concat(O ? "opacity-100" : "opacity-0", " transition-all translate-y-[-40px]"),
                                        width: 50,
                                        height: 50,
                                        src: re,
                                        alt: "arrow"
                                    }), (0, s.jsx)("div", {
                                        style: {
                                            transform: "translate(0, ".concat(H, "px) rotate(").concat(S, "deg)"),
                                            marginLeft: U,
                                            zIndex: T.cardPublic ? 1 : 0
                                        },
                                        children: (0, s.jsx)(Je, {
                                            children: (0, s.jsxs)("div", {
                                                onMouseEnter: () => {
                                                    W({
                                                        cardCreate: !1,
                                                        cardEdit: !1,
                                                        cardPublic: !0
                                                    }), F.current && (F.current.currentTime = 0)
                                                },
                                                onMouseLeave: ee,
                                                className: c()(Me()["feature-card"]),
                                                children: [(0, s.jsx)("div", {
                                                    className: "p-5 leading-[100%]",
                                                    children: r("Home_Feature_Public")
                                                }), (0, s.jsxs)("div", {
                                                    className: "relative",
                                                    children: [(0, s.jsx)(oe.default, {
                                                        className: "absolute top-0",
                                                        src: ne,
                                                        alt: ""
                                                    }), (0, s.jsxs)(s.Fragment, {
                                                        children: [(0, s.jsx)(D, {
                                                            className: "w-full ".concat(T.cardPublic ? "block" : "hidden"),
                                                            ref: F,
                                                            muted: !0,
                                                            loop: !0,
                                                            src: "".concat(pe.QX, "/assets/video/FeaturePublic.mp4")
                                                        }, "public"), (0, s.jsx)(oe.default, {
                                                            "data-follow-hidden": !0,
                                                            className: "".concat(T.cardPublic ? "hidden" : "block"),
                                                            width: 340,
                                                            height: 340,
                                                            src: ke,
                                                            alt: "public"
                                                        })]
                                                    })]
                                                })]
                                            })
                                        })
                                    })]
                                }), (0, s.jsx)("div", {
                                    className: "".concat(Y.translateY ? "z-30" : "z-10", " h-screen absolute top-0 w-full flex flex-col justify-center items-center"),
                                    children: (0, s.jsxs)("div", {
                                        className: "".concat(Y.translateY ? "translate-y-0" : "translate-y-[250px]", " flex flex-col items-center transition-all duration-500"),
                                        children: [(0, s.jsx)("div", {
                                            className: "".concat(Y.textOpacity ? "opacity-1" : "opacity-0", " transition-all duration-300 text-[34px] font-bold text-white text-center mb-7"),
                                            children: r("Home_Feature_AITeam")
                                        }), (0, s.jsxs)("div", {
                                            className: "".concat(Y.imgOpacity ? "opacity-1" : "opacity-0", " w-fit transition-all duration-500 bg-[#0E0E0E] border-[2px] border-[#232323] p-3 rounded-[20px] flex gap-6 justify-start"),
                                            children: [(0, s.jsxs)("div", {
                                                className: "w-[305px] flex flex-col gap-2 py-2 pl-2",
                                                children: [(0, s.jsx)("div", {
                                                    onClick: () => J("autoUpdate"),
                                                    className: "".concat("autoUpdate" === z ? "bg-white/10 px-[14px]" : "text-white/60 hover:bg-white/10 hover:px-[14px]", " transition-all duration-500 text-xl font-normal leading-6 text-white py-[14px] rounded-[10px]"),
                                                    children: r("Home_Feature_AutoUpdate")
                                                }), (0, s.jsx)("div", {
                                                    onClick: () => J("digitalHuman"),
                                                    className: "".concat("digitalHuman" === z ? "bg-white/10 px-[14px]" : "text-white/60 hover:bg-white/10 hover:px-[14px]", " transition-all duration-500 text-xl font-normal leading-6 text-white py-[14px] rounded-[10px]"),
                                                    children: r("Home_Feature_DigitalHuman")
                                                })]
                                            }), (0, s.jsxs)("div", {
                                                className: "w-[440px] h-[440px] rounded-[10px] border-[2px] border-[#FFFFFF1A] overflow-hidden",
                                                children: ["autoUpdate" === z && (0, s.jsx)(D, {
                                                    onEnded: () => J("digitalHuman"),
                                                    className: "w-full",
                                                    muted: !0,
                                                    src: "".concat(pe.QX, "/assets/video/autoUpdate.mp4")
                                                }), "digitalHuman" === z && (0, s.jsx)(D, {
                                                    onEnded: () => J("autoUpdate"),
                                                    className: "w-full",
                                                    muted: !0,
                                                    src: "".concat(pe.QX, "/assets/video/digitalHuman.mp4")
                                                })]
                                            })]
                                        })]
                                    })
                                })]
                            })]
                        }), (0, s.jsxs)("div", {
                            "data-follow-hidden": !0,
                            className: "w-full overflow-hidden z-10 bg-black pt-[40px] pb-[156px]",
                            children: [(0, s.jsxs)("div", {
                                "data-follow-hidden": !0,
                                className: "flex flex-col xl:flex-row gap-[100px] xl:gap-56 justify-center items-center text-center xl:text-start",
                                children: [(0, s.jsx)("div", {
                                    className: "font-bold text-[56px] md:w-[600px] text-white",
                                    children: r("Home_Feature_CTATitle")
                                }), (0, s.jsxs)("div", {
                                    className: "relative",
                                    children: [w, !i && (0, s.jsx)(oe.default, {
                                        width: 100,
                                        height: 100,
                                        className: "absolute bottom-[5px] left-[0px] w-full h-full z-0 scale-y-150 scale-x-[1.4]",
                                        src: xe,
                                        alt: "CirclePath"
                                    }), i && b, (0, s.jsx)(V.Z, {
                                        onClick: () => {
                                            window.location.href = "https://wegic.ai/app?fromHome=website_cta1"
                                        },
                                        type: "primary",
                                        status: "plain",
                                        className: c()(Me().button_cta),
                                        children: r("Home_Feature_CTAText")
                                    })]
                                })]
                            }), (0, s.jsx)("div", {
                                ref: l,
                                className: "w-[1px] ml-3 h-[1px]"
                            })]
                        })]
                    })
                },
                Xe = a(37962),
                Ue = a(72449),
                Ve = {
                    src: "https://cdn.wegic.ai/_next/static/media/enter.f807f07b.png",
                    height: 40,
                    width: 52,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAATUlEQVR42i2JsQ2AMBADrwIShEI+KViBEiFRwhrsPwlXIMu2fIZE/VVYydCNUU8ECw1r4GL3fdhEVL+Xm4OTWUwXNPFgZxeJoKgQBukDwJoD3EkBmwUAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                Ze = JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":150,"w":40,"h":24,"nm":"Comp 1","ddd":0,"assets":[],"layers":[{"ddd":0,"ind":1,"ty":4,"nm":"3","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[3,1.5],[1.4999981316396855,3],[0,1.5],[1.4999981316396855,0],[3,1.5]],"i":[[0,0],[0.8284270515841827,0],[0,0.8284270515841827],[-0.8284270515841827,0],[0,-0.8284270515841827]],"o":[[0,0.8284270515841827],[-0.8284270515841827,0],[0,-0.8284270515841827],[0.8284270515841827,0],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":1,"k":[{"t":0,"s":[31.770263671875,11.96875],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":40,"s":[31.770263671875,2.96875],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":80,"s":[31.770263671875,11.96875],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[1.5,1.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":151,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":4,"nm":"2","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[3,1.5],[1.5,3],[0,1.5],[1.5,0],[3,1.5]],"i":[[0,0],[0.8284270515841827,0],[0,0.828427180567555],[-0.8284270515841827,0],[0,-0.828427180567555]],"o":[[0,0.828427180567555],[-0.8284270515841827,0],[0,-0.828427180567555],[0.8284270515841827,0],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":1,"k":[{"t":10,"s":[19.994140625,11.96875],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":50,"s":[19.994140625,2.96875],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":90,"s":[19.994140625,11.96875],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[1.5,1.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":151,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":4,"nm":"1","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[3,1.5],[1.5,3],[0,1.5],[1.5,0],[3,1.5]],"i":[[0,0],[0.8284270515841827,0],[0,0.8284270515841827],[-0.8284270515841827,0],[0,-0.8284270515841827]],"o":[[0,0.8284270515841827],[-0.8284270515841827,0],[0,-0.8284270515841827],[0.8284270515841827,0],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":1,"k":[{"t":20,"s":[8.229736328125,11.96875],"i":{"x":[0.2],"y":[1]},"o":{"x":[0.5],"y":[-0.5]}},{"t":60,"s":[8.229736328125,2.96875],"i":{"x":[0.5],"y":[1.5]},"o":{"x":[0.8],"y":[0]}},{"t":100,"s":[8.229736328125,11.96875],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[1.5,1.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":151,"st":0,"bm":0}],"markers":[]}');
            var Ke = function(e) {
                    return (0, s.jsx)(k(), {
                        animationData: Ze,
                        autoPlay: !0,
                        loop: !0,
                        style: {
                            width: 40,
                            height: 24
                        }
                    })
                },
                qe = a(76235);
            const _e = (e, t, a) => (t && t(), fetch("/api/onepage/anonymous_chat", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ ...e
                })
            }).then((async e => {
                let t = "";
                const i = e.body.pipeThrough(function(e) {
                        const t = new TextDecoder;
                        let a;
                        return new TransformStream({
                            async start(t) {
                                a = (0, qe.j)((function(a) {
                                    if ("event" === a.type) {
                                        const i = a.data;
                                        if ("[DONE]" === i) return void t.terminate();
                                        const s = e(i);
                                        s && t.enqueue(s)
                                    }
                                }))
                            },
                            transform(e) {
                                a.feed(t.decode(e))
                            }
                        })
                    }(function() {
                        const e = function() {
                            let e = !0;
                            return t => (e && (t = t.trimStart()), t && (e = !1), t)
                        }();
                        return t => {
                            const a = JSON.parse(t);
                            var i;
                            return e(null !== (i = a.content) && void 0 !== i ? i : "")
                        }
                    }())),
                    s = i.getReader();
                for (;;) {
                    const {
                        done: e,
                        value: i
                    } = await s.read();
                    if (e) {
                        a && a(t, e);
                        break
                    }
                    for (const s of i) t += s, a && a(t, e), await (0, v.gw)(5)
                }
            })));
            const $e = (0, a(1435).Ue)(((e, t) => ({
                showFollowerCard: !1,
                setShowFollowerCard: t => e((() => ({
                    showFollowerCard: t
                }))),
                followerCardMessage: "",
                setFollowerCardMessage: t => e((() => ({
                    followerCardMessage: t
                })))
            })));
            var et = a(61957),
                tt = a(16331);
            const at = e => {
                    let {
                        message: t = "Magic Your Site Chat by Chat",
                        className: a,
                        duration: i = 15,
                        onComplete: A
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "flex flex-col items-start z-0",
                        children: (0, s.jsx)(tt.M, {
                            children: (0, s.jsx)(it, {
                                text: t,
                                className: a,
                                duration: i,
                                onComplete: A
                            }, t)
                        })
                    })
                },
                it = e => {
                    let {
                        text: t,
                        onComplete: a,
                        className: i,
                        duration: A = 15
                    } = e;
                    const [o, n] = (0, x.useState)("");
                    return (0, x.useEffect)((() => {
                        if (t.length > o.length) {
                            const e = setTimeout((() => {
                                n(t.slice(0, o.length + 1))
                            }), A);
                            return () => clearTimeout(e)
                        }
                        a && "function" == typeof a && a()
                    }), [t, o, a]), (0, s.jsx)(r.E.div, {
                        initial: {
                            opacity: 0
                        },
                        whileInView: {
                            opacity: 1
                        },
                        transition: {
                            duration: .6
                        },
                        className: i,
                        children: (0, s.jsx)("p", {
                            children: o
                        })
                    })
                },
                st = x.forwardRef(((e, t) => {
                    let {
                        className: a,
                        ...i
                    } = e;
                    return (0, s.jsx)("textarea", {
                        className: (0, J.cn)("flex min-h-[80px] w-full rounded-md border border-input bg-background py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", a),
                        ref: t,
                        ...i
                    })
                }));
            st.displayName = "Textarea";
            var At, ot, rt = () => {
                const {
                    showFollowerCard: e,
                    followerCardMessage: t,
                    setShowFollowerCard: a,
                    setFollowerCardMessage: i
                } = $e(), A = (0, x.useRef)(null), [o, l] = (0, x.useState)({
                    x: 0,
                    y: 0
                }), [c, d, k] = (0, Xe.Z)(""), g = c.length > 0, y = (0, x.useRef)(0), [u, h] = (0, Ue.H)(), [m, f] = (0, x.useState)(!1), v = (0, x.useRef)(), [w, b, B] = (0, Xe.Z)(!1), [C, Q] = (0, x.useState)(""), E = (0, x.useRef)([]), D = (0, p.useTranslations)(), I = function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5e3;
                    y.current = window.setTimeout((async () => {
                        var e;
                        if (!u.current) return;
                        f(!0);
                        const {
                            width: t,
                            height: i
                        } = (null === (e = u.current) || void 0 === e ? void 0 : e.getBoundingClientRect()) || {};
                        let s = h(u.current, {
                            width: [t, 65],
                            height: [i, 56]
                        }, {
                            duration: .1
                        });
                        v.current = s, await s.then((() => {})), s = h(u.current, {
                            opacity: 0
                        }, {
                            duration: 3
                        }), v.current = s, s.then((() => {
                            a(!1), Q("")
                        }))
                    }), e)
                }, H = () => {
                    var e;
                    $e.getState().showFollowerCard && (null === (e = v.current) || void 0 === e || e.cancel(), h(u.current, {
                        width: "auto",
                        height: "auto"
                    }, {
                        duration: 0
                    }));
                    clearTimeout(y.current), v.current = void 0, y.current = 0, f(!1)
                };
                return (0, x.useEffect)((() => {
                    const t = (0, n.Z)((t => {
                        var s, o;
                        H();
                        const r = t.target;
                        if (null == r || null === (s = r.closest) || void 0 === s ? void 0 : s.call(r, "[data-follow-hidden]")) return void(e && a(!1));
                        const n = t.clientX,
                            x = t.clientY;
                        l({
                            x: n,
                            y: x
                        });
                        const c = null == r ? void 0 : r.closest("[data-follow-message]"),
                            d = (null == c ? void 0 : c.getAttribute("data-follow-message")) || D("Home_FollowerPointerCard_Message");
                        i(d), !e && a(!0), null === (o = A.current) || void 0 === o || o.focus({
                            preventScroll: !0
                        }), I()
                    }), 16);
                    return document.body.addEventListener("mousemove", t), document.body.addEventListener("mouseover", t), () => {
                        document.body.removeEventListener("mousemove", t), document.body.removeEventListener("mouseover", t)
                    }
                }), [e]), (0, x.useEffect)((() => {
                    const e = e => {
                        const t = k();
                        "Enter" === e.key && t.length > 0 && (H(), b(!0), d(""), E.current.push({
                            content: t,
                            role: "user"
                        }), _e({
                            messageList: E.current
                        }, void 0, ((e, t) => {
                            var a;
                            (B() && b(!1), t) && (E.current.push({
                                content: e,
                                role: "assistant"
                            }), I(), null === (a = A.current) || void 0 === a || a.focus());
                            Q(e)
                        })))
                    };
                    return document.addEventListener("keydown", e), () => {
                        document.removeEventListener("keydown", e)
                    }
                }), []), (0, s.jsx)(r.E.div, {
                    style: {
                        left: "".concat(o.x + 10, "px"),
                        top: "".concat(o.y + 20, "px")
                    },
                    className: "fixed z-50",
                    children: e && (0, s.jsx)(r.E.div, {
                        ref: u,
                        className: "min-w-12 max-w-[19rem] text-base w-fit min-h-12 px-4 py-3 shadow-button rounded-xl bg-white transition-all duration-300",
                        children: w ? (0, s.jsx)(Ke, {}) : m ? (0, s.jsx)(r.E.div, {
                            animate: {
                                rotate: [0, 28, 0, 28]
                            },
                            transition: {
                                duration: 1
                            },
                            className: "w-fit origin-center ml-2 mt-1",
                            children: "👋"
                        }) : (0, s.jsxs)(s.Fragment, {
                            children: [e ? "" !== C ? (0, s.jsx)(it, {
                                text: C,
                                duration: 0
                            }) : (0, s.jsx)(at, {
                                message: t,
                                duration: 6
                            }) : null, E.current.length <= 4 && (0, s.jsxs)(s.Fragment, {
                                children: [(0, s.jsx)(et.Z, {}), (0, s.jsxs)("div", {
                                    className: "flex gap-[14px] items-center flex-col",
                                    children: [(0, s.jsx)(st, {
                                        onKeyDown: e => {
                                            "Enter" === e.key && e.preventDefault()
                                        },
                                        value: c,
                                        onChange: e => {
                                            const t = e.target.value;
                                            t.length > 50 || (H(), t.length > 0 ? I(1e4) : I(), d(t))
                                        },
                                        ref: A,
                                        className: "resize-none border-none text-base placeholder:text-black/30 min-h-[24px] pb-1.5 py-1",
                                        maxLength: 50,
                                        style: { ...g && {
                                                paddingBottom: 0
                                            }
                                        },
                                        rows: g ? 2 : 1,
                                        placeholder: D("Home_FollowerPointerCard_InputPlaceholder")
                                    }), g && (0, s.jsxs)("div", {
                                        className: "flex gap-[4px] items-center w-full justify-end",
                                        children: [(0, s.jsx)("span", {
                                            className: "text-black/50",
                                            children: D("Home_FollowerPointerCard_EnterPromptPress")
                                        }), (0, s.jsx)(oe.default, {
                                            src: Ve,
                                            alt: "enter",
                                            width: 26
                                        }), (0, s.jsx)("span", {
                                            className: "whitespace-nowrap text-black/50",
                                            children: D("Home_FollowerPointerCard_EnterPromptSend")
                                        })]
                                    })]
                                })]
                            })]
                        })
                    })
                })
            };

            function nt() {
                return nt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, nt.apply(this, arguments)
            }
            var xt = function(e) {
                    return y.createElement("svg", nt({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 132,
                        height: 40,
                        fill: "none",
                        viewBox: "0 0 132 40"
                    }, e), At || (At = y.createElement("path", {
                        fill: "#fff",
                        d: "M17.492 10.499q0-1.684.88-2.676.877-.99 2.49-.991.97 0 1.523.25.556.248.976.77.255.318-.014.494l-.557.361q-.245.16-.522-.142a1.86 1.86 0 0 0-1.358-.58q-1.025 0-1.46.649-.434.645-.434 1.865t.434 1.87q.435.645 1.46.645.498 0 .86-.098.36-.102.683-.366v-.874h-1.06q-.366 0-.366-.318v-.576q0-.317.367-.317h2.119q.366 0 .366.317v2.48q-.683.503-1.382.704-.693.2-1.636.2-1.587 0-2.48-.991-.89-.992-.889-2.676m7.324.938q0-1.245.64-1.954.645-.708 1.914-.708 1.27 0 1.91.708.644.708.644 1.954 0 1.244-.645 1.953-.639.708-1.909.708-1.269 0-1.914-.708-.64-.708-.64-1.953m1.446 0q0 .927.283 1.318.288.386.825.386.538 0 .82-.386.288-.39.288-1.319 0-.927-.288-1.313-.282-.39-.82-.39-.537 0-.825.39-.283.386-.283 1.314M31.272 14q-.294 0-.293-.293V7.94q0-.22.102-.4l.376-.66q.108-.185.254-.185h.342q.293 0 .293.293v6.719q0 .293-.293.293zm2.128-2.563q0-1.075.464-1.866.47-.795 1.617-.796.438 0 .751.127.314.127.567.547h.02a4 4 0 0 1-.02-.39V7.086q0-.293.293-.293h.781q.293 0 .293.293v6.621q0 .293-.293.293h-.771q-.244 0-.264-.293l-.02-.283h-.02q-.252.42-.566.547a2 2 0 0 1-.751.127q-1.148 0-1.617-.791-.464-.796-.464-1.87m1.446 0q0 .78.2 1.245.206.459.864.459.367 0 .625-.41.264-.415.264-1.075v-.44q0-.659-.264-1.068-.258-.416-.625-.416-.66 0-.864.464-.2.46-.2 1.24m4.375 0q0-1.235.615-1.949.62-.713 1.748-.713 1.308 0 1.943.674.635.675.635 2.168 0 .293-.273.293h-3.223q.078.81.4 1.02.323.21.747.21.405 0 .62-.107.216-.107.362-.293.165-.215.41-.068l.488.298q.288.175.083.42a1.9 1.9 0 0 1-.698.532q-.4.176-1.265.176-1.401 0-1.997-.713-.595-.714-.595-1.948m1.45-.503h2.124q0-.527-.264-.86-.263-.337-.84-.337-.459 0-.727.323-.27.316-.293.874M45.52 14q-.293 0-.293-.293V9.166q0-.293.293-.293h.771q.293 0 .293.293v.283h.02q.225-.386.57-.527a2.1 2.1 0 0 1 .836-.147q.762 0 1.26.479t.498 1.748v2.705q0 .293-.293.293h-.782q-.293 0-.293-.293v-2.354q0-1.065-.146-1.342-.147-.279-.63-.279-.513 0-.772.4-.258.396-.258 1.651v1.924q0 .293-.293.293zm9.443 0q-.342 0-.342-.366v-6.27q0-.366.342-.366h.742q.342 0 .342.366v1.944q0 .292-.024.586h.034l2.373-2.608q.263-.288.449-.288h.981q.571 0 .186.42L57.824 9.85l2.378 3.73q.269.42-.185.42h-.914q-.253 0-.439-.288l-1.797-2.817-.82.922v1.817q0 .366-.342.366zm6.484 0q-.293 0-.293-.293V9.166q0-.293.293-.293h.781q.294 0 .294.293v4.541q0 .293-.294.293zm0-5.879q-.293 0-.293-.293v-.625q0-.293.293-.293h.781q.294 0 .294.293v.625q0 .293-.294.293zM63.68 9.85q-.288 0-.288-.245v-.488q0-.244.288-.244h.332v-.17q0-.22.102-.401l.376-.66q.108-.185.254-.185h.342q.293 0 .293.293v1.123h.79q.29 0 .289.244v.488q0 .245-.288.245h-.791v2.422q0 .497.068.717.075.215.371.215.151 0 .342-.049.19-.053.298-.102.171-.078.225.112l.146.557q.044.166-.127.244a2.2 2.2 0 0 1-.444.132 2.5 2.5 0 0 1-.562.063q-.697 0-1.191-.288-.493-.288-.493-1.186V9.85zm3.896 0q-.288 0-.288-.245v-.488q0-.244.288-.244h.332v-.17q0-.22.103-.401l.376-.66q.107-.185.254-.185h.341q.293 0 .293.293v1.123h.791q.288 0 .288.244v.488q0 .245-.288.245h-.79v2.422q0 .497.068.717.073.215.37.215.153 0 .343-.049.19-.053.297-.102.172-.078.225.112l.147.557q.044.166-.127.244a2.2 2.2 0 0 1-.445.132 2.5 2.5 0 0 1-.561.063q-.699 0-1.192-.288-.492-.288-.493-1.186V9.85zm3.75-.596q-.132-.381.161-.381h.874q.225 0 .293.25l.738 2.729q.053.19.092.493.044.297.044.38h.03q.058-.258.083-.41.03-.156.151-.6l.698-2.593q.069-.249.293-.249h.874q.288 0 .161.38l-1.645 4.952q-.288.87-.708 1.358t-1.167.488q-.41 0-.733-.069-.184-.039-.141-.253l.107-.538q.045-.21.25-.146.15.05.282.049.396 0 .601-.376.21-.376.278-.645l.015-.073zM79.792 14q-.35 0-.23-.322l2.393-6.284q.151-.396.46-.396h.683q.308 0 .459.396l2.392 6.284q.123.322-.23.322h-.776q-.322 0-.449-.337l-.498-1.313h-2.48l-.498 1.313q-.127.337-.45.337zm2.178-2.861h1.572l-.6-1.553a3 3 0 0 1-.132-.396 8 8 0 0 1-.044-.37h-.02a5 5 0 0 1-.049.37 2.2 2.2 0 0 1-.127.396zm4.38-1.885q-.108-.381.16-.381h.826q.234 0 .293.25l.66 2.86q.057.25.102.479.044.23.053.376h.03a3 3 0 0 1 .053-.381q.045-.24.103-.474l.693-2.86q.06-.25.293-.25h.889q.234 0 .293.25l.693 2.86q.059.235.103.474.044.234.053.38h.03a3 3 0 0 1 .053-.375q.045-.23.103-.479l.66-2.86q.058-.25.292-.25h.825q.27 0 .162.38l-1.27 4.42q-.093.327-.356.327h-.884q-.279 0-.357-.327l-.708-2.896a7 7 0 0 1-.093-.4 3 3 0 0 1-.034-.337h-.02q-.01.186-.038.337-.025.15-.088.4l-.708 2.896q-.078.327-.357.327h-.883q-.264 0-.357-.327zm7.91 3.379q0-.976.932-1.416.933-.44 2.13-.469v-.195q0-.45-.225-.635-.225-.186-.625-.186-.284 0-.503.083a1.8 1.8 0 0 0-.376.186 3 3 0 0 0-.283.21q-.225.195-.371.02l-.406-.499q-.15-.185.073-.38.171-.152.396-.264a3.3 3.3 0 0 1 .605-.21q.377-.102.977-.103 1.015 0 1.558.47.546.468.547 1.381v3.081q0 .293-.293.293h-.801q-.264 0-.264-.293v-.147h-.01a1.8 1.8 0 0 1-.693.41 2.5 2.5 0 0 1-.737.128q-.802 0-1.216-.391-.415-.396-.415-1.074m1.445-.03a.6.6 0 0 0 .068.298.4.4 0 0 0 .215.181q.147.06.327.059.25 0 .484-.069.234-.068.522-.322v-1.06q-.82.093-1.098.24a1.2 1.2 0 0 0-.4.302.6.6 0 0 0-.118.372M100.314 14q-.293 0-.293-.293V9.166q0-.293.293-.293h.772q.293 0 .293.293v.4h.019q.128-.312.425-.551.298-.24.703-.24.279 0 .459.069.171.063.132.234l-.137.581q-.044.196-.263.117a.8.8 0 0 0-.244-.044q-.47 0-.777.562-.307.561-.307 1.636v1.777q0 .293-.293.293zm3.272-2.563q0-1.075.464-1.866.468-.795 1.616-.796.44 0 .752.127t.566.547h.02a4 4 0 0 1-.02-.39V7.086q0-.293.293-.293h.782q.293 0 .293.293v6.621q0 .293-.293.293h-.772q-.245 0-.264-.293l-.019-.283h-.02q-.254.42-.566.547a2 2 0 0 1-.752.127q-1.148 0-1.616-.791-.464-.796-.464-1.87m1.445 0q0 .78.2 1.245.205.459.865.459.366 0 .625-.41.263-.415.263-1.075v-.44q0-.659-.263-1.068-.26-.416-.625-.416-.66 0-.865.464-.2.46-.2 1.24m4.546 2.221q-.239-.171-.132-.366l.249-.454q.132-.244.41-.059.279.186.655.274.381.088.693.088.22 0 .41-.044a.7.7 0 0 0 .323-.171q.13-.128.131-.371a.4.4 0 0 0-.078-.25.5.5 0 0 0-.2-.156 1.6 1.6 0 0 0-.259-.087 11 11 0 0 1-.522-.147 6 6 0 0 1-.65-.24 2.2 2.2 0 0 1-.507-.312 1.34 1.34 0 0 1-.362-.454 1.5 1.5 0 0 1-.112-.615q0-.494.283-.864.288-.372.742-.513.455-.142 1.133-.142.459 0 .894.132.434.132.62.25.293.185.146.395l-.298.434q-.136.195-.439.03a3 3 0 0 0-.454-.205 1.5 1.5 0 0 0-.493-.079q-.186 0-.357.04a.66.66 0 0 0-.293.146.37.37 0 0 0-.117.283q0 .186.108.293a.7.7 0 0 0 .253.152l.279.092q.273.088.552.171.278.079.566.19.249.099.483.279.236.18.342.459.108.279.108.635 0 .473-.284.879-.282.405-.747.576-.464.17-1.079.17-.688 0-1.172-.097a2.1 2.1 0 0 1-.825-.342M49.692 21.8q1.296 0 2.24.416.96.4 1.472 1.152.528.752.528 1.744 0 .928-.464 1.68T52.3 28.12t-1.936 1.408q-.687.448-1.12.768h4.816V33h-9.12v-.768q0-.848.384-1.504.4-.672 1.152-1.344a69 69 0 0 1 2.208-1.824q1.152-.912 1.616-1.392t.464-.944q0-.495-.352-.832-.336-.336-1.024-.336-.72 0-1.136.416t-.416 1.088v.32h-2.848a3 3 0 0 1-.016-.352q0-1.728 1.2-2.72 1.215-1.008 3.52-1.008m10.48 0q2.577 0 3.616 1.472 1.056 1.456 1.056 4.224t-1.056 4.24q-1.04 1.455-3.616 1.456-2.592 0-3.648-1.456-1.04-1.472-1.04-4.24 0-2.767 1.04-4.224Q57.58 21.8 60.172 21.8m0 2.16q-.832 0-1.184.64-.351.64-.352 2.096v1.584q0 1.471.352 2.112.353.64 1.184.64.832 0 1.168-.64t.336-2.112v-1.584q0-1.472-.336-2.096-.336-.64-1.168-.64m10.864-2.16q1.296 0 2.24.416.96.4 1.472 1.152.528.752.528 1.744 0 .928-.464 1.68-.465.752-1.168 1.328a27 27 0 0 1-1.936 1.408q-.688.448-1.12.768h4.816V33h-9.12v-.768q0-.848.384-1.504.4-.672 1.152-1.344a69 69 0 0 1 2.208-1.824q1.152-.912 1.616-1.392t.464-.944q0-.495-.352-.832-.336-.336-1.024-.336-.72 0-1.136.416t-.416 1.088v.32h-2.848a3 3 0 0 1-.016-.352q0-1.728 1.2-2.72 1.215-1.008 3.52-1.008m11.712 0q-.112.832-.768 2.08-.656 1.232-1.568 2.48-.897 1.232-1.68 2.032H81.9v-2.288q.495-.704 1.008-1.664.511-.96.672-1.584h1.36v5.536h1.536v2.352H84.94V33H81.9v-2.256h-5.36V28.36q.864-1.248 1.712-3.024a23.4 23.4 0 0 0 1.36-3.536z"
                    })), ot || (ot = y.createElement("path", {
                        fill: "#fff",
                        fillRule: "evenodd",
                        d: "M113.463 39.228c-4.562 1.767-6.418.093-6.418-.963 1.617-.136 5.478-.358 6.418.963m5.79-1.444a5.93 5.93 0 0 1-7.657-.538c1.556-.432 5.807-.944 7.657.538m-7.718-3.434c.173 2.198-2.078 3.434-4.508 3.612.443-2.21 2.712-3.198 4.508-3.612m4.359-2.026c.257.94-.096 3.49-3.592 4.502.15-1.722 1.066-3.964 3.592-4.502m6.933 2.557a5.41 5.41 0 0 1-6.903.617c1.401-.722 4.766-1.697 6.903-.617m-3.694-5.087c.479.925.581 3.562-2.515 5.149-.179-1.698.503-4.6 2.515-5.15m7.657 1.024a4.77 4.77 0 0 1-2.872 2.397 4.59 4.59 0 0 1-3.665-.476c1.951-1.834 5.065-2.538 6.537-1.92m-4.627-4.915c1.388 2.421-.079 5.187-1.605 6.323-.679-2.25-.055-4.704 1.605-6.323m7.202-.105c.158 3.546-3.324 3.567-5.269 3.579q-.177 0-.335.003c.581-.79 3.808-3.656 5.604-3.582m-4.843-3.514c.73.804 1.825 3.891-.6 6.41-.76-1.822-.926-4.618.6-6.41m6.903-1.667c.125 3.038-2.431 4.575-4.897 4.552.741-1.464 2.724-4.286 4.897-4.552m-5.173-2.093c1.634.962 1.449 4.07.484 5.687-1.083-1.506-1.892-3.377-.484-5.687m5.28-2.846c.809 2.766-1.568 4.638-2.994 4.798q.041-.149.084-.311c.362-1.352.92-3.435 2.91-4.487m-4.981-.92c1.803.903 2.657 3.062 1.982 5.007-1.257-1.013-2.772-3.155-1.982-5.007m5.065-3.347c1.114 3.365-1.443 4.465-2.394 4.735.113-1.431 1.023-4.284 2.394-4.735m-4.993-.883c.731.21 2.814 1.92 2.436 4.983-1.37-.771-3.035-2.242-2.436-4.983m4.239-4.217c1.245 4.137-.833 5.835-1.515 6.173-.108-1.308-.24-4.364 1.515-6.173m-4.61.104c1.305.364 2.951 2.76 2.873 5.064-1.293-.592-3.227-3.056-2.873-5.064M126.641 0c3.029 3.13 3.454 5.6 2.569 8.644-1.372-1.234-2.467-4.94-2.569-8.644M18.429 39.228c4.562 1.767 6.418.093 6.418-.963-1.617-.136-5.478-.358-6.418.963m-5.791-1.444a5.93 5.93 0 0 0 7.657-.538c-1.557-.432-5.807-.944-7.657.538m7.718-3.434c-.173 2.198 2.077 3.434 4.508 3.612-.443-2.21-2.713-3.198-4.508-3.612m-4.358-2.026c-.257.94.096 3.49 3.592 4.502-.15-1.722-1.066-3.964-3.592-4.502m-6.933 2.557a5.41 5.41 0 0 0 6.903.617c-1.402-.722-4.766-1.697-6.903-.617m3.694-5.087c-.479.925-.58 3.562 2.515 5.149.179-1.698-.503-4.6-2.515-5.15m-7.657 1.024a4.76 4.76 0 0 0 2.872 2.397 4.58 4.58 0 0 0 3.665-.476c-1.951-1.834-5.065-2.538-6.537-1.92m4.627-4.915c-1.388 2.421.079 5.187 1.605 6.323.679-2.25.056-4.704-1.604-6.323zm-7.202-.105c-.159 3.546 3.324 3.567 5.269 3.579q.176 0 .335.003c-.58-.79-3.808-3.656-5.604-3.582m4.843-3.514c-.73.804-1.825 3.891.6 6.41.76-1.822.926-4.618-.6-6.41M.468 20.617C.343 23.655 2.9 25.192 5.365 25.17c-.741-1.464-2.724-4.286-4.897-4.552m5.173-2.093c-1.634.962-1.449 4.07-.484 5.687 1.083-1.506 1.892-3.377.484-5.687M.36 15.678H.359zm0 0c-.808 2.767 1.568 4.638 2.994 4.798q-.041-.147-.084-.31c-.362-1.351-.92-3.435-2.91-4.488m4.98-.92c-1.802.903-2.656 3.062-1.981 5.007 1.257-1.013 2.772-3.155 1.982-5.007M.277 11.41c-1.114 3.365 1.443 4.465 2.394 4.735-.113-1.431-1.023-4.284-2.394-4.735m4.993-.883c-.73.21-2.814 1.92-2.437 4.983 1.371-.771 3.036-2.242 2.437-4.983M1.03 6.31c-1.245 4.137.833 5.835 1.515 6.173.108-1.308.24-4.364-1.515-6.173m4.61.104c-1.305.364-2.951 2.76-2.873 5.064 1.292-.592 3.227-3.056 2.873-5.064M5.25 0C2.223 3.13 1.798 5.6 2.683 8.644 4.054 7.41 5.15 3.704 5.251 0",
                        clipRule: "evenodd"
                    })))
                },
                lt = a(89242),
                ct = a(761),
                dt = a(39698),
                kt = a.n(dt),
                gt = a(89733);

            function pt() {
                return (0, s.jsx)("iframe", {
                    className: " w-full h-full",
                    src: "/wegic3d"
                })
            }
            var yt, ut = a(79245);

            function ht() {
                return ht = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, ht.apply(this, arguments)
            }
            var mt, ft = function(e) {
                return y.createElement("svg", ht({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 25,
                    height: 25,
                    fill: "none",
                    viewBox: "0 0 25 25"
                }, e), yt || (yt = y.createElement("g", {
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 3,
                    opacity: .3
                }, y.createElement("path", {
                    d: "M12.5 6.06v12M18.5 12.06l-6-6-6 6"
                }))))
            };

            function vt() {
                return vt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, vt.apply(this, arguments)
            }
            var wt = function(e) {
                    return y.createElement("svg", vt({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 25,
                        height: 25,
                        fill: "none",
                        viewBox: "0 0 25 25"
                    }, e), mt || (mt = y.createElement("path", {
                        stroke: "#fff",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 3,
                        d: "M12.5 6.06v12M18.5 12.06l-6-6-6 6"
                    })))
                },
                bt = a(8968),
                Bt = a.n(bt);
            const Ct = "RadioTab",
                Qt = ["transform", "WebkitTransform", "msTransform", "MozTransform", "OTransform"];
            var Et = a(71180),
                Dt = a.n(Et);

            function It(e) {
                const {
                    containerRef: t,
                    headerOffset: a,
                    onScroll: i,
                    isScrollControlsVisible: s
                } = e, A = (0, x.useRef)({
                    clientX: 0
                });

                function o(e) {
                    if (!t.current || !s) return;
                    const a = t.current.style.transform,
                        A = new DOMMatrix(a).m41;
                    e.preventDefault();
                    const {
                        deltaX: o,
                        deltaY: r
                    } = e;
                    let n = 0;
                    n = Math.abs(o) >= Math.abs(r) ? o : r;
                    i(A - n)
                }
                const r = e => e && e.touches && e.touches.length && e.touches[0];
                const n = e => {
                        e.cancelable && e.preventDefault();
                        const t = r(e);
                        if (!t) return;
                        const {
                            clientX: s
                        } = A.current;
                        ! function(e) {
                            i && i(a - e)
                        }(-(t.clientX - s))
                    },
                    l = () => {
                        document.documentElement.removeEventListener("touchmove", n), window.removeEventListener("touchend", l)
                    },
                    c = e => {
                        const t = r(e);
                        t && (A.current = {
                            clientX: t.clientX
                        }, document.documentElement.addEventListener("touchmove", n, {
                            passive: !1
                        }), window.addEventListener("touchend", l, {
                            passive: !1
                        }))
                    };
                (0, x.useEffect)((() => {
                    var e, a;
                    return null === (e = t.current) || void 0 === e || e.addEventListener("wheel", o), null === (a = t.current) || void 0 === a || a.addEventListener("touchstart", c), () => {
                        var e, a;
                        null === (e = t.current) || void 0 === e || e.removeEventListener("wheel", o), null === (a = t.current) || void 0 === a || a.removeEventListener("touchstart", c)
                    }
                }), [a, s])
            }
            const Ht = x.createContext({
                value: "",
                onTabClick: () => {},
                size: "default"
            });
            var Pt = e => {
                var t;
                const {
                    size: a = "default",
                    className: i = "",
                    containerStyle: A,
                    sliderStyle: o,
                    id: r,
                    scrollable: l,
                    availableWidth: d,
                    disabled: k,
                    tabGap: g = 0,
                    onMouseDown: p,
                    sliderClassName: y,
                    type: u = "default"
                } = e, h = (0, x.useRef)(null), m = (0, x.useRef)(null), f = (0, x.useRef)(null), v = (0, x.useRef)(null), w = (0, x.useRef)(null), [b, B, C] = (0, Xe.Z)([]), [Q, E] = (0, x.useState)(""), [D, I] = (0, x.useState)(0), [H, P] = (0, x.useState)(!1), [j, M] = (0, x.useState)(0), O = null === (t = h.current) || void 0 === t ? void 0 : t.clientWidth, N = (0, x.useMemo)((() => !!l && (!(!O || !d) && O > d)), [l, d, O]), Y = (0, x.useCallback)((() => function(e, t) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 4;
                    var i, s;
                    const A = (null == e || null === (i = e.current) || void 0 === i ? void 0 : i.clientWidth) || 0;
                    return ((null == t || null === (s = t.current) || void 0 === s ? void 0 : s.clientWidth) || 0) - A - a
                }(h, m, 10)), []), L = () => {
                    var e, t;
                    const a = null !== (t = null === (e = h.current) || void 0 === e ? void 0 : e.children) && void 0 !== t ? t : [];
                    if (0 === a.length) return;
                    const i = Array.from(a).map((e => e.clientWidth));
                    i.every((e => 0 === e)) && C().length > 0 || B(i.slice(0, i.length - 1))
                }, z = (0, x.useMemo)((() => (null == b ? void 0 : b[D]) || 0), [b, D]);

                function J(e, t) {
                    if ("min" === t) {
                        const t = Y();
                        return e < t ? t : e
                    }
                    return e > 0 ? 0 : e
                }
                const S = (0, x.useMemo)((() => {
                        let e = 0;
                        for (let t = 0; t < D; t++) e += b[t] + g;
                        return e
                    }), [b, D]),
                    G = (0, x.useCallback)((() => {
                        L()
                    }), []),
                    T = (0, x.useCallback)((() => {
                        (() => {
                            const e = Y();
                            j < e && M(e)
                        })()
                    }), [j]);
                (0, x.useEffect)((() => {
                    const t = (() => {
                        const {
                            children: t
                        } = e;
                        return x.Children.toArray(t).findIndex((e => e.props.value === Q))
                    })();
                    I(t > -1 ? t : 0)
                }), [Q]), (0, x.useEffect)((() => {
                    E(e.defaultValue), L();
                    const t = (0, n.Z)(G, 500, {
                        trailing: !0
                    });
                    return v.current = new ResizeObserver(t), h.current && v.current.observe(h.current), () => {
                        var e;
                        null === (e = v.current) || void 0 === e || e.disconnect()
                    }
                }), []), (0, x.useEffect)((() => {
                    const e = (0, n.Z)(T, 200, {
                        trailing: !0
                    });
                    return w.current = new ResizeObserver(e), m.current && w.current.observe(m.current), () => {
                        var e;
                        null === (e = w.current) || void 0 === e || e.disconnect()
                    }
                }), [j]);
                const W = {
                    value: Q,
                    onTabClick: (t, a) => {
                        if (!k && t !== Q && (P(!0), E(t), e.onChange && e.onChange(t), l)) {
                            (e => {
                                var t, a;
                                if (!m.current) return;
                                const i = (null === (t = e.nextElementSibling) || void 0 === t ? void 0 : t.clientWidth) || 0,
                                    s = (null === (a = e.previousElementSibling) || void 0 === a ? void 0 : a.clientWidth) || 0,
                                    A = function(e, t) {
                                        const a = e.getBoundingClientRect(),
                                            i = t.getBoundingClientRect(),
                                            s = t.offsetWidth / i.width;
                                        return {
                                            left: (a.left - i.left) * s,
                                            right: (a.right - i.right) * s
                                        }
                                    }(e, m.current),
                                    o = A.left - m.current.clientWidth + e.clientWidth;
                                if (o > 0) M(J(j - o - 10 - i / 2, "min"));
                                else if (A.left < 0) {
                                    const e = j - A.left + 10 + s / 2;
                                    M(J(e, "max"))
                                }
                            })(a.currentTarget)
                        }
                    },
                    size: a
                };
                It({
                    containerRef: h,
                    headerOffset: j,
                    onScroll: e => {
                        e > 0 || e < Y() || M(e)
                    },
                    isScrollControlsVisible: N
                });
                const R = function(e) {
                    const t = {};
                    return Qt.forEach((a => {
                        t[a] = e
                    })), t
                }("translateX(".concat(j, "px)"));
                return (0, s.jsx)("div", {
                    className: c()(Dt()["radio-tabs-box"], {
                        [Dt()["radio-tabs-box-scrollable"]]: l
                    }),
                    style: e.style,
                    onMouseDown: p,
                    children: (0, s.jsx)("div", {
                        className: c()(Dt()["radio-tabs-wrapper"], {
                            [Dt().scrollable]: l,
                            [Dt().plain]: "plain" === u
                        }),
                        ref: m,
                        children: (0, s.jsxs)("div", {
                            className: c()(Dt()["radio-tabs"], {
                                [Dt()["radio-tabs-scrollable"]]: l
                            }, i),
                            ref: h,
                            id: r,
                            style: { ...N ? R : {},
                                ...g ? {
                                    gap: "".concat(g, "px")
                                } : {}
                            },
                            children: [(0, s.jsx)(Ht.Provider, {
                                value: W,
                                children: (() => {
                                    const {
                                        children: t,
                                        size: a = "default"
                                    } = e;
                                    return x.Children.map(t, ((e, t) => {
                                        const i = e;
                                        return i.type.displayName === Ct ? x.cloneElement(i, {
                                            size: a,
                                            scrollable: l,
                                            isActive: t === D
                                        }) : (0, s.jsx)(s.Fragment, {})
                                    }))
                                })()
                            }), (0, s.jsx)("div", {
                                className: Dt()["slider-container"],
                                style: A,
                                children: (0, s.jsx)("div", {
                                    className: c()(Dt().slider, y, {
                                        [Dt().transition]: H
                                    }),
                                    ref: f,
                                    style: {
                                        width: "".concat(z, "px"),
                                        left: "".concat(S, "px"),
                                        opacity: "".concat(-1 === D ? 0 : 1),
                                        ...o
                                    }
                                })
                            })]
                        })
                    })
                })
            };

            function jt(e) {
                const t = (0, x.useContext)(Ht),
                    {
                        value: a,
                        disabled: i,
                        scrollable: A,
                        isActive: o
                    } = e,
                    {
                        size: r
                    } = t;
                return (0, s.jsx)("div", {
                    className: c()(Bt()["radio-tab"], "radio-tab", e.className, {
                        [Bt()["radio-tab--active"]]: o,
                        [Bt()["radio-tab--noActive"]]: !o,
                        ["radio-tab-size-".concat(r, "--active")]: o,
                        [Bt()["radio-tab--disabled"]]: i
                    }),
                    onClick: e => {
                        const {
                            onTabClick: s
                        } = t;
                        s && !i && s(a, e)
                    },
                    style: e.style,
                    children: (0, s.jsx)("div", {
                        className: c()(Bt()["radio-tab-content"], {
                            [Bt()["radio-tab--disabled"]]: i,
                            [Bt()["radio-tab-content--scrollable"]]: A
                        }),
                        children: e.children
                    })
                })
            }
            jt.displayName = Ct;
            var Mt = jt,
                Ot = a(23556),
                Nt = (a(7591), a(89616)),
                Yt = a(39881),
                Lt = a.n(Yt);

            function zt(e) {
                const {
                    className: t,
                    triggerProps: a,
                    ...i
                } = e;
                return (0, s.jsx)(Nt.Z, { ...i,
                    triggerProps: {
                        showArrow: !0,
                        ...a
                    },
                    className: c()(t, {
                        [Lt()["custom-tool-tip"]]: !0
                    })
                })
            }
            var Jt, St, Gt = a(11338);

            function Tt() {
                return Tt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, Tt.apply(this, arguments)
            }
            var Wt, Rt = function(e) {
                return y.createElement("svg", Tt({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 12 12"
                }, e), Jt || (Jt = y.createElement("g", {
                    clipPath: "url(#a)"
                }, y.createElement("path", {
                    fill: "currentColor",
                    d: "M4.669.809A1.7 1.7 0 0 1 6.19 2.32a1.9 1.9 0 0 1 2.658.036l.947.948h-.001a1.9 1.9 0 0 1 .43 2.084 1.9 1.9 0 0 1-.282.47 1.7 1.7 0 0 1 1.26 1.641v2A1.7 1.7 0 0 1 9.5 11.2h-6a2.7 2.7 0 0 1-2.7-2.7v-6A1.7 1.7 0 0 1 2.5.8h2zM2.5 2.2a.3.3 0 0 0-.3.3v6a1.3 1.3 0 0 0 2.594.129L4.8 8.5v-6a.3.3 0 0 0-.241-.294L4.5 2.2zm3.536 7.6h3.464a.3.3 0 0 0 .3-.3v-2a.3.3 0 0 0-.3-.3h-.876zm-2.39-1.986a.7.7 0 0 1 0 1.372l-.141.014H3.5a.7.7 0 0 1 0-1.4h.005zm3.854-4.617a.5.5 0 0 0-.28.084l-.075.063-.945.945V7.65l2.616-2.627.003-.003.064-.077a.5.5 0 0 0-.07-.638l-.01-.01v-.001l-.949-.95a.5.5 0 0 0-.354-.147"
                }))), St || (St = y.createElement("defs", null, y.createElement("clipPath", {
                    id: "a"
                }, y.createElement("path", {
                    fill: "currentColor",
                    d: "M0 0h12v12H0z"
                })))))
            };

            function Ft() {
                return Ft = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, Ft.apply(this, arguments)
            }
            var Xt, Ut = function(e) {
                return y.createElement("svg", Ft({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 12 12"
                }, e), Wt || (Wt = y.createElement("path", {
                    fill: "currentColor",
                    d: "M6 1.425c.243 0 .485.052.706.153v.001L10.99 3.53v.001c.153.068.292.166.405.29l.108.137.087.152a1.2 1.2 0 0 1 .103.331l.015.175-.008.116v2.893a.7.7 0 0 1-1.4 0V6.04l-.6.272v1.717c0 .815-.523 1.478-1.212 1.902-.607.373-1.368.586-2.151.634l-.337.01c-.899 0-1.795-.217-2.488-.644-.646-.398-1.146-1.006-1.206-1.751L2.3 8.03V6.305L1.02 5.722a1.2 1.2 0 0 1-.707-.925l-.012-.174.012-.174a1.2 1.2 0 0 1 .183-.482l.107-.139a1.2 1.2 0 0 1 .408-.3L5.295 1.58A1.7 1.7 0 0 1 6 1.424M3.701 8.029l.005.067c.027.166.158.407.54.642.432.266 1.062.437 1.755.437l.257-.008c.59-.036 1.12-.196 1.498-.429.436-.268.545-.544.545-.709V6.947l-1.596.726v-.001a1.7 1.7 0 0 1-.522.143L6 7.825a1.7 1.7 0 0 1-.536-.087l-.17-.066-1.593-.728zM6 2.825a.3.3 0 0 0-.124.028h-.001l-3.892 1.77 3.893 1.775.06.021q.032.006.064.007l.064-.007a.3.3 0 0 0 .061-.02l.001-.002 3.898-1.77-3.899-1.774A.3.3 0 0 0 6 2.825"
                })))
            };

            function Vt() {
                return Vt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, Vt.apply(this, arguments)
            }
            var Zt, Kt = function(e) {
                return y.createElement("svg", Vt({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 12 12"
                }, e), Xt || (Xt = y.createElement("path", {
                    fill: "currentColor",
                    d: "M7.627.362A.65.65 0 0 1 7.96.54l2.5 2.5a.65.65 0 0 1 .19.46V10A1.65 1.65 0 0 1 9 11.65H3a1.65 1.65 0 0 1-1.642-1.487L1.35 10V2A1.65 1.65 0 0 1 3 .35h4.5zM3 1.65a.35.35 0 0 0-.35.35v8l.007.068A.35.35 0 0 0 3 10.35h6a.35.35 0 0 0 .35-.35V4.65H8A1.65 1.65 0 0 1 6.35 3V1.65zm3 3.2c.911 0 1.65.739 1.65 1.65 0 .32-.093.617-.25.87q.061.051.12.11c.404.403.63.95.63 1.52a.65.65 0 0 1-1.3 0 .85.85 0 0 0-1.7 0 .65.65 0 0 1-1.3 0 2.15 2.15 0 0 1 .75-1.63A1.65 1.65 0 0 1 6 4.85m0 1.3a.35.35 0 1 0 0 .7.35.35 0 0 0 0-.7M7.65 3a.35.35 0 0 0 .35.35h.93L7.65 2.07z"
                })))
            };

            function qt() {
                return qt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, qt.apply(this, arguments)
            }
            var _t, $t, ea = function(e) {
                return y.createElement("svg", qt({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 12 12"
                }, e), Zt || (Zt = y.createElement("path", {
                    fill: "currentColor",
                    d: "M8.911 1.812a2.7 2.7 0 0 1 2.434 2.402l.004.027v.011l.002.009.001.013.002.013c.039.328.347 3.342.347 4.164l-.01.217a2.2 2.2 0 0 1-1.972 1.972l-.218.01c-.606 0-1-.251-1.267-.486l-.228-.219-.707-.707a.3.3 0 0 0-.153-.082l-.06-.006H4.916a.3.3 0 0 0-.166.051l-.046.037-.707.707c-.241.242-.634.65-1.348.7l-.147.005a2.2 2.2 0 0 1-2.19-1.982l-.01-.217c0-.821.309-3.836.348-4.164l.001-.012.002-.014.005-.046A2.7 2.7 0 0 1 3.341 1.8h5.321zM3.341 3.2A1.3 1.3 0 0 0 2.05 4.367l-.001.008-.003.031-.007.047.001.001c-.042.346-.338 3.275-.338 3.997l.004.08a.8.8 0 0 0 .796.72l.08-.005a.4.4 0 0 0 .153-.052c.07-.042.138-.104.272-.238l.707-.707.125-.113a1.7 1.7 0 0 1 1.077-.385h2.172l.168.008a1.7 1.7 0 0 1 1.034.49l.707.707.16.153a1 1 0 0 0 .112.085c.05.03.113.057.233.057l.08-.004a.8.8 0 0 0 .716-.717l.004-.079c0-.723-.296-3.651-.337-3.997l-.006-.048-.004-.039a1.3 1.3 0 0 0-1.173-1.161l-.12-.006zm.66.838a.6.6 0 0 1 .6.6v.4H5l.121.012a.6.6 0 0 1 0 1.176l-.121.011h-.4v.4a.6.6 0 1 1-1.2 0v-.4h-.4a.6.6 0 1 1 0-1.199h.4v-.4a.6.6 0 0 1 .6-.6m3.566 1.58a.7.7 0 0 1 0 1.371l-.141.015H7.42a.7.7 0 0 1 0-1.4h.005zm1.385-1.661a.7.7 0 0 1 0 1.371l-.141.015h-.005a.7.7 0 0 1 0-1.4h.005z"
                })))
            };

            function ta() {
                return ta = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, ta.apply(this, arguments)
            }
            var aa = function(e) {
                return y.createElement("svg", ta({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    fill: "none",
                    viewBox: "0 0 12 12"
                }, e), _t || (_t = y.createElement("g", {
                    clipPath: "url(#a)"
                }, y.createElement("path", {
                    fill: "currentColor",
                    d: "M9.083.305a.7.7 0 0 1 .478.275l1.5 2q.008.015.017.028.02.03.037.059.012.024.023.048.012.026.022.054l.02.068q.006.022.01.045.01.058.011.118v7a1.7 1.7 0 0 1-1.7 1.7h-7a1.7 1.7 0 0 1-1.7-1.7V3q0-.068.013-.133l.008-.031a1 1 0 0 1 .026-.083l.022-.055a1 1 0 0 1 .065-.108l.006-.01 1.5-2 .053-.062A.7.7 0 0 1 3.001.3h6zM2.201 10a.3.3 0 0 0 .3.3h7a.3.3 0 0 0 .3-.3V3.7H2.2zm5.8-5.7a.7.7 0 0 1 .7.7 2.7 2.7 0 0 1-2.433 2.687L6 7.7a2.7 2.7 0 0 1-2.7-2.7.7.7 0 0 1 1.4 0 1.3 1.3 0 0 0 1.3 1.3l.129-.006A1.3 1.3 0 0 0 7.3 5a.7.7 0 0 1 .701-.7m-5.1-2h6.2l-.45-.6h-5.3z"
                }))), $t || ($t = y.createElement("defs", null, y.createElement("clipPath", {
                    id: "a"
                }, y.createElement("path", {
                    fill: "currentColor",
                    d: "M0 0h12v12H0z"
                })))))
            };
            const ia = [{
                    key: "Online education platform",
                    label: "Home_Hero_Reference_Label_1",
                    content: "Home_Hero_Reference_Content_1",
                    icon: (0, s.jsx)(Ut, {
                        className: "size-3 text-white"
                    })
                }, {
                    key: "E-commerce product page",
                    label: "Home_Hero_Reference_Label_2",
                    content: "Home_Hero_Reference_Content_2",
                    icon: (0, s.jsx)(aa, {
                        className: "size-3 text-white"
                    })
                }, {
                    key: "Game community",
                    label: "Home_Hero_Reference_Label_3",
                    content: "Home_Hero_Reference_Content_3",
                    icon: (0, s.jsx)(ea, {
                        className: "size-3 text-white"
                    })
                }, {
                    key: "Show my products",
                    label: "Home_Hero_Reference_Label_4",
                    content: "Home_Hero_Reference_Content_4",
                    icon: (0, s.jsx)(Kt, {
                        className: "size-3 text-white"
                    })
                }, {
                    key: "Design studio",
                    label: "Home_Hero_Reference_Label_5",
                    content: "Home_Hero_Reference_Content_5",
                    icon: (0, s.jsx)(Rt, {
                        className: "size-3 text-white"
                    })
                }],
                sa = [{
                    key: "link",
                    label: "Home_Hero_Link_Reference_Label_1",
                    content: "Home_Hero_Link_Reference_Label_1"
                }];
            var Aa;
            ! function(e) {
                e.common = "common", e.link = "link"
            }(Aa || (Aa = {}));
            const oa = [{
                    value: "common",
                    title: "HelloCard-RadioTab-Title1",
                    tips: "HelloCard-RadioTab-Tips1"
                }, {
                    value: "link",
                    title: "HelloCard-RadioTab-Title2",
                    tips: "HelloCard-RadioTab-Tips2"
                }],
                ra = ia.map((e => e.content)).concat(ia[0].content);
            sa.map((e => e.content)).concat(sa[0].content);
            var na = a(90496),
                xa = a.n(na);
            const la = e => {
                const {
                    options: t,
                    activeKey: a,
                    onClick: i,
                    isDisable: A
                } = e, o = (0, p.useTranslations)();
                return (0, s.jsx)(r.E.div, {
                    variants: {
                        hidden: {
                            opacity: 0,
                            y: 20
                        },
                        inputVisible: {
                            opacity: 1,
                            y: 0,
                            transition: {
                                duration: .6,
                                ease: "easeInOut"
                            }
                        }
                    },
                    className: "w-full flex items-center justify-center flex-wrap gap-2.5",
                    children: t.map((e => (0, s.jsxs)(r.E.div, {
                        className: (0, J.cn)("inline-flex items-center justify-center gap-1", "rounded-[20px] py-1.5 px-5", "bg-black/30 text-white/80", "border border-[rgba(0,0,0,0.08)] border-solid", "cursor-pointer", !A && a !== e.key && "hover:bg-black/70 hover:text-white hover:border-white/20", !A && a === e.key && "bg-black/80 text-white hover:border-white/20", A && "cursor-default opacity-0"),
                        onClick: () => (e => {
                            A || i(e)
                        })(e),
                        children: [e.icon, (0, s.jsx)("span", {
                            className: "text-sm leading-[22px]",
                            children: o(e.label)
                        })]
                    }, e.key)))
                })
            };
            a(70764);
            const ca = function(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "Official_website_bottom",
                    a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "others";
                e.length >= 750 && (e = e.slice(0, 750)), window.open("/app?autoInput=".concat(e, "&fromHome=").concat(t, "&activeKey=").concat(a), "_blank")
            };

            function da() {
                const e = (0, ut.E)(),
                    [t, a] = (0, x.useState)(""),
                    [i, A] = (0, x.useState)(""),
                    [o, n] = (0, x.useState)(!1),
                    [l, d] = (0, x.useState)("others"),
                    k = x.useRef(null),
                    [g, y] = (0, x.useState)(Aa.common),
                    u = (0, p.useTranslations)(),
                    {
                        isResetting: h,
                        placeholderIndex: m
                    } = function(e) {
                        let {
                            length: t,
                            isActive: a,
                            interval: i = 3e3,
                            resetOnRestart: s = !1
                        } = e;
                        const [A, o] = (0, x.useState)(0), [r, n] = (0, x.useState)(!1), l = t + 1, c = (0, x.useRef)(null), d = (0, x.useRef)(null), k = e => {
                            d.current || (d.current = e), e - d.current >= i && o((t => {
                                const a = t + 1;
                                return a === l && (n(!0), o(0), setTimeout((() => {
                                    n(!1), o(1), d.current = performance.now()
                                }), 50)), d.current = e, a
                            })), c.current = requestAnimationFrame(k)
                        };
                        return (0, x.useEffect)((() => a ? (s && (o(1), n(!1)), d.current = performance.now(), c.current = requestAnimationFrame(k), () => {
                            null !== c.current && cancelAnimationFrame(c.current), c.current = null
                        }) : (null !== c.current && cancelAnimationFrame(c.current), c.current = null, void(s && (o(0), n(!0))))), [a, i, s, t]), {
                            placeholderIndex: A,
                            isResetting: r
                        }
                    }({
                        length: ra.length - 1,
                        isActive: !o
                    });
                (0, x.useEffect)((() => {
                    k.current && k.current.value.length > 0 && (a(k.current.value), n(!0))
                }), []), (0, x.useEffect)((() => {
                    (async () => {
                        await e.start("cardVisible"), await e.start("inputVisible"), await e.start("buttonVisible"), await e.start("bgVisible"), await e.start("dividerVisible")
                    })()
                }), [e]);
                const f = () => {
                    (0, Gt.GX)("official_click", {
                        object: "send_message",
                        choice: g === Aa.common ? "chat" : "link"
                    });
                    const e = g === Aa.common ? t : i;
                    ca(e, "Official_first_screen", l)
                };
                return (0, s.jsxs)(r.E.div, {
                    className: (0, J.cn)("relative z-0 h-[9.5rem] min-w-[628px] w-[720px] rounded-xl py-4", "flex flex-col gap-6", "ml:w-[720px] ml:px-0", "md:w-full md:px-[70px]"),
                    initial: "hidden",
                    animate: e,
                    variants: {
                        hidden: {
                            y: 200
                        },
                        cardVisible: {
                            y: 0,
                            transition: {
                                duration: .8,
                                ease: "easeInOut",
                                delay: .3
                            }
                        }
                    },
                    children: [(0, s.jsx)(r.E.div, {
                        className: (0, J.cn)("z-20", "rounded-xl py-[9px] px-4", "flex items-start self-stretch gap-[15px] flex-col", "text-white text-sm whitespace-normal", "bg-white/5 backdrop-blur-[22px]", "border border-white/20 border-solid", "transition-all duration-500"),
                        variants: {
                            hidden: {
                                opacity: 0,
                                y: 20
                            },
                            cardVisible: {
                                opacity: 1,
                                y: 0,
                                transition: {
                                    duration: .3,
                                    ease: "easeInOut"
                                }
                            }
                        },
                        children: u("Home_Hero_Message")
                    }), (0, s.jsxs)(r.E.div, {
                        variants: {
                            hidden: {
                                opacity: 0,
                                y: 20
                            },
                            inputVisible: {
                                opacity: 1,
                                y: 0,
                                transition: {
                                    duration: .3,
                                    ease: "easeInOut"
                                }
                            }
                        },
                        className: "relative rounded-xl px-[12px] pt-[16px] pb-[12px] bg-[#F7F6F5]",
                        children: [(0, s.jsx)(r.E.textarea, {
                            ref: k,
                            className: c()(xa()["no-scrollbar"], "w-full h-[54px] resize-none pl-[4px]", "text-black bg-[#F7F6F5]", "text-[15px] leading-6", "pr-16 z-10 outline-none"),
                            maxLength: 1e4,
                            autoFocus: !0,
                            value: g === Aa.common ? t : i,
                            onChange: e => {
                                d("others");
                                const t = e.target.value;
                                g === Aa.common ? a(t) : A(t), n(t.length > 0)
                            },
                            onKeyDown: e => {
                                o && ("Enter" !== e.key || 13 !== e.keyCode || e.shiftKey || (e.preventDefault(), f()))
                            }
                        }), (0, s.jsx)(Pt, {
                            defaultValue: Aa.common,
                            scrollable: !0,
                            onChange: e => {
                                if (y(e), k.current) {
                                    k.current.focus()
                                }
                                const a = e === Aa.common ? t.length : i.length;
                                n(a > 0), (0, Gt.GX)("official_click", {
                                    object: "website_build_way",
                                    choice: e === Aa.common ? "chat" : "link"
                                })
                            },
                            children: oa.map(((e, t) => (0, s.jsx)(Mt, {
                                value: e.value,
                                isActive: e.value === g,
                                children: (0, s.jsx)(zt, {
                                    getPopupContainer: () => document.getElementById("hero-section") || document.body,
                                    content: u(e.tips),
                                    triggerProps: {
                                        showArrow: !1,
                                        position: "top",
                                        popupAlign: {
                                            top: 18
                                        },
                                        mouseEnterDelay: 500
                                    },
                                    className: "bg-black rounded-[8px] py-[4px] px-[10px] text-white font-normal leading-[22px] text-[13px] !max-w-[400px]",
                                    children: (0, s.jsx)("div", {
                                        children: (0, s.jsx)(Ot.default, {
                                            i18nKey: e.title
                                        })
                                    })
                                })
                            }, t)))
                        }), !o && g === Aa.common && (0, s.jsx)(r.E.div, {
                            className: "absolute top-4 left-4 overflow-hidden h-12 pointer-events-none w-full pr-20",
                            children: (0, s.jsx)(r.E.div, {
                                initial: {
                                    y: 48 * -m
                                },
                                animate: {
                                    y: 48 * -m
                                },
                                transition: {
                                    duration: h ? 0 : .3,
                                    ease: "easeInOut"
                                },
                                children: ra.map(((e, t) => (0, s.jsx)("div", {
                                    className: c()("h-12 text-[#0000004D] text-[15px] leading-6 line-clamp-2"),
                                    children: u(e)
                                }, t)))
                            })
                        }), !o && g === Aa.link && (0, s.jsx)(r.E.div, {
                            className: "absolute top-4 left-4 overflow-hidden h-12 pointer-events-none w-full pr-20",
                            children: sa.map(((e, t) => (0, s.jsx)("div", {
                                className: c()("h-12 text-[#0000004D] text-[15px] leading-6 line-clamp-2"),
                                children: u(e.content)
                            }, t)))
                        }), o ? (0, s.jsx)(r.E.div, {
                            onClick: () => {
                                f()
                            },
                            className: c()(xa()["submit-button"], "flex justify-center items-center", "absolute right-[12px] bottom-[12px]", "text-white w-[40px] h-[40px] rounded-lg"),
                            variants: {
                                hidden: {
                                    opacity: 0,
                                    y: 10
                                },
                                inputVisible: {
                                    opacity: 1,
                                    y: 0,
                                    transition: {
                                        duration: .6,
                                        ease: "easeInOut"
                                    }
                                }
                            },
                            children: (0, s.jsx)(wt, {})
                        }) : (0, s.jsx)(r.E.div, {
                            className: c()(xa()["submit-button-disabled"], "flex justify-center items-center", "absolute right-[12px] bottom-[12px]", "bg-white w-[40px] h-[40px] rounded-lg cursor-not-allowed"),
                            variants: {
                                hidden: {
                                    opacity: 0,
                                    y: 10
                                },
                                inputVisible: {
                                    opacity: 1,
                                    y: 0,
                                    transition: {
                                        duration: .6,
                                        ease: "easeInOut"
                                    }
                                }
                            },
                            children: (0, s.jsx)(ft, {})
                        })]
                    }), (0, s.jsx)(la, {
                        options: ia,
                        activeKey: l,
                        onClick: e => {
                            const t = u(e.content);
                            if (d(e.key), n(!0), (0, Gt.GX)("official_click", {
                                    object: "website_type",
                                    choice: e.key
                                }), k.current) {
                                const e = k.current;
                                e.blur(), requestAnimationFrame((() => {
                                    e.focus(), e.value = t, e.dispatchEvent(new Event("input", {
                                        bubbles: !0
                                    })), a(t), e.setSelectionRange(t.length, t.length)
                                }))
                            }
                        },
                        isDisable: g !== Aa.common
                    })]
                })
            }
            var ka = x.memo(da);
            const ga = [{
                    font: "anton",
                    textSize: "text-[12vw] md:text-[9.3vw] md:leading-snug lg:text-[8.5vw] lg:leading-tight xl:text-[8vw] 2xl:text-[8.5vw] leading-tight",
                    tracking: "",
                    delay: 7e3
                }, {
                    font: "archivo",
                    textSize: "text-[9vw] md:text-[9vw] md:leading-snug lg:text-[7.5vw] lg:leading-tight xl:text-[6.8vw] 2xl:text-[6.5vw] leading-tight",
                    tracking: "tracking-widest",
                    delay: 0
                }, {
                    font: "merriweather",
                    textSize: "text-[10vw] md:text-[9.2vw] md:leading-snug lg:text-[7.8vw] lg:leading-tight xl:text-[7vw] 2xl:text-[6.8vw] leading-tight",
                    tracking: "",
                    delay: 0
                }, {
                    font: "pixel",
                    textSize: "text-[9vw] md:text-[8.5vw] md:leading-snug lg:text-[7vw] lg:leading-tight xl:text-[6.3vw] 2xl:text-[6.5vw] leading-tight",
                    tracking: "",
                    delay: 0
                }],
                pa = x.memo((function(e) {
                    let {
                        message: t = "Magic Your Site Chat by Chat",
                        className: a,
                        duration: i = 15,
                        delay: A
                    } = e;
                    return (0, s.jsx)(tt.M, {
                        children: (0, s.jsx)(ya, {
                            text: t,
                            className: a,
                            duration: i,
                            delay: A
                        })
                    })
                })),
                ya = x.memo((function(e) {
                    let {
                        text: t,
                        className: a,
                        duration: i = 1,
                        delay: A = 0
                    } = e;
                    const o = (0, ut._)();
                    return (0, x.useEffect)((() => {
                        const e = setTimeout((() => {
                            o && o.start("animate")
                        }), A);
                        return () => clearTimeout(e)
                    }), [o, A]), (0, s.jsx)(r.E.div, {
                        initial: "hidden",
                        whileInView: "visible",
                        exit: {
                            opacity: 0
                        },
                        className: a,
                        children: (0, s.jsx)("h1", {
                            children: t.split("").map(((e, t) => (0, s.jsx)(r.E.span, {
                                custom: t,
                                animate: o,
                                initial: {
                                    opacity: 1
                                },
                                variants: {
                                    animate: e => ({
                                        opacity: [0, 1],
                                        transition: {
                                            delay: Math.random() * i,
                                            duration: 1,
                                            ease: "easeInOut",
                                            repeat: 1 / 0,
                                            repeatDelay: 3
                                        }
                                    })
                                },
                                children: e
                            }, t)))
                        })
                    })
                }));
            const ua = x.memo((function() {
                    const [e, t] = (0, x.useState)(0);
                    return (0, x.useEffect)((() => {
                        const e = setTimeout((() => t((e => (e + 1) % ga.length))), 6e3);
                        return () => clearTimeout(e)
                    }), [e]), (0, s.jsx)(r.E.div, {
                        initial: {
                            opacity: 0
                        },
                        whileInView: {
                            opacity: 1
                        },
                        transition: {
                            duration: .1,
                            ease: "easeInOut"
                        },
                        className: "px-8 h-[30vw] max-w-[100vw] md:h-[26vw] lg:h-[20vw] xl:h-[18vw] 2xl:h-[18vw] flex items-center flex-col justify-center text-nowrap",
                        children: (0, s.jsx)(ha, { ...ga[e]
                        })
                    }, e)
                })),
                ha = e => {
                    let {
                        font: t,
                        textSize: a,
                        tracking: i,
                        delay: A
                    } = e;
                    const o = (0, p.useLocale)(),
                        r = "it" === o && "archivo" === t ? "text-[7.5vw] md:text-[7.5vw] md:leading-snug lg:text-[7.5vw] lg:leading-tight xl:text-[6.8vw] 2xl:text-[6.5vw] leading-tight" : a,
                        n = (0, p.useTranslations)(),
                        x = o === ye.i.ja,
                        l = "text-center text-white ".concat(i, " ").concat({
                            anton: x ? "font-BuildingTracks" : "font-Anton",
                            archivo: x ? "font-DelaGothicOne" : "font-ArchivoBlack",
                            merriweather: x ? "font-SoukouMincho" : "font-Merriweather",
                            pixel: x ? "font-BestTen" : "font-LLPixelFun"
                        }[t], " ").concat(r);
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(pa, {
                            message: n("Home_Hero_Title1"),
                            className: l,
                            duration: 1,
                            delay: A
                        }), (0, s.jsx)(pa, {
                            message: n("Home_Hero_Title2"),
                            className: l,
                            duration: 1,
                            delay: A
                        })]
                    })
                };
            var ma = x.memo(ua),
                fa = JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":200,"w":24,"h":24,"nm":"Comp 1","ddd":0,"assets":[{"id":"0","layers":[{"ddd":0,"ind":1,"ty":4,"nm":"Subtract","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[10.3581,21.3944],[0.0168364,10.3413],[10.3581,0],[20.6995,10.3413],[10.3581,21.3944]],"i":[[0,0],[-0.3438804,7.738599999999998],[-5.7113000000000005,0],[0,-5.711340000000001],[5.711400000000001,0]],"o":[[-5.7113000000000005,0],[0,-5.711340000000001],[5.711400000000001,0],[0,8.003699999999998],[0,0]]}}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":0,"k":[10.349749565124512,10.697199821472168],"ix":2},"a":{"a":0,"k":[10.349750001930772,10.6972],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[10.3581,19.3008],[19.6265,10.0324],[10.3581,0.764023],[1.08975,10.0324],[10.3581,19.3008]],"i":[[0,0],[0,5.1187999999999985],[5.1188,0],[0,-5.118780000000001],[-5.11875,0]],"o":[[5.1188,0],[0,-5.118780000000001],[-5.11875,0],[0,5.1187999999999985],[0,0]]}}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":0,"k":[10.358124732971191,10.032411575317383],"ix":2},"a":{"a":0,"k":[10.358125000000001,10.032411499999998],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[11.99158763885498,12.355896949768066],"ix":2},"a":{"a":0,"k":[10.349726676940918,10.697205543518066],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":201,"st":0,"bm":0},{"ddd":0,"refId":"1","w":20000,"h":20000,"ind":2,"ty":0,"nm":"Masked Group 1","sr":1,"ks":{"p":{"a":0,"k":[10012,10012.397958278656],"ix":2},"a":{"a":0,"k":[10000,10000],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":201,"st":0,"bm":0}]},{"id":"2","layers":[{"ddd":0,"ind":3,"ty":4,"nm":"Frame region","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[24,24],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":0,"k":[12,12],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":201,"st":0,"bm":0},{"ddd":0,"refId":"0","w":20000,"h":20000,"ind":4,"ty":0,"nm":"Frame","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[10000,10000],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":201,"st":0,"bm":0,"tt":1}]},{"id":"3","layers":[{"ddd":0,"ind":5,"ty":4,"nm":"Vector (Stroke)","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[3.629547119140625,0.00007217266829684377],[4.121067523956299,0.5084102749824524],[3.9844448566436768,8.631034851074219],[6.103627681732178,5.874263286590576],[6.804765701293945,5.782581329345703],[6.896447658538818,6.483719348907471],[3.9199273586273193,10.355770111083984],[3.5383529663085938,10.595526695251465],[3.3122878074645996,10.593337059020996],[3.187765598297119,10.565567016601562],[3.14986252784729,10.554017066955566],[3.1372523307800293,10.549821853637695],[3.132645606994629,10.548233985900879],[3.1307835578918457,10.547582626342773],[3.129584550857544,10.547159194946289],[3.2735378742218018,10.140902519226074],[3.129584550857544,10.547159194946289],[2.9816999435424805,10.494609832763672],[0.0938180461525917,6.470513820648193],[0.2085152268409729,5.77277135848999],[0.9062577486038208,5.8874688148498535],[2.981804370880127,8.779622077941895],[3.121209144592285,0.4915926456451416],[3.629547119140625,0.00007217266829684377]],"i":[[0,0],[0.004644155502319336,-0.27610331773757935],[0,0],[0,0],[-0.2189311981201172,-0.16829681396484375],[0.16829681396484375,-0.2189311981201172],[0,0],[0.07969856262207031,-0.012564659118652344],[0.04419541358947754,0.0069408416748046875],[0.028822898864746094,0.008230209350585938],[0.009778738021850586,0.003177642822265625],[0,0],[0,0],[0,0],[0,0],[-0.14430642127990723,0.4061317443847656],[0,0],[0,0],[0,0],[-0.2243489921092987,0.16100358963012695],[-0.16100353002548218,-0.2243490219116211],[0,0],[0,0],[-0.27610325813293457,-0.004644066095352173]],"o":[[0.27610325813293457,0.004644066095352173],[0,0],[0,0],[0.16829681396484375,-0.2189311981201172],[0.2189311981201172,0.16829681396484375],[0,0],[-0.11773467063903809,0.17917346954345703],[-0.0967702865600586,0.015254020690917969],[-0.05126619338989258,-0.008051872253417969],[-0.015222311019897461,-0.004345893859863281],[0,0],[0,0],[0,0],[0,0],[-0.00008535385131835938,-0.000030517578125],[0,0],[0,0],[0,0],[-0.1610034704208374,-0.2243490219116211],[0.2243490219116211,-0.16100358963012695],[0,0],[0,0],[0.004643917083740234,-0.27610331773757935],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":1,"k":[{"t":0,"s":[9.5367431640625e-7,-1.5884628295898438],"i":{"x":[1],"y":[1]},"o":{"x":[0.8391253591954023],"y":[0.42040816326530606]}},{"t":70,"s":[0,16.161537170410156],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":120,"s":[-18.75,16.161537170410156],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":133,"s":[-18.75,-16.838462829589844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":147,"s":[0.125,-17.213462829589844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":200,"s":[9.5367431640625e-7,-1.5884628295898438],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[3.5000314712524414,5.30168342590332],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":201,"st":0,"bm":0}]},{"id":"1","layers":[{"ddd":0,"ind":6,"ty":4,"nm":"Shape Layer 1","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","it":[{"ty":"el","d":1,"s":{"a":0,"k":[18.08745964434985,20.31743277683445],"ix":2},"p":{"a":0,"k":[0,0],"ix":2}},{"ty":"fl","c":{"a":0,"k":[1,0.8392156862745098,0.25098039215686274],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"tr","p":{"a":0,"k":[0,-9.5367431640625e-7],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":201,"st":0,"bm":0},{"ddd":0,"refId":"3","w":20000,"h":20000,"ind":2,"ty":0,"nm":"Masked Group 1","sr":1,"ks":{"p":{"a":0,"k":[10000,10000],"ix":2},"a":{"a":0,"k":[10000,10000],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":201,"st":0,"bm":0,"tt":1}]}],"layers":[{"ddd":0,"refId":"2","w":20000,"h":20000,"ind":4,"ty":0,"nm":"Frame","sr":1,"ks":{"p":{"a":0,"k":[12,12],"ix":2},"a":{"a":0,"k":[10012,10012],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2}},"ao":0,"ip":0,"op":201,"st":0,"bm":0}],"markers":[]}');

            function va() {
                const e = (0, p.useTranslations)();
                return (0, s.jsxs)(r.E.div, {
                    className: " absolute group z-10 bottom-[26%] md:bottom-8 flex items-center gap-2",
                    initial: {
                        y: 100,
                        opacity: 0
                    },
                    animate: {
                        y: 0,
                        opacity: 1
                    },
                    transition: {
                        duration: .6,
                        delay: 1.8,
                        ease: "easeInOut"
                    },
                    whileTap: {
                        scale: .95
                    },
                    children: [(0, s.jsx)("p", {
                        className: " text-white uppercase text-xs",
                        children: e("Home_Hero_ScrollButton")
                    }), (0, s.jsx)("div", {
                        className: "w-6 h-auto",
                        children: (0, s.jsx)(k(), {
                            animationData: fa,
                            loop: !0
                        })
                    })]
                })
            }
            var wa = x.memo(va);
            const ba = {
                app: "fromHome=Official_website_header"
            };

            function Ba() {
                return (0, s.jsxs)("section", {
                    "data-follow-hidden": !0,
                    className: "relative w-full h-screen flex flex-col items-center justify-center bg-black",
                    id: "hero-section",
                    children: [(0, s.jsxs)(r.E.div, {
                        className: "z-10 pointer-events-none",
                        initial: {
                            y: "2vh"
                        },
                        animate: {
                            y: "-16vh"
                        },
                        transition: {
                            duration: .6,
                            delay: .4,
                            ease: "easeInOut"
                        },
                        children: [(0, s.jsx)("div", {
                            className: "flex md:hidden pb-6 z-50 absolute left-1/2 bottom-full transform -translate-x-1/2 text-center gap-6 justify-center",
                            children: (0, s.jsx)(xt, {
                                className: "group-hover/mouth:scale-110 transition-all"
                            })
                        }), (0, s.jsx)(ma, {})]
                    }), (0, s.jsx)("div", {
                        className: "absolute z-10 bottom-[30%] hidden md:block",
                        children: (0, s.jsx)(ka, {})
                    }), (0, s.jsx)("div", {
                        className: "absolute z-10 bottom-[45%] block md:hidden",
                        children: (0, s.jsx)(Qa, {})
                    }), (0, s.jsx)(wa, {}), (0, s.jsx)(Ea, {}), (0, s.jsx)("div", {
                        className: "absolute z-0 w-full h-full",
                        children: (0, s.jsx)(pt, {})
                    })]
                })
            }
            var Ca = (0, x.memo)(Ba);

            function Qa() {
                const {
                    isLogin: e,
                    userImage: t,
                    userName: a
                } = (0, ct.L)();
                return (0, s.jsx)(r.E.div, {
                    className: " w-full flex flex-col items-center gap-14",
                    initial: {
                        y: 160
                    },
                    animate: {
                        y: 0
                    },
                    transition: {
                        duration: .6,
                        delay: 2.2,
                        ease: "easeInOut"
                    },
                    children: (0, s.jsx)(r.E.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        transition: {
                            duration: .6,
                            delay: 2.2,
                            ease: "easeInOut"
                        },
                        children: (0, s.jsx)(V.Z, {
                            type: "primary",
                            status: "plain",
                            style: {
                                padding: "0 2.5rem",
                                fontWeight: "bold"
                            },
                            onClick: () => (0, lt.b)(!0, ba),
                            children: (0, s.jsxs)("div", {
                                className: "flex gap-[10px] items-center",
                                children: [e && (0, s.jsx)(gt.Z, {
                                    image: t,
                                    name: a,
                                    size: 24
                                }), (0, s.jsx)("span", {
                                    children: "Build your site"
                                })]
                            })
                        })
                    })
                })
            }

            function Ea() {
                const [e, t] = (0, x.useState)(!1), a = (0, n.Z)((() => {
                    t(!0), setTimeout((() => {
                        t(!1)
                    }), 1e3)
                }), 2e3);
                return (0, s.jsxs)("div", {
                    onMouseEnter: a,
                    className: "hidden xl:block group/mouth absolute z-10 bottom-5 right-5 rounded-[20px] transition-all overflow-hidden",
                    children: [(0, s.jsx)("div", {
                        className: c()({
                            [kt().flash]: e
                        }, "hover:scale-90 w-[100px] h-[80px] bg-white absolute left-[-100px]")
                    }), (0, s.jsx)("div", {
                        className: c()(kt()["month-logo"], "flex items-center justify-center border w-[226px] h-[80px] group-hover/mouth:w-[240px] group-hover/mouth:h-[88px] border-[#FFFFFF0A] transition-all bg-black/30 hover:bg-black/70"),
                        children: (0, s.jsx)(xt, {
                            className: "group-hover/mouth:scale-110 transition-all"
                        })
                    })]
                })
            }

            function Da() {
                const [e, t] = (0, x.useState)(""), [a, i] = (0, x.useState)(!1);
                return (0, x.useEffect)((() => {
                    t("".concat(window.location.origin, "/workspace")), setTimeout((() => {
                        i(!0)
                    }), 3e4)
                }), []), a ? (0, s.jsx)(s.Fragment, {
                    children: (0, s.jsx)("iframe", {
                        loading: "lazy",
                        className: "opacity-0 absolute z-[-1] top-0 left-0",
                        src: e,
                        sandbox: "allow-same-origin"
                    })
                }) : null
            }
            var Ia = a(7083),
                Ha = {
                    src: "https://cdn.wegic.ai/_next/static/media/aspectIpad.1e5cc790.png",
                    height: 280,
                    width: 456,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAjUlEQVR42mOIjo7jcHFxczI1NbfS0zOw0tTStlJVVbdUUVFz1Nc34mDw8fETtbGx02KAAEYoZtDV1dOzsLQSBSkQdnBw0gAJ+voFMHl4eDGB2JZWVtpu7u7CIEEROzsHqAkIoG9gqGtr5yDKEBkVw2Hv4Ohsbm5pY2JqZmNiYmpjZmZhbWVl7eLp6cMBAEKfGhBAsoa4AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 5
                },
                Pa = {
                    src: "https://cdn.wegic.ai/_next/static/media/aspectMac.7aa2543a.png",
                    height: 280,
                    width: 456,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAASFBMVEUlJiglJScAAAAkJCYfHyFbW15aW10RERMQEBITFBUTExU4OTs3Nzk6Oz06Oj04ODo3NzkEBAYDAwUCAwUHCAoHBwoCAgQAAADL9UMZAAAAFHRSTlMxMT9BRFNTycnLy+jo6ens7Pz8/L/8IHoAAAAvSURBVHjaHcGFEQAgDASwx92h3X9TOBKI6J3zAdDED2moPcdYR0HyJ2FaqiV3ewEtQwIjAJZBnwAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 5
                },
                ja = {
                    src: "https://cdn.wegic.ai/_next/static/media/aspectPhone.97294e39.png",
                    height: 375,
                    width: 180,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAIBAMAAAAsHUM2AAAAIVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQIAAAD6uKn6AAAAC3RSTlMAExUWFxgZHiZKSjGXYTwAAAAgSURBVHjaY6iazqDAyJDAyuDAymDAzODAwiDAyNAoAQAqxAL+zDrE7wAAAABJRU5ErkJggg==",
                    blurWidth: 4,
                    blurHeight: 8
                },
                Ma = a(15390),
                Oa = a.n(Ma);

            function Na(e) {
                const {
                    CardContent: t
                } = e, {
                    cardType: a,
                    mediaType: i,
                    deviceType: A,
                    title: o,
                    desc: r,
                    video: n,
                    content: l,
                    backgroundImg: d
                } = t, k = (0, x.useRef)(null), g = (0, p.useTranslations)(), y = e => {
                    k.current.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    })
                }, u = e => {
                    k.current.scrollTo({
                        top: 200,
                        behavior: "smooth"
                    })
                }, h = () => {
                    k.current.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    })
                };
                return "mac" === A && "video" === i ? (0, s.jsxs)("div", {
                    "data-follow-hidden": !0,
                    className: "h-full group/mac p-3 pt-6 flex gap-1 md:gap-4 flex-col bg-[#F7F6F5] rounded-[20px] border-[2px] border-[#0000000A]",
                    children: [(0, s.jsx)(oe.default, {
                        className: "absolute left-0 top-0 rounded-[20px]",
                        src: d,
                        alt: "bg"
                    }), (0, s.jsxs)("div", {
                        className: "relative group-hover/mac:translate-y-[-150%] transition-all duration-300 pl-3",
                        children: [(0, s.jsx)("div", {
                            className: "font-bold text-base md:font-bold md:text-2xl md:leading-[30px]",
                            children: g(o)
                        }), (0, s.jsx)("div", {
                            className: "font-medium text-xs md:font-medium md:text-[15px] md:leading-5 text-black/50",
                            children: g(r)
                        })]
                    }), (0, s.jsxs)("div", {
                        className: "w-full md:w-[456px] md:h-[280px] relative group-hover/mac:scale-125 origin-bottom transition-all duration-300",
                        children: [(0, s.jsx)(oe.default, {
                            src: Pa,
                            alt: "mac"
                        }), (0, s.jsx)(D, {
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            className: "bg-black absolute left-[38px] top-[19px] md:left-[58px] md:top-[29px] w-[232px] h-[145px] md:w-[340px] md:h-[214px]",
                            src: n || ""
                        })]
                    })]
                }) : "tablet" === A && "video" === i ? (0, s.jsxs)("div", {
                    "data-follow-hidden": !0,
                    className: "h-full group/mac p-3 pt-6 flex gap-1 md:gap-4 flex-col bg-[#F7F6F5] rounded-[20px] border-[2px] border-[#0000000A]",
                    children: [(0, s.jsx)(oe.default, {
                        className: "absolute left-0 top-0 rounded-[20px]",
                        src: d,
                        alt: "bg"
                    }), (0, s.jsxs)("div", {
                        className: "relative group-hover/mac:translate-y-[-150%] transition-all duration-300 pl-3",
                        children: [(0, s.jsx)("div", {
                            className: "font-bold text-base md:font-bold md:text-2xl md:leading-[30px]",
                            children: g(o)
                        }), (0, s.jsx)("div", {
                            className: "font-medium text-xs md:font-medium md:text-[15px] md:leading-5 text-black/50",
                            children: g(r)
                        })]
                    }), (0, s.jsxs)("div", {
                        className: "w-full md:w-[456px] md:h-[280px] relative group-hover/mac:scale-125 origin-bottom transition-all duration-300",
                        children: [(0, s.jsx)(oe.default, {
                            src: Ha,
                            alt: "Ipad"
                        }), (0, s.jsx)("video", {
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            className: "bg-black absolute top-[19px] left-[48px] md:left-[70px] md:top-[32px] w-[212px] h-[149px] md:w-[314px] md:h-[217px]",
                            children: (0, s.jsx)("source", {
                                src: n,
                                type: "video/mp4"
                            })
                        })]
                    })]
                }) : "phone" === A && "mobile" === a ? (0, s.jsxs)("div", {
                    "data-follow-hidden": !0,
                    className: "h-full",
                    children: [(0, s.jsx)(oe.default, {
                        src: ja,
                        alt: "phone",
                        className: "relative z-10"
                    }), (0, s.jsx)(oe.default, {
                        src: l,
                        alt: "phone",
                        className: "absolute rounded-2xl w-[170px] h-[369px] top-[3px] left-[5px]"
                    })]
                }) : "none" === A ? (0, s.jsxs)("div", {
                    onMouseLeave: h,
                    "data-follow-hidden": !0,
                    className: "h-full relative group/none p-3 pt-6 flex gap-1 md:gap-4 flex-col bg-[#F7F6F5] rounded-[20px] border-[2px] border-[#0000000A]",
                    children: [(0, s.jsx)(oe.default, {
                        className: "absolute left-0 top-0 w-full h-full rounded-[20px]",
                        src: d,
                        alt: "bg"
                    }), (0, s.jsx)("div", {
                        onMouseEnter: y,
                        className: "w-[450px] left-[13px] h-[200px] z-10 absolute"
                    }), (0, s.jsx)("div", {
                        onMouseEnter: u,
                        className: "w-[450px] left-[13px] h-[200px] z-10 top-[200px] absolute"
                    }), (0, s.jsxs)("div", {
                        className: "group-hover/none:translate-y-[-150%] transition-all duration-300 pl-3 relative",
                        children: [(0, s.jsx)("div", {
                            className: "font-bold text-base md:font-bold md:text-2xl md:leading-[30px]",
                            children: g(o)
                        }), (0, s.jsx)("div", {
                            className: "font-medium text-xs md:font-medium md:text-[15px] md:leading-5 text-black/50",
                            children: g(r)
                        })]
                    }), (0, s.jsx)("div", {
                        ref: k,
                        className: c()(Oa()["no-scrollbar"], "px-[10px] group-hover/none:translate-y-[-70px] transition-all duration-300 min-h-[370px] overflow-scroll"),
                        children: (0, s.jsx)("div", {
                            className: "w-full h-[720px] relative origin-bottom rounded-[10px] overflow-hidden",
                            children: (0, s.jsx)(oe.default, {
                                src: l,
                                alt: "mac",
                                className: "h-full object-fill"
                            })
                        })
                    })]
                }) : (0, s.jsx)("div", {
                    "data-follow-hidden": !0,
                    className: "h-full",
                    children: (0, s.jsxs)("div", {
                        className: "relative z-[2] flex flex-col cursor-pointer h-full ".concat("mobile" === a ? "p-6" : "p-[45px]", " "),
                        children: [(0, s.jsx)("div", {
                            className: "text-white p-2 rounded-[10px] top-5 left-5 font-bold mb-1 bg-black absolute",
                            children: "100% JAZZ Home Page"
                        }), (0, s.jsx)("div", {
                            className: "text-black/80 text-[15px] font-medium absolute",
                            children: o && g(o)
                        }), n ? (0, s.jsx)("video", {
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            className: "h-full",
                            children: (0, s.jsx)("source", {
                                src: n,
                                type: "video/mp4"
                            })
                        }) : (0, s.jsx)(oe.default, {
                            className: "h-full",
                            src: l,
                            alt: "content"
                        })]
                    })
                })
            }
            var Ya = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList1-bg.3d638665.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEX19PT19PP09PT18/P08/L18e/08e/08e717+v07+z17un17en17ej07Ob16eP159715Nr14tf14NT14NP11sT11MD1zrb1ya71xKf1xKb1waH1vZz1uZT1sYj1roP1qn31p3j1pXX1oG71nGb0mF/0fC/1ei31eCti5RNTAAAAQUlEQVR42hXBBRKAIAAAwbNbUQS7g///kGEXwM/78wdIu+kxENRq3t8PwmbYjusGYjmuiwZIpFYCJ2tFgeOVVWQBh1IDW0d0AbUAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 8
                },
                La = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList1.aa8fd268.png",
                    height: 741,
                    width: 1320,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgElEQVR42mM4c/XqvzvPnv/fsu/g/8nzFv2fOm/h/77e3v8T+vr+TyjM+c8QlJD6v3nG/P+ixlb/GZQ1/vvHJP5nYGBAxuxAQui/r5fX/507dvw/e/bs/4qKCrCkvJTkfwYJJe3/rIIS/z09XP83VVX+rykv+69vYAhWwMrK9h8AqRFAb7KZ/SUAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 4
                },
                za = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList2-bg.bc7a4614.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAPUlEQVR42mP48uXj86sH1q5k+PL5w5PLx/ftZwCKvLh+4eINIOPLp+f3Hr8EMb5++fDhE5ABZn6BML4gMQADLzpmU7kAogAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                Ja = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList2.1886f507.png",
                    height: 741,
                    width: 1320,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAb0lEQVR42gFkAJv/AJSQhqiopZWWk5eYldXNwt/UytnPxNPKvgCgoZmzs6qYmJA/QjaDelynpICaim+yk30Ao6Wet7ixmpuTUFNKWVY7cnhQUVEzlXhlAI9wI4RqMQAAAAAIAG5aTqOLdqONco54ZOCjMNmZ8wt5AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 4
                },
                Sa = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList3-bg.1ed78185.png",
                    height: 1092,
                    width: 630,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAVklEQVR42hWKQQ4DQQjDgMn8/7dtF0go64MlS/bMYpEtdzv3YDTSkBInWjCzmWErayVsdenz1K+6qMjS9+mkxnyBaPfCwkk1hQvgnPvGIoS77Qk/EYL+7tFMctafmYUAAAAASUVORK5CYII=",
                    blurWidth: 5,
                    blurHeight: 8
                },
                Ga = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList3.bc934a63.png",
                    height: 748,
                    width: 360,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAIAAABRUclSAAAAc0lEQVR42gFoAJf/AIJ6apubmJucm4OEgQCqpJe+vbm+vrunp6QArK+tq66qs7Otf393AIJyUY59W2llWAAKAACjfgWvhABTPQAOHhYAvLOktaygtamVq52JAKKaf6GggJ+NebiolgBybVViakhQQyCypZWALTFA6ZYSBAAAAABJRU5ErkJggg==",
                    blurWidth: 4,
                    blurHeight: 8
                },
                Ta = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList4-bg.f802dcaa.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAmklEQVR42h3Muw7CMAxA0dhxHi0gEBIL//897EiMMJWBorS0IY7r1vLkY11IKRkw64hhqZ9funfP2+uBIlVEzDZ/Lv00vMdvN/S0XnURN+DMBQFaH4i5KCBasFZzYCCSvx7OVPKsAAjkIqHV38vu2LhAeR5XANAmhfYU94FcLoXyNABqFmtlS75x3lnLrtKsAAqqqLXWR6dZkAUaDk6Jn//kXQAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                Wa = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList4.bae183c2.png",
                    height: 1520,
                    width: 864,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAi0lEQVR42gGAAH//AIimkaG3p5uzo5qypIWjjQDe1Lvg1bi1p45NKQBwc2gA1Mi02c24wbWjoY97rqSYAE1JSjg3PMC3pfLjx/DjywDJv63IuaLJwLLAt6i9saMA7eHK7+DF19DAjIF2i3dzAI+Mim1lY9LLvuLUuuTZxACkopyqpqDRyLjUxq7ZzbkzM09VgOMAFwAAAABJRU5ErkJggg==",
                    blurWidth: 5,
                    blurHeight: 8
                },
                Ra = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList5-bg.1228397c.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAhUlEQVR42j2JUQrDMAxDJcdOR9L737Bf2/ozKEtw44V1TAiE3uO+7/imtbZt23Ec19VryFmWUkiOMVJKfyE553VdJ/qJoIMBSSpWa53I3Umq8wWOgKkUyzcQvfWI0MaHMA0uADLV1GKEu+ubd0MNuEBPLCpiZoHQjifgQKRYTrapJWUL+wCiIzoGuToAFgAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                Fa = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList5.e0a86a09.png",
                    height: 1520,
                    width: 864,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAi0lEQVR42gGAAH//AMrLyp6enrW1tb6+vpKSkgD49/fo5uft7Oz29vbp6egAxszJy9HOxMnH1NzU5OriACZzdkeLiVmVkDKAgTBwdAAAAEwAQWUcU3ADRGcRNV8AbJUAa5QAa5QAb5UAeZ44ANH+mNL/mNP/mtP/mdX/nQDt6+/y8PTz8fb29Pj29PiOcE2K/Iv8twAAAABJRU5ErkJggg==",
                    blurWidth: 5,
                    blurHeight: 8
                },
                Xa = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList6-bg.ca1844fb.png",
                    height: 1092,
                    width: 630,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAUklEQVR42jXNSQ6AMAxDUUOCEPc/axGlcUyY/spv5SkiAEiq0fsx4y+TmemSbjxB+kyyLMjPs9dilRTorbUISpoM5irvZACFed3MxxjvpctswQVGMkxLPtXnfQAAAABJRU5ErkJggg==",
                    blurWidth: 5,
                    blurHeight: 8
                },
                Ua = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList6.59bf6af5.png",
                    height: 748,
                    width: 360,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAIAAABRUclSAAAAa0lEQVR42hXGyw2DMAwAUM/aDbpA1VbMwIFBuCIxCJDw/wikJBAbYQy80wP0Xs4HM4PBA0/xLNsh0M1GtWM1zHdAN32udKZ0UTbgaa8mW092ox1EZHQ8WL4DizFudUSIRPAO/q/P9xdGcZJeaKhWe4QQ2tcAAAAASUVORK5CYII=",
                    blurWidth: 4,
                    blurHeight: 8
                },
                Va = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList7-bg.0a460061.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEX09PX09PTz8/Ty8vTx8fPv7/Pu7PLt7PLs7PLs6/Lr6/Lr5/Dm5vDl5fDn4O3i4u/h4e/g4O/f4O/b3O3X1+zb1enW1uzV1uvazOXQz+nMyujWxeLIw+XIveHJsdrIsNq9rNvAo9W7m9K2m9O2ldCyjcwtcZw8AAAAN0lEQVR42g3HQQ6AMAwDQa9dgYrE/z9LGjK3QVrPm8TSqQKicQWW5NtfGbE3s8h0c2qCHTfSMPxtYwphv2ZcXQAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                Za = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList7.ad55e97b.png",
                    height: 1520,
                    width: 864,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAhklEQVR42mOorKgsKirKzc1ra51QllrK4OrqZm5uxsDAkBJd7Whuy6Cuoa6urM7JzSLFwMbHwM2QGJtmm+Gb25gb2V1hWhHNYKlvGprjGJMbGFQdFlgVyJCVWZTSnNs2oT4+PtY5w4fBwcfHJ90xItnBI9zaM8aEAQgkGTiN9U2E2XmYGRgANZAh94RTYJQAAAAASUVORK5CYII=",
                    blurWidth: 5,
                    blurHeight: 8
                },
                Ka = {
                    src: "https://cdn.wegic.ai/_next/static/media/workList8-bg.5682a572.png",
                    height: 1296,
                    width: 1296,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAk0lEQVR42jWNsQ7CMAxE49hNGwp0gAUhBga+nG/gN9hZmBATYgkqLWlinER9g2XfyXfgnGPmnzCOt/vjfLk+X72fIimlYiaEsLTVab/yfvoMIRlFjcxNXR136/47vJ0nZlYziLjpFodt09aYPgCg/GmtrbVdawyBFokzYshuRCSqcDZiRhYUCCVEy1HKS5mkQhrqD9ZmXFR4KSnPAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 8
                };
            const qa = [{
                    z: 25,
                    position: {
                        top: "-3%",
                        left: "0%"
                    },
                    initial: {
                        translateZ: 70,
                        opacity: -1
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "mac",
                    video: "https://cdn.wegic.ai/assets/video/workListVideo1.mp4",
                    content: La,
                    backgroundImg: Ya,
                    title: "Home_WorkListCase1_Title",
                    desc: "Home_WorkListCase1_Desc",
                    link: "https://jazz.wegic.app/home",
                    intro: "Home_WorkListCase1_Intro"
                }, {
                    z: 24,
                    position: {
                        bottom: "15%",
                        right: "-8%"
                    },
                    initial: {
                        translateZ: 120,
                        opacity: -1
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "tablet",
                    video: "https://cdn.wegic.ai/assets/video/workListVideo2.mp4",
                    content: Ja,
                    backgroundImg: za,
                    title: "Home_WorkListCase2_Title",
                    desc: "Home_WorkListCase2_Desc",
                    link: "https://nfinity.wegic.app/home",
                    intro: "Home_WorkListCase2_Intro"
                }, {
                    z: 23,
                    position: {
                        bottom: "-20%",
                        left: "50%"
                    },
                    initial: {
                        translateZ: 170,
                        opacity: .5
                    },
                    cardType: "mobile",
                    mediaType: "img",
                    deviceType: "phone",
                    content: Ga,
                    backgroundImg: Sa,
                    title: "Home_WorkListCase3_Title",
                    desc: "Home_WorkListCase3_Desc",
                    link: "https://solacec08fa282.wegic.app/",
                    intro: "Home_WorkListCase3_Intro"
                }, {
                    z: 22,
                    position: {
                        top: "-10%",
                        left: "25%"
                    },
                    initial: {
                        translateZ: 220,
                        opacity: 1
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Za,
                    backgroundImg: Va,
                    title: "Home_WorkListCase4_Title",
                    desc: "Home_WorkListCase4_Desc",
                    link: "https://nft.wegic.app/home",
                    intro: "Home_WorkListCase4_Intro"
                }, {
                    z: 21,
                    position: {
                        bottom: "0%",
                        left: "0"
                    },
                    initial: {
                        translateZ: 270,
                        opacity: 1.5
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Fa,
                    backgroundImg: Ra,
                    title: "Home_WorkListCase5_Title",
                    desc: "Home_WorkListCase5_Desc",
                    link: "https://davis.wegic.app/",
                    intro: "Home_WorkListCase5_Intro"
                }, {
                    z: 20,
                    position: {
                        bottom: "-5%",
                        left: "88%"
                    },
                    initial: {
                        translateZ: 320,
                        opacity: 1.6
                    },
                    cardType: "mobile",
                    mediaType: "img",
                    deviceType: "phone",
                    content: Ua,
                    backgroundImg: Xa,
                    title: "Home_WorkListCase6_Title",
                    desc: "Home_WorkListCase6_Desc",
                    link: "https://fang.wegic.app/home",
                    intro: "Home_WorkListCase6_Intro"
                }, {
                    z: 19,
                    position: {
                        top: "0%",
                        right: "8%"
                    },
                    initial: {
                        translateZ: 400,
                        opacity: 2.5
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "mac",
                    video: "https://cdn.wegic.ai/assets/video/workListVideo3.mp4",
                    backgroundImg: Ka,
                    title: "Home_WorkListCase7_Title",
                    desc: "Home_WorkListCase7_Desc",
                    link: "https://tech-symposium.wegic.app/",
                    intro: "Home_WorkListCase7_Intro"
                }, {
                    z: 19,
                    position: {
                        left: "10%",
                        bottom: "2%"
                    },
                    initial: {
                        translateZ: 420,
                        opacity: 3
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Wa,
                    backgroundImg: Ta,
                    title: "Home_WorkListCase8_Title",
                    desc: "Home_WorkListCase8_Desc",
                    link: "https://morning-brew.wegic.app/",
                    intro: "Home_WorkListCase8_Intro"
                }],
                _a = [{
                    num: "230",
                    text: "Home_WorkList_Performance1",
                    position: {
                        left: "50%",
                        top: "15%"
                    }
                }, {
                    num: "500,000+",
                    text: "Home_WorkList_Performance2",
                    position: {
                        left: "22%",
                        bottom: "25%"
                    }
                }, {
                    num: "80%",
                    text: "Home_WorkList_Performance3",
                    position: {
                        right: "12%",
                        bottom: "20%"
                    }
                }, {
                    num: "95%",
                    text: "Home_WorkList_Performance4",
                    position: {
                        left: "20%",
                        top: "20%"
                    }
                }],
                $a = [{
                    z: 25,
                    position: {
                        top: "0%",
                        left: "13%"
                    },
                    initial: {
                        translateZ: 50,
                        opacity: -1
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "mac",
                    video: "https://aibuildcdn-dev.geesdev.com/assets/video/workListVideo1.mp4",
                    content: La,
                    backgroundImg: Ya,
                    title: "Home_WorkListCase1_Title",
                    desc: "Home_WorkListCase1_Desc",
                    link: "https://jazz.wegic.app/home",
                    intro: "Home_WorkListCase1_Intro"
                }, {
                    z: 24,
                    position: {
                        bottom: "6%",
                        right: "-46%"
                    },
                    initial: {
                        translateZ: 100,
                        opacity: -1
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "tablet",
                    video: "https://aibuildcdn-dev.geesdev.com/assets/video/workListVideo2.mp4",
                    content: Ja,
                    backgroundImg: za,
                    title: "Home_WorkListCase2_Title",
                    desc: "Home_WorkListCase2_Desc",
                    link: "https://nfinity.wegic.app/home",
                    intro: "Home_WorkListCase2_Intro"
                }, {
                    z: 23,
                    position: {
                        bottom: "-4%",
                        left: "-14%"
                    },
                    initial: {
                        translateZ: 120,
                        opacity: -.5
                    },
                    cardType: "mobile",
                    mediaType: "img",
                    deviceType: "phone",
                    content: Ga,
                    backgroundImg: Sa,
                    title: "Home_WorkListCase3_Title",
                    desc: "Home_WorkListCase3_Desc",
                    link: "https://solace.aibuild-aws-app.geesdev.com",
                    intro: "Home_WorkListCase3_Intro"
                }, {
                    z: 22,
                    position: {
                        top: "-8%",
                        left: "60%"
                    },
                    initial: {
                        translateZ: 250,
                        opacity: .5
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Za,
                    backgroundImg: Va,
                    title: "Home_WorkListCase4_Title",
                    desc: "Home_WorkListCase4_Desc",
                    link: "https://nft.wegic.app/home",
                    intro: "Home_WorkListCase4_Intro"
                }, {
                    z: 21,
                    position: {
                        bottom: "0%",
                        left: "0"
                    },
                    initial: {
                        translateZ: 250,
                        opacity: 1
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Fa,
                    backgroundImg: Ra,
                    title: "Home_WorkListCase5_Title",
                    desc: "Home_WorkListCase5_Desc",
                    link: "https://davis.wegic.app/",
                    intro: "Home_WorkListCase5_Intro"
                }, {
                    z: 20,
                    position: {
                        bottom: "-5%",
                        left: "88%"
                    },
                    initial: {
                        translateZ: 300,
                        opacity: 1.5
                    },
                    cardType: "mobile",
                    mediaType: "img",
                    deviceType: "phone",
                    content: Ua,
                    backgroundImg: Xa,
                    title: "Home_WorkListCase6_Title",
                    desc: "Home_WorkListCase6_Desc",
                    link: "https://fang.wegic.app/home",
                    intro: "Home_WorkListCase6_Intro"
                }, {
                    z: 19,
                    position: {
                        top: "-7%",
                        left: "10%"
                    },
                    initial: {
                        translateZ: 350,
                        opacity: 2
                    },
                    cardType: "pc",
                    mediaType: "video",
                    deviceType: "mac",
                    video: "https://aibuildcdn-dev.geesdev.com/assets/video/workListVideo3.mp4",
                    backgroundImg: Ka,
                    title: "Home_WorkListCase7_Title",
                    desc: "Home_WorkListCase7_Desc",
                    link: "https://summit.aibuild-aws-app.geesdev.com/",
                    intro: "Home_WorkListCase7_Intro"
                }, {
                    z: 19,
                    position: {
                        left: "10%",
                        bottom: "-23%"
                    },
                    initial: {
                        translateZ: 450,
                        opacity: 2.5
                    },
                    cardType: "pc",
                    mediaType: "img",
                    deviceType: "none",
                    content: Wa,
                    backgroundImg: Ta,
                    title: "Home_WorkListCase8_Title",
                    desc: "Home_WorkListCase8_Desc",
                    link: "https://morning-brew.aibuild-aws-app.geesdev.com/",
                    intro: "Home_WorkListCase8_Intro"
                }],
                ei = [{
                    num: "226",
                    text: "Home_WorkList_Performance1",
                    position: {
                        left: "15%",
                        top: "37%"
                    }
                }, {
                    num: "300,000+",
                    text: "Home_WorkList_Performance2",
                    position: {
                        left: "15%",
                        top: "47%"
                    }
                }, {
                    num: "80%",
                    text: "Home_WorkList_Performance3",
                    position: {
                        left: "15%",
                        top: "37%"
                    }
                }, {
                    num: "95%",
                    text: "Home_WorkList_Performance4",
                    position: {
                        left: "15%",
                        top: "47%"
                    }
                }],
                ti = .19,
                ai = .25,
                ii = 120,
                si = [.2, .200001, .26, .2600001],
                Ai = [.22, .220001, .43, .4300001],
                oi = [.36, .360001, .52, .520001],
                ri = [.47, .470001, .84, .84001],
                ni = 1800,
                xi = 17,
                li = L.fC,
                ci = L.xz,
                di = (L.h_, x.forwardRef(((e, t) => {
                    let {
                        className: a,
                        ...i
                    } = e;
                    return (0, s.jsx)(L.aV, {
                        "data-follow-hidden": !0,
                        ref: t,
                        className: (0, J.cn)("fixed inset-0 z-50 bg-black/40", "data-[state=open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", a),
                        ...i
                    })
                })));
            di.displayName = L.aV.displayName;
            const ki = x.forwardRef(((e, t) => {
                let {
                    className: a,
                    children: i,
                    ...A
                } = e;
                const o = document.getElementById("dialog-container");
                return (0, s.jsxs)(L.h_, {
                    container: o,
                    children: [(0, s.jsx)(di, {}), (0, s.jsx)(L.VY, {
                        ref: t,
                        "data-follow-hidden": !0,
                        className: (0, J.cn)("fixed grid gap-4 p-0", "left-1/2 -translate-x-1/2", "top-1/2 md:top-10 translate-y-[-50%] md:translate-y-0", "w-full max-w-full", "h-full max-h-full md:h-[calc(100vh-40px)] md:max-h-[calc(100vh-40px)]", "shadow-lg duration-200", "md:rounded-t-[20px]", "bg-background border ", "z-50", "data-[state=open]:animate-in data-[state=closed]:animate-out", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", "data-[state=closed]:slide-out-to-left-1/2 data-[state=open]:slide-in-from-left-1/2", "data-[state=closed]:slide-out-to-bottom-[48%] data-[state=open]:slide-in-from-bottom-[48%]", a),
                        ...A,
                        children: i
                    })]
                })
            }));
            ki.displayName = L.VY.displayName;
            const gi = x.forwardRef(((e, t) => {
                let {
                    className: a,
                    ...i
                } = e;
                const [A, o] = x.useState(!1);
                return (0, s.jsx)(L.x8, {
                    className: (0, J.cn)("flex items-center justify-center", "size-10 rounded-xl hover:bg-black/[0.06]"),
                    onMouseLeave: () => o(!1),
                    onMouseUp: () => o(!1),
                    onMouseDown: () => o(!0),
                    children: (0, s.jsx)(z.Z, {
                        className: (0, J.cn)("size-4 transition-all", A && "translate-y-1")
                    })
                })
            }));
            gi.displayName = L.x8.displayName;
            var pi = a(16924),
                yi = {
                    src: "https://cdn.wegic.ai/_next/static/media/IframeUnloadPreview.e6bdb8e9.png",
                    height: 82,
                    width: 146,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAQAAAAZxLZ7AAAALklEQVR42lXLyQkAIBAEwc0/YfdwpgXBh9S7wsk8HjKQqKsBK9CmSBaNQeH0Vw5lJj8wmEQ+kAAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 4
                },
                ui = a(11590),
                hi = a.n(ui);
            const mi = e => {
                const {
                    link: t,
                    hero: a
                } = e, [i, A] = x.useState(!0), o = x.useRef(null), n = (0, p.useTranslations)();
                return (0, s.jsxs)("div", {
                    className: c()(hi()["no-scrollbar"], "flex flex-col bg-background md:rounded-b-[20px] md:rounded-t-[20px] md:h-[calc(100vh-40px)] md:max-h-[calc(100vh-40px)]"),
                    children: [(0, s.jsxs)("div", {
                        className: "flex justify-between px-6 mt-6 mb-[18px]",
                        children: [(0, s.jsx)(pi.default, {
                            href: t,
                            target: "_blank",
                            className: (0, J.cn)("text-black/40 text-[15px] leading-6 hover:text-black hover:underline transition-all", "max-w-80 md:max-w-[400px]", "overflow-ellipsis overflow-hidden whitespace-nowrap", "py-2"),
                            children: t
                        }), (0, s.jsx)(gi, {})]
                    }), (0, s.jsx)("div", {
                        className: "overflow-scroll w-full h-[calc(100%-40px)] flex flex-col",
                        children: (0, s.jsxs)(r.E.div, {
                            className: (0, J.cn)("md:pb-[120px] md:px-6 pb-20 px-[15px]", "flex items-center justify-center flex-col"),
                            children: [(0, s.jsxs)("div", {
                                className: (0, J.cn)("w-full md:w-full h-[520px] lg:h-[540px]", "flex items-center overflow-scroll justify-center rounded-xl", "border-2 border-solid border-black/[0.04]", "md:mb-12 mb-[71px]", "relative"),
                                children: [i && (0, s.jsx)("div", {
                                    className: "absolute w-full h-full flex items-center justify-center bg-background",
                                    children: (0, s.jsx)(oe.default, {
                                        src: yi,
                                        alt: "iframe-unload"
                                    })
                                }), (0, s.jsx)("iframe", {
                                    ref: o,
                                    src: t,
                                    onLoad: () => {
                                        A(!1)
                                    },
                                    className: "rounded-[0.65rem] w-full h-[520px] lg:h-[540px]"
                                })]
                            }), (0, s.jsx)("div", {
                                className: "w-full flex justify-start px-[48px]",
                                children: (0, s.jsxs)(r.E.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 100
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        duration: .6,
                                        ease: "easeInOut"
                                    },
                                    className: "flex justify-start flex-col gap-6 w-full",
                                    children: [(0, s.jsx)("div", {
                                        className: "text-[20px] md:text-[40px] leading-6 md:leading-[48px] font-black",
                                        children: n(a.title)
                                    }), (0, s.jsx)("div", {
                                        className: "text-base max-w-[600px]",
                                        children: n(a.content)
                                    }), (0, s.jsx)(pi.default, {
                                        href: "https://wegic.ai/app?fromHome=website_example",
                                        target: "_blank",
                                        className: "w-fit h-10 mt-4",
                                        children: (0, s.jsx)(V.Z, {
                                            type: "primary",
                                            status: "plain",
                                            style: {
                                                width: "100%",
                                                fontWeight: 500,
                                                paddingLeft: 34,
                                                paddingRight: 34
                                            },
                                            children: n(a.buttonText)
                                        })
                                    })]
                                })
                            })]
                        })
                    })]
                })
            };

            function fi(e) {
                const {
                    scrollRef: t
                } = e, a = (0, x.useRef)(null), [i, n] = (0, x.useState)(0), l = (0, p.useTranslations)(), c = (0, Ia.Z)().phone, [d, k] = (0, x.useState)(), g = c ? $a : qa, y = c ? ei : _a, u = c ? Ai : si, h = c ? ri : oi, {
                    scrollYProgress: m
                } = (0, A.v)({
                    target: t
                }), f = (0, o.H)(m, u, [0, 1, 1, 0]), v = (0, o.H)(m, h, [0, 1, 1, 1]);
                (0, Ae.W)(m, "change", (e => {
                    if (c) {
                        if (e < ai) return;
                        if (e > .6) return;
                        n(e - ai)
                    } else {
                        if (e < ti) return;
                        if (e > .41) return;
                        n(e - ti)
                    }
                }));
                const w = e => {
                        const t = i * ni - e.initial.translateZ;
                        return t >= ii ? ii : t
                    },
                    b = e => {
                        const t = i * xi - e.initial.opacity;
                        return t >= 1 ? 1 : t
                    },
                    B = e => c ? "mobile" === e.cardType ? "w-[210px] h-[374px]" : "w-[336px] h-[266px]" : "mobile" === e.cardType ? "w-[210px] h-[374px]" : "w-[480px] h-[380px]",
                    C = e => {
                        const {
                            item: t
                        } = e, {
                            title: a,
                            intro: i,
                            link: A
                        } = t, o = {
                            link: A,
                            hero: {
                                title: a,
                                content: i,
                                buttonText: "Button_Build_Text",
                                titleFont: "ArchivoBlack"
                            }
                        };
                        return (0, s.jsx)(mi, { ...o
                        })
                    };
                return (0, s.jsxs)(r.E.div, {
                    id: "anchor-cases",
                    "data-follow-hidden": !0,
                    className: "relative w-full flex flex-col",
                    children: [(0, s.jsxs)("div", {
                        className: "flex flex-col items-center text-[28px] md:text-[40px] px-[24px] md:px-0 text-center mb-10 mt-[80px]",
                        children: [(0, s.jsx)("div", {
                            className: "font-Damion font-normal text-[#d3d3d3]",
                            children: l("Home_WorkListPage_Title")
                        }), (0, s.jsx)("h3", {
                            className: "font-bold text-[48px] leading-[1.4] tracking-[0.72px]",
                            children: l("Home_WorkListPage_SubTitle")
                        })]
                    }), (0, s.jsx)(r.E.div, {
                        className: "sticky top-0 flex justify-center",
                        children: (0, s.jsxs)("div", {
                            ref: a,
                            style: {
                                perspective: "100dvh"
                            },
                            className: "sticky z-10 overflow-hidden h-[100vh] w-full flex flex-col px-6 items-center justify-center gap-[14rem] md:gap-[25rem] xl:gap-[30rem] 2xl:gap-[32rem]",
                            children: [g.map(((e, t) => (0, s.jsx)("div", {
                                style: { ...e.position,
                                    zIndex: e.z,
                                    opacity: b(e),
                                    transform: "translate3d(0, 0, ".concat(w(e), "dvh)")
                                },
                                className: "absolute z-20 cursor-pointer overflow-hidden rounded-[20px] ".concat(B(e)),
                                children: (b(e) > 0 || d === t) && (0, s.jsx)("div", {
                                    "data-follow-hidden": !0,
                                    className: "w-full h-full overflow-hidden ".concat(b(e) > 0 ? "" : "hidden"),
                                    children: (0, s.jsxs)(li, {
                                        "data-follow-hidden": !0,
                                        open: d === t,
                                        onOpenChange: e => k(e ? t : void 0),
                                        children: [(0, s.jsx)(ci, {
                                            "data-follow-hidden": !0,
                                            asChild: !0,
                                            children: (0, s.jsx)("div", {
                                                "data-follow-hidden": !0,
                                                className: "group h-full",
                                                children: (0, s.jsx)(Na, {
                                                    CardContent: e
                                                })
                                            })
                                        }), (0, s.jsx)(ki, {
                                            className: "w-full max-w-[1280px] md:w-[825px] lg:w-[980px] xl:w-[1200px]",
                                            children: d === t && (0, s.jsx)(C, {
                                                item: e
                                            })
                                        })]
                                    })
                                })
                            }, t))), y.map(((e, t) => {
                                const a = t < 2;
                                return (0, s.jsx)(r.E.div, {
                                    style: { ...e.position,
                                        opacity: a ? f : v
                                    },
                                    className: "pointer-events-none z-[26] transition-all duration-500 absolute bg-transparent text-black w-[420px]",
                                    children: c ? (0, s.jsxs)("div", {
                                        className: "text-[24px] font-semibold leading-normal",
                                        children: [(0, s.jsxs)("span", {
                                            className: "text-black leading-[24px] font-normal",
                                            children: [e.num, " "]
                                        }), l(e.text)]
                                    }) : (0, s.jsxs)(s.Fragment, {
                                        children: [(0, s.jsx)("div", {
                                            className: "text-[36px] text-black/30 leading-[45px] md:mb-[5px] font-normal font-KronaOne",
                                            children: e.num
                                        }), (0, s.jsx)("div", {
                                            className: "text-[36px] font-semibold leading-[1.2]",
                                            children: l(e.text)
                                        })]
                                    })
                                }, e.text)
                            }))]
                        })
                    }), (0, s.jsx)("div", {
                        className: "h-[2400px]"
                    })]
                })
            }
            var vi = a(94167),
                wi = a(28935),
                bi = a(12466);

            function Bi(e) {
                let {
                    scrollRef: t
                } = e;
                const a = (0, p.useTranslations)(),
                    i = (0, x.useRef)(null),
                    [o, n] = (0, x.useState)(1),
                    [l, c] = (0, x.useState)(""),
                    [d, k] = (0, x.useState)(),
                    {
                        scrollYProgress: g
                    } = (0, A.v)({
                        target: t,
                        offset: ["start end", "end end"]
                    });
                return (0, x.useEffect)((() => {
                    var e;
                    const t = new IntersectionObserver((e => {
                        e.forEach((e => {
                            if (e.isIntersecting) {
                                var t;
                                const a = Array.from((null === (t = i.current) || void 0 === t ? void 0 : t.childNodes) || []).indexOf(e.target);
                                n(a + 1);
                                const s = e.target.querySelector("video");
                                if (!s) return;
                                s.poster = s.getAttribute("data-poster") || "", s.paused && !(0, v.W7)() && s.play()
                            } else {
                                const t = e.target.querySelector("video");
                                if (!t) return;
                                t.paused || t.pause()
                            }
                        }))
                    }));
                    return null === (e = i.current) || void 0 === e || e.childNodes.forEach((e => {
                        t.observe(e)
                    })), () => {
                        t.disconnect()
                    }
                }), []), (0, s.jsxs)(r.E.div, {
                    className: "relative w-full flex flex-col py-[20%] md:py-[15%] lg:py-[10%] xl:py-[10%] 2xl:py-[8%]",
                    children: [(0, s.jsx)(r.E.div, {
                        className: "sticky top-0",
                        initial: {
                            opacity: 0,
                            y: 200
                        },
                        whileInView: {
                            y: 0,
                            opacity: 1,
                            transition: {
                                type: "spring",
                                bounce: .2,
                                duration: .8
                            }
                        },
                        children: (0, s.jsx)(Ei, {
                            scrollYProgress: g,
                            currentIndex: o
                        })
                    }), (0, s.jsx)("div", {
                        ref: i,
                        className: "w-full cursor-pointer flex flex-col px-6 items-center justify-center py-32 gap-[14rem] md:gap-[25rem] xl:gap-[30rem] 2xl:gap-[32rem]",
                        children: Mi.map(((e, t) => (0, s.jsx)("div", {
                            "data-follow-message": l,
                            onMouseEnter: () => c(Ci(JSON.parse(a("Home_FollowerPointerCard_WorkListMessage".concat(t + 1))), 1)),
                            className: "z-20",
                            children: (0, s.jsxs)(S, {
                                open: d === t,
                                onOpenChange: e => k(e ? t : void 0),
                                children: [(0, s.jsx)(G, {
                                    asChild: !0,
                                    children: (0, s.jsx)("div", {
                                        className: "group",
                                        children: (0, s.jsx)(D, {
                                            muted: !0,
                                            loop: !0,
                                            "data-poster": e.videoPoster.src,
                                            src: e.video,
                                            className: "w-[24rem] md:w-[36rem] xl:w-[39rem] 2xl:w-[46rem] h-auto rounded-xl shadow-lg bg-white group-hover:shadow-xl group-hover:rounded-3xl group-hover:scale-110 group-hover:transition-all duration-300"
                                        })
                                    })
                                }), (0, s.jsx)(F, {
                                    className: " w-[100%] max-w-[100%] h-[100%] max-h-[100%] border-none shadow-none bg-white/0 ",
                                    onInteractOutside: e => e.preventDefault(),
                                    children: d === t && (0, s.jsx)(ji, {
                                        items: e
                                    })
                                })]
                            })
                        }, t)))
                    })]
                })
            }
            const Ci = (e, t) => {
                    const a = ((e, t) => {
                        const a = new Set;
                        for (; a.size < t;) {
                            const t = Math.floor(Math.random() * e);
                            a.add(t)
                        }
                        return Array.from(a)
                    })(e.length, t);
                    return e[a[0]]
                },
                Qi = [
                    [450, .64],
                    [600, .63],
                    [700, .66],
                    [768, .65],
                    [800, .73],
                    [900, .74],
                    [1024, .71]
                ],
                Ei = e => {
                    let {
                        currentIndex: t = 0,
                        scrollYProgress: a
                    } = e;
                    const i = [(0, s.jsx)(Di, {}, 0), (0, s.jsx)(Ii, {}, 1), (0, s.jsx)(Hi, {}, 2), (0, s.jsx)(Pi, {}, 3)],
                        A = (0, x.useRef)(null),
                        n = (0, x.useRef)(null),
                        [l, c] = (0, x.useState)(.74),
                        d = (0, o.H)(a, [l, l + .02], [0, -50]),
                        k = (0, o.H)(a, [l, l + .02], [100, 50]),
                        g = (0, o.H)(a, [l, l + .02], [1, 0]),
                        y = (0, o.H)(a, [l, l + .02], [0, 1]),
                        u = (0, p.useTranslations)();
                    return (0, x.useEffect)((() => {
                        const e = n.current,
                            t = new ResizeObserver((e => {
                                const t = e[0].target.getBoundingClientRect().width;
                                for (const e of Qi)
                                    if (t <= e[0]) {
                                        c(e[1]);
                                        break
                                    }
                            }));
                        return e && t.observe(e), () => {
                            e && t.unobserve(e), t.disconnect()
                        }
                    }), []), (0, s.jsxs)("div", {
                        ref: n,
                        className: "relative w-full h-screen flex flex-col gap-20 items-center justify-center",
                        children: [(0, s.jsxs)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "absolute top-36 lg:top-24 xl:top-24 2xl:top-24 w-[40%] md:w-[30%] lg:w-[25%] xl:w-[20%] 2xl:w-[20%] h-auto",
                            viewBox: "0 0 243.28515625 47.34193636715645",
                            fill: "none",
                            children: [(0, s.jsx)("g", {
                                children: (0, s.jsx)("g", {
                                    filter: "url(#filter_121_2)",
                                    children: (0, s.jsx)("path", {
                                        fill: "#000000",
                                        fillOpacity: "0.06",
                                        d: "M0.00172806 6.10352e-05L9.51082 6.10352e-05L19.5541 24.5029L19.9815 24.5029L30.0248 6.10352e-05L39.5339 6.10352e-05L39.5339 36.4694L32.0548 36.4694L32.0548 12.7323L31.7521 12.7323L22.3143 36.2913L17.2214 36.2913L7.78351 12.6432L7.48079 12.6432L7.48079 36.4694L0.00172806 36.4694L0.00172806 6.10352e-05ZM50.4142 46.673Q48.9718 46.673 47.7163 46.4504Q46.4609 46.2278 45.6418 45.9072L47.3513 40.2267Q49.3635 40.85 50.7436 40.5562Q52.1236 40.2623 52.925 38.4104L53.3702 37.2529L43.5583 9.11739L51.536 9.11739L57.1987 29.204L57.4836 29.204L63.1998 9.11739L71.2309 9.15301L60.5999 39.4254Q59.8342 41.6157 58.5254 43.2451Q57.2165 44.8744 55.2221 45.7737Q53.2277 46.673 50.4142 46.673ZM95.8784 36.4694L85.4433 6.10352e-05L93.8661 6.10352e-05L99.9028 25.3398L100.206 25.3398L106.865 6.10352e-05L114.077 6.10352e-05L120.72 25.3932L121.04 25.3932L127.077 6.10352e-05L135.5 6.10352e-05L125.065 36.4694L117.55 36.4694L110.605 12.6254L110.32 12.6254L103.393 36.4694L95.8784 36.4694ZM151.829 37.0036Q147.68 37.0036 144.661 35.2318Q141.643 33.46 140.005 30.2814Q138.367 27.1028 138.367 22.9002Q138.367 18.6621 140.005 15.4835Q141.643 12.3049 144.661 10.5331Q147.68 8.76125 151.829 8.76125Q155.978 8.76125 158.996 10.5331Q162.015 12.3049 163.653 15.4835Q165.291 18.6621 165.291 22.9002Q165.291 27.1028 163.653 30.2814Q162.015 33.46 158.996 35.2318Q155.978 37.0036 151.829 37.0036ZM151.864 31.1272Q153.752 31.1272 155.016 30.0499Q156.281 28.9725 156.931 27.1028Q157.581 25.233 157.581 22.8468Q157.581 20.4606 156.931 18.5909Q156.281 16.7211 155.016 15.6349Q153.752 14.5486 151.864 14.5486Q149.959 14.5486 148.668 15.6349Q147.377 16.7211 146.727 18.5909Q146.077 20.4606 146.077 22.8468Q146.077 25.233 146.727 27.1028Q147.377 28.9725 148.668 30.0499Q149.959 31.1272 151.864 31.1272ZM170.242 36.4694L170.242 9.11739L177.596 9.11739L177.596 13.8897L177.881 13.8897Q178.629 11.3433 180.392 10.0345Q182.155 8.72563 184.452 8.72563Q185.022 8.72563 185.681 8.79686Q186.339 8.86809 186.838 8.99274L186.838 15.7239Q186.304 15.5636 185.36 15.439Q184.416 15.3143 183.633 15.3143Q181.959 15.3143 180.65 16.0355Q179.341 16.7567 178.584 18.0388Q177.827 19.321 177.827 20.9949L177.827 36.4694L170.242 36.4694ZM197.611 28.5986L197.629 19.499L198.733 19.499L207.494 9.11739L216.202 9.11739L204.432 22.8646L202.633 22.8646L197.611 28.5986ZM190.738 36.4694L190.738 6.10352e-05L198.324 6.10352e-05L198.324 36.4694L190.738 36.4694ZM207.833 36.4694L199.784 24.5563L204.841 19.1963L216.719 36.4694L207.833 36.4694ZM242.664 16.917L235.719 17.3444Q235.541 16.454 234.953 15.7328Q234.366 15.0116 233.413 14.5753Q232.46 14.139 231.143 14.139Q229.38 14.139 228.169 14.878Q226.958 15.6171 226.958 16.8458Q226.958 17.8252 227.741 18.5018Q228.525 19.1785 230.43 19.5881L235.381 20.5853Q239.369 21.4044 241.328 23.2208Q243.287 25.0371 243.287 27.9931Q243.287 30.682 241.711 32.712Q240.135 34.7421 237.402 35.8728Q234.668 37.0036 231.107 37.0036Q225.676 37.0036 222.461 34.7332Q219.247 32.4627 218.695 28.5451L226.156 28.1534Q226.495 29.8095 227.795 30.6731Q229.095 31.5368 231.125 31.5368Q233.119 31.5368 234.339 30.7621Q235.559 29.9875 235.577 28.7588Q235.559 27.726 234.704 27.0582Q233.849 26.3905 232.068 26.0343L227.332 25.0905Q223.325 24.2892 221.375 22.3126Q219.425 20.336 219.425 17.2731Q219.425 14.6377 220.859 12.7323Q222.292 10.8269 224.901 9.79407Q227.51 8.76125 231.018 8.76125Q236.2 8.76125 239.182 10.9515Q242.165 13.1418 242.664 16.917Z"
                                    })
                                })
                            }), (0, s.jsx)("defs", {
                                children: (0, s.jsxs)("filter", {
                                    id: "filter_121_2",
                                    x: "0",
                                    y: "0",
                                    className: " w-60 h-auto",
                                    filterUnits: "userSpaceOnUse",
                                    colorInterpolationFilters: "sRGB",
                                    children: [(0, s.jsx)("feFlood", {
                                        floodOpacity: "0",
                                        result: "feFloodId_121_2"
                                    }), (0, s.jsx)("feColorMatrix", { in: "SourceAlpha",
                                        type: "matrix",
                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                        result: "hardAlpha_121_2"
                                    }), (0, s.jsx)("feOffset", {
                                        dx: "0",
                                        dy: "0.6690848046567467"
                                    }), (0, s.jsx)("feComposite", {
                                        in2: "hardAlpha_121_2",
                                        operator: "out"
                                    }), (0, s.jsx)("feColorMatrix", {
                                        type: "matrix",
                                        values: "0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0"
                                    }), (0, s.jsx)("feBlend", {
                                        mode: "normal",
                                        in2: "feFloodId_121_2",
                                        result: "dropShadow_1_121_2"
                                    }), (0, s.jsx)("feBlend", {
                                        mode: "normal",
                                        in: "SourceGraphic",
                                        in2: "dropShadow_1_121_2",
                                        result: "shape_121_2"
                                    }), (0, s.jsx)("feBlend", {
                                        mode: "normal",
                                        in: "SourceGraphic",
                                        in2: "feFloodId_121_2",
                                        result: "shape_121_2"
                                    }), (0, s.jsx)("feColorMatrix", { in: "SourceAlpha",
                                        type: "matrix",
                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                        result: "hardAlpha_121_2"
                                    }), (0, s.jsx)("feOffset", {
                                        dx: "0",
                                        dy: "0.6690848046567467"
                                    }), (0, s.jsx)("feComposite", {
                                        in2: "hardAlpha_121_2",
                                        operator: "arithmetic",
                                        k2: "-1",
                                        k3: "1"
                                    }), (0, s.jsx)("feColorMatrix", {
                                        type: "matrix",
                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0"
                                    }), (0, s.jsx)("feBlend", {
                                        mode: "normal",
                                        in2: "shape_121_2",
                                        result: "innerShadow_0_121_2"
                                    }), (0, s.jsx)("feColorMatrix", { in: "SourceAlpha",
                                        type: "matrix",
                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                        result: "hardAlpha_121_2"
                                    }), (0, s.jsx)("feMorphology", {
                                        radius: "0.6690848046567467",
                                        operator: "erode",
                                        in: "SourceAlpha"
                                    }), (0, s.jsx)("feOffset", {
                                        dx: "0",
                                        dy: "0"
                                    }), (0, s.jsx)("feComposite", {
                                        in2: "hardAlpha_121_2",
                                        operator: "arithmetic",
                                        k2: "-1",
                                        k3: "1"
                                    }), (0, s.jsx)("feColorMatrix", {
                                        type: "matrix",
                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0"
                                    }), (0, s.jsx)("feBlend", {
                                        mode: "normal",
                                        in2: "innerShadow_0_121_2",
                                        result: "innerShadow_1_121_2"
                                    })]
                                })
                            })]
                        }), (0, s.jsx)(r.E.div, {
                            initial: {
                                opacity: 0,
                                y: 200
                            },
                            whileInView: {
                                y: 0,
                                opacity: 1,
                                transition: {
                                    duration: .8,
                                    ease: "easeInOut",
                                    delay: .4
                                }
                            },
                            viewport: {
                                once: !0
                            },
                            children: i[t - 1]
                        }), (0, s.jsxs)(r.E.div, {
                            ref: A,
                            id: "currentRef",
                            style: {
                                y: d,
                                opacity: g
                            },
                            className: "absolute bottom-20 md:bottom-16 xl:bottom-14 2xl:bottom-14 font-KronaOne flex items-center gap-6 text-black/60",
                            children: [(0, s.jsx)("div", {
                                children: "".concat(t)
                            }), (0, s.jsx)("div", {
                                children: u("Home_WorkList_TotalIcon")
                            }), (0, s.jsx)("div", {
                                children: u("Home_WorkList_Total")
                            })]
                        }), (0, s.jsx)(r.E.div, {
                            style: {
                                y: k,
                                opacity: y
                            },
                            className: "absolute bottom-20 md:bottom-16 xl:bottom-14 2xl:bottom-14",
                            children: (0, s.jsxs)(pi.default, {
                                href: "https://wegichub.wegic.app",
                                target: "_blank",
                                className: "group z-60 font-KronaOne flex items-center gap-2 text-black/60",
                                children: [(0, s.jsx)("p", {
                                    className: "group-hover:text-black ml-4",
                                    children: u("Home_WorkList_ButtonMore")
                                }), (0, s.jsx)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-4 h-auto opacity-0 group-hover:translate-x-1 group-hover:opacity-100 transition-all duration-300",
                                    viewBox: "0 0 16.4375 16.4375",
                                    fill: "none",
                                    children: (0, s.jsx)("path", {
                                        d: "M2.70856 13.2811C-0.207356 10.3652 -0.207385 5.63756 2.70855 2.72163C5.62446 -0.194285 10.3521 -0.194285 13.268 2.72163C16.1839 5.63756 16.1839 10.3652 13.268 13.2811C10.3521 16.197 5.62449 16.197 2.70856 13.2811ZM3.83993 12.1497C6.13099 14.4408 9.84557 14.4408 12.1366 12.1497C14.4277 9.85863 14.4277 6.14406 12.1366 3.853C9.84556 1.56192 6.131 1.56192 3.83992 3.853C1.54886 6.14406 1.54885 9.85863 3.83993 12.1497ZM8.83648 8.2566L8.83647 9.88891C8.83648 9.99499 8.85677 10.097 8.89738 10.195C8.93797 10.2931 8.99578 10.3796 9.07079 10.4546C9.14582 10.5296 9.2323 10.5874 9.33037 10.628C9.42837 10.6686 9.53041 10.6889 9.63649 10.6889C9.68899 10.6889 9.74104 10.6838 9.79257 10.6736C9.8441 10.6633 9.89409 10.6481 9.94262 10.628C9.99115 10.6079 10.0373 10.5833 10.0809 10.5541C10.1246 10.5249 10.165 10.4917 10.2022 10.4546C10.2393 10.4175 10.2725 10.377 10.3016 10.3333C10.3309 10.2897 10.3555 10.2436 10.3756 10.195C10.3957 10.1465 10.4109 10.0965 10.4211 10.045C10.4314 9.99347 10.4365 9.94142 10.4365 9.88891L10.4365 6.35337C10.4365 5.91154 10.0783 5.55337 9.63647 5.55337L6.10095 5.55337C6.04841 5.55336 5.99639 5.55849 5.94487 5.56873C5.89335 5.57898 5.84332 5.59416 5.7948 5.61426C5.74626 5.63436 5.70015 5.659 5.65648 5.68819C5.6128 5.71737 5.5724 5.75054 5.53525 5.78768C5.49811 5.82482 5.46494 5.86523 5.43576 5.90891C5.40658 5.95258 5.38194 5.99869 5.36183 6.04722C5.34173 6.09575 5.32656 6.14577 5.3163 6.19729C5.30606 6.24881 5.30094 6.30083 5.30094 6.35337C5.30094 6.45946 5.32124 6.5615 5.36183 6.65951C5.40243 6.75752 5.46024 6.84404 5.53525 6.91905C5.61027 6.99407 5.69678 7.05187 5.7948 7.09247C5.8928 7.13307 5.99485 7.15337 6.10094 7.15337L7.73308 7.15337L5.54931 9.33714C5.51306 9.37339 5.48072 9.41279 5.45229 9.45536C5.42378 9.49799 5.39974 9.54296 5.38016 9.59027C5.36058 9.63758 5.34575 9.68639 5.33575 9.73664C5.32575 9.78689 5.32076 9.83761 5.32077 9.88882C5.32079 9.94004 5.32574 9.99081 5.33578 10.041C5.34577 10.0913 5.36057 10.14 5.38018 10.1874C5.39978 10.2347 5.42381 10.2797 5.45227 10.3223C5.48072 10.3648 5.51306 10.4043 5.54928 10.4405C5.5855 10.4767 5.62491 10.509 5.66751 10.5375C5.71011 10.5659 5.75507 10.59 5.80239 10.6096C5.84972 10.6292 5.8985 10.644 5.94875 10.654C5.999 10.664 6.04973 10.669 6.10094 10.669C6.15215 10.669 6.20288 10.664 6.25312 10.654C6.30337 10.644 6.35216 10.6292 6.39949 10.6096C6.44682 10.59 6.49179 10.566 6.5344 10.5375C6.57697 10.509 6.61637 10.4767 6.65262 10.4405L8.83648 8.2566Z",
                                        fillRule: "evenodd",
                                        fill: "#000"
                                    })
                                })]
                            })
                        })]
                    })
                },
                Di = () => {
                    const e = (0, p.useTranslations)();
                    return (0, s.jsx)(pa, {
                        message: e("Home_WorkList_Title1"),
                        className: "font-Anton text-center max-w-7xl text-[3.5rem] md:text-8xl md:leading-snug lg:text-9xl lg:leading-tight xl:text-[8.5rem] 2xl:text-[9.5rem] leading-tight",
                        duration: 1
                    })
                },
                Ii = () => {
                    const e = (0, p.useTranslations)();
                    return (0, s.jsx)(pa, {
                        message: e("Home_WorkList_Title2"),
                        className: " font-Merriweather text-center max-w-7xl text-5xl md:text-8xl md:leading-snug lg:text-9xl lg:leading-tight xl:text-[7.5rem] 2xl:text-[8.5rem] leading-tight",
                        duration: 1
                    })
                },
                Hi = () => {
                    const e = (0, p.useTranslations)();
                    return (0, s.jsx)(pa, {
                        message: e("Home_WorkList_Title3"),
                        className: " font-ArchivoBlack text-center max-w-7xl text-5xl md:text-8xl md:leading-snug lg:text-9xl lg:leading-tight xl:text-[8.5rem] 2xl:text-[9.5rem] leading-tight",
                        duration: 1
                    })
                },
                Pi = () => {
                    const e = (0, p.useTranslations)();
                    return (0, s.jsx)(pa, {
                        message: e("Home_WorkList_Title4"),
                        className: " font-LLPixelFun uppercase text-center max-w-7xl text-5xl md:text-8xl md:leading-snug lg:text-9xl lg:leading-tight xl:text-[7.5rem] 2xl:text-[8.5rem] leading-tight",
                        duration: 1
                    })
                },
                ji = e => {
                    let {
                        items: t
                    } = e;
                    const a = (0, p.useTranslations)();
                    return (0, s.jsx)("div", {
                        className: "w-full h-full flex flex-col",
                        children: (0, s.jsxs)("div", {
                            className: "overflow-scroll w-full h-screen flex flex-col",
                            children: [(0, s.jsxs)("div", {
                                className: "sticky top-0 mt-10 w-full z-10 py-6 px-[4%] md:px-[6%] lg:px-[9%] xl:px-[11%] 2xl:px-[14%] flex items-center gap-2.5 backdrop-blur-xl bg-[#F7F6F5]/80",
                                style: {
                                    backdropFilter: "blur(24px)"
                                },
                                children: [(0, s.jsx)(oe.default, {
                                    className: " w-7 h-7 rounded-full",
                                    src: t.avatar,
                                    width: 30,
                                    height: 30,
                                    alt: "avatar"
                                }), (0, s.jsx)(pi.default, {
                                    href: t.link,
                                    target: "_blank",
                                    className: " text-black/70 text-sm 2xl:text-base hover:text-black hover:underline",
                                    children: t.link
                                })]
                            }), (0, s.jsxs)(r.E.div, {
                                className: "px-[4%] md:px-[6%] lg:px-[9%] xl:px-[11%] 2xl:px-[14%] pt-10 pb-32 flex flex-col gap-24 md:gap-28 xl:gap-32 2xl:gap-32",
                                children: [(0, s.jsx)("video", {
                                    className: "w-full h-auto rounded-xl bg-white",
                                    autoPlay: !0,
                                    muted: !0,
                                    loop: !0,
                                    poster: t.videoPoster,
                                    children: (0, s.jsx)("source", {
                                        src: t.video,
                                        type: "video/mp4"
                                    })
                                }), (0, s.jsxs)(r.E.div, {
                                    className: "w-full grid grid-cols-1 items-center justify-between gap-16 2xl:gap-24 xl:grid-cols-[0.6fr_0.4fr] 2xl:grid-cols-[0.6fr_0.4fr]",
                                    initial: {
                                        opacity: 0,
                                        y: 100
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        duration: .6,
                                        ease: "easeInOut"
                                    },
                                    children: [(0, s.jsx)("h1", {
                                        className: "text-5xl md:text-8xl lg:8xl xl:text-8xl 2xl:text-8xl font-".concat(t.font),
                                        children: a(t.hero.title)
                                    }), (0, s.jsxs)("div", {
                                        className: "w-full flex flex-col gap-14 justify-between",
                                        children: [(0, s.jsx)("p", {
                                            children: a(t.hero.content)
                                        }), (0, s.jsxs)("div", {
                                            className: "w-full flex flex-col-reverse items-center gap-5 justify-center md:flex-row lg:flex-row xl:flex-row 2xl:flex-row",
                                            children: [(0, s.jsx)(pi.default, {
                                                href: t.link,
                                                target: "_blank",
                                                className: "w-full",
                                                children: (0, s.jsx)(V.Z, {
                                                    type: "secondary",
                                                    style: {
                                                        width: "100%",
                                                        fontWeight: "bold"
                                                    },
                                                    children: (0, s.jsxs)("div", {
                                                        className: "flex items-center gap-2.5",
                                                        children: [(0, s.jsx)("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "w-3 h-auto",
                                                            viewBox: "0 0 12.958984375 12.283935546875",
                                                            fill: "none",
                                                            children: (0, s.jsx)("path", {
                                                                d: "M12.5482 2.38492L10.427 0.263602C10.0755 -0.0878675 9.50563 -0.0878675 9.15423 0.263602C8.80273 0.615083 8.80273 1.18492 9.15423 1.5364L10.0455 2.4277L7.6078 2.4277C5.34344 2.4277 3.5078 4.26333 3.5078 6.5277L3.5078 7.9877C3.5078 8.48479 3.91075 8.88769 4.4078 8.88769C4.90486 8.88769 5.3078 8.48479 5.3078 7.9877L5.3078 6.5277C5.3078 5.25744 6.33755 4.2277 7.6078 4.2277L10.1398 4.2277L9.15463 5.21288C8.80323 5.56435 8.80273 6.13467 9.15423 6.48614C9.50563 6.83762 10.0755 6.83762 10.427 6.48614L12.5482 4.36482C13.095 3.81809 13.095 2.93166 12.5482 2.38492ZM0 10.884L0 0.90391C0 0.40685 0.40294 0.0039 0.9 0.0039C1.39706 0.0039 1.80001 0.40685 1.80001 0.90391L1.80001 10.484L11.5701 10.484C12.0671 10.484 12.4701 10.8869 12.4701 11.384C12.4701 11.8811 12.0671 12.284 11.5701 12.284L1.40001 12.284C0.6268 12.284 0 11.6572 0 10.884Z",
                                                                fillRule: "evenodd",
                                                                fill: "#000000"
                                                            })
                                                        }), a(t.hero.secondaryButton)]
                                                    })
                                                })
                                            }), (0, s.jsx)(pi.default, {
                                                href: "https://wegic.ai/app?fromHome=website_example",
                                                target: "_blank",
                                                className: "w-full",
                                                children: (0, s.jsx)(V.Z, {
                                                    type: "primary",
                                                    status: "plain",
                                                    style: {
                                                        width: "100%",
                                                        fontWeight: "bold"
                                                    },
                                                    children: a(t.hero.primaryButton)
                                                })
                                            })]
                                        })]
                                    })]
                                }), (0, s.jsx)(r.E.div, {
                                    className: "w-full rounded-xl bg-white",
                                    initial: {
                                        opacity: 0,
                                        y: 100
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        duration: .6,
                                        ease: "easeInOut"
                                    },
                                    children: (0, s.jsx)("video", {
                                        className: "w-full h-auto rounded-xl bg-white",
                                        autoPlay: !0,
                                        muted: !0,
                                        loop: !0,
                                        poster: t.videoPosterExample,
                                        children: (0, s.jsx)("source", {
                                            src: t.content,
                                            type: "video/mp4"
                                        })
                                    })
                                })]
                            })]
                        })
                    })
                },
                Mi = [{
                    videoPoster: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-1.7c432ab6.png",
                        height: 644,
                        width: 1e3,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAfklEQVR42h3MMQ6DIAAAQC0Sg1jtAxj4Bkv9LhsfIWGAriQMJMJC6kQFkhrvAddzzq21pRQIB8bYur6O49t1Pdi2d0qJUmrMB4DHNCHv/XkWMI5jay3GqJTK+RfCvofQX4QQUkoIIUIIY0wIcc7VWgdjjNb62vBtnudleeac/2H+Pe1QdpJPAAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 5
                    },
                    videoPosterExample: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-example-1.a20b79b3.png",
                        height: 630,
                        width: 1800,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAATklEQVR42g3LoRHAIAwAwIxGZ0QxBC74YssWHKJBEi6JC7x/MDNVRcScM9Hf2lcK1vqCiPDeTwgA0HsnojHGnBPc/aYYY0rpjrUWM6vKAUSuOWqr6YqjAAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 3
                    },
                    video: "https://cdn.wegic.ai/assets/video/official-video-1.mp4",
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/example_avatar_1.0039cae8.png",
                        height: 84,
                        width: 84,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCUlEQVR42mMAgezcPK2giMj9nn7+P7X1DX5GxcXtL6up1QJiBobc/HztsOjY95Mm9P9fv2zRf1sDzf+6Jqb/C8vL3xeWlWszpKSn749OSv6/YvHCn0umT/xfkBzz38/N8WdhWcX/0uqa/SAFP+NS0/7PnTHt/9yJvf+rspP/x4X4/c8vK/9fUdfwkyElI+NnUmbW/8amxv8Tm2r/Z8WG/dfQ1PhfXFUNVFD/iyE5LX1/TlHR//jUtJ8eLk7/gW7+b25t87Oupe0/0JH7GTJycrRTMjPf+wUG/VfX1f/PyMzyX05B8X9QeMT7spo6bQYQYGbh1Obk4duvoKj0U1pW9iefsMh+oDBYEgAqwXP2m7SwkgAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    link: "https://scarlett.wegic.app",
                    hero: {
                        title: "Home_WorkList_Title1",
                        content: "Home_WorkList_Content1",
                        primaryButton: "Button_Build_Text",
                        secondaryButton: "Home_WorkList_SecondaryButton"
                    },
                    font: "Anton",
                    content: "https://cdn.wegic.ai/assets/video/official-video-example-1.mp4"
                }, {
                    videoPoster: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-2.bb214d05.png",
                        height: 644,
                        width: 1e3,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AKipoaytprm5s7OzrbGyq7e2sKqqoqipoQCipJzEwLfv59vp4tXv6Nvr5Na/vLGjpZ4AoqSdxsG16+DR7+XW6+DP4ti+x8O3oqSdAKSnn7y5r+LazN/XytbOwN/XyL26sKOmnwCloZeCcmVvW0t8alyEdGZ/bWCVhnisqJ5WxFNy/nCQzwAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 5
                    },
                    videoPosterExample: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-example-2.29c83b91.png",
                        height: 630,
                        width: 1800,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAVklEQVR42gFLALT/AJSFa5eKc5aJcYl7YNjW0cXGxKOjobS0sgCLhXaloZikoJeFf3DW1dLo6Oje3t7m5uUAXE8mbGJGc2pTTz8A1dPQ+Pj49fX09vb1jdMu0ah9fcIAAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 3
                    },
                    video: "https://cdn.wegic.ai/assets/video/official-video-2.mp4",
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/example_avatar_2.79f8c0bd.png",
                        height: 84,
                        width: 84,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAyElEQVR42mNABg3NXewgetHiJZ5btmzMgUtEJ2YzZpW0M0G5/Dt2bL138ezJbDAvNrmQEabQOzg919wv/+uK1Zv/v3h8NxjFeN/wnE1uQTn/VZ2z/0+esejU////heCSyZmlfWFxefvD4rK3Vtc13p0/d6opSHz71k0sDA3tfdypeZVz+if0qCxfvnT++vVrsnds3SAPUjBlyiRGhor6Nkm72BLJadOm5K1bv24DzNTVq5Yyorhh4uQpFtt27KwGsZctXcIMEwcALHVPB8kvCIMAAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    link: "https://protection.wegic.app",
                    hero: {
                        title: "Home_WorkList_Title2",
                        content: "Home_WorkList_Content2",
                        primaryButton: "Button_Build_Text",
                        secondaryButton: "Home_WorkList_SecondaryButton"
                    },
                    font: "Merriweather",
                    content: "https://cdn.wegic.ai/assets/video/official-video-example-2.mp4"
                }, {
                    videoPoster: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-3.812a5beb.png",
                        height: 644,
                        width: 1e3,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAfklEQVR42mPg5WBj4OZRYGDYk+Rxq6PkSm/VwZ66VD8PBnZ2NgYGBmk5uczCIgtF2WYzjcluxj7aigzMzEwMjAz8PFyOtjYaxkb9mWnpgYEMQACUYARK8PGyMDAwMTAY6Ot5uLkyAyWAokAgwMerrqKiqaamqqTEz8XFysoCADYoFAbj3Bi1AAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 5
                    },
                    videoPosterExample: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-example-3.ca163425.png",
                        height: 630,
                        width: 1800,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAT0lEQVR42mPIyMiUV1RkAIMLF86dOXNqzZrVe/bsYrC1MIwIDfH1cANLXHjz5vXDhw+eP3/GoK4ib21prq+lDpQ4f/7cjx/fv3z58vXrFwCUFiRNkAQO3gAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 3
                    },
                    video: "https://cdn.wegic.ai/assets/video/official-video-3.mp4",
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/example_avatar_3.a887eaaf.png",
                        height: 84,
                        width: 84,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0klEQVR42l3OO6rCUBAG4D8S7kVRg0HzwiJpJGkEtQgILsAlpHAhItioGwiYFVi6iVOl9YUW2UP6qUbPgI0DPwzMx8wg/gM+SYIGVN8AuZ5HDcNQABLoGv9LUwNgtHoMQGKaZv1FatkFX5cRHQE+nc+83WxII9d1lQa0Gg35iQ/ar/nyevF8NpUttm0TBq2m6MV0wrfHg2/3O1dVxVmWaUTwgkBpsDscqCgKzvOcy7KkNE01kBNJu9ORJ39Sx3EsTwqyLEv5vk+O41AURSoMQxm+AfQ7U/t4nCanAAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    link: "https://jazz.wegic.app",
                    hero: {
                        title: "Home_WorkList_Title3",
                        content: "Home_WorkList_Content3",
                        primaryButton: "Button_Build_Text",
                        secondaryButton: "Home_WorkList_SecondaryButton"
                    },
                    font: "ArchivoBlack",
                    content: "https://cdn.wegic.ai/assets/video/official-video-example-3.mp4"
                }, {
                    videoPoster: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-4.58fb29c7.png",
                        height: 644,
                        width: 1e3,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAhUlEQVR42mMQZ2AwVFPtrKhY3d2yrb9+XZLJIh+Gw9n8DECQl5Zw8PqS3fenbbkxtT8tfE6OydY8RQYgqMlLWXwked5R1/VnynuSImaky0d4yDIAQUdO8t39y+/tXXJ608LWWI9WXwYVSxEGSQaGCnXhA7O7ju9fX58asjyeYVa6apQRKwAuszGYOOf4lgAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 5
                    },
                    videoPosterExample: {
                        src: "https://cdn.wegic.ai/_next/static/media/official-video-example-4.26192012.png",
                        height: 630,
                        width: 1800,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAVklEQVR42gFLALT/APbLYu3JYujIY+vGTu/m0tPV18XFws7OzADRgLPCdau9dKzBbq7n2ePs7uzp6Ont7ewAoZXkn5renqLdm5zf4OD19fXv8/Py9PTy8O44VXbJFMMAAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 3
                    },
                    video: "https://cdn.wegic.ai/assets/video/official-video4.mp4",
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/example_avatar_4.d4613bec.png",
                        height: 108,
                        width: 108,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAbFBMVEWMgP6LgP6Lf/6Lf/6MgP6LgP6Lf/6LgP6MgP6MgP6Lf/6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6LgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6MgP6LgP6Mf/6MgP56Vc+xAAAAJHRSTlMAAAABAgICAwYLEBUYOkBQV1xgZmlyc3V1foKEjJClp6iprsXIKOcNAAAAQ0lEQVR42hXLtwGAMAwAwZfAJueMMXH/HYHqqoMQVax+5m7ONIDyWK+zFhgmG/sG8C7RbgPae++fClTScSnEoObvkbxlVwLRvPq8YgAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    link: "https://future.wegic.app",
                    hero: {
                        title: "Home_WorkList_Title4",
                        content: "Home_WorkList_Content4",
                        primaryButton: "Button_Build_Text",
                        secondaryButton: "Home_WorkList_SecondaryButton"
                    },
                    font: "LLPixelFun",
                    content: "https://cdn.wegic.ai/assets/video/official-video-example-4.mp4"
                }];
            const Oi = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/annie.73df8c43.png",
                        height: 150,
                        width: 150,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA70lEQVR42g2NS0rDUAAA5+Ulr2lCCwW1lFZddaWrgtfwcC68hUu9gAoKgr+FVaq2MSm0FGI+mE/zMesZZoQfxpmoK1UbNo7j4q3WmHtDMEwUZa4JgVKtFivni7eLM5aX5yThL7Zl0jV1pRVlhZQSd/rEwWjI/qCPP3tm1NEZdBR6FIVUVUESBRhJiqXayM2cNEuRhkQPwgCt2vL5+kDf0ui2TL4XHpM8o5TthgmD2TJGPzqlNz4hapbJzw3+Yk6xLdDf1wI0m97hmIVbYY8mSHXF9O6Wj7gpOJsoF3VjSo28vcNfVmDtHpN6j1zfv+T/rWpo19guk88AAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Annie",
                    content: "Home_Testimonials_Content1",
                    type: "discord"
                },
                Ni = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/LeonardoAceroGuerra.e6b812a1.png",
                        height: 96,
                        width: 96,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABB0lEQVR42h2PvUrDUABGv3tvmoSmpqVYhYBDCoKDzSR0cuns4jP4DA6puzj6Aq5ObiKIg4OOCg5xKFmkoiXaEBKNLUnuj9GzHs5wCGo+bo/cBiVjSfQBhwGLLQIh1TGAF/Z+47sEOFMQ20lmcWCDZst0s2WKUSnoncaF8JWkDmFIX6eR1jYA1izS1RXiKMnHlAvplZznDUY1xgrM5zG6Nq9DlVdcDmhVCWiMIkoWuH4MkX3HyJYFpFTgonYEKphMk93TqzD9zH40U+/g8mLG94ZrneHW+j072N95Pjl/GIVR1nPaZvkUxciLwp68fc36veYhwR8t2/X6XZ/ppmeZOghBYBiN/81fqhF1a3dpSEMAAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Leonardo Acero Guerra",
                    content: "Home_Testimonials_Content2",
                    type: "twitter"
                },
                Yi = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/martin.7f3aba41.png",
                        height: 300,
                        width: 300,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7ElEQVR42lXFzysEUQDA8e+bffNmZpHxKxyQKCe27P4XbsofQuHob9qDiBXZZMVJyoGL2mUYORjNPG9m9im3PXz6iNfo4/elF6my3+f68gydaTY2t9BUECY1TjeKlRAOjw/3rBITPrU4b7eRrouSrpImL1BKsTA2jJdWCSfmsCLHFCUjUuK8x59kWjOzuIwfTpIk39TW6wQOuJUKcnZ6iupQgPJ95PwSK7U1StfH6Awv8HDGw1G+4pjDZpPn7hu9n4KDvW3uOlfkJofj1oUFBvny/53dfStvbzoGUPVGA50m2LIgtwIrBKcnR+YPfCBjIq0uiR8AAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Martin",
                    content: "Home_Testimonials_Content3",
                    type: "discord"
                },
                Li = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/hasantoxr.83f10463.png",
                        height: 96,
                        width: 96,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5ElEQVR42mMAgf///2s+efLk4Lp1634dPnz41549ew7u379fEy7558+fdzU1Nf9BXD1tLTANVPgOJAdScPDp06cgwZ9FhQX/Vy5d8n9SX+/PT58+/QfJgRT8un379v+6qsr/ixbM/79986b/zQ31/798+fIfJAdWcP/+/f+lQN09XZ3/9+zY/n/OjOn/QSaAFbx48eLgjm3b/hfn5/00MDT8n5me9r+hvu4nEECsAALNhNiYd7OnT/sf4O8HduChQ4dAku8+fvwI8Ymmjo5mcmLCQWMjo19A7q8DBw4c/P//P1gSAPJPphL2BYaOAAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "hasantoxr",
                    content: "Home_Testimonials_Content4",
                    type: "twitter"
                },
                zi = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/bella.c1ab9466.png",
                        height: 300,
                        width: 300,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+UlEQVR42gWAu0rDUABAT24uN+nDatpKXxS1RbTgexGh4ODkoD/i7uyHFLd+hZMgCg6CiJQ6SKmC2A4xRpMY8yjaanfrT0mpbOOTMNSx9BbznZTJdEAay1D6sad+NB+RbIOvWKw2WFJF5pqKx/GVkhNvRBRF7FgdFlKbtYyG5iQ8v3lU1lvI6kqDsRlyXKrRPTikXLQQUnDb72EU9hDNVg1MQS6vEU0dVPBN1ozJ13dxp0ME3i9GlHD99Yof2JRLOe5enrgZ3VPPb6AvZ/WLumHyYASoicPHu8vAyeD+CwrlFKkrEdZUW7VlhcteHxiCtcn52SknR/vhDFgKVbbS6NGBAAAAAElFTkSuQmCC",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Bella",
                    content: "Home_Testimonials_Content5",
                    type: "discord"
                },
                Ji = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/LeeJohnson.9bbb24a2.png",
                        height: 96,
                        width: 96,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCklEQVR42mMAgexAV8VgF/vZArKqJ4DcEwbGurO97MwVGaBA0cPWZp+no8eN6Z29ZzbOmnkm1NXuhrme5r4gD1tFBj01uVmGhhY3osIST1zevuXMrZ1bztTERZ4I9TC54eFoOJvB0dzwhJWWxpnenMwzWyf2nVnW1HSmLSfpTEKk+RkrbfUTDDpWFicU9bXO1CeGndk1ue/MhpbmM/XpIWfc3I3O2Brpn2CYnO48e0+u5o2T3XknyhNiz5TFxp+ZGWF+IsfH9Ia8n/Nshv/LPBRPZanuW5zgcaM3JfxMgI7MmVmeyjem+GntY2CQhfhkYaCBYpedyKx6C/ET7S4aJxocVGfP9FYHSwIAZVpmR9LH8Q0AAAAASUVORK5CYII=",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Lee Johnson",
                    content: "Home_Testimonials_Content6",
                    type: "twitter"
                },
                Si = {
                    avatar: {
                        src: "https://cdn.wegic.ai/_next/static/media/luke.255960c8.png",
                        height: 300,
                        width: 300,
                        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABA0lEQVR42gWAzytDcQDAP3v79lIcSG1ri6lxIKEcKCcOrnJzkrM/wMHJ3+AfcJGDcpI5SWoKbcvWcrPZy/Qmb9Hzfnzfj+9bqfe+IxPQIwWdbhff8yiVSiQJhFEcaEopPSZF5bHC0f4eu5ur1Gs1NCFIVKyLHyfAlREPt9ccH+zgu9uUL8/JTs8yousIc2CTFoKN5UU028T1JIVsjl/HR7gSzbctImkTj2d4qtZpGwYzK+uEYcDg+wvx0qxjBxKv18Nst7lrtDicW2OrkCVJhaRzC0snreca/eYrk2OCf6VzX75idCJDfqqIZn10g8/GG1aouKkauDImX5zn7PSCP7MTDAGGx3zA0VWVLwAAAABJRU5ErkJggg==",
                        blurWidth: 8,
                        blurHeight: 8
                    },
                    name: "Luke",
                    content: "Home_Testimonials_Content7",
                    type: "discord"
                },
                Gi = [
                    [Oi, Ni],
                    [Yi, Li, zi],
                    [Ji, Si]
                ],
                Ti = [
                    [Oi, Ni, Ji],
                    [Yi, Li, zi, Si]
                ],
                Wi = [Yi, Li, zi],
                Ri = [Yi, Li, zi, Oi, Ni];
            var Fi = a(45657),
                Xi = a.n(Fi),
                Ui = a(36701),
                Vi = a.n(Ui);
            const Zi = (0, s.jsx)("svg", {
                    width: "68",
                    height: "61",
                    viewBox: "0 0 68 61",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, s.jsx)("path", {
                        d: "M53.554 0H63.9811L41.2009 25.839L68 61H47.0165L30.5816 39.675L11.7762 61H1.34279L25.7084 33.3623L0 0H21.5162L36.3719 19.4918L53.554 0ZM49.8944 54.8062H55.6722L18.3767 5.86851H12.1765L49.8944 54.8062Z",
                        fill: "white",
                        fillOpacity: "0.2"
                    })
                }),
                Ki = (0, s.jsx)("svg", {
                    width: "80",
                    height: "62",
                    viewBox: "0 0 80 62",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, s.jsx)("path", {
                        d: "M67.7676 5.77264C62.5115 3.35357 56.9627 1.6374 51.263 0.667969C50.4831 2.06962 49.7773 3.51174 49.1488 4.98828C43.0775 4.06856 36.9034 4.06856 30.832 4.98828C30.2032 3.51189 29.4975 2.06979 28.7178 0.667969C23.0144 1.64559 17.462 3.36583 12.2006 5.78529C1.75548 21.3207 -1.07604 36.4702 0.339722 51.4047C6.45667 55.948 13.3033 59.4033 20.5819 61.6203C22.2209 59.4044 23.6711 57.0535 24.9173 54.5927C22.5504 53.704 20.2658 52.6076 18.0902 51.3161C18.6628 50.8987 19.2228 50.4685 19.7639 50.051C26.0946 53.0439 33.0041 54.5957 39.9999 54.5957C46.9956 54.5957 53.9051 53.0439 60.2358 50.051C60.7832 50.5001 61.3432 50.9303 61.9095 51.3161C59.7297 52.6097 57.441 53.7082 55.0698 54.5991C56.3145 57.0587 57.7648 59.4076 59.4052 61.6203C66.6901 59.4122 73.5419 55.9586 79.66 51.411C81.3211 34.0918 76.8222 19.0815 67.7676 5.77264ZM26.7106 42.2201C22.7653 42.2201 19.506 38.6209 19.506 34.193C19.506 29.7652 22.6521 26.1344 26.698 26.1344C30.7439 26.1344 33.9782 29.7652 33.9089 34.193C33.8397 38.6209 30.7314 42.2201 26.7106 42.2201ZM53.2891 42.2201C49.3376 42.2201 46.0908 38.6209 46.0908 34.193C46.0908 29.7652 49.2369 26.1344 53.2891 26.1344C57.3413 26.1344 60.5504 29.7652 60.4812 34.193C60.412 38.6209 57.3099 42.2201 53.2891 42.2201Z",
                        fill: "white",
                        fillOpacity: "0.1"
                    })
                });
            var qi = e => {
                const {
                    avatar: t,
                    name: a,
                    content: i,
                    type: A
                } = e, o = (0, p.useTranslations)();
                return (0, s.jsxs)("div", {
                    className: c()(Vi()["testimonial-card"], Vi()["type-".concat(A)], "gap-4 md:gap-4 mx-auto w-full md:w-[350px] xl:w-[370px] "),
                    children: [(0, s.jsxs)("div", {
                        className: "flex gap-3 items-center",
                        children: [(0, s.jsx)("div", {
                            className: "w-10 h-10 md:w-12 md:h-12 rounded-full overflow-hidden flex-shrink-0",
                            children: (0, s.jsx)(oe.default, {
                                src: t,
                                alt: a
                            })
                        }), (0, s.jsx)("div", {
                            className: c()(Vi().name, "text-base md:text-xl"),
                            children: a
                        })]
                    }), (0, s.jsx)("div", {
                        className: c()(Vi().content, "text-sm md:text-base"),
                        dangerouslySetInnerHTML: {
                            __html: o(i)
                        }
                    }), (0, s.jsx)("div", {
                        className: Vi().icon,
                        children: "twitter" === A ? Zi : "discord" === A ? Ki : null
                    })]
                })
            };
            var _i = () => {
                const e = (0, p.useTranslations)(),
                    [t, a] = (0, x.useState)(!1);
                return (0, s.jsxs)("div", {
                    id: "anchor-comment",
                    className: c()("z-10 relative w-full overflow-hidden select-auto pt-[80px] pb-[100px] md:pb-[44px]", Xi().testimonial),
                    "data-follow-hidden": "true",
                    children: [(0, s.jsx)("div", {
                        className: c()("font-Damion text-[28px] md:text-[40px]", Xi().subtitle),
                        children: e("Home_Testimonials_Subtitle")
                    }), (0, s.jsx)("div", {
                        className: "mt-2 md:mt-0 text-center text-[28px] tracking-[0.72px] md:text-[48px] font-bold text-black text-opacity h-10 flex items-center md-[40px]",
                        children: e("Home_Testimonials_Title")
                    }), (0, s.jsxs)("div", {
                        className: "mt-20 md:mt-[104px] justify-center",
                        children: [(0, s.jsx)("div", {
                            className: "hidden xl:flex flex-row gap-5",
                            children: Gi.map(((e, t) => (0, s.jsx)("div", {
                                className: "flex flex-col gap-5 items-center px-[10px] sm:px-6 md:px-0 w-full",
                                children: e.map((e => (0, x.createElement)(qi, { ...e,
                                    key: e.name
                                })))
                            }, t)))
                        }), (0, s.jsx)("div", {
                            className: "hidden md:flex xl:hidden flex-row gap-5",
                            children: Ti.map(((e, t) => (0, s.jsx)("div", {
                                className: "flex flex-col gap-5 items-center px-[10px] sm:px-6 md:px-0 w-full",
                                children: e.map((e => (0, x.createElement)(qi, { ...e,
                                    key: e.name
                                })))
                            }, t)))
                        }), (0, s.jsxs)("div", {
                            className: "flex md:hidden flex-col gap-5 items-center px-6 sm:px-6 md:px-0 w-full",
                            children: [(t ? Ri : Wi).map((e => (0, x.createElement)(qi, { ...e,
                                key: e.name
                            }))), (0, s.jsx)("div", {
                                onClick: () => {
                                    a(!t)
                                },
                                className: Xi().more,
                                children: e(t ? "FAQ_Button_Less" : "FAQ_Button_More")
                            })]
                        })]
                    })]
                })
            };
            var $i = function() {
                    const e = (0, p.useTranslations)(),
                        t = (0, x.useRef)(null),
                        a = (0, x.useRef)(null),
                        {
                            currentLanguage: i
                        } = (0, ge.Z)(),
                        A = i === ye.i.en || i === ye.i["zh-cn"] || i === ye.i["zh-hk"] || i === ye.i.es,
                        {
                            FeatureArtLottieView: o
                        } = Ge({
                            AnchorRef: t
                        }),
                        {
                            FeaturePathLottieView: r
                        } = We({
                            style: {
                                top: "-112px",
                                left: "55%",
                                width: 360,
                                height: 299
                            },
                            AnchorRef: t
                        }),
                        [n, l] = (0, x.useState)("autoUpdate");
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            ref: a,
                            "data-follow-hidden": !0,
                            className: "w-full bg-black relative pt-20",
                            children: (0, s.jsxs)("div", {
                                className: "pb-[30px] sticky top-4",
                                children: [(0, s.jsxs)("div", {
                                    className: "text-white text-center sticky top-20 pb-16 mb-[600px]",
                                    children: [(0, s.jsx)("div", {
                                        style: {
                                            color: "rgba(130 130 130"
                                        },
                                        className: "font-normal font-Damion text-[28px] leading-[100%] mb-2",
                                        children: e("Home_Feature_Subtitle")
                                    }), (0, s.jsx)("h1", {
                                        className: "text-[28px] font-bold leading-[100%] text-center px-[19px]",
                                        children: e("Home_Feature_Title")
                                    })]
                                }), (0, s.jsx)("div", {
                                    className: "w-full flex flex-col relative z-10 justify-center items-center px-6 mt-[-600px]",
                                    children: (0, s.jsxs)("div", {
                                        className: "flex w-full flex-col z-20 relative justify-center items-center gap-4",
                                        children: [(0, s.jsx)("div", {
                                            className: "w-full sticky top-[235px] mb-[110px]",
                                            children: (0, s.jsx)(Je, {
                                                children: (0, s.jsxs)("div", {
                                                    className: c()(Me()["feature-card-mobile"]),
                                                    children: [(0, s.jsx)("div", {
                                                        className: "py-4 px-6 text-2xl leading-[30px] font-semibold",
                                                        children: e("Home_Feature_Build")
                                                    }), (0, s.jsxs)("div", {
                                                        className: "relative h-full",
                                                        children: [(0, s.jsx)(oe.default, {
                                                            className: "absolute top-0 w-full h-[100px]",
                                                            width: 540,
                                                            height: 140,
                                                            src: ne,
                                                            alt: ""
                                                        }), (0, s.jsx)(D, {
                                                            className: "w-full h-full object-cover",
                                                            muted: !0,
                                                            loop: !0,
                                                            poster: le.src,
                                                            src: "".concat(pe.QX, "/assets/video/FeartureCreate.mp4")
                                                        })]
                                                    })]
                                                })
                                            })
                                        }), (0, s.jsx)("div", {
                                            className: "w-full sticky top-[305px] mt-[-100px] mb-[40px]",
                                            children: (0, s.jsx)(Je, {
                                                children: (0, s.jsxs)("div", {
                                                    className: c()(Me()["feature-card-mobile"]),
                                                    children: [(0, s.jsx)("div", {
                                                        className: "py-4 px-6 text-2xl leading-[30px] font-semibold",
                                                        children: e("Home_Feature_Edit")
                                                    }), (0, s.jsxs)("div", {
                                                        className: "relative h-full",
                                                        children: [(0, s.jsx)(oe.default, {
                                                            className: "absolute top-0 w-full h-[100px]",
                                                            width: 540,
                                                            height: 140,
                                                            src: ne,
                                                            alt: ""
                                                        }), (0, s.jsx)(D, {
                                                            className: "w-full h-full object-cover",
                                                            muted: !0,
                                                            loop: !0,
                                                            poster: ce,
                                                            src: "".concat(pe.QX, "/assets/video/FeatureEdit.mp4")
                                                        })]
                                                    })]
                                                })
                                            })
                                        }), (0, s.jsx)("div", {
                                            className: "w-full sticky mt-[-30px] mb-[-30px]",
                                            children: (0, s.jsx)(Je, {
                                                children: (0, s.jsxs)("div", {
                                                    className: c()(Me()["feature-card-mobile"]),
                                                    children: [(0, s.jsx)("div", {
                                                        className: "py-4 px-6 text-2xl leading-[30px] font-semibold",
                                                        children: e("Home_Feature_Public")
                                                    }), (0, s.jsxs)("div", {
                                                        className: "relative h-full",
                                                        children: [(0, s.jsx)(oe.default, {
                                                            className: "absolute top-0 w-full h-[100px]",
                                                            width: 540,
                                                            height: 140,
                                                            src: ne,
                                                            alt: ""
                                                        }), (0, s.jsx)(D, {
                                                            className: "w-full h-full object-cover",
                                                            muted: !0,
                                                            loop: !0,
                                                            poster: ke,
                                                            src: "".concat(pe.QX, "/assets/video/FeaturePublic.mp4")
                                                        })]
                                                    })]
                                                })
                                            })
                                        })]
                                    })
                                })]
                            })
                        }), (0, s.jsx)("div", {
                            "data-follow-hidden": !0,
                            className: "w-full z-30 bg-black flex flex-col justify-center items-center",
                            children: (0, s.jsxs)("div", {
                                className: "px-6 w-full",
                                children: [(0, s.jsx)("div", {
                                    className: "text-[24px] font-bold text-white text-center my-24",
                                    children: e("Home_Feature_AITeam")
                                }), (0, s.jsxs)("div", {
                                    className: "bg-[#0E0E0E] border-[2px] border-[#232323] p-3 rounded-[20px] w-full flex flex-col gap-6 justify-center items-center",
                                    children: [(0, s.jsxs)("div", {
                                        className: "w-full",
                                        children: [(0, s.jsx)("div", {
                                            onClick: () => l("autoUpdate"),
                                            className: "".concat("autoUpdate" === n ? "bg-white/10" : "", " transition-all text-xl font-medium leading-6 text-white p-[26px] rounded-[10px]"),
                                            children: e("Home_Feature_AutoUpdate")
                                        }), (0, s.jsx)("div", {
                                            onClick: () => l("digitalHuman"),
                                            className: "".concat("digitalHuman" === n ? "bg-white/10" : "", " transition-all text-xl font-medium leading-6 text-white p-[26px] rounded-[10px]"),
                                            children: e("Home_Feature_DigitalHuman")
                                        })]
                                    }), (0, s.jsxs)("div", {
                                        className: "w-full h-[316px] rounded-[10px] border-[2px] border-[#FFFFFF1A] overflow-hidden",
                                        children: ["autoUpdate" === n && (0, s.jsx)(D, {
                                            className: "w-full h-full",
                                            onEnded: () => l("digitalHuman"),
                                            muted: !0,
                                            src: "".concat(pe.QX, "/assets/video/autoUpdate.mp4")
                                        }), "digitalHuman" === n && (0, s.jsx)(D, {
                                            className: "w-full h-full",
                                            onEnded: () => l("autoUpdate"),
                                            muted: !0,
                                            src: "".concat(pe.QX, "/assets/video/digitalHuman.mp4")
                                        })]
                                    })]
                                })]
                            })
                        }), (0, s.jsxs)("div", {
                            "data-follow-hidden": !0,
                            className: "w-full z-10 bg-black px-6 py-[80px] overflow-hidden",
                            children: [(0, s.jsxs)("div", {
                                className: "flex flex-col gap-[100px] justify-center items-center",
                                children: [(0, s.jsx)("div", {
                                    className: "font-bold text-[32px] text-white text-center",
                                    children: e("Home_Feature_CTATitle")
                                }), (0, s.jsxs)("div", {
                                    className: "relative",
                                    children: [o, !A && (0, s.jsx)(oe.default, {
                                        width: 100,
                                        height: 100,
                                        className: "absolute bottom-[5px] left-[0px] w-full h-full z-0 scale-y-150 scale-x-[1.4]",
                                        src: xe,
                                        alt: "CirclePath"
                                    }), A && r, (0, s.jsx)(V.Z, {
                                        onClick: () => {
                                            window.location.href = "https://wegic.ai/app?fromHome=website_cta1"
                                        },
                                        type: "primary",
                                        status: "plain",
                                        style: {
                                            fontWeight: "bold",
                                            fontSize: 20,
                                            lineHeight: "20px",
                                            paddingTop: 12,
                                            paddingBottom: 12,
                                            height: "auto"
                                        },
                                        children: e("Home_Feature_CTAText")
                                    })]
                                })]
                            }), (0, s.jsx)("div", {
                                ref: t,
                                className: "w-[1px] h-[1px]"
                            })]
                        })]
                    })
                },
                es = a(50564),
                ts = a.n(es);
            const as = {
                animationData: JSON.parse('{"v":"5.7.5","fr":100,"ip":0,"op":500,"w":120,"h":200,"nm":"Comp1","ddd":0,"metadata":{"backgroundColor":{"r":251,"g":251,"b":251}},"assets":[{"id":"0","layers":[{"ddd":0,"ind":1,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[-77,-93],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":4,"nm":"右手:0:0:rg-foreground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":1,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[474.7312109754469,474.7312109754469],"ix":2},"p":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":5,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},"s":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"e":{"a":0,"k":[0.00241851806640625,5.787300109863281],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"a":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":5,"s":[95.18107604980469,110.5035400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[94.93107604980469,109.2535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[94.36652994155884,110.63403606414795],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[94.83251953125,109.7535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[94.83251953125,109.7535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":490,"s":[96.58251953125,106.75734405517579],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":5,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":490,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":1,"k":[{"t":5,"s":[-3.341681002894269],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[3.0704154322201376],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[8.473435415226104],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[13.295472524691089],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[13.295472524691089],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":4,"nm":"右手:0:0:rg-background","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":1,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[35,29],"ix":2},"p":{"a":0,"k":[94.5,107.5],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":1,"k":{"a":1,"k":[{"t":5,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},"s":{"a":0,"k":[0,0],"ix":2},"e":{"a":0,"k":[0,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"1","layers":[{"ddd":0,"ind":4,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[-8,-86],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":5,"ty":4,"nm":"左手:0:0:rg-foreground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":4,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[416.68945294008404,416.68945294008404],"ix":2},"p":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":5,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":143,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0,1,0.25882352941176473,0.33725490196078434,1,1,0.7411764705882353,0.7529411764705882,0,1,1,1],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"e":{"a":0,"k":[0.00241851806640625,5.787300109863281],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"a":{"a":0,"k":[0.00241851806640625,-4.046241760253906],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":5,"s":[28.6790911274013,110.60870855632449],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[28.453871877675958,110.00455873790408],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":30,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[26.856459768300958,110.77491396251345],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[27.912306936269708,107.65699404063845],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[33.828627737050965,111.76530092540408],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[31.540846975332215,108.63065737071658],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[34.840041311269715,111.76530092540408],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[31.540846975332215,108.59766786876345],"i":{"x":[0.3045977011494253],"y":[1]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[26.832533987050958,110.75358217540408],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[26.832533987050958,110.75358217540408],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}},{"t":490,"s":[26.832533987050958,106.75251257243777],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":5,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[100,100],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[100,100],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[100,100],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[100,100],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}},{"t":490,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":1,"k":[{"t":5,"s":[-11.816583487963113],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[-11.816583487963113],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[56],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[60],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[56],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[60],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[47.062325158617654],"i":{"x":[0.3045977011494253],"y":[1]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[-1.1611326639402932],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[-1.1611326639402932],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":6,"ty":4,"nm":"左手:0:0:rg-background","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":4,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[50,46],"ix":2},"p":{"a":0,"k":[33,109],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":1,"k":{"a":1,"k":[{"t":5,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":143,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0,1,0.7411764705882353,0.7529411764705882,0,1],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,0],"ix":2},"e":{"a":0,"k":[0,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"2","layers":[{"ddd":0,"ind":7,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":1,"k":[{"t":35,"s":[55.041744232177734,71.5716323852539],"o":{"x":[0.42],"y":[0]},"i":{"x":[1],"y":[1]}},{"t":60,"s":[55.82901382446289,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[55.82901382446289,31.425106048583984],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[54.60180998248336,30.547271268180314],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[54.60180998248336,30.547271268180314],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[55.82901382446289,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[55.82901382446289,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[55.82901382446289,68.44379425048828],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":75,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-8.706964825682508],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-8.706964825682508],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":8,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":95,"s":[45],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[45],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":7},{"ddd":0,"ind":9,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":95,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[100,100],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":8},{"ddd":0,"ind":10,"ty":3,"nm":"右眼","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[125.21953582763669,125.21953582763669],"ix":2},"r":{"a":1,"k":[{"t":95,"s":[-45],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-45],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":9},{"ddd":0,"ind":11,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":10},{"ddd":0,"ind":12,"ty":4,"nm":"瞳孔:0:0:rg-shape-mask","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"parent":11,"shapes":[{"ty":"gr","nm":"瞳孔","it":[{"ty":"el","d":1,"s":{"a":1,"k":[{"t":95,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[5.955282692188149,5.955282692188145],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"p":{"a":0,"k":[0,0],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":45,"s":[9.856398719421122e-7,1.898421168327332],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"3","w":7,"h":9,"ind":13,"ty":0,"nm":"瞳孔:0:0:rg-precomp","sr":1,"ks":{"p":{"a":0,"k":[-3,-3],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":11,"tt":1},{"ddd":0,"ind":14,"ty":4,"nm":"眼白","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":10,"shapes":[{"ty":"gr","nm":"眼白","it":[{"ty":"rc","d":1,"s":{"a":1,"k":[{"t":0,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":160,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[9.105843866916974,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":1,"k":[{"t":160,"s":[4.552921933458487],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[4.552921933458487],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":160,"s":[0,1,0.6901960784313725,0.7254901960784313,1,1,1,1,0,1,1,0.9999841209349595],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,1,0.6901960784313725,0.7254901960784313,1,1,1,1,0,1,1,0.9999841209349595],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},"s":{"a":0,"k":[-2.581283569335938,5.676355361938477],"ix":2},"e":{"a":0,"k":[-2.463577270507812,-2.725622177124023],"ix":2},"t":1},{"ty":"tr","p":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":160,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[-0.000002716001745284302,5.989384174346924],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":15,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":1,"k":[{"t":35,"s":[42.28367233276367,71.5716323852539],"o":{"x":[0.42],"y":[0]},"i":{"x":[1],"y":[1]}},{"t":60,"s":[43.07094192504883,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[43.07094192504883,31.425106048583984],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[41.990768580015576,32.4786006900714],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[41.990768580015576,32.4786006900714],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[43.07094192504883,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[43.07094192504883,31.425106048583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[43.07094192504883,68.44379425048828],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":75,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-8.706964825682508],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-8.706964825682508],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":16,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":95,"s":[45],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[45],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":15},{"ddd":0,"ind":17,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":95,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[100,100],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":16},{"ddd":0,"ind":18,"ty":3,"nm":"左眼","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[125.21953582763669,125.21953582763669],"ix":2},"r":{"a":1,"k":[{"t":95,"s":[-45],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-45],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":17},{"ddd":0,"ind":19,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":18},{"ddd":0,"ind":20,"ty":4,"nm":"瞳孔:0:0:rg-shape-mask","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"parent":19,"shapes":[{"ty":"gr","nm":"瞳孔","it":[{"ty":"el","d":1,"s":{"a":1,"k":[{"t":95,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[5.955282692188149,5.955282692188145],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[5.955282692188149,5.955282692188145],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2},"p":{"a":0,"k":[0,0],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":45,"s":[0.09982926398515701,2.098070621490479],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"4","w":7,"h":9,"ind":21,"ty":0,"nm":"瞳孔:0:0:rg-precomp","sr":1,"ks":{"p":{"a":0,"k":[-3,-3],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":19,"tt":1},{"ddd":0,"ind":22,"ty":4,"nm":"眼白","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":18,"shapes":[{"ty":"gr","nm":"眼白","it":[{"ty":"rc","d":1,"s":{"a":1,"k":[{"t":0,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":160,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[9.105843866916974,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[9.105843866916974,12.17235900462518],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":1,"k":[{"t":160,"s":[4.552921933458487],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[4.552921933458487],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":160,"s":[0,1,0.6901960784313725,0.7254901960784313,1,1,1,1,0,1,1,0.9999841209349595],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,1,0.6901960784313725,0.7254901960784313,1,1,1,1,0,1,1,0.9999841209349595],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},"s":{"a":0,"k":[-2.581283569335938,5.676355361938477],"ix":2},"e":{"a":0,"k":[-2.463577270507812,-2.725622177124023],"ix":2},"t":1},{"ty":"tr","p":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":160,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":170,"s":[4.968810571881477e-7,6.006110191345215],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":23,"ty":4,"nm":"圣诞帽","sr":1,"ks":{"p":{"a":0,"k":[46,36],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"hd":true,"shapes":[{"ty":"gr","it":[{"ty":"gr","nm":"Vector63","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[16.179380416870117,14.481801986694336],[30.153566360473633,4.778004169464111],[95.7448501586914,44.107078552246094],[80.52998352050781,60.876686096191406],[91.9229736328125,82.61006164550781],[43.73566436767578,98.79714965820312],[1.949218737806735e-11,43.55377960205078],[16.179380416870117,14.481801986694336]],"i":[[0,0],[-6.172143936157227,3.384781837463379],[-9.208442687988281,-22.598800659179688],[6.9685516357421875,0.000001302305463468656],[-0.764171838760376,-9.203577995300293],[20.4085693359375,7.0994720458984375],[0.00002318472252227366,20.932527542114258],[-2.9425697326660156,2.387073516845703]],"o":[[2.9425697326660156,-2.387073516845703],[35.58937454223633,-17.42137336730957],[9.208442687988281,22.598800659179688],[-10.950576782226562,-0.49775195121765137],[0.764171838760376,9.203577995300293],[-20.4085636138916,-7.0995025634765625],[-0.000018547776562627405,-16.746021270751953],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":58,"s":[361.28717041015625,396.9792175292969],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[361.28717041015625,396.9792175292969],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[338.3349609375,409.0826110839844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[338.3349609375,409.0826110839844],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[375.8349609375,409.0826110839844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":242,"s":[353.712158203125,409.0826110839844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":262,"s":[358.712158203125,409.0826110839844],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[49.183780670166016,49.57299041748047],"ix":2},"s":{"a":0,"k":[99.99999655201623,99.99999655201621],"ix":2},"r":{"a":1,"k":[{"t":58,"s":[35.001881966180314],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[35.001881966180314],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[55.24976497066203],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[55.24976497066203],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[35.001881966180314],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":242,"s":[35.001881966180314],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":262,"s":[42.71407352177474],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","nm":"Vector65","it":[{"ty":"sh","d":1,"ks":{"a":1,"k":[{"t":25,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":40,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[212.0279998779297,116.86296081542969],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48832702636719,-15.860580444335938],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48848724365234,15.860809326171875],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":58,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[{"c":false,"v":[[69.52864837646484,125.57420349121094],[48.48994064331055,64.91253662109375],[132.57362365722656,45.11091232299805],[194.9314727783203,12.421947479248047],[225.39137268066406,21.948740005493164],[254.07601928710938,12.570840835571289],[283.35247802734375,24.81770896911621],[306.64892578125,29.68525505065918],[330.88543701171875,68.4891586303711],[314.3233337402344,114.36751556396484],[195.0279998779297,80.38104248046875],[69.52867126464844,125.57422637939453]],"i":[[0,0],[-12.852771759033203,25.780784606933594],[-45.337364196777344,21.430770874023438],[-17.060943603515625,6.877047061920166],[-10.243438720703125,1.3005685806274414],[-12.3355712890625,8.942322731018066],[-7.001145839691162,-14.393939971923828],[-14.76983642578125,6.1331024169921875],[-1.23968505859375,-14.835317611694336],[20.124481201171875,-17.113235473632812],[82.48843383789062,-15.860687255859375],[30.33181381225586,-4.2911529541015625]],"o":[[-29.048622131347656,-11.299827575683594],[12.852767944335938,-25.780776977539062],[45.33735656738281,-21.43075942993164],[17.0609130859375,-6.877033233642578],[10.243453979492188,-1.3005585670471191],[12.335540771484375,-8.942304611206055],[2.788079023361206,8.98382568359375],[14.769775390625,-6.1330766677856445],[1.239654541015625,14.835325241088867],[-20.124542236328125,17.113243103027344],[-82.48845672607422,15.860710144042969],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},{"ty":"fl","c":{"a":0,"k":[1,1,1],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[197.92926025390625,198.9528350830078],"ix":2},"a":{"a":0,"k":[183.64317321777344,75.98601531982422],"ix":2},"s":{"a":0,"k":[99.99999655201623,99.99999655201621],"ix":2},"r":{"a":0,"k":27.664263049630176,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gr","nm":"Vector62","it":[{"ty":"sh","d":1,"ks":{"a":1,"k":[{"t":25,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[165.4583282470703,52.23857116699219],[283.1100769042969,75.00079345703125],[331.964111328125,128.04824829101562],[390.6910095214844,220.218994140625],[382.1517333984375,240.52188110351562],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130859375,42.845157623291016],[-28.637649536132812,-8.877811431884766],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59129333496094,-42.845149993896484],[28.637710571289062,8.877788543701172],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":40,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[130.3444061279297,3.5195515155792236],[248.479736328125,22.902267456054688],[331.964111328125,128.04824829101562],[373.615234375,237.50115966796875],[365.07598876953125,257.8040771484375],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.591346740722656,42.84518051147461],[-28.637649536132812,-8.877826690673828],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.591217041015625,-42.84510803222656],[28.637710571289062,8.877803802490234],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":58,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[156.74700927734375,40.85663604736328],[274.398681640625,63.618873596191406],[331.964111328125,128.04824829101562],[384.2876281738281,226.69979858398438],[375.74832916259766,247.00270462036133],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130096435547,42.84516906738281],[-28.637725830078125,-8.877784729003906],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59123229980469,-42.8451042175293],[28.637710571289062,8.877805709838867],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[165.4583282470703,52.23857116699219],[283.1100769042969,75.00079345703125],[331.964111328125,128.04824829101562],[390.6910095214844,220.218994140625],[382.1517333984375,240.52188110351562],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130859375,42.845157623291016],[-28.637649536132812,-8.877811431884766],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59129333496094,-42.845149993896484],[28.637710571289062,8.877788543701172],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[136.80645751953125,58.90253448486328],[257.9558410644531,67.96192932128906],[331.964111328125,128.04824829101562],[370.4617004394531,229.35809326171875],[361.9224548339844,249.6610107421875],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.591312408447266,42.84516143798828],[-28.637588500976562,-8.877864837646484],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59124755859375,-42.845130920410156],[28.637832641601562,8.877710342407227],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[136.80645751953125,58.90253448486328],[257.9558410644531,67.96192932128906],[331.964111328125,128.04824829101562],[370.4617004394531,229.35809326171875],[361.9224548339844,249.6610107421875],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.591312408447266,42.84516143798828],[-28.637588500976562,-8.877864837646484],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59124755859375,-42.845130920410156],[28.637832641601562,8.877710342407227],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[165.4583282470703,52.23857116699219],[283.1100769042969,75.00079345703125],[331.964111328125,128.04824829101562],[401.0536193847656,214.3156280517578],[392.5143737792969,234.6185302734375],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130859375,42.845157623291016],[-28.637649536132812,-8.877811431884766],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59129333496094,-42.845149993896484],[28.637710571289062,8.877788543701172],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":242,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[165.4583282470703,52.23857116699219],[283.1100769042969,75.00079345703125],[331.964111328125,128.04824829101562],[382.75543212890625,228.4927215576172],[374.2161560058594,248.79562377929688],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130859375,42.845157623291016],[-28.637649536132812,-8.877811431884766],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59129333496094,-42.845149993896484],[28.637710571289062,8.877788543701172],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":262,"s":[{"c":false,"v":[[41.804542541503906,151.17430114746094],[165.4583282470703,52.23857116699219],[283.1100769042969,75.00079345703125],[331.964111328125,128.04824829101562],[393.2501220703125,225.1007537841797],[384.7108154296875,245.40362548828125],[279.6648864746094,155.46434020996094],[224.25393676757812,127.40743255615234],[146.8828887939453,130.98837280273438],[41.8045654296875,151.17430114746094]],"i":[[0,0],[-52.59130859375,42.845157623291016],[-28.637649536132812,-8.877811431884766],[0.254730224609375,-35.719688415527344],[-2.957183837890625,-11.7100830078125],[15.1600341796875,16.81451416015625],[59.163543701171875,78.59402465820312],[15.91058349609375,7.4648590087890625],[30.714324951171875,-11.0592041015625],[21.411972045898438,63.72276306152344]],"o":[[10.731273651123047,-81.59806060791016],[52.59129333496094,-42.845149993896484],[28.637710571289062,8.877788543701172],[-0.2547607421875,35.719696044921875],[2.957183837890625,11.710098266601562],[-15.1600341796875,-16.814498901367188],[-26.215957641601562,-33.89326477050781],[-49.22625732421875,-10.875167846679688],[-30.714324951171875,11.059188842773438],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},{"ty":"fl","c":{"a":0,"k":[0.9137254901960784,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[233.47467041015625,197.31565856933594],"ix":2},"a":{"a":0,"k":[198.55532836914062,136.53756713867188],"ix":2},"s":{"a":0,"k":[99.99999655201623,99.99999655201621],"ix":2},"r":{"a":0,"k":27.664263049630176,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":25,"s":[19.045372009277344,40.26525115966797],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":58,"s":[19.045372009277344,-10.734748840332031],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[19.045372009277344,-10.734748840332031],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[16.545372009277344,-12.625652313232422],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[16.545372009277344,-12.625652313232422],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[19.045372009277344,-10.734748840332031],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[19.045372009277344,-10.734748840332031],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[19.045372009277344,40.26525115966797],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[251.4330920878292,250.4739227294922],"ix":2},"s":{"a":0,"k":[10.000000149011612,10.000000149011612],"ix":2},"r":{"a":1,"k":[{"t":80,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-7.511416935727232],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-7.511416935727232],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":24,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[46,36],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":25,"ty":4,"nm":"身体:0","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":24,"shapes":[{"ty":"gr","nm":"身体","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[40,40],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":5,"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[-1.94598388671875,-20],"ix":2},"e":{"a":0,"k":[-1.94598388671875,-15.32459926605225],"ix":2},"t":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,19.99999809265137],"ix":2},"e":{"a":0,"k":[0,12.66751289367676],"ix":2},"t":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[20,-4.702159881591797],"ix":2},"e":{"a":0,"k":[16.8870849609375,-4.702159881591797],"ix":2},"t":1},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,1,1,1,1,1,1,0,0.3,1,0],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[-20,-0.0000019073486328125],"ix":2},"e":{"a":0,"k":[-16.1343822479248,-0.0000019073486328125],"ix":2},"t":1},{"ty":"tr","p":{"a":1,"k":[{"t":25,"s":[2.662708282470703,43.19272613525391],"o":{"x":[0.42],"y":[0]},"i":{"x":[1],"y":[1]}},{"t":58,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[3.449977874755859,3.046199798583984],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[3.450007438659668,3.046332597732544],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[3.449977918718367,3.046200376056593],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[3.449977874755859,42.04619598388672],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":58,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-8.706964825682508],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-8.706964825682508],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":26,"ty":4,"nm":"身体:0:1:rg-shape-mask","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"parent":24,"shapes":[{"ty":"gr","nm":"身体","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[40,40],"ix":2},"p":{"a":0,"k":[0,0],"ix":2},"r":{"a":0,"k":5,"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":25,"s":[2.662708282470703,43.19272613525391],"o":{"x":[0.42],"y":[0]},"i":{"x":[1],"y":[1]}},{"t":58,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[3.449977874755859,3.046199798583984],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[3.450007438659668,3.046332597732544],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[3.449977918718367,3.046200376056593],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[3.449977874755859,42.04619598388672],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":58,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-8.706964825682508],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-8.706964825682508],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"5","w":48,"h":38,"ind":27,"ty":0,"nm":"身体:0:1:rg-precomp","sr":1,"ks":{"p":{"a":0,"k":[-21,-20],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":24,"tt":1},{"ddd":0,"ind":28,"ty":4,"nm":"ShapeLayer1-box","sr":1,"ks":{"p":{"a":0,"k":[46,36],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"shapes":[{"ty":"rc","d":1,"s":{"a":0,"k":[91,54],"ix":2},"p":{"a":0,"k":[-0.5,-9],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":0,"ix":2},"r":1,"bm":0}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"6","layers":[{"ddd":0,"ind":29,"ty":4,"nm":"ShapeLayer1","sr":1,"ks":{"p":{"a":0,"k":[46,36],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"shapes":[{"ty":"gr","nm":"ShapeLayer1","it":[{"ty":"sh","d":1,"ks":{"a":0,"k":{"c":true,"v":[[-44.67141157648863,-26.427425384521484],[44.67141157648863,-26.427425384521484],[44.67141157648863,26.427425384521484],[-44.67141157648863,26.427425384521484],[-44.67141157648863,-26.427425384521484]],"i":[[0,0],[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0],[0,0]]}}},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":0,"k":[-0.48273468017578125,-9.354717254638672],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"2","w":91,"h":54,"ind":30,"ty":0,"nm":"MaskedGroup1","sr":1,"ks":{"p":{"a":0,"k":[-0.5,-9],"ix":2},"a":{"a":0,"k":[-0.5,-9],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"tt":1}]},{"id":"3","layers":[{"ddd":0,"ind":31,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[3,3],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":32,"ty":4,"nm":"瞳孔:0:0:rg-foreground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":31,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[19.74238530107617,19.74238530107617],"ix":2},"p":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"e":{"a":0,"k":[2.489944458007812,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"a":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":45,"s":[9.856398719421122e-7,1.898421168327332],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0.2870027124881744,2.084273338317871],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[9.856398719421122e-7,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":33,"ty":4,"nm":"瞳孔:0:0:rg-background","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":31,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[7,9],"ix":2},"p":{"a":0,"k":[0.5,1.5],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":1,"k":{"a":1,"k":[{"t":95,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0,0,0,0,0,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,0],"ix":2},"e":{"a":0,"k":[0,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"4","layers":[{"ddd":0,"ind":34,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[3,3],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":35,"ty":4,"nm":"瞳孔:0:0:rg-foreground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":34,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[19.64379978921313,19.64379978921313],"ix":2},"p":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":2,"k":{"a":1,"k":[{"t":95,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0,0.5568627450980392,0.5568627450980392,0.5568627450980392,1,0,0,0,0,1,1,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"e":{"a":0,"k":[2.489944458007812,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"a":{"a":0,"k":[0.352081298828125,-1.072673797607422],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":45,"s":[0.09982926398515701,2.098070621490479],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":75,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0.4635452926158905,1.657983303070068],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0.1996539533138275,0.001752197742462158],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":36,"ty":4,"nm":"瞳孔:0:0:rg-background","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":34,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[7,9],"ix":2},"p":{"a":0,"k":[0.5,1.5],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":1,"k":{"a":1,"k":[{"t":95,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":160,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":180,"s":[0,0,0,0,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":202,"s":[0,0,0,0,0,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,0],"ix":2},"e":{"a":0,"k":[0,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"5","layers":[{"ddd":0,"ind":37,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[21,20],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":38,"ty":4,"nm":"身体:0:1:rg-foreground","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":37,"shapes":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[218.70941503737095,218.70941503737095],"ix":2},"p":{"a":0,"k":[0,-6.744688034057617],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":3,"k":{"a":1,"k":[{"t":95,"s":[0,1,0.25882352941176473,0.33725490196078434,0.3346979977394622,1,0.3843137254901961,0.4470588235294118,1,1,0.8784313725490196,0.8862745098039215,0,1,0.3346979977394622,1,1,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,0.25882352941176473,0.33725490196078434,0.3346979977394622,1,0.3843137254901961,0.4470588235294118,1,1,0.8784313725490196,0.8862745098039215,0,1,0.3346979977394622,1,1,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,-6.744688034057617],"ix":2},"e":{"a":0,"k":[18.87631225585938,17.25237846374512],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,-6.744688034057617],"ix":2},"a":{"a":0,"k":[0,-6.744688034057617],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]},{"ty":"tr","p":{"a":1,"k":[{"t":25,"s":[2.662708282470703,43.19272613525391],"o":{"x":[0.42],"y":[0]},"i":{"x":[1],"y":[1]}},{"t":58,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[3.449977874755859,3.046199798583984],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[3.450007438659668,3.046332597732544],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[3.449977918718367,3.046200376056593],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[3.449977874755859,3.046199798583984],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[3.449977874755859,42.04619598388672],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":1,"k":[{"t":58,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[0],"i":{"x":[1],"y":[1]},"o":{"x":[0.5977011494252874],"y":[0]}},{"t":95,"s":[-8.706964825682508],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[-8.706964825682508],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}},{"t":219,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":500,"s":[0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":39,"ty":4,"nm":"身体:0:1:rg-background","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"parent":37,"shapes":[{"ty":"gr","it":[{"ty":"rc","d":1,"s":{"a":0,"k":[48,38],"ix":2},"p":{"a":0,"k":[3,-1],"ix":2},"r":{"a":0,"k":0,"ix":2}},{"ty":"gf","o":{"a":0,"k":100,"ix":2},"r":1,"bm":0,"g":{"p":1,"k":{"a":1,"k":[{"t":95,"s":[0,1,0.8784313725490196,0.8862745098039215,0,1],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.6436781609195402],"y":[0]}},{"t":202,"s":[0,1,0.8784313725490196,0.8862745098039215,0,1],"i":{"x":[1],"y":[1]},"o":{"x":[0.7816091954022989],"y":[0]}}],"ix":2}},"s":{"a":0,"k":[0,0],"ix":2},"e":{"a":0,"k":[0,0],"ix":2},"t":2},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":0,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0}]},{"id":"7","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAABDCAYAAACfmekvAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA9LSURBVHgB7V1dbFVVFt739kL/wBYFYwCxjSSGNBkUia9UzDwZfzDBBB8QjU9OhFZfJvMg4LMRJMw8TILUeVATE6SayTyp4MM8GAI4gL6ABSGNYCmV/kNvz6xvT9eZdffd59xz29v2HF1fsttz9l5r77X32d9Z++fcc3KmAnbt2tU6NjbWFQTBFjpto/9tRqFQ1ApDuVzubD6f76X/xz/55JPLccK5qAQiatv4+PjRO3fudN64ccMMDw+biYkJQ+eGSGsUCsXcQAQ1hULBNDU1mdbWVhsaGxt7KH5/FHG9hN2xY0cXedW9ly9fbv3111/N3bt3zdTUlJmenlayKhQ1BHlWG0BchFWrVpnVq1cPEYn3f/zxxwdd+TLCvvTSS/v6+/v3Xrt2zZCHtR4VZC0Wi5awCKEy3SEqETiJjE9OnuMYwHmcXFyefJxU36cbJ5MkvpJcUr1q8vSlA1HtEtVOtbYjTqaW16jaspPYAlRTbpz9HEDWJUuW2NDQ0GDWrl1r1qxZs/+jjz7aV6IjT2gY3HXp0qUDP/30k5mcnLRkZcK6ZFUoFHMHE5a9LAhbX19vw7p168zDDz/c3dPTE3rakLCvvfZae19f3+mLFy+2Yq7KhGXvijsE3yVmc2dKmpYUST2Be0f06cv02Xi9qDJc/Wq8fLWeLiqPKLtcGSnna5skecXZUg3mUve40ViUfK2ub1Ib3XgOdXV1lrRLly61hIWnXb9+/dCGDRs2HT58uA/yBdajOes+8qytICoHH1mTIk5+rmSVeVTKKyo9Sr/SeTVluGlJy4yTTVJOXFw1ej7bZ2tLNZhL3ZPYXG29atGX42yRNxfJNcRdvXq1lYbGR+m0E3F5/Onq6mq/fv36TiJtOAzGQhPPW2tBMIVCEQ1wDFwD58A95uHo6Kihxd8t3d3d90LOEnZkZGTbzz//bAXlirDOWRWKhQXzjrmIcPPmTcTtQXqemJ0jFj+LITCTlYfBCoVi4cHDYnARAdwkh9pJSfnCiy++CNJulFs3s5mzKhSK2oCHxzxEBjdpIbht+/btufynn35aR2PlFhbQOatCsfiQpEWgbZ91Z86cKeTb2try0qsqWRWKdIBJi/+YrpKXzedpBSqnRFUo0gvJzzwegXIjFQpFOuDyEsPh8FEX+dSLQqFIF/B8P81l8yF91cMqFOlG3igUiqwgUMIqFBkBrTfllLAKRYaghFUoUg65GJzHypNCoUgveDGYuBoUeB9WkX7gJV0bN260x1euXMHPrkxa0NbWZh566CF7/N1335mhoSGjqC0why3IiKztw27ZssUGdBR0GHTgb775xpw8eTKyM7MOADmELOC9994zb7zxRsnbGB5//HFLjsUE2v3IkSNhm8I22LR582aTVuCm99xzz9lj3FgOHTpksgA7GibWNj799NPBmjVrgqampqBQKATUGeCDUxuokwRffvllMDU1FRmoEwXkkcp033777VAGxwtlM3XoMFSrS2Qtq9/AwMCC2R53HS5dulRmG+xdbNviwssvvxzaevHixVTaCA6Ci+AkuAmOUnxDAazlYVYWAFuJrHZ4GAe6KKazs9N6ocUensELwWYAnn/9+vXVqJvdu3eHx/AGaRkV8OgGQBu/9dZbtn46HJ4foB9lag4Lg48dO2ZWrFhhz9Ex3n//fduBMadD5wFREVj+gw8+MC+88EKYB7/wio8XCrMtE3WQOm+++aZJC6RtmIp8+OGHJitYjD4wW7CN+KFOpjwsDWFtJwFwJ3/qqadK5qo45vnr3r17bRzmKvAElbwS8kXATeDs2bOmEuDhIc+eHjo+z8L5unEA5OO80Wx0pV2V6iLz5nZM0g78lvqWlhZvfpwXy7n2Pvroozbe12bV2O+C8wVOnDgRKYebOwMvyk8z5NsWrXOVc9jm5ubUzmExXyoWi2HAPCRO/quvvgplDxw4EMYTkcN4HNPNys7DZN44J6JH2kFeO7h582aJDgLikS7lXRkZUH7S+vrKcuVlnWVdosqR8tBHO0XlL4NsQ1/geTpNScI4lOW2tWyrqHaFfNy1xjoF7HH1cI78fOsYrl0L0X+rDRFz2MaSVeI0P/yP+agYGlQcfmHoKLdAJDgf3Mk/++yzMi/W3t5u4zdt2lRyh4ccXeAyecauXbusnVu3bg29zFyGXEl14Vlgl29ej7pgtIGRBuoTVQamEXv27DFJkdQ2KedrayCuXWH/0aNH7Sjp1VdfLUlDfaGH+rvAtImvB+rtevLM/jItK6vEuPtPT0/bQBd+1vngbsz5IAwODto4urgBdYySNPfuK9NPnz5t79TwDPj/448/hmnSoyPt+eefLykPcaxrYjyHq4vg6uK/LBt2QYc6sa0TyuM019OiftIuBNgOOeQRZRvXWbbH119/HdrGXg3H0nZuU+SPwHLSfqRDj+2XaXRDibwekIPNvuvhjhakXVnzsJkhrLw4cUPJagiLi+qSRqajA8s0dBh0aFr4KtPDEFqSxu3gssxq7JW6CG46OrXM2x0Cys6J+sh0SVifbjVt6RtCu4T1XTdpv9tucW3nxrvXA3WRpJV1yyphwdXf9aOJ2OB3H7CQQ213iIkV6e7ubrvq7OrxyrVPbz6xc+fO8Bj2uUM/LL7wlAB28QMDLvbv3z+v2zFoL5ThQtrzzjvvePV4AUkuwkm93t7esuuBuiDeV05Wt53A1cLMnSlTqBUhfCuQSR73w7wIAdtI/JRV1Lx2viHnb1FPPaHDy60uH9x5fq0R1a68jwtgro09Z/fbN3IXg59ok/XAtcBcluX5STCZt5SXhE37KjEg59sF7O10dHSYtAOdkQ33LTIkRZJ92Kh4lBu1cFJJfy77fnE60rNHkQKdUi60yXznuiiWtC2j0mH/bK5rtXpu+XyeNW+bmQcnpDfEHZX36aKAuzXkAOzB7tu3z8wF7ooyvBaGXLABx4inhRez0ED5POKIGnlITzPfnnQuwHSj0r6rLx1TgePHj8fquTczPs+Ch5W7NwX5ErY0A6SQnROExAX2AeTBkj6TqxZP4OAuzvmh0zz55JNlZS4GYAvfmPDf16GlB6rmQYSFAOyRD4PEPfDg6vEwH0iqB4Cs2C7KAtyRQb6/vz/wJaQRctGiq6srfJpJwvWEuDg9PT1mrpDey/fUVNRiTlw+tYC0Bfuobv7yxgWkjbDSfklACYxcEGiFPqyf9KjQ890w0T+gh31cNx3tglHXYt1ok8J5NiLI3K91sN8n0dfXZ/dlse2DtFu3bpWku/uJdJHCNBz7ypAwYiuAgTJwbsz/n7RxbTLOFoMEbKUbjt1rrFRfLAr67JF5ozxZNuoM+2CXbA+3vrItuT7VBNmWqJObLtsMZfnycO3n/VzeT5U2uu2K6y7TsEWENoUett9kmtz2gZxMq3Y7ayFC1LZOSFj6nwnConHJYwaVgI4KUsR1smoIi3DmzJnI8tzO4+bp3mgAn31uqERYBHRS90blwkeYNBCW6yhJ64NLOu4LlfQAEFTquf0n7gGWxQpRD06E+7BBRt5JjHkOhjOvvPKKd97Cv+B57LHHzMGDB00tsW3bNu98mPdnq9Wt1Y8uMMxFfX22oT0wlXDn3GkCpi2wL8p+XGek+/ZaUW+0v2+FnPXcKRH6BS9YRummEVggzsHDUscZw7bJ4OCg/epzlr4PizkNL6qg4Rei8WWZUb/SidPledh82LoY7VFr8CIa2rWa39fyr3WS6PF1SGv7YE2prq7OLF261G5hoW7E0SasNGFIPIaOR8OqzBFWofgtIoqweX0Jm0KRDdhv62RlH1ahUJjSj2EpFIr0AqNh9bAKRYagHlahyAjsHNYoFIpMwA6JZURm33OjUPwOUOZhde9VoUg1gnDRSb2rQpFOiBcF5OzP62jhyRQKBSWtQpEygJPgJwJgn3QCWZcsWWIUCkX6UF9fbzlqF53sm9gKhWtNTU2WxeplFYr0AJwEN8mh3rbnHR0dRTq5es8995iGhgYlrEKREoCL4OTy5cvxQ4ALLS0txfyFCxeKlPBvROJXAfiFgJJWoVhcgIMYBoOTcKa0OPwvcDWPtwacP3/+74hcuXKlTdShsUKxeOCFJnBx1apV1sPeuHHjn5Q0XXfixIng+vXrk5s3b95aLBbXQnh8fNz+LlahUCwsJFkffPBB60Sbm5uPff7550co+U7djFyRJrbnV69evZ1cbz1WjEFYBH2YQqFYGPCP1vEmDKwIw7tSGKaF4defeOKJK99//31gPzdJpMQ89lxbW9vh+++//y8gKRR/+eUX+9qYiYkJjKGVvArFPIC9KhaY7rvvPktUkJa4CM4dornr+ZMnTxYhW2AFmsuOvfvuuwefeeaZ1gceeOB1THix/4NJL96OPjY2ZofKeH2MQqGoDeAYGxsb7dYNvmi/bNkyG0Bawl97e3sPjYyMjLJ8ycpSZ2dngea0K3fs2LGHyPqnoaGh5bdv37Ye9u7duzbA0yoUitoAhOUHl+BhMXcl7zpMnPvbF198cXB0dHSAxKZYvmwpGKQ9derUig0bNvyBwm7K8Nnh4WHrXScnJ9XDKhQ1ghwKI8Cz0vmpc+fO/fmHH374D3nWW0aQ1epE5IUHF5spk3s7OjoeaW9v/yMtLXdSZo/QmHq5r+BAfB7QN9d146Pk4nSqkY079x1HycfVB3DTqrG5Gp2o8pLmG1efauqetH6V2i8ur9m04UJgNu1Rqf40Yu2nw35yhqe+/fbbf9ACUz8Rd3BgYGCM4su8Y+xmK7wtTXgbaPFpGZG3kdx0A0Xn8epFCbkFNJOGfDF2ziFNyvM56/Axy7h5zaQhn0DKevRDGR8cO2BfwHrmf29bj4TM36lniR2e88CINp7JB+XmPOWGNsn8POB6hvpu+/naifP0tZ+bt4yYkYW9gZu/W2/ftXTLrNB35DUsOZ6RDTz52PZ06xLR78rq5+iVXANfmnvsXFM3zR57bGYZ6AXErQkayY7TPHaEHOQETUuLJqJPJn06AnLwuvgAdKgzNTWVoztCwB/ZBeTHhZCOzw3gmD/CKz/Gi2Navg5lII//QiesPOQ4zSNXVjYDecz8wCFw7Ua98JkG9wPBjo25mU85lMS7ded6ePIqK0OUb+PcduL6cl1n8i3JR8q5efG52yZu27tli7LK6i/TRLmmLeaD4JX6RJSOrIdsXz532sv2EaGD6ED2K2lHVF7udXPjZTuwrmsz2xLVNi4H8J8IOk1OcZoWfW0wFfBfh2LoMytc5MwAAAAASUVORK5CYII=","w":236,"h":67,"e":1},{"id":"8","u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAB6CAYAAABHjTdkAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAC8zSURBVHgB7Z3rldw28vaf/Z/9vrMRGI7AsxEYjsDjCIyNQLMRDB2BtBF0OwLJETQVgeQIyI1AsxHonVqSb/e0SFQBBNm353cOzkhNoFDEtXAlQAghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEFIU/+J2L+5r7z69uABCyLnhXtzmxX1BV1e/9P93IIRcIncv7gn7Oi2uRJ0Wuf7FPfbyBve2/833fsh54NDlDdt2cjNIw/d1wj2BEHIuuBfXYLyuNmBHRcilIQMAmfAbq9NigN4jnbEBTcw9gpwaB7btJ+cvOD07lKF9cc8v7s8X97l354ZDV7hj/PTiahBCTo20TT7yfPvi/ol18NAnKESXFoRcN9os9ccXV008e4o8E9oX9z3s+Bf3HmkrG+zjT4+UoRB5XqPLpzWRMvRe8cM2vjBfF3Ji6GsN1drIzIem9zsQQk6NdAZaXf2C9QjQ9XEg5PqRvj1WDzaRsJ+g1yPrKog3yBpz3IZ1eiz5tDYON9bG/x+uF4eu025wPlubLA3P30AIOTV3hfwQQs6HUvXaIT7QmaJGt1ODnA5ru832fWGueQBySIVu5uPUBao2+PkIQsipaaEbCue4zZNcJ7J63kTcDsRCa/BjqdcyqemQzp8gp0ba9Vbx00Jv/7U6qW23J2fA1xXdOTTSosOUflJgHQgh54C2ZTJgPQJubHmevKIC1C3Ht4K8aywtNpGwXglboYwOU+4B5Bwo0bZX0PM7BWeQ50CK8nVlV+G0OIzvQ23AwkXIuVHh27oqZz/WvskmgJ3TLVOBA5ABedfcAYjwMCFjCxv30OuitBFV79ehG/gEcFvPOVFhno04Ff7QpeAM8hyuiL/i9niD7qD3qfZhti/uH+gaJN//VoO3YhByjlToDBMxWsR4eO7/z33chFwmH9Bts/LoDLrn/v+1Mbwz+PkNry+UaUHOjQpdW+6xLwdbsG1fjUsYgMSu1BPEKJBZhl9haxjEf8Dpb5uqwUEHIZdAC95OR8g10cK+4nGMZRXjA8gl0CK/HJCZXMIARJZKa8WPVPaqd0/Q+QGEEEIIIeVpQQiJcm23YFUv7t8GfzlfOyWEEEIIIYTM5BrPgFToznnEuFOeaQdMj8+QeHRbwOSv63+TPaUyGNomyhb/7cSzR8R1Hzvb4l/cz9gfhhv2sQ/7Xj+i7BLksMXtB+zPuAxxti/ud3QrWu1RuID4FjrRtcSydqU8Fz1Tt9s46LdmtEhL58N0vO//P+T9kJbiJP9q5M+4ecS/9i1UsKOV0RrTK5oPiE8O1HgdVuJ504dz2Jcz8fML5hOwTJn0L+5H7NuL4zo51JE1ue/1Oay3DvvrKMUNZa1Gee6wTxeHfTk41uHzgR4l92qP1bfD+NH/HeL/jGVnuQNel70fFf+ibzXy+5wyet/He5wXwOu0KNEur4XWxoy1/wGv88Kyg6Ka+H2sj47h0Ok81g+02NeJP7BOm6Gln1BBx0HvM4ezOhqPiPc5Lb7tewPibXs7Eub43bU6KVRG2XPw6Gw8+TuUj8P2UsrGJdXRVdFO/W+QTqPI/BQJ62C/iUAy+j3sN25ZZHvkv5c7imtniG+4QSVgHpIWT+hu/7DcEHK8VU7TdYMyWNLkLlHmo0FmMMrysOfbcfo4pFMZZKfQKLKqSNhtQlgZeEyVtQZl0PJhgzQ80uqkOwgbDGEc0vFIL2+iW0AZ3It7C1u7cdyGbDD/VhiPvPo2p85ZyNVpbhl9gu1r4cflYcm0OKZB/jtvob/LMTuUyYuUOuqRVy+fsGw+WPo6Z5ATDHIqg5w7g5yxSV8tbXcjYbaGuCxuTLbgDGHdkf8dbHE2WPfa+ItBS7gN0mmQVwAEZ9BJ/EjB1xrqKkO2R/57ud6fjNJTO3Rxb5GHQ9696JsDGbsEv3MoOVgY0HQ/zJspHMp0dJJOKQOoyiAzhQZpdeKQrTHsk+KvQRl2KFcmNZ3HnNThYcYtGPw72HGYX94a6KtnMWKDyBT3hHQcyhmWOfFrlNJtY4zPI//bFofl4RHLo+kZe+ct9Hc4ZocyeWGpo9qkpjUfApbBGeIPBjmWd9wZ5HiDnLEVm11G3FtDXBY39V7OENb1fn/FujbeIlzrl9A1A+wPzOcJ53mWxKEr4Kmz+IJ0Hhuk4dANxBzSCVi/QmyhL4H/CDvD1pEYNeLbNaQc7TDPmBsIyM+PS8Dh9N/ySUXaigrpSNmScuFQFilvUkY85uHQ6feEdKSdeYcy30WokNZuOZSrbznxnxsyECxRzhy69vysjJwLwqGrlw+Yh0NXHnPqpUYLfeuhxS6y+tHaB688b2HbxnVJOHR2zFo23mJc4wAkQM+YufvhHNb/EJmV3MHHQID93VyB+CQuj/UY9kXGSOkAvMHP75FnDuWNTIdlDNdzYIlOdUlyBx8DUrdKdhjDYLeE4T9QIa09FAM1oCwBNsPXYZm6EXCZhreUz3coy1kZOReCQ/lyWWGZ9lKbwP1Zee5g/2SCNlDRJgtrXB87zCPgTOzXaxuAOOidgBwMbzGPX3GeyEyWw3yk0bIYKE+F4tugrEGk8bvy3LKqMaA1tsLUgNehvDF4KPs91k3XpZGDmAGXg0OZ1RoP/WINCw7LlQlpdy2zmgHLdX6WyYxSbVZu/OeEx3KriQFcCbGy1EqnUGH+isox2gSuQ7yN8bCj+dXanI+4Lta28RblWm7BGm7D0W5D+IwynV/AeVKqYx9uhInNjHmkpYOsPLT9v48bDYd1kQZUOketkayh45XnMlv0PPHMagw997r8p/+3GOKWTkXSWcpEheugdEe6NKmzj23vxrYeWIx7DWt5q9F13C32s5A/GsLKRMI/oOtgif8P7G/5ER0ejDo8YbreDu2aJf7Dm8iGNHgDPR9i8acgdb09+P9wu02MduS3/074TVlZkzz40Osk4Q5vSoshbc9atzMtSam8mEL6ImfwV7+4P7FfwZey+DNs9VLCPqMMnw1+PKYHKilbnGN+x9rJY2qU49CGAfLLwZx8WNPGuwm+Qj9QtZlwMptnvbHDOtPskH6wR2RX6DI09P9+j287O4tsj2maRJ0C9sud9/3/m4TwMXZGOVN7zUPi+2xQli3mvb9wD13vKaPZwfbeW4yXWwlvPazoME1lCJ9Co8iqImG3sL3P4OQQnjSgAfuZdfn/BmXYIb9MOtjfo8K3eSzhtwkytHwOhvAN4u1PZZARZupQRcI72NqMqXb+YWb8gC0NLP1MKhX0vEvhCbYyNWXwONjyYofyaPFuImG3mJ+OAfp7W3EGWaKTj8h4NMioUJadEl/MsE25Ze1LRI723p9m6G8ptxXKlQPBwZYmhzo+4LWNJ2nSJIS/eb4u7IZMsuISZDdIW050Bpk+Er4x6lUpOlgagC+KDIse7xHHJbzTBmXxhjg1Q0JrAGNpuDHEb5md2M2UUxnCp9Agv2xuDbpY5JRCS9tNJOwGtvfwiFPBniYO+e/SwGY4a2V+FwmrDZg30AnQ02Gqva+QX18P0dJyiZW6Cnr+WXGwtbvabKvIsdzEUzo9NN03kbBbzE/HAP2drWwM+jiDHI8yZdtKhbx2wMHeng3OT8jS2pNYv7fL1P+QCuXKgeBgSw9xQZEz18a7Gb4u5HbIa/icUX6D9JkuZ5DrI+EbQ/gNbHpYOg43Ed4y42JNH2+QZX2vVLQ0CEr4HfJ0diiXfs7wHl8isiqDLik0iqwqEnZr0MWSL6XYIb9MaumgpcUhc1e63IywY2jp4iJ6eHTtckD3/sOK1Q72g6m55aOCXk8s+F7nCq9Xvj32HwMrTQW9vbASUK69tawq7VCWBvm6bzE/HQP0d7ZgKcspNsw7RZZHOTzy6pKlvBy7qYFwg/z33WF+ma1QphwMONjSozLKsth4N8/XhZ2MBJ9g72CdUa5DOs4g10fCNwX10horcfcTYXeGsAF2LPI2KI+WBrE4LZ2HnwgbUDb9LHnpJ8JWhrApNMhvPLcGXTZYj12mLpateQ3sOIO8WN3XJgxS09Qr8krtU55CS4dqIlxlCPsrzpMK5crTDvllaYxGkRWbAMlBi28TCbvF/HQM0NPPQlBk7JCG1u6U3u+vGbh+JIylr7KkgzOEi7HLiPOYaqYOxziDvMYuztSfnpRr/Q7IIVIpK3QFqlTHWGP+TVpLUMOu12eDn6lO4x46H2DnN5wGTcfY7JNHnBbTB+AsN2fVsGNJ6yW2hZyCU5WVFJzBTw07LeYdptTKW+p3kbS24wcsxxPyaQ1+tugMWEsbd4kMB+pjSP62sGO5VfBa03MOPyrPU29wknx7Rn58qWjtxn2CDs+Y1v3e+NshNa6TeiG/J+FabsGy4NDdNvE3zDdiUhuGtWgX8nuMNptVI+2mB8tgaAlq7G/ZGUN+9xivyJpRV0eeOcRJNQBqxN/DEuclcHwLybliMbZSjX7x75GHpo9H2RnqEsbmcMPMcNPNcPObQz4yUNduvxNC76S8SV382P9NrZfniIP+/qn9Ww19YHiP6zUKc3HK8+9QdrupQ1mkPvwaee7xetUlNhCVuik3tr0ZeTbWD3vEKfGx6XPkzwS/Lc6cSxiASEF6jDwfOirpnCxX0lXoCvo75NPiPPkPlscZ/KRUEmEwLB3WR2bvYt9Y8BjvOD10uVNoBlpOPraK3CVnpdfiVAPVVCzGfIs0WuQxtI8xSnxj5DjOFL/3vfuh/+sSZViRdkar78e6ebyu6y32g5Ial/eVZWfwk/pOFv/X0P6URusHAsoOQIa2IGVyMMYwoJ/ieLUj9r5Sn0Svqbp5PIDVylON66RU3p0Fl7AFS/YZthEnjV+NbpDyPWyrG9aPZpFvcQY/OZWkxWn4oDwfWzIejKQpWsxrAFukow36ljDoyDiWtE418nI7nlPkuzP6kXZY9jTvsP86+rDisRQV5rU1Dt1kl+gr5wtF/4DLYYnBsaVs/h3kmFPUzZJxtoiXFYnLHfz/IeK3RrzP9EdyfcRvi8ubGLhJrvEMSIXua+ca/EorEWrEG1GPbxttjzix5V8HnSVmOTgAuWxaXA/DwEMmjdYul1K3fkK59HTozow0uI5tjrm0ILeIttXJH/x7atVi2NoodbOe8HM4EahNHtcgF8G1HkKvoBtxS8+0XStXtQTYox2i9Ef/185/vAMhZXG4DsRYf8RpadENQrR6n4JDtyJyqyvr7EtvE20HwWF98BN+Pk78+5DD8yMecc71jC454loPoVv2+g4FugZJwTIAyemMTtmBSSMaO0TpsW9oteXfYTZnitizge+QjhbmGgeOl0zJvdhzabEOUscC0mmxP3exRZkPaLXYf4tEBkSW84MakqeynUy2Ap9rfTtV+82PnqXzjPNvt7WtTlKvpH75iJ/DQUyN6b7Y9/Fpt3nVIBfBNd+C1Rr8OJBULA2iQzqnnDkczhH5iedy08cwa+sRx7L9T9Iw1mE7pKMZAC3WgTOh9jqidd6H5NaP1uDnn1i+03awfUBrmDyqsb9WdEkjrEVXt8U5dOnssT8Qn1qe73pZFc6T1uDHIQ1L2VzjgpRLo0U8rf+FbsB9zgzbpvzEcwd90q4++vdU/+jR7S6IlTdtApCcEbfwHZAYDiQVi0GQet+4x+mJLdseLv/OuX53oFWepxqbd1jmZq1D+VZ/HIDYOkCPNObcItQqz9fIs2DwI4N3WT0QA/4D9vvC16Lt45X4ZYuWHJz+x4v7Bd2gqDXK+RXnS2vwk1rWnMFPC3JMqzy/lLZU2/LkMW0T1Mbf0MvQJgW4/eqCuOYBiMUIXrNzuya0mVttxuOYc+iw3ynP/dHfMWrYOlqtkUxNvweDnxr5WAdEHkSwrGxYPkZ5iEc+mj4ey6O1x1t0hv+5tcmSdjIoCbDfsuhwvsajpG+r+LG0J4dYyrKlTtwa2s2Fl3J1ca0895juQ8YOscfOgWhXaH8AuRiudQDiYGtEW5AcLLMM1lvGHM7jGsthKXkK6WSlEXURP9ZDrZZGMmVQZvFbT/xuMfisuvBmuQ6LseVhN/wD5q3WavU1ZwLAQ68Ph2j+rHUndXVwCjFmHF5vu7JQwTaYP+fZa+3mItE9wIYz+G3BAcgYWj8gNkxqObpHWr0sQY14PyKDhrtI2GNi6RIQh+XsgrjGAYhDdxDQQguSQ23wI42gZpA62PNqDWIds7yPZqjVsDHsbY8RYDOKLP5aTDfMLcrEIQcHHYigDWYHLAM2B/0r0xpb5flwbsFKQFdvh+9gfO1d0/+25EA0d7XUo9NPDkN/7f822Ou8g30QYpmAWXslxyX4tUyASJmzGL+WslmDjKH1A5L+KXXfoyvLY/VS3AbLUSOdFuP9Uos826zG+a2gnvNExMm5hgHIMJMlswXDx6GcIVwLjpZzqWFrcMSoeY9vZy2HLUbS6TucD9vIM81Iq2FvNKWRtBxWlw7DRZ5bBnlCbNuItQ5IXsn7Hzeovn9WgRyizTILkn9SP6Y6KYcydcQyIJJyZDHuHaaNInkm75Rz3uje6CdloHSIlHOHuEFgNfa0LUctTmMIeaO/Gnp5cOjKnpZeATqWbWu3iKUfkPJuKZcO0wMMh+X72ZyzF3XkmaX9LBFmDpY6nttekZX4eiIXJvRxM8JqOINsHwnfKGEr2PEzdbGEP3Qy47jD61nIFLfBOuyQrltOmZCO3ZIO4ucJrw001/9mCd9AJ/Wdd9jnZWo6VRE9toZ410RLl00krDV/hzx6wn5bVkA3IEitJy6ijzfK2EzIGWZjLTqNhX8PvZyPhRt4gD09qgkZO0PY9xE9JA3eGmRsUJ5H2N59g/2tXjE9vFFeg6483h2F1fJzybRoZsS5hf6+GgH6e1uxthPyTvcT4R+NMjyWwxniP3YhIu8hQ55lEmNgp8jaGWQEo14b7OuktB+xCac5aXaMN8i7eb6ewDURfZwhfEAeziDbR8I3StgKdvxMXYSdQYY1P7QGdIN1sHb0xy5nqTU3rhQXDHpUBeP7hPwyulXC7rAuO8wrkxWWz99D5xR93iXIapA30NxgXlpIeDE+fP/3EentTDWhg0+QIXG+7WW97f9vHQA5lMfDrrtVl9R0TXUNlkmLBnllUNhC11kjQH/3FFL6gWEiT9ynhHAbLE+ToI9WNu8SZVny7ZAd9Pqv4ZCm4+D8DHkBdrxB3s3zdWWnzbQ5g4yAPJxBto+Eb5SwFez4mboM76PpZHEB8429UqTMXJfQzTqTmOMq2Mh556l02M7QSQu7w7rsMD/fU4yEmLMYKU7RRfK5KaTPmGsiOriC8WhltcI0u4J6jLl3WI6cOhoi8hyWLQ8PWAZN500k7BZ6GdYI0N89lR1saZrj5J0clidlguOTQV5KmnxAGprsXSE5Y25qW5YzhA2w4w3yTsqtfQdE9uzJ/e4tSAlazE9P2QO7xfkgZeQz0piz9/SfWOYsktwqVBn9Pvd6zKEF93qPId+QmHseQOpIiTKyZPvXKrLld8u5Jw0xNObUt1+wXPsvebTknu+c+hXbltJiufIguqYahbeMlMsl+oFnLFvmD6kT/H4s5GfgVGUtp037AeR/3NIApEb3UaklKvkt06LrxH5HOlJ5z/GQVkpH32Je4zcYhSWMswGRFZCGvEPuAGLNTu7SaDHPyCtt1Lbo9CnZDrawvWM1M94W3deh5zDUt9L9wO+93CV5h/R2VjN2WpQdhAyTGRVICkO5zOlHp2ixTFmfok7wa+kza9hJ8VsSeY/UvtuD/I9bGIDU6BpErnwsR4vO4JU0rg3+697vOQ4+BO16xENqzEfikrSQctoinxbz0rXK0EH8cmAfR9LGWjcOqbGMUduiy7PfMK+8Pfcy/mGUM8fIGtKwxXxa7N9/7upUi27wHQrIshCQZvDcG/y0sH9kMUaNLl23IDlI+QmY3w8IUkbWbpctt+0NWPzVsNUpeccWp0P625S648Dref/HtQ1AWnSFcYtupkwq4E9gg7gWNbr0/ju6Tvm3IycN6/fIM8bWRBo96zaPkjNWW3TpI+lUJ4QTv7/0YWvMY4u9kdhG/Ek9SzE+b50WXbpa8vYz9pMmSxq1FfY6pRgqLbq8/76XkaLjoZFVG/0vVc6qXm7q+w+G1lDnLLO5JRGD5ydjvC3s+/8rdO/zb6RdKb7t9eEkXxm2yOsHWuzrpZSRNQbEx3w0+Klhx9IPn8PkV4Uu3S32QAt+M+t//AWEnAdymMtHnm8x/5xCCh76QbQWXaOzFDJLct87+fd3/e//wf6sSspqTQ4St8N+xmaItwWZg8O3adtin6enwOG1TkN5+y/2HwcrnfcOr8v439CV7xbrp8VUfcOBToNepzDupvD41qBpMV/PoSwc5o1wqvy5VabK5VAvhwFxC3IueHR5dbjSMeTTObUdhBDoN5u8w7oE6DdIbEAIIYQQQgg5CcMsTUD6ISuH/KvrlkIbEImz7K8mhBBCCCGEzMSh+ziXrADIfd7H99Nr31o5xvJ1YY/1eAPb3eqEEEIIIYSQFZDVDu2jWGKgO4OsN0ZZSyGDH1ld8eg+nLWB7WNCAYQQQgghhJDV2MJmqItB7/H6MJaD7evng6uwDN4Yf+7gihBCCCGEEFIIB33looQTY/8Oy/AuU6cAQgghhBBCyOrI1qUlBx+pZ0lSaTJ02oAQQgghhBByMiosN/hY8pYph3Sd5MD9UqsxhBBCCCGEECNyeLtBucHHDsufsUhdvVn7OySEEEIIIYSQCLIyIEb9nIGIDDw81qGCbRVGBh783gchhBBCSCH+AkLK49GtivyAzngf27b0/OLaF/f5xX18cR/639ZG9HO9u+t1eO71+gxCCCGEEFIUDkDIWtxhPxBpQQghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEELIlfAGr68dlw+VPoAQQgghhBBCCvOE6e8HPYIQQkgUXsNLyO0is7VvEvz/hDLIt1feKn7+je7bMOQ8sOTZv3Ab386RevM+8ly+I/Q9TvNdI0IIIYSQs0aMqJQv1XuUwRviCiDnhMd65ePceQc9LbgKQgghEf4PhJBbRD4KmbpfnfvbCdl/UHWuH0IIuVk4ACHkNskZTPwKQohlm1mtPHfoDrDH3C0N+D309LgHIeRq+CsIIbdIzmBCZnU9dOOKkGtmi+7slJt4LgOUGjpOeX5rqyhOec5VJUKuCK6AEHJ7OOTv1+cqCLl15HC5XMjQjjyrX9wvIIQQEoUrIITcHh75yLYQue2IN/yQW6ZFd9OV1Idha1ANrg4SQogJDkAIuT3mrGLINggxuGoQQj6A10UTQkgy3IJFyG3hMP+61JRvhxBCCCGEvIIDEEJuC2/wo93y48EDoYQQQgjJhFuwzh8P3WiULQCpXyAO0G8d2WL8oOUU/sX93Msd9kW7XsZz7z5i/l7pSnlewy5f9NSuu5QPj42deRAjXPvgWHX0f49uBUHidf1vkne/YZ2tHNrqhegiZzx2ET/DN0S2OH8kf2KDJXlfS7p76PWwgo6D/pHFLdLqnUOXHz+gK1d3vXs+cPKef2D9rXOil7QJHvt8EH3aXp8PSHtXjaFsSlo4fNsOof8rbmiLWqSR02Y4vM53ywB+aEs12Rbu+viPywiwzw8pI5Ima7RDx2n4nSGMbB31I79XSMeaHkvVmWEr61R/CbzOk8/IqyePiJe17Yhcj9dpfYd9nfkDtnZ/SN8fsU9fZMghhJwQD/2ru++QzhdFZmOUIw3Lk0HemPyAPDTZlV3U/3TQ5LmJsM4Q9tDvDqf98reD/QvOWn7ukI836BFQhp0Sz6dCcmLl5JBQSI7gjXod17s3CXEcxqXJ9kf+G6NOmwx9xvRLTYvDsuxhJxhkuhH9vhZyDnY80tNF6v4G8/MkRgCKpMVXpOGRV2eeUCY9cvvL3HrSwF5nZaDwCbb0CJh+v7ewvU9MDiHkTNAaqy9Iw8PW2Gk8IK8hPW6EtNnEYzSZlV3UKgMQ8dco/gKW5xG6vsNM3DvoZc4yizuGN+gRUAbLO1vew1KWtdUw4b0iwzIgcsg3tnPrnTfI9L3fXzP0kfJkSb9jUgwezW1gKwvBIMsdhfGFdByTPUapdHnCMgTM121wFiQ9tLpnqTMB+cjAf25/Ke4t7G1vg+Xq7NNRXA72SYeYHELIGVFBr8T3CfI04/KwYZriCUhuaEo1Qpqsyi5qlQHIxuAvYHka6B3sgIeuc47BaJUdUIZ7Q1we8/UVt4GONsOorWbK+zRGfUrWO2+Q5WFL7xL6CGKEWWZsU1wD3bgLBjnuKIwvqKNT9HOF0+UtyhNQTj8Nh9PUmUOeCsYvTvLXMgjR3tvD1o9NuWESw2FeGj+BEHKWeOgVOMUY1DqnRgn/hPQGpmQjpMmpYCcY5LmJsM4Y1vLuActiMQwPjV/p3JbahuWxbnpo76HVHcsqylfoK5HOIMMr4UvMoObUO2/UvSmgj3VlZlcgrpxyHQwy3FEYX1A/F9FNnjUF4xrcBmUJKKdbDIdl0uMJdp4WiN9STgHbAGRO+jR9PJsZMg51IYScIdLYzG2MBId5nc0T0huWFGcZSGkyKtgJBnluIqwzhLUu+wcsi2XV63gVbWsIk7MNy2Pd9NhiXt3ZwV5+XUTOgyH8FA7LGFKD84jjDTJ2hXSxbO8LheKaco8z43ZHYXxB3VxEt13BeFLSJJWAcnpNIWWoKRhPTnq4BeO36NAo4Uts0wsFZIjbgRByllSIV17rnvwAvSGY2s7lYG9MGnQDmQqd8dsYw32BvsVAk1HBTjDIcxNhHWzvZG3El6SBnl/HeMzvAJEpN6AcAXqZi5Gy6hAicrRB4C4SdmOMf9fHE9DljbXuiZ9Y++GN8Y/J3SHdENS2/VgPy0oauAPnYRtYx8pEMIR3R2GGrXOHzqJDM+LchF5vDDKHdBnKiLgK9i1bDmV4OHonSx1rJtwUVuN6h9fpYa0zlj53Z5RT9Wnie1cl6BDDIuNc3JxzhYSQBXHQK7A3yNFm5JtI2A1sjcjUFooAW0ezQRwtfAU7wSDPTYR1hrDHbofOKArYd/6SJx7L4Q16jZ09WGobljfoE1COO0N8U4Pu1DMNG0yzU8I+ztChQbwMVQYZVSS8h+39D8vTsTHhYDP+h3ZkyhhxhvDvEceyrc5PhA2GsA5xnEFGgB0H3djUDvoHgwwtXXPxyM+PMZxBXqPIlLTS2r8qEt667TVWzi0DQ49pGkP4oWxU2Jdb0T0gfQAj+j4cybGkY04eE0JWZAe9MdPI3Q/vYGtAtMPw3ignNhOiha1gJxjkuYmwDrZ3GRpmj9OwQX7DvzWETZ218gaZAWVpkFfurec/BtdEdMitOxtDnA46QZETm031sKdBQJzKKKeaoYvlUg5tRWqqPQ2G+B3iOIOMADtaOZW8taSJg95HLDFL7aGnh7eLK1ZnPPR0nUqPOSue1vjFxQaVjSF8rGw42AchsYPxDrZBSMltfoSQgmidTKOE98jvODeGsBVsVDNlldJDCMhPE2cIqzXMa9Agv9wElE1vwRtkBpRFMwY2E+Fyru50I3I88vLAZcY3xVaR5SfCeYMeKWVByw9xu4mwAWXSROrkpte5wn5VctgKc7dg/M4gI8BOo8hKMeyqgrKseOjp4Y2yLCueAXa0suojevjeBezL2QZd2bYMCAXNcI9NPDbQ00LLT2+QYSnzlUFGBULIWWJpWF0kvNaQxr5BoDVkDdLeQ2tUY7qUbMSCQZ6bCOsMYbU8WRoPXb9NJPwS27C8QaeAsnjkld+cW6fCiBxt8uDDRPwB66Z9lRlOnOX81oClXH3F+CDgwRBOO0Myh2CI3ykynEFGgA1tq0+DNLS82aE8Hnp6eKMsrXxYvrVziFPkWXYezKFR4t/MCGv9hphWVz8YZFjslwrkZvg/kEvi+cXVip+HyLMfEeffE7876B1qDTvyHp8VP9KpnnLVoBR/vLgWp+NXg5/fI88seeVx2kGWBXmH58hzh2/LW6wMtpjmR+Nvh0x14D8jzh9Io1aeW2dlx5B3aI1+LeVKcCO/WcLJgE8MM4/rxyvP/0Qakjdt5PmcMrIGXnmeWmdaxNsOrW7P4Q2WbVstdcnizyLnGfF0JDfGX0EuDWk8feS5GCxjMzIOesdRT/xu6XBSG3XtPYZ4a1w2NU6LV5630HX83SAn4LxnrwaD10f8yOB9e/D/WLn/F6a/nO2Nvx1ST/zuEEeeB6QhaTE1sPoB+XxEGtY24Ni4afvftHYp9G7I+8+9ji3shtcloBnAKaspFqTsOJx2YiWGVoa/Q9n0cCiDO3DyDlK+PZalxbrE2h5yY3AAcnls0X2LY6oSD7O2xzMNHnFqTDdGDjot0mgNfhwun1PO+HiUWbmSme2N4kcGvhXOG83gPTZoY6sPdS9vbIXJ4bWBFltJET5juj5oRvYblMUhnxZp5K6ACDIots7EH+7Ff+x/GwYlMiCpcdkTHZpB9wD7xx1LxXlKnPI8oPyAbKzPncKjK7vDIGMY0BFyU3AL1uUxdJxTSGM21jFrs2S/KzI1Ug3tOcYHsTF3+9WAZevfGrN1c9HK3HEdmTJwa+j10BvkDEytHJzKyMuNt0UaLfJ5h3mDhmFQIpM5O3R75Zfe7rIUDutzyQOQJbgzPJeyJmcppLzJGaWArm1wIOQG4QDkMtGMxrHZLo84deSZpbNpQc4Ny6yndIZfDc4bZFn8nJIa8YHy4UqFw7RhMGw3/IC4rAFt8F9P/H7tA5C5/IJyW6kcukGN1IcAQsohA1sZ4Fbg9iNC/j8cgFwmYvjEDKnjrSMe8VmWEgel2bCeFzL4WDtPLCsup0Y7q3R/9HeMwehtMV1vfh6ROUWN68BhXaQN/MeL+w3lBj8O3XbDJxAyHylHMrBl/0jIETwDcplIxzu1/1xweL0H3SPOB+jxaaTsgR38a6Ru6yJ7tNuTlsChK2s1zpca8YHScPHBVPq1eP1+Ug/HzmE47Mv4vaLPcyQuDYufc6WUUVahOxvn0eWtx3wq7M+HXDq8feg1a6VHQN65uBb780nyVwbEDoRcGRyAXC5bxA0pmQF/1/87tgXkGa9v/hmjhY5DmjHkDH5akBzEsAs4DVLuapwvMtiOHagfbpGbGjT8OSJv6iC4pEWLONqKjHZrzL9gu4N/DSTN2gT/zuDHaii26NoxccM5OI/9QV+HdGT2usb5I0aqizyX69Ur3A4t4ukhdWaL5bGsokn5li3Vwy1tLThYJDcCt2BdLjVs27Ac4jOCFuOlNfjRtpkc4w1+WuSRMrPqcH084HSc+zYsqTNt5PlgrE6V5+P68lmR5RHns/K8VZ6XWkUowRJtgJY+YwyXJlTozol8/+L+/uJ+Qtp2LY/L2DrzX+X5d7gttDKzRp4G6H2LDAylbD6iGxCJ3hx8kJuBA5DLJnYYfTAGPPJlDFiMgNQtPxb/OcaHkPItgyU/InUqTrH9amC4Xeicia06aKtH9dH/nzE9Sy75oK0+1oijfUQu1ehfktS6ZCmnpQyyw0GJGH3/hE32OaXvFFo7eQnvUJL/KM89lkdLc8kzGXhwwEFuFg5ALpvY6sVgCMaMgha2LQYWQ8nD3tGJX6f4qRHXZ6584QHX96VkB9sKSJ3pLIPCU67AWPigPJ/aOjFskThmakDjEC9fH6FTK89lxSl1Rtdjmes/Pez1KRjib2G/rlvcsOJkSY8tuhlojUtYAdHKs2UlbizMUEYuIQ0O0dJD+sTUdzpMDwvaJJhl4m/AgRBCzhC5V3zq6lTZ694oz608Qr+qdWeU1RhkhUj4T4bw4ifWyTijHl8x3QG4me+xBAG6TloHHePOIP+LIsPjtOkm7/DFoMOxezchz2fIsr6jRde3sBMmZDS922DeOzbQjTsHW90b0+WuDxtLk0fYeDDo4EfCBUM4hzjOIMP6HsJOkbVLkOUwXa+bXlbpQYlHmfoyULLOOMTrzPuRMFp+BNgIyKsnA82MsCnvUxnlaPpUBhn3vT5DHktfH0AIWR0xir5mOg87VqPtSZHz1iCjUWRsYXs/kXM/8h6PSDNA3YQezhA2YF12WF4nSxw+Et6voKOG5R1S3ilnQONgw1LHLcaqQ75B4mF/r0+I1xnLBEIsvbV3kOcWA3lj0MGNhAuZ4Y7RZOxgxzJB9GSQI+mm5U+KXlYcyqZHhTLp4ZBXZ94rYd4Vinsq/oEc3cfYKXIqoxxNn0oJL5MGU21tyqCSEFIAD72BGnMN0qmMsj/h9VaIYTvYzhheM6Y87O85vOuu16ukoegMYQPWw8H2PnNnLytDHJtIeI/Tp5vFYEtJt22irE+w44wyNxgvq6L3E2xl303o4GF/t6HOiT7DNkf5+xb2+tdgmsoY3k2Ev4NtImQqj4IhrIOOJS3kPR77OEXnh8g7NcZ38hPhPeavTudiWVkVt8Pr9LiPyLOk72ZCRspElR8J/y4z3IA8awwyhneYopkR9pCdIqcyytH0qSJhnSF8ACFkVawN1aGzzMAcY+3k5rjGqEfOQGLMWWZj3YQezhA2YD0CdH0+YD7OEI/kz5TB7nH6dPMGHQ7dTpEXEuVtkEaVILvp9RX3CWV08glySrgQ0cUlyNmhM1Sr/q+8o7XtCBPxB0NYB52dUQ9rHlm2lA3uC16XkRIDw7k0sOs/uNhkVcokQ256vJ+IOxjDb3o9Pbr8e0R6uYiViWZG2EM0nSqjHE2fKhI2QE+LHQghq1IhrcESd488JFwp43+sE3CwkTODPea8wY+b0MEZwgasxw7r6WOJy0+E9SvqGSOlHGurctYZ3ME9IJ2UwUSqaxCve94go1Sd3ECnKhTXlIutUAVDeAednPRqFJmWmfc5zmE5KqTro02o7JD3nhYX669KTpJpcjaYppkR9pCdIqcyytH0qSJhrWWbXAi8Bes62CKNFvlX3Eq4f6E8z+iuxmyN/qUxqjGPlG8CnDsOtjM9JVZABMsNTm9w3mgfATykVp5L+W1RTt4Yv2CZ8vpcSLaUrRrzaNHVS40KaTcJperwC5Zni/Q0d4hvBZRBzVLpktI+5yBt+nNaEPXqZ8nH3L4uhugp35VpI88t5Vijhe22tlvguZAfciZwAHIdtEjr+Oc2aNsX9w+U64xadB1FqnE8p0OUTrrC9WCZUa9RroGuDX48zvsKT6th0hr9Wgc0NfLyoUVn9NQoR9vLLGWkzRnItIgbdccElDfO6kQd5jAM/FLLgrZ6HVDG+B0YJoe2WBaJJ3VyS9oXp8iU/Cw5KGthqzPvZsY76E46aoOfUhNshJAEKtiXdB3K4JB++PbYSSM9x0h1GTq8Owqfm16WsAHrYNmeE1CWJjNOj/V1HcMZ9BBn7dS8UV6F+QTMP4+VUve8QZ7r/boM3d4jvx0ImJ8Wss2lskVXbAvWwH2i/o9GuQHz02WHZbddjfGQqHcwyg2Ynx4bpJfTKiMe0fPeGH4TibuZEfaQnSKnMsrR9KmQr4fIdiCErE7KLSKlcegGAVrjMjjp7N+hbGMREG+cJE4xcjy+1V3T103EaQkbsDwOtnR3KEtliHM3Es7jPNJNaArqYt337VEG1+uWcjZE3rdC3scLU8tXgJ6+O5RLj4D0Pf/iv0JaegSkp4WGQzew0NIrZaB0qG9Kugzts8fpcLD1KaKrZfX3kID09Kgwr/100K/mPYzrsDxWSphNJN5mRthDtPSqjHI0fSolvKTLFuPtmrYySM6Mv4BcE9JIeMXP0kvp0gi4/q80Fn97cf/Ffo98jWW3N9zh2y/Wfu7j5P5Qcq0M5X6od9/1v0vda9GV/RqnOfPksf9aOfC6LViiTh62AQ77dkj4zwrxz2XQ/dAIFT2HdiyXWBkZ0uQzljkzMYdTpEeLZerMWJxDmfyMstsrrxmPva3TolulZv9OyAnRZhdyZuYIIYQQQggh5Bs8bNsNCCGEEEIIIWQWspRrWf0IIIQQQggh5ITwDMjl8YBu/6jsF5U9j+7FPUHfWtW+uO9BCCGEEEIIIQnINqqvGa4CIYQQQgghhCRgvWp37Io6QgghhBBCCElCtl/lDEAcCCGEEEIIISSRDdIHHwGEEEIIIYQQkoFspUrZdsUvgxJCCCGEEEKycC/uE2zf+njE66/GEkIIIYQQchbwGt7LQwYWsrLhsD/b0aK7krfu/xJCCCGEEHKW/D84Anvni65OHgAAAABJRU5ErkJggg==","w":800,"h":122,"e":1}],"layers":[{"ddd":0,"ind":40,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":41,"ty":4,"nm":"右手:0:0:rg-shape-mask","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"parent":40,"shapes":[{"ty":"gr","nm":"右手","it":[{"ty":"sh","d":1,"ks":{"a":1,"k":[{"t":5,"s":[{"c":true,"v":[[0.031147335329118824,-7.0836745560207355],[-3.962824200981067,-7.130996195417722],[-8.67225517272775,-8.904539796632633],[-11.131981150246927,-1.2370080773785892],[-4.14780789110685,-6.246808095824928],[-4.662057055755126,-3.788792521160401],[-1.6088778237837495,0.7553485175929523],[2.461073318007076,-2.0521248934945397],[3.0247132709436064,-4.746225154814245],[3.977099374148136,-2.4469176023265176],[7.339057046882704,2.6273724636818865],[10.768551343782285,-2.1927553925535275],[8.492441585364057,-4.426966432932079],[3.2096966609879702,-5.630412054081364],[0.031147335329118824,-7.0836745560207355]],"i":[[0,0],[1.3359941733446221,0.3175852834736269],[3.5456930241587283,0.8973652748489862],[-3.902693286147165,-1.0498273411460874],[-1.493230646172098,0.6987335817211333],[0.19377441333057055,-1.1328225628459472],[-3.0884397477559653,-0.5972092374418677],[-0.5511226710097954,1.7014390337776983],[0,0],[-0.0018596045514352125,-1.478205269458379],[-2.999375596277641,-0.48720438921927917],[0.27218344932989885,1.3014222043417327],[1.4010375984600372,0.5700649524381339],[1.00373901137807,0.328459588521158],[2.5339853257064227,0.4523601352101698]],"o":[[-2.5339838252993285,-0.45236193569868177],[-1.9497837703847312,-0.46349201499861886],[-3.545692423995891,-0.8973652748489862],[3.902693886310002,1.0498309421231116],[-0.24544439443879257,1.4264655313344632],[-0.34857240736798034,2.0377854901738015],[2.3736932387263714,0.45899922170263924],[0.5645760541512519,-1.7429726385762463],[0,0],[0.0018587043071792324,1.478204669295542],[2.9993725954634547,0.4872076901148846],[-0.12113797205376145,-0.5792082407744349],[-1.7469507773226922,-0.7108127668242781],[-0.6365717158457413,-0.14364957527531697],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[{"c":true,"v":[[0.6073086386321095,-9.218292924726647],[-4.980926634465015,-9.543302106834592],[-10.852661764781296,-8.046191107837803],[-11.30873150648894,0.42257895492382924],[-3.488266993219057,-5.005682551287337],[-3.9241316764493925,-2.0401199660096245],[-0.7560273267687458,2.925126700926478],[2.6908979017890173,-0.8369042009902439],[3.5630383303201065,-4.586990851060827],[4.643655525427789,-0.9416539163272231],[7.659816475939588,3.002792323310502],[11.081015322101734,-1.2869600804508385],[10.63296255557501,-5.3928928099093785],[6.590569965947766,-7.3525667123507725],[0.6073086386321095,-9.218292924726647]],"i":[[0,0],[1.3555112798923374,0.24340444095474276],[2.6112905002930664,-2.1031722366817056],[-3.902693286147165,-1.0498273411460874],[-1.493230596158528,0.6987334816939937],[0.1681827716980548,-1.3349973738986347],[-3.1151704203086723,-0.30212039982116246],[-0.2247944719192244,2.038636230893046],[0,0],[0.1057648963323457,-2.001397522973281],[-2.2338216847378405,-0.036365366720296305],[0.2230241113250391,2.9789781620070745],[0.5206936001082186,1.0423420890767177],[1.8880638197464246,0.18764914723204051],[2.279479672749776,0.4367180911811055]],"o":[[-2.279479972831196,-0.4367150903669188],[-1.3555118800551746,-0.24340204030339352],[-2.611292900944416,2.103174037170218],[3.902693886310002,1.0498309921366813],[-0.21944138925408915,1.5262123948427246],[-0.30253671060585646,2.4014690095122346],[2.3942376277131023,0.23220164837972082],[0.23028190025032438,-2.0884011121852755],[0,0],[-0.10576369600667107,2.00139542240335],[2.233813882620955,0.03636746729022692],[-0.0992570756070926,-1.3258173057732718],[-0.6492517334694144,-1.2996941158111754],[-3.4022679097845687,-0.3381437458026875],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[{"c":true,"v":[[0.5204305291986201,-9.220626958000981],[-4.0926661299395874,-9.125391318486574],[-9.918089394832673,-6.42779965279757],[-11.485481862730952,2.082165987226248],[-2.828726095331263,-3.7645570067497456],[-3.1862062971436593,-0.2914474108588475],[0.09682317024625851,5.094904884260004],[2.9207224855709577,0.37831649151405145],[2.621427175595042,-3.7960575535378682],[5.8640959576414575,-0.6217454431533037],[10.131231524959825,2.5006072695088855],[11.984736921560774,-1.4143617473128167],[9.92947208320528,-4.760605656559263],[5.2259077031933945,-8.197094851327803],[0.5204305291986201,-9.220626958000981]],"i":[[0,0],[1.3924615803179559,-0.01033510414006457],[2.3562810106344907,-1.8936351346776255],[-3.902693286147165,-1.0498273411460874],[-1.4932305461449582,0.6987333816668542],[0.14259113006553903,-1.5371721849513231],[-3.1419010928613806,-0.007031562200457249],[0.10153372717134675,2.3758334280083924],[0,0],[-1.0108278597327949,-1.952107799592013],[-2.0120831222103397,0.5880844101779703],[0.6149814579360011,2.0765903494336233],[1.134367178655202,1.1440129957766048],[1.7157317155844125,0.591122584501192],[1.858570095764737,0.1553371463692815]],"o":[[-1.8585705458868655,-0.15533594604360687],[-1.3924615052976008,0.01033720470999519],[-2.356282511041583,1.8936378354103938],[3.902693886310002,1.049831042150251],[-0.19343838406938563,1.6259592583509863],[-0.2565010138437325,2.765152528850667],[2.414782016699833,0.00540407505680218],[-0.10401225365060303,-2.433829585794304],[0,0],[1.0108272595699577,1.9521089999176873],[2.0120855228616894,-0.5880814093637836],[-0.2737011188792496,-0.9242029711991346],[-1.1343719799579006,-1.1440093947995809],[-1.7157365168871113,-0.5911237848268667],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[{"c":true,"v":[[-0.12163358623039727,-7.603956319856055],[-3.7595922597051574,-7.088477059044967],[-8.98351702488405,-4.809408197757336],[-11.662232218972964,3.741753019528667],[-2.1691851974434697,-2.523431462212155],[-2.4482809178379275,1.4572251442919293],[0.9496736672612628,7.264683067593531],[3.1505470693528994,1.5935371840183465],[1.679816020869978,-3.0051242560149087],[5.226627298435342,-1.1256901743939425],[11.312373294585795,0.9902449751454958],[11.645240408722769,-2.8413020074516004],[8.044914561482823,-5.9740130805638],[3.3060609067179594,-7.422617118559895],[-0.12163358623039727,-7.603956319856055]],"i":[[0,0],[1.4294118807435754,-0.2640746492348719],[2.1012715209759145,-1.6840980326735455],[-3.902693286147165,-1.0498273411460874],[-1.4932304961313883,0.6987332816397147],[0.11699948843302332,-1.7393469960040113],[-3.168631765414088,0.28805727542024806],[0.4278619262619179,2.7130306251237397],[0,0],[-1.709234952870426,-1.4688016180418355],[-2.030333473930396,1.2198428950887619],[0.45265961646599245,0.6964520626950623],[2.1121722785901524,1.0103594326382668],[0.5885184460801474,0.07533316409359492],[1.437660518779697,-0.12604379844254238]],"o":[[-1.4376611189425355,0.12604319827970506],[-1.4294111305400283,0.26407644972338384],[-2.1012721211387513,1.6841016336505692],[3.902693886310002,1.0498310921638208],[-0.1674353788846822,1.7257061218592478],[-0.21046531708160854,3.1288360481891004],[2.435326405686565,-0.22139349826611635],[-0.4383064075515305,-2.7792580594033334],[0,0],[1.7092373535217755,1.4688002676754512],[2.0303364747445825,-1.2198407194984766],[-0.45265841614031777,-0.6964517626136437],[-2.1121758795671775,-1.0103609330453602],[-1.060505738429099,-0.13574603087065326],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[{"c":true,"v":[[-0.12163358623039727,-7.603956319856055],[-3.7595922597051574,-7.088477059044967],[-8.98351702488405,-4.809408197757336],[-11.662232218972964,3.741753019528667],[-2.1691851974434697,-2.523431462212155],[-2.4482809178379275,1.4572251442919293],[0.9496736672612628,7.264683067593531],[3.1505470693528994,1.5935371840183465],[1.679816020869978,-3.0051242560149087],[5.226627298435342,-1.1256901743939425],[11.312373294585795,0.9902449751454958],[11.645240408722769,-2.8413020074516004],[8.044914561482823,-5.9740130805638],[3.3060609067179594,-7.422617118559895],[-0.12163358623039727,-7.603956319856055]],"i":[[0,0],[1.4294118807435754,-0.2640746492348719],[2.1012715209759145,-1.6840980326735455],[-3.902693286147165,-1.0498273411460874],[-1.4932304961313883,0.6987332816397147],[0.11699948843302332,-1.7393469960040113],[-3.168631765414088,0.28805727542024806],[0.4278619262619179,2.7130306251237397],[0,0],[-1.709234952870426,-1.4688016180418355],[-2.030333473930396,1.2198428950887619],[0.45265961646599245,0.6964520626950623],[2.1121722785901524,1.0103594326382668],[0.5885184460801474,0.07533316409359492],[1.437660518779697,-0.12604379844254238]],"o":[[-1.4376611189425355,0.12604319827970506],[-1.4294111305400283,0.26407644972338384],[-2.1012721211387513,1.6841016336505692],[3.902693886310002,1.0498310921638208],[-0.1674353788846822,1.7257061218592478],[-0.21046531708160854,3.1288360481891004],[2.435326405686565,-0.22139349826611635],[-0.4383064075515305,-2.7792580594033334],[0,0],[1.7092373535217755,1.4688002676754512],[2.0303364747445825,-1.2198407194984766],[-0.45265841614031777,-0.6964517626136437],[-2.1121758795671775,-1.0103609330453602],[-1.060505738429099,-0.13574603087065326],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":5,"s":[95.18107604980469,110.5035400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[94.93107604980469,109.2535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[94.36652994155884,110.63403606414795],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[94.83251953125,109.7535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[94.83251953125,109.7535400390625],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":490,"s":[96.58251953125,106.75734405517579],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":5,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":490,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":1,"k":[{"t":5,"s":[-3.341681002894269],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[3.0704154322201376],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[8.473435415226104],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[13.295472524691089],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[13.295472524691089],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"0","w":35,"h":29,"ind":42,"ty":0,"nm":"右手:0:0:rg-precomp","sr":1,"ks":{"p":{"a":0,"k":[77,93],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":40,"tt":1},{"ddd":0,"ind":43,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"ind":44,"ty":4,"nm":"左手:0:0:rg-shape-mask","sr":1,"ks":{"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"td":1,"ao":0,"parent":43,"shapes":[{"ty":"gr","nm":"左手","it":[{"ty":"sh","d":1,"ks":{"a":1,"k":[{"t":5,"s":[{"c":true,"v":[[0.031147334517275284,-7.083674371387431],[-3.962824097691549,-7.130996009550998],[-8.67225494668869,-8.904539564539164],[-11.131980860096037,-1.2370080451364405],[-4.147807782995803,-6.2468079330042325],[-4.6620569342403675,-3.7887924224069542],[-1.6088777818489561,0.7553484979050783],[2.4610732538601283,-2.052124840006679],[3.0247131921055965,-4.746225031105678],[3.977099270486541,-2.446917538548534],[7.339056855592951,2.627372395200415],[10.768551063104056,-2.192755335400186],[7.498190027760535,-5.521472752587327],[3.2096965773284376,-5.630411907326799],[0.031147334517275284,-7.083674371387431]],"i":[[0,0],[1.335994138522438,0.31758527519588636],[3.5456929317415775,0.8973652514594991],[-3.9026931844249364,-1.049827313782734],[-1.4932306072516046,0.6987335635089063],[0.19377440827991357,-1.1328225333193547],[-3.0884396672569485,-0.5972092218758344],[-0.5511226566449909,1.7014389894303323],[0,0],[-0.0018596045029653217,-1.4782052309295166],[-2.999375518100048,-0.48720437652048065],[0.27218344223554,1.3014221704206543],[2.5227940235232453,-0.16174478068610898],[1.8087279268523042,0.5918809808786657],[2.533985259659051,0.45236012341957366]],"o":[[-2.5339837592519965,-0.45236192390803864],[-1.9497837195643528,-0.46349200291787446],[-3.545692331578756,-0.8973652514594991],[3.9026937845877585,1.0498309147596643],[-0.24544438804137703,1.4264654941541774],[-0.3485723982825721,2.037785437059692],[2.373693176856953,0.4589992097389978],[0.56457603943579,-1.7429725931463225],[0,0],[0.0018587042587328059,1.4782046307666952],[2.9993725172859396,0.487207677416],[-0.2721846425611833,-1.3014217202985374],[-2.5227946236860666,0.16174688125598483],[-0.6365716992537397,-0.14364957153114502],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[{"c":true,"v":[[0.11100518243168958,-9.356665698967198],[-4.063196659088135,-9.93504524230957],[-9.762458214299727,-10.119803936296957],[-11.220356035913579,-0.48622464044184194],[-3.8180373426472487,-6.717881357774345],[-4.293094254204374,-3.4799355770810383],[-1.1824525444560674,2.197290949500796],[2.5759855427559537,-1.7247874541346766],[2.8005636562690315,-5.320628155035855],[4.4950054262720105,-2.4948022121875932],[8.216321753910265,3.0119863831345466],[11.118609032374806,-2.853801539856602],[7.315694917596364,-7.364971917759122],[3.943272829055786,-8.25999641418457],[0.11100518243168958,-9.356665698967198]],"i":[[0,0],[1.3585445880889893,0.19099903106689453],[3.468237118301623,-0.38905679568479173],[-3.9026931844249364,-1.2535207973315714],[-1.4932305822448202,0.8343057753022344],[0.18097858779717396,-1.4733201801553906],[-3.1018050031849396,-0.5369113375991769],[-0.3879585613525161,2.2328729421030435],[0,0],[-0.26286456406266007,-1.7245932602566512],[-3.0091876800987776,-0.2382263997148206],[0.3946426649131971,1.528614264954506],[1.9354748725891113,0.4700889587402344],[1.4129024778094808,0.4324144413455421],[2.4067324364975247,0.5307911137175494]],"o":[[-2.4067318363347034,-0.5307903971077137],[-1.3585724830627441,-0.1910085678100586],[-3.4682368182202117,0.3890550041602022],[3.9026937845877585,1.2535251268493284],[-0.23244288578790456,1.762786623676777],[-0.32555455050146165,2.6502919203500994],[2.3839653710825774,0.4126557919686282],[0.3974289668419518,-2.2873793102429407],[0,0],[0.262863813859133,1.7245935887028252],[3.014797902128675,0.04167474357778741],[-0.39464326507601877,-1.5286139663670741],[-1.9354643821716309,-0.4700746536254883],[-0.8268239889084348,-0.1648159625330909],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":30,"s":[{"c":true,"v":[[0.19086303034610388,-8.588795104380685],[-4.312529671358838,-8.767470778347704],[-10.852661481910761,-8.046190898116869],[-11.30873121173112,0.42257894390946826],[-3.4882669022986943,-5.005682420816111],[-3.924131574168381,-2.0401199128346676],[-0.7560273070631789,2.9251266246841543],[2.690897831651779,-0.8369041791766518],[2.5764141204324664,-4.165858079966279],[5.012911582057479,-1.7318906797363947],[9.093586652227579,2.417722318006659],[11.468667001645557,-2.5873788451166586],[7.133199807432193,-6.81489805349055],[3.464216927640622,-7.140471980342451],[0.19086303034610388,-8.588795104380685]],"i":[[0,0],[1.3555112445614474,0.24340443461049788],[3.390781304861668,-1.5490376474694474],[-3.9026931844249364,-1.049827313782734],[-1.4932305572380358,0.6987334634817692],[0.16818276731443432,-1.3349973391024321],[-3.1151703391129306,-0.30212039194650825],[-0.22479446606004128,2.038636177756762],[0,0],[-0.5238695236223548,-1.4104985123784481],[-3.0189998420975073,0.08817377117729956],[0.5171018875908543,1.2590156156987788],[1.963436872255146,0.410774241342772],[1.017077028766657,0.13241572383500014],[2.2794796133359982,0.4367180797982133]],"o":[[-2.2794799134174104,-0.4367150789841048],[-1.3555118447242689,-0.24340203395921123],[-3.390781304861668,1.549034646655338],[3.9026937845877585,1.0498309647732327],[-0.21944138353443213,1.5262123550625746],[-0.3025367027203512,2.4014689469188513],[2.394237565308202,0.2322016423274725],[0.23028189424811352,-2.088401057751889],[0,0],[0.5238689234595332,1.410499662690522],[3.0302232869714105,-0.4174022394910957],[-0.5171018875908543,-1.2590155656852102],[-1.963439272906433,-0.4107718406914853],[-1.01707627856313,-0.13241812448628681],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[{"c":true,"v":[[0.19086303034610388,-8.588795104380685],[-4.631266859215442,-8.899779901236705],[-10.620870439065946,-7.406002203746747],[-12.345839500427246,0.838851273059845],[-3.4882669022986943,-5.005682420816111],[-3.924131574168381,-2.0401199128346676],[-0.6523193120956421,4.205990791320801],[2.690897831651779,-0.8369041791766518],[2.5764141204324664,-4.165858079966279],[5.012911582057479,-1.7318906797363947],[10.61591625213623,4.286111831665039],[11.468667001645557,-2.5873788451166586],[7.557727246589188,-6.460170517286517],[3.632912332801269,-7.677768837752239],[0.19086303034610388,-8.588795104380685]],"i":[[0,0],[1.5860937377875481,-0.022039163487878488],[3.390781304861668,-1.5490376474694474],[-3.9026931844249364,-1.049827313782734],[-1.4932305572380358,0.6987334634817692],[0.16818276731443432,-1.3349973391024321],[-3.1151703391129306,-0.30212039194650825],[-0.22479446606004128,2.038636177756762],[0,0],[-0.5238695236223548,-1.4104985123784481],[-3.0189998420975073,0.08817377117729956],[0.5171018875908543,1.2590156156987788],[1.7758687214283495,0.7764709021783444],[1.6669576317110124,0.3719853043642066],[2.2794796133359982,0.4367180797982133]],"o":[[-2.2794799134174104,-0.4367150789841048],[-1.5861115904077518,0.022046200952335893],[-3.390781304861668,1.549034646655338],[3.9026937845877585,1.0498309647732327],[-0.21944138353443213,1.5262123550625746],[-0.3025367027203512,2.4014689469188513],[2.394237565308202,0.2322016423274725],[0.23028189424811352,-2.088401057751889],[0,0],[0.5238689234595332,1.410499662690522],[3.0302232869714105,-0.4174022394910957],[-0.5171018875908543,-1.2590155656852102],[-1.7758825538223113,-0.7764724477827346],[-1.6669737162281544,-0.37199091131718937],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[{"c":true,"v":[[0.19086303034610388,-8.588795104380685],[-4.737512588500977,-8.943882942199707],[-10.543606758117676,-7.192605972290039],[-11.06530475616455,1.2064639329910278],[-3.4882669022986943,-5.005682420816111],[-3.143995761871338,-0.10238105803728104],[-0.5922297239303589,5.3282599449157715],[2.3353824615478516,1.0439252853393555],[2.5764141204324664,-4.165858079966279],[5.012911582057479,-1.7318906797363947],[10.214493751525879,4.590564727783203],[12.177108764648438,-1.0098834037780762],[7.6992363929748535,-6.341928005218506],[3.6891441345214844,-7.856867790222168],[0.19086303034610388,-8.588795104380685]],"i":[[0,0],[1.662954568862915,-0.1105203628540039],[3.390781304861668,-1.5490376474694474],[-3.9026931844249364,-1.049827313782734],[-0.5287859439849854,-1.5615630149841309],[0.16818276731443432,-1.3349973391024321],[-3.1151703391129306,-0.30212039194650825],[-0.22479446606004128,2.038636177756762],[0,0],[-0.5238695236223548,-1.4104985123784481],[-3.0189998420975073,0.08817377117729956],[0.5171018875908543,1.2590156156987788],[1.713346004486084,0.8983697891235352],[1.8835844993591309,0.4518418312072754],[2.2794796133359982,0.4367180797982133]],"o":[[-2.2794799134174104,-0.4367150789841048],[-1.662978172302246,0.11052894592285156],[-3.390781304861668,1.549034646655338],[3.9026937845877585,1.0498309647732327],[0.5212347507476807,1.53922700881958],[-0.3025367027203512,2.4014689469188513],[2.394237565308202,0.2322016423274725],[0.23028189424811352,-2.088401057751889],[0,0],[0.5238689234595332,1.410499662690522],[3.0302232869714105,-0.4174022394910957],[-0.5171018875908543,-1.2590155656852102],[-1.7133636474609375,-0.8983726501464844],[-1.883606195449829,-0.45184850692749023],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[{"c":true,"v":[[0.0854621852912154,-9.819659283707283],[-4.321125935926511,-9.672783236643971],[-10.46610626130229,-7.896312204118],[-10.214434513477402,0.6826951873882287],[-3.467524825682444,-3.4190259670690857],[-3.8146680981074725,-0.7216462992873813],[-0.17433736229383281,3.2414610912425013],[3.2633160927712552,-1.0624377348340184],[3.799454529178245,-4.52359608938804],[6.8843043889983235,-1.9436042072535726],[11.891915101457267,0.8444651664335459],[12.678442023244996,-4.127690275749624],[8.006430014417196,-7.986191371243225],[3.5761649147985297,-8.737640791815565],[0.0854621852912154,-9.819659283707283]],"i":[[0,0],[1.449184461343103,0.028305171739523877],[3.08361879265571,-1.9340203659066102],[-4.094247895435932,-1.2630277120408293],[-1.0181117435713882,0.47640917964666085],[-0.07163140174148278,-1.3774261511005041],[-2.647965101938924,-0.23996410583232225],[-0.35111484387119823,2.956924056081221],[0,0],[-1.5952985530783181,-1.7627979064945576],[-2.333455133023247,0.568903570649231],[1.5807665250012828,1.6436671969174887],[1.8727699831420572,0.5725941932605103],[1.0829472864805585,0.1610447358807132],[2.0821923265771254,0.23206033312574656]],"o":[[-2.0821927515965966,-0.2320585999589296],[-1.4491845950218913,-0.02830259640342094],[-3.0836190130742187,1.9340201969538047],[4.094248525056364,1.2630321566200484],[-0.1496191251371128,1.04059933299721],[-0.01997377463560531,2.10456611833471],[2.1564189819023305,0.19229426457028684],[0.3548547292516891,-2.9908557732262113],[0,0],[1.5952994663874442,1.7628011485245323],[2.3411070409638914,-0.7933780290344689],[-1.3488135161181687,-1.4953678469023384],[-1.8727716199497526,-0.5725922436100125],[-1.0829472158151703,-0.16104449563159365],[0,0]]}],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[{"c":true,"v":[[-0.12784928422931124,-11.343903187947575],[-3.9517142780522723,-10.574889455613766],[-8.77643037108197,-6.898140854220132],[-7.166202028481252,1.129258563043614],[-3.1171515955441684,-0.01734551484990461],[-3.2601439192821777,1.9156473453044953],[0.9763221234627788,3.5690446943771033],[4.088654712576634,-1.407580101380571],[5.846466891464643,-4.817385894394782],[9.920779001950121,-2.1830276496910317],[16.289624203339095,-2.3009759791778164],[13.9060396775219,-6.764473402505424],[8.994857300148942,-9.558051844656633],[3.4750066461229445,-11.073373708666937],[-0.12784928422931124,-11.343903187947575]],"i":[[0,0],[1.5024574337204657,-0.39395771481342606],[2.20865032639373,-2.512408572334266],[-4.102128027823947,-1.5661767665502673],[0,0],[-0.5331901438986604,-1.3371166853404617],[-1.4996328823102287,-0.0972296736897942],[-0.5662299831194668,4.484556913068126],[0,0],[-3.543453522591785,-2.2927120458066823],[-0.7871751945381232,1.4561301903827775],[3.515069225393882,2.2473585678558394],[1.5284750060153307,0.8371873401821814],[1.1146982533396301,0.20251703412056501],[1.511127592197807,-0.18803746192487925]],"o":[[-1.5111282230300604,0.18803656657661091],[-1.5024566451801504,0.3939604008582311],[-2.208650957225982,2.5124139444238756],[4.102128658656199,1.5661823624769446],[0,0],[0.533189513066408,1.3371173568516628],[1.4996298858570296,0.09723549345353844],[0.5662255672936999,-4.484560110318627],[0,0],[3.5434573075853,2.2927190797577857],[0.7871739328736183,-1.456131629145503],[-2.8512255211985362,-1.8229296385624387],[-1.5284750060153307,-0.8371864448339131],[-1.114699515004135,-0.20251166203095491],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[{"c":true,"v":[[-0.1237307243379232,-10.978468645522828],[-3.8244130418668596,-10.234228060203561],[-8.493704860854898,-6.67592290111545],[-6.935348704381688,1.0928804241060819],[-3.016735112071662,-0.016786743307404928],[-3.1551210553134967,1.8539363363616215],[0.9448707065619503,3.4540708451495394],[3.9569420525452363,-1.362236062230035],[5.658127752996522,-4.662197756693468],[9.601189238620114,-2.1127032034181656],[15.76486731248843,-2.226851924154625],[13.458068008308896,-6.54656143678843],[8.70509534544995,-9.250147039365709],[3.3630621555354283,-10.716654051659967],[-0.1237307243379232,-10.978468645522828]],"i":[[0,0],[1.454056999081034,-0.38126668996401614],[2.1375004665941955,-2.4314733896371457],[-3.969981335986145,-1.5157236658354578],[0,0],[-0.5160138604772708,-1.2940425673776927],[-1.451323438279149,-0.09409749945256272],[-0.5479893483608523,4.3400905881751255],[0,0],[-3.429304071985801,-2.2188542066229666],[-0.7618169909059045,1.409222149912303],[3.4018341516550756,2.1749617537873545],[1.4792364366114312,0.8102180362737779],[1.0787891628438981,0.19599311387275345],[1.4624478555100922,-0.18197998922621975]],"o":[[-1.4624484660206019,0.18197912272086195],[-1.4540562359428986,0.38126928948008953],[-2.137501077104704,2.431478588669292],[3.969981946496653,1.5157290814939444],[0,0],[0.5160132499667625,1.294043217256711],[1.4513205383542334,0.09410313173738849],[0.5479850747872927,-4.340093682428822],[0,0],[3.4293077350488526,2.218861013981101],[0.7618157698848873,-1.4092235423264667],[-2.759375628227309,-1.764205454540105],[-1.4792364366114312,-0.8102171697684201],[-1.078790383864915,-0.19598791484060654],[0,0]]}],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[{"c":true,"v":[[-0.11033290283559306,-9.789697109037439],[-3.4102976023889786,-9.126044450203308],[-7.573988741611836,-5.953040012721586],[-6.1843746476554795,0.9745410470118808],[-2.690076727360662,-0.014969039647772239],[-2.8134779513591015,1.6531882340275605],[0.8425581311120258,3.080056832968312],[3.528476094726414,-1.2147302935258164],[5.045453851039955,-4.157365236824365],[8.561552395649667,-1.8839352837421144],[14.057814521915686,-1.9857237423583134],[12.00080026897927,-5.837686078194521],[7.7624894226027275,-8.248521779618123],[2.9989027545280647,-9.556232346746723],[-0.11033290283559306,-9.789697109037439]],"i":[[0,0],[1.29660866737406,-0.3399823356999031],[1.9060474474203721,-2.168188367777466],[-3.5401034572964605,-1.3515979385321968],[0,0],[-0.46013880088801895,-1.153920932861168],[-1.2941711022505755,-0.08390842549193578],[-0.488651916095723,3.870136505909309],[0,0],[-3.0579718577800725,-1.9785920344009833],[-0.6793258544786748,1.2566286294048978],[3.0334764378512773,1.9394523481198198],[1.3190616227686214,0.7224859334670587],[0.9619756169783078,0.1747705697600929],[1.3040909443270843,-0.16227481554607529]],"o":[[-1.3040914887302395,0.16227404286772912],[-1.296607986870117,0.3399846537349415],[-1.906047991823526,2.1681930038475423],[3.540104001699615,1.3516027677718603],[0,0],[0.4601382564848646,1.1539215123699273],[1.2941685163355923,0.08391344790118578],[0.4886481052736428,-3.870139265110747],[0,0],[3.057975124198998,1.9785981046441474],[0.6793247656723661,-1.256629871045545],[-2.4605846664618127,-1.5731735996807457],[-1.3190616227686214,-0.7224851607887125],[-0.9619767057846165,-0.17476593369001597],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[{"c":true,"v":[[-0.13699335390786715,-12.15524477505678],[-4.234349811962988,-11.331229443029896],[-9.404140501224168,-7.391511474194403],[-7.678744989312457,1.2100256869882107],[-3.3400973207400457,-0.018586105263484656],[-3.493316778557381,2.052658771771199],[1.0461508876946286,3.8243108350363593],[4.381084535776108,-1.5082534106036967],[6.264619413406305,-5.161936218257598],[10.63033553178315,-2.3391627196628386],[17.45469493213301,-2.4655469801741723],[14.900631055413015,-7.248283824316661],[9.638189817785145,-10.241665308632154],[3.723546973095757,-11.865366416167173],[-0.13699335390786715,-12.15524477505678]],"i":[[0,0],[1.609916584124176,-0.4221344607089868],[2.3666179880967535,-2.6921017101168765],[-4.39552149297234,-1.6781932676093143],[0,0],[-0.5713251077126449,-1.4327502918390562],[-1.6068900144151153,-0.10418375963874706],[-0.6067280308867528,4.805302556172346],[0,0],[-3.7968893248227,-2.4566919916162995],[-0.8434757430431665,1.560275911668375],[3.7664749185559887,2.408094730447996],[1.6377949919752604,0.897064870344182],[1.1944239910357455,0.21700150998021453],[1.6192068519257017,-0.20148632606506423]],"o":[[-1.6192075278765032,0.20148536667946473],[-1.6099157391856755,0.4221373388657853],[-2.3666186640475537,2.6921074664304725],[4.39552216892314,1.6781992637693113],[0,0],[0.5713244317618446,1.4327510113782556],[1.6068868036488129,0.10418999564514381],[0.6067232992311495,-4.805305982097428],[0,0],[3.7968933805275022,2.4566995286514786],[0.8434743911415655,-1.560277453334662],[-3.0551516127076117,-1.9533096851509053],[-1.6377949919752604,-0.8970639109585826],[-1.1944253429373464,-0.21699575366661755],[0,0]]}],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[{"c":true,"v":[[-0.13330908825374618,-11.408270847928442],[-4.120472246849569,-10.634893572145492],[-9.234727013205426,-6.961721865925131],[-8.110484575391016,1.5289107411234817],[-3.145342076964458,-0.34837207525549035],[-3.3132883050626067,1.9493286261050884],[1.0207586864875315,4.231218807699875],[4.165854888529879,-1.0813121062348945],[5.584635898832222,-4.815205225019499],[10.034318878861558,-2.042391507021052],[16.603856370675278,-1.8475355072806712],[14.452327107127665,-6.650332683241548],[9.346415516065631,-9.579898949044278],[3.6234068142256484,-11.136206328261032],[-0.13330908825374618,-11.408270847928442]],"i":[[0,0],[1.5666198824398192,-0.39619311261379625],[2.3029707444805863,-2.5266644997727905],[-4.277309416206923,-1.5750635784270075],[-0.19673186264193182,0.09205752249436738],[-0.47371333560084017,-1.4557763954202707],[-1.7931695065306243,-0.051243420698008885],[-0.46306693540334665,4.471397759947964],[0,0],[-3.457194684531214,-2.2712363341427158],[-1.125045614493984,1.4990252548970986],[3.3572512634400464,2.216339621757877],[1.5937485352290157,0.8419377148248695],[1.1623014452253067,0.2036661577843191],[1.5756603000580884,-0.18910442549220816]],"o":[[-1.575660957830035,0.189103525063548],[-1.5666190602248868,0.3961958138997767],[-2.3029714022525316,2.5266699023447514],[4.277310073978869,1.5750692061061333],[-0.022059470420327364,0.22736033091041427],[0.4613987125436338,1.6388410260465787],[1.6965543929800657,0.06003165612499801],[0.46168683286619494,-4.480126101776281],[0,0],[3.4571981567371908,2.2712433996159973],[1.1294812861999233,-1.6291541697777967],[-2.7482665278925063,-1.8269851128914718],[-1.5937485352290157,-0.8419368143962095],[-1.1623027607691976,-0.20366075521235819],[0,0]]}],"i":{"x":[0.3045977011494253],"y":[1]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[{"c":true,"v":[[-0.12163358306006374,-7.6039561216618035],[-3.7595921617128036,-7.0884768742864885],[-8.983516790732068,-4.809408072401927],[-11.662231915001282,3.7417529220012864],[-2.1691851409044762,-2.5234313964398662],[-2.448280854024409,1.457225106309906],[0.9496736425083769,7.26468287824231],[3.150546987235079,1.5935371424834013],[1.6798159770862071,-3.0051241776874797],[7.084536205199358,-0.30183696211211786],[12.60264624549683,1.998422163619148],[12.868898878728555,-3.3766258645496015],[8.310359766031736,-6.161053068066133],[3.3060608205467292,-7.422616925092182],[-0.12163358306006374,-7.6039561216618035]],"i":[[0,0],[1.429411843486494,-0.26407464235186584],[2.101271466207065,-1.684097988778166],[-3.9026931844249364,-1.049827313782734],[-1.4932304572108988,0.6987332634274954],[0.1169994853834758,-1.7393469506685884],[-3.1686316828248966,0.28805726791214387],[0.4278619151098582,2.7130305544096207],[0,0],[-1.5678893618611345,-1.2750850752763097],[-3.0582484900924265,1.2389300665728602],[1.006938778301483,1.1742025062550259],[1.4541645087816124,0.5611768449434233],[1.0605045104617736,0.13574962830941423],[1.437660481307618,-0.12604379515725836]],"o":[[-1.437661081470441,0.12604319499443667],[-1.4294110932829667,0.2640764428403308],[-2.1012720663698863,1.6841015897550957],[3.9026937845877585,1.0498310648003697],[-0.16743537452054222,1.7257060768793693],[-0.21046531159590948,3.1288359666371695],[2.435326342210701,-0.22139349249557838],[-0.4383063961272394,-2.779257986963021],[0,0],[1.5678893618611345,1.2750897265381773],[3.0919248263423498,-2.2266220733052875],[-1.0069363776501963,-1.174203256458553],[-1.4541645087816124,-0.5611762447806017],[-1.060505710787417,-0.1357460273324842],[0,0]]}],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[{"c":true,"v":[[-0.12163358306006374,-7.6039561216618035],[-3.7595921617128036,-7.0884768742864885],[-8.983516790732068,-4.809408072401927],[-11.662231915001282,3.7417529220012864],[-2.1691851409044762,-2.5234313964398662],[-2.448280854024409,1.457225106309906],[0.9496736425083769,7.26468287824231],[3.150546987235079,1.5935371424834013],[1.6798159770862071,-3.0051241776874797],[7.084536205199358,-0.30183696211211786],[12.60264624549683,1.998422163619148],[12.868898878728555,-3.3766258645496015],[8.310359766031736,-6.161053068066133],[3.3060608205467292,-7.422616925092182],[-0.12163358306006374,-7.6039561216618035]],"i":[[0,0],[1.429411843486494,-0.26407464235186584],[2.101271466207065,-1.684097988778166],[-3.9026931844249364,-1.049827313782734],[-1.4932304572108988,0.6987332634274954],[0.1169994853834758,-1.7393469506685884],[-3.1686316828248966,0.28805726791214387],[0.4278619151098582,2.7130305544096207],[0,0],[-1.5678893618611345,-1.2750850752763097],[-3.0582484900924265,1.2389300665728602],[1.006938778301483,1.1742025062550259],[1.4541645087816124,0.5611768449434233],[1.0605045104617736,0.13574962830941423],[1.437660481307618,-0.12604379515725836]],"o":[[-1.437661081470441,0.12604319499443667],[-1.4294110932829667,0.2640764428403308],[-2.1012720663698863,1.6841015897550957],[3.9026937845877585,1.0498310648003697],[-0.16743537452054222,1.7257060768793693],[-0.21046531159590948,3.1288359666371695],[2.435326342210701,-0.22139349249557838],[-0.4383063961272394,-2.779257986963021],[0,0],[1.5678893618611345,1.2750897265381773],[3.0919248263423498,-2.2266220733052875],[-1.0069363776501963,-1.174203256458553],[-1.4541645087816124,-0.5611762447806017],[-1.060505710787417,-0.1357460273324842],[0,0]]}],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}}],"ix":2}},{"ty":"tm","s":{"a":0,"k":0,"ix":2},"e":{"a":0,"k":100,"ix":2},"o":{"a":0,"k":0,"ix":2},"m":1},{"ty":"fl","c":{"a":0,"k":[0,0,0],"ix":2},"o":{"a":0,"k":100,"ix":2},"r":1,"bm":0},{"ty":"tr","p":{"a":1,"k":[{"t":5,"s":[28.6790911274013,110.60870855632449],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[28.453871877675958,110.00455873790408],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":30,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":45,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":65,"s":[28.429091604238458,110.3587152320447],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[26.856459768300958,110.77491396251345],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[27.912306936269708,107.65699404063845],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[33.828627737050965,111.76530092540408],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[31.540846975332215,108.63065737071658],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[34.840041311269715,111.76530092540408],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[31.540846975332215,108.59766786876345],"i":{"x":[0.3045977011494253],"y":[1]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[26.832533987050958,110.75358217540408],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[26.832533987050958,110.75358217540408],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}},{"t":490,"s":[26.832533987050958,106.75251257243777],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":1,"k":[{"t":0,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":5,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":25,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[100,100],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[100,100],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[100,100],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[100,100],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[100,100],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}},{"t":490,"s":[0,0],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}}],"ix":2},"r":{"a":1,"k":[{"t":5,"s":[-11.816583487963113],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":80,"s":[-11.816583487963113],"i":{"x":[0.5287356321839081],"y":[1]},"o":{"x":[0.5517241379310345],"y":[0]}},{"t":100,"s":[56],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":113,"s":[60],"i":{"x":[0.29310344827586204],"y":[1]},"o":{"x":[0.45977011494252873],"y":[0]}},{"t":143,"s":[56],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":163,"s":[60],"i":{"x":[0.4885057471264368],"y":[1]},"o":{"x":[0.8735632183908046],"y":[0]}},{"t":183,"s":[47.062325158617654],"i":{"x":[0.3045977011494253],"y":[1]},"o":{"x":[0.25],"y":[0.25]}},{"t":215,"s":[-1.1611326639402932],"i":{"x":[0.75],"y":[0.75]},"o":{"x":[0.25],"y":[0.25]}},{"t":480,"s":[-1.1611326639402932],"i":{"x":[0.3448275862068966],"y":[1]},"o":{"x":[0.6896551724137931],"y":[0]}}],"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}}]}],"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"1","w":50,"h":46,"ind":45,"ty":0,"nm":"左手:0:0:rg-precomp","sr":1,"ks":{"p":{"a":0,"k":[8,86],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":43,"tt":1},{"ddd":0,"ind":46,"ty":3,"nm":"","sr":1,"ks":{"p":{"a":0,"k":[56.83251953125,84.7535400390625],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[125.86326599121094,125.86326599121094],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0},{"ddd":0,"refId":"6","w":91,"h":54,"ind":30,"ty":0,"nm":"MaskedGroup1","sr":1,"ks":{"p":{"a":0,"k":[-46,-36],"ix":2},"a":{"a":0,"k":[0,0],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"parent":46},{"ddd":0,"refId":"7","ind":47,"ty":2,"nm":"Frame316.png","sr":1,"ks":{"p":{"a":0,"k":[62.83251953125,139.7535400390625],"ix":2},"a":{"a":0,"k":[118,33.5],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"hd":true},{"ddd":0,"refId":"8","ind":48,"ty":2,"nm":"Group20.png","sr":1,"ks":{"p":{"a":0,"k":[62.83251953125,-45.2464599609375],"ix":2},"a":{"a":0,"k":[400,61],"ix":2},"s":{"a":0,"k":[100,100],"ix":2},"r":{"a":0,"k":0,"ix":2},"o":{"a":0,"k":100,"ix":2},"sk":{"a":0,"k":0,"ix":2},"sa":{"a":0,"k":0,"ix":2}},"ao":0,"ip":0,"op":501,"st":0,"bm":0,"hd":true}],"markers":[]}'),
                loop: !1,
                autoplay: !1
            };
            var is = function(e) {
                const {
                    style: t
                } = e, a = {
                    pointerEvents: "none",
                    position: "absolute",
                    top: "-107px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    zIndex: 2,
                    width: 120,
                    height: 200,
                    ...t
                }, {
                    View: i,
                    playSegments: s,
                    destroy: A
                } = (0, d.useLottie)(as, a), o = (0, x.useRef)(), r = (0, x.useRef)(), n = (0, x.useRef)(), l = (0, x.useRef)(), c = () => {
                    r.current = setTimeout((() => {
                        s([0, 260], !0), n.current = setTimeout((() => {
                            o && clearInterval(o.current), o.current = setInterval((() => {
                                s([75, 440], !0)
                            }), 3650)
                        }), 2600)
                    }), 200)
                };
                return (0, x.useEffect)((() => (c(), () => {
                    clearInterval(o.current), clearTimeout(r.current), clearTimeout(n.current), clearTimeout(l.current)
                })), []), {
                    MessageLottieView: i,
                    appear: c,
                    disappear: () => {
                        s([480, 500], !0), l.current = setTimeout((() => {
                            A()
                        }), 200)
                    }
                }
            };
            let ss = !1;
            var As, os = function() {
                const e = (0, x.useRef)(null),
                    {
                        MessageLottieView: t
                    } = is({}),
                    a = (0, p.useTranslations)(),
                    [i, A] = (0, x.useState)({
                        offsetX: 0,
                        offsetY: 0,
                        hasTransition: !1
                    }),
                    o = t => {
                        const a = window.innerWidth / 2,
                            i = t.clientX - a;
                        if (e.current && e.current.getBoundingClientRect) {
                            var s;
                            const {
                                top: a
                            } = (null === (s = e.current) || void 0 === s ? void 0 : s.getBoundingClientRect()) || {
                                top: 0
                            };
                            return {
                                offsetX: i,
                                offsetY: t.clientY - a
                            }
                        }
                        return {
                            offsetX: 0,
                            offsetY: 0
                        }
                    },
                    n = () => {
                        A({
                            hasTransition: !0,
                            offsetX: 0,
                            offsetY: 0
                        })
                    };
                return (0, x.useEffect)((() => (window.addEventListener("scroll", n), () => {
                    window.removeEventListener("scroll", n)
                })), []), (0, s.jsx)(r.E.div, {
                    "data-follow-hidden": "true",
                    className: "w-full flex justify-center bg-[#FBFBFB] relative z-10 pb-[60px] pt-[40px]",
                    children: (0, s.jsx)(r.E.div, {
                        initial: {
                            opacity: 0,
                            y: 100
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            duration: .6,
                            ease: "easeInOut"
                        },
                        className: "md:w-[800px] h-[600px] flex justify-center items-center",
                        children: (0, s.jsxs)("div", {
                            className: "flex flex-col relative items-center max-w-[800px]",
                            children: [(0, s.jsx)("div", {
                                className: "text-center",
                                children: (0, s.jsx)("h2", {
                                    className: "font-semibold mb-[20px] tracking-[0.72px] text-[20px] leading-[22px] md:font-bold md:text-[56px] md:leading-[60px]",
                                    children: a("Home_CTA_Title")
                                })
                            }), (0, s.jsx)("div", {
                                onClick: () => {
                                    window.location.href = "https://wegic.ai/app?fromHome=website_cta"
                                },
                                onMouseMove: e => {
                                    ss && setTimeout((() => {
                                        A({
                                            hasTransition: !1,
                                            ...o(e)
                                        })
                                    }), 50)
                                },
                                onMouseLeave: e => {
                                    setTimeout((() => {
                                        A({
                                            hasTransition: !0,
                                            offsetX: 0,
                                            offsetY: 0
                                        })
                                    }), 66)
                                },
                                onMouseEnter: e => {
                                    A({
                                        hasTransition: !0,
                                        ...o(e)
                                    }), ss = !0
                                },
                                className: "w-[500px] z-10 cursor-pointer h-[360px] absolute bottom-[-80px]"
                            }), (0, s.jsx)("div", {
                                ref: e,
                                className: "bg-blue-700 w-[1px] h-[1px] absolute bottom-[100px] left-[50%]"
                            }), (0, s.jsx)(r.E.div, {
                                initial: {
                                    opacity: 0,
                                    y: 50
                                },
                                whileInView: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    duration: .6,
                                    delay: .2,
                                    ease: "easeInOut"
                                },
                                className: "flex group/cta justify-center items-center cursor-pointer w-[400px] h-[200px]",
                                children: (0, s.jsxs)("div", {
                                    style: {
                                        transform: "translate(".concat(.03 * i.offsetX, "px,").concat(.03 * i.offsetY, "px)")
                                    },
                                    className: c()(ts()["home-cta-button"], "bg-black rounded-xl text-[13px] px-5 py-2 font-bold leading-6 text-white md:font-bold md:text-xl md:py-5 md:px-10 md:leading-6", "".concat(i.hasTransition ? "transition-all duration-300" : "")),
                                    children: [t, (0, s.jsx)("div", {
                                        style: {
                                            transform: "translate(".concat(.03 * i.offsetX, "px,").concat(.03 * i.offsetY, "px)")
                                        },
                                        className: "md:text-[28px] tracking-[1.12px] whitespace-nowrap ".concat(i.hasTransition ? "transition-all duration-300" : ""),
                                        children: a("Home_Feature_CTAText")
                                    })]
                                })
                            })]
                        })
                    })
                })
            };

            function rs() {
                return rs = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i])
                    }
                    return e
                }, rs.apply(this, arguments)
            }
            var ns = function(e) {
                    return y.createElement("svg", rs({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 18.566 14.283"
                    }, e), As || (As = y.createElement("path", {
                        fill: "#FFF",
                        d: "M15.727 1.2A15 15 0 0 0 11.893 0c-.175.333-.333.667-.483 1.008a14.5 14.5 0 0 0-4.25 0c-.15-.341-.308-.683-.492-1A15 15 0 0 0 2.835 1.2a15.86 15.86 0 0 0-2.75 10.692 15.3 15.3 0 0 0 4.692 2.391q.574-.774 1-1.65a10 10 0 0 1-1.584-.766c.142-.1.267-.2.392-.309a10.93 10.93 0 0 0 9.4 0l.383.309c-.5.3-1.041.558-1.583.766.292.584.625 1.125 1 1.65a15.6 15.6 0 0 0 4.7-2.391c.392-4.059-.65-7.575-2.75-10.692zM6.202 9.742c-.917 0-1.667-.85-1.667-1.892 0-1.033.733-1.883 1.667-1.883.933 0 1.683.85 1.666 1.883 0 1.042-.741 1.892-1.666 1.892m6.166 0c-.916 0-1.666-.85-1.666-1.892 0-1.033.733-1.883 1.666-1.883.934 0 1.684.85 1.667 1.883 0 1.042-.733 1.892-1.667 1.892"
                    })))
                },
                xs = a(96430);
            const ls = [{
                question: "FAQ_WhatWegic_Question",
                answer: "FAQ_WhatWegic_Answer"
            }, {
                question: "FAQ_UseFree_Question",
                answer: "FAQ_UseFree_Answer",
                blockAnswer: "FAQ_UseFree_BlackAnswer"
            }, {
                question: "FAQ_WhyCreate_Question",
                answer: "FAQ_WhyCreate_Answer"
            }, {
                question: "FAQ_HowCreate_Question",
                answer: "FAQ_HowCreate_Answer"
            }, {
                question: "FAQ_CanCreate_Question",
                answer: "FAQ_CanCreate_Answer"
            }];
            var cs = e => {
                const t = (0, p.useTranslations)(),
                    {
                        isBlock: a
                    } = e,
                    [i, A] = (0, x.useState)(0);
                return (0, s.jsx)("div", {
                    id: "anchor-faq",
                    className: "mx-auto mt-0 sm:mt-[48px] md:mt-0 py-0 md:py-40 xl:max-w-[1160px] md:max-w-[720px] px-6 md:px-0",
                    children: (0, s.jsxs)("div", {
                        className: "flex flex-col xl:flex-row justify-between items-start",
                        children: [(0, s.jsxs)("div", {
                            className: "md:w-[720px] xl:w-[380px] mb-[60px] xl:mr-[60px]",
                            children: [(0, s.jsx)("p", {
                                className: "text-[28px] md:text-[40px] leading-normal font-bold md:mb-4",
                                style: {
                                    color: "#d3d3d3",
                                    fontFamily: "Damion"
                                },
                                children: t("Home_FAQ_Name")
                            }), (0, s.jsx)("h1", {
                                className: "text-[28px] leading-[1.2] md:text-[48px] xl:text-[40px] tracking-[0.72px] font-bold",
                                dangerouslySetInnerHTML: {
                                    __html: t("Home_FAQ_Title")
                                }
                            }), (0, s.jsx)(V.Z, {
                                type: "primary",
                                status: "plain",
                                style: {
                                    padding: "0 1.5rem",
                                    fontWeight: "bold",
                                    marginTop: "30px",
                                    borderRadius: "8px",
                                    background: "#000",
                                    boxShadow: "0px 0px 0px 1px #000, 0px 1px 1px 0px rgba(0, 0, 0, 0.20), 0px 1px 0px 0px rgba(255, 255, 255, 0.20) inset, 0px -1px 1px 0px rgba(255, 255, 255, 0.20) inset, 0px 1px 4px 1px rgba(255, 255, 255, 0.20) inset, 0px -2px 1px 1px rgba(255, 255, 255, 0.20) inset, 0px 20px 20px 0px rgba(0, 0, 0, 0.04) inset"
                                },
                                onClick: () => {
                                    window.open("https://discord.com/invite/ZVUReEz9T3", "_blank")
                                },
                                children: (0, s.jsxs)("div", {
                                    className: "flex gap-[10px] items-center text-[#FBFBFB] text-[13px] font-bold leading-6",
                                    children: [(0, s.jsx)(ns, {
                                        style: {
                                            width: 16,
                                            height: 16,
                                            fontSize: 16
                                        }
                                    }), (0, s.jsx)("span", {
                                        children: t("Home_FAQ_ButtonText")
                                    })]
                                })
                            })]
                        }), (0, s.jsx)("div", {
                            className: "flex-1 w-full xl:mt-[68px] md:px-[10px]",
                            children: ls.map(((e, o) => (0, s.jsxs)("div", {
                                children: [0 !== o && (0, s.jsx)(et.Z, {}), (0, s.jsxs)("div", {
                                    onClick: () => (e => {
                                        A(e === i ? -1 : e)
                                    })(o),
                                    className: "group flex w-full h-16 items-center justify-between text-left focus:outline-none space-x-5 md:space-x-10 ".concat(i === o ? "text-black" : "text-gray-600"),
                                    children: [(0, s.jsx)("span", {
                                        className: "text-[15px] md:text-[20px] font-normal leading-normal group-hover:text-black",
                                        children: t(e.question)
                                    }), (0, s.jsx)("span", {
                                        className: "flex items-start justify-center w-6 h-6 duration-200 ease-in-out ".concat(i === o ? "opacity-100" : "opacity-60 rotate-[-180deg]", " group-hover:opacity-100 group-hover:text-black"),
                                        children: (0, s.jsx)(xs.Z, {
                                            className: "w-4 h-4 md:w-6 md:h-6"
                                        })
                                    })]
                                }), (0, s.jsx)("div", {
                                    className: "text-[14px] md:text-[16px] text-black-60 leading-[22px] md:leading-6 font-normal overflow-hidden transition-all duration-300 ease-in-out ".concat(i === o ? "max-h-96 opacity-100" : "max-h-0 opacity-0"),
                                    style: {
                                        color: "rgba(0, 0, 0, 0.40)"
                                    },
                                    children: (() => {
                                        const i = a && e.blockAnswer ? e.blockAnswer : e.answer;
                                        return Array.isArray(i) ? i.map(((e, a) => (0, s.jsx)("p", {
                                            className: a === i.length - 1 ? "py-2 pb-10" : "py-2",
                                            children: t(e)
                                        }, a))) : (0, s.jsx)("p", {
                                            className: "pb-10 text-[15px]",
                                            children: t(i)
                                        })
                                    })()
                                })]
                            }, o)))
                        })]
                    })
                })
            };

            function ds() {
                const [e, t] = (0, x.useState)((0, v.W7)()), a = (0, x.useRef)(null), i = (0, x.useRef)(null), l = window.innerWidth, {
                    scrollYProgress: c
                } = (0, A.v)({
                    target: a,
                    offset: ["start end", "end start"]
                }), {
                    scrollYProgress: d
                } = (0, A.v)({
                    target: i,
                    offset: ["start end", "end start"]
                }), k = (0, bi.t)();
                (0, x.useEffect)((() => {
                    (0, Gt.GX)("page_view_wegicai", {
                        source: (0, wi.b5)() || (0, wi.oZ)(),
                        plan: (0, vi.Wh)() || (0, vi.PP)(),
                        object: "home_page"
                    })
                }), []), (0, x.useEffect)((() => {
                    const e = (0, n.Z)((() => {
                        t((0, v.W7)())
                    }), 300);
                    return window.addEventListener("resize", e), () => {
                        window.removeEventListener("resize", e), e.cancel()
                    }
                }), []);
                const g = (0, o.H)(c, [0, .27, .29], ["#000000", "#000000", "#FBFBFB"]),
                    p = (0, o.H)(c, [0, .25, .35], ["#000000", "#000000", "#FBFBFB"]);
                return (0, s.jsxs)("main", {
                    className: "w-full flex min-h-screen flex-col cursor-default select-none",
                    id: "dialog-container",
                    ref: i,
                    children: [(0, s.jsx)(se.Z, {
                        scrollYProgress: d
                    }), (0, s.jsx)("div", {
                        id: "anchor-hero",
                        className: "sticky top-0 z-0 overflow-hidden",
                        children: (0, s.jsx)(Ca, {})
                    }), (0, s.jsxs)(r.E.div, {
                        ref: a,
                        className: "z-10 ",
                        style: {
                            backgroundColor: e ? p : g
                        },
                        transition: {
                            duration: .4
                        },
                        children: [(0, s.jsx)(te, {}), e ? (0, s.jsx)(Bi, {
                            scrollRef: a
                        }) : (0, s.jsx)(fi, {
                            scrollYProgress: c,
                            scrollRef: a
                        })]
                    }), e ? void 0 : (0, s.jsx)(os, {}), e || l <= 768 ? (0, s.jsx)($i, {}) : (0, s.jsx)(Fe, {}), (0, s.jsx)(_i, {}), (0, s.jsx)("div", {
                        className: "w-full bg-[#FBFBFB] z-10",
                        "data-follow-hidden": !0,
                        children: (0, s.jsx)(cs, {
                            isBlock: k
                        })
                    }), (0, s.jsx)("div", {
                        className: "z-10 bg-[#FBFBFB] overflow-hidden pt-10 md:pt-3",
                        children: (0, s.jsx)(ie.Z, {})
                    }), !e && (0, s.jsx)(rt, {}), (0, s.jsx)(Da, {})]
                })
            }
        },
        23556: function(e, t, a) {
            "use strict";
            a.d(t, {
                default: function() {
                    return A
                }
            });
            var i = a(75467),
                s = a(18562);

            function A(e) {
                let {
                    i18nKey: t,
                    raw: a = !1
                } = e;
                const A = (0, s.useTranslations)();
                return a ? (0, i.jsx)("span", {
                    dangerouslySetInnerHTML: {
                        __html: A.raw(t)
                    }
                }) : (0, i.jsx)(i.Fragment, {
                    children: A(t)
                })
            }
        },
        94167: function(e, t, a) {
            "use strict";
            a.d(t, {
                PP: function() {
                    return r
                },
                Wh: function() {
                    return o
                },
                ef: function() {
                    return A
                }
            });
            var i = a(6139),
                s = a(72241);

            function A(e) {
                const t = i.Z.parse(location.search),
                    a = t.plan ? "string" == typeof t.plan ? t.plan : JSON.stringify(t.plan) : "";
                (e || a) && sessionStorage.setItem(s.k7, e || a)
            }

            function o() {
                var e;
                return null !== (e = sessionStorage.getItem(s.k7)) && void 0 !== e ? e : ""
            }

            function r() {
                const e = i.Z.parse(location.search);
                return e.plan ? "string" == typeof e.plan ? e.plan : JSON.stringify(e.plan) : ""
            }
        },
        28935: function(e, t, a) {
            "use strict";
            a.d(t, {
                Pn: function() {
                    return x
                },
                b5: function() {
                    return o
                },
                m3: function() {
                    return r
                },
                oZ: function() {
                    return n
                },
                rY: function() {
                    return A
                }
            });
            var i = a(6139),
                s = a(72241);

            function A(e) {
                const t = i.Z.parse(location.search),
                    a = t.source ? "string" == typeof t.source ? t.source : JSON.stringify(t.source) : "";
                (e || a) && sessionStorage.setItem(s.Pt, e || a)
            }

            function o() {
                var e;
                return null !== (e = sessionStorage.getItem(s.Pt)) && void 0 !== e ? e : ""
            }

            function r() {
                const e = i.Z.parse(location.search);
                return e.event_source ? "string" == typeof e.event_source ? e.event_source : JSON.stringify(e.event_source) : ""
            }

            function n() {
                const e = i.Z.parse(location.search);
                return e.source ? "string" == typeof e.source ? e.source : JSON.stringify(e.source) : ""
            }
            const x = e => {
                const t = sessionStorage.getItem(s.Pt);
                if (t) return t;
                const a = document.referrer;
                let i = "";
                if (a) try {
                    const t = new URL(a).hostname;
                    for (const [a, s] of Object.entries(e))
                        if (s.some((e => t.includes(e)))) {
                            i = a;
                            break
                        }
                } catch (e) {}
                return A(i), i
            }
        },
        12466: function(e, t, a) {
            "use strict";
            a.d(t, {
                t: function() {
                    return o
                }
            });
            var i = a(84371),
                s = a(13561),
                A = a(761);

            function o() {
                const e = (0, A.L)((e => e.countryBlock)),
                    t = (0, A.L)((e => e.isLogin)),
                    [a, o] = (0, i.useState)(!1);
                return (0, i.useEffect)((() => {
                    t ? o(e) : (0, s.rz)({
                        isServer: !0
                    }).then((e => {
                        e.data && o(e.data.freeRightBlock)
                    }))
                }), [e, t]), a
            }
        },
        13122: function(e, t, a) {
            "use strict";
            a.d(t, {
                cn: function() {
                    return A
                }
            });
            var i = a(57782),
                s = a(11435);

            function A() {
                for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
                return (0, s.m6)((0, i.W)(t))
            }
        },
        71393: function(e) {
            e.exports = {
                "video-wrap": "AboutMeSection_video-wrap__HkdmZ",
                play: "AboutMeSection_play__D8vER"
            }
        },
        70764: function(e) {
            e.exports = {
                "example-item": "ChatExample_example-item__ebGbi"
            }
        },
        43248: function(e) {
            e.exports = {
                "promotional-video": "PromotionalVideo_promotional-video__KTy9R",
                "volume-btn": "PromotionalVideo_volume-btn__rpzu3",
                "close-btn": "PromotionalVideo_close-btn__J155g"
            }
        },
        8968: function(e) {
            e.exports = {
                "radio-tab": "RadioTab_radio-tab__rBQan",
                "radio-tab-content": "RadioTab_radio-tab-content__QFpaJ",
                "radio-tab-content--scrollable": "RadioTab_radio-tab-content--scrollable__TwuLb",
                "radio-tab--disabled": "RadioTab_radio-tab--disabled__OpwHs",
                "radio-tab--active": "RadioTab_radio-tab--active__iHqG0",
                "radio-tab--noActive": "RadioTab_radio-tab--noActive__QgzGN"
            }
        },
        71180: function(e) {
            e.exports = {
                "radio-tabs-box": "tabs_radio-tabs-box__oJPhV",
                "radio-tabs-box-scrollable": "tabs_radio-tabs-box-scrollable__czAdN",
                "radio-tabs-wrapper": "tabs_radio-tabs-wrapper__e7s_0",
                "radio-tabs": "tabs_radio-tabs___F56c",
                "radio-tabs-scrollable": "tabs_radio-tabs-scrollable__oFrT3",
                "slider-container": "tabs_slider-container__qxPjY",
                slider: "tabs_slider__QdMPj",
                transition: "tabs_transition__qwrFM",
                scrollable: "tabs_scrollable__Xvqo6",
                plain: "tabs_plain__KqRIo",
                "scroll-controls": "tabs_scroll-controls__V8gzd",
                "scroll-controls-buttons": "tabs_scroll-controls-buttons__9YKPb",
                "icon-button": "tabs_icon-button__x4D96",
                disabled: "tabs_disabled__SSDLz",
                "mobile-right-shadow": "tabs_mobile-right-shadow__qgrDU"
            }
        },
        45896: function(e) {
            e.exports = {
                wrapper: "TiltedCard_wrapper__PsLIW"
            }
        },
        21242: function(e) {
            e.exports = {
                "feature-card": "Feature_feature-card__Fwo7i",
                "feature-card-mobile": "Feature_feature-card-mobile__K_iHa",
                button_cta: "Feature_button_cta___n7AP"
            }
        },
        90496: function(e) {
            e.exports = {
                "no-scrollbar": "HelloCard_no-scrollbar__sgR1w",
                "submit-button-disabled": "HelloCard_submit-button-disabled__RC9rJ",
                "submit-button": "HelloCard_submit-button__77cuT"
            }
        },
        39698: function(e) {
            e.exports = {
                flash: "HeroSection_flash__QTPpn",
                "month-logo": "HeroSection_month-logo__3IMYS"
            }
        },
        50564: function(e) {
            e.exports = {
                "home-cta-button": "HomeCTA_home-cta-button__2HTN4"
            }
        },
        15390: function(e) {
            e.exports = {
                "no-scrollbar": "CaseCardTrigger_no-scrollbar__455QW"
            }
        },
        11590: function(e) {
            e.exports = {
                "no-scrollbar": "WorkListSection_no-scrollbar__kSCXJ"
            }
        },
        36701: function(e) {
            e.exports = {
                "testimonial-card": "TestimonialCard_testimonial-card__rbuBN",
                name: "TestimonialCard_name__PkWFg",
                content: "TestimonialCard_content__z688u",
                icon: "TestimonialCard_icon__vCXIY",
                "type-twitter": "TestimonialCard_type-twitter__LFv_K",
                "type-discord": "TestimonialCard_type-discord__u59R8"
            }
        },
        45657: function(e) {
            e.exports = {
                testimonial: "Testimonials_testimonial__r9ALZ",
                subtitle: "Testimonials_subtitle__xrkc_",
                more: "Testimonials_more__q52Fy"
            }
        },
        39881: function(e) {
            e.exports = {
                "custom-tool-tip": "ToolTip_custom-tool-tip__cnBAK"
            }
        }
    },
    function(e) {
        e.O(0, [5757, 7493, 9819, 5089, 7983, 5537, 8767, 8677, 8339, 3223, 5880, 9589, 711, 5298, 9775, 8741, 8193, 1744], (function() {
            return t = 97788, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);