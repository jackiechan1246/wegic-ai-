! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "a162afb6-a199-45c9-b166-b83f5cf82d89", e._sentryDebugIdIdentifier = "sentry-dbid-a162afb6-a199-45c9-b166-b83f5cf82d89")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8432], {
        69868: function(e, t, n) {
            Promise.resolve().then(n.bind(n, 13973)), Promise.resolve().then(n.bind(n, 85671)), Promise.resolve().then(n.bind(n, 81767)), Promise.resolve().then(n.bind(n, 14691)), Promise.resolve().then(n.bind(n, 61453)), Promise.resolve().then(n.bind(n, 99509))
        },
        72402: function(e, t, n) {
            "use strict";

            function r(e, t) {
                var n = t && t.cache ? t.cache : l,
                    r = t && t.serializer ? t.serializer : a;
                return (t && t.strategy ? t.strategy : c)(e, {
                    cache: n,
                    serializer: r
                })
            }

            function o(e, t, n, r) {
                var o, i = null == (o = r) || "number" == typeof o || "boolean" == typeof o ? r : n(r),
                    s = t.get(i);
                return void 0 === s && (s = e.call(this, r), t.set(i, s)), s
            }

            function i(e, t, n) {
                var r = Array.prototype.slice.call(arguments, 3),
                    o = n(r),
                    i = t.get(o);
                return void 0 === i && (i = e.apply(this, r), t.set(o, i)), i
            }

            function s(e, t, n, r, o) {
                return n.bind(t, e, r, o)
            }

            function c(e, t) {
                return s(e, this, 1 === e.length ? o : i, t.cache.create(), t.serializer)
            }
            n.r(t), n.d(t, {
                memoize: function() {
                    return r
                },
                strategies: function() {
                    return f
                }
            });
            var a = function() {
                return JSON.stringify(arguments)
            };

            function u() {
                this.cache = Object.create(null)
            }
            u.prototype.get = function(e) {
                return this.cache[e]
            }, u.prototype.set = function(e, t) {
                this.cache[e] = t
            };
            var l = {
                    create: function() {
                        return new u
                    }
                },
                f = {
                    variadic: function(e, t) {
                        return s(e, this, i, t.cache.create(), t.serializer)
                    },
                    monadic: function(e, t) {
                        return s(e, this, o, t.cache.create(), t.serializer)
                    }
                }
        },
        92692: function(e, t, n) {
            "use strict";

            function r() {
                return r = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, r.apply(null, arguments)
            }
            n.d(t, {
                g: function() {
                    return r
                }
            })
        },
        13973: function(e, t, n) {
            "use strict";
            n.d(t, {
                default: function() {
                    return l
                }
            });
            var r = n(92692),
                o = n(16924),
                i = n(46055),
                s = n(84371),
                c = n(40027);

            function a(e, t, n, r) {
                if (!e || r === n || null == r || !t) return;
                const o = function(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : window.location.pathname;
                        return "/" === e ? t : t.replace(e, "")
                    }(t),
                    i = "" !== o ? o : "/",
                    {
                        name: s,
                        ...c
                    } = e;
                c.path || (c.path = i);
                let a = "".concat(s, "=").concat(r, ";");
                for (const [e, t] of Object.entries(c)) a += "".concat("maxAge" === e ? "max-age" : e), "boolean" != typeof t && (a += "=" + t), a += ";";
                document.cookie = a
            }

            function u(e, t) {
                let {
                    defaultLocale: n,
                    href: u,
                    locale: l,
                    localeCookie: f,
                    onClick: p,
                    prefetch: d,
                    unprefixed: g,
                    ...m
                } = e;
                const y = (0, c.Z)(),
                    h = null != l && l !== y,
                    b = l || y,
                    v = function() {
                        const [e, t] = (0, s.useState)();
                        return (0, s.useEffect)((() => {
                            t(window.location.host)
                        }), []), e
                    }(),
                    _ = v && g && (g.domains[v] === b || !Object.keys(g.domains).includes(v) && y === n && !l) ? g.pathname : u,
                    w = (0, i.usePathname)();
                return h && (d = !1), s.createElement(o.default, (0, r.g)({
                    ref: t,
                    href: _,
                    hrefLang: h ? l : void 0,
                    onClick: function(e) {
                        a(f, w, y, l), p && p(e)
                    },
                    prefetch: d
                }, m))
            }
            var l = (0, s.forwardRef)(u)
        },
        85671: function(e, t, n) {
            "use strict";
            n.d(t, {
                default: function() {
                    return p
                }
            });
            var r = n(92692),
                o = n(46055),
                i = n(84371),
                s = n(40027);
            n(92869);

            function c(e) {
                return function(e) {
                    return "object" == typeof e ? null == e.host && null == e.hostname : !/^[a-z]+:/i.test(e)
                }(e) && ! function(e) {
                    const t = "object" == typeof e ? e.pathname : e;
                    return null != t && !t.startsWith("/")
                }(e)
            }

            function a(e, t) {
                let n;
                return "string" == typeof e ? n = u(t, e) : (n = { ...e
                }, e.pathname && (n.pathname = u(t, e.pathname))), n
            }

            function u(e, t) {
                let n = e;
                return /^\/(\?.*)?$/.test(t) && (t = t.slice(1)), n += t, n
            }
            var l = n(13973);

            function f(e, t) {
                let {
                    href: n,
                    locale: u,
                    localeCookie: f,
                    localePrefixMode: p,
                    prefix: d,
                    ...g
                } = e;
                const m = (0, o.usePathname)(),
                    y = (0, s.Z)(),
                    h = u !== y,
                    [b, v] = (0, i.useState)((() => c(n) && ("never" !== p || h) ? a(n, d) : n));
                return (0, i.useEffect)((() => {
                    m && v(function(e, t) {
                        let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : t,
                            r = arguments.length > 3 ? arguments[3] : void 0,
                            o = arguments.length > 4 ? arguments[4] : void 0;
                        if (!c(e)) return e;
                        const i = t !== n,
                            s = function(e, t) {
                                return t === e || t.startsWith("".concat(e, "/"))
                            }(o, r);
                        return (i || s) && null != o ? a(e, o) : e
                    }(n, u, y, m, d))
                }), [y, n, u, m, d]), i.createElement(l.default, (0, r.g)({
                    ref: t,
                    href: b,
                    locale: u,
                    localeCookie: f
                }, g))
            }
            const p = (0, i.forwardRef)(f);
            p.displayName = "ClientLink"
        },
        40027: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return s
                }
            });
            var r = n(46055),
                o = n(15217);
            const i = "locale";

            function s() {
                const e = (0, r.useParams)();
                let t;
                try {
                    t = (0, o.useLocale)()
                } catch (n) {
                    if ("string" != typeof(null == e ? void 0 : e[i])) throw n;
                    t = e[i]
                }
                return t
            }
        },
        81767: function(e, t, n) {
            "use strict";
            n.d(t, {
                default: function() {
                    return s
                }
            });
            var r = n(92692),
                o = n(84371),
                i = n(22667);

            function s(e) {
                let {
                    locale: t,
                    ...n
                } = e;
                if (!t) throw new Error("Failed to determine locale in `NextIntlClientProvider`, please provide the `locale` prop explicitly.\n\nSee https://next-intl-docs.vercel.app/docs/configuration#locale");
                return o.createElement(i.IntlProvider, (0, r.g)({
                    locale: t
                }, n))
            }
        },
        14691: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "BailoutToCSR", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            const r = n(9964);

            function o(e) {
                let {
                    reason: t,
                    children: n
                } = e;
                if ("undefined" == typeof window) throw new r.BailoutToCSRError(t);
                return n
            }
        },
        61453: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "PreloadCss", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            const r = n(75467);

            function o(e) {
                let {
                    moduleIds: t
                } = e;
                if ("undefined" != typeof window) return null;
                const {
                    getExpectedRequestStore: o
                } = n(36289), i = o(), s = [];
                if (i.reactLoadableManifest && t) {
                    const e = i.reactLoadableManifest;
                    for (const n of t) {
                        if (!e[n]) continue;
                        const t = e[n].files.filter((e => e.endsWith(".css")));
                        s.push(...t)
                    }
                }
                return 0 === s.length ? null : (0, r.jsx)(r.Fragment, {
                    children: s.map((e => (0, r.jsx)("link", {
                        precedence: "dynamic",
                        rel: "stylesheet",
                        href: i.assetPrefix + "/_next/" + encodeURI(e),
                        as: "style"
                    }, e)))
                })
            }
        },
        22667: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(84371),
                o = n(64145),
                i = n(21567);
            n(72402);
            var s = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }(r);
            t.IntlProvider = function(e) {
                let {
                    children: t,
                    defaultTranslationValues: n,
                    formats: c,
                    getMessageFallback: a,
                    locale: u,
                    messages: l,
                    now: f,
                    onError: p,
                    timeZone: d
                } = e;
                const g = r.useMemo((() => o.createCache()), [u]),
                    m = r.useMemo((() => o.createIntlFormatters(g)), [g]),
                    y = r.useMemo((() => ({ ...o.initializeConfig({
                            locale: u,
                            defaultTranslationValues: n,
                            formats: c,
                            getMessageFallback: a,
                            messages: l,
                            now: f,
                            onError: p,
                            timeZone: d
                        }),
                        formatters: m,
                        cache: g
                    })), [g, n, c, m, a, u, l, f, p, d]);
                return s.default.createElement(i.IntlContext.Provider, {
                    value: y
                }, t)
            }
        },
        64145: function(e, t, n) {
            "use strict";
            var r = n(72402);

            function o() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return t.filter(Boolean).join(".")
            }

            function i(e) {
                return o(e.namespace, e.key)
            }

            function s(e) {}

            function c(e, t) {
                return r.memoize(e, {
                    cache: (n = t, {
                        create: () => ({
                            get: e => n[e],
                            set(e, t) {
                                n[e] = t
                            }
                        })
                    }),
                    strategy: r.strategies.variadic
                });
                var n
            }

            function a(e, t) {
                return c((function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    return new e(...n)
                }), t)
            }
            t.createCache = function() {
                return {
                    dateTime: {},
                    number: {},
                    message: {},
                    relativeTime: {},
                    pluralRules: {},
                    list: {},
                    displayNames: {}
                }
            }, t.createIntlFormatters = function(e) {
                return {
                    getDateTimeFormat: a(Intl.DateTimeFormat, e.dateTime),
                    getNumberFormat: a(Intl.NumberFormat, e.number),
                    getPluralRules: a(Intl.PluralRules, e.pluralRules),
                    getRelativeTimeFormat: a(Intl.RelativeTimeFormat, e.relativeTime),
                    getListFormat: a(Intl.ListFormat, e.list),
                    getDisplayNames: a(Intl.DisplayNames, e.displayNames)
                }
            }, t.defaultGetMessageFallback = i, t.defaultOnError = s, t.initializeConfig = function(e) {
                let {
                    getMessageFallback: t,
                    messages: n,
                    onError: r,
                    ...o
                } = e;
                return { ...o,
                    messages: n,
                    onError: r || s,
                    getMessageFallback: t || i
                }
            }, t.joinPath = o, t.memoFn = c
        },
        99509: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return u
                }
            });
            var r = n(75467),
                o = n(54503),
                i = n(46055),
                s = n(83847),
                c = n(38960),
                a = n(761);

            function u(e) {
                let {
                    lang: t
                } = e;
                const n = (0, i.usePathname)();
                return (0, r.jsx)(l, {
                    currentLanguage: t
                }, n)
            }

            function l(e) {
                let {
                    currentLanguage: t
                } = e;
                const n = (0, a.L)((e => e.notLogin)),
                    {
                        setUserInfo: i
                    } = a.L.getState();
                return (0, r.jsx)(o.L, {
                    currentLanguage: t,
                    isLogin: !n,
                    clientId: s.wL,
                    afterGoogleLoginSuccess: e => {
                        i(e), (0, c.By)()
                    },
                    afterFirstGoogleRegister: e => {
                        var t, n;
                        null === (t = (n = window).gtag) || void 0 === t || t.call(n, "event", "conversion", {
                            send_to: "AW-16682805170/Rpg7CJLptM0ZELLP_ZI-"
                        }), i(e), (0, c.WU)()
                    }
                })
            }
        },
        38960: function(e, t, n) {
            "use strict";
            n.d(t, {
                A$: function() {
                    return c
                },
                By: function() {
                    return a
                },
                WU: function() {
                    return u
                },
                jb: function() {
                    return s
                },
                s5: function() {
                    return l
                }
            });
            var r = n(11338),
                o = n(94167),
                i = n(28935);

            function s() {
                (0, r.GX)("user_login", {
                    login_type: "email"
                }), window.open("/workspace", "_blank")
            }

            function c() {
                (0, r.GX)("user_signup", {
                    signup_type: "email",
                    signup_source: (0, i.b5)(),
                    signup_plan: (0, o.Wh)()
                }), (0, r.GX)("user_login", {
                    login_type: "email"
                }), window.open("/workspace", "_blank")
            }

            function a() {
                (0, r.GX)("user_login", {
                    login_type: "google"
                }), window.open("/workspace", "_blank")
            }

            function u() {
                (0, r.GX)("user_signup", {
                    signup_type: "google",
                    signup_source: (0, i.b5)(),
                    signup_plan: (0, o.Wh)()
                }), window.open("/workspace", "_blank")
            }

            function l() {
                (0, r.GX)("user_login", {
                    login_type: "email"
                }), window.open("/workspace", "_blank")
            }
        },
        72241: function(e, t, n) {
            "use strict";
            n.d(t, {
                B9: function() {
                    return r
                },
                Lc: function() {
                    return s
                },
                Pt: function() {
                    return o
                },
                k7: function() {
                    return i
                }
            });
            const r = {
                    page_view_wegicai: "basic_functions",
                    home_endofpage_dialogbox: "basic_functions",
                    bounce_location: "basic_functions",
                    blog_banner_button_click: "basic_functions",
                    ph_infusion_click: "basic_functions",
                    user_login: "basic_functions",
                    user_signup: "basic_functions",
                    sem_lp_button_click: "basic_functions",
                    button_click: "basic_functions",
                    wegic_signup: "wegic_official",
                    wegic_build: "wegic_official",
                    sem_lp: "ai_abtest",
                    official_click: "basic_functions",
                    user_case_click: "basic_functions",
                    send_message: "ai_messages"
                },
                o = "source",
                i = "plan",
                s = "code"
        },
        11338: function(e, t, n) {
            "use strict";
            n.d(t, {
                GX: function() {
                    return p
                },
                T3: function() {
                    return f
                },
                ps: function() {
                    return l
                }
            });
            var r = n(94875),
                o = n(61213),
                i = n(83847),
                s = n(761),
                c = n(72241);
            let a = !1;
            const u = [];
            async function l() {
                r.ZP.init({
                    actionToThemeMap: c.B9,
                    businessType: "wegic",
                    userId: "",
                    isOnline: i.Gg,
                    serverUrl: i.YR
                })
            }
            async function f() {
                for (a = !0; u.length > 0;) {
                    const e = u.shift();
                    (null == e ? void 0 : e.length) && p(e[0], e[1])
                }
            }
            async function p(e, t) {
                var n;
                if (!a) return void u.push([e, t]);
                const c = {
                        firstEnterUrl: (0, o.g)(),
                        referrerUrl: (0, o.y)(),
                        version: i.D0 || null === (n = window.scm) || void 0 === n ? void 0 : n.gitHash,
                        ...t
                    },
                    {
                        userId: l
                    } = s.L.getState();
                r.ZP.setConfig("userId", l || ""), (0, r.KM)(e, c)
            }
        },
        94167: function(e, t, n) {
            "use strict";
            n.d(t, {
                PP: function() {
                    return c
                },
                Wh: function() {
                    return s
                },
                ef: function() {
                    return i
                }
            });
            var r = n(6139),
                o = n(72241);

            function i(e) {
                const t = r.Z.parse(location.search),
                    n = t.plan ? "string" == typeof t.plan ? t.plan : JSON.stringify(t.plan) : "";
                (e || n) && sessionStorage.setItem(o.k7, e || n)
            }

            function s() {
                var e;
                return null !== (e = sessionStorage.getItem(o.k7)) && void 0 !== e ? e : ""
            }

            function c() {
                const e = r.Z.parse(location.search);
                return e.plan ? "string" == typeof e.plan ? e.plan : JSON.stringify(e.plan) : ""
            }
        },
        28935: function(e, t, n) {
            "use strict";
            n.d(t, {
                Pn: function() {
                    return u
                },
                b5: function() {
                    return s
                },
                m3: function() {
                    return c
                },
                oZ: function() {
                    return a
                },
                rY: function() {
                    return i
                }
            });
            var r = n(6139),
                o = n(72241);

            function i(e) {
                const t = r.Z.parse(location.search),
                    n = t.source ? "string" == typeof t.source ? t.source : JSON.stringify(t.source) : "";
                (e || n) && sessionStorage.setItem(o.Pt, e || n)
            }

            function s() {
                var e;
                return null !== (e = sessionStorage.getItem(o.Pt)) && void 0 !== e ? e : ""
            }

            function c() {
                const e = r.Z.parse(location.search);
                return e.event_source ? "string" == typeof e.event_source ? e.event_source : JSON.stringify(e.event_source) : ""
            }

            function a() {
                const e = r.Z.parse(location.search);
                return e.source ? "string" == typeof e.source ? e.source : JSON.stringify(e.source) : ""
            }
            const u = e => {
                const t = sessionStorage.getItem(o.Pt);
                if (t) return t;
                const n = document.referrer;
                let r = "";
                if (n) try {
                    const t = new URL(n).hostname;
                    for (const [n, o] of Object.entries(e))
                        if (o.some((e => t.includes(e)))) {
                            r = n;
                            break
                        }
                } catch (e) {}
                return i(r), r
            }
        },
        761: function(e, t, n) {
            "use strict";
            n.d(t, {
                L: function() {
                    return i
                }
            });
            var r = n(1435);
            const o = {
                    notLogin: !1,
                    isLogin: !1,
                    email: "",
                    password: "",
                    unionId: "",
                    userId: "",
                    userImage: "",
                    userName: "",
                    inviteCode: "",
                    countryBlock: !1,
                    freeRightBlock: !1,
                    isRenew: !1,
                    discount: 1.2,
                    isSupportRefund: !1
                },
                i = (0, r.Ue)(((e, t) => ({ ...o,
                    setIsLogin(t) {
                        e({
                            isLogin: t
                        })
                    },
                    setNotLogin(t) {
                        e({
                            notLogin: t
                        })
                    },
                    setUserInfo(n) {
                        const {
                            setIsLogin: r,
                            setNotLogin: o
                        } = t();
                        e(n), n.userId && (r(!0), o(!1), e({
                            password: ""
                        }))
                    },
                    getUserInfo() {
                        const {
                            email: e,
                            unionId: n,
                            userId: r,
                            userImage: o,
                            userName: i,
                            inviteCode: s,
                            countryBlock: c,
                            freeRightBlock: a
                        } = t();
                        return {
                            email: e,
                            unionId: n,
                            userId: r,
                            userImage: o,
                            userName: i,
                            inviteCode: s,
                            countryBlock: c,
                            freeRightBlock: a
                        }
                    },
                    userSubscription: void 0,
                    setUserSubscription(t) {
                        e({
                            userSubscription: t
                        })
                    },
                    setIsRenew(t) {
                        e({
                            isRenew: t
                        })
                    },
                    isUnlimitedUser: !1,
                    setIsUnlimitedUser(t) {
                        e({
                            isUnlimitedUser: t
                        })
                    },
                    duration: {
                        updateTime: Date.now(),
                        leftTime: 864e5
                    },
                    setDuration: t => {
                        e({
                            duration: {
                                updateTime: Date.now(),
                                leftTime: t
                            }
                        })
                    },
                    setIsSupportRefund(t) {
                        e({
                            isSupportRefund: t
                        })
                    }
                })))
        },
        6139: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return P
                }
            });
            var r = {};
            n.r(r), n.d(r, {
                exclude: function() {
                    return O
                },
                extract: function() {
                    return w
                },
                parse: function() {
                    return k
                },
                parseUrl: function() {
                    return j
                },
                pick: function() {
                    return S
                },
                stringify: function() {
                    return I
                },
                stringifyUrl: function() {
                    return F
                }
            });
            const o = "%[a-f0-9]{2}",
                i = new RegExp("(" + o + ")|([^%]+?)", "gi"),
                s = new RegExp("(" + o + ")+", "gi");

            function c(e, t) {
                try {
                    return [decodeURIComponent(e.join(""))]
                } catch {}
                if (1 === e.length) return e;
                t = t || 1;
                const n = e.slice(0, t),
                    r = e.slice(t);
                return Array.prototype.concat.call([], c(n), c(r))
            }

            function a(e) {
                try {
                    return decodeURIComponent(e)
                } catch {
                    let t = e.match(i) || [];
                    for (let n = 1; n < t.length; n++) t = (e = c(t, n).join("")).match(i) || [];
                    return e
                }
            }

            function u(e) {
                if ("string" != typeof e) throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof e + "`");
                try {
                    return decodeURIComponent(e)
                } catch {
                    return function(e) {
                        const t = {
                            "%FE%FF": "��",
                            "%FF%FE": "��"
                        };
                        let n = s.exec(e);
                        for (; n;) {
                            try {
                                t[n[0]] = decodeURIComponent(n[0])
                            } catch {
                                const e = a(n[0]);
                                e !== n[0] && (t[n[0]] = e)
                            }
                            n = s.exec(e)
                        }
                        t["%C2"] = "�";
                        const r = Object.keys(t);
                        for (const n of r) e = e.replace(new RegExp(n, "g"), t[n]);
                        return e
                    }(e)
                }
            }

            function l(e, t) {
                if ("string" != typeof e || "string" != typeof t) throw new TypeError("Expected the arguments to be of type `string`");
                if ("" === e || "" === t) return [];
                const n = e.indexOf(t);
                return -1 === n ? [] : [e.slice(0, n), e.slice(n + t.length)]
            }

            function f(e, t) {
                const n = {};
                if (Array.isArray(t))
                    for (const r of t) {
                        const t = Object.getOwnPropertyDescriptor(e, r);
                        t ? .enumerable && Object.defineProperty(n, r, t)
                    } else
                        for (const r of Reflect.ownKeys(e)) {
                            const o = Object.getOwnPropertyDescriptor(e, r);
                            if (o.enumerable) {
                                t(r, e[r], e) && Object.defineProperty(n, r, o)
                            }
                        }
                return n
            }
            const p = e => null == e,
                d = e => encodeURIComponent(e).replaceAll(/[!'()*]/g, (e => `%${e.charCodeAt(0).toString(16).toUpperCase()}`)),
                g = Symbol("encodeFragmentIdentifier");

            function m(e) {
                if ("string" != typeof e || 1 !== e.length) throw new TypeError("arrayFormatSeparator must be single character string")
            }

            function y(e, t) {
                return t.encode ? t.strict ? d(e) : encodeURIComponent(e) : e
            }

            function h(e, t) {
                return t.decode ? u(e) : e
            }

            function b(e) {
                return Array.isArray(e) ? e.sort() : "object" == typeof e ? b(Object.keys(e)).sort(((e, t) => Number(e) - Number(t))).map((t => e[t])) : e
            }

            function v(e) {
                const t = e.indexOf("#");
                return -1 !== t && (e = e.slice(0, t)), e
            }

            function _(e, t) {
                return t.parseNumbers && !Number.isNaN(Number(e)) && "string" == typeof e && "" !== e.trim() ? e = Number(e) : !t.parseBooleans || null === e || "true" !== e.toLowerCase() && "false" !== e.toLowerCase() || (e = "true" === e.toLowerCase()), e
            }

            function w(e) {
                const t = (e = v(e)).indexOf("?");
                return -1 === t ? "" : e.slice(t + 1)
            }

            function k(e, t) {
                m((t = {
                    decode: !0,
                    sort: !0,
                    arrayFormat: "none",
                    arrayFormatSeparator: ",",
                    parseNumbers: !1,
                    parseBooleans: !1,
                    ...t
                }).arrayFormatSeparator);
                const n = function(e) {
                        let t;
                        switch (e.arrayFormat) {
                            case "index":
                                return (e, n, r) => {
                                    t = /\[(\d*)]$/.exec(e), e = e.replace(/\[\d*]$/, ""), t ? (void 0 === r[e] && (r[e] = {}), r[e][t[1]] = n) : r[e] = n
                                };
                            case "bracket":
                                return (e, n, r) => {
                                    t = /(\[])$/.exec(e), e = e.replace(/\[]$/, ""), t ? void 0 !== r[e] ? r[e] = [...r[e], n] : r[e] = [n] : r[e] = n
                                };
                            case "colon-list-separator":
                                return (e, n, r) => {
                                    t = /(:list)$/.exec(e), e = e.replace(/:list$/, ""), t ? void 0 !== r[e] ? r[e] = [...r[e], n] : r[e] = [n] : r[e] = n
                                };
                            case "comma":
                            case "separator":
                                return (t, n, r) => {
                                    const o = "string" == typeof n && n.includes(e.arrayFormatSeparator),
                                        i = "string" == typeof n && !o && h(n, e).includes(e.arrayFormatSeparator);
                                    n = i ? h(n, e) : n;
                                    const s = o || i ? n.split(e.arrayFormatSeparator).map((t => h(t, e))) : null === n ? n : h(n, e);
                                    r[t] = s
                                };
                            case "bracket-separator":
                                return (t, n, r) => {
                                    const o = /(\[])$/.test(t);
                                    if (t = t.replace(/\[]$/, ""), !o) return void(r[t] = n ? h(n, e) : n);
                                    const i = null === n ? [] : n.split(e.arrayFormatSeparator).map((t => h(t, e)));
                                    void 0 !== r[t] ? r[t] = [...r[t], ...i] : r[t] = i
                                };
                            default:
                                return (e, t, n) => {
                                    void 0 !== n[e] ? n[e] = [...[n[e]].flat(), t] : n[e] = t
                                }
                        }
                    }(t),
                    r = Object.create(null);
                if ("string" != typeof e) return r;
                if (!(e = e.trim().replace(/^[?#&]/, ""))) return r;
                for (const o of e.split("&")) {
                    if ("" === o) continue;
                    const e = t.decode ? o.replaceAll("+", " ") : o;
                    let [i, s] = l(e, "=");
                    void 0 === i && (i = e), s = void 0 === s ? null : ["comma", "separator", "bracket-separator"].includes(t.arrayFormat) ? s : h(s, t), n(h(i, t), s, r)
                }
                for (const [e, n] of Object.entries(r))
                    if ("object" == typeof n && null !== n)
                        for (const [e, r] of Object.entries(n)) n[e] = _(r, t);
                    else r[e] = _(n, t);
                return !1 === t.sort ? r : (!0 === t.sort ? Object.keys(r).sort() : Object.keys(r).sort(t.sort)).reduce(((e, t) => {
                    const n = r[t];
                    return e[t] = Boolean(n) && "object" == typeof n && !Array.isArray(n) ? b(n) : n, e
                }), Object.create(null))
            }

            function I(e, t) {
                if (!e) return "";
                m((t = {
                    encode: !0,
                    strict: !0,
                    arrayFormat: "none",
                    arrayFormatSeparator: ",",
                    ...t
                }).arrayFormatSeparator);
                const n = n => t.skipNull && p(e[n]) || t.skipEmptyString && "" === e[n],
                    r = function(e) {
                        switch (e.arrayFormat) {
                            case "index":
                                return t => (n, r) => {
                                    const o = n.length;
                                    return void 0 === r || e.skipNull && null === r || e.skipEmptyString && "" === r ? n : null === r ? [...n, [y(t, e), "[", o, "]"].join("")] : [...n, [y(t, e), "[", y(o, e), "]=", y(r, e)].join("")]
                                };
                            case "bracket":
                                return t => (n, r) => void 0 === r || e.skipNull && null === r || e.skipEmptyString && "" === r ? n : null === r ? [...n, [y(t, e), "[]"].join("")] : [...n, [y(t, e), "[]=", y(r, e)].join("")];
                            case "colon-list-separator":
                                return t => (n, r) => void 0 === r || e.skipNull && null === r || e.skipEmptyString && "" === r ? n : null === r ? [...n, [y(t, e), ":list="].join("")] : [...n, [y(t, e), ":list=", y(r, e)].join("")];
                            case "comma":
                            case "separator":
                            case "bracket-separator":
                                {
                                    const t = "bracket-separator" === e.arrayFormat ? "[]=" : "=";
                                    return n => (r, o) => void 0 === o || e.skipNull && null === o || e.skipEmptyString && "" === o ? r : (o = null === o ? "" : o, 0 === r.length ? [
                                        [y(n, e), t, y(o, e)].join("")
                                    ] : [
                                        [r, y(o, e)].join(e.arrayFormatSeparator)
                                    ])
                                }
                            default:
                                return t => (n, r) => void 0 === r || e.skipNull && null === r || e.skipEmptyString && "" === r ? n : null === r ? [...n, y(t, e)] : [...n, [y(t, e), "=", y(r, e)].join("")]
                        }
                    }(t),
                    o = {};
                for (const [t, r] of Object.entries(e)) n(t) || (o[t] = r);
                const i = Object.keys(o);
                return !1 !== t.sort && i.sort(t.sort), i.map((n => {
                    const o = e[n];
                    return void 0 === o ? "" : null === o ? y(n, t) : Array.isArray(o) ? 0 === o.length && "bracket-separator" === t.arrayFormat ? y(n, t) + "[]" : o.reduce(r(n), []).join("&") : y(n, t) + "=" + y(o, t)
                })).filter((e => e.length > 0)).join("&")
            }

            function j(e, t) {
                t = {
                    decode: !0,
                    ...t
                };
                let [n, r] = l(e, "#");
                return void 0 === n && (n = e), {
                    url: n ? .split("?") ? .[0] ? ? "",
                    query: k(w(e), t),
                    ...t && t.parseFragmentIdentifier && r ? {
                        fragmentIdentifier: h(r, t)
                    } : {}
                }
            }

            function F(e, t) {
                t = {
                    encode: !0,
                    strict: !0,
                    [g]: !0,
                    ...t
                };
                const n = v(e.url).split("?")[0] || "";
                let r = I({ ...k(w(e.url), {
                        sort: !1
                    }),
                    ...e.query
                }, t);
                r && = `?${r}`;
                let o = function(e) {
                    let t = "";
                    const n = e.indexOf("#");
                    return -1 !== n && (t = e.slice(n)), t
                }(e.url);
                if ("string" == typeof e.fragmentIdentifier) {
                    const r = new URL(n);
                    r.hash = e.fragmentIdentifier, o = t[g] ? r.hash : `#${e.fragmentIdentifier}`
                }
                return `${n}${r}${o}`
            }

            function S(e, t, n) {
                n = {
                    parseFragmentIdentifier: !0,
                    [g]: !1,
                    ...n
                };
                const {
                    url: r,
                    query: o,
                    fragmentIdentifier: i
                } = j(e, n);
                return F({
                    url: r,
                    query: f(o, t),
                    fragmentIdentifier: i
                }, n)
            }

            function O(e, t, n) {
                return S(e, Array.isArray(t) ? e => !t.includes(e) : (e, n) => !t(e, n), n)
            }
            var P = r
        }
    },
    function(e) {
        e.O(0, [8715, 5537, 9775, 8741, 8193, 1744], (function() {
            return t = 69868, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);