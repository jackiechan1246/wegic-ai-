! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "7d80fc12-97ba-44d8-b265-c452b180dd79", t._sentryDebugIdIdentifier = "sentry-dbid-7d80fc12-97ba-44d8-b265-c452b180dd79")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8767], {
        68767: function(t, e, s) {
            s.d(e, {
                F4: function() {
                    return ce
                }
            });
            var r = {};
            s.r(r), s.d(r, {
                Decoder: function() {
                    return ks
                },
                Encoder: function() {
                    return vs
                },
                PacketType: function() {
                    return _s
                },
                protocol: function() {
                    return ms
                }
            });
            var n = s(22162);
            const {
                Axios: o,
                AxiosError: i,
                CanceledError: a,
                isCancel: c,
                CancelToken: h,
                VERSION: u,
                all: p,
                Cancel: l,
                isAxiosError: d,
                spread: f,
                toFormData: y,
                AxiosHeaders: g,
                HttpStatusCode: b,
                formToJSON: m,
                getAdapter: _,
                mergeConfig: v
            } = n.default;
            var w = s(93535);
            var k = function(t, e) {
                    for (var s = -1, r = null == t ? 0 : t.length, n = Array(r); ++s < r;) n[s] = e(t[s], s, t);
                    return n
                },
                E = Array.isArray,
                A = s(74535),
                O = w.Z ? w.Z.prototype : void 0,
                T = O ? O.toString : void 0;
            var C = function t(e) {
                if ("string" == typeof e) return e;
                if (E(e)) return k(e, t) + "";
                if ((0, A.Z)(e)) return T ? T.call(e) : "";
                var s = e + "";
                return "0" == s && 1 / e == -1 / 0 ? "-0" : s
            };
            var R = function(t) {
                return null == t ? "" : C(t)
            };
            var j = function(t) {
                return R(t).toLowerCase()
            };
            const S = new Map;
            let x = {
                responseErrorIsEnterCatch: !1
            };

            function B(t, e) {
                return j(e ? `${t}-${e}` : t)
            }

            function N(t) {
                const {
                    method: e,
                    url: s = "/"
                } = t, r = B(s, e), n = new AbortController;
                return S.set(r, n), t.signal = n.signal, t
            }

            function P(t) {
                const e = t.config,
                    {
                        method: s,
                        url: r = "/"
                    } = e;
                return S.delete(B(r, s)), t
            }

            function L(t) {
                const {
                    responseErrorIsEnterCatch: e
                } = x;
                return t instanceof a && !e ? new Promise((() => {})) : Promise.reject(t)
            }
            var q = function(t) {
                return void 0 === t
            };
            var I = function(t) {
                    return null === t
                },
                M = Object.prototype;
            var D = function(t) {
                var e = t && t.constructor;
                return t === ("function" == typeof e && e.prototype || M)
            };
            var U = function(t, e) {
                    return function(s) {
                        return t(e(s))
                    }
                }(Object.keys, Object),
                F = Object.prototype.hasOwnProperty;
            var Z = function(t) {
                    if (!D(t)) return U(t);
                    var e = [];
                    for (var s in Object(t)) F.call(t, s) && "constructor" != s && e.push(s);
                    return e
                },
                H = s(56617),
                V = s(74646);
            var W, $ = function(t) {
                    if (!(0, V.Z)(t)) return !1;
                    var e = (0, H.Z)(t);
                    return "[object Function]" == e || "[object GeneratorFunction]" == e || "[object AsyncFunction]" == e || "[object Proxy]" == e
                },
                K = s(81729),
                Y = K.Z["__core-js_shared__"],
                z = (W = /[^.]+$/.exec(Y && Y.keys && Y.keys.IE_PROTO || "")) ? "Symbol(src)_1." + W : "";
            var J = function(t) {
                    return !!z && z in t
                },
                Q = Function.prototype.toString;
            var X = function(t) {
                    if (null != t) {
                        try {
                            return Q.call(t)
                        } catch (t) {}
                        try {
                            return t + ""
                        } catch (t) {}
                    }
                    return ""
                },
                G = /^\[object .+?Constructor\]$/,
                tt = Function.prototype,
                et = Object.prototype,
                st = tt.toString,
                rt = et.hasOwnProperty,
                nt = RegExp("^" + st.call(rt).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
            var ot = function(t) {
                return !(!(0, V.Z)(t) || J(t)) && ($(t) ? nt : G).test(X(t))
            };
            var it = function(t, e) {
                return null == t ? void 0 : t[e]
            };
            var at = function(t, e) {
                    var s = it(t, e);
                    return ot(s) ? s : void 0
                },
                ct = at(K.Z, "DataView"),
                ht = at(K.Z, "Map"),
                ut = at(K.Z, "Promise"),
                pt = at(K.Z, "Set"),
                lt = at(K.Z, "WeakMap"),
                dt = "[object Map]",
                ft = "[object Promise]",
                yt = "[object Set]",
                gt = "[object WeakMap]",
                bt = "[object DataView]",
                mt = X(ct),
                _t = X(ht),
                vt = X(ut),
                wt = X(pt),
                kt = X(lt),
                Et = H.Z;
            (ct && Et(new ct(new ArrayBuffer(1))) != bt || ht && Et(new ht) != dt || ut && Et(ut.resolve()) != ft || pt && Et(new pt) != yt || lt && Et(new lt) != gt) && (Et = function(t) {
                var e = (0, H.Z)(t),
                    s = "[object Object]" == e ? t.constructor : void 0,
                    r = s ? X(s) : "";
                if (r) switch (r) {
                    case mt:
                        return bt;
                    case _t:
                        return dt;
                    case vt:
                        return ft;
                    case wt:
                        return yt;
                    case kt:
                        return gt
                }
                return e
            });
            var At = Et,
                Ot = s(55822);
            var Tt = function(t) {
                    return (0, Ot.Z)(t) && "[object Arguments]" == (0, H.Z)(t)
                },
                Ct = Object.prototype,
                Rt = Ct.hasOwnProperty,
                jt = Ct.propertyIsEnumerable,
                St = Tt(function() {
                    return arguments
                }()) ? Tt : function(t) {
                    return (0, Ot.Z)(t) && Rt.call(t, "callee") && !jt.call(t, "callee")
                },
                xt = St;
            var Bt = function(t) {
                return "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991
            };
            var Nt = function(t) {
                return null != t && Bt(t.length) && !$(t)
            };
            var Pt = function() {
                    return !1
                },
                Lt = "object" == typeof exports && exports && !exports.nodeType && exports,
                qt = Lt && "object" == typeof module && module && !module.nodeType && module,
                It = qt && qt.exports === Lt ? K.Z.Buffer : void 0,
                Mt = (It ? It.isBuffer : void 0) || Pt,
                Dt = {};
            Dt["[object Float32Array]"] = Dt["[object Float64Array]"] = Dt["[object Int8Array]"] = Dt["[object Int16Array]"] = Dt["[object Int32Array]"] = Dt["[object Uint8Array]"] = Dt["[object Uint8ClampedArray]"] = Dt["[object Uint16Array]"] = Dt["[object Uint32Array]"] = !0, Dt["[object Arguments]"] = Dt["[object Array]"] = Dt["[object ArrayBuffer]"] = Dt["[object Boolean]"] = Dt["[object DataView]"] = Dt["[object Date]"] = Dt["[object Error]"] = Dt["[object Function]"] = Dt["[object Map]"] = Dt["[object Number]"] = Dt["[object Object]"] = Dt["[object RegExp]"] = Dt["[object Set]"] = Dt["[object String]"] = Dt["[object WeakMap]"] = !1;
            var Ut = function(t) {
                return (0, Ot.Z)(t) && Bt(t.length) && !!Dt[(0, H.Z)(t)]
            };
            var Ft = function(t) {
                    return function(e) {
                        return t(e)
                    }
                },
                Zt = s(99905),
                Ht = "object" == typeof exports && exports && !exports.nodeType && exports,
                Vt = Ht && "object" == typeof module && module && !module.nodeType && module,
                Wt = Vt && Vt.exports === Ht && Zt.Z.process,
                $t = function() {
                    try {
                        var t = Vt && Vt.require && Vt.require("util").types;
                        return t || Wt && Wt.binding && Wt.binding("util")
                    } catch (t) {}
                }(),
                Kt = $t && $t.isTypedArray,
                Yt = Kt ? Ft(Kt) : Ut,
                zt = Object.prototype.hasOwnProperty;
            var Jt = function(t) {
                    if (null == t) return !0;
                    if (Nt(t) && (E(t) || "string" == typeof t || "function" == typeof t.splice || Mt(t) || Yt(t) || xt(t))) return !t.length;
                    var e = At(t);
                    if ("[object Map]" == e || "[object Set]" == e) return !t.size;
                    if (D(t)) return !Z(t).length;
                    for (var s in t)
                        if (zt.call(t, s)) return !1;
                    return !0
                },
                Qt = s(73562),
                Xt = s.n(Qt),
                Gt = s(92869);
            new class {
                constructor() {
                    this.log = function() {}.bind(), this.error = function() {}.bind(), this.warn = function() {}.bind(), this.info = function() {}.bind(), this.trace = function() {}.bind(), this.debug = function() {}.bind(), this.assert = function() {}.bind(), this.defaultStyles = {
                        error: {
                            background: "red",
                            color: "white",
                            fontWeight: "bold"
                        },
                        warn: {
                            background: "yellow",
                            color: "black",
                            fontWeight: "bold"
                        },
                        info: {
                            background: "orange",
                            color: "black",
                            fontWeight: "bold"
                        },
                        success: {
                            background: "green",
                            color: "white",
                            fontWeight: "bold"
                        },
                        trace: {
                            background: "purple",
                            color: "white",
                            fontWeight: "bold"
                        }
                    }, this.isNodeEnvironment = void 0 !== Gt && null != Gt.versions && null != Gt.versions.node
                }
                dir(t, e) {}
                dirxml(...t) {}
                group(...t) {}
                groupCollapsed(...t) {}
                groupEnd() {}
                time(t) {}
                timeEnd(t) {}
                timeLog(t, ...e) {}
                table(t, e) {}
                clear() {}
                count(t) {}
                countReset(t) {}
                profile(t) {}
                profileEnd(t) {}
                colorError(t, e, ...s) {
                    this.logMessage("error", t, e, ...s)
                }
                colorWarn(t, e, ...s) {
                    this.logMessage("warn", t, e, ...s)
                }
                colorInfo(t, e, ...s) {
                    this.logMessage("info", t, e, ...s)
                }
                colorSuccess(t, e, ...s) {
                    this.logMessage("success", t, e, ...s)
                }
                colorTrace(t, e, ...s) {
                    this.logMessage("trace", t, e, ...s)
                }
                logMessage(t, e, s, ...r) {
                    this.isNodeEnvironment ? this.logInNode(t, e, s, ...r) : this.logInBrowser(t, e, s, ...r)
                }
                logInNode(t, e, s, ...r) {
                    const n = { ...this.defaultStyles[t],
                            ...s
                        },
                        {
                            background: o,
                            color: i,
                            fontWeight: a
                        } = n;
                    let c = t.toUpperCase();
                    o && (c = Xt().bgHex(o)(c)), i && (c = Xt().hex(i)(c)), "bold" === a && (c = Xt().bold(c))
                }
                logInBrowser(t, e, s, ...r) {
                    const n = { ...this.defaultStyles[t],
                            ...s
                        },
                        {
                            background: o,
                            color: i,
                            fontWeight: a
                        } = n
                }
            };
            const te = t => q(t) || I(t) || Jt(t),
                ee = [920001, 920004, 100007, 920002],
                se = "Data acquisition error";

            function re(t) {
                return t.isServer && (t.baseURL = `https://wegic.ai${t.baseURL}`), t
            }

            function ne(t) {
                const {
                    data: e
                } = t, s = t.config, r = s.errorHandler;
                if (te(e)) return Promise.reject((n = se, {
                    code: -1,
                    data: null,
                    message: "function" == typeof r ? .onErrorMessage ? r.onErrorMessage() : r ? .onErrorMessage || n
                }));
                var n;
                const o = { ...e
                };
                if ([0, ...s.allowedCodes || []].includes(o.code)) return Promise.resolve(o);
                (function(t) {
                    return ee.includes(t)
                })(o.code) && r ? .onPermissionError ? .();
                const i = "function" == typeof r ? .onErrorMessage ? r.onErrorMessage(e.key) : r ? .onErrorMessage || se;
                return !s.hideCodeErrorMessage && r ? .onError ? .(i), Promise.reject({ ...o,
                    message: i
                })
            }

            function oe(t) {
                const {
                    message: e,
                    response: s
                } = t, r = t.config, n = r.errorHandler;
                if (te(s)) return !r.hideHTTPErrorMessage && n ? .onError ? .(e || se), Promise.reject({
                    code: -1,
                    data: null,
                    message: se
                });
                const {
                    status: o,
                    data: i
                } = s, {
                    code: a,
                    data: c,
                    key: h
                } = i;
                return !r.hideHTTPErrorMessage && n ? .onError ? .(e || se), Promise.reject({
                    code: a ? ? o ? ? -1,
                    data: c,
                    message: "function" == typeof n ? .onErrorMessage ? n.onErrorMessage(h) : n ? .onErrorMessage || se
                })
            }
            const ie = {
                hideCodeErrorMessage: !0,
                hideHTTPErrorMessage: !0
            };
            var ae = class {
                constructor(t) {
                    this.instance = this.createInstance(t)
                }
                createInstance(t) {
                    const e = n.default.create({ ...ie,
                        ...t
                    });
                    return this.setupInterceptors(e, t), e
                }
                setupInterceptors(t, e) {
                    const {
                        interceptors: s
                    } = e;
                    t.interceptors.request.use(re), t.interceptors.request.use(N), s ? .request && t.interceptors.request.use(s.request), t.interceptors.response.use(P, L), t.interceptors.response.use(ne, oe), s ? .response && t.interceptors.response.use(s.response)
                }
                request(t, e, s, r) {
                    const n = { ...r,
                        method: t,
                        url: e,
                        data: s
                    };
                    return this.instance.request(n)
                }
                post(t, e, s) {
                    return this.request("POST", t, e, s)
                }
                get(t, e) {
                    return this.instance.get(t, e)
                }
                patch(t, e, s) {
                    return this.request("PATCH", t, e, s)
                }
                delete(t, e) {
                    return this.request("DELETE", t, void 0, e)
                }
                put(t, e, s) {
                    return this.request("PUT", t, e, s)
                }
                postForm(t, e, s) {
                    return this.request("POST", t, e, s)
                }
                putForm(t, e, s) {
                    return this.request("PUT", t, e, s)
                }
                patchForm(t, e, s) {
                    return this.request("PATCH", t, e, s)
                }
                head(t, e) {
                    return this.request("HEAD", t, void 0, e)
                }
                options(t, e) {
                    return this.request("OPTIONS", t, void 0, e)
                }
            };

            function ce(t) {
                const {
                    originalInstance: e
                } = t;
                return e ? n.default.create(t) : new ae(t)
            }
            const he = Object.create(null);
            he.open = "0", he.close = "1", he.ping = "2", he.pong = "3", he.message = "4", he.upgrade = "5", he.noop = "6";
            const ue = Object.create(null);
            Object.keys(he).forEach((t => {
                ue[he[t]] = t
            }));
            const pe = {
                    type: "error",
                    data: "parser error"
                },
                le = "function" == typeof Blob || "undefined" != typeof Blob && "[object BlobConstructor]" === Object.prototype.toString.call(Blob),
                de = "function" == typeof ArrayBuffer,
                fe = t => "function" == typeof ArrayBuffer.isView ? ArrayBuffer.isView(t) : t && t.buffer instanceof ArrayBuffer,
                ye = ({
                    type: t,
                    data: e
                }, s, r) => le && e instanceof Blob ? s ? r(e) : ge(e, r) : de && (e instanceof ArrayBuffer || fe(e)) ? s ? r(e) : ge(new Blob([e]), r) : r(he[t] + (e || "")),
                ge = (t, e) => {
                    const s = new FileReader;
                    return s.onload = function() {
                        const t = s.result.split(",")[1];
                        e("b" + (t || ""))
                    }, s.readAsDataURL(t)
                };

            function be(t) {
                return t instanceof Uint8Array ? t : t instanceof ArrayBuffer ? new Uint8Array(t) : new Uint8Array(t.buffer, t.byteOffset, t.byteLength)
            }
            let me;
            const _e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                ve = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256);
            for (let t = 0; t < 64; t++) ve[_e.charCodeAt(t)] = t;
            const we = "function" == typeof ArrayBuffer,
                ke = (t, e) => {
                    if ("string" != typeof t) return {
                        type: "message",
                        data: Ae(t, e)
                    };
                    const s = t.charAt(0);
                    if ("b" === s) return {
                        type: "message",
                        data: Ee(t.substring(1), e)
                    };
                    return ue[s] ? t.length > 1 ? {
                        type: ue[s],
                        data: t.substring(1)
                    } : {
                        type: ue[s]
                    } : pe
                },
                Ee = (t, e) => {
                    if (we) {
                        const s = (t => {
                            let e, s, r, n, o, i = .75 * t.length,
                                a = t.length,
                                c = 0;
                            "=" === t[t.length - 1] && (i--, "=" === t[t.length - 2] && i--);
                            const h = new ArrayBuffer(i),
                                u = new Uint8Array(h);
                            for (e = 0; e < a; e += 4) s = ve[t.charCodeAt(e)], r = ve[t.charCodeAt(e + 1)], n = ve[t.charCodeAt(e + 2)], o = ve[t.charCodeAt(e + 3)], u[c++] = s << 2 | r >> 4, u[c++] = (15 & r) << 4 | n >> 2, u[c++] = (3 & n) << 6 | 63 & o;
                            return h
                        })(t);
                        return Ae(s, e)
                    }
                    return {
                        base64: !0,
                        data: t
                    }
                },
                Ae = (t, e) => "blob" === e ? t instanceof Blob ? t : new Blob([t]) : t instanceof ArrayBuffer ? t : t.buffer,
                Oe = String.fromCharCode(30);

            function Te() {
                return new TransformStream({
                    transform(t, e) {
                        ! function(t, e) {
                            le && t.data instanceof Blob ? t.data.arrayBuffer().then(be).then(e) : de && (t.data instanceof ArrayBuffer || fe(t.data)) ? e(be(t.data)) : ye(t, !1, (t => {
                                me || (me = new TextEncoder), e(me.encode(t))
                            }))
                        }(t, (s => {
                            const r = s.length;
                            let n;
                            if (r < 126) n = new Uint8Array(1), new DataView(n.buffer).setUint8(0, r);
                            else if (r < 65536) {
                                n = new Uint8Array(3);
                                const t = new DataView(n.buffer);
                                t.setUint8(0, 126), t.setUint16(1, r)
                            } else {
                                n = new Uint8Array(9);
                                const t = new DataView(n.buffer);
                                t.setUint8(0, 127), t.setBigUint64(1, BigInt(r))
                            }
                            t.data && "string" != typeof t.data && (n[0] |= 128), e.enqueue(n), e.enqueue(s)
                        }))
                    }
                })
            }
            let Ce;

            function Re(t) {
                return t.reduce(((t, e) => t + e.length), 0)
            }

            function je(t, e) {
                if (t[0].length === e) return t.shift();
                const s = new Uint8Array(e);
                let r = 0;
                for (let n = 0; n < e; n++) s[n] = t[0][r++], r === t[0].length && (t.shift(), r = 0);
                return t.length && r < t[0].length && (t[0] = t[0].slice(r)), s
            }

            function Se(t) {
                if (t) return function(t) {
                    for (var e in Se.prototype) t[e] = Se.prototype[e];
                    return t
                }(t)
            }
            Se.prototype.on = Se.prototype.addEventListener = function(t, e) {
                return this._callbacks = this._callbacks || {}, (this._callbacks["$" + t] = this._callbacks["$" + t] || []).push(e), this
            }, Se.prototype.once = function(t, e) {
                function s() {
                    this.off(t, s), e.apply(this, arguments)
                }
                return s.fn = e, this.on(t, s), this
            }, Se.prototype.off = Se.prototype.removeListener = Se.prototype.removeAllListeners = Se.prototype.removeEventListener = function(t, e) {
                if (this._callbacks = this._callbacks || {}, 0 == arguments.length) return this._callbacks = {}, this;
                var s, r = this._callbacks["$" + t];
                if (!r) return this;
                if (1 == arguments.length) return delete this._callbacks["$" + t], this;
                for (var n = 0; n < r.length; n++)
                    if ((s = r[n]) === e || s.fn === e) {
                        r.splice(n, 1);
                        break
                    }
                return 0 === r.length && delete this._callbacks["$" + t], this
            }, Se.prototype.emit = function(t) {
                this._callbacks = this._callbacks || {};
                for (var e = new Array(arguments.length - 1), s = this._callbacks["$" + t], r = 1; r < arguments.length; r++) e[r - 1] = arguments[r];
                if (s) {
                    r = 0;
                    for (var n = (s = s.slice(0)).length; r < n; ++r) s[r].apply(this, e)
                }
                return this
            }, Se.prototype.emitReserved = Se.prototype.emit, Se.prototype.listeners = function(t) {
                return this._callbacks = this._callbacks || {}, this._callbacks["$" + t] || []
            }, Se.prototype.hasListeners = function(t) {
                return !!this.listeners(t).length
            };
            const xe = "function" == typeof Promise && "function" == typeof Promise.resolve ? t => Promise.resolve().then(t) : (t, e) => e(t, 0),
                Be = "undefined" != typeof self ? self : "undefined" != typeof window ? window : Function("return this")();

            function Ne(t, ...e) {
                return e.reduce(((e, s) => (t.hasOwnProperty(s) && (e[s] = t[s]), e)), {})
            }
            const Pe = Be.setTimeout,
                Le = Be.clearTimeout;

            function qe(t, e) {
                e.useNativeTimers ? (t.setTimeoutFn = Pe.bind(Be), t.clearTimeoutFn = Le.bind(Be)) : (t.setTimeoutFn = Be.setTimeout.bind(Be), t.clearTimeoutFn = Be.clearTimeout.bind(Be))
            }

            function Ie() {
                return Date.now().toString(36).substring(3) + Math.random().toString(36).substring(2, 5)
            }
            class Me extends Error {
                constructor(t, e, s) {
                    super(t), this.description = e, this.context = s, this.type = "TransportError"
                }
            }
            class De extends Se {
                constructor(t) {
                    super(), this.writable = !1, qe(this, t), this.opts = t, this.query = t.query, this.socket = t.socket, this.supportsBinary = !t.forceBase64
                }
                onError(t, e, s) {
                    return super.emitReserved("error", new Me(t, e, s)), this
                }
                open() {
                    return this.readyState = "opening", this.doOpen(), this
                }
                close() {
                    return "opening" !== this.readyState && "open" !== this.readyState || (this.doClose(), this.onClose()), this
                }
                send(t) {
                    "open" === this.readyState && this.write(t)
                }
                onOpen() {
                    this.readyState = "open", this.writable = !0, super.emitReserved("open")
                }
                onData(t) {
                    const e = ke(t, this.socket.binaryType);
                    this.onPacket(e)
                }
                onPacket(t) {
                    super.emitReserved("packet", t)
                }
                onClose(t) {
                    this.readyState = "closed", super.emitReserved("close", t)
                }
                pause(t) {}
                createUri(t, e = {}) {
                    return t + "://" + this._hostname() + this._port() + this.opts.path + this._query(e)
                }
                _hostname() {
                    const t = this.opts.hostname;
                    return -1 === t.indexOf(":") ? t : "[" + t + "]"
                }
                _port() {
                    return this.opts.port && (this.opts.secure && Number(443 !== this.opts.port) || !this.opts.secure && 80 !== Number(this.opts.port)) ? ":" + this.opts.port : ""
                }
                _query(t) {
                    const e = function(t) {
                        let e = "";
                        for (let s in t) t.hasOwnProperty(s) && (e.length && (e += "&"), e += encodeURIComponent(s) + "=" + encodeURIComponent(t[s]));
                        return e
                    }(t);
                    return e.length ? "?" + e : ""
                }
            }
            class Ue extends De {
                constructor() {
                    super(...arguments), this._polling = !1
                }
                get name() {
                    return "polling"
                }
                doOpen() {
                    this._poll()
                }
                pause(t) {
                    this.readyState = "pausing";
                    const e = () => {
                        this.readyState = "paused", t()
                    };
                    if (this._polling || !this.writable) {
                        let t = 0;
                        this._polling && (t++, this.once("pollComplete", (function() {
                            --t || e()
                        }))), this.writable || (t++, this.once("drain", (function() {
                            --t || e()
                        })))
                    } else e()
                }
                _poll() {
                    this._polling = !0, this.doPoll(), this.emitReserved("poll")
                }
                onData(t) {
                    ((t, e) => {
                        const s = t.split(Oe),
                            r = [];
                        for (let t = 0; t < s.length; t++) {
                            const n = ke(s[t], e);
                            if (r.push(n), "error" === n.type) break
                        }
                        return r
                    })(t, this.socket.binaryType).forEach((t => {
                        if ("opening" === this.readyState && "open" === t.type && this.onOpen(), "close" === t.type) return this.onClose({
                            description: "transport closed by the server"
                        }), !1;
                        this.onPacket(t)
                    })), "closed" !== this.readyState && (this._polling = !1, this.emitReserved("pollComplete"), "open" === this.readyState && this._poll())
                }
                doClose() {
                    const t = () => {
                        this.write([{
                            type: "close"
                        }])
                    };
                    "open" === this.readyState ? t() : this.once("open", t)
                }
                write(t) {
                    this.writable = !1, ((t, e) => {
                        const s = t.length,
                            r = new Array(s);
                        let n = 0;
                        t.forEach(((t, o) => {
                            ye(t, !1, (t => {
                                r[o] = t, ++n === s && e(r.join(Oe))
                            }))
                        }))
                    })(t, (t => {
                        this.doWrite(t, (() => {
                            this.writable = !0, this.emitReserved("drain")
                        }))
                    }))
                }
                uri() {
                    const t = this.opts.secure ? "https" : "http",
                        e = this.query || {};
                    return !1 !== this.opts.timestampRequests && (e[this.opts.timestampParam] = Ie()), this.supportsBinary || e.sid || (e.b64 = 1), this.createUri(t, e)
                }
            }
            let Fe = !1;
            try {
                Fe = "undefined" != typeof XMLHttpRequest && "withCredentials" in new XMLHttpRequest
            } catch (t) {}
            const Ze = Fe;

            function He() {}
            class Ve extends Ue {
                constructor(t) {
                    if (super(t), "undefined" != typeof location) {
                        const e = "https:" === location.protocol;
                        let s = location.port;
                        s || (s = e ? "443" : "80"), this.xd = "undefined" != typeof location && t.hostname !== location.hostname || s !== t.port
                    }
                }
                doWrite(t, e) {
                    const s = this.request({
                        method: "POST",
                        data: t
                    });
                    s.on("success", e), s.on("error", ((t, e) => {
                        this.onError("xhr post error", t, e)
                    }))
                }
                doPoll() {
                    const t = this.request();
                    t.on("data", this.onData.bind(this)), t.on("error", ((t, e) => {
                        this.onError("xhr poll error", t, e)
                    })), this.pollXhr = t
                }
            }
            class We extends Se {
                constructor(t, e, s) {
                    super(), this.createRequest = t, qe(this, s), this._opts = s, this._method = s.method || "GET", this._uri = e, this._data = void 0 !== s.data ? s.data : null, this._create()
                }
                _create() {
                    var t;
                    const e = Ne(this._opts, "agent", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "autoUnref");
                    e.xdomain = !!this._opts.xd;
                    const s = this._xhr = this.createRequest(e);
                    try {
                        s.open(this._method, this._uri, !0);
                        try {
                            if (this._opts.extraHeaders) {
                                s.setDisableHeaderCheck && s.setDisableHeaderCheck(!0);
                                for (let t in this._opts.extraHeaders) this._opts.extraHeaders.hasOwnProperty(t) && s.setRequestHeader(t, this._opts.extraHeaders[t])
                            }
                        } catch (t) {}
                        if ("POST" === this._method) try {
                            s.setRequestHeader("Content-type", "text/plain;charset=UTF-8")
                        } catch (t) {}
                        try {
                            s.setRequestHeader("Accept", "*/*")
                        } catch (t) {}
                        null === (t = this._opts.cookieJar) || void 0 === t || t.addCookies(s), "withCredentials" in s && (s.withCredentials = this._opts.withCredentials), this._opts.requestTimeout && (s.timeout = this._opts.requestTimeout), s.onreadystatechange = () => {
                            var t;
                            3 === s.readyState && (null === (t = this._opts.cookieJar) || void 0 === t || t.parseCookies(s.getResponseHeader("set-cookie"))), 4 === s.readyState && (200 === s.status || 1223 === s.status ? this._onLoad() : this.setTimeoutFn((() => {
                                this._onError("number" == typeof s.status ? s.status : 0)
                            }), 0))
                        }, s.send(this._data)
                    } catch (t) {
                        return void this.setTimeoutFn((() => {
                            this._onError(t)
                        }), 0)
                    }
                    "undefined" != typeof document && (this._index = We.requestsCount++, We.requests[this._index] = this)
                }
                _onError(t) {
                    this.emitReserved("error", t, this._xhr), this._cleanup(!0)
                }
                _cleanup(t) {
                    if (void 0 !== this._xhr && null !== this._xhr) {
                        if (this._xhr.onreadystatechange = He, t) try {
                            this._xhr.abort()
                        } catch (t) {}
                        "undefined" != typeof document && delete We.requests[this._index], this._xhr = null
                    }
                }
                _onLoad() {
                    const t = this._xhr.responseText;
                    null !== t && (this.emitReserved("data", t), this.emitReserved("success"), this._cleanup())
                }
                abort() {
                    this._cleanup()
                }
            }
            if (We.requestsCount = 0, We.requests = {}, "undefined" != typeof document)
                if ("function" == typeof attachEvent) attachEvent("onunload", $e);
                else if ("function" == typeof addEventListener) {
                addEventListener("onpagehide" in Be ? "pagehide" : "unload", $e, !1)
            }

            function $e() {
                for (let t in We.requests) We.requests.hasOwnProperty(t) && We.requests[t].abort()
            }
            const Ke = function() {
                const t = Ye({
                    xdomain: !1
                });
                return t && null !== t.responseType
            }();

            function Ye(t) {
                const e = t.xdomain;
                try {
                    if ("undefined" != typeof XMLHttpRequest && (!e || Ze)) return new XMLHttpRequest
                } catch (t) {}
                if (!e) try {
                    return new(Be[["Active"].concat("Object").join("X")])("Microsoft.XMLHTTP")
                } catch (t) {}
            }
            const ze = "undefined" != typeof navigator && "string" == typeof navigator.product && "reactnative" === navigator.product.toLowerCase();
            class Je extends De {
                get name() {
                    return "websocket"
                }
                doOpen() {
                    const t = this.uri(),
                        e = this.opts.protocols,
                        s = ze ? {} : Ne(this.opts, "agent", "perMessageDeflate", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "localAddress", "protocolVersion", "origin", "maxPayload", "family", "checkServerIdentity");
                    this.opts.extraHeaders && (s.headers = this.opts.extraHeaders);
                    try {
                        this.ws = this.createSocket(t, e, s)
                    } catch (t) {
                        return this.emitReserved("error", t)
                    }
                    this.ws.binaryType = this.socket.binaryType, this.addEventListeners()
                }
                addEventListeners() {
                    this.ws.onopen = () => {
                        this.opts.autoUnref && this.ws._socket.unref(), this.onOpen()
                    }, this.ws.onclose = t => this.onClose({
                        description: "websocket connection closed",
                        context: t
                    }), this.ws.onmessage = t => this.onData(t.data), this.ws.onerror = t => this.onError("websocket error", t)
                }
                write(t) {
                    this.writable = !1;
                    for (let e = 0; e < t.length; e++) {
                        const s = t[e],
                            r = e === t.length - 1;
                        ye(s, this.supportsBinary, (t => {
                            try {
                                this.doWrite(s, t)
                            } catch (t) {}
                            r && xe((() => {
                                this.writable = !0, this.emitReserved("drain")
                            }), this.setTimeoutFn)
                        }))
                    }
                }
                doClose() {
                    void 0 !== this.ws && (this.ws.onerror = () => {}, this.ws.close(), this.ws = null)
                }
                uri() {
                    const t = this.opts.secure ? "wss" : "ws",
                        e = this.query || {};
                    return this.opts.timestampRequests && (e[this.opts.timestampParam] = Ie()), this.supportsBinary || (e.b64 = 1), this.createUri(t, e)
                }
            }
            const Qe = Be.WebSocket || Be.MozWebSocket;
            const Xe = {
                    websocket: class extends Je {
                        createSocket(t, e, s) {
                            return ze ? new Qe(t, e, s) : e ? new Qe(t, e) : new Qe(t)
                        }
                        doWrite(t, e) {
                            this.ws.send(e)
                        }
                    },
                    webtransport: class extends De {
                        get name() {
                            return "webtransport"
                        }
                        doOpen() {
                            try {
                                this._transport = new WebTransport(this.createUri("https"), this.opts.transportOptions[this.name])
                            } catch (t) {
                                return this.emitReserved("error", t)
                            }
                            this._transport.closed.then((() => {
                                this.onClose()
                            })).catch((t => {
                                this.onError("webtransport error", t)
                            })), this._transport.ready.then((() => {
                                this._transport.createBidirectionalStream().then((t => {
                                    const e = function(t, e) {
                                            Ce || (Ce = new TextDecoder);
                                            const s = [];
                                            let r = 0,
                                                n = -1,
                                                o = !1;
                                            return new TransformStream({
                                                transform(i, a) {
                                                    for (s.push(i);;) {
                                                        if (0 === r) {
                                                            if (Re(s) < 1) break;
                                                            const t = je(s, 1);
                                                            o = !(128 & ~t[0]), n = 127 & t[0], r = n < 126 ? 3 : 126 === n ? 1 : 2
                                                        } else if (1 === r) {
                                                            if (Re(s) < 2) break;
                                                            const t = je(s, 2);
                                                            n = new DataView(t.buffer, t.byteOffset, t.length).getUint16(0), r = 3
                                                        } else if (2 === r) {
                                                            if (Re(s) < 8) break;
                                                            const t = je(s, 8),
                                                                e = new DataView(t.buffer, t.byteOffset, t.length),
                                                                o = e.getUint32(0);
                                                            if (o > Math.pow(2, 21) - 1) {
                                                                a.enqueue(pe);
                                                                break
                                                            }
                                                            n = o * Math.pow(2, 32) + e.getUint32(4), r = 3
                                                        } else {
                                                            if (Re(s) < n) break;
                                                            const t = je(s, n);
                                                            a.enqueue(ke(o ? t : Ce.decode(t), e)), r = 0
                                                        }
                                                        if (0 === n || n > t) {
                                                            a.enqueue(pe);
                                                            break
                                                        }
                                                    }
                                                }
                                            })
                                        }(Number.MAX_SAFE_INTEGER, this.socket.binaryType),
                                        s = t.readable.pipeThrough(e).getReader(),
                                        r = Te();
                                    r.readable.pipeTo(t.writable), this._writer = r.writable.getWriter();
                                    const n = () => {
                                        s.read().then((({
                                            done: t,
                                            value: e
                                        }) => {
                                            t || (this.onPacket(e), n())
                                        })).catch((t => {}))
                                    };
                                    n();
                                    const o = {
                                        type: "open"
                                    };
                                    this.query.sid && (o.data = `{"sid":"${this.query.sid}"}`), this._writer.write(o).then((() => this.onOpen()))
                                }))
                            }))
                        }
                        write(t) {
                            this.writable = !1;
                            for (let e = 0; e < t.length; e++) {
                                const s = t[e],
                                    r = e === t.length - 1;
                                this._writer.write(s).then((() => {
                                    r && xe((() => {
                                        this.writable = !0, this.emitReserved("drain")
                                    }), this.setTimeoutFn)
                                }))
                            }
                        }
                        doClose() {
                            var t;
                            null === (t = this._transport) || void 0 === t || t.close()
                        }
                    },
                    polling: class extends Ve {
                        constructor(t) {
                            super(t);
                            const e = t && t.forceBase64;
                            this.supportsBinary = Ke && !e
                        }
                        request(t = {}) {
                            return Object.assign(t, {
                                xd: this.xd
                            }, this.opts), new We(Ye, this.uri(), t)
                        }
                    }
                },
                Ge = /^(?:(?![^:@\/?#]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@\/?#]*)(?::([^:@\/?#]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,
                ts = ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"];

            function es(t) {
                if (t.length > 8e3) throw "URI too long";
                const e = t,
                    s = t.indexOf("["),
                    r = t.indexOf("]"); - 1 != s && -1 != r && (t = t.substring(0, s) + t.substring(s, r).replace(/:/g, ";") + t.substring(r, t.length));
                let n = Ge.exec(t || ""),
                    o = {},
                    i = 14;
                for (; i--;) o[ts[i]] = n[i] || "";
                return -1 != s && -1 != r && (o.source = e, o.host = o.host.substring(1, o.host.length - 1).replace(/;/g, ":"), o.authority = o.authority.replace("[", "").replace("]", "").replace(/;/g, ":"), o.ipv6uri = !0), o.pathNames = function(t, e) {
                    const s = /\/{2,9}/g,
                        r = e.replace(s, "/").split("/");
                    "/" != e.slice(0, 1) && 0 !== e.length || r.splice(0, 1);
                    "/" == e.slice(-1) && r.splice(r.length - 1, 1);
                    return r
                }(0, o.path), o.queryKey = function(t, e) {
                    const s = {};
                    return e.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, (function(t, e, r) {
                        e && (s[e] = r)
                    })), s
                }(0, o.query), o
            }
            const ss = "function" == typeof addEventListener && "function" == typeof removeEventListener,
                rs = [];
            ss && addEventListener("offline", (() => {
                rs.forEach((t => t()))
            }), !1);
            class ns extends Se {
                constructor(t, e) {
                    if (super(), this.binaryType = "arraybuffer", this.writeBuffer = [], this._prevBufferLen = 0, this._pingInterval = -1, this._pingTimeout = -1, this._maxPayload = -1, this._pingTimeoutTime = 1 / 0, t && "object" == typeof t && (e = t, t = null), t) {
                        const s = es(t);
                        e.hostname = s.host, e.secure = "https" === s.protocol || "wss" === s.protocol, e.port = s.port, s.query && (e.query = s.query)
                    } else e.host && (e.hostname = es(e.host).host);
                    qe(this, e), this.secure = null != e.secure ? e.secure : "undefined" != typeof location && "https:" === location.protocol, e.hostname && !e.port && (e.port = this.secure ? "443" : "80"), this.hostname = e.hostname || ("undefined" != typeof location ? location.hostname : "localhost"), this.port = e.port || ("undefined" != typeof location && location.port ? location.port : this.secure ? "443" : "80"), this.transports = [], this._transportsByName = {}, e.transports.forEach((t => {
                        const e = t.prototype.name;
                        this.transports.push(e), this._transportsByName[e] = t
                    })), this.opts = Object.assign({
                        path: "/engine.io",
                        agent: !1,
                        withCredentials: !1,
                        upgrade: !0,
                        timestampParam: "t",
                        rememberUpgrade: !1,
                        addTrailingSlash: !0,
                        rejectUnauthorized: !0,
                        perMessageDeflate: {
                            threshold: 1024
                        },
                        transportOptions: {},
                        closeOnBeforeunload: !1
                    }, e), this.opts.path = this.opts.path.replace(/\/$/, "") + (this.opts.addTrailingSlash ? "/" : ""), "string" == typeof this.opts.query && (this.opts.query = function(t) {
                        let e = {},
                            s = t.split("&");
                        for (let t = 0, r = s.length; t < r; t++) {
                            let r = s[t].split("=");
                            e[decodeURIComponent(r[0])] = decodeURIComponent(r[1])
                        }
                        return e
                    }(this.opts.query)), ss && (this.opts.closeOnBeforeunload && (this._beforeunloadEventListener = () => {
                        this.transport && (this.transport.removeAllListeners(), this.transport.close())
                    }, addEventListener("beforeunload", this._beforeunloadEventListener, !1)), "localhost" !== this.hostname && (this._offlineEventListener = () => {
                        this._onClose("transport close", {
                            description: "network connection lost"
                        })
                    }, rs.push(this._offlineEventListener))), this.opts.withCredentials && (this._cookieJar = void 0), this._open()
                }
                createTransport(t) {
                    const e = Object.assign({}, this.opts.query);
                    e.EIO = 4, e.transport = t, this.id && (e.sid = this.id);
                    const s = Object.assign({}, this.opts, {
                        query: e,
                        socket: this,
                        hostname: this.hostname,
                        secure: this.secure,
                        port: this.port
                    }, this.opts.transportOptions[t]);
                    return new this._transportsByName[t](s)
                }
                _open() {
                    if (0 === this.transports.length) return void this.setTimeoutFn((() => {
                        this.emitReserved("error", "No transports available")
                    }), 0);
                    const t = this.opts.rememberUpgrade && ns.priorWebsocketSuccess && -1 !== this.transports.indexOf("websocket") ? "websocket" : this.transports[0];
                    this.readyState = "opening";
                    const e = this.createTransport(t);
                    e.open(), this.setTransport(e)
                }
                setTransport(t) {
                    this.transport && this.transport.removeAllListeners(), this.transport = t, t.on("drain", this._onDrain.bind(this)).on("packet", this._onPacket.bind(this)).on("error", this._onError.bind(this)).on("close", (t => this._onClose("transport close", t)))
                }
                onOpen() {
                    this.readyState = "open", ns.priorWebsocketSuccess = "websocket" === this.transport.name, this.emitReserved("open"), this.flush()
                }
                _onPacket(t) {
                    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) switch (this.emitReserved("packet", t), this.emitReserved("heartbeat"), t.type) {
                        case "open":
                            this.onHandshake(JSON.parse(t.data));
                            break;
                        case "ping":
                            this._sendPacket("pong"), this.emitReserved("ping"), this.emitReserved("pong"), this._resetPingTimeout();
                            break;
                        case "error":
                            const e = new Error("server error");
                            e.code = t.data, this._onError(e);
                            break;
                        case "message":
                            this.emitReserved("data", t.data), this.emitReserved("message", t.data)
                    }
                }
                onHandshake(t) {
                    this.emitReserved("handshake", t), this.id = t.sid, this.transport.query.sid = t.sid, this._pingInterval = t.pingInterval, this._pingTimeout = t.pingTimeout, this._maxPayload = t.maxPayload, this.onOpen(), "closed" !== this.readyState && this._resetPingTimeout()
                }
                _resetPingTimeout() {
                    this.clearTimeoutFn(this._pingTimeoutTimer);
                    const t = this._pingInterval + this._pingTimeout;
                    this._pingTimeoutTime = Date.now() + t, this._pingTimeoutTimer = this.setTimeoutFn((() => {
                        this._onClose("ping timeout")
                    }), t), this.opts.autoUnref && this._pingTimeoutTimer.unref()
                }
                _onDrain() {
                    this.writeBuffer.splice(0, this._prevBufferLen), this._prevBufferLen = 0, 0 === this.writeBuffer.length ? this.emitReserved("drain") : this.flush()
                }
                flush() {
                    if ("closed" !== this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
                        const t = this._getWritablePackets();
                        this.transport.send(t), this._prevBufferLen = t.length, this.emitReserved("flush")
                    }
                }
                _getWritablePackets() {
                    if (!(this._maxPayload && "polling" === this.transport.name && this.writeBuffer.length > 1)) return this.writeBuffer;
                    let t = 1;
                    for (let s = 0; s < this.writeBuffer.length; s++) {
                        const r = this.writeBuffer[s].data;
                        if (r && (t += "string" == typeof(e = r) ? function(t) {
                                let e = 0,
                                    s = 0;
                                for (let r = 0, n = t.length; r < n; r++) e = t.charCodeAt(r), e < 128 ? s += 1 : e < 2048 ? s += 2 : e < 55296 || e >= 57344 ? s += 3 : (r++, s += 4);
                                return s
                            }(e) : Math.ceil(1.33 * (e.byteLength || e.size))), s > 0 && t > this._maxPayload) return this.writeBuffer.slice(0, s);
                        t += 2
                    }
                    var e;
                    return this.writeBuffer
                }
                _hasPingExpired() {
                    if (!this._pingTimeoutTime) return !0;
                    const t = Date.now() > this._pingTimeoutTime;
                    return t && (this._pingTimeoutTime = 0, xe((() => {
                        this._onClose("ping timeout")
                    }), this.setTimeoutFn)), t
                }
                write(t, e, s) {
                    return this._sendPacket("message", t, e, s), this
                }
                send(t, e, s) {
                    return this._sendPacket("message", t, e, s), this
                }
                _sendPacket(t, e, s, r) {
                    if ("function" == typeof e && (r = e, e = void 0), "function" == typeof s && (r = s, s = null), "closing" === this.readyState || "closed" === this.readyState) return;
                    (s = s || {}).compress = !1 !== s.compress;
                    const n = {
                        type: t,
                        data: e,
                        options: s
                    };
                    this.emitReserved("packetCreate", n), this.writeBuffer.push(n), r && this.once("flush", r), this.flush()
                }
                close() {
                    const t = () => {
                            this._onClose("forced close"), this.transport.close()
                        },
                        e = () => {
                            this.off("upgrade", e), this.off("upgradeError", e), t()
                        },
                        s = () => {
                            this.once("upgrade", e), this.once("upgradeError", e)
                        };
                    return "opening" !== this.readyState && "open" !== this.readyState || (this.readyState = "closing", this.writeBuffer.length ? this.once("drain", (() => {
                        this.upgrading ? s() : t()
                    })) : this.upgrading ? s() : t()), this
                }
                _onError(t) {
                    if (ns.priorWebsocketSuccess = !1, this.opts.tryAllTransports && this.transports.length > 1 && "opening" === this.readyState) return this.transports.shift(), this._open();
                    this.emitReserved("error", t), this._onClose("transport error", t)
                }
                _onClose(t, e) {
                    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
                        if (this.clearTimeoutFn(this._pingTimeoutTimer), this.transport.removeAllListeners("close"), this.transport.close(), this.transport.removeAllListeners(), ss && (this._beforeunloadEventListener && removeEventListener("beforeunload", this._beforeunloadEventListener, !1), this._offlineEventListener)) {
                            const t = rs.indexOf(this._offlineEventListener); - 1 !== t && rs.splice(t, 1)
                        }
                        this.readyState = "closed", this.id = null, this.emitReserved("close", t, e), this.writeBuffer = [], this._prevBufferLen = 0
                    }
                }
            }
            ns.protocol = 4;
            class os extends ns {
                constructor() {
                    super(...arguments), this._upgrades = []
                }
                onOpen() {
                    if (super.onOpen(), "open" === this.readyState && this.opts.upgrade)
                        for (let t = 0; t < this._upgrades.length; t++) this._probe(this._upgrades[t])
                }
                _probe(t) {
                    let e = this.createTransport(t),
                        s = !1;
                    ns.priorWebsocketSuccess = !1;
                    const r = () => {
                        s || (e.send([{
                            type: "ping",
                            data: "probe"
                        }]), e.once("packet", (t => {
                            if (!s)
                                if ("pong" === t.type && "probe" === t.data) {
                                    if (this.upgrading = !0, this.emitReserved("upgrading", e), !e) return;
                                    ns.priorWebsocketSuccess = "websocket" === e.name, this.transport.pause((() => {
                                        s || "closed" !== this.readyState && (h(), this.setTransport(e), e.send([{
                                            type: "upgrade"
                                        }]), this.emitReserved("upgrade", e), e = null, this.upgrading = !1, this.flush())
                                    }))
                                } else {
                                    const t = new Error("probe error");
                                    t.transport = e.name, this.emitReserved("upgradeError", t)
                                }
                        })))
                    };

                    function n() {
                        s || (s = !0, h(), e.close(), e = null)
                    }
                    const o = t => {
                        const s = new Error("probe error: " + t);
                        s.transport = e.name, n(), this.emitReserved("upgradeError", s)
                    };

                    function i() {
                        o("transport closed")
                    }

                    function a() {
                        o("socket closed")
                    }

                    function c(t) {
                        e && t.name !== e.name && n()
                    }
                    const h = () => {
                        e.removeListener("open", r), e.removeListener("error", o), e.removeListener("close", i), this.off("close", a), this.off("upgrading", c)
                    };
                    e.once("open", r), e.once("error", o), e.once("close", i), this.once("close", a), this.once("upgrading", c), -1 !== this._upgrades.indexOf("webtransport") && "webtransport" !== t ? this.setTimeoutFn((() => {
                        s || e.open()
                    }), 200) : e.open()
                }
                onHandshake(t) {
                    this._upgrades = this._filterUpgrades(t.upgrades), super.onHandshake(t)
                }
                _filterUpgrades(t) {
                    const e = [];
                    for (let s = 0; s < t.length; s++) ~this.transports.indexOf(t[s]) && e.push(t[s]);
                    return e
                }
            }
            class is extends os {
                constructor(t, e = {}) {
                    const s = "object" == typeof t ? t : e;
                    (!s.transports || s.transports && "string" == typeof s.transports[0]) && (s.transports = (s.transports || ["polling", "websocket", "webtransport"]).map((t => Xe[t])).filter((t => !!t))), super(t, s)
                }
            }
            const as = "function" == typeof ArrayBuffer,
                cs = Object.prototype.toString,
                hs = "function" == typeof Blob || "undefined" != typeof Blob && "[object BlobConstructor]" === cs.call(Blob),
                us = "function" == typeof File || "undefined" != typeof File && "[object FileConstructor]" === cs.call(File);

            function ps(t) {
                return as && (t instanceof ArrayBuffer || (t => "function" == typeof ArrayBuffer.isView ? ArrayBuffer.isView(t) : t.buffer instanceof ArrayBuffer)(t)) || hs && t instanceof Blob || us && t instanceof File
            }

            function ls(t, e) {
                if (!t || "object" != typeof t) return !1;
                if (Array.isArray(t)) {
                    for (let e = 0, s = t.length; e < s; e++)
                        if (ls(t[e])) return !0;
                    return !1
                }
                if (ps(t)) return !0;
                if (t.toJSON && "function" == typeof t.toJSON && 1 === arguments.length) return ls(t.toJSON(), !0);
                for (const e in t)
                    if (Object.prototype.hasOwnProperty.call(t, e) && ls(t[e])) return !0;
                return !1
            }

            function ds(t) {
                const e = [],
                    s = t.data,
                    r = t;
                return r.data = fs(s, e), r.attachments = e.length, {
                    packet: r,
                    buffers: e
                }
            }

            function fs(t, e) {
                if (!t) return t;
                if (ps(t)) {
                    const s = {
                        _placeholder: !0,
                        num: e.length
                    };
                    return e.push(t), s
                }
                if (Array.isArray(t)) {
                    const s = new Array(t.length);
                    for (let r = 0; r < t.length; r++) s[r] = fs(t[r], e);
                    return s
                }
                if ("object" == typeof t && !(t instanceof Date)) {
                    const s = {};
                    for (const r in t) Object.prototype.hasOwnProperty.call(t, r) && (s[r] = fs(t[r], e));
                    return s
                }
                return t
            }

            function ys(t, e) {
                return t.data = gs(t.data, e), delete t.attachments, t
            }

            function gs(t, e) {
                if (!t) return t;
                if (t && !0 === t._placeholder) {
                    if ("number" == typeof t.num && t.num >= 0 && t.num < e.length) return e[t.num];
                    throw new Error("illegal attachments")
                }
                if (Array.isArray(t))
                    for (let s = 0; s < t.length; s++) t[s] = gs(t[s], e);
                else if ("object" == typeof t)
                    for (const s in t) Object.prototype.hasOwnProperty.call(t, s) && (t[s] = gs(t[s], e));
                return t
            }
            const bs = ["connect", "connect_error", "disconnect", "disconnecting", "newListener", "removeListener"],
                ms = 5;
            var _s;
            ! function(t) {
                t[t.CONNECT = 0] = "CONNECT", t[t.DISCONNECT = 1] = "DISCONNECT", t[t.EVENT = 2] = "EVENT", t[t.ACK = 3] = "ACK", t[t.CONNECT_ERROR = 4] = "CONNECT_ERROR", t[t.BINARY_EVENT = 5] = "BINARY_EVENT", t[t.BINARY_ACK = 6] = "BINARY_ACK"
            }(_s || (_s = {}));
            class vs {
                constructor(t) {
                    this.replacer = t
                }
                encode(t) {
                    return t.type !== _s.EVENT && t.type !== _s.ACK || !ls(t) ? [this.encodeAsString(t)] : this.encodeAsBinary({
                        type: t.type === _s.EVENT ? _s.BINARY_EVENT : _s.BINARY_ACK,
                        nsp: t.nsp,
                        data: t.data,
                        id: t.id
                    })
                }
                encodeAsString(t) {
                    let e = "" + t.type;
                    return t.type !== _s.BINARY_EVENT && t.type !== _s.BINARY_ACK || (e += t.attachments + "-"), t.nsp && "/" !== t.nsp && (e += t.nsp + ","), null != t.id && (e += t.id), null != t.data && (e += JSON.stringify(t.data, this.replacer)), e
                }
                encodeAsBinary(t) {
                    const e = ds(t),
                        s = this.encodeAsString(e.packet),
                        r = e.buffers;
                    return r.unshift(s), r
                }
            }

            function ws(t) {
                return "[object Object]" === Object.prototype.toString.call(t)
            }
            class ks extends Se {
                constructor(t) {
                    super(), this.reviver = t
                }
                add(t) {
                    let e;
                    if ("string" == typeof t) {
                        if (this.reconstructor) throw new Error("got plaintext data when reconstructing a packet");
                        e = this.decodeString(t);
                        const s = e.type === _s.BINARY_EVENT;
                        s || e.type === _s.BINARY_ACK ? (e.type = s ? _s.EVENT : _s.ACK, this.reconstructor = new Es(e), 0 === e.attachments && super.emitReserved("decoded", e)) : super.emitReserved("decoded", e)
                    } else {
                        if (!ps(t) && !t.base64) throw new Error("Unknown type: " + t);
                        if (!this.reconstructor) throw new Error("got binary data when not reconstructing a packet");
                        e = this.reconstructor.takeBinaryData(t), e && (this.reconstructor = null, super.emitReserved("decoded", e))
                    }
                }
                decodeString(t) {
                    let e = 0;
                    const s = {
                        type: Number(t.charAt(0))
                    };
                    if (void 0 === _s[s.type]) throw new Error("unknown packet type " + s.type);
                    if (s.type === _s.BINARY_EVENT || s.type === _s.BINARY_ACK) {
                        const r = e + 1;
                        for (;
                            "-" !== t.charAt(++e) && e != t.length;);
                        const n = t.substring(r, e);
                        if (n != Number(n) || "-" !== t.charAt(e)) throw new Error("Illegal attachments");
                        s.attachments = Number(n)
                    }
                    if ("/" === t.charAt(e + 1)) {
                        const r = e + 1;
                        for (; ++e;) {
                            if ("," === t.charAt(e)) break;
                            if (e === t.length) break
                        }
                        s.nsp = t.substring(r, e)
                    } else s.nsp = "/";
                    const r = t.charAt(e + 1);
                    if ("" !== r && Number(r) == r) {
                        const r = e + 1;
                        for (; ++e;) {
                            const s = t.charAt(e);
                            if (null == s || Number(s) != s) {
                                --e;
                                break
                            }
                            if (e === t.length) break
                        }
                        s.id = Number(t.substring(r, e + 1))
                    }
                    if (t.charAt(++e)) {
                        const r = this.tryParse(t.substr(e));
                        if (!ks.isPayloadValid(s.type, r)) throw new Error("invalid payload");
                        s.data = r
                    }
                    return s
                }
                tryParse(t) {
                    try {
                        return JSON.parse(t, this.reviver)
                    } catch (t) {
                        return !1
                    }
                }
                static isPayloadValid(t, e) {
                    switch (t) {
                        case _s.CONNECT:
                            return ws(e);
                        case _s.DISCONNECT:
                            return void 0 === e;
                        case _s.CONNECT_ERROR:
                            return "string" == typeof e || ws(e);
                        case _s.EVENT:
                        case _s.BINARY_EVENT:
                            return Array.isArray(e) && ("number" == typeof e[0] || "string" == typeof e[0] && -1 === bs.indexOf(e[0]));
                        case _s.ACK:
                        case _s.BINARY_ACK:
                            return Array.isArray(e)
                    }
                }
                destroy() {
                    this.reconstructor && (this.reconstructor.finishedReconstruction(), this.reconstructor = null)
                }
            }
            class Es {
                constructor(t) {
                    this.packet = t, this.buffers = [], this.reconPack = t
                }
                takeBinaryData(t) {
                    if (this.buffers.push(t), this.buffers.length === this.reconPack.attachments) {
                        const t = ys(this.reconPack, this.buffers);
                        return this.finishedReconstruction(), t
                    }
                    return null
                }
                finishedReconstruction() {
                    this.reconPack = null, this.buffers = []
                }
            }

            function As(t, e, s) {
                return t.on(e, s),
                    function() {
                        t.off(e, s)
                    }
            }
            const Os = Object.freeze({
                connect: 1,
                connect_error: 1,
                disconnect: 1,
                disconnecting: 1,
                newListener: 1,
                removeListener: 1
            });
            class Ts extends Se {
                constructor(t, e, s) {
                    super(), this.connected = !1, this.recovered = !1, this.receiveBuffer = [], this.sendBuffer = [], this._queue = [], this._queueSeq = 0, this.ids = 0, this.acks = {}, this.flags = {}, this.io = t, this.nsp = e, s && s.auth && (this.auth = s.auth), this._opts = Object.assign({}, s), this.io._autoConnect && this.open()
                }
                get disconnected() {
                    return !this.connected
                }
                subEvents() {
                    if (this.subs) return;
                    const t = this.io;
                    this.subs = [As(t, "open", this.onopen.bind(this)), As(t, "packet", this.onpacket.bind(this)), As(t, "error", this.onerror.bind(this)), As(t, "close", this.onclose.bind(this))]
                }
                get active() {
                    return !!this.subs
                }
                connect() {
                    return this.connected || (this.subEvents(), this.io._reconnecting || this.io.open(), "open" === this.io._readyState && this.onopen()), this
                }
                open() {
                    return this.connect()
                }
                send(...t) {
                    return t.unshift("message"), this.emit.apply(this, t), this
                }
                emit(t, ...e) {
                    var s, r, n;
                    if (Os.hasOwnProperty(t)) throw new Error('"' + t.toString() + '" is a reserved event name');
                    if (e.unshift(t), this._opts.retries && !this.flags.fromQueue && !this.flags.volatile) return this._addToQueue(e), this;
                    const o = {
                        type: _s.EVENT,
                        data: e,
                        options: {}
                    };
                    if (o.options.compress = !1 !== this.flags.compress, "function" == typeof e[e.length - 1]) {
                        const t = this.ids++,
                            s = e.pop();
                        this._registerAckCallback(t, s), o.id = t
                    }
                    const i = null === (r = null === (s = this.io.engine) || void 0 === s ? void 0 : s.transport) || void 0 === r ? void 0 : r.writable,
                        a = this.connected && !(null === (n = this.io.engine) || void 0 === n ? void 0 : n._hasPingExpired());
                    return this.flags.volatile && !i || (a ? (this.notifyOutgoingListeners(o), this.packet(o)) : this.sendBuffer.push(o)), this.flags = {}, this
                }
                _registerAckCallback(t, e) {
                    var s;
                    const r = null !== (s = this.flags.timeout) && void 0 !== s ? s : this._opts.ackTimeout;
                    if (void 0 === r) return void(this.acks[t] = e);
                    const n = this.io.setTimeoutFn((() => {
                            delete this.acks[t];
                            for (let e = 0; e < this.sendBuffer.length; e++) this.sendBuffer[e].id === t && this.sendBuffer.splice(e, 1);
                            e.call(this, new Error("operation has timed out"))
                        }), r),
                        o = (...t) => {
                            this.io.clearTimeoutFn(n), e.apply(this, t)
                        };
                    o.withError = !0, this.acks[t] = o
                }
                emitWithAck(t, ...e) {
                    return new Promise(((s, r) => {
                        const n = (t, e) => t ? r(t) : s(e);
                        n.withError = !0, e.push(n), this.emit(t, ...e)
                    }))
                }
                _addToQueue(t) {
                    let e;
                    "function" == typeof t[t.length - 1] && (e = t.pop());
                    const s = {
                        id: this._queueSeq++,
                        tryCount: 0,
                        pending: !1,
                        args: t,
                        flags: Object.assign({
                            fromQueue: !0
                        }, this.flags)
                    };
                    t.push(((t, ...r) => {
                        if (s !== this._queue[0]) return;
                        return null !== t ? s.tryCount > this._opts.retries && (this._queue.shift(), e && e(t)) : (this._queue.shift(), e && e(null, ...r)), s.pending = !1, this._drainQueue()
                    })), this._queue.push(s), this._drainQueue()
                }
                _drainQueue(t = !1) {
                    if (!this.connected || 0 === this._queue.length) return;
                    const e = this._queue[0];
                    e.pending && !t || (e.pending = !0, e.tryCount++, this.flags = e.flags, this.emit.apply(this, e.args))
                }
                packet(t) {
                    t.nsp = this.nsp, this.io._packet(t)
                }
                onopen() {
                    "function" == typeof this.auth ? this.auth((t => {
                        this._sendConnectPacket(t)
                    })) : this._sendConnectPacket(this.auth)
                }
                _sendConnectPacket(t) {
                    this.packet({
                        type: _s.CONNECT,
                        data: this._pid ? Object.assign({
                            pid: this._pid,
                            offset: this._lastOffset
                        }, t) : t
                    })
                }
                onerror(t) {
                    this.connected || this.emitReserved("connect_error", t)
                }
                onclose(t, e) {
                    this.connected = !1, delete this.id, this.emitReserved("disconnect", t, e), this._clearAcks()
                }
                _clearAcks() {
                    Object.keys(this.acks).forEach((t => {
                        if (!this.sendBuffer.some((e => String(e.id) === t))) {
                            const e = this.acks[t];
                            delete this.acks[t], e.withError && e.call(this, new Error("socket has been disconnected"))
                        }
                    }))
                }
                onpacket(t) {
                    if (t.nsp === this.nsp) switch (t.type) {
                        case _s.CONNECT:
                            t.data && t.data.sid ? this.onconnect(t.data.sid, t.data.pid) : this.emitReserved("connect_error", new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));
                            break;
                        case _s.EVENT:
                        case _s.BINARY_EVENT:
                            this.onevent(t);
                            break;
                        case _s.ACK:
                        case _s.BINARY_ACK:
                            this.onack(t);
                            break;
                        case _s.DISCONNECT:
                            this.ondisconnect();
                            break;
                        case _s.CONNECT_ERROR:
                            this.destroy();
                            const e = new Error(t.data.message);
                            e.data = t.data.data, this.emitReserved("connect_error", e)
                    }
                }
                onevent(t) {
                    const e = t.data || [];
                    null != t.id && e.push(this.ack(t.id)), this.connected ? this.emitEvent(e) : this.receiveBuffer.push(Object.freeze(e))
                }
                emitEvent(t) {
                    if (this._anyListeners && this._anyListeners.length) {
                        const e = this._anyListeners.slice();
                        for (const s of e) s.apply(this, t)
                    }
                    super.emit.apply(this, t), this._pid && t.length && "string" == typeof t[t.length - 1] && (this._lastOffset = t[t.length - 1])
                }
                ack(t) {
                    const e = this;
                    let s = !1;
                    return function(...r) {
                        s || (s = !0, e.packet({
                            type: _s.ACK,
                            id: t,
                            data: r
                        }))
                    }
                }
                onack(t) {
                    const e = this.acks[t.id];
                    "function" == typeof e && (delete this.acks[t.id], e.withError && t.data.unshift(null), e.apply(this, t.data))
                }
                onconnect(t, e) {
                    this.id = t, this.recovered = e && this._pid === e, this._pid = e, this.connected = !0, this.emitBuffered(), this.emitReserved("connect"), this._drainQueue(!0)
                }
                emitBuffered() {
                    this.receiveBuffer.forEach((t => this.emitEvent(t))), this.receiveBuffer = [], this.sendBuffer.forEach((t => {
                        this.notifyOutgoingListeners(t), this.packet(t)
                    })), this.sendBuffer = []
                }
                ondisconnect() {
                    this.destroy(), this.onclose("io server disconnect")
                }
                destroy() {
                    this.subs && (this.subs.forEach((t => t())), this.subs = void 0), this.io._destroy(this)
                }
                disconnect() {
                    return this.connected && this.packet({
                        type: _s.DISCONNECT
                    }), this.destroy(), this.connected && this.onclose("io client disconnect"), this
                }
                close() {
                    return this.disconnect()
                }
                compress(t) {
                    return this.flags.compress = t, this
                }
                get volatile() {
                    return this.flags.volatile = !0, this
                }
                timeout(t) {
                    return this.flags.timeout = t, this
                }
                onAny(t) {
                    return this._anyListeners = this._anyListeners || [], this._anyListeners.push(t), this
                }
                prependAny(t) {
                    return this._anyListeners = this._anyListeners || [], this._anyListeners.unshift(t), this
                }
                offAny(t) {
                    if (!this._anyListeners) return this;
                    if (t) {
                        const e = this._anyListeners;
                        for (let s = 0; s < e.length; s++)
                            if (t === e[s]) return e.splice(s, 1), this
                    } else this._anyListeners = [];
                    return this
                }
                listenersAny() {
                    return this._anyListeners || []
                }
                onAnyOutgoing(t) {
                    return this._anyOutgoingListeners = this._anyOutgoingListeners || [], this._anyOutgoingListeners.push(t), this
                }
                prependAnyOutgoing(t) {
                    return this._anyOutgoingListeners = this._anyOutgoingListeners || [], this._anyOutgoingListeners.unshift(t), this
                }
                offAnyOutgoing(t) {
                    if (!this._anyOutgoingListeners) return this;
                    if (t) {
                        const e = this._anyOutgoingListeners;
                        for (let s = 0; s < e.length; s++)
                            if (t === e[s]) return e.splice(s, 1), this
                    } else this._anyOutgoingListeners = [];
                    return this
                }
                listenersAnyOutgoing() {
                    return this._anyOutgoingListeners || []
                }
                notifyOutgoingListeners(t) {
                    if (this._anyOutgoingListeners && this._anyOutgoingListeners.length) {
                        const e = this._anyOutgoingListeners.slice();
                        for (const s of e) s.apply(this, t.data)
                    }
                }
            }

            function Cs(t) {
                t = t || {}, this.ms = t.min || 100, this.max = t.max || 1e4, this.factor = t.factor || 2, this.jitter = t.jitter > 0 && t.jitter <= 1 ? t.jitter : 0, this.attempts = 0
            }
            Cs.prototype.duration = function() {
                var t = this.ms * Math.pow(this.factor, this.attempts++);
                if (this.jitter) {
                    var e = Math.random(),
                        s = Math.floor(e * this.jitter * t);
                    t = 1 & Math.floor(10 * e) ? t + s : t - s
                }
                return 0 | Math.min(t, this.max)
            }, Cs.prototype.reset = function() {
                this.attempts = 0
            }, Cs.prototype.setMin = function(t) {
                this.ms = t
            }, Cs.prototype.setMax = function(t) {
                this.max = t
            }, Cs.prototype.setJitter = function(t) {
                this.jitter = t
            };
            class Rs extends Se {
                constructor(t, e) {
                    var s;
                    super(), this.nsps = {}, this.subs = [], t && "object" == typeof t && (e = t, t = void 0), (e = e || {}).path = e.path || "/socket.io", this.opts = e, qe(this, e), this.reconnection(!1 !== e.reconnection), this.reconnectionAttempts(e.reconnectionAttempts || 1 / 0), this.reconnectionDelay(e.reconnectionDelay || 1e3), this.reconnectionDelayMax(e.reconnectionDelayMax || 5e3), this.randomizationFactor(null !== (s = e.randomizationFactor) && void 0 !== s ? s : .5), this.backoff = new Cs({
                        min: this.reconnectionDelay(),
                        max: this.reconnectionDelayMax(),
                        jitter: this.randomizationFactor()
                    }), this.timeout(null == e.timeout ? 2e4 : e.timeout), this._readyState = "closed", this.uri = t;
                    const n = e.parser || r;
                    this.encoder = new n.Encoder, this.decoder = new n.Decoder, this._autoConnect = !1 !== e.autoConnect, this._autoConnect && this.open()
                }
                reconnection(t) {
                    return arguments.length ? (this._reconnection = !!t, t || (this.skipReconnect = !0), this) : this._reconnection
                }
                reconnectionAttempts(t) {
                    return void 0 === t ? this._reconnectionAttempts : (this._reconnectionAttempts = t, this)
                }
                reconnectionDelay(t) {
                    var e;
                    return void 0 === t ? this._reconnectionDelay : (this._reconnectionDelay = t, null === (e = this.backoff) || void 0 === e || e.setMin(t), this)
                }
                randomizationFactor(t) {
                    var e;
                    return void 0 === t ? this._randomizationFactor : (this._randomizationFactor = t, null === (e = this.backoff) || void 0 === e || e.setJitter(t), this)
                }
                reconnectionDelayMax(t) {
                    var e;
                    return void 0 === t ? this._reconnectionDelayMax : (this._reconnectionDelayMax = t, null === (e = this.backoff) || void 0 === e || e.setMax(t), this)
                }
                timeout(t) {
                    return arguments.length ? (this._timeout = t, this) : this._timeout
                }
                maybeReconnectOnOpen() {
                    !this._reconnecting && this._reconnection && 0 === this.backoff.attempts && this.reconnect()
                }
                open(t) {
                    if (~this._readyState.indexOf("open")) return this;
                    this.engine = new is(this.uri, this.opts);
                    const e = this.engine,
                        s = this;
                    this._readyState = "opening", this.skipReconnect = !1;
                    const r = As(e, "open", (function() {
                            s.onopen(), t && t()
                        })),
                        n = e => {
                            this.cleanup(), this._readyState = "closed", this.emitReserved("error", e), t ? t(e) : this.maybeReconnectOnOpen()
                        },
                        o = As(e, "error", n);
                    if (!1 !== this._timeout) {
                        const t = this._timeout,
                            s = this.setTimeoutFn((() => {
                                r(), n(new Error("timeout")), e.close()
                            }), t);
                        this.opts.autoUnref && s.unref(), this.subs.push((() => {
                            this.clearTimeoutFn(s)
                        }))
                    }
                    return this.subs.push(r), this.subs.push(o), this
                }
                connect(t) {
                    return this.open(t)
                }
                onopen() {
                    this.cleanup(), this._readyState = "open", this.emitReserved("open");
                    const t = this.engine;
                    this.subs.push(As(t, "ping", this.onping.bind(this)), As(t, "data", this.ondata.bind(this)), As(t, "error", this.onerror.bind(this)), As(t, "close", this.onclose.bind(this)), As(this.decoder, "decoded", this.ondecoded.bind(this)))
                }
                onping() {
                    this.emitReserved("ping")
                }
                ondata(t) {
                    try {
                        this.decoder.add(t)
                    } catch (t) {
                        this.onclose("parse error", t)
                    }
                }
                ondecoded(t) {
                    xe((() => {
                        this.emitReserved("packet", t)
                    }), this.setTimeoutFn)
                }
                onerror(t) {
                    this.emitReserved("error", t)
                }
                socket(t, e) {
                    let s = this.nsps[t];
                    return s ? this._autoConnect && !s.active && s.connect() : (s = new Ts(this, t, e), this.nsps[t] = s), s
                }
                _destroy(t) {
                    const e = Object.keys(this.nsps);
                    for (const t of e) {
                        if (this.nsps[t].active) return
                    }
                    this._close()
                }
                _packet(t) {
                    const e = this.encoder.encode(t);
                    for (let s = 0; s < e.length; s++) this.engine.write(e[s], t.options)
                }
                cleanup() {
                    this.subs.forEach((t => t())), this.subs.length = 0, this.decoder.destroy()
                }
                _close() {
                    this.skipReconnect = !0, this._reconnecting = !1, this.onclose("forced close")
                }
                disconnect() {
                    return this._close()
                }
                onclose(t, e) {
                    var s;
                    this.cleanup(), null === (s = this.engine) || void 0 === s || s.close(), this.backoff.reset(), this._readyState = "closed", this.emitReserved("close", t, e), this._reconnection && !this.skipReconnect && this.reconnect()
                }
                reconnect() {
                    if (this._reconnecting || this.skipReconnect) return this;
                    const t = this;
                    if (this.backoff.attempts >= this._reconnectionAttempts) this.backoff.reset(), this.emitReserved("reconnect_failed"), this._reconnecting = !1;
                    else {
                        const e = this.backoff.duration();
                        this._reconnecting = !0;
                        const s = this.setTimeoutFn((() => {
                            t.skipReconnect || (this.emitReserved("reconnect_attempt", t.backoff.attempts), t.skipReconnect || t.open((e => {
                                e ? (t._reconnecting = !1, t.reconnect(), this.emitReserved("reconnect_error", e)) : t.onreconnect()
                            })))
                        }), e);
                        this.opts.autoUnref && s.unref(), this.subs.push((() => {
                            this.clearTimeoutFn(s)
                        }))
                    }
                }
                onreconnect() {
                    const t = this.backoff.attempts;
                    this._reconnecting = !1, this.backoff.reset(), this.emitReserved("reconnect", t)
                }
            }
            const js = {};

            function Ss(t, e) {
                "object" == typeof t && (e = t, t = void 0);
                const s = function(t, e = "", s) {
                        let r = t;
                        s = s || "undefined" != typeof location && location, null == t && (t = s.protocol + "//" + s.host), "string" == typeof t && ("/" === t.charAt(0) && (t = "/" === t.charAt(1) ? s.protocol + t : s.host + t), /^(https?|wss?):\/\//.test(t) || (t = void 0 !== s ? s.protocol + "//" + t : "https://" + t), r = es(t)), r.port || (/^(http|ws)$/.test(r.protocol) ? r.port = "80" : /^(http|ws)s$/.test(r.protocol) && (r.port = "443")), r.path = r.path || "/";
                        const n = -1 !== r.host.indexOf(":") ? "[" + r.host + "]" : r.host;
                        return r.id = r.protocol + "://" + n + ":" + r.port + e, r.href = r.protocol + "://" + n + (s && s.port === r.port ? "" : ":" + r.port), r
                    }(t, (e = e || {}).path || "/socket.io"),
                    r = s.source,
                    n = s.id,
                    o = s.path,
                    i = js[n] && o in js[n].nsps;
                let a;
                return e.forceNew || e["force new connection"] || !1 === e.multiplex || i ? a = new Rs(r, e) : (js[n] || (js[n] = new Rs(r, e)), a = js[n]), s.query && !e.query && (e.query = s.queryKey), a.socket(s.path, e)
            }
            Object.assign(Ss, {
                Manager: Rs,
                Socket: Ts,
                io: Ss,
                connect: Ss
            });
            const xs = "undefined" != typeof window ? "https:" === window.location.protocol ? `wss://${location.host}` : `ws://${location.host}` : "ws://localhost",
                Bs = "/socket.io",
                Ns = {
                    transports: ["websocket"],
                    randomizationFactor: .35,
                    reconnectionDelay: 2e3,
                    reconnectionDelayMax: 5e3
                };
            class Ps {
                constructor(t, e) {
                    this.eventRecord = new Map, this.wssHost = t, this.wssPath = e
                }
                get socket() {
                    return this.socketInstance || (this.socketInstance = Ss(this.wssHost, this.clientOpts()), this.onSocketInit(this.socketInstance)), this.socketInstance
                }
                clientOpts() {
                    const t = this.wssPath;
                    return { ...Ns,
                        ...t ? {
                            path: t
                        } : {}
                    }
                }
                onSocketInit(t) {}
                disconnectClient() {
                    this.socketInstance && (this.socketInstance.disconnect(), this.socketInstance.removeAllListeners(), this.eventRecord.forEach((t => t.clear())), this.eventRecord.clear(), this.socketInstance = void 0)
                }
                on(t, e, s) {
                    if (!t || !e || !s) return !1;
                    let r = this.eventRecord.get(t);
                    if (r || (r = new Set, this.eventRecord.set(t, r)), r.has(e)) return !1;
                    r.add(e);
                    const {
                        socket: n
                    } = this;
                    return n.on(e, s), !0
                }
                onConnect(t, e) {
                    this.on(t, "connect", e), this.socket.connected && e()
                }
            }
            class Ls extends Ps {
                constructor() {
                    super(xs, Bs), this.socketInitCallback = []
                }
                onSocketInit(t) {
                    this.socketInitCallback.forEach((e => {
                        e(t)
                    }))
                }
                registerSocketInitEvent(t) {
                    this.socketInitCallback.push(t), this.socket.connected && t(this.socket)
                }
            }
            new class {
                getEditorClient() {
                    return this.editorClient || (this.editorClient = new Ls), this.editorClient
                }
                getEditorClientSocket() {
                    return this.getEditorClient().socket
                }
                disconnectEditorClient() {
                    this.editorClient && this.editorClient.disconnectClient()
                }
            }
        },
        93535: function(t, e, s) {
            var r = s(81729).Z.Symbol;
            e.Z = r
        },
        56617: function(t, e, s) {
            s.d(e, {
                Z: function() {
                    return l
                }
            });
            var r = s(93535),
                n = Object.prototype,
                o = n.hasOwnProperty,
                i = n.toString,
                a = r.Z ? r.Z.toStringTag : void 0;
            var c = function(t) {
                    var e = o.call(t, a),
                        s = t[a];
                    try {
                        t[a] = void 0;
                        var r = !0
                    } catch (t) {}
                    var n = i.call(t);
                    return r && (e ? t[a] = s : delete t[a]), n
                },
                h = Object.prototype.toString;
            var u = function(t) {
                    return h.call(t)
                },
                p = r.Z ? r.Z.toStringTag : void 0;
            var l = function(t) {
                return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : p && p in Object(t) ? c(t) : u(t)
            }
        },
        99905: function(t, e) {
            var s = "object" == typeof global && global && global.Object === Object && global;
            e.Z = s
        },
        81729: function(t, e, s) {
            var r = s(99905),
                n = "object" == typeof self && self && self.Object === Object && self,
                o = r.Z || n || Function("return this")();
            e.Z = o
        },
        74646: function(t, e) {
            e.Z = function(t) {
                var e = typeof t;
                return null != t && ("object" == e || "function" == e)
            }
        },
        55822: function(t, e) {
            e.Z = function(t) {
                return null != t && "object" == typeof t
            }
        },
        74535: function(t, e, s) {
            var r = s(56617),
                n = s(55822);
            e.Z = function(t) {
                return "symbol" == typeof t || (0, n.Z)(t) && "[object Symbol]" == (0, r.Z)(t)
            }
        }
    }
]);